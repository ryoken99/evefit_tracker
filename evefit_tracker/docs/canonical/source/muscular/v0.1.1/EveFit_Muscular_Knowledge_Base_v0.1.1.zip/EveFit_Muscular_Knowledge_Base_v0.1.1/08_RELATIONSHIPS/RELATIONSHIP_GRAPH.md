# Grafo de relações

O grafo v0.1 contém 365 relações de entidade para
articulação, 484 relações de entidade para ação e
394 relações músculo-músculo contextuais.

## Regras

- `muscle_id` pode identificar músculo/série ou componente; `subject_type` e
  `parent_muscle_id` impedem dupla contagem.
- Cada relação ação tem uma afirmação atómica própria e rastreável.
- Componentes são nós funcionais com relações ou justificação explícita.
- Relações músculo-músculo incluem um núcleo curado e co-contribuições de baixa
  confiança derivadas de ação/articulação partilhadas. A ordenação alfabética é
  apenas desempate determinístico, nunca evidência da relação.
- Candidatos residuais de estabilização ou compensação por grupo/região ficam
  `specialist_pending`; não são dependências nem sinergias inevitáveis.
- Lateralidade, segmento fixo, cadeia, apoio, ângulo e limitações fazem parte do
  contexto da relação.
- Relações clínicas/especialistas ficam `specialist_pending` e não entram na
  camada pública.

Os exports normativos são `muscle_joint_relations.csv`,
`muscle_action_relations.csv` e `muscle_interaction_relations.csv`.
