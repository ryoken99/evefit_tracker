# Catálogo do membro inferior e cintura pélvica

> Catálogo completo dentro do âmbito EveFit definido. Não é um catálogo completo de todos os músculos do corpo humano.

Cada perfil separa factos anatómicos, interpretação funcional e inferência de treino. As ações são contextuais.

## Abdutor do dedo mínimo do pé (`abductor_digiti_minimi_foot`)

- **Latim / inglês:** musculus abductor digiti minimi pedis / abductor digiti minimi of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `superficial`
- **Origem:** Tuberosidade do calcâneo.
- **Inserção:** Base lateral da falange proximal do dedo V.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints; `monoarticular`
- **Inervação:** Nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metatarsofalângica dos dedos II–V e abdução metatarsofalângica dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000001, claim_000002, claim_000003, claim_000004, claim_000005, claim_000006

### Relações músculo-ação

- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_mtp_abduction` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Abdutor do hálux (`abductor_hallucis`)

- **Latim / inglês:** musculus abductor hallucis / abductor hallucis
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `superficial`
- **Origem:** Processo medial da tuberosidade do calcâneo, retináculo dos flexores e aponeurose plantar.
- **Inserção:** Base medial da falange proximal do hálux.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** hallux_metatarsophalangeal_joint; `monoarticular`
- **Inervação:** Nervo plantar medial.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metatarsofalângica do hálux e abdução metatarsofalângica do hálux; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000021, claim_000022, claim_000023, claim_000024, claim_000025, claim_000026

### Relações músculo-ação

- `hallux_mtp_flexion` em `hallux_metatarsophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hallux_metatarsophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica do hálux quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hallux_mtp_abduction` em `hallux_metatarsophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hallux_metatarsophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução metatarsofalângica do hálux quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Adutor curto (`adductor_brevis`)

- **Latim / inglês:** musculus adductor brevis / adductor brevis
- **Região / grupo / camada:** `thigh` / `thigh_adductors` / `deep`
- **Origem:** Corpo e ramo inferior do púbis.
- **Inserção:** Linha pectínea e linha áspera proximal.
- **Arquitetura e fibras:** `triangular`. Fibras dispõem-se numa unidade triangular entre fixações de larguras diferentes.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo obturador.
- **Encurtamento aproximado:** Posição combinada compatível com adução da anca e flexão da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com abdução da anca e extensão da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta adução da anca e flexão da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000046, claim_000047, claim_000048, claim_000049, claim_000050, claim_000051

### Relações músculo-ação

- `hip_adduction` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_flexion` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Adutor do hálux (`adductor_hallucis`)

- **Latim / inglês:** musculus adductor hallucis / adductor hallucis
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Cabeça oblíqua nas bases metatársicas II–IV; cabeça transversa nos ligamentos plantares MTF.
- **Inserção:** Base lateral da falange proximal do hálux.
- **Arquitetura e fibras:** `two_headed`. Duas cabeças com orientação própria convergem para uma unidade funcional comum.
- **Articulações e classe:** hallux_metatarsophalangeal_joint; `monoarticular`
- **Inervação:** Ramo profundo do nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metatarsofalângica do hálux e adução metatarsofalângica do hálux; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000054, claim_000055, claim_000056, claim_000057, claim_000058, claim_000059

### Relações músculo-ação

- `hallux_mtp_flexion` em `hallux_metatarsophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hallux_metatarsophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica do hálux quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hallux_mtp_adduction` em `hallux_metatarsophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hallux_metatarsophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução metatarsofalângica do hálux quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Adutor longo (`adductor_longus`)

- **Latim / inglês:** musculus adductor longus / adductor longus
- **Região / grupo / camada:** `thigh` / `thigh_adductors` / `superficial`
- **Origem:** Corpo do púbis inferior à crista púbica.
- **Inserção:** Terço médio da linha áspera.
- **Arquitetura e fibras:** `triangular`. Fibras dispõem-se numa unidade triangular entre fixações de larguras diferentes.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo obturador.
- **Encurtamento aproximado:** Posição combinada compatível com adução da anca e flexão da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com abdução da anca e extensão da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta adução da anca e flexão da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000062, claim_000063, claim_000064, claim_000065, claim_000066, claim_000067

### Relações músculo-ação

- `hip_adduction` em `hip_joint`: `principal_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_flexion` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Adutor magno (`adductor_magnus`)

- **Latim / inglês:** musculus adductor magnus / adductor magnus
- **Região / grupo / camada:** `thigh` / `thigh_adductors` / `deep`
- **Origem:** Ramo inferior do púbis, ramo do ísquio e tuberosidade isquiática.
- **Inserção:** Tuberosidade glútea, linha áspera, linha supracondilar medial e tubérculo adutor.
- **Arquitetura e fibras:** `composite_fan`. As porções adutora e isquiotibial têm orientações e fixações diferentes; a descrição mecânica deve conservar essa subdivisão.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo obturador (porção adutora) e divisão tibial do ciático (porção isquiotibial).
- **Encurtamento aproximado:** Posição combinada compatível com adução da anca, flexão da anca e extensão da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com abdução da anca, extensão da anca e flexão da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta adução da anca, flexão da anca e extensão da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. As porções adutora e isquiotibial têm linhas de ação e inervação distintas; a contribuição flexora/extensora depende do ângulo.
- **Claims:** claim_000070, claim_000071, claim_000072, claim_000073, claim_000074, claim_000075

### Relações músculo-ação

- `hip_adduction` em `hip_joint`: `principal_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_flexion` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_extension` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Articular do joelho (`articularis_genus`)

- **Latim / inglês:** musculus articularis genus / articularis genus
- **Região / grupo / camada:** `thigh` / `anterior_thigh_other` / `deep`
- **Origem:** Face anterior distal do fémur.
- **Inserção:** Cápsula articular e bolsa suprapatelar.
- **Arquitetura e fibras:** `small_parallel`. Pequeno feixe de fibras paralelas, por vezes anatomicamente variável.
- **Articulações e classe:** knee_joint; `monoarticular`
- **Inervação:** Nervo femoral.
- **Encurtamento aproximado:** Relaciona-se com a retração da cápsula durante a extensão do joelho; não se define uma posição de encurtamento como alvo de treino independente.
- **Alongamento aproximado:** A flexão do joelho altera a relação com a cápsula; não se apresenta uma posição de alongamento autónoma.
- **Insuficiência ativa/passiva:** Não aplicável como limitação multiarticular de um alvo motor independente. Não aplicável como regra prática autónoma; a cápsula articular exige contexto especializado.
- **Mecânica:** A linha de tração dirige-se à cápsula do joelho e acompanha a extensão articular. Não é tratado como motor rotacional independente; não foi atribuído braço de momento. A força local acompanha a atividade do aparelho extensor e a geometria capsular; não existe perfil motor independente aprovado.
- **Cadeia aberta/fechada:** Durante a extensão do joelho, acompanha a retração capsular; não é um motor isolável da cadeia. Com o segmento distal fixo, o papel capsular continua subordinado ao movimento do joelho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000115, claim_000116, claim_000117, claim_000118, claim_000119, claim_000120, claim_000121

### Relações músculo-ação

- `knee_capsular_retraction` em ``: `capsular_retractor`. Ocorre em associação com a extensão do joelho e com a relação local entre músculo e cápsula. Retração capsular local associada à extensão, sem afirmar produção relevante do momento articular. Não foi aprovada uma função excêntrica capsular independente nesta versão.

## Bicípite femoral (`biceps_femoris`)

- **Latim / inglês:** musculus biceps femoris / biceps femoris
- **Região / grupo / camada:** `thigh` / `hamstrings` / `superficial`
- **Origem:** Cabeça longa: tuberosidade isquiática; cabeça curta: linha áspera e linha supracondilar lateral.
- **Inserção:** Cabeça da fíbula.
- **Arquitetura e fibras:** `fusiform_two_headed`. Duas cabeças convergem para uma unidade distal comum, com orientações proximais diferentes.
- **Articulações e classe:** hip_joint, knee_joint; `biarticular`
- **Inervação:** Divisão tibial do ciático (longa) e divisão fibular comum (curta).
- **Encurtamento aproximado:** Posição combinada compatível com extensão da anca, flexão do joelho e rotação externa da perna com o joelho fletido; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão da anca e extensão do joelho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** A cabeça longa pode perder capacidade quando a anca está estendida e o joelho fletido em simultâneo. A flexão da anca combinada com extensão do joelho pode aumentar a tensão passiva da cabeça longa; a cabeça curta não atravessa a anca.
- **Mecânica:** A tração relativamente à anca sustenta extensão da anca, flexão do joelho e rotação externa da perna com o joelho fletido, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000134, claim_000135, claim_000136, claim_000137, claim_000138, claim_000139, claim_000140

### Relações músculo-ação

- `hip_extension` em `hip_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: hip_joint. Pode produzir ou assistir extensão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_flexion` em `knee_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: knee_joint. Pode produzir ou assistir flexão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_external_rotation` em `knee_joint`: `secondary_or_contextual_contributor`. A rotação axial da perna torna-se mecanicamente relevante sobretudo com o joelho fletido. Pode produzir ou assistir rotação externa da perna no joelho fletido quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Primeiro interósseo dorsal do pé (`dorsal_interosseous_foot_1`)

- **Latim / inglês:** musculus interosseus dorsalis pedis I / first dorsal interosseous of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Faces adjacentes dos metatársicos I e II.
- **Inserção:** Base medial da falange proximal do dedo II e expansão extensora do dedo correspondente.
- **Arquitetura e fibras:** `bipennate_set`. Conjunto de músculos bipenados com orientação específica por raio digital.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com abdução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com abdução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000209, claim_000210, claim_000211, claim_000212, claim_000213, claim_000214, claim_000215, claim_000216

### Relações músculo-ação

- `lesser_toe_mtp_abduction` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Segundo interósseo dorsal do pé (`dorsal_interosseous_foot_2`)

- **Latim / inglês:** musculus interosseus dorsalis pedis II / second dorsal interosseous of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Faces adjacentes dos metatársicos II e III.
- **Inserção:** Base lateral da falange proximal do dedo II e expansão extensora do dedo correspondente.
- **Arquitetura e fibras:** `bipennate_set`. Conjunto de músculos bipenados com orientação específica por raio digital.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com abdução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com abdução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000221, claim_000222, claim_000223, claim_000224, claim_000225, claim_000226, claim_000227, claim_000228

### Relações músculo-ação

- `lesser_toe_mtp_abduction` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Terceiro interósseo dorsal do pé (`dorsal_interosseous_foot_3`)

- **Latim / inglês:** musculus interosseus dorsalis pedis III / third dorsal interosseous of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Faces adjacentes dos metatársicos III e IV.
- **Inserção:** Base lateral da falange proximal do dedo III e expansão extensora do dedo correspondente.
- **Arquitetura e fibras:** `bipennate_set`. Conjunto de músculos bipenados com orientação específica por raio digital.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com abdução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com abdução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000233, claim_000234, claim_000235, claim_000236, claim_000237, claim_000238, claim_000239, claim_000240

### Relações músculo-ação

- `lesser_toe_mtp_abduction` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Quarto interósseo dorsal do pé (`dorsal_interosseous_foot_4`)

- **Latim / inglês:** musculus interosseus dorsalis pedis IV / fourth dorsal interosseous of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Faces adjacentes dos metatársicos IV e V.
- **Inserção:** Base lateral da falange proximal do dedo IV e expansão extensora do dedo correspondente.
- **Arquitetura e fibras:** `bipennate_set`. Conjunto de músculos bipenados com orientação específica por raio digital.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com abdução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com abdução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000245, claim_000246, claim_000247, claim_000248, claim_000249, claim_000250, claim_000251, claim_000252

### Relações músculo-ação

- `lesser_toe_mtp_abduction` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor curto dos dedos do pé (`extensor_digitorum_brevis`)

- **Latim / inglês:** musculus extensor digitorum brevis / extensor digitorum brevis
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_dorsal` / `superficial`
- **Origem:** Face superolateral do calcâneo.
- **Inserção:** Tendões extensores dos dedos II–IV.
- **Arquitetura e fibras:** `fan_shaped`. Fibras em leque convergem entre uma fixação ampla e outra mais concentrada.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo fibular profundo.
- **Encurtamento aproximado:** Combinação digital compatível com extensão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com extensão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000358, claim_000359, claim_000360, claim_000361, claim_000362, claim_000363, claim_000364, claim_000365

### Relações músculo-ação

- `lesser_toe_mtp_extension` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor longo dos dedos (`extensor_digitorum_longus`)

- **Latim / inglês:** musculus extensor digitorum longus / extensor digitorum longus
- **Região / grupo / camada:** `leg` / `anterior_leg` / `superficial`
- **Origem:** Côndilo lateral da tíbia, fíbula anterior e membrana interóssea.
- **Inserção:** Expansões extensoras dos dedos II–V.
- **Arquitetura e fibras:** `pennate`. Fascículos oblíquos inserem-se num tendão ou aponeurose.
- **Articulações e classe:** talocrural_joint, subtalar_joint, lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo fibular profundo.
- **Encurtamento aproximado:** Combinação digital compatível com dorsiflexão, eversão do pé, extensão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de talocrural_joint, subtalar_joint, lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com dorsiflexão, eversão do pé, extensão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações talocrural_joint, subtalar_joint, lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta dorsiflexão, eversão do pé, extensão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000369, claim_000370, claim_000371, claim_000372, claim_000373, claim_000374, claim_000375, claim_000376, claim_000377, claim_000378

### Relações músculo-ação

- `ankle_dorsiflexion` em `talocrural_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de talocrural_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir dorsiflexão quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `foot_eversion` em `subtalar_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de subtalar_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir eversão do pé quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_mtp_extension` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor curto do hálux (`extensor_hallucis_brevis`)

- **Latim / inglês:** musculus extensor hallucis brevis / extensor hallucis brevis
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_dorsal` / `superficial`
- **Origem:** Face superolateral do calcâneo.
- **Inserção:** Base dorsal da falange proximal do hálux.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** hallux_metatarsophalangeal_joint; `monoarticular`
- **Inervação:** Nervo fibular profundo.
- **Encurtamento aproximado:** Combinação digital compatível com extensão metatarsofalângica do hálux; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000384, claim_000385, claim_000386, claim_000387, claim_000388, claim_000389

### Relações músculo-ação

- `hallux_mtp_extension` em `hallux_metatarsophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hallux_metatarsophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão metatarsofalângica do hálux quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor longo do hálux (`extensor_hallucis_longus`)

- **Latim / inglês:** musculus extensor hallucis longus / extensor hallucis longus
- **Região / grupo / camada:** `leg` / `anterior_leg` / `deep`
- **Origem:** Face anterior média da fíbula e membrana interóssea.
- **Inserção:** Base dorsal da falange distal do hálux.
- **Arquitetura e fibras:** `unipennate`. Fascículos oblíquos inserem-se num lado do tendão.
- **Articulações e classe:** talocrural_joint, hallux_metatarsophalangeal_joint, hallux_interphalangeal_joint; `multiarticular`
- **Inervação:** Nervo fibular profundo.
- **Encurtamento aproximado:** Combinação digital compatível com dorsiflexão, extensão metatarsofalângica do hálux e extensão interfalângica do hálux; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de talocrural_joint, hallux_metatarsophalangeal_joint, hallux_interphalangeal_joint, em posições compatíveis com dorsiflexão, extensão metatarsofalângica do hálux e extensão interfalângica do hálux. Pode ocorrer quando as articulações talocrural_joint, hallux_metatarsophalangeal_joint, hallux_interphalangeal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta dorsiflexão, extensão metatarsofalângica do hálux e extensão interfalângica do hálux conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000391, claim_000392, claim_000393, claim_000394, claim_000395, claim_000396, claim_000397, claim_000398

### Relações músculo-ação

- `ankle_dorsiflexion` em `talocrural_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de talocrural_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir dorsiflexão quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hallux_mtp_extension` em `hallux_metatarsophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hallux_metatarsophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão metatarsofalângica do hálux quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hallux_ip_extension` em `hallux_interphalangeal_joint`: `principal_contributor`. A contribuição varia ao longo de hallux_interphalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica do hálux quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Fibular curto (`fibularis_brevis`)

- **Latim / inglês:** musculus fibularis brevis / fibularis brevis
- **Região / grupo / camada:** `leg` / `lateral_leg` / `deep`
- **Origem:** Dois terços inferiores da face lateral da fíbula.
- **Inserção:** Tuberosidade da base do metatársico V.
- **Arquitetura e fibras:** `unipennate`. Fascículos oblíquos inserem-se num lado do tendão.
- **Articulações e classe:** talocrural_joint, subtalar_joint; `biarticular`
- **Inervação:** Nervo fibular superficial.
- **Encurtamento aproximado:** Posição combinada compatível com flexão plantar e eversão do pé; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com dorsiflexão e inversão do pé; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de talocrural_joint, subtalar_joint, em posições compatíveis com flexão plantar e eversão do pé. Pode ocorrer quando as articulações talocrural_joint, subtalar_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta flexão plantar e eversão do pé conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000467, claim_000468, claim_000469, claim_000470, claim_000471, claim_000472, claim_000473

### Relações músculo-ação

- `ankle_plantarflexion` em `talocrural_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de talocrural_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão plantar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `foot_eversion` em `subtalar_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de subtalar_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir eversão do pé quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Fibular longo (`fibularis_longus`)

- **Latim / inglês:** musculus fibularis longus / fibularis longus
- **Região / grupo / camada:** `leg` / `lateral_leg` / `superficial`
- **Origem:** Cabeça e dois terços superiores da face lateral da fíbula.
- **Inserção:** Base do metatársico I e cuneiforme medial, plantarmente.
- **Arquitetura e fibras:** `bipennate`. Fascículos oblíquos inserem-se nos dois lados de um tendão central.
- **Articulações e classe:** talocrural_joint, subtalar_joint, transverse_tarsal_joint; `multiarticular`
- **Inervação:** Nervo fibular superficial.
- **Encurtamento aproximado:** Posição combinada compatível com flexão plantar e eversão do pé; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com dorsiflexão e inversão do pé; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de talocrural_joint, subtalar_joint, transverse_tarsal_joint, em posições compatíveis com flexão plantar e eversão do pé. Pode ocorrer quando as articulações talocrural_joint, subtalar_joint, transverse_tarsal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta flexão plantar e eversão do pé conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. Também contribui para suporte dinâmico dos arcos e estabilização do primeiro raio, dependente da tarefa.
- **Claims:** claim_000476, claim_000477, claim_000478, claim_000479, claim_000480, claim_000481, claim_000482, claim_000483

### Relações músculo-ação

- `ankle_plantarflexion` em `talocrural_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de talocrural_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão plantar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `foot_eversion` em `subtalar_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de subtalar_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir eversão do pé quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Fibular terceiro (`fibularis_tertius`)

- **Latim / inglês:** musculus fibularis tertius / fibularis tertius
- **Região / grupo / camada:** `leg` / `anterior_leg` / `superficial`
- **Origem:** Terço distal da face anterior da fíbula.
- **Inserção:** Base dorsal do metatársico V.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** talocrural_joint, subtalar_joint; `biarticular`
- **Inervação:** Nervo fibular profundo.
- **Encurtamento aproximado:** Posição combinada compatível com dorsiflexão e eversão do pé; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão plantar e inversão do pé; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de talocrural_joint, subtalar_joint, em posições compatíveis com dorsiflexão e eversão do pé. Pode ocorrer quando as articulações talocrural_joint, subtalar_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta dorsiflexão e eversão do pé conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Pode estar ausente ou fundido com o extensor longo dos dedos. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000486, claim_000487, claim_000488, claim_000489, claim_000490, claim_000491, claim_000492

### Relações músculo-ação

- `ankle_dorsiflexion` em `talocrural_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de talocrural_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir dorsiflexão quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `foot_eversion` em `subtalar_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de subtalar_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir eversão do pé quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor curto do dedo mínimo do pé (`flexor_digiti_minimi_brevis_foot`)

- **Latim / inglês:** musculus flexor digiti minimi brevis pedis / flexor digiti minimi brevis of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Base do metatársico V.
- **Inserção:** Base da falange proximal do dedo V.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints; `monoarticular`
- **Inervação:** Ramo superficial do nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metatarsofalângica dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000513, claim_000514, claim_000515, claim_000516, claim_000517, claim_000518

### Relações músculo-ação

- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor curto dos dedos do pé (`flexor_digitorum_brevis`)

- **Latim / inglês:** musculus flexor digitorum brevis / flexor digitorum brevis
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `superficial`
- **Origem:** Processo medial da tuberosidade do calcâneo.
- **Inserção:** Falanges médias II–V.
- **Arquitetura e fibras:** `multipennate`. Múltiplos conjuntos de fascículos oblíquos inserem-se em septos ou tendões internos.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints; `biarticular`
- **Inervação:** Nervo plantar medial.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metatarsofalângica dos dedos II–V e flexão interfalângica proximal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, em posições compatíveis com flexão metatarsofalângica dos dedos II–V e flexão interfalângica proximal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000527, claim_000528, claim_000529, claim_000530, claim_000531, claim_000532, claim_000533

### Relações músculo-ação

- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_flexion` em `lesser_toe_proximal_interphalangeal_joints`: `principal_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor longo dos dedos do pé (`flexor_digitorum_longus`)

- **Latim / inglês:** musculus flexor digitorum longus / flexor digitorum longus
- **Região / grupo / camada:** `leg` / `posterior_leg_deep` / `deep`
- **Origem:** Face posterior da tíbia.
- **Inserção:** Bases das falanges distais II–V.
- **Arquitetura e fibras:** `unipennate`. Fascículos oblíquos inserem-se num lado do tendão.
- **Articulações e classe:** talocrural_joint, subtalar_joint, lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo tibial.
- **Encurtamento aproximado:** Combinação digital compatível com flexão plantar, inversão do pé, flexão metatarsofalângica dos dedos II–V, flexão interfalângica proximal dos dedos II–V e flexão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Flexão plantar e flexão dos dedos em simultâneo podem reduzir a capacidade ativa distal. Dorsiflexão combinada com extensão dos dedos pode aumentar a tensão passiva.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta flexão plantar, inversão do pé, flexão metatarsofalângica dos dedos II–V, flexão interfalângica proximal dos dedos II–V e flexão interfalângica distal dos dedos II–V conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000536, claim_000537, claim_000538, claim_000539, claim_000540, claim_000541, claim_000542, claim_000543, claim_000544, claim_000545

### Relações músculo-ação

- `ankle_plantarflexion` em `talocrural_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de talocrural_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão plantar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `foot_inversion` em `subtalar_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de subtalar_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir inversão do pé quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_flexion` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_flexion` em `lesser_toe_distal_interphalangeal_joints`: `principal_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor curto do hálux (`flexor_hallucis_brevis`)

- **Latim / inglês:** musculus flexor hallucis brevis / flexor hallucis brevis
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Cubóide, cuneiforme lateral e tendão do tibial posterior.
- **Inserção:** Ambos os lados da base da falange proximal do hálux por sesamoides.
- **Arquitetura e fibras:** `two_headed`. Duas cabeças com orientação própria convergem para uma unidade funcional comum.
- **Articulações e classe:** hallux_metatarsophalangeal_joint; `monoarticular`
- **Inervação:** Nervo plantar medial.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metatarsofalângica do hálux; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000577, claim_000578, claim_000579, claim_000580, claim_000581, claim_000582

### Relações músculo-ação

- `hallux_mtp_flexion` em `hallux_metatarsophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hallux_metatarsophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica do hálux quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor longo do hálux (`flexor_hallucis_longus`)

- **Latim / inglês:** musculus flexor hallucis longus / flexor hallucis longus
- **Região / grupo / camada:** `leg` / `posterior_leg_deep` / `deep`
- **Origem:** Dois terços inferiores da face posterior da fíbula.
- **Inserção:** Base da falange distal do hálux.
- **Arquitetura e fibras:** `unipennate`. Fascículos oblíquos inserem-se num lado do tendão.
- **Articulações e classe:** talocrural_joint, subtalar_joint, hallux_metatarsophalangeal_joint, hallux_interphalangeal_joint; `multiarticular`
- **Inervação:** Nervo tibial.
- **Encurtamento aproximado:** Combinação digital compatível com flexão plantar, inversão do pé, flexão metatarsofalângica do hálux e flexão interfalângica do hálux; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Flexão plantar e flexão do hálux em simultâneo podem reduzir a capacidade ativa distal. Dorsiflexão combinada com extensão do hálux pode aumentar a tensão passiva.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta flexão plantar, inversão do pé, flexão metatarsofalângica do hálux e flexão interfalângica do hálux conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000584, claim_000585, claim_000586, claim_000587, claim_000588, claim_000589, claim_000590, claim_000591, claim_000592

### Relações músculo-ação

- `ankle_plantarflexion` em `talocrural_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de talocrural_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão plantar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `foot_inversion` em `subtalar_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de subtalar_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir inversão do pé quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hallux_mtp_flexion` em `hallux_metatarsophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hallux_metatarsophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica do hálux quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hallux_ip_flexion` em `hallux_interphalangeal_joint`: `principal_contributor`. A contribuição varia ao longo de hallux_interphalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão interfalângica do hálux quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Gastrocnémio (`gastrocnemius`)

- **Latim / inglês:** musculus gastrocnemius / gastrocnemius
- **Região / grupo / camada:** `leg` / `posterior_leg_superficial` / `superficial`
- **Origem:** Cabeças medial e lateral acima dos côndilos femorais.
- **Inserção:** Calcâneo através do tendão calcaneano.
- **Arquitetura e fibras:** `bipennate_two_headed`. A orientação é inferida qualitativamente das fixações e da arquitetura registadas; não foi quantificada como uma direção universal.
- **Articulações e classe:** knee_joint, talocrural_joint; `biarticular`
- **Inervação:** Nervo tibial.
- **Encurtamento aproximado:** Posição combinada compatível com flexão plantar e flexão do joelho; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com dorsiflexão e extensão do joelho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode perder capacidade de flexão plantar quando está encurtado simultaneamente pela flexão do joelho e pela flexão plantar. A extensão do joelho combinada com dorsiflexão pode aumentar a tensão passiva.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta flexão plantar e flexão do joelho conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. Biarticular: a flexão do joelho reduz o comprimento e pode limitar a contribuição para flexão plantar.
- **Claims:** claim_000619, claim_000620, claim_000621, claim_000622, claim_000623, claim_000624, claim_000625

### Relações músculo-ação

- `ankle_plantarflexion` em `talocrural_joint`: `principal_contributor`. O papel depende da posição combinada das articulações: talocrural_joint. Pode produzir ou assistir flexão plantar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_flexion` em `knee_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: knee_joint. Pode produzir ou assistir flexão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Glúteo máximo (`gluteus_maximus`)

- **Latim / inglês:** musculus gluteus maximus / gluteus maximus
- **Região / grupo / camada:** `pelvic_girdle_gluteal` / `gluteal_group` / `superficial`
- **Origem:** Ílio posterior, sacro, cóccix e ligamento sacrotuberoso.
- **Inserção:** Trato iliotibial e tuberosidade glútea.
- **Arquitetura e fibras:** `coarse_fascicular`. Fascículos espessos convergem para a inserção tendinosa e fascial.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo glúteo inferior.
- **Encurtamento aproximado:** Posição combinada compatível com extensão da anca e rotação externa da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão da anca e rotação interna da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta extensão da anca e rotação externa da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. As fibras superiores e inferiores diferem na componente frontal; a extensão é mais relevante sob determinadas amplitudes e exigências externas.
- **Claims:** claim_000628, claim_000629, claim_000630, claim_000631, claim_000632, claim_000633, claim_000634

### Relações músculo-ação

- `hip_extension` em `hip_joint`: `principal_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_external_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação externa da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Glúteo médio (`gluteus_medius`)

- **Latim / inglês:** musculus gluteus medius / gluteus medius
- **Região / grupo / camada:** `pelvic_girdle_gluteal` / `gluteal_group` / `intermediate`
- **Origem:** Face glútea do ílio entre as linhas glúteas anterior e posterior.
- **Inserção:** Face lateral do trocânter maior.
- **Arquitetura e fibras:** `fan_shaped`. Fascículos anteriores, médios e posteriores formam um leque com linhas de ação diferentes.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo glúteo superior.
- **Encurtamento aproximado:** Posição combinada compatível com abdução da anca, rotação interna da anca e rotação externa da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com adução da anca, rotação externa da anca e rotação interna da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta abdução da anca, rotação interna da anca e rotação externa da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A direção de rotação varia entre fascículos e ângulos; em apoio unilateral participa no controlo frontal da pelve.
- **Claims:** claim_000637, claim_000638, claim_000639, claim_000640, claim_000641, claim_000642

### Relações músculo-ação

- `hip_abduction` em `hip_joint`: `principal_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_internal_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação interna da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_external_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação externa da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Glúteo mínimo (`gluteus_minimus`)

- **Latim / inglês:** musculus gluteus minimus / gluteus minimus
- **Região / grupo / camada:** `pelvic_girdle_gluteal` / `gluteal_group` / `deep`
- **Origem:** Face glútea do ílio entre as linhas glúteas anterior e inferior.
- **Inserção:** Face anterior do trocânter maior.
- **Arquitetura e fibras:** `fan_shaped`. Fascículos anteriores e posteriores convergem em leque, com contribuição dependente da posição.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo glúteo superior.
- **Encurtamento aproximado:** Posição combinada compatível com abdução da anca e rotação interna da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com adução da anca e rotação externa da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta abdução da anca e rotação interna da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000646, claim_000647, claim_000648, claim_000649, claim_000650, claim_000651

### Relações músculo-ação

- `hip_abduction` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_internal_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação interna da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Grácil (`gracilis`)

- **Latim / inglês:** musculus gracilis / gracilis
- **Região / grupo / camada:** `thigh` / `thigh_adductors` / `superficial`
- **Origem:** Corpo e ramo inferior do púbis.
- **Inserção:** Face medial da tíbia proximal, na pata de ganso.
- **Arquitetura e fibras:** `strap`. A orientação é inferida qualitativamente das fixações e da arquitetura registadas; não foi quantificada como uma direção universal.
- **Articulações e classe:** hip_joint, knee_joint; `biarticular`
- **Inervação:** Nervo obturador.
- **Encurtamento aproximado:** Posição combinada compatível com adução da anca, flexão do joelho e rotação interna da perna com o joelho fletido; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com abdução da anca e extensão do joelho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode perder capacidade quando adução da anca e flexão do joelho o encurtam simultaneamente. Abdução da anca combinada com extensão do joelho pode aumentar a tensão passiva.
- **Mecânica:** A tração relativamente à anca sustenta adução da anca, flexão do joelho e rotação interna da perna com o joelho fletido, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000654, claim_000655, claim_000656, claim_000657, claim_000658, claim_000659, claim_000660

### Relações músculo-ação

- `hip_adduction` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_flexion` em `knee_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de knee_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_internal_rotation` em `knee_joint`: `secondary_or_contextual_contributor`. A rotação axial da perna torna-se mecanicamente relevante sobretudo com o joelho fletido. Pode produzir ou assistir rotação interna da perna no joelho fletido quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Ilíaco (`iliacus`)

- **Latim / inglês:** musculus iliacus / iliacus
- **Região / grupo / camada:** `hip` / `iliopsoas` / `deep`
- **Origem:** Fossa ilíaca, asa do sacro e ligamentos sacroilíacos anteriores.
- **Inserção:** Tendão do psoas maior e trocânter menor.
- **Arquitetura e fibras:** `fan_shaped`. Fibras em leque convergem entre uma fixação ampla e outra mais concentrada.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo femoral.
- **Encurtamento aproximado:** Posição combinada compatível com flexão da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta flexão da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000664, claim_000665, claim_000666, claim_000667, claim_000668, claim_000669

### Relações músculo-ação

- `hip_flexion` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Gémeo inferior (`inferior_gemellus`)

- **Latim / inglês:** musculus gemellus inferior / inferior gemellus
- **Região / grupo / camada:** `hip` / `deep_hip_rotators` / `deep`
- **Origem:** Tuberosidade isquiática.
- **Inserção:** Com o tendão do obturador interno na face medial do trocânter maior.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo do quadrado femoral.
- **Encurtamento aproximado:** Posição combinada compatível com rotação externa da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com rotação interna da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta rotação externa da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000711, claim_000712, claim_000713, claim_000714, claim_000715, claim_000716

### Relações músculo-ação

- `hip_external_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A linha de ação rotacional pode mudar com a flexão da anca; não se fixa um limiar universal. Pode produzir ou assistir rotação externa da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Primeiro lumbrical do pé (`lumbrical_foot_1`)

- **Latim / inglês:** musculus lumbricalis pedis I / first lumbrical of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Face medial do tendão do flexor longo destinado ao dedo II.
- **Inserção:** Margem medial da expansão extensora do dedo II.
- **Arquitetura e fibras:** `fusiform_set`. Conjunto de pequenos ventres fusiformes, cada um associado ao respetivo raio digital.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo plantar medial.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000874, claim_000875, claim_000876, claim_000877, claim_000878, claim_000879, claim_000880, claim_000881

### Relações músculo-ação

- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Segundo lumbrical do pé (`lumbrical_foot_2`)

- **Latim / inglês:** musculus lumbricalis pedis II / second lumbrical of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Faces adjacentes dos tendões do flexor longo destinados aos dedos II e III.
- **Inserção:** Margem medial da expansão extensora do dedo III.
- **Arquitetura e fibras:** `fusiform_set`. Conjunto de pequenos ventres fusiformes, cada um associado ao respetivo raio digital.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000885, claim_000886, claim_000887, claim_000888, claim_000889, claim_000890, claim_000891, claim_000892

### Relações músculo-ação

- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Terceiro lumbrical do pé (`lumbrical_foot_3`)

- **Latim / inglês:** musculus lumbricalis pedis III / third lumbrical of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Faces adjacentes dos tendões do flexor longo destinados aos dedos III e IV.
- **Inserção:** Margem medial da expansão extensora do dedo IV.
- **Arquitetura e fibras:** `fusiform_set`. Conjunto de pequenos ventres fusiformes, cada um associado ao respetivo raio digital.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000896, claim_000897, claim_000898, claim_000899, claim_000900, claim_000901, claim_000902, claim_000903

### Relações músculo-ação

- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Quarto lumbrical do pé (`lumbrical_foot_4`)

- **Latim / inglês:** musculus lumbricalis pedis IV / fourth lumbrical of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Faces adjacentes dos tendões do flexor longo destinados aos dedos IV e V.
- **Inserção:** Margem medial da expansão extensora do dedo V.
- **Arquitetura e fibras:** `fusiform_set`. Conjunto de pequenos ventres fusiformes, cada um associado ao respetivo raio digital.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000907, claim_000908, claim_000909, claim_000910, claim_000911, claim_000912, claim_000913, claim_000914

### Relações músculo-ação

- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Obturador externo (`obturator_externus`)

- **Latim / inglês:** musculus obturatorius externus / obturator externus
- **Região / grupo / camada:** `hip` / `deep_hip_rotators` / `deep`
- **Origem:** Face externa da membrana obturadora e margens do forame.
- **Inserção:** Fossa trocantérica.
- **Arquitetura e fibras:** `fan_shaped`. Fibras em leque convergem entre uma fixação ampla e outra mais concentrada.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo obturador.
- **Encurtamento aproximado:** Posição combinada compatível com rotação externa da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com rotação interna da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta rotação externa da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001001, claim_001002, claim_001003, claim_001004, claim_001005, claim_001006

### Relações músculo-ação

- `hip_external_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação externa da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Obturador interno (`obturator_internus`)

- **Latim / inglês:** musculus obturatorius internus / obturator internus
- **Região / grupo / camada:** `hip` / `deep_hip_rotators` / `deep`
- **Origem:** Face pélvica da membrana obturadora e ossos adjacentes.
- **Inserção:** Face medial do trocânter maior.
- **Arquitetura e fibras:** `fan_shaped`. Fibras em leque convergem entre uma fixação ampla e outra mais concentrada.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo do obturador interno.
- **Encurtamento aproximado:** Posição combinada compatível com rotação externa da anca e abdução da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com rotação interna da anca e adução da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta rotação externa da anca e abdução da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001008, claim_001009, claim_001010, claim_001011, claim_001012, claim_001013

### Relações músculo-ação

- `hip_external_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A linha de ação rotacional pode mudar com a flexão da anca; não se fixa um limiar universal. Pode produzir ou assistir rotação externa da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_abduction` em `hip_joint`: `secondary_or_contextual_contributor`. A linha de ação rotacional pode mudar com a flexão da anca; não se fixa um limiar universal. Pode produzir ou assistir abdução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Pectíneo (`pectineus`)

- **Latim / inglês:** musculus pectineus / pectineus
- **Região / grupo / camada:** `thigh` / `thigh_adductors` / `superficial`
- **Origem:** Pecten do púbis.
- **Inserção:** Linha pectínea do fémur.
- **Arquitetura e fibras:** `flat_quadrangular`. Fascículos planos formam uma lâmina aproximadamente quadrangular.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo femoral; contribuição obturadora variável.
- **Encurtamento aproximado:** Posição combinada compatível com adução da anca, flexão da anca e rotação interna da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com abdução da anca, extensão da anca e rotação externa da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta adução da anca, flexão da anca e rotação interna da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001081, claim_001082, claim_001083, claim_001084, claim_001085, claim_001086

### Relações músculo-ação

- `hip_adduction` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_flexion` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_internal_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação interna da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Piriforme (`piriformis`)

- **Latim / inglês:** musculus piriformis / piriformis
- **Região / grupo / camada:** `hip` / `deep_hip_rotators` / `deep`
- **Origem:** Face anterior do sacro.
- **Inserção:** Bordo superior do trocânter maior.
- **Arquitetura e fibras:** `pyramidal`. A orientação é inferida qualitativamente das fixações e da arquitetura registadas; não foi quantificada como uma direção universal.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo do piriforme.
- **Encurtamento aproximado:** Posição combinada compatível com rotação externa da anca e abdução da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com rotação interna da anca e adução da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta rotação externa da anca e abdução da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A linha de ação muda com a flexão da anca; relações com o nervo ciático apresentam variação anatómica.
- **Claims:** claim_001109, claim_001110, claim_001111, claim_001112, claim_001113, claim_001114, claim_001115

### Relações músculo-ação

- `hip_external_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A linha de ação rotacional pode mudar com a flexão da anca; não se fixa um limiar universal. Pode produzir ou assistir rotação externa da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_abduction` em `hip_joint`: `secondary_or_contextual_contributor`. A linha de ação rotacional pode mudar com a flexão da anca; não se fixa um limiar universal. Pode produzir ou assistir abdução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Primeiro interósseo plantar do pé (`plantar_interosseous_foot_1`)

- **Latim / inglês:** musculus interosseus plantaris pedis I / first plantar interosseous of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Face medial do metatársico III.
- **Inserção:** Base medial da falange proximal do dedo III e expansão extensora do dedo correspondente.
- **Arquitetura e fibras:** `unipennate_set`. Conjunto de músculos unipenados com orientação específica por raio digital.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com adução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com adução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001118, claim_001119, claim_001120, claim_001121, claim_001122, claim_001123, claim_001124, claim_001125

### Relações músculo-ação

- `lesser_toe_mtp_adduction` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Segundo interósseo plantar do pé (`plantar_interosseous_foot_2`)

- **Latim / inglês:** musculus interosseus plantaris pedis II / second plantar interosseous of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Face medial do metatársico IV.
- **Inserção:** Base medial da falange proximal do dedo IV e expansão extensora do dedo correspondente.
- **Arquitetura e fibras:** `unipennate_set`. Conjunto de músculos unipenados com orientação específica por raio digital.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com adução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com adução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001130, claim_001131, claim_001132, claim_001133, claim_001134, claim_001135, claim_001136, claim_001137

### Relações músculo-ação

- `lesser_toe_mtp_adduction` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Terceiro interósseo plantar do pé (`plantar_interosseous_foot_3`)

- **Latim / inglês:** musculus interosseus plantaris pedis III / third plantar interosseous of foot
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Face medial do metatársico V.
- **Inserção:** Base medial da falange proximal do dedo V e expansão extensora do dedo correspondente.
- **Arquitetura e fibras:** `unipennate_set`. Conjunto de músculos unipenados com orientação específica por raio digital.
- **Articulações e classe:** lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo plantar lateral.
- **Encurtamento aproximado:** Combinação digital compatível com adução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints, em posições compatíveis com adução metatarsofalângica dos dedos II–V, flexão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações lesser_toe_metatarsophalangeal_joints, lesser_toe_proximal_interphalangeal_joints, lesser_toe_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital determinam a direção; músculos extrínsecos e intrínsecos não são equivalentes. Varia com a articulação, dedo e posição do pé; não foi agregado num único valor. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001142, claim_001143, claim_001144, claim_001145, claim_001146, claim_001147, claim_001148, claim_001149

### Relações músculo-ação

- `lesser_toe_mtp_adduction` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_mtp_flexion` em `lesser_toe_metatarsophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_metatarsophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metatarsofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_pip_extension` em `lesser_toe_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `lesser_toe_dip_extension` em `lesser_toe_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lesser_toe_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Plantar (`plantaris`)

- **Latim / inglês:** musculus plantaris / plantaris
- **Região / grupo / camada:** `leg` / `posterior_leg_superficial` / `deep`
- **Origem:** Linha supracondilar lateral do fémur.
- **Inserção:** Calcâneo, geralmente medial ao tendão calcaneano.
- **Arquitetura e fibras:** `small_fusiform_long_tendon`. Pequeno ventre fusiforme continua num tendão longo; a presença e o desenvolvimento variam.
- **Articulações e classe:** knee_joint, talocrural_joint; `biarticular`
- **Inervação:** Nervo tibial.
- **Encurtamento aproximado:** Posição combinada compatível com flexão do joelho e flexão plantar; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão do joelho e dorsiflexão; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** A pequena contribuição ativa pode diminuir quando joelho e tornozelo o encurtam simultaneamente. A extensão do joelho combinada com dorsiflexão pode aumentar a tensão passiva; a presença e o desenvolvimento variam.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta flexão do joelho e flexão plantar conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Ausente numa fração relevante da população; morfologia muito variável. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001154, claim_001155, claim_001156, claim_001157, claim_001158, claim_001159, claim_001160, claim_001161

### Relações músculo-ação

- `knee_flexion` em `knee_joint`: `weak_variable_contributor`. A contribuição varia ao longo de knee_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `ankle_plantarflexion` em `talocrural_joint`: `weak_variable_contributor`. A contribuição varia ao longo de talocrural_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão plantar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Poplíteo (`popliteus`)

- **Latim / inglês:** musculus popliteus / popliteus
- **Região / grupo / camada:** `knee` / `posterior_knee_muscles` / `deep`
- **Origem:** Côndilo lateral do fémur e menisco lateral.
- **Inserção:** Tíbia posterior acima da linha do sóleo.
- **Arquitetura e fibras:** `triangular`. Fibras dispõem-se numa unidade triangular entre fixações de larguras diferentes.
- **Articulações e classe:** knee_joint; `monoarticular`
- **Inervação:** Nervo tibial.
- **Encurtamento aproximado:** Posição combinada compatível com flexão do joelho e rotação interna da perna com o joelho fletido; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão do joelho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta flexão do joelho e rotação interna da perna com o joelho fletido conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. Participa no desbloqueio e controlo rotacional do joelho; não é alvo de isolamento prático absoluto.
- **Claims:** claim_001164, claim_001165, claim_001166, claim_001167, claim_001168, claim_001169, claim_001170

### Relações músculo-ação

- `knee_flexion` em `knee_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de knee_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_internal_rotation` em `knee_joint`: `principal_contextual_contributor`. A rotação axial da perna torna-se mecanicamente relevante sobretudo com o joelho fletido. Pode produzir ou assistir rotação interna da perna no joelho fletido quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Psoas maior (`psoas_major`)

- **Latim / inglês:** musculus psoas major / psoas major
- **Região / grupo / camada:** `hip` / `iliopsoas` / `deep`
- **Origem:** Corpos, discos e processos transversos T12–L5.
- **Inserção:** Trocânter menor através do tendão iliopsoas.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** lumbosacral_spine, hip_joint; `biarticular`
- **Inervação:** Ramos anteriores L1–L3.
- **Encurtamento aproximado:** Posição axial compatível com flexão da anca e flexão lateral do tronco, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração relativamente à anca sustenta flexão da anca e flexão lateral do tronco, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. Com o fémur livre contribui para flexão da anca; com o fémur fixo pode influenciar o tronco e a coluna lombar.
- **Claims:** claim_001200, claim_001201, claim_001202, claim_001203, claim_001204, claim_001205, claim_001206, claim_001207

### Relações músculo-ação

- `hip_flexion` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_lateral_flexion` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Quadrado femoral (`quadratus_femoris`)

- **Latim / inglês:** musculus quadratus femoris / quadratus femoris
- **Região / grupo / camada:** `hip` / `deep_hip_rotators` / `deep`
- **Origem:** Bordo lateral da tuberosidade isquiática.
- **Inserção:** Tubérculo quadrado da crista intertrocantérica.
- **Arquitetura e fibras:** `quadrate`. Fascículos curtos formam uma unidade quadrangular.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo do quadrado femoral.
- **Encurtamento aproximado:** Posição combinada compatível com rotação externa da anca e adução da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com rotação interna da anca e abdução da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta rotação externa da anca e adução da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001266, claim_001267, claim_001268, claim_001269, claim_001270, claim_001271

### Relações músculo-ação

- `hip_external_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação externa da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_adduction` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Quadrado plantar (`quadratus_plantae`)

- **Latim / inglês:** musculus quadratus plantae / quadratus plantae
- **Região / grupo / camada:** `ankle_foot` / `intrinsic_foot_plantar` / `deep`
- **Origem:** Faces medial e lateral do calcâneo.
- **Inserção:** Margem posterolateral do tendão do flexor longo dos dedos.
- **Arquitetura e fibras:** `quadrate`. Fascículos plantares convergem para o tendão do flexor longo dos dedos, em vez de atravessarem diretamente as articulações digitais.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo plantar lateral.
- **Encurtamento aproximado:** Depende da tensão do flexor longo dos dedos e da forma do arco plantar; não decorre diretamente de uma combinação de ângulos digitais.
- **Alongamento aproximado:** Depende da excursão do tendão do flexor longo dos dedos e da deformação do pé sob carga.
- **Insuficiência ativa/passiva:** Não aplicável como músculo que atravesse diretamente as articulações dos dedos. Não aplicável como insuficiência digital direta; a transmissão ocorre pelo tendão associado.
- **Mecânica:** A tração converge para o tendão do flexor longo dos dedos e modifica a sua direção resultante. Não se atribui braço de momento digital direto porque não atravessa diretamente as articulações dos dedos. A força transmitida depende da tensão do flexor longo dos dedos, da excursão tendinosa e da deformação do arco plantar.
- **Cadeia aberta/fechada:** Modula a tração do flexor longo dos dedos através do tendão, sem cruzar diretamente as articulações digitais. Com o pé apoiado, participa na função flexora e no controlo plantar através do sistema tendinoso e do arco.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001284, claim_001285, claim_001286, claim_001287, claim_001288

### Relações músculo-ação

- `flexor_tendon_redirection` em ``: `regulator_or_stabilizer`. Depende da tensão e excursão do tendão do flexor longo dos dedos e da configuração do arco plantar. A contração pode modificar a direção resultante da tração do flexor longo dos dedos através da ligação tendinosa. O controlo durante excursão tendinosa oposta é plausível, mas não foi caracterizado como ação digital direta.

## Reto femoral (`rectus_femoris`)

- **Latim / inglês:** musculus rectus femoris / rectus femoris
- **Região / grupo / camada:** `thigh` / `quadriceps_femoris` / `superficial`
- **Origem:** Espinha ilíaca anteroinferior e margem superior do acetábulo.
- **Inserção:** Patela e tuberosidade da tíbia através do ligamento patelar.
- **Arquitetura e fibras:** `bipennate`. Fascículos oblíquos inserem-se nos dois lados de um tendão central.
- **Articulações e classe:** hip_joint, knee_joint; `biarticular`
- **Inervação:** Nervo femoral.
- **Encurtamento aproximado:** Posição combinada compatível com flexão da anca e extensão do joelho; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão da anca e flexão do joelho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** A combinação de flexão da anca e extensão do joelho pode encurtá-lo nas duas articulações e reduzir a capacidade ativa. A extensão da anca combinada com flexão do joelho pode aumentar a tensão passiva.
- **Mecânica:** A tração relativamente à anca sustenta flexão da anca e extensão do joelho, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. Biarticular: a posição da anca altera o comprimento disponível e a contribuição no joelho.
- **Claims:** claim_001335, claim_001336, claim_001337, claim_001338, claim_001339, claim_001340, claim_001341

### Relações músculo-ação

- `hip_flexion` em `hip_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: hip_joint. Pode produzir ou assistir flexão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_extension` em `knee_joint`: `principal_contributor`. O papel depende da posição combinada das articulações: knee_joint. Pode produzir ou assistir extensão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Sartório (`sartorius`)

- **Latim / inglês:** musculus sartorius / sartorius
- **Região / grupo / camada:** `thigh` / `anterior_thigh_other` / `superficial`
- **Origem:** Espinha ilíaca anterossuperior.
- **Inserção:** Face medial da tíbia proximal, na pata de ganso.
- **Arquitetura e fibras:** `strap`. A orientação é inferida qualitativamente das fixações e da arquitetura registadas; não foi quantificada como uma direção universal.
- **Articulações e classe:** hip_joint, knee_joint; `biarticular`
- **Inervação:** Nervo femoral.
- **Encurtamento aproximado:** Posição combinada compatível com flexão da anca, abdução da anca, rotação externa da anca, flexão do joelho e rotação interna da perna com o joelho fletido; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão da anca, adução da anca, rotação interna da anca e extensão do joelho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode perder capacidade quando as ações combinadas da anca e do joelho o encurtam simultaneamente. A combinação oposta de posições da anca e extensão do joelho pode aumentar a tensão passiva.
- **Mecânica:** A tração relativamente à anca sustenta flexão da anca, abdução da anca, rotação externa da anca, flexão do joelho e rotação interna da perna com o joelho fletido, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001380, claim_001381, claim_001382, claim_001383, claim_001384, claim_001385, claim_001386

### Relações músculo-ação

- `hip_flexion` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_abduction` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_external_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação externa da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_flexion` em `knee_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de knee_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_internal_rotation` em `knee_joint`: `secondary_or_contextual_contributor`. A rotação axial da perna torna-se mecanicamente relevante sobretudo com o joelho fletido. Pode produzir ou assistir rotação interna da perna no joelho fletido quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Semimembranoso (`semimembranosus`)

- **Latim / inglês:** musculus semimembranosus / semimembranosus
- **Região / grupo / camada:** `thigh` / `hamstrings` / `deep`
- **Origem:** Tuberosidade isquiática.
- **Inserção:** Côndilo medial posterior da tíbia e expansão capsular.
- **Arquitetura e fibras:** `flat_tendon`. A orientação é inferida qualitativamente das fixações e da arquitetura registadas; não foi quantificada como uma direção universal.
- **Articulações e classe:** hip_joint, knee_joint; `biarticular`
- **Inervação:** Divisão tibial do nervo ciático.
- **Encurtamento aproximado:** Posição combinada compatível com extensão da anca, flexão do joelho e rotação interna da perna com o joelho fletido; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão da anca e extensão do joelho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode perder capacidade quando a anca está estendida e o joelho fletido em simultâneo. A flexão da anca combinada com extensão do joelho pode aumentar a tensão passiva.
- **Mecânica:** A tração relativamente à anca sustenta extensão da anca, flexão do joelho e rotação interna da perna com o joelho fletido, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001402, claim_001403, claim_001404, claim_001405, claim_001406, claim_001407, claim_001408

### Relações músculo-ação

- `hip_extension` em `hip_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: hip_joint. Pode produzir ou assistir extensão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_flexion` em `knee_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: knee_joint. Pode produzir ou assistir flexão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_internal_rotation` em `knee_joint`: `secondary_or_contextual_contributor`. A rotação axial da perna torna-se mecanicamente relevante sobretudo com o joelho fletido. Pode produzir ou assistir rotação interna da perna no joelho fletido quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Semitendinoso (`semitendinosus`)

- **Latim / inglês:** musculus semitendinosus / semitendinosus
- **Região / grupo / camada:** `thigh` / `hamstrings` / `superficial`
- **Origem:** Tuberosidade isquiática.
- **Inserção:** Face medial da tíbia proximal, na pata de ganso.
- **Arquitetura e fibras:** `fusiform_long_tendon`. Ventre fusiforme continua num tendão longo, que condiciona transmissão e excursão.
- **Articulações e classe:** hip_joint, knee_joint; `biarticular`
- **Inervação:** Divisão tibial do nervo ciático.
- **Encurtamento aproximado:** Posição combinada compatível com extensão da anca, flexão do joelho e rotação interna da perna com o joelho fletido; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão da anca e extensão do joelho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode perder capacidade quando a anca está estendida e o joelho fletido em simultâneo. A flexão da anca combinada com extensão do joelho pode aumentar a tensão passiva.
- **Mecânica:** A tração relativamente à anca sustenta extensão da anca, flexão do joelho e rotação interna da perna com o joelho fletido, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001442, claim_001443, claim_001444, claim_001445, claim_001446, claim_001447, claim_001448

### Relações músculo-ação

- `hip_extension` em `hip_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: hip_joint. Pode produzir ou assistir extensão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_flexion` em `knee_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: knee_joint. Pode produzir ou assistir flexão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `knee_internal_rotation` em `knee_joint`: `secondary_or_contextual_contributor`. A rotação axial da perna torna-se mecanicamente relevante sobretudo com o joelho fletido. Pode produzir ou assistir rotação interna da perna no joelho fletido quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Sóleo (`soleus`)

- **Latim / inglês:** musculus soleus / soleus
- **Região / grupo / camada:** `leg` / `posterior_leg_superficial` / `deep`
- **Origem:** Cabeça e face posterior da fíbula, linha do sóleo e tíbia medial.
- **Inserção:** Calcâneo através do tendão calcaneano.
- **Arquitetura e fibras:** `multipennate`. Múltiplos conjuntos de fascículos oblíquos inserem-se em septos ou tendões internos.
- **Articulações e classe:** talocrural_joint; `monoarticular`
- **Inervação:** Nervo tibial.
- **Encurtamento aproximado:** Posição combinada compatível com flexão plantar; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com dorsiflexão; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta flexão plantar conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001478, claim_001479, claim_001480, claim_001481, claim_001482, claim_001483

### Relações músculo-ação

- `ankle_plantarflexion` em `talocrural_joint`: `principal_contributor`. A contribuição varia ao longo de talocrural_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão plantar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Gémeo superior (`superior_gemellus`)

- **Latim / inglês:** musculus gemellus superior / superior gemellus
- **Região / grupo / camada:** `hip` / `deep_hip_rotators` / `deep`
- **Origem:** Espinha isquiática.
- **Inserção:** Com o tendão do obturador interno na face medial do trocânter maior.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** hip_joint; `monoarticular`
- **Inervação:** Nervo do obturador interno.
- **Encurtamento aproximado:** Posição combinada compatível com rotação externa da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com rotação interna da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta rotação externa da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001575, claim_001576, claim_001577, claim_001578, claim_001579, claim_001580

### Relações músculo-ação

- `hip_external_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A linha de ação rotacional pode mudar com a flexão da anca; não se fixa um limiar universal. Pode produzir ou assistir rotação externa da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Tensor da fáscia lata (`tensor_fasciae_latae`)

- **Latim / inglês:** musculus tensor fasciae latae / tensor fasciae latae
- **Região / grupo / camada:** `pelvic_girdle_gluteal` / `lateral_hip_muscles` / `superficial`
- **Origem:** Espinha ilíaca anterossuperior e crista ilíaca anterior.
- **Inserção:** Trato iliotibial até ao côndilo lateral da tíbia.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** hip_joint, knee_joint; `biarticular`
- **Inervação:** Nervo glúteo superior.
- **Encurtamento aproximado:** Posição combinada compatível com flexão da anca, abdução da anca e rotação interna da anca; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão da anca, adução da anca e rotação externa da anca; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de hip_joint, knee_joint, em posições compatíveis com flexão da anca, abdução da anca e rotação interna da anca. Pode ocorrer quando as articulações hip_joint, knee_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A tração relativamente à anca sustenta flexão da anca, abdução da anca e rotação interna da anca, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001597, claim_001598, claim_001599, claim_001600, claim_001601, claim_001602, claim_001603

### Relações músculo-ação

- `hip_flexion` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_abduction` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `hip_internal_rotation` em `hip_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de hip_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação interna da anca quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Tibial anterior (`tibialis_anterior`)

- **Latim / inglês:** musculus tibialis anterior / tibialis anterior
- **Região / grupo / camada:** `leg` / `anterior_leg` / `superficial`
- **Origem:** Côndilo lateral e metade superior da tíbia, membrana interóssea.
- **Inserção:** Cuneiforme medial e base do metatársico I.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** talocrural_joint, subtalar_joint, transverse_tarsal_joint; `multiarticular`
- **Inervação:** Nervo fibular profundo.
- **Encurtamento aproximado:** Posição combinada compatível com dorsiflexão e inversão do pé; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão plantar e eversão do pé; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de talocrural_joint, subtalar_joint, transverse_tarsal_joint, em posições compatíveis com dorsiflexão e inversão do pé. Pode ocorrer quando as articulações talocrural_joint, subtalar_joint, transverse_tarsal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta dorsiflexão e inversão do pé conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001625, claim_001626, claim_001627, claim_001628, claim_001629, claim_001630, claim_001631, claim_001632

### Relações músculo-ação

- `ankle_dorsiflexion` em `talocrural_joint`: `principal_contributor`. A contribuição varia ao longo de talocrural_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir dorsiflexão quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `foot_inversion` em `subtalar_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de subtalar_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir inversão do pé quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Tibial posterior (`tibialis_posterior`)

- **Latim / inglês:** musculus tibialis posterior / tibialis posterior
- **Região / grupo / camada:** `leg` / `posterior_leg_deep` / `deep`
- **Origem:** Membrana interóssea e faces posteriores da tíbia e fíbula.
- **Inserção:** Navicular, cuneiformes, cuboide e bases metatársicas médias.
- **Arquitetura e fibras:** `pennate`. Fascículos oblíquos inserem-se num tendão ou aponeurose.
- **Articulações e classe:** talocrural_joint, subtalar_joint, transverse_tarsal_joint; `multiarticular`
- **Inervação:** Nervo tibial.
- **Encurtamento aproximado:** Posição combinada compatível com flexão plantar e inversão do pé; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com dorsiflexão e eversão do pé; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de talocrural_joint, subtalar_joint, transverse_tarsal_joint, em posições compatíveis com flexão plantar e inversão do pé. Pode ocorrer quando as articulações talocrural_joint, subtalar_joint, transverse_tarsal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A tração relativamente ao joelho ou tornozelo sustenta flexão plantar e inversão do pé conforme as articulações atravessadas. Muda com flexão articular e com a trajetória tendinosa; não foi fixado um máximo. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001635, claim_001636, claim_001637, claim_001638, claim_001639, claim_001640, claim_001641, claim_001642

### Relações músculo-ação

- `ankle_plantarflexion` em `talocrural_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de talocrural_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão plantar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `foot_inversion` em `subtalar_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de subtalar_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir inversão do pé quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Vasto intermédio (`vastus_intermedius`)

- **Latim / inglês:** musculus vastus intermedius / vastus intermedius
- **Região / grupo / camada:** `thigh` / `quadriceps_femoris` / `deep`
- **Origem:** Faces anterior e lateral do corpo do fémur.
- **Inserção:** Patela e tuberosidade da tíbia através do aparelho extensor.
- **Arquitetura e fibras:** `unipennate`. Fascículos oblíquos inserem-se num lado do tendão.
- **Articulações e classe:** knee_joint; `monoarticular`
- **Inervação:** Nervo femoral.
- **Encurtamento aproximado:** Posição combinada compatível com extensão do joelho; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão do joelho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta extensão do joelho, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001685, claim_001686, claim_001687, claim_001688, claim_001689, claim_001690

### Relações músculo-ação

- `knee_extension` em `knee_joint`: `principal_contributor`. A contribuição varia ao longo de knee_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Vasto lateral (`vastus_lateralis`)

- **Latim / inglês:** musculus vastus lateralis / vastus lateralis
- **Região / grupo / camada:** `thigh` / `quadriceps_femoris` / `superficial`
- **Origem:** Trocânter maior e lábio lateral da linha áspera.
- **Inserção:** Patela e tuberosidade da tíbia através do aparelho extensor.
- **Arquitetura e fibras:** `unipennate`. Fascículos oblíquos inserem-se num lado do tendão.
- **Articulações e classe:** knee_joint; `monoarticular`
- **Inervação:** Nervo femoral.
- **Encurtamento aproximado:** Posição combinada compatível com extensão do joelho; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão do joelho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta extensão do joelho, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001692, claim_001693, claim_001694, claim_001695, claim_001696, claim_001697

### Relações músculo-ação

- `knee_extension` em `knee_joint`: `principal_contributor`. A contribuição varia ao longo de knee_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Vasto medial (`vastus_medialis`)

- **Latim / inglês:** musculus vastus medialis / vastus medialis
- **Região / grupo / camada:** `thigh` / `quadriceps_femoris` / `superficial`
- **Origem:** Linha intertrocantérica e lábio medial da linha áspera.
- **Inserção:** Patela e tuberosidade da tíbia através do aparelho extensor.
- **Arquitetura e fibras:** `unipennate`. Fascículos oblíquos inserem-se num lado do tendão.
- **Articulações e classe:** knee_joint; `monoarticular`
- **Inervação:** Nervo femoral.
- **Encurtamento aproximado:** Posição combinada compatível com extensão do joelho; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão do joelho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração relativamente à anca sustenta extensão do joelho, mas pode mudar com flexão, rotação e orientação pélvica. Pode mudar com a posição da anca e entre porções; não foi aprovado um máximo universal. A capacidade depende da combinação articular, comprimento, velocidade, transmissão tendinosa e reação do solo quando existe apoio.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla o segmento distal nas articulações efetivamente atravessadas. Com o pé fixo, pode controlar pelve, fémur, tíbia ou pé e contribuir para rigidez e transferência de força.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A porção distal oblíqua contribui para o controlo patelar, mas não deve ser tratada como músculo isolável universalmente.
- **Claims:** claim_001699, claim_001700, claim_001701, claim_001702, claim_001703, claim_001704

### Relações músculo-ação

- `knee_extension` em `knee_joint`: `principal_contributor`. A contribuição varia ao longo de knee_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do joelho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
