#!/usr/bin/env python3
"""Independent, read-only validator for EveFit Muscular KB v0.1.1."""

from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
import unicodedata
import zipfile
from collections import Counter, defaultdict
from itertools import permutations
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXPORTS = ROOT / "13_EXPORTS"
SCHEMAS = EXPORTS / "schemas"
ID_RE = re.compile(r"^[a-z][a-z0-9]*(?:_[a-z0-9]+)*$")
TRAIN_STATES = {
    "supported",
    "plausible_inference",
    "not_applicable",
    "insufficient_evidence",
    "specialist_only",
}
FUNCTIONAL_ACTIONS = {
    "inspiration",
    "forced_expiration",
    "intra_abdominal_pressure_regulation",
    "pelvic_floor_elevation",
    "perineal_support_and_compression",
    "erectile_tissue_compression",
    "anal_sphincter_constriction",
    "hypothenar_skin_tension",
    "linea_alba_tension",
    "flexor_tendon_redirection",
    "elbow_capsular_retraction",
    "knee_capsular_retraction",
    "foot_arch_control",
    "respiratory_pelvic_floor_coordination",
}
DIGITAL_ACTIONS = {
    "finger_mcp_flexion",
    "finger_mcp_extension",
    "finger_mcp_abduction",
    "finger_mcp_adduction",
    "finger_pip_flexion",
    "finger_pip_extension",
    "finger_dip_flexion",
    "finger_dip_extension",
    "lesser_toe_mtp_flexion",
    "lesser_toe_mtp_extension",
    "lesser_toe_mtp_abduction",
    "lesser_toe_mtp_adduction",
    "lesser_toe_pip_flexion",
    "lesser_toe_pip_extension",
    "lesser_toe_dip_flexion",
    "lesser_toe_dip_extension",
}
PUBLIC_DESCRIPTION_ACTION_LIMIT = 3
PUBLIC_ROLE_PRIORITY = {
    "principal_contributor": 0,
    "principal_contextual_contributor": 1,
    "secondary_or_contextual_contributor": 2,
    "regulator_or_stabilizer": 3,
    "capsular_retractor": 4,
    "weak_variable_contributor": 5,
}
PUBLIC_DESCRIPTION_ACTION_PRIORITY = {
    "deltoid": ("shoulder_abduction", "shoulder_flexion", "shoulder_extension", "shoulder_horizontal_abduction", "shoulder_horizontal_adduction"),
    "extensor_digiti_minimi": ("finger_mcp_extension", "finger_pip_extension", "finger_dip_extension", "wrist_extension"),
    "extensor_digitorum": ("finger_mcp_extension", "finger_pip_extension", "finger_dip_extension", "wrist_extension"),
    "extensor_digitorum_longus": ("lesser_toe_mtp_extension", "lesser_toe_pip_extension", "lesser_toe_dip_extension", "ankle_dorsiflexion", "foot_eversion"),
    "extensor_indicis": ("finger_mcp_extension", "finger_pip_extension", "finger_dip_extension", "wrist_extension"),
    "extensor_pollicis_longus": ("thumb_ip_extension", "thumb_mcp_extension", "thumb_cmc_extension", "wrist_extension"),
    "external_oblique": ("trunk_flexion", "trunk_lateral_flexion", "trunk_rotation", "forced_expiration", "intra_abdominal_pressure_regulation"),
    "flexor_digitorum_longus": ("lesser_toe_dip_flexion", "lesser_toe_pip_flexion", "lesser_toe_mtp_flexion", "ankle_plantarflexion", "foot_inversion"),
    "flexor_digitorum_profundus": ("finger_dip_flexion", "finger_pip_flexion", "finger_mcp_flexion", "wrist_flexion"),
    "flexor_digitorum_superficialis": ("finger_pip_flexion", "finger_mcp_flexion", "wrist_flexion", "elbow_flexion"),
    "flexor_hallucis_longus": ("hallux_ip_flexion", "hallux_mtp_flexion", "ankle_plantarflexion", "foot_inversion"),
    "flexor_pollicis_longus": ("thumb_ip_flexion", "thumb_mcp_flexion", "thumb_cmc_flexion", "wrist_flexion"),
    "internal_oblique": ("trunk_flexion", "trunk_lateral_flexion", "trunk_rotation", "forced_expiration", "intra_abdominal_pressure_regulation"),
    "pectoralis_major": ("shoulder_horizontal_adduction", "shoulder_adduction", "shoulder_internal_rotation", "shoulder_flexion"),
    "sartorius": ("hip_flexion", "hip_abduction", "hip_external_rotation", "knee_flexion", "knee_internal_rotation"),
    "trapezius": ("scapular_elevation", "scapular_retraction", "scapular_upward_rotation", "scapular_depression"),
}
PUBLIC_ACTION_LABEL_OVERRIDES = {
    ("extensor_digiti_minimi", "finger_mcp_extension"): "extensão metacarpofalângica do dedo V",
    ("extensor_digiti_minimi", "finger_pip_extension"): "extensão interfalângica proximal do dedo V",
    ("extensor_digiti_minimi", "finger_dip_extension"): "extensão interfalângica distal do dedo V",
    ("extensor_indicis", "finger_mcp_extension"): "extensão metacarpofalângica do dedo II",
    ("extensor_indicis", "finger_pip_extension"): "extensão interfalângica proximal do dedo II",
    ("extensor_indicis", "finger_dip_extension"): "extensão interfalângica distal do dedo II",
}
CURATED_PRIMARY_RELATIONS = {
    ("brachialis", "elbow_flexion"),
    ("triceps_brachii", "elbow_extension"),
    ("pronator_quadratus", "forearm_pronation"),
    ("supinator", "forearm_supination"),
    ("deltoid", "shoulder_abduction"),
    ("pectoralis_major", "shoulder_horizontal_adduction"),
    ("latissimus_dorsi", "shoulder_extension"),
    ("gluteus_maximus", "hip_extension"),
    ("gluteus_medius", "hip_abduction"),
    ("adductor_longus", "hip_adduction"),
    ("adductor_magnus", "hip_adduction"),
    ("rectus_femoris", "knee_extension"),
    ("vastus_lateralis", "knee_extension"),
    ("vastus_medialis", "knee_extension"),
    ("vastus_intermedius", "knee_extension"),
    ("tibialis_anterior", "ankle_dorsiflexion"),
    ("gastrocnemius", "ankle_plantarflexion"),
    ("soleus", "ankle_plantarflexion"),
    ("rectus_abdominis", "trunk_flexion"),
    ("diaphragm", "inspiration"),
    ("flexor_digitorum_superficialis", "finger_pip_flexion"),
    ("flexor_digitorum_profundus", "finger_dip_flexion"),
    ("flexor_digitorum_brevis", "lesser_toe_pip_flexion"),
    ("flexor_digitorum_longus", "lesser_toe_dip_flexion"),
    ("flexor_pollicis_longus", "thumb_ip_flexion"),
    ("extensor_pollicis_longus", "thumb_ip_extension"),
    ("flexor_hallucis_longus", "hallux_ip_flexion"),
    ("extensor_hallucis_longus", "hallux_ip_extension"),
}
ACTION_JOINT_ALLOWED = {
    **{action: {"scapulothoracic_articulation"} for action in {
        "scapular_elevation", "scapular_depression", "scapular_protraction",
        "scapular_retraction", "scapular_upward_rotation", "scapular_downward_rotation",
    }},
    "clavicular_depression": {"sternoclavicular_joint"},
    **{action: {"glenohumeral_joint"} for action in {
        "shoulder_flexion", "shoulder_extension", "shoulder_abduction", "shoulder_adduction",
        "shoulder_horizontal_abduction", "shoulder_horizontal_adduction",
        "shoulder_internal_rotation", "shoulder_external_rotation",
    }},
    "elbow_flexion": {"elbow_joint"}, "elbow_extension": {"elbow_joint"},
    "forearm_pronation": {"proximal_radioulnar_joint", "distal_radioulnar_joint"},
    "forearm_supination": {"proximal_radioulnar_joint", "distal_radioulnar_joint"},
    **{action: {"radiocarpal_joint"} for action in {
        "wrist_flexion", "wrist_extension", "wrist_radial_deviation", "wrist_ulnar_deviation",
    }},
    **{action: {"finger_metacarpophalangeal_joints"} for action in {
        "finger_mcp_flexion", "finger_mcp_extension", "finger_mcp_abduction", "finger_mcp_adduction",
    }},
    "finger_pip_flexion": {"finger_proximal_interphalangeal_joints"},
    "finger_pip_extension": {"finger_proximal_interphalangeal_joints"},
    "finger_dip_flexion": {"finger_distal_interphalangeal_joints"},
    "finger_dip_extension": {"finger_distal_interphalangeal_joints"},
    **{action: {"thumb_carpometacarpal_joint"} for action in {
        "thumb_cmc_flexion", "thumb_cmc_extension", "thumb_cmc_palmar_abduction",
        "thumb_cmc_radial_abduction", "thumb_cmc_adduction", "thumb_opposition",
    }},
    "thumb_mcp_flexion": {"thumb_metacarpophalangeal_joint"},
    "thumb_mcp_extension": {"thumb_metacarpophalangeal_joint"},
    "thumb_ip_flexion": {"thumb_interphalangeal_joint"},
    "thumb_ip_extension": {"thumb_interphalangeal_joint"},
    "fifth_cmc_opposition": {"fifth_carpometacarpal_joint"},
    **{action: {"hip_joint"} for action in {
        "hip_flexion", "hip_extension", "hip_abduction", "hip_adduction",
        "hip_internal_rotation", "hip_external_rotation",
    }},
    **{action: {"knee_joint"} for action in {
        "knee_flexion", "knee_extension", "knee_internal_rotation", "knee_external_rotation",
    }},
    "ankle_dorsiflexion": {"talocrural_joint"}, "ankle_plantarflexion": {"talocrural_joint"},
    "foot_inversion": {"subtalar_joint"}, "foot_eversion": {"subtalar_joint"},
    **{action: {"lesser_toe_metatarsophalangeal_joints"} for action in {
        "lesser_toe_mtp_flexion", "lesser_toe_mtp_extension", "lesser_toe_mtp_abduction", "lesser_toe_mtp_adduction",
    }},
    "lesser_toe_pip_flexion": {"lesser_toe_proximal_interphalangeal_joints"},
    "lesser_toe_pip_extension": {"lesser_toe_proximal_interphalangeal_joints"},
    "lesser_toe_dip_flexion": {"lesser_toe_distal_interphalangeal_joints"},
    "lesser_toe_dip_extension": {"lesser_toe_distal_interphalangeal_joints"},
    **{action: {"hallux_metatarsophalangeal_joint"} for action in {
        "hallux_mtp_flexion", "hallux_mtp_extension", "hallux_mtp_abduction", "hallux_mtp_adduction",
    }},
    "hallux_ip_flexion": {"hallux_interphalangeal_joint"},
    "hallux_ip_extension": {"hallux_interphalangeal_joint"},
    **{action: {"lumbosacral_spine", "thoracic_spine"} for action in {
        "trunk_flexion", "trunk_extension", "trunk_lateral_flexion", "trunk_rotation",
    }},
    **{action: {"cervical_spine", "atlanto_occipital_joint", "atlanto_axial_joint"} for action in {
        "cervical_flexion", "cervical_extension", "cervical_lateral_flexion", "cervical_rotation",
    }},
    "rib_elevation": {"costovertebral_joints"}, "rib_depression": {"costovertebral_joints"},
}


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def load_csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def validate_schema(instance, schema: dict, location: str, failures: list[str]) -> None:
    """Validate the strict subset of JSON Schema used by this package."""
    if "const" in schema and instance != schema["const"]:
        failures.append(f"schema const {location}")
        return
    if "enum" in schema and instance not in schema["enum"]:
        failures.append(f"schema enum {location}: {instance!r}")
        return
    expected = schema.get("type")
    if expected:
        allowed = expected if isinstance(expected, list) else [expected]
        type_ok = any({
            "object": isinstance(instance, dict),
            "array": isinstance(instance, list),
            "string": isinstance(instance, str),
            "integer": isinstance(instance, int) and not isinstance(instance, bool),
            "boolean": isinstance(instance, bool),
            "null": instance is None,
        }.get(kind, True) for kind in allowed)
        if not type_ok:
            failures.append(f"schema type {location}: {type(instance).__name__}")
            return
    if isinstance(instance, str):
        if "minLength" in schema and len(instance) < schema["minLength"]:
            failures.append(f"schema minLength {location}")
        if "pattern" in schema and not re.fullmatch(schema["pattern"], instance):
            failures.append(f"schema pattern {location}: {instance!r}")
    if isinstance(instance, int) and "minimum" in schema and instance < schema["minimum"]:
        failures.append(f"schema minimum {location}")
    if isinstance(instance, list):
        item_schema = schema.get("items")
        if item_schema:
            for index, item in enumerate(instance):
                validate_schema(item, item_schema, f"{location}[{index}]", failures)
    if isinstance(instance, dict):
        required = schema.get("required", [])
        for key in required:
            if key not in instance:
                failures.append(f"schema required {location}.{key}")
        if "minProperties" in schema and len(instance) < schema["minProperties"]:
            failures.append(f"schema minProperties {location}")
        properties = schema.get("properties", {})
        if schema.get("additionalProperties") is False:
            for key in instance:
                if key not in properties:
                    failures.append(f"schema additional property {location}.{key}")
        additional_schema = schema.get("additionalProperties")
        for key, value in instance.items():
            if key in properties:
                validate_schema(value, properties[key], f"{location}.{key}", failures)
            elif isinstance(additional_schema, dict):
                validate_schema(value, additional_schema, f"{location}.{key}", failures)


def validate_csv_schema(path: Path, schema_path: Path, failures: list[str]) -> int:
    schema = load_json(schema_path)
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        header = reader.fieldnames or []
    if header != schema["required_columns"]:
        failures.append(f"CSV header {path.relative_to(ROOT)}")
    for index, row in enumerate(rows, 2):
        for column in schema.get("nonempty_columns", []):
            if not row.get(column, "").strip():
                failures.append(f"CSV empty {path.relative_to(ROOT)}:{index}:{column}")
        for column, allowed in schema.get("column_enums", {}).items():
            if row.get(column) not in allowed:
                failures.append(f"CSV enum {path.relative_to(ROOT)}:{index}:{column}")
        for column, pattern in schema.get("column_patterns", {}).items():
            if row.get(column) and not re.fullmatch(pattern, row[column]):
                failures.append(f"CSV pattern {path.relative_to(ROOT)}:{index}:{column}")
    return len(rows)


def main() -> int:
    passed = 0
    failures: list[str] = []

    def check(condition: bool, label: str):
        nonlocal passed
        if condition:
            passed += 1
        else:
            failures.append(label)

    manifest = load_json(ROOT / "MANIFEST.json")
    validate_schema(manifest, load_json(SCHEMAS / "manifest.schema.json"), "MANIFEST", failures)
    for item in manifest["files"]:
        path = ROOT / item["path"]
        check(path.is_file(), f"manifest missing: {item['path']}")
        if path.is_file():
            check(path.stat().st_size == item["bytes"], f"manifest size: {item['path']}")
            check(digest(path) == item["sha256"], f"manifest hash: {item['path']}")

    sums = {}
    for line in (ROOT / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        sums[relative] = expected
    for relative, expected in sums.items():
        path = ROOT / relative
        check(path.is_file() and digest(path) == expected, f"SHA256SUMS: {relative}")

    for path in sorted(item for item in ROOT.rglob("*") if item.is_file() and "_coordination" not in item.parts):
        raw = path.read_bytes()
        check(b"\r\n" not in raw and b"\r" not in raw, f"LF-only: {path.relative_to(ROOT)}")
        if path.suffix in {".md", ".json", ".jsonl", ".csv", ".txt"}:
            text = raw.decode("utf-8")
            check(text == unicodedata.normalize("NFC", text), f"NFC: {path.relative_to(ROOT)}")

    json_schema_map = {
        "regions.json": "regions.schema.json",
        "muscle_groups.json": "muscle_groups.schema.json",
        "muscles.jsonl": "muscles.schema.json",
        "muscle_components.jsonl": "muscle_components.schema.json",
        "joints.json": "joints.schema.json",
        "joint_actions.json": "joint_actions.schema.json",
        "functional_actions.json": "functional_actions.schema.json",
        "anatomical_compartments.json": "anatomical_compartments.schema.json",
        "muscle_trainability_profiles.jsonl": "muscle_trainability_profiles.schema.json",
        "public_muscle_taxonomy.json": "public_muscle_taxonomy.schema.json",
    }
    for data_name, schema_name in json_schema_map.items():
        path = EXPORTS / data_name
        schema = load_json(SCHEMAS / schema_name)
        instances = load_jsonl(path) if path.suffix == ".jsonl" else load_json(path)
        if path.suffix == ".jsonl":
            for index, instance in enumerate(instances, 1):
                validate_schema(instance, schema, f"{data_name}:{index}", failures)
                passed += 1
        else:
            validate_schema(instances, schema, data_name, failures)
            passed += 1

    csv_schema_map = {
        EXPORTS / "muscle_joint_relations.csv": SCHEMAS / "muscle_joint_relations.schema.json",
        EXPORTS / "muscle_action_relations.csv": SCHEMAS / "muscle_action_relations.schema.json",
        EXPORTS / "muscle_interaction_relations.csv": SCHEMAS / "muscle_interaction_relations.schema.json",
        EXPORTS / "muscle_claims.csv": SCHEMAS / "muscle_claims.schema.json",
        ROOT / "11_EVIDENCE/CLAIMS_LEDGER.csv": SCHEMAS / "muscle_claims.schema.json",
        ROOT / "11_EVIDENCE/SOURCE_LEDGER.csv": SCHEMAS / "source_ledger.schema.json",
    }
    for data_path, schema_path in csv_schema_map.items():
        passed += validate_csv_schema(data_path, schema_path, failures)

    regions = load_json(EXPORTS / "regions.json")
    groups = load_json(EXPORTS / "muscle_groups.json")
    muscles = load_jsonl(EXPORTS / "muscles.jsonl")
    components = load_jsonl(EXPORTS / "muscle_components.jsonl")
    joints = load_json(EXPORTS / "joints.json")
    actions = load_json(EXPORTS / "joint_actions.json") + load_json(EXPORTS / "functional_actions.json")
    profiles = load_jsonl(EXPORTS / "muscle_trainability_profiles.jsonl")
    joint_relations = load_csv(EXPORTS / "muscle_joint_relations.csv")
    action_relations = load_csv(EXPORTS / "muscle_action_relations.csv")
    interactions = load_csv(EXPORTS / "muscle_interaction_relations.csv")
    claims = load_csv(EXPORTS / "muscle_claims.csv")
    sources = load_csv(ROOT / "11_EVIDENCE/SOURCE_LEDGER.csv")

    ids = {
        "region": {item["canonical_id"] for item in regions},
        "group": {item["canonical_id"] for item in groups},
        "muscle": {item["canonical_id"] for item in muscles},
        "component": {item["canonical_id"] for item in components},
        "joint": {item["canonical_id"] for item in joints},
        "action": {item["canonical_id"] for item in actions},
        "claim": {item["claim_id"] for item in claims},
        "source": {item["source_id"] for item in sources},
        "interaction": {item["relation_id"] for item in interactions},
    }
    entities = ids["muscle"] | ids["component"]
    for kind, values in ids.items():
        check(all(ID_RE.fullmatch(value) for value in values), f"{kind} ID format")
    check(len(ids["muscle"]) == len(muscles), "muscle IDs unique")
    check(len(ids["component"]) == len(components), "component IDs unique")
    check(not ids["muscle"].intersection(ids["component"]), "muscle/component IDs disjoint")

    group_by_id = {item["canonical_id"]: item for item in groups}
    muscle_by_id = {item["canonical_id"]: item for item in muscles}
    component_relation_count = Counter()
    for muscle in muscles:
        mid = muscle["canonical_id"]
        check(muscle["region_id"] in ids["region"], f"{mid}: region")
        check(muscle["group_id"] in ids["group"], f"{mid}: group")
        check(group_by_id[muscle["group_id"]]["region_id"] == muscle["region_id"], f"{mid}: group region")
        expected = group_by_id[muscle["group_id"]]["compartment_id"]
        check(expected is None or muscle["compartment_id"] == expected, f"{mid}: inherited compartment")
        check(all(joint in ids["joint"] for joint in muscle["crossed_joint_ids"]), f"{mid}: crossed joints")
        check(all(claim in ids["claim"] for claim in muscle["claim_ids"]), f"{mid}: claims")
    for component in components:
        cid = component["canonical_id"]
        check(component["parent_muscle_id"] in ids["muscle"], f"{cid}: parent")
        check(all(action in ids["action"] for action in component["action_ids"]), f"{cid}: actions")
        check(all(claim in ids["claim"] for claim in component["claim_ids"]), f"{cid}: claims")

    for row in joint_relations:
        check(row["muscle_id"] in entities, f"joint relation entity {row['muscle_id']}")
        check(row["joint_id"] in ids["joint"], f"joint relation joint {row['muscle_id']}:{row['joint_id']}")
        check(row["claim_id"] in ids["claim"], f"joint relation claim {row['muscle_id']}:{row['joint_id']}")
        if row["subject_type"] == "muscle_component":
            component_relation_count[row["muscle_id"]] += 1
            check(row["parent_muscle_id"] in ids["muscle"], f"component joint parent {row['muscle_id']}")
    action_claim_usage = Counter()
    joint_claim_usage = Counter()
    for row in joint_relations:
        joint_claim_usage[row["claim_id"]] += 1
    for row in action_relations:
        check(row["muscle_id"] in entities, f"action relation entity {row['muscle_id']}")
        check(row["action_id"] in ids["action"], f"action relation action {row['muscle_id']}:{row['action_id']}")
        check(not row["joint_id"] or row["joint_id"] in ids["joint"], f"action relation joint {row['muscle_id']}:{row['action_id']}")
        check(row["claim_id"] in ids["claim"], f"action relation claim {row['muscle_id']}:{row['action_id']}")
        check(
            row["role"] != "principal_contributor"
            or (row["muscle_id"], row["action_id"]) in CURATED_PRIMARY_RELATIONS,
            f"principal role curated {row['muscle_id']}:{row['action_id']}",
        )
        if row["action_id"] in FUNCTIONAL_ACTIONS:
            check(not row["joint_id"], f"functional action without joint {row['muscle_id']}:{row['action_id']}")
        else:
            check(
                row["joint_id"] in ACTION_JOINT_ALLOWED.get(row["action_id"], set()),
                f"action-joint compatibility {row['muscle_id']}:{row['action_id']}:{row['joint_id']}",
            )
        if row["action_id"] in DIGITAL_ACTIONS:
            check(
                row.get("digit_scope", "") not in {"", "not_applicable"},
                f"digit scope required {row['muscle_id']}:{row['action_id']}",
            )
        if row["action_id"] in {"trunk_rotation", "cervical_rotation"}:
            check(row["laterality_rule"] != "not_applicable_or_task_dependent", f"rotation laterality {row['muscle_id']}")
        if row["subject_type"] == "muscle_component":
            component_relation_count[row["muscle_id"]] += 1
            check(row["parent_muscle_id"] in ids["muscle"], f"component action parent {row['muscle_id']}")
        action_claim_usage[row["claim_id"]] += 1
    for component in components:
        check(component_relation_count[component["canonical_id"]] > 0 or component["relation_status"] == "no_separate_relation_approved", f"{component['canonical_id']}: live component")
    check(all(count == 1 for count in action_claim_usage.values()), "atomic action-relation claims")
    check(all(count == 1 for count in joint_claim_usage.values()), "atomic joint-relation claims")
    action_role_by_pair = {
        (row["muscle_id"], row["action_id"]): row["role"]
        for row in action_relations
    }
    check(
        all(
            action_role_by_pair[pair] == "principal_contributor"
            for pair in {
                ("flexor_pollicis_longus", "thumb_ip_flexion"),
                ("extensor_pollicis_longus", "thumb_ip_extension"),
                ("flexor_hallucis_longus", "hallux_ip_flexion"),
                ("extensor_hallucis_longus", "hallux_ip_extension"),
            }
        ),
        "four audited distal long-muscle roles are principal",
    )

    covered_interaction_muscles: set[str] = set()
    for row in interactions:
        check(row["muscle_a_id"] in entities and row["muscle_b_id"] in entities, f"interaction entities {row['relation_id']}")
        check(
            row["subject_a_type"] == ("muscle_component" if row["muscle_a_id"] in ids["component"] else "individual_muscle_or_series")
            and row["subject_b_type"] == ("muscle_component" if row["muscle_b_id"] in ids["component"] else "individual_muscle_or_series"),
            f"interaction subject types {row['relation_id']}",
        )
        check(all(action in ids["action"] for action in row["action_context"].split("|")), f"interaction actions {row['relation_id']}")
        check(row["claim_id"] in ids["claim"], f"interaction claim {row['relation_id']}")
        check("não é uma relação universal" in row["limitations"].lower(), f"interaction contextual {row['relation_id']}")
        matching_claim = next((claim for claim in claims if claim["claim_id"] == row["claim_id"]), None)
        check(
            matching_claim is not None and matching_claim["affected_structure_id"] == row["relation_id"],
            f"interaction claim target {row['relation_id']}",
        )
        covered_interaction_muscles.update(
            entity for entity in (row["muscle_a_id"], row["muscle_b_id"]) if entity in ids["muscle"]
        )
    check(covered_interaction_muscles == ids["muscle"], "interaction graph covers every muscle")
    for profile in profiles:
        mid = profile["muscle_id"]
        values = list(profile["modality_states"].values())
        check(mid in ids["muscle"] and profile["claim_id"] in ids["claim"], f"trainability refs {mid}")
        check(all(value in TRAIN_STATES and not isinstance(value, bool) for value in values), f"trainability states {mid}")
        if profile["review_workflow_status"] == "specialist_pending":
            check(all(value in {"specialist_only", "not_applicable"} for value in values), f"specialist trainability block {mid}")
        check("não prova hipertrofia" in profile["evidence_boundary"].lower(), f"EMG boundary {mid}")
        check(bool(profile["unavoidable_synergists"]["muscle_ids"]), f"trainability contextual partners {mid}")
        check(bool(profile["stability_requirements"]["muscle_ids"]), f"trainability stability candidates {mid}")
    claim_targets = ids["muscle"] | ids["component"] | ids["interaction"]
    joint_relations_by_muscle = defaultdict(set)
    for row in joint_relations:
        if row["relation_type"] == "anatomical_crossing":
            joint_relations_by_muscle[row["muscle_id"]].add(row["joint_id"])
    source_by_id = {source["source_id"]: source for source in sources}
    interaction_by_id = {row["relation_id"]: row for row in interactions}
    for claim in claims:
        check(all(source_id in ids["source"] for source_id in claim["source_ids"].split("|")), f"claim sources {claim['claim_id']}")
        check(claim["affected_structure_id"] in claim_targets, f"claim target {claim['claim_id']}")
        source_ids = set(claim["source_ids"].split("|"))
        expected_source_types = sorted({source_by_id[source_id]["source_type"] for source_id in source_ids})
        expected_source_dates = sorted({source_by_id[source_id]["year"] for source_id in source_ids})
        check(sorted(claim["source_type"].split("|")) == expected_source_types, f"claim source types {claim['claim_id']}")
        check(sorted(claim["source_date"].split("|")) == expected_source_dates, f"claim source dates {claim['claim_id']}")
        target = claim["affected_structure_id"]
        parent = target
        if target in ids["component"]:
            parent = next(item["parent_muscle_id"] for item in components if item["canonical_id"] == target)
        crossed = joint_relations_by_muscle.get(parent, set())
        if "src_hip_moment_arms_1999" in source_ids:
            check("hip_joint" in crossed, f"hip source scope {claim['claim_id']}:{target}")
        if "src_hik_shoulder_2019" in source_ids:
            interaction_actions = (
                interaction_by_id[target]["action_context"].split("|")
                if target in ids["interaction"]
                else []
            )
            check(
                "glenohumeral_joint" in crossed
                or bool(set(interaction_actions).intersection({
                    "shoulder_flexion", "shoulder_extension", "shoulder_abduction", "shoulder_adduction",
                    "shoulder_horizontal_abduction", "shoulder_horizontal_adduction",
                    "shoulder_internal_rotation", "shoulder_external_rotation",
                })),
                f"shoulder source scope {claim['claim_id']}:{target}",
            )
        if "src_hodges_iap_2000" in source_ids:
            check(
                parent in {"diaphragm", "transversus_abdominis", "rectus_abdominis", "external_oblique", "internal_oblique"}
                or target in ids["interaction"],
                f"IAP source scope {claim['claim_id']}:{target}",
            )
    hip_source = next(source for source in sources if source["source_id"] == "src_hip_moment_arms_1999")
    check(hip_source["authors"] == "Delp et al." and hip_source["title"] == "Variation of rotation moment arms with hip flexion", "hip PMID metadata")
    shoulder_source = next(source for source in sources if source["source_id"] == "src_hik_shoulder_2019")
    check(shoulder_source["source_type"] == "systematic_review", "shoulder source type")

    check(manifest["counts"]["regions"] == len(regions), "manifest region count")
    check(manifest["counts"]["groups"] == len(groups), "manifest group count")
    check(manifest["counts"]["muscles"] == len(muscles), "manifest muscle count")
    check(manifest["counts"]["components"] == len(components), "manifest component count")
    check(manifest["counts"]["joints"] == len(joints), "manifest joint count")
    check(manifest["counts"]["actions"] == len(actions), "manifest action count")
    check(manifest["counts"]["joint_relations"] == len(joint_relations), "manifest joint-relation count")
    check(manifest["counts"]["action_relations"] == len(action_relations), "manifest action-relation count")
    check(manifest["counts"]["interactions"] == len(interactions), "manifest interaction count")
    check(manifest["counts"]["claims"] == len(claims), "manifest claim count")

    review_queue = ROOT / "11_EVIDENCE/SPECIALIST_REVIEW_QUEUE.md"
    queued_ids = re.findall(
        r"^\| `([a-z][a-z0-9_]+)` \|",
        review_queue.read_text(encoding="utf-8"),
        flags=re.MULTILINE,
    )
    check(len(queued_ids) == len(set(queued_ids)), "specialist queue unique")

    public = load_json(EXPORTS / "public_muscle_taxonomy.json")
    public_items = [
        item
        for area in public["navigation"]
        for region in area["regions"]
        for group in region["groups"]
        for item in group["muscles"]
    ]
    public_item_by_id = {item["muscle_id"]: item for item in public_items}
    action_name_by_id = {
        action["canonical_id"]: action["name_pt_pt"]
        for action in actions
    }
    action_rows_by_muscle: dict[str, list[dict]] = defaultdict(list)
    for row in action_relations:
        if row["subject_type"] == "individual_muscle_or_series":
            action_rows_by_muscle[row["muscle_id"]].append(row)

    def selected_public_actions(
        muscle_id: str,
        rows: list[dict],
    ) -> list[str]:
        action_ids = list(dict.fromkeys(row["action_id"] for row in rows))
        if len(action_ids) <= PUBLIC_DESCRIPTION_ACTION_LIMIT:
            return action_ids
        roles = {row["action_id"]: row["role"] for row in rows}
        curated = PUBLIC_DESCRIPTION_ACTION_PRIORITY.get(muscle_id, ())
        curated_index = {
            action_id: index
            for index, action_id in enumerate(curated)
        }
        return sorted(
            action_ids,
            key=lambda action_id: (
                PUBLIC_ROLE_PRIORITY.get(roles[action_id], 99),
                curated_index.get(action_id, len(curated)),
                action_id,
            ),
        )[:PUBLIC_DESCRIPTION_ACTION_LIMIT]

    def expected_public_description(
        muscle_id: str,
        rows: list[dict],
    ) -> str:
        selected = selected_public_actions(muscle_id, rows)
        labels = [
            PUBLIC_ACTION_LABEL_OVERRIDES.get(
                (muscle_id, action_id),
                action_name_by_id[action_id].lower(),
            ).replace("ii–v", "II–V")
            for action_id in selected
        ]
        action_text = ", ".join(labels) if labels else "estabilização ou transmissão de força contextual"
        return (
            f"{muscle_by_id[muscle_id]['names']['pt_pt']}: participa em {action_text}. "
            "A contribuição real depende da posição, da amplitude, da direção da resistência, "
            "da estabilidade disponível e da tarefa."
        )

    for item in public_items:
        muscle = muscle_by_id[item["muscle_id"]]
        check(
            muscle["approval_status"] in {"approved", "approved_with_limits"}
            and muscle["public_state"] == "public_training_relevant"
            and muscle["risk_class"] in {"general_training", "caution_required"}
            and muscle["review_status"] == "reviewed_internal",
            f"public fail-closed {muscle['canonical_id']}",
        )
        check(all(key in item for key in {"risk_class", "approval_status", "review_status", "limitations", "inclusion_reason"}), f"public audit fields {muscle['canonical_id']}")
        rows = action_rows_by_muscle[muscle["canonical_id"]]
        selected = selected_public_actions(muscle["canonical_id"], rows)
        expected_description = expected_public_description(
            muscle["canonical_id"],
            rows,
        )
        check(
            item["description"] == expected_description
            and muscle["public_description"] == expected_description,
            f"public description derived from valid relations {muscle['canonical_id']}",
        )
        check(
            set(selected) <= {row["action_id"] for row in rows},
            f"public description relation validity {muscle['canonical_id']}",
        )
        principal_actions = {
            row["action_id"]
            for row in rows
            if row["role"] in {
                "principal_contributor",
                "principal_contextual_contributor",
            }
        }
        check(
            not principal_actions or bool(principal_actions.intersection(selected)),
            f"public description principal inclusion {muscle['canonical_id']}",
        )
        if len(rows) > PUBLIC_DESCRIPTION_ACTION_LIMIT:
            roles = {row["action_id"]: row["role"] for row in rows}
            check(
                all(
                    selected_public_actions(
                        muscle["canonical_id"],
                        [
                            next(
                                row
                                for row in rows
                                if row["action_id"] == action_id
                            )
                            for action_id in order
                        ],
                    ) == selected
                    for order in permutations(
                        [row["action_id"] for row in rows]
                    )
                ),
                f"public description order independence {muscle['canonical_id']}",
            )

    public_ids = set(public_item_by_id)
    over_capacity_public_ids = {
        muscle_id
        for muscle_id in public_ids
        if len(action_rows_by_muscle[muscle_id])
        > PUBLIC_DESCRIPTION_ACTION_LIMIT
    }
    check(
        len(over_capacity_public_ids) == 16
        and over_capacity_public_ids
        == set(PUBLIC_DESCRIPTION_ACTION_PRIORITY),
        "all 16 over-capacity public candidates explicitly reviewed",
    )
    mandatory_public_actions = {
        "flexor_digitorum_profundus": "finger_dip_flexion",
        "flexor_digitorum_superficialis": "finger_pip_flexion",
        "flexor_digitorum_longus": "lesser_toe_dip_flexion",
    }
    check(
        all(
            action_id
            in selected_public_actions(
                muscle_id,
                action_rows_by_muscle[muscle_id],
            )
            for muscle_id, action_id in mandatory_public_actions.items()
        ),
        "three mandatory distal principal actions exposed",
    )
    check(
        all(
            next(
                row
                for row in action_rows_by_muscle[muscle_id]
                if row["action_id"] == action_id
            )["role"] == "principal_contributor"
            for muscle_id, action_id in mandatory_public_actions.items()
        ),
        "three mandatory distal roles remain principal",
    )

    public_text = "\n".join(
        str(item[field])
        for item in public_items
        for field in ("name_pt_pt", "description", "limitations", "inclusion_reason")
    )
    check(
        not re.search(r"\b(?:usuário|usuários|treinamento|panturrilha|você)\b", public_text, flags=re.IGNORECASE),
        "public PT-PT terminology",
    )
    check(not re.search(r"\b[a-z]+_[a-z0-9_]+\b", public_text), "no internal IDs in public prose")
    scope_text = (ROOT / "01_METHOD/SCOPE_AND_EXCLUSIONS.md").read_text(encoding="utf-8")
    check(
        "Não é um catálogo completo de todos os músculos do corpo humano."
        in re.sub(r"\s+", " ", scope_text),
        "scope completeness boundary",
    )
    readme_text = (ROOT / "00_README/README.md").read_text(encoding="utf-8")
    check(
        "implementação na EveFit: **não**" in readme_text
        and "catálogo de exercícios criado: **não**" in readme_text,
        "no implementation or exercise catalogue",
    )

    package_text = "\n".join(
        path.read_text(encoding="utf-8")
        for path in ROOT.rglob("*")
        if path.is_file() and path.suffix in {".json", ".jsonl", ".csv", ".md"} and "_coordination" not in path.parts
    )
    check("Position and task dependent" not in package_text, "no English relation placeholder")
    check("open_or_closed_context_required" not in package_text, "no unresolved chain placeholder")

    zip_path = ROOT.parent / f"{ROOT.name}.zip"
    check(zip_path.is_file(), "ZIP exists")
    if zip_path.is_file():
        with zipfile.ZipFile(zip_path) as archive:
            check(archive.testzip() is None, "ZIP CRC")
            names = archive.namelist()
            check(names == sorted(names), "ZIP order deterministic")
            check(all(info.date_time == (2026, 7, 28, 12, 0, 0) for info in archive.infolist()), "ZIP fixed timestamps")

    result = {
        "status": "PASS" if not failures else "FAIL",
        "checks_passed": passed,
        "failures": failures,
        "counts": {
            "regions": len(regions),
            "groups": len(groups),
            "muscles_or_series": len(muscles),
            "components": len(components),
            "joints": len(joints),
            "actions": len(actions),
            "joint_relations": len(joint_relations),
            "action_relations": len(action_relations),
            "interactions": len(interactions),
            "claims": len(claims),
            "sources": len(sources),
            "public_candidates": len(public_items),
        },
    }
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
