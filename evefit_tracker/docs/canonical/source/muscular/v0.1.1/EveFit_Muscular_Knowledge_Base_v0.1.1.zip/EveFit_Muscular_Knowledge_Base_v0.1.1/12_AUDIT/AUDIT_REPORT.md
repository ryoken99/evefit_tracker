# Relatório de auditoria

## Processo

Na v0.1.1 foi feita uma correção localizada da camada pública: seleção
determinística das ações curtas, revisão dos 16 candidatos acima do limite e
auditoria das ações distais dos flexores/extensores longos. A taxonomia, claims,
fontes e restante estrutura da v0.1 foram preservadas.

A primeira integração foi submetida a três auditorias independentes e recebeu
três pareceres `BLOCKER`. Nenhum desses resultados foi ocultado ou promovido.
As correções foram feitas no construtor, os exports foram regenerados e os
mesmos domínios críticos fizeram uma segunda leitura completa.

## Histórico dos gates

| Gate | Primeira leitura | Reauditoria final |
|---|---|---|
| Anatomia | `BLOCKER` | `PASS` |
| Biomecânica e treinabilidade | `BLOCKER` | `PASS` |
| Evidência, dados e schemas | `BLOCKER` | `PASS` |

## Correções materiais

- três ações principais anteriormente truncadas pela ordem da lista passaram a
  integrar obrigatoriamente as descrições de `flexor_digitorum_profundus`,
  `flexor_digitorum_superficialis` e `flexor_digitorum_longus`;
- as descrições dos 16 candidatos acima do limite passaram a usar papel,
  prioridade curada e ID canónico, nunca ordem física do CSV;
- quatro papéis distais foram promovidos a `principal_contributor` com base na
  inserção distal e função direta: FPL/IP, EPL/IP, FHL/IP e EHL/IP;
- grupos, regiões, compartimentos e camadas incoerentes foram corrigidos;
- articulações PIP/DIP, travessias axiais e funções capsulares foram separadas;
- 36 componentes receberam estrutura própria e 22 intrínsecos numerados foram
  individualizados;
- modelos textuais mecânicos foram substituídos por perfis de região/função;
- o grafo músculo-músculo passou a cobrir 179/179 entidades, mantendo inferências
  automáticas em baixa confiança e casos residuais em `specialist_pending`;
- origem, inserção, inervação e cada relação articular/ação passaram a ter afirmações
  separadas;
- âmbito e tipo de fontes, alvos relacionais e esquemas foram fechados.

## Validação final

- validação interna: 11557 verificações, 0 falhas;
- validação externa independente do construtor: 25647 verificações, 0 falhas;
- PT-PT, fronteira de completude e ausência de IDs em prosa pública: aprovados;
- integridade: manifest, hashes, CRC, UTF-8/NFC e LF aprovados;
- determinismo: duas gerações isoladas e ZIPs comparados byte a byte;
- aplicação EveFit, código Flutter, base de dados e catálogo de exercícios:
  zero alterações;
- publicação ou implementação: não.

### Limites da auditoria

Os pareceres independentes são auditorias técnicas multiagente, não revisão
profissional humana. Não substituem anatomista, biomecânico, fisioterapeuta,
médico ou linguista PT-PT nos itens assinalados para especialista.
