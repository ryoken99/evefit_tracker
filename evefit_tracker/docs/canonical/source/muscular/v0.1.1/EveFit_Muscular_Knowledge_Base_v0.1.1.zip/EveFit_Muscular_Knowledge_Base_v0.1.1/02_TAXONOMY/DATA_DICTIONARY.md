# Dicionário de dados

Os schemas normativos estão em `13_EXPORTS/schemas/`.

| Campo/família | Significado |
|---|---|
| `canonical_id` | ID estável ASCII `snake_case` |
| `names` | nomes PT-PT, latim e inglês |
| `region_id`, `group_id`, `compartment_id` | pertença e navegação |
| `origin`, `insertion`, `innervation` | estrutura anatómica |
| `crossed_joint_ids` | articulações diretas ou complexos documentados |
| `mechanics` | linha de tração, momento, força e estabilidade sem números inventados |
| `kinetic_chain` | papéis em cadeia aberta/fechada e suporte |
| `practical_emphasis` | ênfase relativa, nunca isolamento absoluto |
| `modality_states` | estado de evidência por forma de carga, sem booleanos universais |
| `subject_type`, `parent_muscle_id` | distinguem músculo/série de componente e preservam agregação |
| `laterality_rule` | direção ipsilateral/contralateral ou regra que exige lado declarado |
| `risk_class` | `general_training`, `caution_required`, `specialist_review`, `clinical_only` |
| `claim_ids` | ligação obrigatória à proveniência |
| `approval_status` | estado canónico |

CSV usam colunas fixas e schemas com enums. JSONL possui um objeto por linha.
Cada modalidade de treinabilidade usa `supported`, `plausible_inference`,
`not_applicable`, `insufficient_evidence` ou `specialist_only`.
