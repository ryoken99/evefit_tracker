# Auditoria das descrições públicas de ações v0.1.1

## Âmbito

Correção localizada da seleção e geração de descrições públicas curtas. Foram
revistos os 16 candidatos públicos com mais de três relações de ação. Não foram
alterados taxonomia, claims, fontes, grupos, articulações, ações, treinabilidade
ou aplicação EveFit.

## Política determinística

1. `principal_contributor`;
2. `principal_contextual_contributor`;
3. contribuições secundárias ou contextuais representativas;
4. reguladores/estabilizadores e papéis residuais;
5. desempate por prioridade curada e ID canónico.

O limite continua a ser três ações. A ordem física das relações no CSV não é
usada. As ações não selecionadas continuam disponíveis na ficha detalhada.

## Registos com descrição corrigida

`extensor_digiti_minimi`, `extensor_digitorum`, `extensor_digitorum_longus`, `extensor_indicis`, `extensor_pollicis_longus`, `flexor_digitorum_longus`, `flexor_digitorum_profundus`, `flexor_digitorum_superficialis`, `flexor_hallucis_longus`, `flexor_pollicis_longus`, `trapezius`.

## Antes e depois dos 16 candidatos revistos

| Registo | Descrição alterada | Antes | Depois |
|---|---|---|---|
| `deltoid` | não | Deltoide: participa em abdução do ombro, flexão do ombro, extensão do ombro. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Deltoide: participa em abdução do ombro, flexão do ombro, extensão do ombro. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `extensor_digiti_minimi` | sim | Extensor do dedo mínimo: participa em extensão do punho, extensão metacarpofalângica dos dedos ii–v, extensão interfalângica proximal dos dedos ii–v. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Extensor do dedo mínimo: participa em extensão metacarpofalângica do dedo V, extensão interfalângica proximal do dedo V, extensão interfalângica distal do dedo V. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `extensor_digitorum` | sim | Extensor dos dedos: participa em extensão do punho, extensão metacarpofalângica dos dedos ii–v, extensão interfalângica proximal dos dedos ii–v. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Extensor dos dedos: participa em extensão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V, extensão interfalângica distal dos dedos II–V. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `extensor_digitorum_longus` | sim | Extensor longo dos dedos: participa em dorsiflexão, eversão do pé, extensão metatarsofalângica dos dedos ii–v. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Extensor longo dos dedos: participa em extensão metatarsofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V, extensão interfalângica distal dos dedos II–V. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `extensor_indicis` | sim | Extensor do indicador: participa em extensão do punho, extensão metacarpofalângica dos dedos ii–v, extensão interfalângica proximal dos dedos ii–v. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Extensor do indicador: participa em extensão metacarpofalângica do dedo II, extensão interfalângica proximal do dedo II, extensão interfalângica distal do dedo II. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `extensor_pollicis_longus` | sim | Extensor longo do polegar: participa em extensão do punho, extensão carpometacárpica do polegar, extensão metacarpofalângica do polegar. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Extensor longo do polegar: participa em extensão interfalângica do polegar, extensão metacarpofalângica do polegar, extensão carpometacárpica do polegar. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `external_oblique` | não | Oblíquo externo do abdómen: participa em flexão do tronco, flexão lateral do tronco, rotação do tronco. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Oblíquo externo do abdómen: participa em flexão do tronco, flexão lateral do tronco, rotação do tronco. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `flexor_digitorum_longus` | sim | Flexor longo dos dedos do pé: participa em flexão plantar, inversão do pé, flexão metatarsofalângica dos dedos ii–v. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Flexor longo dos dedos do pé: participa em flexão interfalângica distal dos dedos II–V, flexão interfalângica proximal dos dedos II–V, flexão metatarsofalângica dos dedos II–V. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `flexor_digitorum_profundus` | sim | Flexor profundo dos dedos: participa em flexão do punho, flexão metacarpofalângica dos dedos ii–v, flexão interfalângica proximal dos dedos ii–v. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Flexor profundo dos dedos: participa em flexão interfalângica distal dos dedos II–V, flexão interfalângica proximal dos dedos II–V, flexão metacarpofalângica dos dedos II–V. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `flexor_digitorum_superficialis` | sim | Flexor superficial dos dedos: participa em flexão do punho, flexão do cotovelo, flexão metacarpofalângica dos dedos ii–v. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Flexor superficial dos dedos: participa em flexão interfalângica proximal dos dedos II–V, flexão metacarpofalângica dos dedos II–V, flexão do punho. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `flexor_hallucis_longus` | sim | Flexor longo do hálux: participa em flexão plantar, inversão do pé, flexão metatarsofalângica do hálux. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Flexor longo do hálux: participa em flexão interfalângica do hálux, flexão metatarsofalângica do hálux, flexão plantar. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `flexor_pollicis_longus` | sim | Flexor longo do polegar: participa em flexão do punho, flexão carpometacárpica do polegar, flexão metacarpofalângica do polegar. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Flexor longo do polegar: participa em flexão interfalângica do polegar, flexão metacarpofalângica do polegar, flexão carpometacárpica do polegar. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `internal_oblique` | não | Oblíquo interno do abdómen: participa em flexão do tronco, flexão lateral do tronco, rotação do tronco. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Oblíquo interno do abdómen: participa em flexão do tronco, flexão lateral do tronco, rotação do tronco. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `pectoralis_major` | não | Peitoral maior: participa em adução horizontal do ombro, adução do ombro, rotação interna do ombro. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Peitoral maior: participa em adução horizontal do ombro, adução do ombro, rotação interna do ombro. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `sartorius` | não | Sartório: participa em flexão da anca, abdução da anca, rotação externa da anca. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Sartório: participa em flexão da anca, abdução da anca, rotação externa da anca. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |
| `trapezius` | sim | Trapézio: participa em elevação escapular, retração escapular, depressão escapular. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. | Trapézio: participa em elevação escapular, retração escapular, rotação superior da escápula. A contribuição real depende da posição, da amplitude, da direção da resistência, da estabilidade disponível e da tarefa. |

## Auditoria distal dos flexores e extensores longos

| Músculo | Ação distal | Papel antes | Papel depois | Decisão | Fundamentação |
|---|---|---|---|---|---|
| `flexor_digitorum_superficialis` | `finger_pip_flexion` | `principal_contributor` | `principal_contributor` | mantido | Inserção nas falanges médias; principal flexor da IFP. |
| `flexor_digitorum_profundus` | `finger_dip_flexion` | `principal_contributor` | `principal_contributor` | mantido | Inserção nas falanges distais; único flexor extrínseco direto da IFD. |
| `extensor_digitorum` | `finger_pip_extension` | `secondary_or_contextual_contributor` | `secondary_or_contextual_contributor` | mantido | Contribuição pela expansão extensora; partilhada com intrínsecos. |
| `extensor_digitorum` | `finger_dip_extension` | `secondary_or_contextual_contributor` | `secondary_or_contextual_contributor` | mantido | Contribuição pela expansão extensora; partilhada com intrínsecos. |
| `flexor_pollicis_longus` | `thumb_ip_flexion` | `secondary_or_contextual_contributor` | `principal_contributor` | alterado | Inserção distal e função primária de flexão da interfalângica do polegar. |
| `extensor_pollicis_longus` | `thumb_ip_extension` | `secondary_or_contextual_contributor` | `principal_contributor` | alterado | Inserção distal e função primária de extensão da interfalângica do polegar. |
| `flexor_digitorum_longus` | `lesser_toe_dip_flexion` | `principal_contributor` | `principal_contributor` | mantido | Inserção nas falanges distais II–V; ação distal principal. |
| `extensor_digitorum_longus` | `lesser_toe_pip_extension` | `secondary_or_contextual_contributor` | `secondary_or_contextual_contributor` | mantido | Contribuição pela expansão extensora dos dedos II–V; papel partilhado. |
| `extensor_digitorum_longus` | `lesser_toe_dip_extension` | `secondary_or_contextual_contributor` | `secondary_or_contextual_contributor` | mantido | Contribuição pela expansão extensora dos dedos II–V; papel partilhado. |
| `flexor_hallucis_longus` | `hallux_ip_flexion` | `secondary_or_contextual_contributor` | `principal_contributor` | alterado | Inserção na falange distal e função primária de flexão do hálux. |
| `extensor_hallucis_longus` | `hallux_ip_extension` | `secondary_or_contextual_contributor` | `principal_contributor` | alterado | Inserção na falange distal e extensão direta da interfalângica do hálux. |

As quatro alterações de papel são sustentadas pela inserção na falange distal e
pela função articular direta descritas nas fontes já existentes
`src_moore_coa_9e`, `src_grays_students_5e`,
`src_neumann_kinesiology_3e`, `src_ncbi_forearm_muscles` e
`src_ncbi_foot_muscles`. Não foram adicionadas, removidas ou modificadas fontes
ou afirmações.

## Alterações de papel

- `extensor_hallucis_longus` / `hallux_ip_extension`: `secondary_or_contextual_contributor` → `principal_contributor`
- `extensor_pollicis_longus` / `thumb_ip_extension`: `secondary_or_contextual_contributor` → `principal_contributor`
- `flexor_hallucis_longus` / `hallux_ip_flexion`: `secondary_or_contextual_contributor` → `principal_contributor`
- `flexor_pollicis_longus` / `thumb_ip_flexion`: `secondary_or_contextual_contributor` → `principal_contributor`

## Preservação byte a byte

Dos 56 ficheiros de entrega da v0.1, 42 permanecem byte a byte idênticos.
Não foi eliminado nenhum ficheiro.

Ficheiros v0.1 modificados:

- `00_README/FINAL_REPORT.md`;
- `00_README/README.md`;
- `03_UPPER_BODY/UPPER_BODY_CATALOGUE.md`;
- `04_LOWER_BODY/LOWER_BODY_CATALOGUE.md`;
- `09_PUBLIC_LAYER/PUBLIC_NAVIGATION_PROPOSAL.md`;
- `12_AUDIT/AUDIT_REPORT.md`;
- `12_AUDIT/VALIDATION_REPORT.md`;
- `12_AUDIT/validate_package.py`;
- `13_EXPORTS/muscle_action_relations.csv`;
- `13_EXPORTS/muscles.jsonl`;
- `13_EXPORTS/public_muscle_taxonomy.json`;
- `13_EXPORTS/schemas/manifest.schema.json`;
- `MANIFEST.json`;
- `SHA256SUMS.txt`.

Novo ficheiro:

- `12_AUDIT/PUBLIC_ACTION_DESCRIPTION_AUDIT_v0.1.1.md`.

`CLAIMS_LEDGER.csv`, `muscle_claims.csv` e `SOURCE_LEDGER.csv` foram comparados
com a v0.1 e são byte a byte idênticos.

## Alterações fora do pacote documental

- aplicação EveFit: zero;
- código Flutter: zero;
- base de dados da aplicação: zero;
- catálogo de exercícios: zero.
