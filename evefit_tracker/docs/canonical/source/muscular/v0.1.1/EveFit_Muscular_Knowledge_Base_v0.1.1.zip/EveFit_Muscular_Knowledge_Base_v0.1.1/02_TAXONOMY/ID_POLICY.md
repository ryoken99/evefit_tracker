# Política de IDs

- Regex: `^[a-z][a-z0-9]*(?:_[a-z0-9]+)*$`.
- IDs são tipados pelo ficheiro e não recebem prefixos redundantes.
- Não incluem lado, idioma, versão, estado ou nome popular.
- Mudanças de nome público não alteram o ID.
- Sinónimos não criam novos registos.
- IDs não são reutilizados.
- Cabeças/porções usam ID próprio e `parent_muscle_id`.
- Códigos externos são mapeamentos, não IDs EveFit.
