# Catálogo do membro superior e cintura escapular

> Catálogo completo dentro do âmbito EveFit definido. Não é um catálogo completo de todos os músculos do corpo humano.

Cada perfil separa factos anatómicos, interpretação funcional e inferência de treino. As ações são contextuais.

## Abdutor do dedo mínimo da mão (`abductor_digiti_minimi_hand`)

- **Latim / inglês:** musculus abductor digiti minimi manus / abductor digiti minimi of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_hypothenar` / `superficial`
- **Origem:** Pisiforme e tendão do flexor ulnar do carpo.
- **Inserção:** Base medial da falange proximal do dedo V e expansão extensora do dedo V.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com abdução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com abdução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000009, claim_000010, claim_000011, claim_000012, claim_000013, claim_000014, claim_000015, claim_000016

### Relações músculo-ação

- `finger_mcp_abduction` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Abdutor curto do polegar (`abductor_pollicis_brevis`)

- **Latim / inglês:** musculus abductor pollicis brevis / abductor pollicis brevis
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_thenar` / `superficial`
- **Origem:** Retináculo dos flexores, escafoide e trapézio.
- **Inserção:** Base lateral da falange proximal do polegar.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** thumb_carpometacarpal_joint; `monoarticular`
- **Inervação:** Ramo recorrente do nervo mediano.
- **Encurtamento aproximado:** Combinação digital compatível com oposição do polegar e abdução palmar do polegar; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000029, claim_000030, claim_000031, claim_000032, claim_000033, claim_000034

### Relações músculo-ação

- `thumb_opposition` em `thumb_carpometacarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_carpometacarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir oposição do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_cmc_palmar_abduction` em `thumb_carpometacarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_carpometacarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução palmar do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Abdutor longo do polegar (`abductor_pollicis_longus`)

- **Latim / inglês:** musculus abductor pollicis longus / abductor pollicis longus
- **Região / grupo / camada:** `forearm` / `posterior_forearm_deep` / `deep`
- **Origem:** Faces posteriores do rádio e ulna e membrana interóssea.
- **Inserção:** Base do metacárpico I.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** radiocarpal_joint, thumb_carpometacarpal_joint; `biarticular`
- **Inervação:** Nervo interósseo posterior.
- **Encurtamento aproximado:** Combinação digital compatível com desvio radial do punho e abdução radial do polegar; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, thumb_carpometacarpal_joint, em posições compatíveis com desvio radial do punho e abdução radial do polegar. Pode ocorrer quando as articulações radiocarpal_joint, thumb_carpometacarpal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000037, claim_000038, claim_000039, claim_000040, claim_000041, claim_000042, claim_000043

### Relações músculo-ação

- `wrist_radial_deviation` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir desvio radial do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_cmc_radial_abduction` em `thumb_carpometacarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_carpometacarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução radial do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Adutor do polegar (`adductor_pollicis`)

- **Latim / inglês:** musculus adductor pollicis / adductor pollicis
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_thenar` / `deep`
- **Origem:** Cabeças oblíqua e transversa a partir de bases metacárpicas/capitato e metacárpico III.
- **Inserção:** Base medial da falange proximal do polegar.
- **Arquitetura e fibras:** `convergent_two_headed`. Duas cabeças com orientações distintas convergem para uma inserção comum.
- **Articulações e classe:** thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint; `biarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com adução carpometacárpica do polegar e flexão metacarpofalângica do polegar; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint, em posições compatíveis com adução carpometacárpica do polegar e flexão metacarpofalângica do polegar. Pode ocorrer quando as articulações thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000079, claim_000080, claim_000081, claim_000082, claim_000083, claim_000084, claim_000085

### Relações músculo-ação

- `thumb_cmc_adduction` em `thumb_carpometacarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_carpometacarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução carpometacárpica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_mcp_flexion` em `thumb_metacarpophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_metacarpophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Ancóneo (`anconeus`)

- **Latim / inglês:** musculus anconeus / anconeus
- **Região / grupo / camada:** `arm` / `posterior_arm` / `deep`
- **Origem:** Epicôndilo lateral do úmero.
- **Inserção:** Face lateral do olécrano e ulna proximal posterior.
- **Arquitetura e fibras:** `triangular`. Fibras dispõem-se numa unidade triangular entre fixações de larguras diferentes.
- **Articulações e classe:** elbow_joint; `monoarticular`
- **Inervação:** Nervo radial.
- **Encurtamento aproximado:** Posição combinada compatível com extensão do cotovelo; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão do cotovelo; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A linha de tração é inferida das fixações e deve ser interpretada para extensão do cotovelo na posição e tarefa declaradas. O braço de momento pode mudar de magnitude ou sinal com a posição; não foi aprovado um valor ou máximo angular universal. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: elbow_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000088, claim_000089, claim_000090, claim_000091, claim_000092, claim_000093

### Relações músculo-ação

- `elbow_extension` em `elbow_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de elbow_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do cotovelo quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Articular do cotovelo (`articularis_cubiti`)

- **Latim / inglês:** musculus articularis cubiti / articularis cubiti
- **Região / grupo / camada:** `arm` / `posterior_arm` / `deep`
- **Origem:** Úmero posterior distal e/ou fibras profundas do tricípite.
- **Inserção:** Cápsula posterior do cotovelo e olécrano.
- **Arquitetura e fibras:** `small_parallel`. Pequeno feixe de fibras paralelas, por vezes anatomicamente variável.
- **Articulações e classe:** elbow_joint; `monoarticular`
- **Inervação:** Nervo radial.
- **Encurtamento aproximado:** Relaciona-se com a retração da cápsula durante a extensão do cotovelo; não se define uma posição de encurtamento como alvo de treino independente.
- **Alongamento aproximado:** A flexão do cotovelo altera a relação com a cápsula; não se apresenta uma posição de alongamento autónoma.
- **Insuficiência ativa/passiva:** Não aplicável como limitação multiarticular de um alvo motor independente. Não aplicável como regra prática autónoma; a cápsula articular exige contexto especializado.
- **Mecânica:** A linha de tração dirige-se à cápsula do cotovelo e acompanha a extensão articular. Não é tratado como motor rotacional independente; não foi atribuído braço de momento. A força local acompanha a atividade do aparelho extensor e a geometria capsular; não existe perfil motor independente aprovado.
- **Cadeia aberta/fechada:** Durante a extensão do cotovelo, acompanha a retração capsular; não é um motor isolável da cadeia. Com o segmento distal fixo, o papel capsular continua subordinado ao movimento do cotovelo.
- **Ênfase prática:** `specialist_review`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `catalogued_not_public` / `specialist_review`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A identidade anatómica recebeu apoio recente, mas prevalência, limites e função mecânica continuam em revisão; não é alvo público.
- **Claims:** claim_000107, claim_000108, claim_000109, claim_000110, claim_000111, claim_000112, claim_000113

### Relações músculo-ação

- `elbow_capsular_retraction` em ``: `capsular_retractor`. Ocorre em associação com a extensão do cotovelo e com a relação local entre músculo e cápsula. Retração capsular local associada à extensão, sem afirmar produção relevante do momento articular. Não foi aprovada uma função excêntrica capsular independente nesta versão.

## Bicípite braquial (`biceps_brachii`)

- **Latim / inglês:** musculus biceps brachii / biceps brachii
- **Região / grupo / camada:** `arm` / `anterior_arm` / `superficial`
- **Origem:** Cabeça longa: tubérculo supraglenoidal; cabeça curta: processo coracoide.
- **Inserção:** Tuberosidade do rádio e aponeurose bicipital.
- **Arquitetura e fibras:** `fusiform_two_headed`. Duas cabeças convergem para uma unidade distal comum, com orientações proximais diferentes.
- **Articulações e classe:** glenohumeral_joint, elbow_joint, proximal_radioulnar_joint; `multiarticular`
- **Inervação:** Nervo musculocutâneo.
- **Encurtamento aproximado:** Posição combinada compatível com flexão do cotovelo, supinação do antebraço e flexão do ombro; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão do cotovelo, pronação do antebraço e extensão do ombro; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode perder capacidade de produzir força quando está simultaneamente encurtado no ombro, cotovelo e antebraço. A combinação de extensão do cotovelo, extensão do ombro e pronação pode aumentar a tensão passiva, com variação individual.
- **Mecânica:** A linha de tração é inferida das fixações e deve ser interpretada para flexão do cotovelo, supinação do antebraço e flexão do ombro na posição e tarefa declaradas. O braço de momento pode mudar de magnitude ou sinal com a posição; não foi aprovado um valor ou máximo angular universal. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: glenohumeral_joint, elbow_joint, proximal_radioulnar_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000123, claim_000124, claim_000125, claim_000126, claim_000127, claim_000128, claim_000129, claim_000130

### Relações músculo-ação

- `elbow_flexion` em `elbow_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: elbow_joint. Pode produzir ou assistir flexão do cotovelo quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `forearm_supination` em `proximal_radioulnar_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: proximal_radioulnar_joint. Pode produzir ou assistir supinação do antebraço quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_flexion` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: glenohumeral_joint. Pode produzir ou assistir flexão do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Braquial (`brachialis`)

- **Latim / inglês:** musculus brachialis / brachialis
- **Região / grupo / camada:** `arm` / `anterior_arm` / `deep`
- **Origem:** Metade distal da face anterior do úmero.
- **Inserção:** Tuberosidade e processo coronoide da ulna.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** elbow_joint; `monoarticular`
- **Inervação:** Nervo musculocutâneo; contribuição radial variável.
- **Encurtamento aproximado:** Posição combinada compatível com flexão do cotovelo; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão do cotovelo; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A linha de tração é inferida das fixações e deve ser interpretada para flexão do cotovelo na posição e tarefa declaradas. O braço de momento pode mudar de magnitude ou sinal com a posição; não foi aprovado um valor ou máximo angular universal. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: elbow_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000144, claim_000145, claim_000146, claim_000147, claim_000148, claim_000149

### Relações músculo-ação

- `elbow_flexion` em `elbow_joint`: `principal_contributor`. A contribuição varia ao longo de elbow_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do cotovelo quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Braquiorradial (`brachioradialis`)

- **Latim / inglês:** musculus brachioradialis / brachioradialis
- **Região / grupo / camada:** `forearm` / `posterior_forearm_superficial` / `superficial`
- **Origem:** Crista supracondilar lateral do úmero.
- **Inserção:** Face lateral do rádio distal, proximal ao processo estiloide.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** elbow_joint; `monoarticular`
- **Inervação:** Nervo radial.
- **Encurtamento aproximado:** Posição combinada compatível com flexão do cotovelo; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão do cotovelo; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração deve ser resolvida em relação ao eixo longitudinal do antebraço e também ao cotovelo. A vantagem muda com a posição de pronação/supinação e com o ângulo do cotovelo quando atravessado; não foi fixado um máximo. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: elbow_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. O momento flexor é relevante com o antebraço em posição intermédia; pode ajudar a devolver o antebraço à posição neutra.
- **Claims:** claim_000151, claim_000152, claim_000153, claim_000154, claim_000155, claim_000156

### Relações músculo-ação

- `elbow_flexion` em `elbow_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de elbow_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do cotovelo quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Coracobraquial (`coracobrachialis`)

- **Latim / inglês:** musculus coracobrachialis / coracobrachialis
- **Região / grupo / camada:** `arm` / `anterior_arm` / `deep`
- **Origem:** Processo coracoide.
- **Inserção:** Terço médio da face medial do úmero.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** glenohumeral_joint; `monoarticular`
- **Inervação:** Nervo musculocutâneo.
- **Encurtamento aproximado:** Posição combinada compatível com flexão do ombro e adução do ombro; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão do ombro e abdução do ombro; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A linha de tração é inferida das fixações e deve ser interpretada para flexão do ombro e adução do ombro na posição e tarefa declaradas. O braço de momento pode mudar de magnitude ou sinal com a posição; não foi aprovado um valor ou máximo angular universal. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: glenohumeral_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000174, claim_000175, claim_000176, claim_000177, claim_000178, claim_000179

### Relações músculo-ação

- `shoulder_flexion` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_adduction` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Deltoide (`deltoid`)

- **Latim / inglês:** musculus deltoideus / deltoid
- **Região / grupo / camada:** `shoulder` / `scapulohumeral_muscles` / `superficial`
- **Origem:** Terço lateral da clavícula, acrómio e espinha da escápula.
- **Inserção:** Tuberosidade deltoideia do úmero.
- **Arquitetura e fibras:** `multipennate`. As porções anterior, média e posterior têm orientações distintas em torno da articulação glenoumeral; não se atribui uma direção única ao deltoide completo.
- **Articulações e classe:** glenohumeral_joint; `monoarticular`
- **Inervação:** Nervo axilar.
- **Encurtamento aproximado:** Varia entre porções e com a orientação do úmero e da escápula; não existe uma posição única para o músculo completo.
- **Alongamento aproximado:** Varia entre porções e com o plano de elevação, rotação umeral e posição escapular.
- **Insuficiência ativa/passiva:** Não é descrita como insuficiência multiarticular principal; a posição altera linha de ação e capacidade. Não é inferida por uma regra única; cápsula, escápula e estruturas adjacentes também limitam a amplitude.
- **Mecânica:** As porções anterior, média e posterior geram vetores diferentes; o vetor resultante depende da posição e da porção ativa. Muda com o plano e a amplitude de elevação; não se atribui um pico universal. A capacidade muda com elevação e rotação umeral, comprimento muscular, velocidade e coativação glenoumeral.
- **Cadeia aberta/fechada:** Com o tronco e a escápula relativamente fixos, produz ou controla movimento do úmero e translação glenoumeral. Com a mão fixa, contribui para rigidez glenoumeral e controlo do tronco sobre o membro.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. As porções anterior, média e posterior possuem linhas de ação diferentes; a abdução líquida requer coordenação escapular e da coifa.
- **Claims:** claim_000189, claim_000190, claim_000191, claim_000192, claim_000193, claim_000194

### Relações músculo-ação

- `shoulder_abduction` em `glenohumeral_joint`: `principal_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_flexion` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_extension` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_horizontal_abduction` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução horizontal do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_horizontal_adduction` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução horizontal do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Primeiro interósseo dorsal da mão (`dorsal_interosseous_hand_1`)

- **Latim / inglês:** musculus interosseus dorsalis manus I / first dorsal interosseous of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_central` / `deep`
- **Origem:** Faces adjacentes dos metacárpicos I e II.
- **Inserção:** Base radial da falange proximal e expansão extensora do dedo II.
- **Arquitetura e fibras:** `bipennate_set`. Conjunto de músculos bipenados com orientação específica por raio digital.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com abdução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com abdução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000257, claim_000258, claim_000259, claim_000260, claim_000261, claim_000262, claim_000263, claim_000264

### Relações músculo-ação

- `finger_mcp_abduction` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Segundo interósseo dorsal da mão (`dorsal_interosseous_hand_2`)

- **Latim / inglês:** musculus interosseus dorsalis manus II / second dorsal interosseous of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_central` / `deep`
- **Origem:** Faces adjacentes dos metacárpicos II e III.
- **Inserção:** Base radial da falange proximal e expansão extensora do dedo III.
- **Arquitetura e fibras:** `bipennate_set`. Conjunto de músculos bipenados com orientação específica por raio digital.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com abdução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com abdução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000269, claim_000270, claim_000271, claim_000272, claim_000273, claim_000274, claim_000275, claim_000276

### Relações músculo-ação

- `finger_mcp_abduction` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Terceiro interósseo dorsal da mão (`dorsal_interosseous_hand_3`)

- **Latim / inglês:** musculus interosseus dorsalis manus III / third dorsal interosseous of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_central` / `deep`
- **Origem:** Faces adjacentes dos metacárpicos III e IV.
- **Inserção:** Base ulnar da falange proximal e expansão extensora do dedo III.
- **Arquitetura e fibras:** `bipennate_set`. Conjunto de músculos bipenados com orientação específica por raio digital.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com abdução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com abdução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000281, claim_000282, claim_000283, claim_000284, claim_000285, claim_000286, claim_000287, claim_000288

### Relações músculo-ação

- `finger_mcp_abduction` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Quarto interósseo dorsal da mão (`dorsal_interosseous_hand_4`)

- **Latim / inglês:** musculus interosseus dorsalis manus IV / fourth dorsal interosseous of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_central` / `deep`
- **Origem:** Faces adjacentes dos metacárpicos IV e V.
- **Inserção:** Base ulnar da falange proximal e expansão extensora do dedo IV.
- **Arquitetura e fibras:** `bipennate_set`. Conjunto de músculos bipenados com orientação específica por raio digital.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com abdução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com abdução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000293, claim_000294, claim_000295, claim_000296, claim_000297, claim_000298, claim_000299, claim_000300

### Relações músculo-ação

- `finger_mcp_abduction` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor radial curto do carpo (`extensor_carpi_radialis_brevis`)

- **Latim / inglês:** musculus extensor carpi radialis brevis / extensor carpi radialis brevis
- **Região / grupo / camada:** `forearm` / `posterior_forearm_superficial` / `superficial`
- **Origem:** Epicôndilo lateral.
- **Inserção:** Base dorsal do metacárpico III.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** radiocarpal_joint, midcarpal_joint; `biarticular`
- **Inervação:** Ramo profundo do nervo radial.
- **Encurtamento aproximado:** Posição combinada compatível com extensão do punho e desvio radial do punho; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão do punho e desvio ulnar do punho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, midcarpal_joint, em posições compatíveis com extensão do punho e desvio radial do punho. Pode ocorrer quando as articulações radiocarpal_joint, midcarpal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa relativamente ao punho determina flexão, extensão ou desvio; não se presume ação digital. Varia com a posição radiocárpica e a trajetória sob retináculos; não foi agregado num valor único. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: radiocarpal_joint, midcarpal_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000305, claim_000306, claim_000307, claim_000308, claim_000309, claim_000310, claim_000311

### Relações músculo-ação

- `wrist_extension` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `wrist_radial_deviation` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir desvio radial do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor radial longo do carpo (`extensor_carpi_radialis_longus`)

- **Latim / inglês:** musculus extensor carpi radialis longus / extensor carpi radialis longus
- **Região / grupo / camada:** `forearm` / `posterior_forearm_superficial` / `superficial`
- **Origem:** Crista supracondilar lateral.
- **Inserção:** Base dorsal do metacárpico II.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** radiocarpal_joint, midcarpal_joint; `biarticular`
- **Inervação:** Nervo radial.
- **Encurtamento aproximado:** Posição combinada compatível com extensão do punho e desvio radial do punho; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão do punho e desvio ulnar do punho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, midcarpal_joint, em posições compatíveis com extensão do punho e desvio radial do punho. Pode ocorrer quando as articulações radiocarpal_joint, midcarpal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa relativamente ao punho determina flexão, extensão ou desvio; não se presume ação digital. Varia com a posição radiocárpica e a trajetória sob retináculos; não foi agregado num valor único. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: radiocarpal_joint, midcarpal_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000314, claim_000315, claim_000316, claim_000317, claim_000318, claim_000319, claim_000320

### Relações músculo-ação

- `wrist_extension` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `wrist_radial_deviation` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir desvio radial do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor ulnar do carpo (`extensor_carpi_ulnaris`)

- **Latim / inglês:** musculus extensor carpi ulnaris / extensor carpi ulnaris
- **Região / grupo / camada:** `forearm` / `posterior_forearm_superficial` / `superficial`
- **Origem:** Epicôndilo lateral e bordo posterior da ulna.
- **Inserção:** Base dorsal do metacárpico V.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** radiocarpal_joint, midcarpal_joint; `biarticular`
- **Inervação:** Nervo interósseo posterior.
- **Encurtamento aproximado:** Posição combinada compatível com extensão do punho e desvio ulnar do punho; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão do punho e desvio radial do punho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, midcarpal_joint, em posições compatíveis com extensão do punho e desvio ulnar do punho. Pode ocorrer quando as articulações radiocarpal_joint, midcarpal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa relativamente ao punho determina flexão, extensão ou desvio; não se presume ação digital. Varia com a posição radiocárpica e a trajetória sob retináculos; não foi agregado num valor único. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: radiocarpal_joint, midcarpal_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000323, claim_000324, claim_000325, claim_000326, claim_000327, claim_000328, claim_000329

### Relações músculo-ação

- `wrist_extension` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `wrist_ulnar_deviation` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir desvio ulnar do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor do dedo mínimo (`extensor_digiti_minimi`)

- **Latim / inglês:** musculus extensor digiti minimi / extensor digiti minimi
- **Região / grupo / camada:** `forearm` / `posterior_forearm_superficial` / `superficial`
- **Origem:** Epicôndilo lateral.
- **Inserção:** Expansão extensora do dedo V.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** radiocarpal_joint, finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo interósseo posterior.
- **Encurtamento aproximado:** Combinação digital compatível com extensão do punho, extensão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com extensão do punho, extensão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações radiocarpal_joint, finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000332, claim_000333, claim_000334, claim_000335, claim_000336, claim_000337, claim_000338, claim_000339, claim_000340

### Relações músculo-ação

- `wrist_extension` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_extension` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor dos dedos (`extensor_digitorum`)

- **Latim / inglês:** musculus extensor digitorum / extensor digitorum
- **Região / grupo / camada:** `forearm` / `posterior_forearm_superficial` / `superficial`
- **Origem:** Epicôndilo lateral.
- **Inserção:** Expansões extensoras dos dedos II–V.
- **Arquitetura e fibras:** `multipennate`. Múltiplos conjuntos de fascículos oblíquos inserem-se em septos ou tendões internos.
- **Articulações e classe:** radiocarpal_joint, finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo interósseo posterior.
- **Encurtamento aproximado:** Combinação digital compatível com extensão do punho, extensão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com extensão do punho, extensão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações radiocarpal_joint, finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000345, claim_000346, claim_000347, claim_000348, claim_000349, claim_000350, claim_000351, claim_000352, claim_000353

### Relações músculo-ação

- `wrist_extension` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_extension` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor do indicador (`extensor_indicis`)

- **Latim / inglês:** musculus extensor indicis / extensor indicis
- **Região / grupo / camada:** `forearm` / `posterior_forearm_deep` / `deep`
- **Origem:** Face posterior distal da ulna e membrana interóssea.
- **Inserção:** Expansão extensora do dedo II.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** radiocarpal_joint, finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo interósseo posterior.
- **Encurtamento aproximado:** Combinação digital compatível com extensão do punho, extensão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com extensão do punho, extensão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações radiocarpal_joint, finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000402, claim_000403, claim_000404, claim_000405, claim_000406, claim_000407, claim_000408, claim_000409, claim_000410

### Relações músculo-ação

- `wrist_extension` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_extension` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor curto do polegar (`extensor_pollicis_brevis`)

- **Latim / inglês:** musculus extensor pollicis brevis / extensor pollicis brevis
- **Região / grupo / camada:** `forearm` / `posterior_forearm_deep` / `deep`
- **Origem:** Face posterior do rádio e membrana interóssea.
- **Inserção:** Base da falange proximal do polegar.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** radiocarpal_joint, thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint; `multiarticular`
- **Inervação:** Nervo interósseo posterior.
- **Encurtamento aproximado:** Combinação digital compatível com desvio radial do punho, extensão carpometacárpica do polegar e extensão metacarpofalângica do polegar; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint, em posições compatíveis com desvio radial do punho, extensão carpometacárpica do polegar e extensão metacarpofalângica do polegar. Pode ocorrer quando as articulações radiocarpal_joint, thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000415, claim_000416, claim_000417, claim_000418, claim_000419, claim_000420, claim_000421, claim_000422

### Relações músculo-ação

- `wrist_radial_deviation` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir desvio radial do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_cmc_extension` em `thumb_carpometacarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_carpometacarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão carpometacárpica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_mcp_extension` em `thumb_metacarpophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_metacarpophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão metacarpofalângica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Extensor longo do polegar (`extensor_pollicis_longus`)

- **Latim / inglês:** musculus extensor pollicis longus / extensor pollicis longus
- **Região / grupo / camada:** `forearm` / `posterior_forearm_deep` / `deep`
- **Origem:** Face posterior da ulna e membrana interóssea.
- **Inserção:** Base da falange distal do polegar.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** radiocarpal_joint, thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint, thumb_interphalangeal_joint; `multiarticular`
- **Inervação:** Nervo interósseo posterior.
- **Encurtamento aproximado:** Combinação digital compatível com extensão do punho, extensão carpometacárpica do polegar, extensão metacarpofalângica do polegar e extensão interfalângica do polegar; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint, thumb_interphalangeal_joint, em posições compatíveis com extensão do punho, extensão carpometacárpica do polegar, extensão metacarpofalângica do polegar e extensão interfalângica do polegar. Pode ocorrer quando as articulações radiocarpal_joint, thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint, thumb_interphalangeal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000426, claim_000427, claim_000428, claim_000429, claim_000430, claim_000431, claim_000432, claim_000433, claim_000434

### Relações músculo-ação

- `wrist_extension` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_cmc_extension` em `thumb_carpometacarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_carpometacarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão carpometacárpica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_mcp_extension` em `thumb_metacarpophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_metacarpophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão metacarpofalângica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_ip_extension` em `thumb_interphalangeal_joint`: `principal_contributor`. A contribuição varia ao longo de thumb_interphalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor radial do carpo (`flexor_carpi_radialis`)

- **Latim / inglês:** musculus flexor carpi radialis / flexor carpi radialis
- **Região / grupo / camada:** `forearm` / `anterior_forearm_superficial` / `superficial`
- **Origem:** Epicôndilo medial do úmero.
- **Inserção:** Bases dos metacárpicos II e III.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** radiocarpal_joint, midcarpal_joint; `biarticular`
- **Inervação:** Nervo mediano.
- **Encurtamento aproximado:** Posição combinada compatível com flexão do punho e desvio radial do punho; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão do punho e desvio ulnar do punho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, midcarpal_joint, em posições compatíveis com flexão do punho e desvio radial do punho. Pode ocorrer quando as articulações radiocarpal_joint, midcarpal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa relativamente ao punho determina flexão, extensão ou desvio; não se presume ação digital. Varia com a posição radiocárpica e a trajetória sob retináculos; não foi agregado num valor único. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: radiocarpal_joint, midcarpal_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000495, claim_000496, claim_000497, claim_000498, claim_000499, claim_000500, claim_000501

### Relações músculo-ação

- `wrist_flexion` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `wrist_radial_deviation` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir desvio radial do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor ulnar do carpo (`flexor_carpi_ulnaris`)

- **Latim / inglês:** musculus flexor carpi ulnaris / flexor carpi ulnaris
- **Região / grupo / camada:** `forearm` / `anterior_forearm_superficial` / `superficial`
- **Origem:** Epicôndilo medial, olécrano e bordo posterior da ulna.
- **Inserção:** Pisiforme, hâmulo do hamato e base do metacárpico V.
- **Arquitetura e fibras:** `fusiform_two_headed`. Duas cabeças convergem para uma unidade distal comum, com orientações proximais diferentes.
- **Articulações e classe:** radiocarpal_joint, midcarpal_joint; `biarticular`
- **Inervação:** Nervo ulnar.
- **Encurtamento aproximado:** Posição combinada compatível com flexão do punho e desvio ulnar do punho; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão do punho e desvio radial do punho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, midcarpal_joint, em posições compatíveis com flexão do punho e desvio ulnar do punho. Pode ocorrer quando as articulações radiocarpal_joint, midcarpal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa relativamente ao punho determina flexão, extensão ou desvio; não se presume ação digital. Varia com a posição radiocárpica e a trajetória sob retináculos; não foi agregado num valor único. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: radiocarpal_joint, midcarpal_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000504, claim_000505, claim_000506, claim_000507, claim_000508, claim_000509, claim_000510

### Relações músculo-ação

- `wrist_flexion` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `wrist_ulnar_deviation` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir desvio ulnar do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor curto do dedo mínimo da mão (`flexor_digiti_minimi_brevis_hand`)

- **Latim / inglês:** musculus flexor digiti minimi brevis manus / flexor digiti minimi brevis of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_hypothenar` / `superficial`
- **Origem:** Hâmulo do hamato e retináculo dos flexores.
- **Inserção:** Base da falange proximal do dedo V.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** finger_metacarpophalangeal_joints; `monoarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metacarpofalângica dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000520, claim_000521, claim_000522, claim_000523, claim_000524, claim_000525

### Relações músculo-ação

- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor profundo dos dedos (`flexor_digitorum_profundus`)

- **Latim / inglês:** musculus flexor digitorum profundus / flexor digitorum profundus
- **Região / grupo / camada:** `forearm` / `anterior_forearm_deep` / `deep`
- **Origem:** Ulna proximal e membrana interóssea.
- **Inserção:** Bases das falanges distais dos dedos II–V.
- **Arquitetura e fibras:** `multipennate`. Múltiplos conjuntos de fascículos oblíquos inserem-se em septos ou tendões internos.
- **Articulações e classe:** radiocarpal_joint, finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo interósseo anterior para II–III; nervo ulnar para IV–V.
- **Encurtamento aproximado:** Combinação digital compatível com flexão do punho, flexão metacarpofalângica dos dedos II–V, flexão interfalângica proximal dos dedos II–V e flexão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Flexão simultânea do punho e dos dedos pode reduzir a capacidade de flexão digital. Extensão simultânea do punho e das articulações digitais pode aumentar a tensão passiva.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000551, claim_000552, claim_000553, claim_000554, claim_000555, claim_000556, claim_000557, claim_000558, claim_000559

### Relações músculo-ação

- `wrist_flexion` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_flexion` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_flexion` em `finger_distal_interphalangeal_joints`: `principal_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor superficial dos dedos (`flexor_digitorum_superficialis`)

- **Latim / inglês:** musculus flexor digitorum superficialis / flexor digitorum superficialis
- **Região / grupo / camada:** `forearm` / `anterior_forearm_intermediate` / `intermediate`
- **Origem:** Epicôndilo medial, processo coronoide e bordo anterior do rádio.
- **Inserção:** Falanges médias dos dedos II–V.
- **Arquitetura e fibras:** `multipennate`. Múltiplos conjuntos de fascículos oblíquos inserem-se em septos ou tendões internos.
- **Articulações e classe:** elbow_joint, radiocarpal_joint, finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo mediano.
- **Encurtamento aproximado:** Combinação digital compatível com flexão do punho, flexão do cotovelo, flexão metacarpofalângica dos dedos II–V e flexão interfalângica proximal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Flexão simultânea do punho e dos dedos pode reduzir a capacidade de flexão digital. Extensão simultânea do punho e das articulações digitais pode aumentar a tensão passiva.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000564, claim_000565, claim_000566, claim_000567, claim_000568, claim_000569, claim_000570, claim_000571, claim_000572

### Relações músculo-ação

- `wrist_flexion` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `elbow_flexion` em `elbow_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de elbow_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do cotovelo quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_flexion` em `finger_proximal_interphalangeal_joints`: `principal_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor curto do polegar (`flexor_pollicis_brevis`)

- **Latim / inglês:** musculus flexor pollicis brevis / flexor pollicis brevis
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_thenar` / `superficial`
- **Origem:** Retináculo dos flexores e ossos do carpo adjacentes.
- **Inserção:** Base da falange proximal do polegar.
- **Arquitetura e fibras:** `two_headed`. Duas cabeças com orientação própria convergem para uma unidade funcional comum.
- **Articulações e classe:** thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint; `biarticular`
- **Inervação:** Nervo mediano; cabeça profunda frequentemente ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com oposição do polegar e flexão metacarpofalângica do polegar; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint, em posições compatíveis com oposição do polegar e flexão metacarpofalângica do polegar. Pode ocorrer quando as articulações thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000597, claim_000598, claim_000599, claim_000600, claim_000601, claim_000602, claim_000603

### Relações músculo-ação

- `thumb_opposition` em `thumb_carpometacarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_carpometacarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir oposição do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_mcp_flexion` em `thumb_metacarpophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_metacarpophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Flexor longo do polegar (`flexor_pollicis_longus`)

- **Latim / inglês:** musculus flexor pollicis longus / flexor pollicis longus
- **Região / grupo / camada:** `forearm` / `anterior_forearm_deep` / `deep`
- **Origem:** Face anterior do rádio e membrana interóssea.
- **Inserção:** Base da falange distal do polegar.
- **Arquitetura e fibras:** `unipennate`. Fascículos oblíquos inserem-se num lado do tendão.
- **Articulações e classe:** radiocarpal_joint, thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint, thumb_interphalangeal_joint; `multiarticular`
- **Inervação:** Nervo interósseo anterior.
- **Encurtamento aproximado:** Combinação digital compatível com flexão do punho, flexão carpometacárpica do polegar, flexão metacarpofalângica do polegar e flexão interfalângica do polegar; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de radiocarpal_joint, thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint, thumb_interphalangeal_joint, em posições compatíveis com flexão do punho, flexão carpometacárpica do polegar, flexão metacarpofalângica do polegar e flexão interfalângica do polegar. Pode ocorrer quando as articulações radiocarpal_joint, thumb_carpometacarpal_joint, thumb_metacarpophalangeal_joint, thumb_interphalangeal_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000606, claim_000607, claim_000608, claim_000609, claim_000610, claim_000611, claim_000612, claim_000613, claim_000614

### Relações músculo-ação

- `wrist_flexion` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_cmc_flexion` em `thumb_carpometacarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_carpometacarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão carpometacárpica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_mcp_flexion` em `thumb_metacarpophalangeal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_metacarpophalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_ip_flexion` em `thumb_interphalangeal_joint`: `principal_contributor`. A contribuição varia ao longo de thumb_interphalangeal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão interfalângica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Infraespinhoso (`infraspinatus`)

- **Latim / inglês:** musculus infraspinatus / infraspinatus
- **Região / grupo / camada:** `shoulder` / `rotator_cuff` / `deep`
- **Origem:** Fossa infraespinhosa da escápula.
- **Inserção:** Faceta média do tubérculo maior do úmero.
- **Arquitetura e fibras:** `multipennate`. Fascículos convergem lateralmente para o tendão da coifa posterior.
- **Articulações e classe:** glenohumeral_joint; `monoarticular`
- **Inervação:** Nervo supraescapular.
- **Encurtamento aproximado:** Varia entre porções e com a orientação do úmero e da escápula; não existe uma posição única para o músculo completo.
- **Alongamento aproximado:** Varia entre porções e com o plano de elevação, rotação umeral e posição escapular.
- **Insuficiência ativa/passiva:** Não é descrita como insuficiência multiarticular principal; a posição altera linha de ação e capacidade. Não é inferida por uma regra única; cápsula, escápula e estruturas adjacentes também limitam a amplitude.
- **Mecânica:** A tração da coifa combina rotação externa e controlo posterior dependentes da posição; varia com a orientação do úmero e da escápula. O braço rotacional muda com a elevação e rotação umeral; nenhum máximo angular foi fixado. A capacidade muda com elevação e rotação umeral, comprimento muscular, velocidade e coativação glenoumeral.
- **Cadeia aberta/fechada:** Com o tronco e a escápula relativamente fixos, produz ou controla movimento do úmero e translação glenoumeral. Com a mão fixa, contribui para rigidez glenoumeral e controlo do tronco sobre o membro.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000718, claim_000719, claim_000720, claim_000721, claim_000722, claim_000723, claim_000724

### Relações músculo-ação

- `shoulder_external_rotation` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação externa do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Grande dorsal (`latissimus_dorsi`)

- **Latim / inglês:** musculus latissimus dorsi / latissimus dorsi
- **Região / grupo / camada:** `shoulder` / `thoracohumeral_muscles` / `superficial`
- **Origem:** Processos espinhosos torácicos inferiores, fáscia toracolombar, crista ilíaca e costelas inferiores.
- **Inserção:** Soalho do sulco intertubercular do úmero.
- **Arquitetura e fibras:** `convergent`. Fibras em leque convergem de uma origem ampla para uma inserção mais estreita.
- **Articulações e classe:** glenohumeral_joint; `monoarticular`
- **Inervação:** Nervo toracodorsal.
- **Encurtamento aproximado:** Posição combinada compatível com extensão do ombro, adução do ombro e rotação interna do ombro; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão do ombro, abdução do ombro e rotação externa do ombro; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A linha de tração é inferida das fixações e deve ser interpretada para extensão do ombro, adução do ombro e rotação interna do ombro na posição e tarefa declaradas. O braço de momento pode mudar de magnitude ou sinal com a posição; não foi aprovado um valor ou máximo angular universal. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: glenohumeral_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000784, claim_000785, claim_000786, claim_000787, claim_000788, claim_000789

### Relações músculo-ação

- `shoulder_extension` em `glenohumeral_joint`: `principal_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_adduction` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_internal_rotation` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação interna do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Elevador da escápula (`levator_scapulae`)

- **Latim / inglês:** musculus levator scapulae / levator scapulae
- **Região / grupo / camada:** `pectoral_girdle` / `scapular_elevators_retractors` / `intermediate`
- **Origem:** Tubérculos posteriores dos processos transversos C1–C4.
- **Inserção:** Margem medial da escápula acima da espinha.
- **Arquitetura e fibras:** `parallel`. Fascículos predominantemente paralelos seguem a direção geral entre as fixações.
- **Articulações e classe:** cervical_spine; `monoarticular`
- **Inervação:** Nervo dorsal da escápula e ramos C3–C4.
- **Encurtamento aproximado:** Posições escapulares compatíveis com elevação da escápula, rotação inferior da escápula e flexão lateral cervical; a orientação clavicular e torácica modifica o resultado.
- **Alongamento aproximado:** Posições escapulares opostas às ações registadas, condicionadas pela forma do tórax, posição cervical e orientação do membro superior.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração deve ser resolvida sobre escápula, clavícula e tórax; as componentes variam com a orientação escapular. A vantagem para translação ou rotação escapular muda com a posição; não foi quantificada no catálogo. A capacidade resulta da orientação escapular ou clavicular, comprimento fascicular, apoio do membro e momento externo.
- **Cadeia aberta/fechada:** Com o tórax relativamente fixo, desloca ou controla escápula e clavícula para orientar a glenoide. Com a mão fixa, controla a escápula sobre o tórax e pode contribuir para mover ou estabilizar o tronco.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000793, claim_000794, claim_000795, claim_000796, claim_000797, claim_000798, claim_000799, claim_000800

### Relações músculo-ação

- `scapular_elevation` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir elevação escapular quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `scapular_downward_rotation` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação inferior da escápula quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Primeiro lumbrical da mão (`lumbrical_hand_1`)

- **Latim / inglês:** musculus lumbricalis manus I / first lumbrical of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_central` / `deep`
- **Origem:** Face radial do tendão do flexor profundo destinado ao dedo II.
- **Inserção:** Margem radial da expansão extensora do dedo II.
- **Arquitetura e fibras:** `fusiform_set`. Conjunto de pequenos ventres fusiformes, cada um associado ao respetivo raio digital.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo mediano.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000918, claim_000919, claim_000920, claim_000921, claim_000922, claim_000923, claim_000924, claim_000925

### Relações músculo-ação

- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Segundo lumbrical da mão (`lumbrical_hand_2`)

- **Latim / inglês:** musculus lumbricalis manus II / second lumbrical of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_central` / `deep`
- **Origem:** Face radial do tendão do flexor profundo destinado ao dedo III.
- **Inserção:** Margem radial da expansão extensora do dedo III.
- **Arquitetura e fibras:** `fusiform_set`. Conjunto de pequenos ventres fusiformes, cada um associado ao respetivo raio digital.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Nervo mediano.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000929, claim_000930, claim_000931, claim_000932, claim_000933, claim_000934, claim_000935, claim_000936

### Relações músculo-ação

- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Terceiro lumbrical da mão (`lumbrical_hand_3`)

- **Latim / inglês:** musculus lumbricalis manus III / third lumbrical of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_central` / `deep`
- **Origem:** Faces adjacentes dos tendões do flexor profundo destinados aos dedos III e IV.
- **Inserção:** Margem radial da expansão extensora do dedo IV.
- **Arquitetura e fibras:** `fusiform_set`. Conjunto de pequenos ventres fusiformes, cada um associado ao respetivo raio digital.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000940, claim_000941, claim_000942, claim_000943, claim_000944, claim_000945, claim_000946, claim_000947

### Relações músculo-ação

- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Quarto lumbrical da mão (`lumbrical_hand_4`)

- **Latim / inglês:** musculus lumbricalis manus IV / fourth lumbrical of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_central` / `deep`
- **Origem:** Faces adjacentes dos tendões do flexor profundo destinados aos dedos IV e V.
- **Inserção:** Margem radial da expansão extensora do dedo V.
- **Arquitetura e fibras:** `fusiform_set`. Conjunto de pequenos ventres fusiformes, cada um associado ao respetivo raio digital.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000951, claim_000952, claim_000953, claim_000954, claim_000955, claim_000956, claim_000957, claim_000958

### Relações músculo-ação

- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Oponente do dedo mínimo (`opponens_digiti_minimi`)

- **Latim / inglês:** musculus opponens digiti minimi / opponens digiti minimi
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_hypothenar` / `deep`
- **Origem:** Hâmulo do hamato e retináculo dos flexores.
- **Inserção:** Bordo medial do metacárpico V.
- **Arquitetura e fibras:** `parallel`. Fascículos predominantemente paralelos seguem a direção geral entre as fixações.
- **Articulações e classe:** fifth_carpometacarpal_joint; `monoarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com oposição do quinto metacárpico; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001016, claim_001017, claim_001018, claim_001019, claim_001020, claim_001021

### Relações músculo-ação

- `fifth_cmc_opposition` em `fifth_carpometacarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de fifth_carpometacarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir oposição do quinto metacárpico quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Oponente do polegar (`opponens_pollicis`)

- **Latim / inglês:** musculus opponens pollicis / opponens pollicis
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_thenar` / `deep`
- **Origem:** Retináculo dos flexores e trapézio.
- **Inserção:** Bordo lateral do metacárpico I.
- **Arquitetura e fibras:** `parallel`. Fascículos predominantemente paralelos seguem a direção geral entre as fixações.
- **Articulações e classe:** thumb_carpometacarpal_joint; `monoarticular`
- **Inervação:** Ramo recorrente do nervo mediano.
- **Encurtamento aproximado:** Combinação digital compatível com oposição do polegar e flexão carpometacárpica do polegar; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001023, claim_001024, claim_001025, claim_001026, claim_001027, claim_001028

### Relações músculo-ação

- `thumb_opposition` em `thumb_carpometacarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_carpometacarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir oposição do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `thumb_cmc_flexion` em `thumb_carpometacarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thumb_carpometacarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão carpometacárpica do polegar quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Primeiro interósseo palmar da mão (`palmar_interosseous_hand_1`)

- **Latim / inglês:** musculus interosseus palmaris manus I / first palmar interosseous of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_central` / `deep`
- **Origem:** Face ulnar do metacárpico II.
- **Inserção:** Base ulnar da falange proximal e expansão extensora do dedo II.
- **Arquitetura e fibras:** `unipennate_set`. Conjunto de músculos unipenados com orientação específica por raio digital.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com adução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com adução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001031, claim_001032, claim_001033, claim_001034, claim_001035, claim_001036, claim_001037, claim_001038

### Relações músculo-ação

- `finger_mcp_adduction` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Segundo interósseo palmar da mão (`palmar_interosseous_hand_2`)

- **Latim / inglês:** musculus interosseus palmaris manus II / second palmar interosseous of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_central` / `deep`
- **Origem:** Face radial do metacárpico IV.
- **Inserção:** Base radial da falange proximal e expansão extensora do dedo IV.
- **Arquitetura e fibras:** `unipennate_set`. Conjunto de músculos unipenados com orientação específica por raio digital.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com adução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com adução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001043, claim_001044, claim_001045, claim_001046, claim_001047, claim_001048, claim_001049, claim_001050

### Relações músculo-ação

- `finger_mcp_adduction` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Terceiro interósseo palmar da mão (`palmar_interosseous_hand_3`)

- **Latim / inglês:** musculus interosseus palmaris manus III / third palmar interosseous of hand
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_central` / `deep`
- **Origem:** Face radial do metacárpico V.
- **Inserção:** Base radial da falange proximal e expansão extensora do dedo V.
- **Arquitetura e fibras:** `unipennate_set`. Conjunto de músculos unipenados com orientação específica por raio digital.
- **Articulações e classe:** finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints; `multiarticular`
- **Inervação:** Ramo profundo do nervo ulnar.
- **Encurtamento aproximado:** Combinação digital compatível com adução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V; punho ou tornozelo e raio específico devem ser declarados quando atravessados.
- **Alongamento aproximado:** Combinação oposta nas articulações efetivamente atravessadas; não se mistura polegar ou hálux com os restantes dedos.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints, em posições compatíveis com adução metacarpofalângica dos dedos II–V, flexão metacarpofalângica dos dedos II–V, extensão interfalângica proximal dos dedos II–V e extensão interfalângica distal dos dedos II–V. Pode ocorrer quando as articulações finger_metacarpophalangeal_joints, finger_proximal_interphalangeal_joints, finger_distal_interphalangeal_joints são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A trajetória tendinosa e o raio digital condicionam a direção; posição do punho altera a transmissão distal. Varia entre articulações do punho e dedos; não foi agregado num valor único. A capacidade depende da posição do punho, raio digital, excursão tendinosa, contacto e força de preensão ou apoio.
- **Cadeia aberta/fechada:** Com antebraço e punho relativamente fixos, move ou controla o raio digital correspondente. No apoio ou preensão, contribui para rigidez digital e transmissão de força sem deixar de depender do punho.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001055, claim_001056, claim_001057, claim_001058, claim_001059, claim_001060, claim_001061, claim_001062

### Relações músculo-ação

- `finger_mcp_adduction` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_mcp_flexion` em `finger_metacarpophalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_metacarpophalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão metacarpofalângica dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_pip_extension` em `finger_proximal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_proximal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica proximal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `finger_dip_extension` em `finger_distal_interphalangeal_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de finger_distal_interphalangeal_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão interfalângica distal dos dedos ii–v quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Palmar curto (`palmaris_brevis`)

- **Latim / inglês:** musculus palmaris brevis / palmaris brevis
- **Região / grupo / camada:** `wrist_hand` / `intrinsic_hand_hypothenar` / `superficial`
- **Origem:** Aponeurose palmar e retináculo dos flexores.
- **Inserção:** Pele da margem ulnar da mão.
- **Arquitetura e fibras:** `thin_parallel`. Lâmina fina de fibras predominantemente paralelas.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Ramo superficial do nervo ulnar.
- **Encurtamento aproximado:** Contração local que enruga e tensiona a pele hipotenar, sem posição articular única.
- **Alongamento aproximado:** Alongamento local da pele e fáscia hipotenar durante abertura da mão ou contacto palmar.
- **Insuficiência ativa/passiva:** Não aplicável como músculo multiarticular ou motor principal do punho e dedos. Não aplicável como regra articular; a mobilidade cutânea e fascial é local.
- **Mecânica:** A tração ocorre entre a aponeurose palmar e a pele hipotenar, sem vetor articular principal. Não aplicável como braço de momento do punho ou dedos. A tensão local depende do contacto palmar, mobilidade da pele hipotenar e intensidade da contração, sem perfil articular.
- **Cadeia aberta/fechada:** A classificação articular aberta não é aplicável; a ação é local sobre pele e fáscia hipotenar. O contacto palmar pode alterar a tensão local, sem transformar a função numa ação articular fechada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001067, claim_001068, claim_001069, claim_001070, claim_001071, claim_001072

### Relações músculo-ação

- `hypothenar_skin_tension` em ``: `regulator_or_stabilizer`. Depende da preensão, do contacto palmar e da tensão local da pele e fáscia hipotenares. A contração encurta localmente o palmar curto e enruga ou tensiona a pele hipotenar. O alongamento sob contacto palmar pode ser controlado localmente, sem ação articular principal aprovada.

## Palmar longo (`palmaris_longus`)

- **Latim / inglês:** musculus palmaris longus / palmaris longus
- **Região / grupo / camada:** `forearm` / `anterior_forearm_superficial` / `superficial`
- **Origem:** Epicôndilo medial do úmero.
- **Inserção:** Retináculo dos flexores e aponeurose palmar.
- **Arquitetura e fibras:** `fusiform_long_tendon`. Ventre fusiforme continua num tendão longo, que condiciona transmissão e excursão.
- **Articulações e classe:** radiocarpal_joint; `monoarticular`
- **Inervação:** Nervo mediano.
- **Encurtamento aproximado:** Posição combinada compatível com flexão do punho; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com extensão do punho; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A trajetória tendinosa relativamente ao punho determina flexão, extensão ou desvio; não se presume ação digital. Varia com a posição radiocárpica e a trajetória sob retináculos; não foi agregado num valor único. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: radiocarpal_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Frequentemente ausente unilateral ou bilateralmente. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001074, claim_001075, claim_001076, claim_001077, claim_001078, claim_001079

### Relações músculo-ação

- `wrist_flexion` em `radiocarpal_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de radiocarpal_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do punho quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Peitoral maior (`pectoralis_major`)

- **Latim / inglês:** musculus pectoralis major / pectoralis major
- **Região / grupo / camada:** `shoulder` / `thoracohumeral_muscles` / `superficial`
- **Origem:** Metade medial da clavícula, esterno, cartilagens costais superiores e aponeurose do oblíquo externo.
- **Inserção:** Lábio lateral do sulco intertubercular do úmero.
- **Arquitetura e fibras:** `convergent`. Fascículos claviculares e esternocostais convergem e torcem antes da inserção umeral; a linha de tração varia com a porção e a posição do braço.
- **Articulações e classe:** glenohumeral_joint; `monoarticular`
- **Inervação:** Nervos peitorais lateral e medial.
- **Encurtamento aproximado:** Posição combinada compatível com adução horizontal do ombro, adução do ombro, rotação interna do ombro e flexão do ombro; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com abdução horizontal do ombro, abdução do ombro, rotação externa do ombro e extensão do ombro; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A linha de tração é inferida das fixações e deve ser interpretada para adução horizontal do ombro, adução do ombro, rotação interna do ombro e flexão do ombro na posição e tarefa declaradas. O braço de momento pode mudar de magnitude ou sinal com a posição; não foi aprovado um valor ou máximo angular universal. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: glenohumeral_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001090, claim_001091, claim_001092, claim_001093, claim_001094, claim_001095

### Relações músculo-ação

- `shoulder_horizontal_adduction` em `glenohumeral_joint`: `principal_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução horizontal do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_adduction` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_internal_rotation` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação interna do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_flexion` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Peitoral menor (`pectoralis_minor`)

- **Latim / inglês:** musculus pectoralis minor / pectoralis minor
- **Região / grupo / camada:** `pectoral_girdle` / `scapular_protractors_stabilisers` / `deep`
- **Origem:** Costelas 3–5, junto às cartilagens costais.
- **Inserção:** Processo coracoide da escápula.
- **Arquitetura e fibras:** `triangular`. Fibras dispõem-se numa unidade triangular entre fixações de larguras diferentes.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo peitoral medial.
- **Encurtamento aproximado:** Posições escapulares compatíveis com protração da escápula, depressão da escápula e rotação inferior da escápula; a orientação clavicular e torácica modifica o resultado.
- **Alongamento aproximado:** Posições escapulares opostas às ações registadas, condicionadas pela forma do tórax, posição cervical e orientação do membro superior.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração deve ser resolvida sobre escápula, clavícula e tórax; as componentes variam com a orientação escapular. A vantagem para translação ou rotação escapular muda com a posição; não foi quantificada no catálogo. A capacidade resulta da orientação escapular ou clavicular, comprimento fascicular, apoio do membro e momento externo.
- **Cadeia aberta/fechada:** Com o tórax relativamente fixo, desloca ou controla escápula e clavícula para orientar a glenoide. Com a mão fixa, controla a escápula sobre o tórax e pode contribuir para mover ou estabilizar o tronco.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001100, claim_001101, claim_001102, claim_001103, claim_001104, claim_001105

### Relações músculo-ação

- `scapular_protraction` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir protração escapular quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `scapular_depression` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir depressão escapular quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `scapular_downward_rotation` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação inferior da escápula quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Pronador quadrado (`pronator_quadratus`)

- **Latim / inglês:** musculus pronator quadratus / pronator quadratus
- **Região / grupo / camada:** `forearm` / `anterior_forearm_deep` / `deep`
- **Origem:** Quarto distal da face anterior da ulna.
- **Inserção:** Quarto distal da face anterior do rádio.
- **Arquitetura e fibras:** `quadrate_parallel`. Fibras curtas e aproximadamente paralelas formam uma lâmina quadrangular.
- **Articulações e classe:** distal_radioulnar_joint; `monoarticular`
- **Inervação:** Nervo interósseo anterior.
- **Encurtamento aproximado:** Posição combinada compatível com pronação do antebraço; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com supinação do antebraço; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração deve ser resolvida em relação ao eixo longitudinal radioulnar do antebraço. A vantagem muda com a posição de pronação/supinação e com o ângulo do cotovelo quando atravessado; não foi fixado um máximo. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: distal_radioulnar_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001184, claim_001185, claim_001186, claim_001187, claim_001188, claim_001189

### Relações músculo-ação

- `forearm_pronation` em `distal_radioulnar_joint`: `principal_contributor`. A contribuição varia ao longo de distal_radioulnar_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir pronação do antebraço quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Pronador redondo (`pronator_teres`)

- **Latim / inglês:** musculus pronator teres / pronator teres
- **Região / grupo / camada:** `forearm` / `anterior_forearm_superficial` / `superficial`
- **Origem:** Epicôndilo medial e processo coronoide da ulna.
- **Inserção:** Face lateral do rádio, a meio do corpo.
- **Arquitetura e fibras:** `fusiform_two_headed`. Duas cabeças convergem para uma unidade distal comum, com orientações proximais diferentes.
- **Articulações e classe:** elbow_joint, proximal_radioulnar_joint; `biarticular`
- **Inervação:** Nervo mediano.
- **Encurtamento aproximado:** Posição combinada compatível com pronação do antebraço e flexão do cotovelo; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com supinação do antebraço e extensão do cotovelo; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Pode ocorrer quando o músculo é encurtado simultaneamente através de elbow_joint, proximal_radioulnar_joint, em posições compatíveis com pronação do antebraço e flexão do cotovelo. Pode ocorrer quando as articulações elbow_joint, proximal_radioulnar_joint são posicionadas simultaneamente no sentido oposto às ações registadas; não se infere amplitude individual.
- **Mecânica:** A tração deve ser resolvida em relação ao eixo longitudinal radioulnar do antebraço. A vantagem muda com a posição de pronação/supinação e com o ângulo do cotovelo quando atravessado; não foi fixado um máximo. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: elbow_joint, proximal_radioulnar_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001191, claim_001192, claim_001193, claim_001194, claim_001195, claim_001196, claim_001197

### Relações músculo-ação

- `forearm_pronation` em `proximal_radioulnar_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de proximal_radioulnar_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir pronação do antebraço quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `elbow_flexion` em `elbow_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de elbow_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do cotovelo quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Romboide maior (`rhomboid_major`)

- **Latim / inglês:** musculus rhomboideus major / rhomboid major
- **Região / grupo / camada:** `pectoral_girdle` / `scapular_elevators_retractors` / `intermediate`
- **Origem:** Processos espinhosos T2–T5.
- **Inserção:** Margem medial da escápula, da espinha ao ângulo inferior.
- **Arquitetura e fibras:** `parallel`. Fascículos predominantemente paralelos seguem a direção geral entre as fixações.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo dorsal da escápula.
- **Encurtamento aproximado:** Posições escapulares compatíveis com retração da escápula e rotação inferior da escápula; a orientação clavicular e torácica modifica o resultado.
- **Alongamento aproximado:** Posições escapulares opostas às ações registadas, condicionadas pela forma do tórax, posição cervical e orientação do membro superior.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração deve ser resolvida sobre escápula, clavícula e tórax; as componentes variam com a orientação escapular. A vantagem para translação ou rotação escapular muda com a posição; não foi quantificada no catálogo. A capacidade resulta da orientação escapular ou clavicular, comprimento fascicular, apoio do membro e momento externo.
- **Cadeia aberta/fechada:** Com o tórax relativamente fixo, desloca ou controla escápula e clavícula para orientar a glenoide. Com a mão fixa, controla a escápula sobre o tórax e pode contribuir para mover ou estabilizar o tronco.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001344, claim_001345, claim_001346, claim_001347, claim_001348, claim_001349

### Relações músculo-ação

- `scapular_retraction` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir retração escapular quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `scapular_downward_rotation` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação inferior da escápula quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Romboide menor (`rhomboid_minor`)

- **Latim / inglês:** musculus rhomboideus minor / rhomboid minor
- **Região / grupo / camada:** `pectoral_girdle` / `scapular_elevators_retractors` / `intermediate`
- **Origem:** Ligamento nucal e processos espinhosos C7–T1.
- **Inserção:** Extremidade medial da espinha da escápula.
- **Arquitetura e fibras:** `parallel`. Fascículos predominantemente paralelos seguem a direção geral entre as fixações.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo dorsal da escápula.
- **Encurtamento aproximado:** Posições escapulares compatíveis com retração da escápula e rotação inferior da escápula; a orientação clavicular e torácica modifica o resultado.
- **Alongamento aproximado:** Posições escapulares opostas às ações registadas, condicionadas pela forma do tórax, posição cervical e orientação do membro superior.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração deve ser resolvida sobre escápula, clavícula e tórax; as componentes variam com a orientação escapular. A vantagem para translação ou rotação escapular muda com a posição; não foi quantificada no catálogo. A capacidade resulta da orientação escapular ou clavicular, comprimento fascicular, apoio do membro e momento externo.
- **Cadeia aberta/fechada:** Com o tórax relativamente fixo, desloca ou controla escápula e clavícula para orientar a glenoide. Com a mão fixa, controla a escápula sobre o tórax e pode contribuir para mover ou estabilizar o tronco.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001352, claim_001353, claim_001354, claim_001355, claim_001356, claim_001357

### Relações músculo-ação

- `scapular_retraction` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir retração escapular quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `scapular_downward_rotation` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação inferior da escápula quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Serrátil anterior (`serratus_anterior`)

- **Latim / inglês:** musculus serratus anterior / serratus anterior
- **Região / grupo / camada:** `pectoral_girdle` / `scapular_protractors_stabilisers` / `deep`
- **Origem:** Faces externas das primeiras oito ou nove costelas.
- **Inserção:** Face costal da margem medial da escápula.
- **Arquitetura e fibras:** `segmented_parallel`. Digitações costais convergem para o bordo medial da escápula; as regiões superior e inferior diferem na orientação e no contributo rotacional.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo torácico longo.
- **Encurtamento aproximado:** Posições escapulares compatíveis com protração da escápula e rotação superior da escápula; a orientação clavicular e torácica modifica o resultado.
- **Alongamento aproximado:** Posições escapulares opostas às ações registadas, condicionadas pela forma do tórax, posição cervical e orientação do membro superior.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração deve ser resolvida sobre escápula, clavícula e tórax; as componentes variam com a orientação escapular. A vantagem para translação ou rotação escapular muda com a posição; não foi quantificada no catálogo. A capacidade resulta da orientação escapular ou clavicular, comprimento fascicular, apoio do membro e momento externo.
- **Cadeia aberta/fechada:** Com o tórax relativamente fixo, desloca ou controla escápula e clavícula para orientar a glenoide. Com a mão fixa, controla a escápula sobre o tórax e pode contribuir para mover ou estabilizar o tronco.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. Mantém a escápula aplicada ao tórax e integra um par de forças com o trapézio; o papel muda com o ângulo de elevação do braço.
- **Claims:** claim_001452, claim_001453, claim_001454, claim_001455, claim_001456, claim_001457, claim_001458, claim_001459

### Relações músculo-ação

- `scapular_protraction` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir protração escapular quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `scapular_upward_rotation` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação superior da escápula quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Subclávio (`subclavius`)

- **Latim / inglês:** musculus subclavius / subclavius
- **Região / grupo / camada:** `pectoral_girdle` / `scapular_protractors_stabilisers` / `deep`
- **Origem:** Junção da primeira costela com a cartilagem costal.
- **Inserção:** Sulco do subclávio na face inferior da clavícula.
- **Arquitetura e fibras:** `parallel`. Fascículos predominantemente paralelos seguem a direção geral entre as fixações.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo do subclávio.
- **Encurtamento aproximado:** Depressão ou fixação da clavícula relativamente à primeira costela, dependente da posição esternoclavicular.
- **Alongamento aproximado:** Elevação clavicular relativa à primeira costela, sem definir um máximo de alongamento universal.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração dirige a clavícula medial e inferiormente em relação à primeira costela. A vantagem para depressão ou fixação clavicular varia com a posição esternoclavicular; não foi quantificada. A capacidade resulta da orientação escapular ou clavicular, comprimento fascicular, apoio do membro e momento externo.
- **Cadeia aberta/fechada:** Com o tórax relativamente fixo, pode deprimir ou estabilizar a clavícula na articulação esternoclavicular. Com o membro superior apoiado, a carga da cintura escapular pode ser transmitida à clavícula e primeira costela.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001544, claim_001545, claim_001546, claim_001547, claim_001548, claim_001549

### Relações músculo-ação

- `clavicular_depression` em `sternoclavicular_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de sternoclavicular_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir depressão da clavícula quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Subescapular (`subscapularis`)

- **Latim / inglês:** musculus subscapularis / subscapularis
- **Região / grupo / camada:** `shoulder` / `rotator_cuff` / `deep`
- **Origem:** Fossa subescapular.
- **Inserção:** Tubérculo menor do úmero.
- **Arquitetura e fibras:** `multipennate`. Fascículos multipenados convergem lateralmente na face anterior da escápula.
- **Articulações e classe:** glenohumeral_joint; `monoarticular`
- **Inervação:** Nervos subescapulares superior e inferior.
- **Encurtamento aproximado:** Varia entre porções e com a orientação do úmero e da escápula; não existe uma posição única para o músculo completo.
- **Alongamento aproximado:** Varia entre porções e com o plano de elevação, rotação umeral e posição escapular.
- **Insuficiência ativa/passiva:** Não é descrita como insuficiência multiarticular principal; a posição altera linha de ação e capacidade. Não é inferida por uma regra única; cápsula, escápula e estruturas adjacentes também limitam a amplitude.
- **Mecânica:** A tração da coifa combina rotação interna e controlo anterior dependentes da posição; varia com a orientação do úmero e da escápula. O braço rotacional muda com a elevação e rotação umeral; nenhum máximo angular foi fixado. A capacidade muda com elevação e rotação umeral, comprimento muscular, velocidade e coativação glenoumeral.
- **Cadeia aberta/fechada:** Com o tronco e a escápula relativamente fixos, produz ou controla movimento do úmero e translação glenoumeral. Com a mão fixa, contribui para rigidez glenoumeral e controlo do tronco sobre o membro.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001559, claim_001560, claim_001561, claim_001562, claim_001563, claim_001564, claim_001565

### Relações músculo-ação

- `shoulder_internal_rotation` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação interna do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_adduction` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Supinador (`supinator`)

- **Latim / inglês:** musculus supinator / supinator
- **Região / grupo / camada:** `forearm` / `posterior_forearm_deep` / `deep`
- **Origem:** Epicôndilo lateral, ligamentos colateral radial e anular, crista do supinador da ulna.
- **Inserção:** Terço proximal do rádio.
- **Arquitetura e fibras:** `broad`. Fascículos amplos com direção variável entre as fixações.
- **Articulações e classe:** proximal_radioulnar_joint; `monoarticular`
- **Inervação:** Ramo profundo do nervo radial.
- **Encurtamento aproximado:** Posição combinada compatível com supinação do antebraço; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com pronação do antebraço; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração deve ser resolvida em relação ao eixo longitudinal radioulnar do antebraço. A vantagem muda com a posição de pronação/supinação e com o ângulo do cotovelo quando atravessado; não foi fixado um máximo. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: proximal_radioulnar_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001582, claim_001583, claim_001584, claim_001585, claim_001586, claim_001587

### Relações músculo-ação

- `forearm_supination` em `proximal_radioulnar_joint`: `principal_contributor`. A contribuição varia ao longo de proximal_radioulnar_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir supinação do antebraço quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Supraespinhoso (`supraspinatus`)

- **Latim / inglês:** musculus supraspinatus / supraspinatus
- **Região / grupo / camada:** `shoulder` / `rotator_cuff` / `deep`
- **Origem:** Fossa supraespinhosa da escápula.
- **Inserção:** Faceta superior do tubérculo maior do úmero.
- **Arquitetura e fibras:** `pennate`. Fascículos penados convergem lateralmente para o tendão da coifa superior.
- **Articulações e classe:** glenohumeral_joint; `monoarticular`
- **Inervação:** Nervo supraescapular.
- **Encurtamento aproximado:** Varia entre porções e com a orientação do úmero e da escápula; não existe uma posição única para o músculo completo.
- **Alongamento aproximado:** Varia entre porções e com o plano de elevação, rotação umeral e posição escapular.
- **Insuficiência ativa/passiva:** Não é descrita como insuficiência multiarticular principal; a posição altera linha de ação e capacidade. Não é inferida por uma regra única; cápsula, escápula e estruturas adjacentes também limitam a amplitude.
- **Mecânica:** A tração da coifa combina abdução e compressão/centragem dependentes do plano de elevação; varia com a orientação do úmero e da escápula. O braço rotacional muda com a elevação e rotação umeral; nenhum máximo angular foi fixado. A capacidade muda com elevação e rotação umeral, comprimento muscular, velocidade e coativação glenoumeral.
- **Cadeia aberta/fechada:** Com o tronco e a escápula relativamente fixos, produz ou controla movimento do úmero e translação glenoumeral. Com a mão fixa, contribui para rigidez glenoumeral e controlo do tronco sobre o membro.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. Contribui para abdução e compressão/centragem glenoumeral; a exigência e o espaço subacromial dependem da posição.
- **Claims:** claim_001589, claim_001590, claim_001591, claim_001592, claim_001593, claim_001594, claim_001595

### Relações músculo-ação

- `shoulder_abduction` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir abdução do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Redondo maior (`teres_major`)

- **Latim / inglês:** musculus teres major / teres major
- **Região / grupo / camada:** `shoulder` / `scapulohumeral_muscles` / `intermediate`
- **Origem:** Face posterior do ângulo inferior da escápula.
- **Inserção:** Lábio medial do sulco intertubercular do úmero.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades.
- **Articulações e classe:** glenohumeral_joint; `monoarticular`
- **Inervação:** Nervo subescapular inferior.
- **Encurtamento aproximado:** Posição combinada compatível com extensão do ombro, adução do ombro e rotação interna do ombro; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão do ombro, abdução do ombro e rotação externa do ombro; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A linha de tração é inferida das fixações e deve ser interpretada para extensão do ombro, adução do ombro e rotação interna do ombro na posição e tarefa declaradas. O braço de momento pode mudar de magnitude ou sinal com a posição; não foi aprovado um valor ou máximo angular universal. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: glenohumeral_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001607, claim_001608, claim_001609, claim_001610, claim_001611, claim_001612

### Relações músculo-ação

- `shoulder_extension` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_adduction` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_internal_rotation` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação interna do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Redondo menor (`teres_minor`)

- **Latim / inglês:** musculus teres minor / teres minor
- **Região / grupo / camada:** `shoulder` / `rotator_cuff` / `deep`
- **Origem:** Porção média da margem lateral da escápula.
- **Inserção:** Faceta inferior do tubérculo maior do úmero.
- **Arquitetura e fibras:** `fusiform`. Fascículos seguem do bordo lateral da escápula para a coifa posterior.
- **Articulações e classe:** glenohumeral_joint; `monoarticular`
- **Inervação:** Nervo axilar.
- **Encurtamento aproximado:** Varia entre porções e com a orientação do úmero e da escápula; não existe uma posição única para o músculo completo.
- **Alongamento aproximado:** Varia entre porções e com o plano de elevação, rotação umeral e posição escapular.
- **Insuficiência ativa/passiva:** Não é descrita como insuficiência multiarticular principal; a posição altera linha de ação e capacidade. Não é inferida por uma regra única; cápsula, escápula e estruturas adjacentes também limitam a amplitude.
- **Mecânica:** A tração da coifa combina rotação externa e controlo posterior dependentes da posição; varia com a orientação do úmero e da escápula. O braço rotacional muda com a elevação e rotação umeral; nenhum máximo angular foi fixado. A capacidade muda com elevação e rotação umeral, comprimento muscular, velocidade e coativação glenoumeral.
- **Cadeia aberta/fechada:** Com o tronco e a escápula relativamente fixos, produz ou controla movimento do úmero e translação glenoumeral. Com a mão fixa, contribui para rigidez glenoumeral e controlo do tronco sobre o membro.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001616, claim_001617, claim_001618, claim_001619, claim_001620, claim_001621, claim_001622

### Relações músculo-ação

- `shoulder_external_rotation` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação externa do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_adduction` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de glenohumeral_joint; não foi aprovado um máximo angular universal. Pode produzir ou assistir adução do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Trapézio (`trapezius`)

- **Latim / inglês:** musculus trapezius / trapezius
- **Região / grupo / camada:** `pectoral_girdle` / `scapular_elevators_retractors` / `superficial`
- **Origem:** Protuberância occipital externa, linha nucal superior, ligamento nucal e processos espinhosos C7–T12.
- **Inserção:** Terço lateral da clavícula, acrómio e espinha da escápula.
- **Arquitetura e fibras:** `flat_convergent`. Fibras superiores, médias e inferiores seguem direções diferentes; o músculo não tem uma única linha de tração escapular.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo acessório (XI) motor; ramos C3–C4 proprioceptivos.
- **Encurtamento aproximado:** Posições escapulares compatíveis com elevação da escápula, retração da escápula, depressão da escápula e rotação superior da escápula; a orientação clavicular e torácica modifica o resultado.
- **Alongamento aproximado:** Posições escapulares opostas às ações registadas, condicionadas pela forma do tórax, posição cervical e orientação do membro superior.
- **Insuficiência ativa/passiva:** Não é uma limitação multiarticular principal; a capacidade continua dependente do comprimento local e da tarefa. Não é uma insuficiência passiva multiarticular principal; tecidos adjacentes podem, ainda assim, limitar a amplitude.
- **Mecânica:** A tração deve ser resolvida sobre escápula, clavícula e tórax; as componentes variam com a orientação escapular. A vantagem para translação ou rotação escapular muda com a posição; não foi quantificada no catálogo. A capacidade resulta da orientação escapular ou clavicular, comprimento fascicular, apoio do membro e momento externo.
- **Cadeia aberta/fechada:** Com o tórax relativamente fixo, desloca ou controla escápula e clavícula para orientar a glenoide. Com a mão fixa, controla a escápula sobre o tórax e pode contribuir para mover ou estabilizar o tronco.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001663, claim_001664, claim_001665, claim_001666, claim_001667, claim_001668, claim_001669, claim_001670

### Relações músculo-ação

- `scapular_elevation` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir elevação escapular quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `scapular_retraction` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir retração escapular quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `scapular_depression` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir depressão escapular quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `scapular_upward_rotation` em `scapulothoracic_articulation`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de scapulothoracic_articulation; não foi aprovado um máximo angular universal. Pode produzir ou assistir rotação superior da escápula quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Tricípite braquial (`triceps_brachii`)

- **Latim / inglês:** musculus triceps brachii / triceps brachii
- **Região / grupo / camada:** `arm` / `posterior_arm` / `superficial`
- **Origem:** Cabeça longa: tubérculo infraglenoidal; lateral e medial: face posterior do úmero em torno do sulco radial.
- **Inserção:** Olécrano da ulna e fáscia do antebraço.
- **Arquitetura e fibras:** `fusiform_three_headed`. Três cabeças convergem para um tendão comum; a cabeça longa tem relação articular adicional.
- **Articulações e classe:** glenohumeral_joint, elbow_joint; `biarticular`
- **Inervação:** Nervo radial.
- **Encurtamento aproximado:** Posição combinada compatível com extensão do cotovelo, extensão do ombro e adução do ombro; não representa um máximo individual universal.
- **Alongamento aproximado:** Posição combinada compatível com flexão do cotovelo, flexão do ombro e abdução do ombro; articulações adjacentes e tolerância limitam a amplitude.
- **Insuficiência ativa/passiva:** A cabeça longa pode perder capacidade quando o ombro e o cotovelo a colocam simultaneamente numa posição encurtada. A flexão do cotovelo combinada com flexão ou elevação do ombro pode aumentar a tensão passiva da cabeça longa.
- **Mecânica:** A linha de tração é inferida das fixações e deve ser interpretada para extensão do cotovelo, extensão do ombro e adução do ombro na posição e tarefa declaradas. O braço de momento pode mudar de magnitude ou sinal com a posição; não foi aprovado um valor ou máximo angular universal. A capacidade depende da posição do cotovelo, antebraço ou punho, comprimento, velocidade e direção da resistência.
- **Cadeia aberta/fechada:** Com o segmento proximal relativamente fixo, produz ou controla movimento do segmento distal nas articulações registadas: glenohumeral_joint, elbow_joint. Com o segmento distal fixo, pode controlar o segmento proximal ou contribuir para rigidez; a direção depende do momento externo.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001675, claim_001676, claim_001677, claim_001678, claim_001679, claim_001680, claim_001681

### Relações músculo-ação

- `elbow_extension` em `elbow_joint`: `principal_contributor`. O papel depende da posição combinada das articulações: elbow_joint. Pode produzir ou assistir extensão do cotovelo quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_extension` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: glenohumeral_joint. Pode produzir ou assistir extensão do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `shoulder_adduction` em `glenohumeral_joint`: `secondary_or_contextual_contributor`. O papel depende da posição combinada das articulações: glenohumeral_joint. Pode produzir ou assistir adução do ombro quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
