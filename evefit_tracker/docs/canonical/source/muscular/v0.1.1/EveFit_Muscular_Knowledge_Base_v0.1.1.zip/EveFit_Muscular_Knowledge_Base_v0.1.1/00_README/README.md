# EveFit Muscular Knowledge Base v0.1.1

Fonte canónica documental e estruturada para anatomia, função contextual,
relações musculares e treinabilidade.

## Estado

- versão do pacote: `0.1.1`;
- versão do schema de dados: `0.1`;
- data de fecho: `2026-07-28`;
- músculos/séries: 179;
- componentes: 36;
- relações: 1243;
- claims: 2387;
- implementação na EveFit: **não**;
- catálogo de exercícios criado: **não**;
- prescrição clínica: **não**.

Começar por `FINAL_REPORT.md`, `SCOPE_AND_EXCLUSIONS.md` e
`CANONICAL_TAXONOMY.md`. Os exports normativos estão em `13_EXPORTS/`.
