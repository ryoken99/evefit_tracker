# Registo de decisões

| ID | Decisão | Estado |
|---|---|---|
| D-001 | Completude limitada ao âmbito EveFit definido | approved |
| D-002 | IDs sem prefixo, tipados pelo ficheiro | approved_with_limits |
| D-003 | Não duplicar músculos por lado | approved |
| D-004 | Cabeças/porções são componentes com política de agregação | approved |
| D-005 | `iliopsoas` e `quadriceps_femoris` são grupos | approved |
| D-006 | Escapulotorácica é articulação funcional | approved |
| D-007 | Séries segmentares mantidas internas | approved_with_limits |
| D-008 | Intrínsecos numerados têm IDs anatómicos e UI agregada | approved |
| D-009 | Nenhuma inferência de hipertrofia depende apenas de EMG | approved |
| D-010 | Valores de braço de momento não são inventados nem universalizados | approved |
| D-011 | Pavimento pélvico fica em camada clínica/especialista | approved |
| D-012 | Esta missão não altera os quatro pilares | approved |
