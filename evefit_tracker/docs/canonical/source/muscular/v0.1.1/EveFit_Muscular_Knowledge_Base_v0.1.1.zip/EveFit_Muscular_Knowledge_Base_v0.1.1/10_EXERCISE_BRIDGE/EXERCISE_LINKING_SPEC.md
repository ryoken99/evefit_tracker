# Especificação de ligação futura a exercícios

Cada exercício futuro deve referenciar IDs canónicos e declarar:

| Campo | Regra |
|---|---|
| `primary_muscle_ids` | principais contribuintes no contexto especificado |
| `secondary_muscle_ids` | contribuição relevante, não meramente anatómica |
| `stabilizer_muscle_ids` | estabilização necessária, com tarefa |
| `emphasized_component_ids` | só componentes aprovados e sem dupla contagem |
| `joint_action_relations` | articulação, ação, fase e papel |
| `range_context` | amplitude/ângulo, sem universalizar |
| `kinetic_chain` | aberta, fechada ou mista |
| `muscle_length_context` | alongado, intermédio, encurtado ou variável |
| `resistance_profile` | direção e mudança na amplitude |
| `equipment_ids` | vocabulário técnico futuro |
| `claim_ids` | proveniência por relação |
| `confidence` | confiança e limitações |

Relações condicionais devem permanecer fail-closed. Não ligar exercícios por
simples correspondência “movimento → músculo”. Uma variante só é nova entidade
quando altera materialmente técnica, contexto, risco ou relações.
