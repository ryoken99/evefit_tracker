# Questões abertas

1. Mapeamentos externos FMA/Uberon/TA2 por entidade não foram licenciados nem
   reconciliados nesta versão.
2. Séries intercostais e segmentares poderão precisar de instâncias por nível
   numa futura camada clínica, não na UI geral.
3. Limiares angulares para mudança de ação em músculos profundos continuam
   dependentes do modelo, indivíduo e plano de movimento.
4. A melhor agregação pública de músculos cervicais exige teste de usabilidade.
5. Dados quantitativos de braços de momento, arquitetura e força exigem um
   subprojeto com unidades, populações e intervalos.
6. Tradução anatómica PT-PT deve ter revisão profissional antes de publicação.
