# Metodologia

## Camadas de afirmação

1. `anatomical_fact`: identidade, fixações, inervação e relações espaciais.
2. `biomechanical_observation`: medidas ou observações dependentes de método.
3. `functional_interpretation`: papel contextual num movimento ou tarefa.
4. `training_inference`: aplicação plausível de carga, sem prescrição.
5. `clinical_or_specialist_consideration`: limite de exposição e segurança.

Terminologia Anatomica 2 rege nomenclatura, não função. Anatomia reconhecida
suporta estrutura; referências de cinesiologia e estudos biomecânicos suportam
função; revisões longitudinais delimitam inferências de treino.

## Proveniência e atomicidade

Origem, inserção, inervação, cada relação articular, cada relação de ação e cada
interação possuem afirmações separadas. O tipo e a data da fonte são derivados
do ledger, e o seu âmbito é validado contra a articulação, ação ou estrutura
afetada. Relações contextuais inferidas não recebem a confiança de uma relação
curada e não podem ser convertidas em dependência universal.

## Organização multiagente

Investigação anatómica e integração foram executadas em vagas por área. A
primeira integração foi submetida a auditorias anatómica, biomecânica e de
evidência independentes; os três pareceres bloquearam o pacote. As correções
foram regeneradas e submetidas a uma segunda leitura pelos mesmos papéis
críticos antes do fecho. O Worker integrou e validou, sem transformar o parecer
de um investigador em fonte para outro antes do gate crítico.

## Contexto obrigatório

Posição, ângulo, amplitude, direção da resistência, momento externo, velocidade,
comprimento, fadiga, técnica, cadeia, suporte e modo de contração podem alterar
a contribuição. Relações músculo-músculo nunca são universais.

## EMG

sEMG é evidência auxiliar de ativação aguda. Não é usada isoladamente para
inferir tensão, dose efetiva, hipertrofia ou superioridade de uma posição.

## Aprovação

`approved` exige identidade e função não controversas e proveniência fechada.
`approved_with_limits` admite dependência mecânica documentada. Estruturas com
impacto clínico, identidade ambígua ou exposição insegura ficam em revisão.
