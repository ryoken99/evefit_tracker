# Política de ênfase prática

| Classe | Critério |
|---|---|
| `high_practical_emphasis` | A exigência relativa pode ser elevada com manipulação plausível de ação, resistência e estabilidade |
| `moderate_practical_emphasis` | Boa contribuição, mas sinergistas ou posição limitam a seletividade |
| `limited_practical_isolation` | É possível alterar exigência relativa, porém o músculo permanece fortemente acoplado |
| `functionally_non_separable` | O papel prático é predominantemente de série, componente ou grupo |
| `specialist_review` | Identidade, risco ou evidência não permite classificação pública |

“Isolamento” nunca significa ausência de sinergistas, estabilizadores ou
antagonistas. Nenhum campo autoriza alegações de isolamento absoluto.
