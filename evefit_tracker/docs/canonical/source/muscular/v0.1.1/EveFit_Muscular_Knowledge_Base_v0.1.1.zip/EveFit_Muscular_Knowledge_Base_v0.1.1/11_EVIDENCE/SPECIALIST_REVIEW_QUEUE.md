# Fila de revisão especialista

| ID | Nome | Estado | Motivo |
|---|---|---|---|
| `anterior_scalene` | Escaleno anterior | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `articularis_cubiti` | Articular do cotovelo | `specialist_review` | `specialist_review` e/ou exposição `catalogued_not_public` |
| `articularis_genus` | Articular do joelho | `excluded_public` | `general_training` e/ou exposição `catalogued_not_public` |
| `bulbospongiosus` | Bulboesponjoso | `excluded_public` | `clinical_only` e/ou exposição `catalogued_not_public` |
| `coccygeus` | Coccígeo | `specialist_review` | `clinical_only` e/ou exposição `clinical_or_specialist_only` |
| `deep_transverse_perineal` | Transverso profundo do períneo | `specialist_review` | `clinical_only` e/ou exposição `clinical_or_specialist_only` |
| `diaphragm` | Diafragma | `approved_with_limits` | `specialist_review` e/ou exposição `public_training_relevant` |
| `external_anal_sphincter` | Esfíncter externo do ânus | `specialist_review` | `clinical_only` e/ou exposição `clinical_or_specialist_only` |
| `iliococcygeus` | Iliococcígeo | `specialist_review` | `clinical_only` e/ou exposição `clinical_or_specialist_only` |
| `innermost_intercostals` | Intercostais íntimos | `excluded_public` | `general_training` e/ou exposição `catalogued_not_public` |
| `interspinales` | Interespinhais | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `intertransversarii` | Intertransversários | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `ischiocavernosus` | Isquiocavernoso | `excluded_public` | `clinical_only` e/ou exposição `catalogued_not_public` |
| `levatores_costarum_longi` | Elevadores longos das costelas | `approved_with_limits` | `caution_required` e/ou exposição `catalogued_not_public` |
| `longissimus_capitis` | Longuíssimo da cabeça | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `longus_capitis` | Longo da cabeça | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `longus_colli` | Longo do pescoço | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `middle_scalene` | Escaleno médio | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `multifidus` | Multífido | `approved_with_limits` | `specialist_review` e/ou exposição `public_training_relevant` |
| `obliquus_capitis_inferior` | Oblíquo inferior da cabeça | `excluded_public` | `specialist_review` e/ou exposição `catalogued_not_public` |
| `obliquus_capitis_superior` | Oblíquo superior da cabeça | `excluded_public` | `specialist_review` e/ou exposição `catalogued_not_public` |
| `palmaris_brevis` | Palmar curto | `excluded_public` | `general_training` e/ou exposição `catalogued_not_public` |
| `plantaris` | Plantar | `excluded_public` | `general_training` e/ou exposição `catalogued_not_public` |
| `posterior_scalene` | Escaleno posterior | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `psoas_minor` | Psoas menor | `excluded_public` | `general_training` e/ou exposição `catalogued_not_public` |
| `puboanalis` | Puboanal (puborretal) | `specialist_review` | `clinical_only` e/ou exposição `clinical_or_specialist_only` |
| `pubococcygeus` | Pubococcígeo | `specialist_review` | `clinical_only` e/ou exposição `clinical_or_specialist_only` |
| `puboperinealis` | Puboperineal | `specialist_review` | `clinical_only` e/ou exposição `clinical_or_specialist_only` |
| `puboprostaticus` | Puboprostático | `specialist_review` | `clinical_only` e/ou exposição `clinical_or_specialist_only` |
| `pubovaginalis` | Pubovaginal | `specialist_review` | `clinical_only` e/ou exposição `clinical_or_specialist_only` |
| `pyramidalis` | Piramidal | `excluded_public` | `general_training` e/ou exposição `catalogued_not_public` |
| `rectus_capitis_anterior` | Reto anterior da cabeça | `excluded_public` | `specialist_review` e/ou exposição `catalogued_not_public` |
| `rectus_capitis_lateralis` | Reto lateral da cabeça | `excluded_public` | `specialist_review` e/ou exposição `catalogued_not_public` |
| `rectus_capitis_posterior_major` | Reto posterior maior da cabeça | `excluded_public` | `specialist_review` e/ou exposição `catalogued_not_public` |
| `rectus_capitis_posterior_minor` | Reto posterior menor da cabeça | `excluded_public` | `specialist_review` e/ou exposição `catalogued_not_public` |
| `rotatores_breves` | Rotadores curtos | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `rotatores_longi` | Rotadores longos | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `scalenus_minimus` | Escaleno mínimo | `specialist_review` | `specialist_review` e/ou exposição `catalogued_not_public` |
| `semispinalis_capitis` | Semiespinal da cabeça | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `semispinalis_cervicis` | Semiespinal cervical | `approved_with_limits` | `specialist_review` e/ou exposição `specialist_training_relevant` |
| `spinalis_capitis` | Espinhal da cabeça | `specialist_review` | `specialist_review` e/ou exposição `catalogued_not_public` |
| `spinalis_cervicis` | Espinhal cervical | `approved_with_limits` | `specialist_review` e/ou exposição `catalogued_not_public` |
| `splenius_capitis` | Esplénio da cabeça | `approved_with_limits` | `specialist_review` e/ou exposição `public_training_relevant` |
| `splenius_cervicis` | Esplénio cervical | `approved_with_limits` | `specialist_review` e/ou exposição `public_training_relevant` |
| `sternocleidomastoid` | Esternocleidomastoideu | `approved_with_limits` | `specialist_review` e/ou exposição `public_training_relevant` |
| `subcostales` | Subcostais | `excluded_public` | `general_training` e/ou exposição `catalogued_not_public` |
| `superficial_transverse_perineal` | Transverso superficial do períneo | `specialist_review` | `clinical_only` e/ou exposição `clinical_or_specialist_only` |
| `transversus_thoracis` | Transverso do tórax | `excluded_public` | `general_training` e/ou exposição `catalogued_not_public` |
