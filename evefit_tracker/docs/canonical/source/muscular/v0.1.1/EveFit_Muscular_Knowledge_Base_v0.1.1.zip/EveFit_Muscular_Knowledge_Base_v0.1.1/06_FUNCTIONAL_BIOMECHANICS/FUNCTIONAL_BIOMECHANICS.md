# Biomecânica funcional

## Regra central

Uma ação anatómica descreve capacidade, não contribuição suficiente numa tarefa.
O perfil real resulta da interação entre geometria, capacidade de força,
comando neural, resistência e estabilidade.

## Cadeia cinética

- Em cadeia aberta, o segmento distal tende a mover-se sobre o proximal.
- Em cadeia fechada, a mesma ação muscular pode controlar o segmento proximal,
  desacelerar movimento ou coativar para rigidez.
- Distal fixo não significa músculo isométrico.
- Superfície instável pode aumentar estabilização sem provar maior estímulo do
  músculo pretendido.

## Comprimento, velocidade e momento

Músculos multiarticulares exigem análise conjunta das articulações. Encurtamento
numa articulação pode ser compensado por alongamento noutra. O braço de momento
pode aumentar, diminuir ou mudar de sinal com o ângulo. Por isso, o pacote não
publica máximos universais nem valores inventados.

## Relações

Agonista, sinergista, antagonista, neutralizador, estabilizador e compensador
são papéis por tarefa. Antagonistas anatómicos podem coativar. Estabilizadores
podem ser principais sob outras condições.

## Força articular

Coaptação, compressão, translação e cisalhamento são registados apenas de forma
qualitativa nesta versão. Quantificação futura exige população, posição,
instrumento/modelo e incerteza.
