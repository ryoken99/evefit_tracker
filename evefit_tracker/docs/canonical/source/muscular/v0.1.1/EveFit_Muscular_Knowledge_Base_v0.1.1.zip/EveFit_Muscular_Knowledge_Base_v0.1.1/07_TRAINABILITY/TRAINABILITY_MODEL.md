# Modelo de treinabilidade

Treinabilidade descreve maneiras plausíveis de aplicar carga, não prescrição.
Cada modalidade usa um estado explícito:

- `supported`: suporte direto suficiente para o nível da afirmação;
- `plausible_inference`: inferência biomecânica, sem prova de eficácia;
- `not_applicable`: modalidade não aplicável à entidade;
- `insufficient_evidence`: não há base para disponibilizar a modalidade;
- `specialist_only`: a entidade ou aplicação exige revisão especialista.

Nenhum estado significa adequação individual, eficácia garantida, dose ou
prescrição. Máquina, cabo, peso livre, banda e peso corporal permanecem
`insufficient_evidence` até existirem relações exercício-músculo específicas.

## Limites

- amplitude completa é individual e tarefa-específica;
- “posição alongada” é aproximação multiarticular, não medição de fascículo;
- máquina, cabo ou banda não garantem perfil de resistência equivalente;
- capacidade de carga não implica elevada ênfase prática;
- atividade aguda não determina adaptação longitudinal.
