# Relatório final

## 1. Resumo executivo

A Base de Conhecimento Anatómica, Funcional e de Treinabilidade Muscular v0.1.1
foi construída como fonte documental e estruturada. Não implementa a EveFit,
não altera os quatro pilares, schemas da aplicação, base de dados ou catálogo
de exercícios.

Esta versão corrige apenas a seleção e geração das descrições públicas curtas
de ações e quatro papéis distais suportados pela anatomia de inserção e função.
Taxonomia, claims, fontes e restante estrutura permanecem inalterados.

## 2. Metodologia

Identidade e nomenclatura foram separadas de função, biomecânica, inferência de
treino e considerações clínicas. Cada músculo possui claims estruturais,
funcionais e de treinabilidade com proveniência.

## 3. Definição exata de completude

Catálogo completo dentro do âmbito EveFit de treino, movimento, postura,
respiração e estabilidade. Não é catálogo completo de todos os músculos humanos.

## 4–11. Cobertura quantitativa

| Métrica | Total |
|---|---:|
| Regiões | 16 |
| Grupos | 45 |
| Músculos/séries canónicas | 179 |
| Porções/cabeças/subdivisões | 36 |
| Articulações/complexos | 35 |
| Ações | 94 |
| Relações totais | 1243 |
| Afirmações | 2387 |
| Fontes | 27 |

## 12. Fontes utilizadas

27 fontes estão no ledger, das quais 26
estão diretamente ligadas a afirmações. Incluem FIPAT TA2, tratados anatómicos
reconhecidos, cinesiologia, estudos biomecânicos e revisões sobre EMG e
adaptação. Fontes contextuais não ligadas a uma afirmação atómica permanecem
identificadas, sem serem contadas como prova dessa afirmação.

## 13–15. Estados

| Estado | Total |
|---|---:|
| `approved_with_limits` | 150 |
| `excluded_public` | 16 |
| `specialist_review` | 13 |

Itens com revisão especialista ou exposição não pública: 48.
Itens não resolvidos/especialista por identidade ou aprovação: 13.

## 16. Exclusões

Expressão facial, olhos, língua, palato, faringe, laringe, mastigação, ouvido
médio, músculo liso, miocárdio, prescrição clínica e catálogo de exercícios.

## 17. Principais decisões taxonómicas

Grupos compostos não são músculos; componentes não duplicam volume; séries
segmentares ficam internas; escapulotorácica é funcional; intrínsecos numerados
têm IDs próprios e UI agregada.

## 18. Principais controvérsias

Mudanças angulares de ação, divisões funcionais sem fronteira anatómica,
recrutamento de músculos profundos, identidade de séries e aplicabilidade
clínica permanecem limitadas ou em revisão quando necessário.

## 19. Auditorias

| Gate | Resultado |
|---|---|
| Primeira auditoria anatómica | `BLOCKER`; agrupamentos, relações digitais e porções corrigidos |
| Primeira auditoria biomecânica | `BLOCKER`; modelos textuais mecânicos e cobertura relacional corrigidos |
| Primeira auditoria de evidência/dados | `BLOCKER`; atomicidade, fontes e esquemas corrigidos |
| Reauditoria anatómica final | `PASS` |
| Reauditoria biomecânica/treinabilidade final | `PASS` |
| Reauditoria de evidência/dados final | `PASS` |
| Auditoria PT-PT, âmbito e exposição pública | `PASS` automático, mantendo revisão humana recomendada |
| Validação interna final | `11557` verificações, `0` falhas |
| Validação externa final | `25647` verificações, `0` falhas |

Resultado: **PASS técnico interno**, sem autorização de publicação. A primeira
integração rejeitada não é considerada entrega final.

## 20. Limitações

Não contém medidas individuais, dose, eficácia, prescrição, modelos
quantitativos completos, validação clínica externa nem mapeamentos exaustivos
para ontologias externas. A revisão PT-PT profissional continua recomendada
antes de publicação.

## 21. Ponte para exercícios

Usar `EXERCISE_LINKING_SPEC.md`: ligações devem declarar papel, articulação,
ação, fase, amplitude, cadeia, comprimento, resistência, confiança e claims.

## 22. Recomendação de implementação futura

Após auditoria de Sandro/EVE e revisão especialista da fila, o Planner pode
criar uma missão técnica que importe apenas estados elegíveis e mantenha
relações condicionais fail-closed.

## Tabelas de cobertura

### Por área

| Área | Músculos/séries |
|---|---:|
| `lower_body` | 59 |
| `trunk_core` | 61 |
| `upper_body` | 59 |

### Por região

| Região | Músculos/séries |
|---|---:|
| `abdominal_wall` | 5 |
| `ankle_foot` | 20 |
| `arm` | 6 |
| `cervical` | 20 |
| `forearm` | 19 |
| `hip` | 8 |
| `knee` | 1 |
| `leg` | 12 |
| `pectoral_girdle` | 7 |
| `pelvic_floor` | 12 |
| `pelvic_girdle_gluteal` | 4 |
| `shoulder` | 8 |
| `spine_back` | 14 |
| `thigh` | 14 |
| `thorax_respiration` | 10 |
| `wrist_hand` | 19 |

### Por grupo

| Grupo | Músculos/séries |
|---|---:|
| `abdominal_wall_muscles` | 5 |
| `anal_sphincter_group` | 1 |
| `anterior_arm` | 3 |
| `anterior_forearm_deep` | 3 |
| `anterior_forearm_intermediate` | 1 |
| `anterior_forearm_superficial` | 4 |
| `anterior_lateral_neck` | 9 |
| `anterior_leg` | 4 |
| `anterior_thigh_other` | 2 |
| `cervical_erector_spinae` | 3 |
| `cervical_transversospinales` | 2 |
| `deep_hip_rotators` | 6 |
| `deep_perineal_muscles` | 1 |
| `erector_spinae` | 6 |
| `gluteal_group` | 3 |
| `hamstrings` | 3 |
| `iliopsoas` | 2 |
| `intrinsic_foot_dorsal` | 2 |
| `intrinsic_foot_plantar` | 18 |
| `intrinsic_hand_central` | 11 |
| `intrinsic_hand_hypothenar` | 4 |
| `intrinsic_hand_thenar` | 4 |
| `lateral_hip_muscles` | 1 |
| `lateral_leg` | 2 |
| `pelvic_diaphragm` | 7 |
| `posterior_abdominal_wall` | 2 |
| `posterior_arm` | 3 |
| `posterior_forearm_deep` | 5 |
| `posterior_forearm_superficial` | 6 |
| `posterior_knee_muscles` | 1 |
| `posterior_leg_deep` | 3 |
| `posterior_leg_superficial` | 3 |
| `posterior_neck` | 2 |
| `quadriceps_femoris` | 4 |
| `rotator_cuff` | 4 |
| `scapular_elevators_retractors` | 4 |
| `scapular_protractors_stabilisers` | 3 |
| `scapulohumeral_muscles` | 2 |
| `segmental_spine` | 2 |
| `suboccipital_group` | 4 |
| `superficial_perineal_muscles` | 3 |
| `thigh_adductors` | 5 |
| `thoracic_respiratory` | 10 |
| `thoracohumeral_muscles` | 2 |
| `transversospinales` | 4 |

### Por confiança

| Confiança | Claims |
|---|---:|
| `high_confidence` | 638 |
| `low_confidence` | 601 |
| `moderate_confidence` | 1148 |

### Por tipo de evidência

| Tipo | Ligações afirmação–tipo de evidência |
|---|---:|
| `academic_anatomy_review` | 808 |
| `academic_textbook` | 212 |
| `biomechanical_model` | 141 |
| `biomechanical_study` | 62 |
| `cadaveric_biomechanics` | 8 |
| `cadaveric_imaging_review` | 6 |
| `cadaveric_intraoperative_anatomy` | 3 |
| `consensus_anatomical` | 1006 |
| `experimental_biomechanics` | 11 |
| `functional_anatomy_textbook` | 1491 |
| `imaging_study` | 20 |
| `peer_reviewed_clinical_review` | 32 |
| `peer_reviewed_review` | 286 |
| `recognised_anatomy_reference` | 1777 |
| `systematic_review` | 216 |

### Por tipo de afirmação

| Tipo | Afirmações |
|---|---:|
| `anatomical_fact` | 1007 |
| `biomechanical_observation` | 375 |
| `clinical_or_specialist_consideration` | 69 |
| `functional_interpretation` | 749 |
| `training_inference` | 187 |

### Por camada pública/especialista

| Camada | Músculos/séries |
|---|---:|
| `catalogued_not_public` | 21 |
| `clinical_or_specialist_only` | 10 |
| `public_training_relevant` | 83 |
| `specialist_training_relevant` | 65 |

### Por estado de revisão

| Estado | Músculos/séries |
|---|---:|
| `reviewed_internal` | 131 |
| `specialist_pending` | 48 |

### Por risco

| Risco | Músculos/séries |
|---|---:|
| `caution_required` | 22 |
| `clinical_only` | 12 |
| `general_training` | 118 |
| `specialist_review` | 27 |
