# Âmbito e exclusões

## Definição de completude

Este pacote é um catálogo completo dentro do âmbito EveFit de treino, movimento,
postura, respiração e estabilidade. Não é um catálogo completo de todos os
músculos do corpo humano.

Inclui membro superior, membro inferior, cintura escapular e pélvica, parede
abdominal, dorso e coluna, musculatura cervical relevante, respiração e
pavimento pélvico em camada especialista. Inclui músculos intrínsecos da mão e
do pé como entidades especialistas, agregadas na futura navegação pública.

## Exclusões

- músculos da expressão facial, olhos, língua, palato, faringe, laringe,
  mastigação e ouvido médio;
- musculatura lisa e miocárdio;
- anatomia fetal, patologias e variações sem impacto no âmbito;
- dose, planos, prescrição, diagnóstico ou aconselhamento clínico;
- catálogo canónico de exercícios e implementação na aplicação.

Estruturas opcionais podem ser catalogadas internamente, mas não apresentadas
como universais. Não existe duplicação por lado.
