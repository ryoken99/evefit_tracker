# Proposta de navegação pública

Fluxo:

`Região → Grupo muscular → Grupo completo ou músculo específico → resultados futuros`

## Regras

- mostrar primeiro três áreas: Superior, Inferior, Tronco/Core;
- usar 5–7 regiões por área;
- agrupar intrínsecos da mão/pé e músculos segmentares;
- permitir abrir detalhes anatómicos sem os impor no primeiro nível;
- não expor IDs, enums, controvérsias clínicas ou descrições extensas;
- apenas `approved` e `approved_with_limits` são candidatos públicos;
- estruturas clínicas aparecem apenas em contexto especialista;
- “core” é rótulo de navegação, não um músculo nem compartimento.

## Descrições curtas de ações

- máximo de três ações;
- `principal_contributor` antes de `principal_contextual_contributor`;
- depois, contribuições secundárias ou contextuais representativas;
- empates resolvidos por prioridade curada e, por fim, pelo ID canónico;
- a ordem física das relações no CSV não participa na seleção;
- ações omitidas da descrição curta permanecem na ficha detalhada.

O export público já aplica estas regras, mas não implementa UI.
