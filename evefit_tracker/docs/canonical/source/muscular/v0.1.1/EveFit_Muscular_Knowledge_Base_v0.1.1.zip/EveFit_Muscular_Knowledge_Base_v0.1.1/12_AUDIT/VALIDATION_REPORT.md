# Relatório de validação

Resultado: **PASS**

- verificações: 11557;
- aprovadas: 11557;
- falhas: 0;
- verificações externas: 25647;
- falhas externas: 0;
- IDs únicos e válidos: sim;
- referências resolvidas: sim;
- afirmações de relações articulares atómicas: sim;
- afirmações de relações de ação atómicas: sim;
- relações músculo-músculo cobrem 179/179 entidades: sim;
- 16 candidatos públicos acima de três relações revistos: sim;
- ação principal presente quando existe relação principal: sim;
- ações públicas limitadas a relações válidas: sim;
- seleção pública independente da ordem do CSV: sim;
- EMG não usado isoladamente para hipertrofia: sim;
- export público fail-closed: sim;
- alterações à aplicação EveFit: zero;
- determinismo: duas gerações isoladas e ZIPs idênticos byte a byte;
- hashes: emitidos em `SHA256SUMS.txt`.
