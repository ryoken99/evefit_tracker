# Catálogo do tronco, core, respiração e suporte axial

> Catálogo completo dentro do âmbito EveFit definido. Não é um catálogo completo de todos os músculos do corpo humano.

Cada perfil separa factos anatómicos, interpretação funcional e inferência de treino. As ações são contextuais.

## Escaleno anterior (`anterior_scalene`)

- **Latim / inglês:** musculus scalenus anterior / anterior scalene
- **Região / grupo / camada:** `cervical` / `anterior_lateral_neck` / `deep`
- **Origem:** Tubérculos anteriores dos processos transversos C3–C6.
- **Inserção:** Primeira costela.
- **Arquitetura e fibras:** `parallel`. Fascículos predominantemente paralelos seguem a direção geral entre as fixações.
- **Articulações e classe:** cervical_spine; `monoarticular`
- **Inervação:** Ramos anteriores C4–C6.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000095, claim_000096, claim_000097, claim_000098, claim_000099, claim_000100, claim_000101, claim_000102

### Relações músculo-ação

- `cervical_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `rib_elevation` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir elevação das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `inspiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Bulboesponjoso (`bulbospongiosus`)

- **Latim / inglês:** musculus bulbospongiosus / bulbospongiosus
- **Região / grupo / camada:** `pelvic_floor` / `superficial_perineal_muscles` / `superficial`
- **Origem:** Corpo perineal e rafe mediana, com anatomia sexualmente diferenciada.
- **Inserção:** Tecidos eréteis e membrana perineal.
- **Arquitetura e fibras:** `paired_fascicular`. Fascículos pares acompanham estruturas perineais sexualmente diferenciadas. A orientação depende da subdivisão, do suporte visceral e da anatomia individual.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Ramo perineal do nervo pudendo.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000158, claim_000159, claim_000160, claim_000161, claim_000162, claim_000163

### Relações músculo-ação

- `perineal_support_and_compression` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `erectile_tissue_compression` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Coccígeo (`coccygeus`)

- **Latim / inglês:** musculus coccygeus / coccygeus
- **Região / grupo / camada:** `pelvic_floor` / `pelvic_diaphragm` / `deep`
- **Origem:** Espinha isquiática e ligamento sacroespinhoso.
- **Inserção:** Margens laterais do sacro inferior e cóccix.
- **Arquitetura e fibras:** `triangular`. Fibras dispõem-se numa unidade triangular entre fixações de larguras diferentes. A orientação depende da subdivisão, do suporte visceral e da anatomia individual.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Ramos anteriores S4–S5.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `specialist_review`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `clinical_or_specialist_only` / `specialist_review`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000166, claim_000167, claim_000168, claim_000169, claim_000170, claim_000171, claim_000172

### Relações músculo-ação

- `pelvic_floor_elevation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Transverso profundo do períneo (`deep_transverse_perineal`)

- **Latim / inglês:** musculus transversus perinei profundus / deep transverse perineal
- **Região / grupo / camada:** `pelvic_floor` / `deep_perineal_muscles` / `deep`
- **Origem:** Ramos isquiopúbicos.
- **Inserção:** Corpo perineal e estruturas perineais profundas.
- **Arquitetura e fibras:** `flat`. Fascículos planos acompanham a superfície anatómica entre as fixações. A orientação depende da subdivisão, do suporte visceral e da anatomia individual.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Ramo perineal do nervo pudendo.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `clinical_or_specialist_only` / `specialist_review`
- **Variações e limites:** Taxonomia, extensão e diferenciação sexual variam entre referências. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000182, claim_000183, claim_000184, claim_000185, claim_000186, claim_000187

### Relações músculo-ação

- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Diafragma (`diaphragm`)

- **Latim / inglês:** diaphragma / diaphragm
- **Região / grupo / camada:** `thorax_respiration` / `thoracic_respiratory` / `deep`
- **Origem:** Processo xifoide, margens costais inferiores, ligamentos arqueados e pilares lombares.
- **Inserção:** Tendão central.
- **Arquitetura e fibras:** `dome_shaped_musculotendinous`. Fibras esternais, costais e lombares convergem radialmente para o tendão central; a geometria muda com o volume pulmonar e a postura.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo frénico C3–C5; aferência periférica intercostal.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. É o principal músculo inspiratório e coopera na regulação de pressão; função respiratória e postural não devem ser reduzidas a um único padrão de respiração.
- **Claims:** claim_000200, claim_000201, claim_000202, claim_000203, claim_000204, claim_000205, claim_000206

### Relações músculo-ação

- `inspiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Esfíncter externo do ânus (`external_anal_sphincter`)

- **Latim / inglês:** musculus sphincter ani externus / external anal sphincter
- **Região / grupo / camada:** `pelvic_floor` / `anal_sphincter_group` / `mixed_depth`
- **Origem:** Corpo perineal e estruturas anococcígeas.
- **Inserção:** Circunda o canal anal em partes subcutânea, superficial e profunda.
- **Arquitetura e fibras:** `circular_three_part`. Fibras circulares distribuídas por porções anatómicas distintas.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervos retais inferiores e ramo de S4.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `specialist_review`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `clinical_or_specialist_only` / `specialist_review`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000439, claim_000440, claim_000441, claim_000442, claim_000443, claim_000444

### Relações músculo-ação

- `anal_sphincter_constriction` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Intercostais externos (`external_intercostals`)

- **Latim / inglês:** musculi intercostales externi / external intercostals
- **Região / grupo / camada:** `thorax_respiration` / `thoracic_respiratory` / `intermediate`
- **Origem:** Bordo inferior da costela superior em cada espaço.
- **Inserção:** Bordo superior da costela inferior.
- **Arquitetura e fibras:** `segmental_series`. Série de fascículos segmentares cuja orientação varia entre espaços ou níveis.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervos intercostais.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000446, claim_000447, claim_000448, claim_000449, claim_000450, claim_000451

### Relações músculo-ação

- `rib_elevation` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir elevação das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `inspiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Oblíquo externo do abdómen (`external_oblique`)

- **Latim / inglês:** musculus obliquus externus abdominis / external oblique
- **Região / grupo / camada:** `abdominal_wall` / `abdominal_wall_muscles` / `superficial`
- **Origem:** Faces externas das costelas V–XII.
- **Inserção:** Linha alba, tubérculo púbico e metade anterior da crista ilíaca.
- **Arquitetura e fibras:** `flat_unipennate`. Fascículos oblíquos dispõem-se numa lâmina ampla.
- **Articulações e classe:** thoracic_spine, lumbosacral_spine; `biarticular`
- **Inervação:** Nervos toracoabdominais T7–T12.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000454, claim_000455, claim_000456, claim_000457, claim_000458, claim_000459, claim_000460, claim_000461

### Relações músculo-ação

- `trunk_flexion` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_lateral_flexion` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_rotation` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A direção depende do lado ativo e do segmento relativamente fixo; a regra lateral é obrigatória. Pode produzir ou assistir rotação do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `forced_expiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Iliococcígeo (`iliococcygeus`)

- **Latim / inglês:** musculus iliococcygeus / iliococcygeus
- **Região / grupo / camada:** `pelvic_floor` / `pelvic_diaphragm` / `deep`
- **Origem:** Arco tendíneo da fáscia obturatória e espinha isquiática.
- **Inserção:** Cóccix e rafe/ligamento anococcígeo.
- **Arquitetura e fibras:** `thin_fan`. Lâmina fina em leque entre fixações amplas. A orientação depende da subdivisão, do suporte visceral e da anatomia individual.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo para o elevador do ânus S3–S4.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `specialist_review`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `clinical_or_specialist_only` / `specialist_review`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000671, claim_000672, claim_000673, claim_000674, claim_000675, claim_000676, claim_000677

### Relações músculo-ação

- `pelvic_floor_elevation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Iliocostal cervical (`iliocostalis_cervicis`)

- **Latim / inglês:** musculus iliocostalis cervicis / iliocostalis cervicis
- **Região / grupo / camada:** `spine_back` / `erector_spinae` / `deep`
- **Origem:** Ângulos das costelas III–VI.
- **Inserção:** Processos transversos C4–C6.
- **Arquitetura e fibras:** `longitudinal`. Fascículos longos orientam-se predominantemente ao longo do eixo axial.
- **Articulações e classe:** cervical_spine, thoracic_spine; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical e flexão lateral cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000680, claim_000681, claim_000682, claim_000683, claim_000684, claim_000685, claim_000686, claim_000687

### Relações músculo-ação

- `cervical_extension` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Iliocostal lombar (`iliocostalis_lumborum`)

- **Latim / inglês:** musculus iliocostalis lumborum / iliocostalis lumborum
- **Região / grupo / camada:** `spine_back` / `erector_spinae` / `superficial`
- **Origem:** Tendão comum do erector da coluna no sacro, crista ilíaca e processos espinhosos lombares.
- **Inserção:** Ângulos das costelas inferiores e processos transversos lombares superiores.
- **Arquitetura e fibras:** `longitudinal`. Fascículos longos orientam-se predominantemente ao longo do eixo axial.
- **Articulações e classe:** lumbosacral_spine, thoracic_spine; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão do tronco e flexão lateral do tronco, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000690, claim_000691, claim_000692, claim_000693, claim_000694, claim_000695, claim_000696, claim_000697, claim_000698

### Relações músculo-ação

- `trunk_extension` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_lateral_flexion` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Iliocostal torácico (`iliocostalis_thoracis`)

- **Latim / inglês:** musculus iliocostalis thoracis / iliocostalis thoracis
- **Região / grupo / camada:** `spine_back` / `erector_spinae` / `intermediate`
- **Origem:** Ângulos das seis costelas inferiores.
- **Inserção:** Ângulos das seis costelas superiores e processo transverso C7.
- **Arquitetura e fibras:** `longitudinal`. Fascículos longos orientam-se predominantemente ao longo do eixo axial.
- **Articulações e classe:** thoracic_spine; `monoarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão do tronco e flexão lateral do tronco, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000701, claim_000702, claim_000703, claim_000704, claim_000705, claim_000706, claim_000707, claim_000708

### Relações músculo-ação

- `trunk_extension` em `thoracic_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thoracic_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_lateral_flexion` em `thoracic_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thoracic_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Intercostais íntimos (`innermost_intercostals`)

- **Latim / inglês:** musculi intercostales intimi / innermost intercostals
- **Região / grupo / camada:** `thorax_respiration` / `thoracic_respiratory` / `deep`
- **Origem:** Face interna de costelas adjacentes.
- **Inserção:** Face interna da costela imediatamente inferior.
- **Arquitetura e fibras:** `segmental_series`. Série de fascículos segmentares cuja orientação varia entre espaços ou níveis.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervos intercostais.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000726, claim_000727, claim_000728, claim_000729, claim_000730, claim_000731, claim_000732

### Relações músculo-ação

- `rib_depression` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir depressão das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `forced_expiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Intercostais internos (`internal_intercostals`)

- **Latim / inglês:** musculi intercostales interni / internal intercostals
- **Região / grupo / camada:** `thorax_respiration` / `thoracic_respiratory` / `deep`
- **Origem:** Sulco costal da costela superior.
- **Inserção:** Bordo superior da costela inferior.
- **Arquitetura e fibras:** `segmental_series`. Série de fascículos segmentares cuja orientação varia entre espaços ou níveis.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervos intercostais.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. Porções interósseas e intercondrais podem ter contribuições diferentes na respiração.
- **Claims:** claim_000735, claim_000736, claim_000737, claim_000738, claim_000739, claim_000740

### Relações músculo-ação

- `rib_depression` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir depressão das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `forced_expiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `rib_elevation` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir elevação das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Oblíquo interno do abdómen (`internal_oblique`)

- **Latim / inglês:** musculus obliquus internus abdominis / internal oblique
- **Região / grupo / camada:** `abdominal_wall` / `abdominal_wall_muscles` / `intermediate`
- **Origem:** Fáscia toracolombar, crista ilíaca e ligamento inguinal.
- **Inserção:** Costelas X–XII, linha alba e púbis por tendão conjunto.
- **Arquitetura e fibras:** `flat_fan`. Fascículos planos dispõem-se em leque, com linha de tração dependente da porção recrutada.
- **Articulações e classe:** thoracic_spine, lumbosacral_spine; `biarticular`
- **Inervação:** Nervos toracoabdominais e L1.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000744, claim_000745, claim_000746, claim_000747, claim_000748, claim_000749, claim_000750, claim_000751

### Relações músculo-ação

- `trunk_flexion` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_lateral_flexion` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_rotation` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A direção depende do lado ativo e do segmento relativamente fixo; a regra lateral é obrigatória. Pode produzir ou assistir rotação do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `forced_expiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Interespinhais (`interspinales`)

- **Latim / inglês:** musculi interspinales / interspinales
- **Região / grupo / camada:** `spine_back` / `segmental_spine` / `deep`
- **Origem:** Processo espinhoso de uma vértebra.
- **Inserção:** Processo espinhoso da vértebra adjacente.
- **Arquitetura e fibras:** `short_segmental_series`. Série de fascículos curtos que liga níveis vertebrais adjacentes.
- **Articulações e classe:** lumbosacral_spine, cervical_spine; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão do tronco e extensão cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000757, claim_000758, claim_000759, claim_000760, claim_000761, claim_000762, claim_000763, claim_000764

### Relações músculo-ação

- `trunk_extension` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_extension` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Intertransversários (`intertransversarii`)

- **Latim / inglês:** musculi intertransversarii / intertransversarii
- **Região / grupo / camada:** `spine_back` / `segmental_spine` / `deep`
- **Origem:** Processo transverso de uma vértebra.
- **Inserção:** Processo transverso da vértebra adjacente.
- **Arquitetura e fibras:** `short_segmental_series`. Série de fascículos curtos que liga níveis vertebrais adjacentes.
- **Articulações e classe:** lumbosacral_spine, cervical_spine; `biarticular`
- **Inervação:** Ramos anteriores e posteriores conforme a região.
- **Encurtamento aproximado:** Posição axial compatível com flexão lateral do tronco e flexão lateral cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000767, claim_000768, claim_000769, claim_000770, claim_000771, claim_000772, claim_000773, claim_000774

### Relações músculo-ação

- `trunk_lateral_flexion` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Isquiocavernoso (`ischiocavernosus`)

- **Latim / inglês:** musculus ischiocavernosus / ischiocavernosus
- **Região / grupo / camada:** `pelvic_floor` / `superficial_perineal_muscles` / `superficial`
- **Origem:** Ramo isquiático.
- **Inserção:** Pilar do tecido erétil.
- **Arquitetura e fibras:** `fusiform`. Fascículos predominantemente longitudinais convergem para tendões nas extremidades. A orientação depende da subdivisão, do suporte visceral e da anatomia individual.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Ramo perineal do nervo pudendo.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000777, claim_000778, claim_000779, claim_000780, claim_000781, claim_000782

### Relações músculo-ação

- `erectile_tissue_compression` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Elevadores curtos das costelas (`levatores_costarum_breves`)

- **Latim / inglês:** musculi levatores costarum breves / levatores costarum breves
- **Região / grupo / camada:** `thorax_respiration` / `thoracic_respiratory` / `deep`
- **Origem:** Processos transversos C7–T11.
- **Inserção:** Costela imediatamente inferior, entre tubérculo e ângulo.
- **Arquitetura e fibras:** `segmental_series`. Série de fascículos segmentares cuja orientação varia entre espaços ou níveis.
- **Articulações e classe:** thoracic_spine; `monoarticular`
- **Inervação:** Ramos posteriores C8–T11.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000804, claim_000805, claim_000806, claim_000807, claim_000808, claim_000809, claim_000810, claim_000811

### Relações músculo-ação

- `rib_elevation` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir elevação das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_lateral_flexion` em `thoracic_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thoracic_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Elevadores longos das costelas (`levatores_costarum_longi`)

- **Latim / inglês:** musculi levatores costarum longi / levatores costarum longi
- **Região / grupo / camada:** `thorax_respiration` / `thoracic_respiratory` / `deep`
- **Origem:** Processos transversos torácicos inferiores.
- **Inserção:** Segunda costela abaixo da origem.
- **Arquitetura e fibras:** `segmental_series`. Série de fascículos segmentares cuja orientação varia entre espaços ou níveis.
- **Articulações e classe:** thoracic_spine; `monoarticular`
- **Inervação:** Ramos posteriores torácicos.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `catalogued_not_public` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000814, claim_000815, claim_000816, claim_000817, claim_000818, claim_000819, claim_000820, claim_000821

### Relações músculo-ação

- `rib_elevation` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir elevação das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_lateral_flexion` em `thoracic_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thoracic_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Longuíssimo da cabeça (`longissimus_capitis`)

- **Latim / inglês:** musculus longissimus capitis / longissimus capitis
- **Região / grupo / camada:** `cervical` / `cervical_erector_spinae` / `deep`
- **Origem:** Processos transversos T1–T5 e processos articulares C4–C7.
- **Inserção:** Processo mastoide.
- **Arquitetura e fibras:** `longitudinal`. Fascículos longos orientam-se predominantemente ao longo do eixo axial.
- **Articulações e classe:** cervical_spine, atlanto_occipital_joint; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical, flexão lateral cervical e rotação cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000824, claim_000825, claim_000826, claim_000827, claim_000828, claim_000829, claim_000830, claim_000831

### Relações músculo-ação

- `cervical_extension` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_rotation` em `cervical_spine`: `secondary_or_contextual_contributor`. A direção depende do lado ativo e do segmento relativamente fixo; a regra lateral é obrigatória. Pode produzir ou assistir rotação cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Longuíssimo cervical (`longissimus_cervicis`)

- **Latim / inglês:** musculus longissimus cervicis / longissimus cervicis
- **Região / grupo / camada:** `spine_back` / `erector_spinae` / `deep`
- **Origem:** Processos transversos T1–T5.
- **Inserção:** Processos transversos C2–C6.
- **Arquitetura e fibras:** `longitudinal`. Fascículos longos orientam-se predominantemente ao longo do eixo axial.
- **Articulações e classe:** cervical_spine, thoracic_spine; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical e flexão lateral cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000835, claim_000836, claim_000837, claim_000838, claim_000839, claim_000840, claim_000841, claim_000842

### Relações músculo-ação

- `cervical_extension` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Longuíssimo torácico (`longissimus_thoracis`)

- **Latim / inglês:** musculus longissimus thoracis / longissimus thoracis
- **Região / grupo / camada:** `spine_back` / `erector_spinae` / `intermediate`
- **Origem:** Tendão comum do erector da coluna e processos transversos lombares.
- **Inserção:** Processos transversos torácicos e costelas adjacentes.
- **Arquitetura e fibras:** `longitudinal`. Fascículos longos orientam-se predominantemente ao longo do eixo axial.
- **Articulações e classe:** lumbosacral_spine, thoracic_spine; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão do tronco e flexão lateral do tronco, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000845, claim_000846, claim_000847, claim_000848, claim_000849, claim_000850, claim_000851, claim_000852, claim_000853

### Relações músculo-ação

- `trunk_extension` em `thoracic_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thoracic_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_lateral_flexion` em `thoracic_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thoracic_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Longo da cabeça (`longus_capitis`)

- **Latim / inglês:** musculus longus capitis / longus capitis
- **Região / grupo / camada:** `cervical` / `anterior_lateral_neck` / `deep`
- **Origem:** Tubérculos anteriores dos processos transversos C3–C6.
- **Inserção:** Parte basilar do occipital.
- **Arquitetura e fibras:** `parallel`. Fascículos predominantemente paralelos seguem a direção geral entre as fixações.
- **Articulações e classe:** cervical_spine, atlanto_occipital_joint; `biarticular`
- **Inervação:** Ramos anteriores C1–C3.
- **Encurtamento aproximado:** Posição axial compatível com flexão cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000856, claim_000857, claim_000858, claim_000859, claim_000860, claim_000861, claim_000862, claim_000863

### Relações músculo-ação

- `cervical_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Longo do pescoço (`longus_colli`)

- **Latim / inglês:** musculus longus colli / longus colli
- **Região / grupo / camada:** `cervical` / `anterior_lateral_neck` / `deep`
- **Origem:** Corpos e processos transversos C5–T3, por fascículos.
- **Inserção:** Atlas, corpos C2–C4 e processos transversos C5–C6.
- **Arquitetura e fibras:** `multifascicular`. Fascículos com trajetos diferentes ligam níveis ou fixações distintas.
- **Articulações e classe:** cervical_spine; `monoarticular`
- **Inervação:** Ramos anteriores C2–C6.
- **Encurtamento aproximado:** Posição axial compatível com flexão cervical e flexão lateral cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000865, claim_000866, claim_000867, claim_000868, claim_000869, claim_000870, claim_000871

### Relações músculo-ação

- `cervical_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Escaleno médio (`middle_scalene`)

- **Latim / inglês:** musculus scalenus medius / middle scalene
- **Região / grupo / camada:** `cervical` / `anterior_lateral_neck` / `deep`
- **Origem:** Tubérculos posteriores dos processos transversos C2–C7.
- **Inserção:** Primeira costela.
- **Arquitetura e fibras:** `parallel`. Fascículos predominantemente paralelos seguem a direção geral entre as fixações.
- **Articulações e classe:** cervical_spine; `monoarticular`
- **Inervação:** Ramos anteriores C3–C8.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000962, claim_000963, claim_000964, claim_000965, claim_000966, claim_000967, claim_000968, claim_000969

### Relações músculo-ação

- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `rib_elevation` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir elevação das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `inspiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Multífido (`multifidus`)

- **Latim / inglês:** musculus multifidus / multifidus
- **Região / grupo / camada:** `spine_back` / `transversospinales` / `deep`
- **Origem:** Sacro, espinha ilíaca posterossuperior, processos mamilares lombares e transversos torácicos/cervicais.
- **Inserção:** Processos espinhosos dois a quatro segmentos acima.
- **Arquitetura e fibras:** `multifascicular_segmental`. Fascículos segmentares cruzam diferentes números de níveis, sem uma única linha de tração.
- **Articulações e classe:** lumbosacral_spine, thoracic_spine, cervical_spine; `multiarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão do tronco e rotação do tronco, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. Fascículos profundos e superficiais podem diferir na contribuição segmentar e de extensão; dor e patologia alteram recrutamento.
- **Claims:** claim_000973, claim_000974, claim_000975, claim_000976, claim_000977, claim_000978, claim_000979, claim_000980, claim_000981

### Relações músculo-ação

- `trunk_extension` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_rotation` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A direção depende do lado ativo e do segmento relativamente fixo; a regra lateral é obrigatória. Pode produzir ou assistir rotação do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Oblíquo inferior da cabeça (`obliquus_capitis_inferior`)

- **Latim / inglês:** musculus obliquus capitis inferior / obliquus capitis inferior
- **Região / grupo / camada:** `cervical` / `suboccipital_group` / `deep`
- **Origem:** Processo espinhoso do áxis.
- **Inserção:** Processo transverso do atlas.
- **Arquitetura e fibras:** `short_parallel`. Fascículos curtos e aproximadamente paralelos ligam fixações próximas.
- **Articulações e classe:** atlanto_axial_joint; `monoarticular`
- **Inervação:** Nervo suboccipital.
- **Encurtamento aproximado:** Posição axial compatível com rotação cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000984, claim_000985, claim_000986, claim_000987, claim_000988, claim_000989, claim_000990

### Relações músculo-ação

- `cervical_rotation` em `atlanto_axial_joint`: `secondary_or_contextual_contributor`. A contribuição ocorre no complexo atlanto_axial_joint e é ipsilateral ao lado ativo; não se extrapola para toda a coluna cervical nem para um ângulo máximo. Pode produzir ou assistir rotação cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Oblíquo superior da cabeça (`obliquus_capitis_superior`)

- **Latim / inglês:** musculus obliquus capitis superior / obliquus capitis superior
- **Região / grupo / camada:** `cervical` / `suboccipital_group` / `deep`
- **Origem:** Processo transverso do atlas.
- **Inserção:** Occipital entre as linhas nucais.
- **Arquitetura e fibras:** `short_fan`. Fascículos curtos abrem em leque entre fixações craniovertebrais próximas.
- **Articulações e classe:** atlanto_occipital_joint; `monoarticular`
- **Inervação:** Nervo suboccipital.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical e flexão lateral cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_000992, claim_000993, claim_000994, claim_000995, claim_000996, claim_000997, claim_000998

### Relações músculo-ação

- `cervical_extension` em `atlanto_occipital_joint`: `secondary_or_contextual_contributor`. A ação é local ao complexo atlanto_occipital_joint; a contribuição muda com a posição craniovertebral e não é tratada como movimento uniforme de toda a cervical. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_lateral_flexion` em `atlanto_occipital_joint`: `secondary_or_contextual_contributor`. A contribuição é ipsilateral no complexo atlanto_occipital_joint; a pequena excursão segmentar não autoriza uma amplitude de treino específica. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Escaleno posterior (`posterior_scalene`)

- **Latim / inglês:** musculus scalenus posterior / posterior scalene
- **Região / grupo / camada:** `cervical` / `anterior_lateral_neck` / `deep`
- **Origem:** Tubérculos posteriores dos processos transversos C4–C6.
- **Inserção:** Segunda costela.
- **Arquitetura e fibras:** `parallel`. Fascículos predominantemente paralelos seguem a direção geral entre as fixações.
- **Articulações e classe:** cervical_spine; `monoarticular`
- **Inervação:** Ramos anteriores C6–C8.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001173, claim_001174, claim_001175, claim_001176, claim_001177, claim_001178, claim_001179, claim_001180

### Relações músculo-ação

- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `rib_elevation` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir elevação das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `inspiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Psoas menor (`psoas_minor`)

- **Latim / inglês:** musculus psoas minor / psoas minor
- **Região / grupo / camada:** `spine_back` / `posterior_abdominal_wall` / `deep`
- **Origem:** Corpos T12–L1 e disco interveniente.
- **Inserção:** Eminência iliopúbica e fáscia ilíaca.
- **Arquitetura e fibras:** `fusiform_long_tendon`. Ventre fusiforme continua num tendão longo, que condiciona transmissão e excursão.
- **Articulações e classe:** lumbosacral_spine; `monoarticular`
- **Inervação:** Ramo anterior L1.
- **Encurtamento aproximado:** Posição axial compatível com flexão do tronco, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Frequentemente ausente e com expressão anatómica variável. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001210, claim_001211, claim_001212, claim_001213, claim_001214, claim_001215, claim_001216

### Relações músculo-ação

- `trunk_flexion` em `lumbosacral_spine`: `weak_variable_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Puboanal (puborretal) (`puboanalis`)

- **Latim / inglês:** musculus puboanalis / puboanalis (puborectalis)
- **Região / grupo / camada:** `pelvic_floor` / `pelvic_diaphragm` / `deep`
- **Origem:** Face posterior do púbis.
- **Inserção:** Alça em torno da junção anorretal.
- **Arquitetura e fibras:** `u_shaped_sling`. Fascículos formam uma alça em U em torno da estrutura visceral relacionada. A orientação depende da subdivisão, do suporte visceral e da anatomia individual.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo para o elevador do ânus e contribuição pudenda variável.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `specialist_review`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `clinical_or_specialist_only` / `specialist_review`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A função normal inclui contração e relaxamento coordenado; sintomas anorretais exigem avaliação especializada.
- **Claims:** claim_001218, claim_001219, claim_001220, claim_001221, claim_001222, claim_001223

### Relações músculo-ação

- `pelvic_floor_elevation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Pubococcígeo (`pubococcygeus`)

- **Latim / inglês:** musculus pubococcygeus / pubococcygeus
- **Região / grupo / camada:** `pelvic_floor` / `pelvic_diaphragm` / `deep`
- **Origem:** Face posterior do púbis.
- **Inserção:** Cóccix e ligamento anococcígeo.
- **Arquitetura e fibras:** `fan_shaped`. Fibras em leque convergem entre uma fixação ampla e outra mais concentrada. A orientação depende da subdivisão, do suporte visceral e da anatomia individual.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo para o elevador do ânus S3–S4; contribuição pudenda variável.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `specialist_review`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `clinical_or_specialist_only` / `specialist_review`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001226, claim_001227, claim_001228, claim_001229, claim_001230, claim_001231, claim_001232

### Relações músculo-ação

- `pelvic_floor_elevation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Puboperineal (`puboperinealis`)

- **Latim / inglês:** musculus puboperinealis / puboperinealis
- **Região / grupo / camada:** `pelvic_floor` / `pelvic_diaphragm` / `deep`
- **Origem:** Face posterior do púbis.
- **Inserção:** Corpo perineal.
- **Arquitetura e fibras:** `short_parallel`. Fascículos curtos e aproximadamente paralelos ligam fixações próximas. A orientação depende da subdivisão, do suporte visceral e da anatomia individual.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo para o elevador do ânus; contribuição pudenda variável.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `specialist_review`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `clinical_or_specialist_only` / `specialist_review`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001235, claim_001236, claim_001237, claim_001238, claim_001239, claim_001240

### Relações músculo-ação

- `pelvic_floor_elevation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Puboprostático (`puboprostaticus`)

- **Latim / inglês:** musculus puboprostaticus / puboprostaticus
- **Região / grupo / camada:** `pelvic_floor` / `pelvic_diaphragm` / `deep`
- **Origem:** Púbis.
- **Inserção:** Fáscia periprostática e uretral no sexo masculino.
- **Arquitetura e fibras:** `short_parallel`. Fascículos curtos e aproximadamente paralelos ligam fixações próximas. A orientação depende da subdivisão, do suporte visceral e da anatomia individual.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Ramos S3–S4 e/ou pudendos, variável.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `specialist_review`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `clinical_or_specialist_only` / `specialist_review`
- **Variações e limites:** Componente sexualmente diferenciado, aplicável à anatomia masculina. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001243, claim_001244, claim_001245, claim_001246, claim_001247, claim_001248

### Relações músculo-ação

- `pelvic_floor_elevation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Pubovaginal (`pubovaginalis`)

- **Latim / inglês:** musculus pubovaginalis / pubovaginalis
- **Região / grupo / camada:** `pelvic_floor` / `pelvic_diaphragm` / `deep`
- **Origem:** Púbis.
- **Inserção:** Parede vaginal e corpo perineal no sexo feminino.
- **Arquitetura e fibras:** `short_parallel`. Fascículos curtos e aproximadamente paralelos ligam fixações próximas. A orientação depende da subdivisão, do suporte visceral e da anatomia individual.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Ramos S3–S4 e/ou pudendos, variável.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `specialist_review`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `clinical_or_specialist_only` / `specialist_review`
- **Variações e limites:** Componente sexualmente diferenciado, aplicável à anatomia feminina. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001251, claim_001252, claim_001253, claim_001254, claim_001255, claim_001256

### Relações músculo-ação

- `pelvic_floor_elevation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Piramidal (`pyramidalis`)

- **Latim / inglês:** musculus pyramidalis / pyramidalis
- **Região / grupo / camada:** `abdominal_wall` / `abdominal_wall_muscles` / `superficial`
- **Origem:** Crista púbica.
- **Inserção:** Linha alba inferior.
- **Arquitetura e fibras:** `triangular`. Fibras dispõem-se numa unidade triangular entre fixações de larguras diferentes.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervo subcostal.
- **Encurtamento aproximado:** Contração local entre púbis e linha alba, dependente da tensão da parede abdominal.
- **Alongamento aproximado:** Afastamento relativo das fixações e cedência da linha alba, sem amplitude axial autónoma aprovada.
- **Insuficiência ativa/passiva:** Não aplicável como limitação multiarticular principal. Não se infere por uma amplitude do tronco; depende da parede abdominal e dos tecidos adjacentes.
- **Mecânica:** A tração local dirige-se do púbis para a linha alba. Não foi tratado como motor axial com braço de momento independente. A tensão local depende do comprimento entre púbis e linha alba e da coativação da parede abdominal.
- **Cadeia aberta/fechada:** A classificação articular aberta não é primária; a função é tensão local da linha alba. Apoios dos membros podem mudar a tensão abdominal, mas não criam uma ação articular própria do piramidal.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Pode estar ausente unilateral ou bilateralmente. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001259, claim_001260, claim_001261, claim_001262, claim_001263, claim_001264

### Relações músculo-ação

- `linea_alba_tension` em ``: `regulator_or_stabilizer`. Depende da posição do púbis, da tensão da linha alba e da coativação da parede abdominal. A contração pode tensionar localmente a linha alba a partir da fixação púbica. O controlo do alongamento local não foi caracterizado como ação axial independente.

## Quadrado lombar (`quadratus_lumborum`)

- **Latim / inglês:** musculus quadratus lumborum / quadratus lumborum
- **Região / grupo / camada:** `spine_back` / `posterior_abdominal_wall` / `deep`
- **Origem:** Ligamento iliolombar e crista ilíaca.
- **Inserção:** 12.ª costela e processos transversos L1–L4.
- **Arquitetura e fibras:** `quadrilateral`. Fascículos formam uma lâmina quadrilateral entre a pelve, coluna e costela.
- **Articulações e classe:** lumbosacral_spine; `monoarticular`
- **Inervação:** Ramos anteriores T12–L4.
- **Encurtamento aproximado:** Posição axial compatível com flexão lateral do tronco e extensão do tronco, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001274, claim_001275, claim_001276, claim_001277, claim_001278, claim_001279, claim_001280, claim_001281

### Relações músculo-ação

- `trunk_lateral_flexion` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_extension` em `lumbosacral_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Reto do abdómen (`rectus_abdominis`)

- **Latim / inglês:** musculus rectus abdominis / rectus abdominis
- **Região / grupo / camada:** `abdominal_wall` / `abdominal_wall_muscles` / `superficial`
- **Origem:** Crista e sínfise púbicas.
- **Inserção:** Processo xifoide e cartilagens costais V–VII.
- **Arquitetura e fibras:** `parallel_with_tendinous_intersections`. Fascículos longitudinais são interrompidos por interseções tendinosas.
- **Articulações e classe:** lumbosacral_spine, thoracic_spine; `biarticular`
- **Inervação:** Nervos toracoabdominais T6–T12.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `high_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001290, claim_001291, claim_001292, claim_001293, claim_001294, claim_001295, claim_001296, claim_001297

### Relações músculo-ação

- `trunk_flexion` em `lumbosacral_spine`: `principal_contributor`. A contribuição varia ao longo de lumbosacral_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `forced_expiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Reto anterior da cabeça (`rectus_capitis_anterior`)

- **Latim / inglês:** musculus rectus capitis anterior / rectus capitis anterior
- **Região / grupo / camada:** `cervical` / `anterior_lateral_neck` / `deep`
- **Origem:** Massa lateral e raiz do processo transverso do atlas.
- **Inserção:** Parte basilar do occipital.
- **Arquitetura e fibras:** `short_parallel`. Fascículos curtos e aproximadamente paralelos ligam fixações próximas.
- **Articulações e classe:** atlanto_occipital_joint; `monoarticular`
- **Inervação:** Ramos anteriores C1–C2.
- **Encurtamento aproximado:** Posição axial compatível com flexão cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001301, claim_001302, claim_001303, claim_001304, claim_001305, claim_001306, claim_001307

### Relações músculo-ação

- `cervical_flexion` em `atlanto_occipital_joint`: `secondary_or_contextual_contributor`. A ação é local ao complexo atlanto_occipital_joint; a contribuição muda com a posição craniovertebral e não é tratada como movimento uniforme de toda a cervical. Pode produzir ou assistir flexão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Reto lateral da cabeça (`rectus_capitis_lateralis`)

- **Latim / inglês:** musculus rectus capitis lateralis / rectus capitis lateralis
- **Região / grupo / camada:** `cervical` / `anterior_lateral_neck` / `deep`
- **Origem:** Processo transverso do atlas.
- **Inserção:** Processo jugular do occipital.
- **Arquitetura e fibras:** `short_parallel`. Fascículos curtos e aproximadamente paralelos ligam fixações próximas.
- **Articulações e classe:** atlanto_occipital_joint; `monoarticular`
- **Inervação:** Ramos anteriores C1–C2.
- **Encurtamento aproximado:** Posição axial compatível com flexão lateral cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001309, claim_001310, claim_001311, claim_001312, claim_001313, claim_001314, claim_001315

### Relações músculo-ação

- `cervical_lateral_flexion` em `atlanto_occipital_joint`: `secondary_or_contextual_contributor`. A contribuição é ipsilateral no complexo atlanto_occipital_joint; a pequena excursão segmentar não autoriza uma amplitude de treino específica. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Reto posterior maior da cabeça (`rectus_capitis_posterior_major`)

- **Latim / inglês:** musculus rectus capitis posterior major / rectus capitis posterior major
- **Região / grupo / camada:** `cervical` / `suboccipital_group` / `deep`
- **Origem:** Processo espinhoso do áxis.
- **Inserção:** Linha nucal inferior lateral.
- **Arquitetura e fibras:** `short_parallel`. Fascículos curtos e aproximadamente paralelos ligam fixações próximas.
- **Articulações e classe:** atlanto_occipital_joint, atlanto_axial_joint; `biarticular`
- **Inervação:** Nervo suboccipital.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical e rotação cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001317, claim_001318, claim_001319, claim_001320, claim_001321, claim_001322, claim_001323, claim_001324

### Relações músculo-ação

- `cervical_extension` em `atlanto_occipital_joint`: `secondary_or_contextual_contributor`. A ação é local ao complexo atlanto_occipital_joint; a contribuição muda com a posição craniovertebral e não é tratada como movimento uniforme de toda a cervical. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_rotation` em `atlanto_axial_joint`: `secondary_or_contextual_contributor`. A contribuição ocorre no complexo atlanto_axial_joint e é ipsilateral ao lado ativo; não se extrapola para toda a coluna cervical nem para um ângulo máximo. Pode produzir ou assistir rotação cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Reto posterior menor da cabeça (`rectus_capitis_posterior_minor`)

- **Latim / inglês:** musculus rectus capitis posterior minor / rectus capitis posterior minor
- **Região / grupo / camada:** `cervical` / `suboccipital_group` / `deep`
- **Origem:** Tubérculo posterior do atlas.
- **Inserção:** Linha nucal inferior medial.
- **Arquitetura e fibras:** `short_fan`. Fascículos curtos abrem em leque entre fixações craniovertebrais próximas.
- **Articulações e classe:** atlanto_occipital_joint; `monoarticular`
- **Inervação:** Nervo suboccipital.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001327, claim_001328, claim_001329, claim_001330, claim_001331, claim_001332, claim_001333

### Relações músculo-ação

- `cervical_extension` em `atlanto_occipital_joint`: `secondary_or_contextual_contributor`. A ação é local ao complexo atlanto_occipital_joint; a contribuição muda com a posição craniovertebral e não é tratada como movimento uniforme de toda a cervical. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Rotadores curtos (`rotatores_breves`)

- **Latim / inglês:** musculi rotatores breves / rotatores breves
- **Região / grupo / camada:** `spine_back` / `transversospinales` / `deep`
- **Origem:** Processos transversos.
- **Inserção:** Lâmina/processo espinhoso da vértebra imediatamente superior.
- **Arquitetura e fibras:** `short_segmental`. Fascículos curtos e oblíquos ligam níveis vertebrais próximos.
- **Articulações e classe:** thoracic_spine, lumbosacral_spine; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com rotação do tronco e extensão do tronco, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001360, claim_001361, claim_001362, claim_001363, claim_001364, claim_001365, claim_001366, claim_001367

### Relações músculo-ação

- `trunk_rotation` em `thoracic_spine`: `secondary_or_contextual_contributor`. A ação unilateral é descrita como contralateral e de pequena escala segmentar; a magnitude rotacional é incerta e o papel de controlo/proprioceção não deve ser convertido em torque global. Pode produzir ou assistir rotação do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_extension` em `thoracic_spine`: `secondary_or_contextual_contributor`. A ação bilateral pode assistir extensão ou rigidez segmentar; não se generaliza uma amplitude global da coluna. Pode produzir ou assistir extensão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Rotadores longos (`rotatores_longi`)

- **Latim / inglês:** musculi rotatores longi / rotatores longi
- **Região / grupo / camada:** `spine_back` / `transversospinales` / `deep`
- **Origem:** Processos transversos.
- **Inserção:** Lâmina/processo espinhoso duas vértebras acima.
- **Arquitetura e fibras:** `short_segmental`. Fascículos curtos e oblíquos ligam níveis vertebrais próximos.
- **Articulações e classe:** thoracic_spine, lumbosacral_spine; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com rotação do tronco e extensão do tronco, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001370, claim_001371, claim_001372, claim_001373, claim_001374, claim_001375, claim_001376, claim_001377

### Relações músculo-ação

- `trunk_rotation` em `thoracic_spine`: `secondary_or_contextual_contributor`. A ação unilateral é descrita como contralateral e de pequena escala segmentar; a magnitude rotacional é incerta e o papel de controlo/proprioceção não deve ser convertido em torque global. Pode produzir ou assistir rotação do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_extension` em `thoracic_spine`: `secondary_or_contextual_contributor`. A ação bilateral pode assistir extensão ou rigidez segmentar; não se generaliza uma amplitude global da coluna. Pode produzir ou assistir extensão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Escaleno mínimo (`scalenus_minimus`)

- **Latim / inglês:** musculus scalenus minimus / scalenus minimus
- **Região / grupo / camada:** `cervical` / `anterior_lateral_neck` / `deep`
- **Origem:** Processo transverso C6/C7, quando presente.
- **Inserção:** Primeira costela e membrana suprapleural.
- **Arquitetura e fibras:** `small_parallel`. Pequeno feixe de fibras paralelas, por vezes anatomicamente variável.
- **Articulações e classe:** cervical_spine; `monoarticular`
- **Inervação:** Ramos anteriores cervicais inferiores.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `specialist_review`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `catalogued_not_public` / `specialist_review`
- **Variações e limites:** Variante inconstante; não deve ser apresentada como anatomia universal. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001392, claim_001393, claim_001394, claim_001395, claim_001396, claim_001397, claim_001398, claim_001399

### Relações músculo-ação

- `rib_elevation` em `costovertebral_joints`: `weak_variable_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir elevação das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `inspiration` em ``: `weak_variable_contributor`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Semiespinal da cabeça (`semispinalis_capitis`)

- **Latim / inglês:** musculus semispinalis capitis / semispinalis capitis
- **Região / grupo / camada:** `cervical` / `cervical_transversospinales` / `deep`
- **Origem:** Processos transversos C7–T6 e articulares C4–C6.
- **Inserção:** Osso occipital entre as linhas nucais.
- **Arquitetura e fibras:** `broad_multifascicular`. A orientação é inferida qualitativamente das fixações e da arquitetura registadas; não foi quantificada como uma direção universal.
- **Articulações e classe:** cervical_spine, atlanto_occipital_joint; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical e rotação cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001412, claim_001413, claim_001414, claim_001415, claim_001416, claim_001417, claim_001418, claim_001419

### Relações músculo-ação

- `cervical_extension` em `cervical_spine`: `secondary_or_contextual_contributor`. A extensão emerge sobretudo de ação bilateral ou de controlo excêntrico; a distribuição varia por região e não tem um máximo angular universal. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_rotation` em `cervical_spine`: `secondary_or_contextual_contributor`. A ação unilateral tende a rodar contralateralmente o segmento móvel; o nível, a postura e o segmento relativamente fixo devem ser declarados. Pode produzir ou assistir rotação cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Semiespinal cervical (`semispinalis_cervicis`)

- **Latim / inglês:** musculus semispinalis cervicis / semispinalis cervicis
- **Região / grupo / camada:** `cervical` / `cervical_transversospinales` / `deep`
- **Origem:** Processos transversos T1–T6.
- **Inserção:** Processos espinhosos C2–C5.
- **Arquitetura e fibras:** `oblique_multifascicular`. Fascículos oblíquos atravessam vários níveis e mudam de orientação por região.
- **Articulações e classe:** cervical_spine, thoracic_spine; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical e rotação cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001422, claim_001423, claim_001424, claim_001425, claim_001426, claim_001427, claim_001428, claim_001429

### Relações músculo-ação

- `cervical_extension` em `cervical_spine`: `secondary_or_contextual_contributor`. A extensão emerge sobretudo de ação bilateral ou de controlo excêntrico; a distribuição varia por região e não tem um máximo angular universal. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_rotation` em `cervical_spine`: `secondary_or_contextual_contributor`. A ação unilateral tende a rodar contralateralmente o segmento móvel; o nível, a postura e o segmento relativamente fixo devem ser declarados. Pode produzir ou assistir rotação cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Semiespinal torácico (`semispinalis_thoracis`)

- **Latim / inglês:** musculus semispinalis thoracis / semispinalis thoracis
- **Região / grupo / camada:** `spine_back` / `transversospinales` / `deep`
- **Origem:** Processos transversos T6–T10.
- **Inserção:** Processos espinhosos C6–T4.
- **Arquitetura e fibras:** `oblique_multifascicular`. Fascículos oblíquos atravessam vários níveis e mudam de orientação por região.
- **Articulações e classe:** thoracic_spine, cervical_spine; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão do tronco e rotação do tronco, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001432, claim_001433, claim_001434, claim_001435, claim_001436, claim_001437, claim_001438, claim_001439

### Relações músculo-ação

- `trunk_extension` em `thoracic_spine`: `secondary_or_contextual_contributor`. A extensão emerge sobretudo de ação bilateral ou de controlo excêntrico; a distribuição varia por região e não tem um máximo angular universal. Pode produzir ou assistir extensão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `trunk_rotation` em `thoracic_spine`: `secondary_or_contextual_contributor`. A ação unilateral tende a rodar contralateralmente o segmento móvel; o nível, a postura e o segmento relativamente fixo devem ser declarados. Pode produzir ou assistir rotação do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Serrátil posterior inferior (`serratus_posterior_inferior`)

- **Latim / inglês:** musculus serratus posterior inferior / serratus posterior inferior
- **Região / grupo / camada:** `thorax_respiration` / `thoracic_respiratory` / `intermediate`
- **Origem:** Processos espinhosos T11–L2.
- **Inserção:** Bordos inferiores das costelas IX–XII.
- **Arquitetura e fibras:** `thin_serrated`. Lâmina fina com digitações serrilhadas; a função mecânica é pouco caracterizada.
- **Articulações e classe:** thoracic_spine; `monoarticular`
- **Inervação:** Nervos intercostais inferiores.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A magnitude do papel respiratório e proprioceptivo é discutida.
- **Claims:** claim_001462, claim_001463, claim_001464, claim_001465, claim_001466, claim_001467, claim_001468

### Relações músculo-ação

- `rib_depression` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir depressão das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Serrátil posterior superior (`serratus_posterior_superior`)

- **Latim / inglês:** musculus serratus posterior superior / serratus posterior superior
- **Região / grupo / camada:** `thorax_respiration` / `thoracic_respiratory` / `intermediate`
- **Origem:** Ligamento nucal e processos espinhosos C7–T3.
- **Inserção:** Bordos superiores das costelas II–V.
- **Arquitetura e fibras:** `thin_serrated`. Lâmina fina com digitações serrilhadas; a função mecânica é pouco caracterizada.
- **Articulações e classe:** thoracic_spine; `monoarticular`
- **Inervação:** Nervos intercostais II–V.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A magnitude do papel respiratório e proprioceptivo é discutida.
- **Claims:** claim_001470, claim_001471, claim_001472, claim_001473, claim_001474, claim_001475, claim_001476

### Relações músculo-ação

- `rib_elevation` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir elevação das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Espinhal da cabeça (`spinalis_capitis`)

- **Latim / inglês:** musculus spinalis capitis / spinalis capitis
- **Região / grupo / camada:** `cervical` / `cervical_erector_spinae` / `deep`
- **Origem:** Processos espinhosos cervicais inferiores/torácicos superiores.
- **Inserção:** Osso occipital, geralmente fundido com semiespinal da cabeça.
- **Arquitetura e fibras:** `longitudinal`. Fascículos longos orientam-se predominantemente ao longo do eixo axial.
- **Articulações e classe:** cervical_spine, atlanto_occipital_joint; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `specialist_review`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `catalogued_not_public` / `specialist_review`
- **Variações e limites:** Frequentemente indistinto do semiespinal da cabeça; identidade prática requer revisão anatómica. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001485, claim_001486, claim_001487, claim_001488, claim_001489, claim_001490, claim_001491, claim_001492

### Relações músculo-ação

- `cervical_extension` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Espinhal cervical (`spinalis_cervicis`)

- **Latim / inglês:** musculus spinalis cervicis / spinalis cervicis
- **Região / grupo / camada:** `cervical` / `cervical_erector_spinae` / `deep`
- **Origem:** Ligamento nucal e processos espinhosos C7–T2.
- **Inserção:** Processo espinhoso C2 e níveis cervicais superiores variáveis.
- **Arquitetura e fibras:** `longitudinal`. Fascículos longos orientam-se predominantemente ao longo do eixo axial.
- **Articulações e classe:** cervical_spine; `monoarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `catalogued_not_public` / `approved_with_limits`
- **Variações e limites:** Pode estar pouco definido ou fundido com músculos adjacentes. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001494, claim_001495, claim_001496, claim_001497, claim_001498, claim_001499, claim_001500

### Relações músculo-ação

- `cervical_extension` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Espinhal torácico (`spinalis_thoracis`)

- **Latim / inglês:** musculus spinalis thoracis / spinalis thoracis
- **Região / grupo / camada:** `spine_back` / `erector_spinae` / `deep`
- **Origem:** Processos espinhosos torácicos inferiores e lombares superiores.
- **Inserção:** Processos espinhosos torácicos superiores.
- **Arquitetura e fibras:** `longitudinal`. Fascículos longos orientam-se predominantemente ao longo do eixo axial.
- **Articulações e classe:** thoracic_spine, lumbosacral_spine; `biarticular`
- **Inervação:** Ramos posteriores dos nervos espinhais.
- **Encurtamento aproximado:** Posição axial compatível com extensão do tronco, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `specialist_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001502, claim_001503, claim_001504, claim_001505, claim_001506, claim_001507, claim_001508, claim_001509

### Relações músculo-ação

- `trunk_extension` em `thoracic_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de thoracic_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão do tronco quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Esplénio da cabeça (`splenius_capitis`)

- **Latim / inglês:** musculus splenius capitis / splenius capitis
- **Região / grupo / camada:** `cervical` / `posterior_neck` / `superficial`
- **Origem:** Ligamento nucal inferior e processos espinhosos C7–T3/4.
- **Inserção:** Processo mastoide e linha nucal superior lateral.
- **Arquitetura e fibras:** `flat`. Fascículos planos acompanham a superfície anatómica entre as fixações.
- **Articulações e classe:** cervical_spine, atlanto_occipital_joint; `biarticular`
- **Inervação:** Ramos posteriores dos nervos cervicais.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical, flexão lateral cervical e rotação cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001511, claim_001512, claim_001513, claim_001514, claim_001515, claim_001516, claim_001517, claim_001518

### Relações músculo-ação

- `cervical_extension` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_rotation` em `cervical_spine`: `secondary_or_contextual_contributor`. A direção depende do lado ativo e do segmento relativamente fixo; a regra lateral é obrigatória. Pode produzir ou assistir rotação cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Esplénio cervical (`splenius_cervicis`)

- **Latim / inglês:** musculus splenius cervicis / splenius cervicis
- **Região / grupo / camada:** `cervical` / `posterior_neck` / `deep`
- **Origem:** Processos espinhosos T3–T6.
- **Inserção:** Processos transversos C1–C3/4.
- **Arquitetura e fibras:** `flat`. Fascículos planos acompanham a superfície anatómica entre as fixações.
- **Articulações e classe:** cervical_spine; `monoarticular`
- **Inervação:** Ramos posteriores dos nervos cervicais.
- **Encurtamento aproximado:** Posição axial compatível com extensão cervical, flexão lateral cervical e rotação cervical, declarando o lado ativo e o segmento relativamente fixo.
- **Alongamento aproximado:** Posição axial no sentido oposto, distribuída por vários segmentos e não atribuível a um único ângulo ou nível.
- **Insuficiência ativa/passiva:** Não se reduz a uma regra monoarticular; recrutamento regional, caixa torácica, pelve e estabilidade disponível alteram a capacidade. Não se infere amplitude individual a partir do músculo; tecidos segmentares e articulações adjacentes também limitam o movimento.
- **Mecânica:** A tração distribui-se por níveis vertebrais; lado ativo, região e segmento relativamente fixo determinam a ação observada. Varia por nível, postura e orientação fascicular; não foi agregado num valor axial universal. A capacidade depende do nível vertebral, postura, comprimento regional, velocidade e distribuição da carga externa.
- **Cadeia aberta/fechada:** A classificação isolada é incompleta; deve identificar-se se tórax, pelve ou cabeça é o segmento relativamente móvel. Apoios dos membros podem transformar a tarefa em controlo axial ou transmissão de força, sem fixar todos os segmentos vertebrais.
- **Ênfase prática:** `limited_practical_isolation`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001522, claim_001523, claim_001524, claim_001525, claim_001526, claim_001527, claim_001528

### Relações músculo-ação

- `cervical_extension` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir extensão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_rotation` em `cervical_spine`: `secondary_or_contextual_contributor`. A direção depende do lado ativo e do segmento relativamente fixo; a regra lateral é obrigatória. Pode produzir ou assistir rotação cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Esternocleidomastoideu (`sternocleidomastoid`)

- **Latim / inglês:** musculus sternocleidomastoideus / sternocleidomastoid
- **Região / grupo / camada:** `cervical` / `anterior_lateral_neck` / `superficial`
- **Origem:** Manúbrio e terço medial da clavícula.
- **Inserção:** Processo mastoide e metade lateral da linha nucal superior.
- **Arquitetura e fibras:** `two_headed_parallel`. A orientação é inferida qualitativamente das fixações e da arquitetura registadas; não foi quantificada como uma direção universal.
- **Articulações e classe:** cervical_spine, atlanto_occipital_joint; `biarticular`
- **Inervação:** Nervo acessório (XI) e ramos C2–C3.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `specialist_review` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001532, claim_001533, claim_001534, claim_001535, claim_001536, claim_001537, claim_001538, claim_001539

### Relações músculo-ação

- `cervical_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_lateral_flexion` em `cervical_spine`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de cervical_spine; não foi aprovado um máximo angular universal. Pode produzir ou assistir flexão lateral cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `cervical_rotation` em `cervical_spine`: `secondary_or_contextual_contributor`. A direção depende do lado ativo e do segmento relativamente fixo; a regra lateral é obrigatória. Pode produzir ou assistir rotação cervical quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `inspiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Subcostais (`subcostales`)

- **Latim / inglês:** musculi subcostales / subcostals
- **Região / grupo / camada:** `thorax_respiration` / `thoracic_respiratory` / `deep`
- **Origem:** Face interna das costelas inferiores, perto dos ângulos.
- **Inserção:** Face interna da segunda ou terceira costela abaixo.
- **Arquitetura e fibras:** `segmental_series`. Série de fascículos segmentares cuja orientação varia entre espaços ou níveis.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervos intercostais.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001551, claim_001552, claim_001553, claim_001554, claim_001555, claim_001556, claim_001557

### Relações músculo-ação

- `rib_depression` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir depressão das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.

## Transverso superficial do períneo (`superficial_transverse_perineal`)

- **Latim / inglês:** musculus transversus perinei superficialis / superficial transverse perineal
- **Região / grupo / camada:** `pelvic_floor` / `superficial_perineal_muscles` / `superficial`
- **Origem:** Tuberosidade e ramo isquiáticos.
- **Inserção:** Corpo perineal.
- **Arquitetura e fibras:** `short_parallel`. Fascículos curtos e aproximadamente paralelos ligam fixações próximas. A orientação depende da subdivisão, do suporte visceral e da anatomia individual.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Ramo perineal do nervo pudendo.
- **Encurtamento aproximado:** Contração e elevação não correspondem a um ângulo articular único; dependem de respiração, pressão, suporte visceral e tarefa.
- **Alongamento aproximado:** Relaxamento e cedência devem ser coordenados com pressão e função visceral; não se define um máximo público universal.
- **Insuficiência ativa/passiva:** Não aplicável como regra articular; excesso ou défice de atividade exige avaliação especializada. Não aplicável como regra articular; mobilidade e sintomas são matéria clínica.
- **Mecânica:** A geometria envolve elevação, constrição ou suporte conforme a subdivisão e a estrutura visceral relacionada. Não aplicável como braço de momento de uma articulação sinovial. A força depende de pressão, comprimento, coordenação respiratória e função visceral; não foi definida uma curva pública universal.
- **Cadeia aberta/fechada:** Classificação não aplicável como cadeia articular; a função depende de pressão, respiração e suporte visceral. Classificação não aplicável como cadeia articular; o apoio dos membros pode modificar a tarefa, não a anatomia funcional básica.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `clinical_only` / `clinical_or_specialist_only` / `specialist_review`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001568, claim_001569, claim_001570, claim_001571, claim_001572, claim_001573

### Relações músculo-ação

- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Transverso do abdómen (`transversus_abdominis`)

- **Latim / inglês:** musculus transversus abdominis / transversus abdominis
- **Região / grupo / camada:** `abdominal_wall` / `abdominal_wall_muscles` / `deep`
- **Origem:** Cartilagens costais VII–XII, fáscia toracolombar, crista ilíaca e ligamento inguinal.
- **Inserção:** Linha alba, crista púbica e pecten do púbis.
- **Arquitetura e fibras:** `flat_transverse`. Fibras predominantemente transversais integram uma parede músculo-aponevrótica.
- **Articulações e classe:** lumbosacral_spine; `monoarticular`
- **Inervação:** Nervos toracoabdominais e L1.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `moderate_practical_emphasis`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `caution_required` / `public_training_relevant` / `approved_with_limits`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. Integra regulação de pressão e rigidez do tronco com diafragma, pavimento pélvico e restantes músculos; não equivale a estabilização isolada.
- **Claims:** claim_001645, claim_001646, claim_001647, claim_001648, claim_001649, claim_001650, claim_001651

### Relações músculo-ação

- `forced_expiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
- `intra_abdominal_pressure_regulation` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.

## Transverso do tórax (`transversus_thoracis`)

- **Latim / inglês:** musculus transversus thoracis / transversus thoracis
- **Região / grupo / camada:** `thorax_respiration` / `thoracic_respiratory` / `deep`
- **Origem:** Face posterior do esterno e processo xifoide.
- **Inserção:** Faces internas das cartilagens costais II–VI.
- **Arquitetura e fibras:** `fan_shaped`. Fibras em leque convergem entre uma fixação ampla e outra mais concentrada.
- **Articulações e classe:** sem ação articular direta catalogada; `not_applicable`
- **Inervação:** Nervos intercostais.
- **Encurtamento aproximado:** A geometria muda com a fase respiratória, o volume pulmonar, a postura e a pressão; não se define um encurtamento máximo universal.
- **Alongamento aproximado:** A configuração oposta depende da caixa torácica, conteúdo abdominal, postura e fase respiratória.
- **Insuficiência ativa/passiva:** Não se aplica como regra simples de músculo apendicular multiarticular. Não se aplica como regra articular simples; a complacência toracoabdominal condiciona o movimento.
- **Mecânica:** A ação depende da geometria das costelas, diafragma, coluna e estruturas relativamente fixas durante a fase respiratória. Não foi reduzido a um braço de momento articular único; a geometria muda com postura e volume pulmonar. A capacidade muda com volume pulmonar, postura, fase respiratória, velocidade do fluxo e pressão externa.
- **Cadeia aberta/fechada:** Não se reduz a cadeia aberta; a função emerge do movimento da caixa torácica, pressão e segmentos relativamente fixos. Apoios fixos podem permitir ação acessória sobre costelas ou tronco, mas a fase respiratória deve ser declarada.
- **Ênfase prática:** `functionally_non_separable`. Ênfase é aumento relativo de exigência; não significa ausência de sinergistas, estabilizadores ou antagonistas.
- **Risco / exposição / aprovação:** `general_training` / `catalogued_not_public` / `excluded_public`
- **Variações e limites:** Variação individual de arquitetura e linha de tração é esperada. A contribuição relativa depende da posição, da tarefa e da resistência.
- **Claims:** claim_001654, claim_001655, claim_001656, claim_001657, claim_001658, claim_001659, claim_001660

### Relações músculo-ação

- `rib_depression` em `costovertebral_joints`: `secondary_or_contextual_contributor`. A contribuição varia ao longo de costovertebral_joints; não foi aprovado um máximo angular universal. Pode produzir ou assistir depressão das costelas quando o momento muscular excede o externo. Pode controlar a direção oposta ou a mesma direção imposta externamente, conforme a tarefa.
- `forced_expiration` em ``: `regulator_or_stabilizer`. Depende de pressão, postura, suporte, fase respiratória quando aplicável e exigência da tarefa. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados. Os termos concêntrico e excêntrico dependem da geometria, pressão e fase funcional; não são universalizados.
