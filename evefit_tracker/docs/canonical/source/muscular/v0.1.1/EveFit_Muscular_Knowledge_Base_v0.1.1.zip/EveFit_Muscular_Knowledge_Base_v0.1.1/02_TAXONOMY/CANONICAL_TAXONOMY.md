# Taxonomia canónica

## Unidades

| Unidade | Regra |
|---|---|
| `anatomical_region` | Área espacial reconhecida; pode sobrepor-se |
| `functional_region` | Agrupamento de navegação, não órgão anatómico |
| `muscle_group` | Agregador anatómico/funcional, não unidade de volume |
| `anatomical_compartment` | Espaço fascial reconhecido |
| `individual_muscle` | Unidade principal, sem duplicação por lado |
| `muscle_series` | Série segmentar repetida, mantida interna |
| `muscle_head` | Componente com origem distinta |
| `muscle_portion` | Parte reconhecida de músculo-pai |
| `functional_subdivision` | Separação prática sustentada e limitada |
| `tendon_or_aponeurosis` | Transmissão de força, nunca músculo |
| `joint` | Articulação anatómica, complexo ou articulação funcional |
| `anatomical_landmark` | Marco usado em fixações e mecânica |

## Decisões compostas

- `iliopsoas`, `quadriceps_femoris`, `hamstrings`, `rotator_cuff`,
  `erector_spinae` e `triceps_surae` são grupos/agregadores.
- Cabeças e porções nunca são somadas ao músculo-pai como volume adicional.
- Escapulotorácica é uma articulação funcional.
- Séries intercostais e segmentares são internas.
- Intrínsecos numerados da mão e do pé têm IDs próprios, mas UI agregada.
