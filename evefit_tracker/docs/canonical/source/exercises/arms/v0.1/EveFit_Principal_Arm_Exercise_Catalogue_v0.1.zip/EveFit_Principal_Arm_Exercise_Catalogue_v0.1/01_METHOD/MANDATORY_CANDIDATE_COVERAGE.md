# Cobertura dos candidatos obrigatórios

| Candidato da ordem | Resolução | ID |
|---|---|---|
| Curl com barra reta | Variante de equipamento | `standing_curl_straight_bar` |
| Curl com barra EZ | Variante de pega/equipamento | `standing_curl_ez_bar` |
| Curl com halteres | Variante de equipamento | `standing_curl_dumbbells` |
| Curl alternado | Variante técnica | `standing_curl_alternating` |
| Curl inclinado | Canónico posicional | `shoulder_extended_supinated_curl` |
| Curl Scott/preacher | Canónico apoiado | `preacher_curl` |
| Curl de concentração | Variante técnica apoiada | `concentration_curl` |
| Curl spider | Canónico posicional | `spider_curl` |
| Curl no cabo | Variante de equipamento | `standing_cable_curl` |
| Curl unilateral no cabo | Variante de equipamento/técnica | `standing_unilateral_cable_curl` |
| Curl na máquina | Variante com limites | `standing_machine_curl` / `preacher_machine_curl` |
| Curl martelo | Canónico de pega neutra | `hammer_curl` |
| Curl martelo cruzado | Variante técnica | `cross_body_hammer_curl` |
| Curl inverso | Canónico pronado | `reverse_curl` |
| Chin-up supinado | Canónico multiarticular | `supinated_chin_up` |
| Curl com banda | Variante de equipamento | `standing_band_curl` |
| Curl em suspensão | Canónico de cadeia fechada | `suspension_bodyweight_curl` |
| Pushdown barra/corda/unilateral | Canónico + variantes | `cable_triceps_pushdown` |
| Extensão acima da cabeça cabo/halter/EZ/banda | Canónico + variantes | `overhead_triceps_extension` |
| Extensão deitada barra/halteres | Canónico + variantes | `lying_triceps_extension` |
| Extensão cruzada no cabo | Canónico | `cross_body_cable_triceps_extension` |
| Kickback halter/cabo | Canónico + variantes | `triceps_kickback` |
| Máquina de tríceps | Canónico com limites + variantes | `machine_triceps_extension` |
| Fundos em paralelas | Canónico multiarticular | `parallel_bar_dip` |
| Fundos no banco | Canónico com limites | `bench_dip` |
| Flexão de braços estreita | Canónico multiarticular | `close_grip_push_up` |
| Supino com pega fechada | Canónico multiarticular | `close_grip_bench_press` |
| Extensão em suspensão | Canónico de cadeia fechada | `suspension_triceps_extension` |
| Extensão de tríceps com banda | Variante de pushdown ou overhead | `pushdown_band` / `overhead_band_extension` |
| Pronação/supinação: alavanca, cabo, banda, manual | Dois canónicos de ação + variantes | `resisted_forearm_pronation` / `resisted_forearm_supination` |
| Flexão/extensão do punho | Canónicos apoiados + variantes | `supported_wrist_curl` / `supported_wrist_extension` |
| Flexão do punho atrás do corpo | Variante técnica | `behind_back_wrist_curl` |
| Rolo de punho | Canónico cíclico com limites | `wrist_roller` |
| Desvios radial/ulnar | Canónicos com limites | `wrist_radial_deviation` / `wrist_ulnar_deviation` |
| Hand gripper e bola | Um canónico funcional + variantes | `resisted_hand_close` |
| Plate pinch | Canónico de pinça | `plate_pinch_hold` |
| Barbell/dumbbell hold | Canónico de suporte + variantes | `support_grip_hold` |
| Fat-grip hold | Variante de contacto | `thick_grip_hold` |
| Farmer carry | Canónico bilateral | `farmers_carry` |
| Suitcase carry | Canónico unilateral | `suitcase_carry` |
| Dead hang | Canónico com limites | `dead_hang` |
| Towel hang | Variante de interface | `towel_hang` |
| Extensão dos dedos com banda | Canónico | `resisted_finger_extension` |
| Suporte em paralelas | Canónico multiarticular de suporte | `parallel_bar_support_hold` |
| Carry com toalha/pega espessa | Variantes de interface | `towel_carry` / `thick_grip_farmers_carry` |

Todos os candidatos foram investigados. A coluna “variante” não representa omissão: evita duplicação quando a diferença pertence ao implemento, pega, lado ou configuração.
