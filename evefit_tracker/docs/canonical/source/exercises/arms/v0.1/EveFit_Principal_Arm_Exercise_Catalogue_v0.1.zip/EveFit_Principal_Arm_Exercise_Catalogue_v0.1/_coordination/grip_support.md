# EQUIPA 4 — Preensão, suspensão, apoio e transportes

## Relatório independente para o Catálogo Canónico dos Principais Exercícios de Braços v0.1

**Estado do relatório:** concluído para integração e crítica  
**Âmbito:** preensão de aperto, sustentação, pinça, mão aberta, extensão dos dedos, suspensões, apoios e transportes carregados  
**Base anatómica consultada:** `EveFit_Muscular_Knowledge_Base_v0.1.1`  
**SHA-256 da base recebida:** `a1876a1d4bc21ab54b3828774f66a99519a4953dc00191e69475d8c15b8b30b0`  
**Intervenções fora do relatório:** nenhuma  

Este documento é uma recomendação independente. Não altera a base muscular, não
implementa dados na EveFit e não constitui aconselhamento clínico individual.

---

## 1. Conclusão executiva

Recomendo **sete identidades canónicas próprias** para esta equipa:

1. `hand_gripper_close`
2. `plate_pinch_hold`
3. `support_grip_hold`
4. `farmers_carry`
5. `suitcase_carry`
6. `dead_hang`
7. `parallel_bar_support_hold`

Devem ainda ser **reutilizadas, sem duplicação**, duas identidades já justificadas
pela equipa do antebraço e punho:

8. `wrist_roller`
9. `resisted_finger_extension`

As seguintes propostas não justificam uma identidade canónica adicional:

- `hand_squeeze`: variante por equipamento/complacência de
  `hand_gripper_close`;
- `thick_grip_hold`: variante de interface/diâmetro de `support_grip_hold`;
- `barbell_support_hold` e `dumbbell_support_hold`: variantes por equipamento de
  `support_grip_hold`;
- `plate_pinch_carry`: variante de interface de `farmers_carry` ou
  `suitcase_carry`, conforme a carga seja bilateral ou unilateral;
- `towel_hang`: variante de interface/equipamento de `dead_hang`;
- `ring_dead_hang`: variante por equipamento e estabilidade de `dead_hang`;
- `towel_carry` e `thick_grip_carry`: variantes de interface do transporte
  bilateral ou unilateral correspondente.

`crush`, `support`, `pinch` e `open_hand` descrevem a **função ou a interface de
preensão**. Não devem, por si só, ser usados como quatro famílias de exercícios
mutuamente exclusivas. Em particular, `open_hand` é uma configuração dependente
do diâmetro ou da largura da pega relativamente à mão da pessoa, não uma
identidade de exercício.

O campo `grip_limiter` deve ser tratado como uma observação dependente da série,
da carga, do diâmetro, da fricção, da duração e da capacidade individual. O
catálogo pode guardar uma expectativa inicial, mas não deve afirmar que a
preensão é sempre o fator limitante de um transporte, suspensão ou apoio.

---

## 2. Critério de identidade canónica

Foi aplicada a seguinte pergunta:

> A proposta muda o padrão motor, a distribuição unilateral/bilateral da carga,
> a relação com o solo ou o objetivo mecânico de forma suficientemente material
> para exigir uma identidade própria, ou muda apenas o implemento e a interface
> de contacto?

### 2.1 Mudanças que justificam identidade própria

- fechar e reabrir uma resistência manual, em vez de apenas a sustentar;
- preensão em pinça sem apoio palmar, em vez de preensão cilíndrica;
- sustentação estática, em vez de locomover a carga;
- locomover cargas bilateralmente, em vez de unilateralmente;
- suspensão com as mãos fixas acima do corpo, em vez de carga livre nas mãos;
- apoio compressivo sobre as mãos, em vez de suspensão por tração.

### 2.2 Mudanças que são variantes ou configurações

- barra, halteres, kettlebells ou objeto transportável;
- pega espessa, adaptador `fat_grip`, toalha ou superfície mais lisa;
- textura, fricção, uso de magnésio e presença de rotação livre;
- largura da mão ou orientação confortável da pega;
- dois discos em vez de um, desde que o padrão de pinça se mantenha;
- execução com pausa isométrica dentro de um exercício dinâmico;
- pequena alteração de amplitude que não mude o padrão.

### 2.3 Regra para transportes com interface especial

A identidade principal deve representar primeiro:

1. existência de locomoção;
2. unilateralidade ou bilateralidade da carga;
3. distribuição e posição geral da carga;
4. só depois a interface de preensão.

Assim:

- transporte bilateral em pinça → variante de `farmers_carry`;
- transporte unilateral em pinça → variante de `suitcase_carry`;
- transporte bilateral com toalhas → variante de `farmers_carry`;
- transporte unilateral com toalha → variante de `suitcase_carry`.

Esta regra evita que o mesmo exercício seja duplicado simultaneamente nos
catálogos de braços, tronco e condicionamento.

---

## 3. Decisões de canonicalização

| Proposta | Decisão | Identidade principal | Fundamentação |
|---|---|---|---|
| Fecho de hand gripper | Canónico | `hand_gripper_close` | Movimento dinâmico de fecho dos dedos contra resistência própria e reabertura controlada. |
| Hand gripper isométrico fechado | Variante técnica | `hand_gripper_close` | A pausa não altera a família. |
| Hand gripper ajustável | Variante por equipamento | `hand_gripper_close` | Muda a resistência, não o padrão. |
| Aperto de bola macia | Variante com limites | `hand_gripper_close` | Mesma intenção geral de fecho; a complacência dificulta quantificar carga e amplitude. |
| Pinça isométrica com discos | Canónico | `plate_pinch_hold` | Interface sem apoio palmar e oposição entre polegar e dedos materialmente distinta. |
| Transporte em pinça | Variante de transporte | `farmers_carry` ou `suitcase_carry` | A locomoção e lateralidade definem a família; `plate_pinch` fica como interface. |
| Sustentação estática com barra | Canónico | `support_grip_hold` | Preensão cilíndrica isométrica com carga livre, sem locomoção. |
| Sustentação estática com halteres | Variante por equipamento | `support_grip_hold` | Cargas independentes não criam uma nova família. |
| Sustentação com pega espessa | Variante de interface | `support_grip_hold` | O diâmetro altera a geometria e a capacidade de força, mas não o padrão de sustentação. |
| Farmer carry | Canónico | `farmers_carry` | Transporte bilateral carregado com marcha. |
| Suitcase carry | Canónico | `suitcase_carry` | Transporte unilateral cria exigência assimétrica do tronco e distribuição de carga distinta. |
| Carry com pega espessa | Variante de interface | Carry bilateral ou unilateral correspondente | O diâmetro deve ser um atributo. |
| Carry com toalha | Variante de interface | Carry bilateral ou unilateral correspondente | A pega deformável/fricção muda; a locomoção mantém a identidade. |
| Dead hang | Canónico com limites | `dead_hang` | Suspensão estática de cadeia fechada do membro superior. |
| Towel hang | Variante com limites | `dead_hang` | Muda a interface e a segurança da ancoragem, não a suspensão. |
| Ring dead hang | Variante com limites | `dead_hang` | A rotação livre e instabilidade são atributos de equipamento. |
| Wrist roller | Reutilizar canónico | `wrist_roller` | Já pertence à família de punho; grip contínuo é relação secundária/limitadora. |
| Extensão dos dedos com banda | Reutilizar canónico | `resisted_finger_extension` | Já pertence à família distal do antebraço/mão. |
| Apoio isométrico em paralelas | Canónico com limites | `parallel_bar_support_hold` | Apoio compressivo de cadeia fechada, diferente de hang e de carga suspensa nas mãos. |

### 3.1 Nota sobre `hand_squeeze`

Uma bola macia não deve ser apresentada como equivalente quantitativa a um
gripper calibrado. A bola pode permanecer como variante pública acessível, mas
com `approved_with_limits`, sem estimativas de carga se a rigidez e a deformação
não forem conhecidas.

### 3.2 Nota sobre `plate_pinch_carry`

Se o produto precisar de pesquisar especificamente “pinça em movimento”, deve
fazê-lo através de filtros:

```text
movement_family = loaded_carry
load_distribution = bilateral | unilateral
grip_interface = plate_pinch
```

Não é necessário criar uma terceira identidade canónica.

---

## 4. Vocabulário de preensão

| ID técnico | Termo público PT-PT | Definição operacional |
|---|---|---|
| `crush_grip` | preensão de aperto / fecho da mão | Dedos fecham sobre a palma ou uma pega; num gripper existe movimento mensurável das pegas. |
| `support_grip` | preensão de sustentação | A mão resiste isometricamente à abertura dos dedos provocada por uma carga. |
| `pinch_grip` | preensão em pinça | Polegar opõe-se aos dedos sem apoio palmar dominante. |
| `open_hand_grip` | preensão com a mão mais aberta | Configuração causada por maior diâmetro/largura relativamente à mão; não é uma família de movimento. |
| `suspension_grip` | preensão em suspensão | A mão mantém o corpo ligado a um apoio superior fixo. |
| `support_contact` | apoio sobre as mãos | A força é transmitida compressivamente para a barra/paralela; não pressupõe “apertar” como objetivo principal. |

Na camada pública deve evitar-se o brasileirismo **“pegada”**. “Pega” descreve o
local ou modo de contacto; “preensão” descreve a função da mão.

A taxonomia GRASP de Feix et al. organiza 33 formas de agarrar por oposição,
dedos virtuais, potência/precisão e posição do polegar. É útil para classificar a
interface, mas é uma taxonomia estática da mão, não uma ontologia de exercícios.
Por isso não deve ser convertida diretamente em dezenas de exercícios EveFit.

---

## 5. Fichas canónicas recomendadas

## 5.1 `hand_gripper_close`

**Nome PT-PT:** Fecho de hand gripper  
**Nome inglês:** Hand gripper close  
**Estado recomendado:** `approved_with_limits`  
**Família:** preensão dinâmica  
**Cadeia:** aberta, com resistência externa na mão  
**Lateralidade:** unilateral por defeito; duas mãos constituem configuração  

### Descrição pública curta

> Fecha e reabre um hand gripper de forma controlada, treinando a flexão dos
> dedos e a contribuição do polegar.

### Mecânica e ações

- flexão MCP, PIP e DIP dos dedos durante o fecho;
- contribuição contextual de oposição/adução e flexão do polegar;
- estabilização isométrica do punho, idealmente sem o deixar colapsar em flexão;
- fase concêntrica no fecho e excêntrica/controlada na reabertura;
- uma pausa na posição fechada é uma variante isométrica, não outro exercício.

### Relações musculares

| Papel | Músculos | Confiança e contexto |
|---|---|---|
| Principais | `flexor_digitorum_profundus`, `flexor_digitorum_superficialis` | Alta para a flexão distal/proximal dos dedos; a contribuição relativa muda com geometria, posição e amplitude. |
| Contextuais do polegar | `flexor_pollicis_longus`, `flexor_pollicis_brevis`, `adductor_pollicis`, `opponens_pollicis` | Moderada; depende de a pega exigir oposição e de o polegar participar no fecho. |
| Estabilizadores do punho | `extensor_carpi_radialis_brevis`, `extensor_carpi_radialis_longus`, `extensor_carpi_ulnaris` e coativação dos flexores do punho | Moderada; não listar como alvos isolados. |
| Antagonistas/controlo da abertura | `extensor_digitorum` e extensores próprios | Contextual na reabertura; a mola pode fazer grande parte do trabalho se a fase for libertada. |

### `grip_limiter`

- `grip_role_default = primary_target`
- `grip_limiter_default = likely`
- não usar `grip_limiter = true` imutável;
- largura inicial da pega e amplitude têm de ser compatíveis com a mão.

### Variantes

- ajustável, mola fixa, pega mais espessa, pausa fechada;
- aperto de bola macia, com estado `approved_with_limits`;
- não publicar “negativas máximas” ou assistência forçada na primeira camada.

### Segurança

- manter os dedos afastados da mola e de pontos de entalamento;
- não permitir abertura brusca e descontrolada;
- começar com resistência que permita amplitude e controlo;
- dor aguda, parestesia ou agravamento persistente no punho/dedos exige
  interrupção e, quando aplicável, revisão especializada.

---

## 5.2 `plate_pinch_hold`

**Nome PT-PT:** Pinça isométrica com discos  
**Nome inglês:** Plate pinch hold  
**Estado recomendado:** `approved_with_limits`  
**Família:** preensão isométrica em pinça  
**Cadeia:** carga livre na mão; sem locomoção  
**Lateralidade:** unilateral ou bilateral como configuração  

### Descrição pública curta

> Mantém um ou mais discos seguros entre o polegar e os dedos, sem os apoiar na
> palma.

### Mecânica e ações

- adução/oposição isométrica do polegar conforme a largura e a forma do disco;
- flexão e estabilização MCP/IP do polegar;
- flexão isométrica MCP, PIP e DIP dos dedos;
- coestabilização do punho;
- a fricção, espessura total, rebordo e textura são variáveis mecânicas críticas.

Não fixar `thumb_cmc_adduction` como única ação principal universal. Uma pinça
lateral, uma pinça de polpas e uma pinça larga com discos não têm exatamente a
mesma coordenação.

### Relações musculares

| Papel | Músculos | Confiança e contexto |
|---|---|---|
| Principal contextual do polegar | `adductor_pollicis` | Alta para pinça com forte componente de adução. |
| Sinergistas do polegar | `flexor_pollicis_longus`, `flexor_pollicis_brevis`, `opponens_pollicis` | Moderada a alta, dependente da forma de pinça. |
| Principais/contextuais dos dedos | `flexor_digitorum_profundus`, `flexor_digitorum_superficialis` | Alta para gerar/manter força dos dedos contra o polegar. |
| Estabilização do indicador | `dorsal_interosseous_hand_1` e intrínsecos da mão | Moderada e dependente da tarefa. |
| Estabilizadores do punho | extensores e flexores do carpo em coativação | Moderada; não inferir isolamento. |

Cooney et al. observaram atividade importante de `adductor_pollicis`,
`opponens_pollicis` e `flexor_pollicis_longus` em tarefas de pinça e preensão.
Esse estudo tem amostra pequena e EMG dependente da tarefa; suporta uma relação
contextual, não uma percentagem fixa nem uma previsão de hipertrofia.

### `grip_limiter`

- `grip_role_default = primary_target`
- `grip_limiter_default = likely`
- registar largura total, textura, presença de rebordo e mão utilizada.

### Segurança

- usar discos sólidos, íntegros e com superfície previsível;
- não depender de um rebordo não declarado;
- libertar e pousar numa zona livre, sem pés ou outras pessoas por baixo;
- não executar sobre pavimento ou objetos que tornem a queda perigosa;
- parar perante dor aguda na base do polegar, dedos ou punho.

---

## 5.3 `support_grip_hold`

**Nome PT-PT:** Sustentação estática de carga nas mãos  
**Sinónimos públicos:** sustentação com barra; sustentação com halteres  
**Nome inglês:** Static support-grip hold  
**Estado recomendado:** `approved_with_limits`  
**Família:** preensão isométrica de sustentação  
**Cadeia:** carga externa livre; posição corporal estática  

### Descrição pública curta

> Mantém uma barra ou cargas nas mãos, com os punhos controlados, sem caminhar.

### Mecânica e ações

- flexão isométrica MCP, PIP e DIP para impedir a abertura dos dedos;
- polegar em oposição/adução conforme a pega;
- punho estabilizado por coativação;
- cotovelo e ombro mantêm a posição escolhida, sem serem automaticamente os
  alvos do exercício;
- entrada e saída da carga fazem parte do risco e devem ser descritas.

### Relações musculares

| Papel | Músculos | Confiança e contexto |
|---|---|---|
| Principais da preensão | `flexor_digitorum_profundus`, `flexor_digitorum_superficialis` | Alta para manutenção da flexão digital. |
| Polegar | `flexor_pollicis_longus`, `adductor_pollicis`, `opponens_pollicis` | Contextual; reduz-se numa pega sem polegar, que deve ser outra configuração de risco. |
| Estabilizadores do punho | `extensor_carpi_radialis_brevis`, `extensor_carpi_radialis_longus`, `extensor_carpi_ulnaris`, `flexor_carpi_radialis`, `flexor_carpi_ulnaris` | Coativação contextual. |
| Estabilizadores proximais | flexores/extensores do cotovelo, cintura escapular e tronco | Dependem da posição e da forma de levantar a carga; não devem ser publicados como alvos universais. |

### `grip_limiter`

- `grip_role_default = primary_target`
- `grip_limiter_default = likely`
- se a carga não puder ser levantada com segurança até à posição, o exercício foi
  limitado pelo setup e não pela preensão;
- correias ou ganchos devem definir `grip_assistance = true` e anulam a
  equivalência com a versão orientada para preensão.

### Variantes

- barra, halteres, kettlebells, trap bar ou objeto seguro;
- unilateral/bilateral como configuração quando não há marcha;
- pega dupla-pronada, neutra ou outra orientação confortável;
- pega espessa como `grip_interface = thick_cylindrical`;
- não criar `thick_grip_hold` como canónico separado.

### Segurança

- usar suportes ou uma altura de levantamento segura quando necessário;
- usar discos fixos/colares quando o implemento o exigir;
- manter zona de queda livre;
- pousar de forma controlada;
- declarar se o implemento pode rodar;
- dor, dormência ou perda súbita de controlo exige interrupção.

---

## 5.4 `farmers_carry`

**Nome PT-PT recomendado:** Transporte bilateral com cargas  
**Sinónimos públicos:** passeio do agricultor; farmer carry  
**Nome inglês:** Farmer's carry  
**Estado recomendado:** `approved_with_limits`  
**Família:** transporte carregado bilateral  
**Cadeia:** mista; mãos em interface quase estática e membros inferiores em marcha cíclica  

### Descrição pública curta

> Caminha com uma carga em cada mão, mantendo o percurso, a postura e a preensão
> sob controlo.

### Mecânica

- preensão de sustentação bilateral;
- coestabilização de punho, cotovelo e cintura escapular;
- marcha sob carga, com alternância de apoio dos membros inferiores;
- exigência global do tronco e ventilatória dependente de carga, distância e
  velocidade;
- levantamento e colocação das cargas são fases próprias do exercício.

### Relações musculares

| Papel | Músculos/sistemas | Confiança e contexto |
|---|---|---|
| Preensão | `flexor_digitorum_profundus`, `flexor_digitorum_superficialis` e músculos do polegar | Alta para manter a carga; ser o limitador depende da série. |
| Punho | flexores e extensores do carpo em coativação | Moderada. |
| Cintura escapular | trapézio, serrátil anterior, romboides e outros estabilizadores | Contextual; evitar apresentar um único músculo como “principal”. |
| Tronco | oblíquos, transverso, multifídios e extensores do tronco | Contextual; a bilateralidade não elimina controlo frontal e rotacional. |
| Locomoção | musculatura da anca, joelho, tornozelo e pé | Fora do foco de braços, mas indispensável ao exercício completo. |

### `grip_limiter`

- `grip_role_default = potential_limiter`
- `grip_limiter_default = possible`
- a preensão pode ser alvo, mas marcha, tronco, capacidade cardiorrespiratória,
  pickup ou tolerância do ombro podem limitar primeiro;
- guardar `grip_limiter_observed` ao nível da série.

### Variantes

- halteres, kettlebells, trap bar ou objetos adequados;
- pega espessa, pinça e toalha como interfaces;
- distância, tempo e velocidade como parâmetros;
- cargas assimétricas nas duas mãos devem ser uma configuração declarada, não
  confundida com suitcase carry puro.

### Segurança

- percurso plano, livre e com distância de travagem;
- cargas que possam ser pousadas em segurança;
- sem mudanças rápidas de direção na camada inicial;
- não permitir que a fadiga de preensão transforme o fim da série numa queda
  imprevisível;
- calçado, piso e área de circulação têm de ser compatíveis.

---

## 5.5 `suitcase_carry`

**Nome PT-PT:** Transporte unilateral tipo mala  
**Nome inglês:** Suitcase carry  
**Estado recomendado:** `approved_with_limits`  
**Família:** transporte carregado unilateral  
**Cadeia:** mista  

### Descrição pública curta

> Caminha com uma carga numa só mão, resistindo à inclinação lateral do tronco e
> mantendo a preensão.

### Justificação da identidade própria

A distribuição unilateral não é uma simples troca de implemento. Altera os
momentos externos no plano frontal, a rotação, o controlo da marcha e a
necessidade de estabilização do tronco. Estudos de carries e holds mostram
diferenças entre condições bilaterais e unilaterais. A evidência disponível
suporta a distinção de padrão, embora não autorize uma regra universal sobre qual
músculo do tronco é “mais ativado” em todas as cargas e velocidades.

### Relações musculares

- relações de preensão e punho iguais às de `farmers_carry`;
- estabilização unilateral da cintura escapular;
- oblíquos, transverso, multifídios e outros estabilizadores do tronco em
  coativação dependente do lado e da fase da marcha;
- não atribuir um “lado principal” universal sem guardar `loaded_side`.

### `grip_limiter`

- `grip_role_default = potential_limiter`
- `grip_limiter_default = possible`
- guardar `loaded_side`, mão dominante e razão de término da série;
- `grip_limiter_observed` pode diferir entre lados.

### Variantes

- halter, kettlebell, objeto transportável;
- pinça, toalha e pega espessa como interfaces;
- hold unilateral sem marcha deve permanecer configuração de
  `support_grip_hold`, não `suitcase_carry`.

### Segurança

Aplicam-se as regras do transporte bilateral, acrescidas de:

- não permitir inclinação progressiva ou perda de trajetória;
- adequar carga e distância ao lado mais limitado;
- não usar a assimetria como instrução para “corrigir” uma condição clínica.

---

## 5.6 `dead_hang`

**Nome PT-PT recomendado:** Suspensão estática na barra  
**Nome inglês:** Dead hang  
**Estado recomendado:** `approved_with_limits`  
**Família:** suspensão  
**Cadeia:** fechada do membro superior, com mãos fixas  

### Descrição pública curta

> Mantém o corpo suspenso numa barra, com entrada e saída assistidas e controlo
> da cintura escapular.

Evitar o nome público “suspensão passiva” como descrição única. A preensão é
ativa e a estratégia escapuloumeral pode variar; “passiva” pode ser interpretada
como instrução para abandonar todo o controlo do ombro.

### Mecânica e ações

- flexão digital e participação do polegar mantêm a ligação à barra;
- o cotovelo permanece estendido na versão canónica;
- a cintura escapular suporta a suspensão com estratégia dependente da técnica,
  mobilidade e tolerância;
- a barra fixa distingue-se de argolas pela rotação disponível;
- balanço e kipping não pertencem à identidade canónica.

### Relações musculares

| Papel | Músculos/sistemas | Confiança e contexto |
|---|---|---|
| Preensão | `flexor_digitorum_profundus`, `flexor_digitorum_superficialis`, polegar | Alta para manter o contacto. |
| Punho | coativação dos músculos do carpo | Moderada. |
| Ombro/escápula | coifa dos rotadores, latíssimo do dorso, trapézio, serrátil anterior e outros estabilizadores | Contextual; não promover um único músculo a alvo universal. |
| Cotovelo | estabilização isométrica em extensão | Contextual; um arm lock-off já é outro padrão. |

Em hangs de escalada numa reglete de 22 mm, a flexão do cotovelo aumentou os
momentos do cotovelo e ombro sem alterar a atividade dos flexores dos dedos no
estudo de Exel et al. Isto ajuda a separar dead hang de lock-off, mas não deve ser
generalizado para barras largas, principiantes ou pessoas com patologia.

### `grip_limiter`

- `grip_role_default = potential_limiter`
- `grip_limiter_default = possible`
- ombro, pele, desconforto da mão, peso corporal e tolerância geral podem limitar
  antes da força de preensão;
- só marcar `grip_limiter_observed = true` quando a falha de contacto for a razão
  observada para terminar.

### Variantes

- largura e orientação da pega;
- assistência dos pés ou banda, com carga corporal reduzida;
- argolas, com rotação livre e maior necessidade de controlo;
- toalha como interface deformável;
- pega mais espessa;
- não juntar hang com cotovelos fletidos à mesma identidade.

### Segurança

- barra e ancoragem classificadas para a carga;
- acesso por caixa/plataforma estável, sem salto desnecessário;
- saída assistida, sem largar o corpo em queda;
- espaço vertical livre e ausência de balanço;
- toalha e ponto de ancoragem inspecionados em cada sessão;
- instabilidade do ombro, hipermobilidade sintomática, lesão/cirurgia recente,
  dor ou sintomas neurais exigem revisão especializada;
- não publicar alegações de “descompressão”, cura do ombro ou prevenção de
  lesão.

---

## 5.7 `parallel_bar_support_hold`

**Nome PT-PT:** Apoio isométrico em paralelas  
**Nome inglês:** Parallel-bar support hold  
**Estado recomendado:** `approved_with_limits`  
**Família:** apoio compressivo  
**Cadeia:** fechada do membro superior, com mãos fixas  

### Descrição pública curta

> Mantém o corpo apoiado em paralelas com os cotovelos estendidos e a cintura
> escapular controlada.

### Mecânica e ações

- extensão isométrica do cotovelo;
- transmissão compressiva de força através das mãos e punhos;
- estabilização da cintura escapular;
- tronco e anca mantêm a posição escolhida;
- a mão exerce pressão e controlo sobre a barra, mas a força de preensão raramente
  deve ser declarada como alvo principal por defeito.

### Relações musculares

| Papel | Músculos | Confiança e contexto |
|---|---|---|
| Principal contextual | `triceps_brachii` | Alta para manter extensão do cotovelo. |
| Sinergista do cotovelo | `anconeus` | Moderada/contextual. |
| Estabilização escapular | `serratus_anterior`, trapézio e outros estabilizadores; `pectoralis_minor` apenas de forma contextual | Não transformar depressão escapular numa lista rígida de agonistas. |
| Estabilização do punho | flexores e extensores do carpo em coativação | Moderada. |
| Contacto da mão | flexores digitais e intrínsecos | Estabilização/contacto, não `grip_limiter` universal. |

### `grip_limiter`

- `grip_role_default = stabilizer`
- `grip_limiter_default = unlikely`
- `grip_limiter_observed` continua permitido, mas é exceção;
- punho, cotovelo, ombro, cintura escapular ou capacidade de suporte podem limitar
  primeiro.

### Variantes

- paralelas altas, barras de dips estáveis ou pegas baixas adequadas;
- assistência dos pés;
- argolas não devem ser tratadas como simples variante inicial devido à
  instabilidade e rotação materialmente maiores; manter em revisão ou numa
  progressão futura;
- flexão de cotovelos transforma o padrão e não é configuração do apoio
  isométrico.

### Segurança

- equipamento estável e espaço livre por baixo;
- entrada e saída por apoio controlado;
- evitar hiperextensão forçada dos cotovelos e colapso do punho;
- não instruir depressão escapular máxima rígida;
- dor ou instabilidade no punho, cotovelo ou ombro exige interrupção e, quando
  aplicável, revisão especializada.

---

## 6. Identidades reutilizadas de outra equipa

## 6.1 `wrist_roller`

Deve ser referenciado, não recriado. O exercício combina:

- fases alternadas de flexão e extensão do punho;
- controlo excêntrico durante o desenrolamento;
- preensão contínua no cilindro;
- possível limitação pela preensão, pelo punho ou pela cintura escapular.

Recomendação:

- `grip_role_default = potential_limiter`
- `grip_limiter_default = possible`
- `grip_interface` e diâmetro do rolo devem ser parâmetros;
- uma versão de rolo mais espesso é configuração, não exercício novo.

## 6.2 `resisted_finger_extension`

Deve ser referenciado como contrapartida funcional para extensão resistida dos
dedos, sem o chamar “exercício de grip”.

Relações prioritárias:

- `extensor_digitorum`;
- `extensor_indicis` e `extensor_digiti_minimi` como contribuintes contextuais;
- intrínsecos da mão na coordenação das expansões extensoras;
- estabilizadores do punho.

Recomendação:

- `grip_role_default = not_applicable`
- `grip_limiter_default = not_applicable`
- a resistência e posição da banda devem evitar enrolamento sobre articulações.

---

## 7. Modelo de ações e articulações

As ações listadas devem ser relações válidas da base v0.1.1. Para tarefas
isométricas, a ação descreve a capacidade muscular usada para impedir movimento,
não uma amplitude articular visível.

| Exercício | Articulações relevantes | Ações/capacidades principais |
|---|---|---|
| `hand_gripper_close` | MCP, PIP e DIP dos dedos; CMC, MCP e IP do polegar; punho | Flexão dos dedos; oposição/adução e flexão contextual do polegar; estabilidade do punho. |
| `plate_pinch_hold` | CMC/MCP/IP do polegar; MCP/PIP/DIP dos dedos; punho | Adução ou oposição do polegar conforme a pinça; flexão isométrica de polegar/dedos; estabilidade do punho. |
| `support_grip_hold` | Dedos, polegar e punho; cotovelo/ombro conforme setup | Flexão digital isométrica, participação do polegar e coestabilização do punho. |
| `farmers_carry` | Mão/punho, membro superior, tronco e membros inferiores | Sustentação isométrica mais marcha carregada bilateral. |
| `suitcase_carry` | Igual ao farmer carry, com momento externo unilateral | Sustentação isométrica, marcha e controlo frontal/rotacional assimétrico. |
| `dead_hang` | Dedos/polegar, punho, cotovelo, glenoumeral e escapulotorácica | Sustentação digital, extensão mantida do cotovelo e estabilização da suspensão. |
| `parallel_bar_support_hold` | Punho, cotovelo, glenoumeral e escapulotorácica | Extensão isométrica do cotovelo e estabilização compressiva. |
| `wrist_roller` | Punho e dedos | Flexão/extensão alternada do punho e preensão contínua. |
| `resisted_finger_extension` | MCP/PIP/DIP dos dedos e punho | Extensão dos dedos com estabilização do punho. |

### 7.1 Auditoria distal

A base v0.1.1 distingue corretamente:

- `flexor_digitorum_profundus` como principal contribuinte para
  `finger_dip_flexion`;
- `flexor_digitorum_superficialis` como principal contribuinte para
  `finger_pip_flexion`;
- `flexor_pollicis_longus` como principal contribuinte para
  `thumb_ip_flexion`;
- extensores digitais como contribuintes para MCP e, através das expansões,
  extensão interfalângica contextual.

Este relatório **não propõe alterações de papéis na base muscular**. Para os
exercícios, converte essas capacidades em relações dependentes da tarefa, sem
promover a anatomia para alegações de adaptação.

---

## 8. Política proposta para `grip_limiter`

### 8.1 Separar papel e observação

Recomenda-se guardar:

```json
{
  "grip_role_default": "primary_target | potential_limiter | stabilizer | not_applicable",
  "grip_limiter_default": "likely | possible | unlikely | not_applicable",
  "grip_limiter_observed": "true | false | unknown",
  "termination_reason": "grip_loss | target_reached | posture_loss | pain | cardiorespiratory | other"
}
```

`grip_limiter_observed` pertence ao desempenho/série futura, não à identidade
canónica.

### 8.2 Valores por exercício

| Exercício | Papel por defeito | Limitador por defeito |
|---|---|---|
| `hand_gripper_close` | `primary_target` | `likely` |
| `plate_pinch_hold` | `primary_target` | `likely` |
| `support_grip_hold` | `primary_target` | `likely` |
| `farmers_carry` | `potential_limiter` | `possible` |
| `suitcase_carry` | `potential_limiter` | `possible` |
| `dead_hang` | `potential_limiter` | `possible` |
| `parallel_bar_support_hold` | `stabilizer` | `unlikely` |
| `wrist_roller` | `potential_limiter` | `possible` |
| `resisted_finger_extension` | `not_applicable` | `not_applicable` |

### 8.3 Variáveis obrigatórias ou recomendadas

- diâmetro/largura da pega;
- forma e possibilidade de rotação;
- textura/fricção e uso de magnésio;
- presença de correias, ganchos ou assistência;
- mão e lateralidade;
- carga, tempo, distância e velocidade;
- razão de término;
- no hang, percentagem aproximada de peso corporal assistida;
- na pinça, espessura total e presença de rebordo.

Kong e Lowe mostraram que o diâmetro do cabo altera a força de preensão e o
conforto. Mogk e Keir mostraram que a postura do punho e antebraço altera
substancialmente a capacidade de força e a carga muscular. Estes resultados
justificam guardar geometria e posição; não justificam um “diâmetro perfeito”
universal.

---

## 9. Segurança e revisão especialista

### 9.1 Regras gerais públicas

- utilizar equipamento íntegro, estável e adequado à carga;
- planear a entrada, a saída e a zona de queda antes de iniciar;
- manter pessoas, pés e objetos frágeis fora da possível trajetória da carga;
- progredir carga, duração e complexidade separadamente;
- parar perante dor aguda, dormência, formigueiro, perda súbita de força ou
  instabilidade;
- não converter instruções gerais em tratamento de lesão;
- não afirmar isolamento absoluto;
- não inferir hipertrofia a partir de uma diferença aguda de EMG.

### 9.2 `caution_required`

Aplicar, pelo menos, a:

- pinças com discos;
- holds e carries pesados;
- pega espessa;
- towel carry;
- dead hang;
- towel hang;
- apoio em paralelas.

### 9.3 `specialist_review`

Recomendar revisão quando existam:

- dor ou instabilidade do ombro, punho, polegar ou dedos;
- sintomas neurais ou parestesias;
- cirurgia ou lesão recente do membro superior;
- hipermobilidade sintomática;
- suspeita de lesão tendinosa dos flexores/extensores;
- necessidade de adaptar o exercício a uma condição clínica.

### 9.4 Alegações públicas proibidas

- “descomprime a coluna/ombro”;
- “cura a dor do ombro”;
- “previne todas as lesões de preensão”;
- “isola completamente o antebraço”;
- “pega espessa produz mais hipertrofia”;
- “towel hang ativa mais todos os músculos”;
- “farmer carry é sempre limitado pela preensão”.

---

## 10. Camada pública PT-PT

| ID | Nome recomendado | Descrição curta recomendada |
|---|---|---|
| `hand_gripper_close` | Fecho de hand gripper | Fecha e reabre um hand gripper de forma controlada, treinando a flexão dos dedos e a contribuição do polegar. |
| `plate_pinch_hold` | Pinça isométrica com discos | Mantém um ou mais discos seguros entre o polegar e os dedos, sem os apoiar na palma. |
| `support_grip_hold` | Sustentação estática de carga nas mãos | Mantém uma barra ou cargas nas mãos, com os punhos controlados, sem caminhar. |
| `farmers_carry` | Transporte bilateral com cargas | Caminha com uma carga em cada mão, mantendo o percurso, a postura e a preensão sob controlo. |
| `suitcase_carry` | Transporte unilateral tipo mala | Caminha com uma carga numa só mão, resistindo à inclinação lateral do tronco e mantendo a preensão. |
| `dead_hang` | Suspensão estática na barra | Mantém o corpo suspenso numa barra, com entrada e saída assistidas e controlo da cintura escapular. |
| `parallel_bar_support_hold` | Apoio isométrico em paralelas | Mantém o corpo apoiado em paralelas com os cotovelos estendidos e a cintura escapular controlada. |
| `wrist_roller` | Rolo de punho | Enrola e desenrola uma carga através de movimentos controlados dos punhos, mantendo a preensão no rolo. |
| `resisted_finger_extension` | Extensão resistida dos dedos | Abre e estende os dedos contra uma banda leve, mantendo o punho controlado. |

### 10.1 Termos e traduções

- preferir **preensão**, **pega**, **sustentação** e **apoio**;
- evitar **pegada**;
- manter `hand gripper`, `farmer carry`, `suitcase carry` e `dead hang` como
  sinónimos pesquisáveis, não necessariamente como primeiro nome;
- não traduzir `crush grip` literalmente como “preensão de esmagamento” na
  descrição pública; “preensão de aperto” ou “fecho da mão” é mais claro;
- “mão aberta” deve significar explicitamente maior abertura causada pela
  interface, não extensão completa dos dedos.

---

## 11. Validações automáticas recomendadas

### 11.1 Identidade e variantes

- cada `variant_id` resolve para um `canonical_exercise_id`;
- uma variante não pode ser simultaneamente canónica;
- `plate_pinch_carry` exige `load_distribution` e resolve para farmer ou suitcase;
- `towel_carry` exige lateralidade e resolve para o carry correspondente;
- `thick_grip_hold` resolve para `support_grip_hold`;
- `towel_hang` e `ring_dead_hang` resolvem para `dead_hang`;
- `wrist_roller` e `resisted_finger_extension` aparecem uma única vez no pacote.

### 11.2 Relações anatómicas

- todos os músculos, articulações e ações existem na base v0.1.1;
- ações digitais distinguem MCP, PIP e DIP;
- o polegar distingue CMC, MCP e IP quando aplicável;
- tarefas isométricas declaram o contexto em vez de fingirem movimento angular;
- nenhuma relação de EMG é transformada automaticamente em alvo de hipertrofia;
- `parallel_bar_support_hold` não recebe `grip_limiter` universal;
- carries e hangs não recebem um único estabilizador universal.

### 11.3 Configuração de preensão

- `open_hand_grip` não pode ser `movement_family`;
- diâmetro/largura e unidade são obrigatórios quando se afirma “pega espessa”;
- `grip_assistance = true` quando se usam correias/ganchos;
- `grip_limiter_observed` não pode ser preenchido sem `termination_reason`;
- `grip_limiter_default` é um enum, não um booleano;
- uma pinça deve declarar se existe apoio palmar ou rebordo.

### 11.4 Segurança e camada pública

- hangs exigem entrada/saída segura e ancoragem;
- carries exigem percurso e zona de colocação;
- pinças e holds exigem zona de queda;
- descrições públicas não contêm “isolamento”, cura, prevenção garantida ou
  superioridade hipertrófica;
- português europeu validado, incluindo ausência de “pegada”;
- resultados ordenados por IDs e serialização determinística.

---

## 12. Fontes e âmbito de utilização

| Ref. | Fonte | Identificador/ligação | Utilização permitida neste relatório | Limitação principal |
|---|---|---|---|---|
| G01 | Feix et al., taxonomia GRASP | DOI `10.1109/THMS.2015.2470657`; https://www.eng.yale.edu/grablab/pubs/Feix_THMS2016.pdf | Classificar formas de preensão como atributos da interface. | Taxonomia estática, não catálogo de treino. |
| G02 | Cooney et al., função muscular do polegar em pinça/preensão | PMID `3980932`; DOI `10.1016/S0363-5023(85)80106-4`; https://pubmed.ncbi.nlm.nih.gov/3980932/ | Relações contextuais de adutor, oponente e flexor longo do polegar. | Amostra pequena e EMG dependente da tarefa. |
| G03 | Kong & Lowe, diâmetro cilíndrico e força de preensão | DOI `10.1016/j.ergon.2004.11.003`; https://stacks.cdc.gov/view/cdc/197408 | Diâmetro como variável que altera força e conforto. | Condições laboratoriais e intervalo de diâmetros específico. |
| G04 | Krings et al., efeitos agudos de Fat Grip | PMID `30694963`; DOI `10.1519/JSC.0000000000002954`; https://pubmed.ncbi.nlm.nih.gov/30694963/ | Pega espessa como variante que altera desempenho e atividade aguda. | Não demonstra superioridade longitudinal nem hipertrofia. |
| G05 | Rendos et al., tipo de pega e atividade/força | PMID `26694502`; DOI `10.1519/JSC.0000000000001293`; https://pubmed.ncbi.nlm.nih.gov/26694502/ | Forma e tamanho da pega como parâmetros mecânicos. | Resultados específicos das tarefas estudadas. |
| G06 | Mogk & Keir, postura do punho/antebraço e preensão | PMID `12775491`; DOI `10.1080/0014013031000107595`; https://pubmed.ncbi.nlm.nih.gov/12775491/ | Necessidade de guardar posição do punho e antebraço. | Não fornece uma regra universal para treino. |
| G07 | Seo et al., intensidade de preensão e força do punho | PMID `18803097`; DOI `10.1080/00140130802216925`; https://pubmed.ncbi.nlm.nih.gov/18803097/ | Interdependência entre preensão e estabilização do punho. | Estudo agudo/laboratorial. |
| G08 | Mannella et al., força de preensão e rigidez do punho | PMID `35646483`; DOI `10.7717/peerj.13495`; https://pubmed.ncbi.nlm.nih.gov/35646483/ | Coativação e resistência a perturbações do punho. | Não é estudo de adaptação ao treino. |
| G09 | Lv et al., modelo mecânico dos flexores dos dedos | PMID `35544543`; DOI `10.1371/journal.pone.0268137`; https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0268137 | Cooperação FDS/FDP e controlo antagonista em flexão digital. | Modelação; não traduzir diretamente para eficácia de exercício. |
| G10 | Ferrer-Uris et al., posições de preensão em dead-hangs de escalada | PMID `37304875`; DOI `10.7717/peerj.15464`; https://pubmed.ncbi.nlm.nih.gov/37304875/ | Configuração da mão altera coordenação no hang. | Escalada e hangs máximos; não é barra de ginásio genérica. |
| G11 | Exel et al., finger hangs e arm lock-offs | DOI `10.3389/fspor.2023.1251089`; https://www.frontiersin.org/journals/sports-and-active-living/articles/10.3389/fspor.2023.1251089/full | Separar hang com cotovelo estendido de lock-off. | 17 escaladores experientes e reglete específica. |
| G12 | Hermans et al., treino de hangboard | PMID `35571743`; PMCID `PMC9092147`; DOI `10.3389/fspor.2022.888158`; https://pubmed.ncbi.nlm.nih.gov/35571743/ | Evidência de treino específica para força dos dedos em escaladores. | Não generalizar para dead hang comum ou população geral. |
| G13 | Snarr et al., pull-up tradicional, suspensão e toalha | PMID `28828073`; DOI `10.1515/hukin-2017-0068`; https://pubmed.ncbi.nlm.nih.gov/28828073/ | Mostrar que toalha é uma interface e que alegações musculares simples são frágeis. | Pull-up dinâmico; não mediu diretamente músculos da preensão. |
| G14 | Ellestad et al., carries e holds bilaterais/unilaterais | PMID `38665162`; DOI `10.70252/NWUE9985`; https://pubmed.ncbi.nlm.nih.gov/38665162/ | Distinguir farmer de suitcase e carry de hold. | Atividade muscular aguda; não prova adaptação longitudinal. |
| G15 | Winwood et al., biomecânica do farmer's walk | DOI `10.1260/1747-9541.9.5.1127`; https://journals.sagepub.com/doi/10.1260/1747-9541.9.5.1127 | Locomoção carregada como padrão próprio. | Amostra muito pequena de strongmen experientes. |
| G16 | McGill et al., eventos strongman | PMID `19528856`; DOI `10.1519/JSC.0b013e318198f8f7`; https://pubmed.ncbi.nlm.nih.gov/19528856/ | Exigência global e do tronco em carries pesados. | Contexto strongman; não é fonte específica de preensão. |
| G17 | Vigotsky et al., interpretação de sEMG | PMID `29354060`; https://pubmed.ncbi.nlm.nih.gov/29354060/ | Limitar inferências a partir de amplitude de EMG. | Documento metodológico, não teste destes exercícios. |
| G18 | Vigotsky et al., EMG e hipertrofia | PMID `35006527`; https://pubmed.ncbi.nlm.nih.gov/35006527/ | Proibir inferência automática de hipertrofia por EMG aguda. | Não classifica identidades de exercício. |
| G19 | ACSM, modelos de progressão em resistência | PMID `19204579`; DOI `10.1249/MSS.0b013e3181915670`; https://pubmed.ncbi.nlm.nih.gov/19204579/ | Princípios gerais de progressão, não prescrição individual. | Não é específico de grip/hang/carry. |

### 12.1 Hierarquia de evidência aplicada

- a base v0.1.1 é autoritativa para identidade muscular, articulações e ações;
- estudos anatómicos/mecânicos suportam relações de tarefa;
- estudos de EMG suportam apenas participação contextual;
- estudos agudos de pega espessa ou handles não suportam alegações de adaptação;
- estudos de escalada são marcados como população e implemento específicos;
- estudos de carries suportam a identidade do padrão global, não a dominância
  universal de um músculo.

---

## 13. Questões para o integrador

1. Confirmar se o modelo global permite uma variante apontar para um de dois pais
   canónicos conforme `load_distribution`. Se não permitir, criar variantes
   explícitas `bilateral_plate_pinch_carry` e `unilateral_plate_pinch_carry`,
   ambas não canónicas.
2. Decidir se `hand_squeeze` permanece pesquisável na camada pública ou apenas
   como exemplo de equipamento não calibrado.
3. Definir uma unidade normalizada para diâmetro/largura da pega e, se possível,
   uma razão relativamente ao comprimento ou largura da mão.
4. Confirmar como a ontologia representa cadeia mista nos carries; rotular todo o
   exercício apenas como `closed_chain` perde a diferença entre mão/objeto e
   marcha.
5. Confirmar se o apoio em argolas fica fora da primeira versão pública devido à
   instabilidade ou se entra como variante `approved_with_limits`.
6. Não promover nenhuma fonte específica de escalada a recomendação geral para
   dead hangs sem revisão especializada.

---

## 14. Entrega e declaração de integridade

- relatório criado de forma independente;
- nenhuma alteração proposta à taxonomia ou aos papéis da base muscular v0.1.1;
- nenhuma alteração à aplicação EveFit;
- nenhum código Flutter, migration, release ou catálogo final foi criado;
- nenhuma prescrição clínica individual foi produzida;
- as decisões de canonicalização estão prontas para crítica e integração pelo
  Worker.
