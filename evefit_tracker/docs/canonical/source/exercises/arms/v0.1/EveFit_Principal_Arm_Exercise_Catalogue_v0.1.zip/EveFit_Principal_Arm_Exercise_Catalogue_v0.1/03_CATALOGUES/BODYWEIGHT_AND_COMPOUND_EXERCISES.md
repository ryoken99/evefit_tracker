# Peso corporal e exercícios multiarticulares

O papel muscular é contextual e nunca significa isolamento absoluto.

## Apoio isométrico nas paralelas

- ID: `parallel_bar_support_hold`
- Estado: `approved_public`
- Família: `upper_limb_support`
- Objetivo: Sustentar o corpo com os braços estendidos nas paralelas, mantendo mãos, cotovelos e ombros estáveis.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo, extensor radial curto do carpo, flexor profundo dos dedos, flexor radial do carpo, flexor superficial dos dedos, peitoral menor e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal e paralelas.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar-se para apoio, manter cotovelos estendidos e sair através de apoio controlado.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Elevação na barra com pega supinada

- ID: `supinated_chin_up`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Tração vertical multiarticular com pega supinada, na qual os flexores do cotovelo têm papel relevante mas não exclusivo.
- Músculos principais/contextuais: Bicípite braquial, braquial e grande dorsal.
- Secundários/estabilizadores: Braquiorradial e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Peso corporal e barra fixa.
- Mecânica: Exercício de cadeia fechada para cotovelo e ombro. O bicípite e o braquial contribuem para a flexão do cotovelo, enquanto músculos das costas e cintura escapular também são determinantes.

### Execução

1. Suspender-se numa barra fixa com pega supinada segura, cotovelos estendidos sem relaxamento descontrolado.
2. Puxar o corpo para cima através de flexão do cotovelo e movimento coordenado do ombro/escápula; descer sob controlo.
3. Terminar a subida sem projetar a cabeça ou perder o controlo escapular; regressar à suspensão controlada.

**Cues:** Iniciar com controlo escapular, manter a pega fechada e evitar balanço das pernas.

**Erros frequentes:** Usar impulso excessivo, soltar bruscamente para a extensão e forçar amplitude do ombro dolorosa.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Flexão de braços com mãos próximas

- ID: `close_grip_push_up`
- Estado: `approved_public`
- Família: `elbow_extension_compound`
- Objetivo: Flexão de braços multiarticular com mãos próximas, aumentando a exigência contextual de extensão do cotovelo.
- Músculos principais/contextuais: Peitoral maior e tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal.
- Mecânica: Cadeia fechada com extensão do cotovelo e adução horizontal do ombro; não é isolamento de tríceps.

### Execução

1. Em prancha, mãos abaixo ou ligeiramente dentro da largura dos ombros, corpo alinhado.
2. Descer o corpo com controlo e empurrar o solo até regressar à prancha.
3. Terminar a descida antes de perder alinhamento; subir sem bloquear agressivamente os cotovelos.

**Cues:** Manter corpo alinhado, cotovelos orientados para trás e empurrar o chão de forma uniforme.

**Erros frequentes:** Abrir excessivamente os cotovelos, deixar a anca cair e forçar uma posição estreita dolorosa.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Fundos em paralelas

- ID: `parallel_bar_dip`
- Estado: `approved_public`
- Família: `elbow_extension_compound`
- Objetivo: Exercício multiarticular em apoio nas paralelas, com extensão do cotovelo relevante e participação do ombro e peito.
- Músculos principais/contextuais: Peitoral maior e tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal e paralelas.
- Mecânica: Cadeia fechada. O tricípite é importante, mas o gesto também exige extensão/adução do ombro, depressão escapular e controlo do tronco.

### Execução

1. Apoiar o corpo nas paralelas com cotovelos estendidos, ombros organizados e pés sem apoio.
2. Descer por flexão controlada dos cotovelos e ombros; subir estendendo os cotovelos sem perder a posição escapular.
3. Terminar a descida antes de dor ou perda de controlo do ombro; subir até extensão confortável.

**Cues:** Manter as barras firmemente seguras, controlar a profundidade e evitar encolher os ombros.

**Erros frequentes:** Descer além da amplitude tolerada, balançar o corpo e bloquear o cotovelo de forma agressiva.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Fundos no banco

- ID: `bench_dip`
- Estado: `approved_with_limits`
- Família: `elbow_extension_compound`
- Objetivo: Extensão do cotovelo com as mãos apoiadas atrás do tronco; opção pública com limites pela extensão do ombro.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide, peitoral maior e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal e banco plano.
- Mecânica: Apoio posterior que combina extensão do cotovelo com extensão do ombro. A amplitude deve ser conservadora.

### Execução

1. Apoiar as mãos na borda de um banco estável, com o tronco próximo do apoio e cotovelos estendidos.
2. Descer através de flexão do cotovelo mantendo o ombro confortável; regressar estendendo o cotovelo.
3. Parar a descida antes de desconforto anterior no ombro ou perda de alinhamento.

**Cues:** Manter o tronco perto do banco, usar amplitude curta e confortável e apontar os cotovelos para trás.

**Erros frequentes:** Descer demasiado, afastar o tronco do banco e usar apoio instável.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Passeio do agricultor

- ID: `farmers_carry`
- Estado: `approved_public`
- Família: `loaded_carry`
- Objetivo: Transportar cargas nas duas mãos mantendo preensão, postura e marcha controladas.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo, flexor longo do polegar, oblíquo externo do abdómen e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Halter.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar as cargas, caminhar em linha controlada e pousá-las sem perder a preensão.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Supino com pega fechada

- ID: `close_grip_bench_press`
- Estado: `approved_public`
- Família: `elbow_extension_compound`
- Objetivo: Supino multiarticular com pega relativamente estreita, no qual a extensão do cotovelo tem papel relevante.
- Músculos principais/contextuais: Peitoral maior e tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Barra reta e banco plano.
- Mecânica: A largura de pega altera momentos e carga tolerada. Continua a ser um exercício de empurrar multiarticular.

### Execução

1. Deitado no banco, pés estáveis, barra segura com pega ligeiramente mais estreita do que a habitual.
2. Descer a barra ao tronco com controlo e empurrar por extensão do cotovelo e adução horizontal do ombro.
3. Aproximar do tronco sem perder posição do ombro; subir até extensão controlada.

**Cues:** Manter antebraços alinhados, controlar a descida e usar observador ou suportes de segurança.

**Erros frequentes:** Pega estreita ao ponto de colapsar o punho, cotovelos sem controlo e treinar sem suportes adequados.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Suspensão passiva controlada na barra

- ID: `dead_hang`
- Estado: `approved_with_limits`
- Família: `suspension_support`
- Objetivo: Suspender o peso corporal numa barra fixa mantendo a pega segura.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo, flexor longo do polegar, grande dorsal e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Peso corporal e barra fixa.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Assumir suspensão controlada e manter o contacto; sair através de apoio seguro, sem largar em queda.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Transporte unilateral tipo mala

- ID: `suitcase_carry`
- Estado: `approved_public`
- Família: `loaded_carry`
- Objetivo: Transportar uma carga numa só mão, mantendo preensão e controlo lateral do tronco.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo, flexor longo do polegar, oblíquo externo do abdómen e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Halter.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar a carga, caminhar sem inclinar o tronco e pousar de forma controlada.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.
