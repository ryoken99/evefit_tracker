# Registo de decisões

| Decisão | Resultado | Justificação |
|---|---|---|
| Barra reta vs barra EZ | Variantes de pega/equipamento | Preservam ação, posição e cadeia; mudam liberdade do punho. |
| Halteres vs barra | Variantes de equipamento | A independência dos lados não basta para nova identidade. |
| Curl inclinado | Canónico | Ombro em extensão altera comprimento e contexto mecânico. |
| Curl Scott | Canónico | Apoio do braço e ombro em flexão alteram estabilidade e perfil. |
| Curl spider | Canónico | Peito apoiado e braço pendente à frente criam trajetória própria. |
| Curl martelo | Canónico | Posição neutra do antebraço muda contribuição dos flexores. |
| Curl inverso | Canónico | Pronação muda contribuição e limitação pela pega/punho. |
| Pushdown barra vs corda | Variantes | Implemento não muda a ação principal. |
| Extensão acima da cabeça | Canónico | Posição do ombro altera comprimento da cabeça longa. |
| Extensão deitada | Canónico | Apoio, posição do ombro e trajetória justificam identidade. |
| Fundos, flexão estreita e supino fechado | Canónicos distintos | Cadeias, apoios, trajetórias e estabilidade diferem materialmente. |
| Farmer carry vs sustentação estática | Canónicos distintos | Transporte dinâmico e suporte isométrico têm exigências diferentes. |
| Curl de concentração | Variante do curl apoiado | Apoio muda, mas não fecha família mecânica adicional no núcleo. |
| Flexão do punho atrás do corpo | Variante técnica | Mesma ação; muda setup e estabilidade. |
| Hand gripper vs bola | Um canónico com variantes | Ambos são fecho resistido da mão; contacto e perfil ficam na variante. |
| Pega espessa | Variante de sustentação | O diâmetro muda contacto e desempenho, não o objetivo de suporte. |
| Towel hang | Variante do dead hang | A interface deformável muda a exigência, mas preserva a suspensão. |
| Transporte em pinça | Variante da pinça isométrica | Acrescenta locomoção sem criar nova capacidade de pinça. |
| `coracobrachialis` | Sem relação direta neste catálogo | As ações diretas são glenoumerais; não se força uma relação contextual sem evidência específica da tarefa. |
| `grip_limiter` | Campo separado do alvo muscular | Um potencial limitador não é promovido a músculo principal e nunca representa um resultado observado da série. |
| Pegas móveis de suspensão | Cadeia mista | Pés mantêm contacto com o solo, mãos mantêm contacto com pegas móveis e nenhum segmento distal é geometricamente fixo. |
| Fundos | Modelação por fase | A extensão do ombro descreve a descida; o regresso em direção a neutro ocorre na subida e é registado separadamente. |
| Cabeças do tríceps | Participação sem ênfase automática | Só a cabeça longa acima da cabeça conserva ênfase moderadamente suportada; as restantes ficam em evidência insuficiente. |

## Achado de proveniência

`src_murray_elbow_1995` na base v0.1.1 aponta para o PMID `7581389`, que não corresponde ao artigo. O PMID correto é `7775488`, DOI `10.1016/0021-9290(94)00114-J`. A base não foi alterada; este catálogo usa o URL correto e envia a correção para revisão.
