# Auditoria anatómica independente final

## Veredito

**PASS**

O alvo congelado:

`test_build7/EveFit_Principal_Arm_Exercise_Catalogue_v0.1`

passa a reauditoria anatómica e funcional. Os seis blockers originais,
`ANAT-B01` a `ANAT-B06`, permanecem corrigidos. O blocker adicional de
projeção pública de preensão, `ANAT-B07`, também está corrigido.

Não foram encontrados blockers anatómicos novos.

Base canónica comparada:

`EveFit_Muscular_Knowledge_Base_v0.1.1`

Esta auditoria foi apenas de leitura. O pacote, a base muscular e a aplicação
não foram alterados. Apenas este relatório de auditoria foi substituído.

## Resultado por blocker

### ANAT-B01 - `grip_limiter` promovido a músculo principal

**Estado:** corrigido.

- Existem 15 relações com `role = grip_limiter`, distribuídas por nove
  exercícios públicos.
- Nenhuma dessas relações é projetada em `primary_muscles`.
- Nos exercícios em que FDP e FDS são alvos da tarefa, o papel muscular está
  separado da expectativa de limitação.
- `grip_limiter_observed` permanece `unknown` nas 228 relações, sem inventar o
  resultado de uma série.

### ANAT-B02 - Ênfase automática da cabeça longa do tricípite

**Estado:** corrigido.

- Existem 33 relações de componentes do tricípite, correspondentes a 11
  exercícios por três cabeças.
- As 30 relações fora da extensão acima da cabeça têm
  `emphasis_evidence = insufficient_evidence`.
- Na extensão acima da cabeça, apenas a cabeça longa possui
  `moderate_supported_emphasis`, com contexto e fontes específicas.
- As cabeças lateral e medial permanecem em `insufficient_evidence`.
- Nenhuma cabeça do tricípite é exposta como alvo separado na camada pública.

### ANAT-B03 - Grande dorsal no curl em suspensão

**Estado:** corrigido.

Em `suspension_bodyweight_curl`, o grande dorsal possui:

- `role = stabilizer`;
- `confidence = low_confidence`;
- `emphasis_evidence = weak_or_indirect_evidence`;
- contexto isométrico explícito para manter o ombro, sem declarar uma remada.

O grande dorsal não aparece entre os músculos principais públicos.

### ANAT-B04 - Cadeia das tarefas com pegas móveis

**Estado:** corrigido.

`suspension_bodyweight_curl` e `suspension_triceps_extension` possuem:

- `kinetic_chain = mixed_chain`;
- `whole_body = mixed_chain_unstable_movable_handle`;
- mãos em contacto com pegas móveis;
- pés em contacto com o solo;
- indicação de que nenhum segmento distal é geometricamente fixo;
- relações articulares e de ação com contexto `mixed_chain`.

Não foi encontrada contradição entre a classificação global e os segmentos.

### ANAT-B05 - Ações por fase nos fundos

**Estado:** corrigido.

Nos fundos no banco e em paralelas:

- `shoulder_extension` representa a cinemática da descida;
- o modo é `descent_under_eccentric_flexor_control`;
- `shoulder_flexion` representa o regresso desde extensão em direção a neutro
  na subida;
- o modo é `concentric_ascent_toward_neutral`;
- `elbow_extension` distingue subida concêntrica e controlo excêntrico da
  descida;
- os perfis por fase coincidem entre `exercises.jsonl` e
  `exercise_action_relations.csv`.

Nos fundos no banco, o peitoral maior permanece `secondary`. Nos fundos em
paralelas, o papel contextual é compatível com flexão/adução do ombro e com a
trajetória declarada. A extensão do ombro não é apresentada como ação
concêntrica do peitoral maior.

### ANAT-B06 - Papel do bicípite nos curls supinados locais

**Estado:** corrigido.

Nos quatro registos:

- `standing_supinated_curl`;
- `shoulder_extended_supinated_curl`;
- `preacher_curl`;
- `spider_curl`;

o bicípite braquial possui:

- `role = primary_contextual`;
- `confidence = moderate_confidence`.

As 12 relações das duas cabeças do bicípite, em seis exercícios, permanecem com
`emphasis_evidence = insufficient_evidence`. Nenhuma cabeça é apresentada
publicamente como alvo seletivo.

### ANAT-B07 - Projeção pública dos novos campos de preensão

**Estado:** corrigido.

Nos três exercícios que combinam papel principal/contextual com potencial de
limitação:

- `dead_hang`;
- `farmers_carry`;
- `suitcase_carry`;

FDP e FDS mantêm:

- `role = primary_contextual`;
- `grip_role_default = potential_limiter`;
- `grip_limiter_default = possible`;
- `grip_limiter_observed = unknown`.

As seis relações são agora projetadas corretamente. Nos três registos de
`public_arm_exercises.json`, `potential_grip_limiters` contém:

- Flexor profundo dos dedos;
- Flexor superficial dos dedos.

Os catálogos Markdown apresentam os mesmos dois potenciais limitadores. A
projeção deixa de depender de `role = grip_limiter` e usa
`grip_role_default = potential_limiter` com estado `likely` ou `possible`.

No `parallel_bar_support_hold`, FDP e FDS possuem agora relações próprias com:

- `role = stabilizer`;
- `grip_role_default = stabilizer`;
- `grip_limiter_default = unlikely`;
- `grip_limiter_observed = unknown`.

Estes músculos aparecem como estabilizadores públicos, sem serem promovidos a
principais nem a potenciais limitadores.

## Contagens

| Entidade | Total |
|---|---:|
| Exercícios canónicos | 36 |
| Variantes | 85 |
| Relações musculares | 228 |
| Relações articulares | 86 |
| Relações de ação | 68 |
| Exercícios públicos | 35 |
| Claims | 545 |
| Fontes | 24 |
| Relações `grip_limiter` | 15 |
| Relações de preensão `potential_limiter` | 21 |
| Relações de preensão `primary_target` | 6 |
| Relações de contacto `stabilizer` | 2 |

## Verificações independentes

| Verificação | Resultado |
|---|---:|
| Músculos inválidos contra a base | 0 |
| Componentes com pai incorreto | 0 |
| Articulações inválidas | 0 |
| Ações inválidas | 0 |
| Diferenças entre mecânica e CSV articular | 0 |
| Diferenças entre mecânica e CSV de ações | 0 |
| Ações sem articulação compatível no exercício | 0 |
| Músculos principais sem ação compatível na base | 0 |
| Componentes expostos publicamente | 0 |
| `grip_limiter` promovido a principal público | 0 |
| Divergências na projeção pública de potenciais limitadores | 0 |
| Potenciais limitadores em falta no `dead_hang` | 0 |
| Potenciais limitadores em falta no `farmers_carry` | 0 |
| Potenciais limitadores em falta no `suitcase_carry` | 0 |
| Erros nos campos de preensão do apoio em paralelas | 0 |
| Ênfases positivas não suportadas nas cabeças do tricípite | 0 |
| Ênfases seletivas nas cabeças do bicípite | 0 |
| Erros de cadeia nas duas suspensões móveis | 0 |
| Erros nos perfis por fase dos dois fundos | 0 |

Foram ainda executados dois validadores sobre o alvo:

- validador incluído no pacote: 9 033 verificações, zero falhas;
- validador externo reforçado: 9 033 verificações, zero falhas.

Os validadores confirmam agora explicitamente:

- compatibilidade geral entre músculos principais e ações da base;
- projeção de potenciais limitadores pelos novos campos;
- ausência de promoção de `grip_limiter` a músculo principal;
- contacto da mão no apoio em paralelas como estabilização com limitação
  improvável;
- cadeia mista nas duas tarefas com pegas móveis;
- ações por fase nos fundos.

## Conclusão

`ANAT-B01` a `ANAT-B07` estão resolvidos no alvo `test_build7`. A estrutura
anatómica, os componentes do bicípite e do tricípite, a cadeia das suspensões,
as ações por fase dos fundos e a camada pública são coerentes dentro do âmbito
auditado.

**Veredito final anatómico: PASS, sem blockers.**
