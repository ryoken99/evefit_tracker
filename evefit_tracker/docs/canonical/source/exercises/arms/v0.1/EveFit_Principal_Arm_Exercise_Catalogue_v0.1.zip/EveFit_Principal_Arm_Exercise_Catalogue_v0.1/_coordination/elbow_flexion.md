# Relatório independente da Equipa 1: flexão do cotovelo

## Catálogo Canónico dos Principais Exercícios de Braços v0.1

**Âmbito deste relatório:** identidade, cobertura, mecânica, relações anatómicas, evidência, segurança e terminologia PT-PT para exercícios de flexão do cotovelo.

**Base canónica usada:** `EveFit_Muscular_Knowledge_Base_v0.1.1.zip`

**SHA-256 verificado:** `a1876a1d4bc21ab54b3828774f66a99519a4953dc00191e69475d8c15b8b30b0`

**Estado:** investigação independente concluída. Não foi alterado qualquer ficheiro da base muscular, aplicação EveFit, catálogo final, schema, claim ou fonte.

## 1. Resultado executivo

Recomendo oito identidades mecânicas para a família de flexão do cotovelo:

1. `standing_supinated_elbow_curl`
2. `shoulder_extended_supinated_elbow_curl`
3. `preacher_supinated_elbow_curl`
4. `spider_supinated_elbow_curl`
5. `neutral_grip_elbow_curl`
6. `pronated_grip_elbow_curl`
7. `supinated_chin_up`
8. `suspension_elbow_curl`

O curl de concentração deve existir como `exercise_variant` público do curl supinado apoiado, mas não como nona identidade canónica. Barra reta, barra EZ, halteres, cabo, banda e máquina são variantes de equipamento ou manifestações mecânicas das identidades acima. Alternar braços, executar unilateralmente e pequenas alterações de largura de pega são configuração, não exercício novo.

As três orientações do antebraço justificam identidades públicas próprias:

- supinada, porque o bicípite braquial combina flexão do cotovelo com capacidade de supinação;
- neutra, porque altera a coordenação entre flexores e permite um padrão martelo reconhecido;
- pronada, porque reduz a vantagem mecânica do bicípite e aumenta a contribuição contextual exigida a outros flexores.

Isto não autoriza alegações de isolamento. O `brachialis` continua a ser principal contribuinte anatómico para flexão do cotovelo na base v0.1.1. O `biceps_brachii` deve ser `primary_contextual` em curls supinados, e `secondary` nas versões neutra e pronada. O `brachioradialis` pode ser `primary_contextual` nas versões neutra e pronada, mas apenas com confiança moderada e com a limitação explícita de que os estudos de sEMG não são uniformes.

Não deve ser publicada ênfase seletiva na cabeça longa ou curta do bicípite para nenhum destes exercícios. Ambas as cabeças participam na unidade muscular, mas a evidência disponível não demonstra recrutamento independente nem superioridade adaptativa específica por cabeça.

## 2. Política de identidade aplicada

### 2.1 Novo exercício canónico

Foi criada uma identidade própria quando muda pelo menos um destes elementos de forma material:

- orientação do antebraço mantida durante a flexão;
- posição glenoumeral que altera o comprimento do bicípite;
- apoio ou liberdade do braço;
- cadeia cinética e segmento que se move;
- perfil externo de resistência suficientemente característico;
- exigência de estabilidade;
- trajetória reconhecida e objetivo técnico.

### 2.2 Variante

Uma variante herda a identidade principal e declara apenas os campos que mudam:

- `equipment_variant`: barra, halteres, cabo, banda ou máquina;
- `grip_orientation_variant`: apenas quando a alteração não constitui já uma das três identidades de pega;
- `technique_variant`: trajetória, apoio ou supinação dinâmica;
- `exercise_variant`: manifestação reconhecida com diferença prática, mas insuficiente para nova identidade canónica;
- `configuration`: unilateral, bilateral, alternado, largura de pega, carga, cadência e amplitude prescrita.

### 2.3 Regra fail-closed para máquinas e cabos

“Curl na máquina” e “curl no cabo” não determinam, por si sós, a mecânica. O registo deve guardar:

- posição do ombro;
- existência e ângulo do apoio do braço;
- orientação da pega;
- localização da polia ou eixo;
- direção inicial e final da resistência;
- perfil de resistência conhecido ou `unknown_manufacturer_specific`;
- amplitude permitida;
- unilateralidade.

Sem estes campos, não se deve inferir um perfil de resistência nem ênfase muscular específica.

## 3. Decisão sobre todos os candidatos obrigatórios

| Candidato | Classificação recomendada | Identidade-pai | Estado público | Decisão |
|---|---|---|---|---|
| Curl com barra reta | `equipment_variant` | `standing_supinated_elbow_curl` | `approved_public` | A barra fixa uma pega bilateral supinada, mas não cria uma ação articular nova. |
| Curl com barra EZ | `equipment_variant` + `grip_orientation_variant` | `standing_supinated_elbow_curl` | `approved_public` | A pega é semi-supinada e pode alterar conforto e coordenação, mas a pequena diferença de sEMG não justifica exercício canónico separado. |
| Curl com halteres | `equipment_variant` | `standing_supinated_elbow_curl` | `approved_public` | Permite braços independentes e supinação fixa ou dinâmica. Continua a mesma identidade quando o ombro permanece neutro. |
| Curl alternado | `configuration` | variante com halteres | `approved_public` | A sequência temporal entre braços não altera a mecânica de cada repetição. |
| Curl inclinado | manifestação pública principal de `shoulder_extended_supinated_elbow_curl` | próprio | `approved_with_limits` | A extensão do ombro e o apoio do tronco alteram o comprimento do bicípite e a estabilidade. Não implica superioridade universal. |
| Curl Scott / preacher | `canonical_exercise` | próprio | `approved_public` | O braço está apoiado e o ombro flexionado. O apoio, a posição e o perfil gravitacional justificam identidade própria. |
| Curl de concentração | `exercise_variant` | `preacher_supinated_elbow_curl` | `approved_with_limits` | Braço apoiado na coxa, unilateral, com geometria menos padronizada. É reconhecido, mas não acrescenta identidade mecânica suficiente além do curl apoiado. |
| Curl spider | `canonical_exercise` | próprio | `approved_with_limits` | Ombro flexionado, braço livre e tronco apoiado de bruços. Distingue-se do Scott pela ausência de apoio posterior do braço e pela estabilidade. |
| Curl no cabo | `equipment_variant` | normalmente `standing_supinated_elbow_curl` | `approved_public` | A polia baixa com ombro neutro é variante de equipamento. Outras geometrias devem apontar para a identidade posicional correta. |
| Curl unilateral no cabo | `configuration` | variante no cabo | `approved_public` | Unilateralidade não cria identidade nova. Permite ajustar a linha de tração e deve guardar o lado. |
| Curl na máquina | `equipment_variant` com classificação geométrica obrigatória | em pé/neutro ou Scott | `approved_with_limits` | Não existe uma “máquina de curl” mecânica universal. A entidade só é publicável após classificar apoio, eixo, pega e perfil. |
| Curl martelo | manifestação pública de `neutral_grip_elbow_curl` | próprio | `approved_public` | A posição neutra é materialmente distinta e reconhecida. |
| Curl martelo cruzado | `technique_variant` | `neutral_grip_elbow_curl` | `approved_with_limits` | A trajetória cruza o tronco e acrescenta movimento glenoumeral, mas a principal ação continua a ser flexão do cotovelo em pega neutra. |
| Curl inverso | manifestação pública de `pronated_grip_elbow_curl` | próprio | `approved_public` | A pronação mantida reduz a vantagem do bicípite e muda a coordenação dos flexores. |
| Chin-up com pega supinada | `canonical_exercise`, multiarticular | próprio | `approved_public` | Exercício de puxar em cadeia fechada. Deve ser cruzado no catálogo de braços, sem ser apresentado como exercício local de bicípite. |
| Curl com banda | `equipment_variant` | identidade de pega e ombro correspondente | `approved_public` | A banda altera a relação força-alongamento, mas não cria ação ou trajetória nova. |
| Curl em suspensão / peso corporal | `canonical_exercise` | próprio | `approved_with_limits` | O corpo move-se relativamente às mãos, existe instabilidade e a cadeia é fechada ou mista. É mecanicamente distinto do curl com resistência externa livre. |

### 3.1 Barra reta versus barra EZ

Decisão: mesma identidade canónica, variantes de equipamento e de orientação da pega.

Justificação:

- ambas executam flexão do cotovelo em cadeia aberta com resistência gravitacional;
- a barra EZ permite semi-supinação, enquanto a barra reta fixa uma supinação mais completa;
- os estudos agudos encontraram diferenças pequenas e dependentes da fase, sem evidência longitudinal de superioridade;
- a escolha deve poder ser guiada por tolerância individual do punho, cotovelo e antebraço, sem declarar a barra EZ universalmente “mais segura”.

### 3.2 Barra versus halteres

Decisão: variantes de equipamento da mesma identidade quando ombro, pega e trajetória permanecem equivalentes.

Os halteres permitem:

- trabalho unilateral ou bilateral;
- movimento independente dos braços;
- supinação dinâmica;
- ajuste individual da pega;
- maior liberdade do punho e ombro.

Essas capacidades devem ser campos da variante, não identidades automáticas. Um curl inclinado com halteres pertence à identidade de ombro em extensão, não à identidade genérica em pé.

### 3.3 Cabo, banda e máquina

Decisão: variantes de equipamento com sobreposições mecânicas obrigatórias.

- A resistência de um cabo não é “constante” no momento articular. A força do cabo pode ser aproximadamente constante, mas o momento no cotovelo muda com a linha de tração, distância à polia e ângulo do antebraço.
- A banda tende a aumentar a força à medida que alonga, mas o momento articular também depende da geometria. “Mais difícil no topo” não é universal.
- A máquina depende da came, do eixo, do apoio e da pega. Não inferir o perfil a partir do nome comercial.

## 4. Grafo articulação, ação e fase

### 4.1 Curls em cadeia aberta

| Campo | Regra |
|---|---|
| Articulação principal | `elbow_joint` |
| Ação concêntrica | `elbow_flexion` |
| Ação excêntrica | controlo de extensão do cotovelo sob momento externo |
| Isométrica | manutenção do ângulo do cotovelo, quando prescrita |
| Cadeia | `open_chain` |
| Segmento proximal | braço relativamente estável |
| Segmento móvel | antebraço e implemento |
| Plano | predominantemente sagital |
| Eixo | mediolateral |

### 4.2 Supinação fixa versus dinâmica

Esta distinção deve ser obrigatória:

- **pega já supinada e mantida:** `forearm_supination` não é uma ação dinâmica da repetição. É posição do antebraço e possível função isométrica/neutralizadora contra um momento de pronação;
- **halter começa neutro e roda para supinação:** adicionar `proximal_radioulnar_joint / forearm_supination` na fase concêntrica e controlo excêntrico da rotação no regresso;
- **pega neutra ou pronada mantida:** não adicionar pronação ou supinação dinâmica apenas por causa da orientação da pega.

O erro “posição = ação” deve ser bloqueado por validação.

### 4.3 Chin-up supinado

| Campo | Relação |
|---|---|
| Cotovelo | `elbow_flexion` durante a subida; controlo excêntrico durante a descida |
| Ombro | adução e/ou extensão dependente da trajetória |
| Escápula | depressão, rotação e retração contextuais |
| Cadeia | fechada, mãos fixas na barra e corpo móvel |
| Antebraço | supinação mantida, não necessariamente supinação dinâmica |
| Punho e dedos | preensão isométrica, potencial `grip_limiter` |

### 4.4 Curl em suspensão

| Campo | Relação |
|---|---|
| Cotovelo | flexão concêntrica e controlo excêntrico |
| Ombro | posição flexionada ou variável, conforme altura dos cotovelos |
| Cadeia | `closed_or_mixed_chain` |
| Segmento distal | mãos ligadas a pegas móveis ancoradas |
| Segmento móvel | corpo e braço movem-se relativamente ao ponto de ancoragem |
| Estabilidade | elevada exigência contextual de tronco, ombro e pega |

Não classificar automaticamente como cadeia fechada rígida, porque as pegas de suspensão não são um apoio fixo comparável ao chão ou a uma barra imóvel.

## 5. Relações exercício-músculo

### 5.1 Regra global

As classificações abaixo são específicas da tarefa. Não substituem as relações anatómicas da v0.1.1.

| Músculo | Papel recomendado | Contexto |
|---|---|---|
| `brachialis` | `primary` | Todos os exercícios com flexão dinâmica do cotovelo. É monoarticular e a sua função não depende diretamente da rotação do antebraço. |
| `biceps_brachii` | `primary_contextual` | Curls supinados e com supinação dinâmica. Combina flexão do cotovelo e supinação. |
| `biceps_brachii` | `secondary` | Curl martelo e curl inverso. Mantém capacidade flexora, mas a contribuição relativa muda com a posição. |
| `brachioradialis` | `secondary` | Curls supinados. |
| `brachioradialis` | `primary_contextual` | Curl martelo e curl inverso, com confiança moderada e limitação por evidência de sEMG divergente. |
| `supinator` | `synergist` | Apenas quando existe supinação dinâmica ou resistência relevante à pronação. |
| `pronator_teres` | `synergist` ou `neutralizer` | Pode assistir flexão e estabilizar a orientação em tarefas neutras/pronadas; confiança baixa e não expor como músculo principal. |
| flexores dos dedos e polegar | `grip_limiter` / `stabilizer` | Quando a preensão do implemento limita a série. Herda relações detalhadas da equipa de preensão. |
| extensores do punho | `stabilizer` / `neutralizer` | Podem contrariar o momento de flexão do punho criado pela pega. Dependente do implemento. |
| `deltoid` | `stabilizer` | Controlo glenoumeral em curls com braço livre; não é músculo principal da flexão do cotovelo. |

### 5.2 Papéis por identidade

| Identidade | `brachialis` | `biceps_brachii` | `brachioradialis` | Outros |
|---|---|---|---|---|
| `standing_supinated_elbow_curl` | `primary`, moderada | `primary_contextual`, moderada | `secondary`, moderada | `supinator` sinergista se houver rotação dinâmica; pega contextual |
| `shoulder_extended_supinated_elbow_curl` | `primary`, moderada | `primary_contextual`, moderada | `secondary`, moderada | estabilizadores glenoumerais e escapulares contextuais |
| `preacher_supinated_elbow_curl` | `primary`, moderada | `primary_contextual`, moderada | `secondary`, moderada | apoio reduz exigência de estabilização do braço |
| `spider_supinated_elbow_curl` | `primary`, moderada | `primary_contextual`, moderada | `secondary`, moderada | deltoide e estabilizadores do ombro contextuais |
| `neutral_grip_elbow_curl` | `primary`, moderada | `secondary`, moderada | `primary_contextual`, baixa a moderada | pega e punho contextuais |
| `pronated_grip_elbow_curl` | `primary`, moderada | `secondary`, moderada | `primary_contextual`, moderada | `pronator_teres` contextual; extensores do punho frequentemente relevantes |
| `supinated_chin_up` | `primary_contextual` para a ação do cotovelo | `primary_contextual` para a ação do cotovelo, mas `secondary` no exercício global | `secondary` | dorsais e músculos escapulares são determinantes do exercício global; preensão pode limitar |
| `suspension_elbow_curl` | `primary`, moderada | `primary_contextual`, baixa a moderada | `secondary`, baixa | estabilização de tronco, ombro e pega elevada |

### 5.3 Componentes do bicípite

IDs válidos na base:

- `biceps_brachii_long_head`
- `biceps_brachii_short_head`

Política recomendada para v0.1:

- `emphasized_component_ids: []` para todos os exercícios desta família;
- guardar ambas as cabeças como `participating_components` apenas na camada interna;
- não somar volume do componente ao volume do `biceps_brachii`;
- não publicar “inclinado para cabeça longa”, “Scott para cabeça curta” ou equivalentes;
- posição do ombro pode alterar comprimento e coordenação, mas isso não prova ênfase seletiva estável numa cabeça nem hipertrofia preferencial dessa cabeça.

O estudo cadavérico de Jarrett et al. encontrou diferenças funcionais entre os feixes distais das cabeças a 90° de flexão, mas seis cadáveres e uma condição de teste não justificam uma regra pública de seleção de exercícios por cabeça.

## 6. Perfis mecânicos e de resistência

| Identidade / variante | Posição do ombro | Antebraço | Apoio | Perfil externo resumido |
|---|---|---|---|---|
| Curl em pé com peso livre | aproximadamente neutro | supinado | braço livre | Momento gravitacional baixo quando o antebraço se aproxima da vertical e maior quando a distância perpendicular à gravidade aumenta. Não fixar um ângulo universal. |
| Curl inclinado com halteres | extensão | supinado ou supinação dinâmica | tronco apoiado, braço livre | O bicípite inicia mais alongado no ombro. O perfil continua dependente da gravidade e da posição real do braço. |
| Curl Scott com barra/halter | flexão | supinado/semi-supinado | braço apoiado | Tendência para maior momento externo perto da zona alongada/inicial e redução quando o antebraço fica mais vertical. |
| Curl Scott no cabo | flexão | variável | braço apoiado | O perfil depende da posição da polia. Pode deslocar desafio para zonas mais encurtadas, mas deve ser calculado pela geometria real. |
| Curl spider | flexão | supinado | tronco apoiado, braço livre | A gravidade mantém desafio relevante na zona média; apoio do tronco reduz balanço, mas não fixa o braço. |
| Curl martelo | neutro no ombro | neutro | braço livre | Perfil do implemento, geralmente gravitacional com halteres. Muda coordenação muscular, não a ação principal do cotovelo. |
| Curl inverso | neutro no ombro | pronado | braço livre | Perfil semelhante ao curl de peso livre correspondente, com maior exigência contextual do punho e menor vantagem do bicípite. |
| Curl no cabo em pé | depende da polia | variável | braço livre | Não chamar “tensão constante” ao momento articular. Registar vetor e distância à polia. |
| Curl com banda | variável | variável | braço livre | A força tende a aumentar com alongamento, mas o momento articular resulta também da direção e braço externo. |
| Chin-up | variável | supinação fixa | mãos fixas | Resistência é o peso corporal e cargas adicionais; perfil multiarticular dependente da trajetória e antropometria. |
| Curl em suspensão | ombro flexionado/variável | supinado ou neutro | pegas instáveis | Dificuldade muda com ângulo corporal, posição dos pés, comprimento das fitas e altura do ponto de ancoragem. |

## 7. Conteúdo técnico mínimo por identidade

### 7.1 `standing_supinated_elbow_curl`

- **Nome PT-PT:** Curl de bíceps em pé com pega supinada.
- **Nome inglês:** Standing supinated elbow curl.
- **Sinónimos:** curl de bíceps em pé; curl supinado; barbell curl; dumbbell curl.
- **Descrição:** flexão do cotovelo em cadeia aberta, com braço junto ao tronco e antebraço supinado ou a supinar.
- **Execução:** iniciar estável, fletir o cotovelo sem usar impulso do tronco, terminar dentro da amplitude controlável e regressar de forma controlada.
- **Cues:** punho próximo do neutro; ombro controlado; carga junto da trajetória pretendida; não transformar a repetição em flexão do ombro.
- **Erros frequentes:** balanço do tronco; avanço exagerado do cotovelo; punho em extensão forçada; queda rápida na descida; amplitude forçada.
- **Paragem:** dor aguda, sensação de estalido, perda súbita de força, dormência ou incapacidade de controlar a descida.

### 7.2 `shoulder_extended_supinated_elbow_curl`

- **Nome PT-PT:** Curl com o ombro em extensão.
- **Manifestação principal:** curl inclinado com halteres.
- **Manifestação secundária:** curl no cabo de costas para a polia, por vezes chamado curl Bayesian.
- **Descrição:** curl supinado com o braço atrás do plano do tronco.
- **Execução:** ajustar banco ou cabo sem forçar a extensão glenoumeral; manter o braço dentro da posição tolerada; fletir e estender o cotovelo de forma controlada.
- **Limitação pública:** a posição altera comprimento e mecânica, mas estudos longitudinais recentes não demonstram superioridade universal quando o perfil de resistência e a amplitude são equiparados.
- **Cautela:** dor anterior do ombro, patologia do tendão proximal do bicípite ou limitação de extensão do ombro exigem regressão ou avaliação especialista.

### 7.3 `preacher_supinated_elbow_curl`

- **Nome PT-PT:** Curl Scott.
- **Sinónimos:** curl no banco Scott; preacher curl; curl com braço apoiado.
- **Descrição:** flexão do cotovelo com a face posterior do braço apoiada e o ombro em flexão.
- **Execução:** alinhar o cotovelo com a zona de rotação do apoio; manter contacto amplo do braço; baixar apenas até à amplitude controlável; evitar relaxar ou deixar cair a carga perto da extensão.
- **Erros frequentes:** banco mal ajustado; apoio no cotovelo em vez do braço; perda de tensão e arrancada no fundo; carga excessiva; hiperextensão forçada.
- **Cautela:** o apoio não torna o exercício perigoso por definição. O risco aumenta com carga súbita, descida sem controlo ou tentativa de resistir a uma extensão inesperada perto do cotovelo estendido.

### 7.4 `spider_supinated_elbow_curl`

- **Nome PT-PT:** Curl spider de bruços.
- **Nome descritivo alternativo:** curl de bruços em banco inclinado.
- **Descrição:** curl supinado com tronco apoiado de bruços, ombro flexionado e braços livres.
- **Execução:** apoiar o tronco sem comprimir a respiração; deixar os braços suspensos; fletir o cotovelo sem projetar o ombro; controlar a descida.
- **Estado:** `approved_with_limits`, porque a identidade mecânica é clara, mas a evidência comparativa própria é escassa.

### 7.5 `neutral_grip_elbow_curl`

- **Nome PT-PT:** Curl martelo.
- **Nome inglês:** Hammer curl.
- **Descrição:** flexão do cotovelo mantendo o antebraço em posição neutra.
- **Execução:** manter polegares orientados para cima; não rodar o antebraço durante a repetição, salvo variante declarada; evitar desvio do punho.
- **Relação muscular:** braquial principal; braquiorradial como principal contextual; bicípite secundário.
- **Limitação:** não publicar “isola o braquial” nem “ativa sempre mais o braquiorradial”. Os estudos de sEMG não são concordantes.

### 7.6 `pronated_grip_elbow_curl`

- **Nome PT-PT:** Curl inverso.
- **Nome inglês:** Reverse curl.
- **Descrição:** flexão do cotovelo com antebraço pronado e pega dorsal.
- **Execução:** usar carga compatível com controlo do punho; manter a pronação sem deixar o punho colapsar em flexão; controlar a descida.
- **Relação muscular:** braquial principal; braquiorradial principal contextual; bicípite secundário; extensores do punho frequentemente estabilizadores.
- **Cautela:** reduzir carga ou usar barra EZ/halteres se a pega reta pronada provocar desconforto do punho ou antebraço.

### 7.7 `supinated_chin_up`

- **Nome PT-PT:** Elevação na barra fixa com pega supinada.
- **Nome inglês:** Supinated chin-up.
- **Descrição:** puxar o corpo em direção à barra com mãos fixas, combinando flexão do cotovelo, movimento glenoumeral e controlo escapular.
- **Classificação:** multiarticular, cadeia fechada.
- **Regra pública:** não apresentar como “curl com peso corporal” nem como exercício exclusivo do bicípite.
- **Regressões:** assistência por banda ou máquina; amplitude parcial controlada; isometria em posição tolerada.
- **Cautelas:** incapacidade de controlar a descida, dor do ombro/cotovelo/punho e perda da pega são condições de paragem.

### 7.8 `suspension_elbow_curl`

- **Nome PT-PT:** Curl em suspensão com peso corporal.
- **Nome inglês:** Suspension bodyweight elbow curl.
- **Descrição:** com as mãos nas pegas e o corpo inclinado, fletir os cotovelos aproximando o corpo das mãos, mantendo alinhamento corporal.
- **Execução:** verificar ancoragem; regular inclinação; manter cotovelos elevados conforme a variante; mover o corpo como unidade; controlar o regresso.
- **Progressão/regressão:** aproximar ou afastar os pés do ponto de ancoragem e alterar o ângulo corporal.
- **Cautela:** falha da ancoragem, escorregamento, perda de alinhamento e dor do ombro/cotovelo.
- **Evidência:** identidade baseada em mecânica e uso reconhecido; evidência específica para adaptação muscular é insuficiente.

## 8. Evidência de ênfase muscular

| Afirmação | Classificação | Decisão |
|---|---|---|
| A pega supinada favorece a contribuição/excitação do bicípite relativamente à pega neutra ou pronada | `moderate_supported_emphasis` | Apoiada por estudos agudos, sem extrapolar para hipertrofia superior. |
| O curl martelo enfatiza sempre o braquiorradial | `disputed` | Há plausibilidade mecânica e tradição, mas resultados de sEMG são divergentes. Usar `primary_contextual`, não “isolamento”. |
| O curl inverso reduz a vantagem do bicípite e exige maior contribuição de outros flexores | `moderate_supported_emphasis` | Compatível com biomecânica e coordenação em pronação. |
| Barra reta é superior à EZ para hipertrofia do bicípite | `insufficient_evidence` | Existem diferenças agudas pequenas, sem confirmação longitudinal. |
| EZ é universalmente mais segura para punho e cotovelo | `insufficient_evidence` | Pode melhorar tolerância individual, mas não há base para regra universal. |
| Curl inclinado enfatiza a cabeça longa do bicípite | `insufficient_evidence` | O ombro em extensão alonga a unidade do bicípite, mas não prova seleção da cabeça longa. |
| Curl Scott enfatiza a cabeça curta do bicípite | `insufficient_evidence` | Não publicar. Estudos regionais não equivalem a hipertrofia por cabeça. |
| Inclinado e Scott produzem adaptações regionais diferentes | `moderate_supported_emphasis` | Um ensaio de 2025 encontrou diferenças regionais, mas posição, perfil e apoio mudaram em conjunto. |
| A posição do ombro, isoladamente, determina hipertrofia superior | `disputed` | Estudos de cabo de 2025 e 2026, com perfil mais bem equiparado, não encontraram diferença significativa. |
| Cabo mantém “tensão constante” no bicípite | `false_as_stated` | A força do cabo e o momento articular não são a mesma coisa. |
| Chin-up supinado tem participação relevante do bicípite | `moderate_supported_emphasis` | Apoiado por sEMG, mas continua exercício multiarticular e não prova hipertrofia superior ao curl. |
| Curl em suspensão é superior a pesos livres | `insufficient_evidence` | Não publicar superioridade. |

## 9. Segurança e condições de revisão

### 9.1 Cautelas gerais

- Não forçar amplitude terminal do cotovelo, ombro ou punho.
- Evitar carga que exija balanço, queda rápida ou perda de controlo excêntrico.
- Manter o punho próximo de uma posição tolerável, sem exigir neutralidade rígida universal.
- Inspecionar cabos, bandas, mosquetões, barras e ancoragens antes da série.
- Ajustar banco, apoio e eixo de máquina ao utilizador.
- Interromper perante dor aguda, estalido acompanhado de perda de força, equimose, deformidade, dormência ou fraqueza súbita.

### 9.2 Tendão distal do bicípite

Rupturas distais são raras, mas estão associadas a forças elevadas e inesperadas durante carga excêntrica ou isométrica, frequentemente com cotovelo quase estendido e antebraço supinado. Isto justifica:

- descida controlada;
- progressão gradual;
- ausência de arrancada após relaxar no fundo;
- cautela acrescida em pessoas com dor distal, lesão prévia, cirurgia ou fatores clínicos de risco.

Não justifica classificar o curl Scott, curl inclinado ou qualquer curl supinado como inerentemente perigoso.

### 9.3 Classes propostas

| Exercício / variante | Classe |
|---|---|
| Curl em pé, martelo, inverso, cabo e banda | `general_training` |
| Curl inclinado, Scott, concentração e spider | `caution_required` quando há dor ou limitação do ombro/cotovelo |
| Chin-up e suspensão | `caution_required` pela carga corporal, controlo e ancoragem |
| Pós-ruptura, pós-cirurgia, tendinopatia ativa ou défice neurológico | `specialist_review` |
| Prescrição clínica individual | fora do âmbito |

## 10. Regras PT-PT

### 10.1 Termos públicos recomendados

| Conceito | PT-PT |
|---|---|
| biceps curl | curl de bíceps |
| standing curl | curl em pé |
| incline curl | curl inclinado |
| preacher curl | curl Scott / curl no banco Scott |
| concentration curl | curl de concentração |
| spider curl | curl spider de bruços |
| hammer curl | curl martelo |
| cross-body hammer curl | curl martelo cruzado |
| reverse curl | curl inverso |
| cable curl | curl no cabo |
| band curl | curl com banda elástica |
| machine curl | curl na máquina |
| chin-up | elevação na barra fixa com pega supinada |
| suspension curl | curl em suspensão com peso corporal |
| underhand / supinated grip | pega supinada |
| neutral grip | pega neutra |
| overhand / pronated grip | pega pronada |

### 10.2 Termos a evitar

- “rosca”;
- “bíceps isolado”;
- “cabeça interna/externa” sem correspondência anatómica;
- “tensão constante” para cabo sem análise do momento;
- “pega perfeita” ou “mais segura” sem contexto individual;
- “chin-up de bíceps” como classificação global;
- “curl Bayesian” como único nome público PT-PT.

## 11. Validações automáticas recomendadas

1. Toda relação de exercício com `elbow_flexion` deve apontar para `elbow_joint`.
2. Orientação fixa do antebraço não pode gerar automaticamente `forearm_supination` ou `forearm_pronation` dinâmica.
3. `biceps_brachii_long_head` e `biceps_brachii_short_head` não podem aparecer em `emphasized_component_ids` nesta versão.
4. Componentes não podem ser somados ao músculo-pai para volume ou contagem.
5. `alternating`, `unilateral`, carga, repetições, cadência e largura de pega não podem criar `canonical_exercise`.
6. Toda máquina deve declarar apoio, ombro, pega, eixo e perfil, ou ficar `approved_with_limits`.
7. Todo cabo deve declarar ancoragem e direção da resistência.
8. Toda banda deve declarar ponto de ancoragem e direção inicial/final.
9. `supinated_chin_up` deve ser marcado como `compound` e nunca como exercício monoarticular.
10. `suspension_elbow_curl` deve incluir validação de ancoragem e cadeia `closed_or_mixed`.
11. Nenhuma afirmação de hipertrofia pode depender apenas de sEMG.
12. Nenhum exercício pode alegar isolamento absoluto.
13. Todos os termos públicos devem passar auditoria PT-PT e bloquear “rosca”.
14. A geração deve ser determinística e a ordem dos equipamentos não pode alterar a identidade-pai.

## 12. Finding sobre a base v0.1.1

### `ELBOW_SOURCE_URL_001`

**Tipo:** erro de proveniência localizado, sem alteração anatómica proposta.

**Ficheiro observado:** `11_EVIDENCE/SOURCE_LEDGER.csv`

**Registo:** `src_murray_elbow_1995`

**Problema:** o título e autores identificam “Variation of muscle moment arms with elbow and forearm position”, mas o URL guardado aponta para PMID `7581389`, que corresponde a “An eighth locus for autosomal dominant retinitis pigmentosa is linked to chromosome 17q”.

**Referência correta:**

- PMID: `7775488`
- DOI: `10.1016/0021-9290(94)00114-J`
- URL: <https://pubmed.ncbi.nlm.nih.gov/7775488/>

**Ação recomendada:** colocar na fila de revisão da base muscular. Não corrigir silenciosamente durante a missão do catálogo de exercícios.

## 13. Fontes consultadas

| ID proposto | Tipo | Referência | Identificadores e URL | Uso |
|---|---|---|---|---|
| `src_elbow_moment_arms_murray_1995` | biomecânica cadavérica/modelação | Murray WM, Delp SL, Buchanan TS. Variation of muscle moment arms with elbow and forearm position. J Biomech. 1995. | DOI `10.1016/0021-9290(94)00114-J`; PMID `7775488`; <https://pubmed.ncbi.nlm.nih.gov/7775488/> | Dependência angular e orientação do antebraço. |
| `src_elbow_capacity_murray_2000` | biomecânica/modelação | Murray WM, Buchanan TS, Delp SL. The isometric functional capacity of muscles that cross the elbow. J Biomech. 2000. | DOI `10.1016/S0021-9290(00)00051-8`; PMID `10828324`; <https://pubmed.ncbi.nlm.nih.gov/10828324/> | Capacidade funcional dos músculos do cotovelo. |
| `src_elbow_coordination_buchanan_1989` | EMG isométrica | Buchanan TS, Rovai GP, Rymer WZ. Strategies for muscle activation during isometric torque generation at the human elbow. J Neurophysiol. 1989. | DOI `10.1152/jn.1989.62.6.1201`; PMID `2600619`; <https://pubmed.ncbi.nlm.nih.gov/2600619/> | Sinergias dependentes da tarefa. |
| `src_hand_position_kleiber_2015` | sEMG dinâmica | Kleiber T, Kunz L, Disselhorst-Klug C. Muscular coordination of biceps brachii and brachioradialis in elbow flexion with respect to hand position. Front Physiol. 2015. | DOI `10.3389/fphys.2015.00215`; PMID `26300781`; <https://www.frontiersin.org/articles/10.3389/fphys.2015.00215/full> | Coordenação em supinação, neutro e pronação. |
| `src_forearm_rotation_chen_2025` | sEMG/isometria | Chen Y et al. Forearm rotation and elbow angle differentially modulate biceps brachii and brachioradialis muscle stiffness and EMG activity. BMC Sports Sci Med Rehabil. 2025. | DOI `10.1186/s13102-025-01226-y`; PMID `40604986`; <https://pubmed.ncbi.nlm.nih.gov/40604986/> | Interação entre ângulo e orientação. |
| `src_handgrips_coratella_2023` | sEMG aguda | Coratella G et al. Biceps Brachii and Brachioradialis Excitation in Biceps Curl Exercise: Different Handgrips, Different Synergy. Sports. 2023. | DOI `10.3390/sports11030064`; PMID `36976950`; <https://pubmed.ncbi.nlm.nih.gov/36976950/> | Comparação de pegas supinada, neutra e pronada. |
| `src_bar_variants_marcolin_2018` | sEMG aguda | Marcolin G et al. Differences in electromyographic activity of biceps brachii and brachioradialis while performing three variants of curl. PeerJ. 2018. | DOI `10.7717/peerj.5165`; PMID `30013836`; <https://pubmed.ncbi.nlm.nih.gov/30013836/> | Barra reta, EZ e halteres. |
| `src_straight_ez_coratella_2023` | sEMG aguda | Coratella G et al. Bilateral Biceps Curl Shows Distinct Biceps Brachii and Anterior Deltoid Excitation Comparing Straight vs. EZ Barbell. J Funct Morphol Kinesiol. 2023. | DOI `10.3390/jfmk8010013`; PMID `36810497`; <https://pubmed.ncbi.nlm.nih.gov/36810497/> | Barra reta versus EZ e movimento do ombro. |
| `src_shoulder_position_oliveira_2009` | sEMG aguda | Oliveira LF et al. Effect of the shoulder position on the biceps brachii EMG in different dumbbell curls. J Sports Sci Med. 2009. | PMID `24150552`; PMCID `PMC3737788`; <https://pubmed.ncbi.nlm.nih.gov/24150552/> | Inclinado, Scott e curl clássico. |
| `src_preacher_profile_nunes_2020` | ensaio longitudinal | Nunes JP et al. Placing Greater Torque at Shorter or Longer Muscle Lengths? Effects of Cable vs. Barbell Preacher Curl Training. IJERPH. 2020. | DOI `10.3390/ijerph17165859`; PMID `32823490`; <https://pubmed.ncbi.nlm.nih.gov/32823490/> | Perfil cabo versus barra no Scott; força e hipertrofia. |
| `src_incline_preacher_kassiano_2025` | ensaio longitudinal | Kassiano W et al. Distinct muscle growth and strength adaptations after preacher and incline biceps curls. Int J Sports Med. 2025. | DOI `10.1055/a-2517-0509`; PMID `39809454`; <https://pubmed.ncbi.nlm.nih.gov/39809454/> | Adaptação regional e especificidade de força. |
| `src_preacher_bayesian_attarieh_2025` | ensaio longitudinal | Attarieh P et al. Comparison Between Shoulder Flexed and Extended Positions in Elbow Flexion Resistance Training. Eur J Sport Sci. 2025. | DOI `10.1002/ejsc.12279`; PMID `40082069`; <https://pubmed.ncbi.nlm.nih.gov/40082069/> | Scott no cabo versus curl de costas para a polia. |
| `src_shoulder_extension_larsen_2026` | ensaio longitudinal | Larsen S et al. The effects of shoulder extension angle on elbow flexor hypertrophy in the cable curl exercise. Front Physiol. 2026. | DOI `10.3389/fphys.2026.1750722`; <https://www.frontiersin.org/articles/10.3389/fphys.2026.1750722/full> | Isolar posição do ombro com perfil e amplitude equiparados. |
| `src_chinup_youdas_2010` | sEMG aguda | Youdas JW et al. Surface electromyographic activation patterns and elbow joint motion during a pull-up, chin-up, or rotational exercise. J Strength Cond Res. 2010. | DOI `10.1519/JSC.0b013e3181f1598c`; PMID `21068680`; <https://pubmed.ncbi.nlm.nih.gov/21068680/> | Participação do bicípite no chin-up. |
| `src_biceps_heads_jarrett_2012` | anatomia/biomecânica cadavérica | Jarrett CD et al. Anatomic and biomechanical analysis of the short and long head components of the distal biceps tendon. J Shoulder Elbow Surg. 2012. | DOI `10.1016/j.jse.2011.04.030`; PMID `21813298`; <https://pubmed.ncbi.nlm.nih.gov/21813298/> | Limites de inferência por cabeça. |
| `src_distal_biceps_lappen_2022` | análise observacional de lesões | Lappen S et al. Distal biceps tendon ruptures occur with the almost extended elbow and supinated forearm. BMC Musculoskelet Disord. 2022. | DOI `10.1186/s12891-022-05546-9`; PMID `35733124`; <https://pubmed.ncbi.nlm.nih.gov/35733124/> | Mecanismo de lesão e cautelas. |
| `src_distal_biceps_review_2023` | revisão clínica | Jaschke M et al. Distal biceps tendon rupture: a comprehensive overview. EFORT Open Rev. 2023. | DOI `10.1530/EOR-23-0035`; PMID `37909692`; <https://pubmed.ncbi.nlm.nih.gov/37909692/> | Segurança geral e fatores de risco. |

## 14. Questões em aberto

1. Confirmar no schema final se `primary_contextual` pode ser aplicado a uma ação local dentro de um exercício global, mantendo `secondary` ao nível global do chin-up.
2. Definir se `participating_components` existe separadamente de `emphasized_component_ids`.
3. Definir vocabulário canónico para `closed_or_mixed_chain` em suspensão.
4. Decidir se o curl spider entra no núcleo público inicial ou numa expansão, dado ser reconhecido mas pouco estudado diretamente.
5. Harmonizar a máquina de curl com a taxonomia da equipa de equipamentos antes de gerar relações.
6. Rever o erro de URL `ELBOW_SOURCE_URL_001` numa missão própria da base muscular.

## 15. Recomendações de integração

- Contabilizar oito identidades canónicas nesta família.
- Publicar o curl de concentração como variante reconhecida, não como canónico adicional.
- Cruzar `supinated_chin_up` com o catálogo multiarticular, mantendo uma única entidade.
- Exigir geometria antes de integrar máquinas, cabos e bandas.
- Bloquear todas as alegações seletivas por cabeça do bicípite.
- Tratar a ênfase do braquiorradial em martelo/inverso como contextual, não absoluta.
- Ligar os músculos de preensão por referência à equipa de grip, evitando duplicar relações.
- Preservar a base v0.1.1 e encaminhar apenas o finding de proveniência para revisão.

