# EQUIPA 2 - Extensão do cotovelo e exercícios de tricípite

## Relatório independente para o Catálogo Canónico dos Principais Exercícios de Braços v0.1

**Estado:** concluído para integração crítica  
**Âmbito:** identidade, cobertura, relações anatómicas, componentes do tricípite, segurança e evidência  
**Base anatómica consultada:** `EveFit_Muscular_Knowledge_Base_v0.1.1`  
**Alterações à base muscular:** nenhuma  
**Alterações ao pacote final:** nenhuma  

## 1. Resumo executivo

Recomendo 11 exercícios canónicos para cobrir a extensão do cotovelo dentro do âmbito pedido:

1. `cable_triceps_pushdown`
2. `overhead_triceps_extension`
3. `lying_triceps_extension`
4. `cross_body_cable_triceps_extension`
5. `triceps_kickback`
6. `supported_machine_elbow_extension`
7. `parallel_bar_dip`
8. `bench_dip`
9. `narrow_hand_push_up`
10. `close_grip_barbell_bench_press`
11. `suspension_triceps_extension`

As decisões principais são:

- Barra, corda e execução unilateral no pushdown não justificam três exercícios canónicos. A corda é uma variante de equipamento e a unilateralidade é configuração.
- Cabo, halter e barra EZ na extensão acima da cabeça pertencem ao mesmo exercício canónico, com variantes de equipamento.
- Barra e halteres na extensão deitada pertencem ao mesmo exercício canónico.
- Kickback com halter e com cabo pertence ao mesmo exercício canónico, mas o perfil de resistência deve ser descrito por variante.
- A extensão cruzada no cabo merece identidade canónica própria, desde que o trajeto e a posição do braço sejam definidos de forma não ambígua.
- A designação genérica "máquina de tríceps" não é uma identidade suficiente. O exercício canónico deve ser uma extensão do cotovelo em máquina com braço apoiado e eixo identificável. Uma máquina de fundos ou press é outro exercício.
- Fundos em paralelas, fundos no banco, flexão estreita e supino fechado são quatro exercícios compostos distintos.
- A extensão em suspensão merece identidade canónica própria pela forma de aplicação da força, suporte e exigência de estabilidade, embora a evidência direta específica seja insuficiente.
- "Extensão com banda" sem posição do corpo e ponto de ancoragem não deve ser publicada como exercício canónico. A banda é uma variante de equipamento do pushdown ou da extensão acima da cabeça, conforme a geometria.

Não existe suporte para afirmar isolamento absoluto de qualquer cabeça do tricípite. A melhor alegação prática disponível é uma ênfase contextual moderadamente suportada para a extensão acima da cabeça, sobretudo por trabalhar o tricípite longo em maior comprimento no ombro. Isto não significa que as restantes cabeças deixem de contribuir, nem que todas as implementações acima da cabeça sejam superiores em todos os resultados.

## 2. Regras de identidade usadas

Um novo exercício canónico foi aceite apenas quando existe uma alteração material em pelo menos um dos seguintes elementos:

- articulações ativamente envolvidas;
- posição estrutural do ombro;
- trajetória do segmento;
- cadeia cinética;
- ponto e direção de aplicação da força;
- suporte e estabilidade;
- perfil de resistência;
- amplitude característica;
- objetivo técnico reconhecível.

Não foi criada identidade canónica autónoma por:

- lado unilateral ou bilateral;
- pequena alteração da largura ou orientação da pega;
- barra reta, barra EZ, corda ou halter, quando a tarefa principal se mantém;
- carga, repetições ou cadência;
- nome histórico ou comercial;
- alegações não confirmadas de "cabeça alvo".

### 2.1 Tipos de registo recomendados

| Tipo | Uso neste conjunto |
|---|---|
| `canonical_exercise` | Tarefa mecânica distinta e estável |
| `equipment_variant` | Implemento altera interface ou resistência sem mudar a tarefa base |
| `grip_orientation_variant` | Pronação, neutra ou supinação quando relevante |
| `technique_variant` | Trajeto ou amplitude definidos dentro do mesmo exercício |
| `progression` | Mais carga externa ou geometria corporal mais exigente |
| `regression` | Assistência, menor inclinação ou menor amplitude |
| `configuration_only` | Unilateralidade, lado, ajuste do banco ou cabo |
| `excluded` | Termo demasiado ambíguo para identidade segura |

## 3. Decisões de identidade e cobertura

| Candidato pedido | Decisão | Relação hierárquica | Estado público proposto | Fundamentação |
|---|---|---|---|---|
| Pushdown com barra | Manter como representação base | `canonical_exercise`: `cable_triceps_pushdown` | `approved_public` | Extensão do cotovelo em cadeia aberta com ombro junto do tronco e resistência por polia alta |
| Pushdown com corda | Não criar novo canónico | `equipment_variant` de `cable_triceps_pushdown` | `approved_public` | A interface permite trajetória individual das mãos, mas não cria uma tarefa anatómica diferente |
| Pushdown unilateral | Não criar entidade própria | `configuration_only` de `cable_triceps_pushdown` | `approved_public` | O lado não deve duplicar exercício; pode alterar estabilização e controlo |
| Extensão acima da cabeça no cabo | Representação base | `canonical_exercise`: `overhead_triceps_extension` | `approved_public` | Ombro elevado coloca a cabeça longa em maior comprimento e altera a linha externa |
| Extensão acima da cabeça com halter | Mesma identidade | `equipment_variant` | `approved_public` | Resistência gravítica e pega mudam, mas a tarefa base mantém-se |
| Extensão acima da cabeça com barra EZ | Mesma identidade | `equipment_variant` | `approved_public` | Barra bilateral restringe orientação das mãos, sem criar novo exercício |
| Extensão deitada com barra ou EZ | Representação base | `canonical_exercise`: `lying_triceps_extension` | `approved_public` | Suporte supino, ombro em posição elevada e resistência gravítica própria |
| Extensão deitada com halteres | Mesma identidade | `equipment_variant` | `approved_public` | Permite trajetória independente, mantendo a mesma tarefa |
| Extensão cruzada no cabo | Criar canónico próprio | `canonical_exercise`: `cross_body_cable_triceps_extension` | `approved_with_limits` | Posição cruzada, direção contralateral do cabo e trajetória do braço são materialmente distintas; evidência direta é escassa |
| Kickback com halter | Representação base | `canonical_exercise`: `triceps_kickback` | `approved_with_limits` | Ombro mantido atrás do tronco e extensão do cotovelo com braço fixo |
| Kickback no cabo | Mesma identidade | `equipment_variant` | `approved_with_limits` | A resistência externa muda substancialmente ao longo da amplitude, mas a tarefa base não |
| Máquina de tríceps | Aceitar apenas com definição | `canonical_exercise`: `supported_machine_elbow_extension` | `approved_with_limits` | Exigir braço apoiado, assento e eixo de rotação; "máquina de tríceps" pode também designar fundos assistidos ou press |
| Fundos em paralelas | Criar canónico próprio | `canonical_exercise`: `parallel_bar_dip` | `approved_with_limits` | Exercício composto em cadeia fechada, com movimento do cotovelo e ombro |
| Fundos no banco | Criar canónico próprio | `canonical_exercise`: `bench_dip` | `approved_with_limits` | Apoio posterior e maior extensão do ombro distinguem-no dos fundos em paralelas |
| Flexão estreita | Criar canónico próprio | `canonical_exercise`: `narrow_hand_push_up` | `approved_with_limits` | Exercício composto de peso corporal, mãos fixas e contribuição contextual do tricípite |
| Supino fechado | Criar canónico próprio | `canonical_exercise`: `close_grip_barbell_bench_press` | `approved_with_limits` | Exercício composto de carga externa, com cotovelo e ombro ativos |
| Extensão em suspensão | Criar canónico próprio | `canonical_exercise`: `suspension_triceps_extension` | `approved_with_limits` | Peso corporal aplicado através de pegas móveis, estabilidade elevada e geometria própria |
| Extensão com banda, termo genérico | Não aceitar como canónico | `excluded` enquanto não houver geometria | `internal_only` | A ancoragem determina se é pushdown, extensão acima da cabeça ou outra tarefa |
| Banda ancorada em cima | Mesma identidade do pushdown | `equipment_variant` de `cable_triceps_pushdown` | `approved_with_limits` | A tensão varia com o alongamento e com o braço de momento |
| Banda ancorada atrás ou abaixo para execução acima da cabeça | Mesma identidade da extensão acima da cabeça | `equipment_variant` de `overhead_triceps_extension` | `approved_with_limits` | A posição elevada do ombro define a família |

## 4. Fichas canónicas propostas

### 4.1 `cable_triceps_pushdown`

- **Nome PT-PT:** Extensão de tricípite na polia alta
- **Sinónimos:** pushdown de tríceps; puxada de tríceps na polia
- **Tipo:** `canonical_exercise`
- **Movimento ativo:** `elbow_joint` -> `elbow_extension`
- **Ombro:** aproximadamente neutro ou ligeiramente estendido, mantido de forma isométrica
- **Cadeia:** aberta
- **Músculo primário:** `triceps_brachii`
- **Componentes:** cabeças longa, lateral e medial como `primary_contextual`, sem contagem adicional ao músculo principal
- **Sinergista:** `anconeus`
- **Estabilização contextual:** músculos que mantêm o ombro, escápula, tronco e punho
- **Variantes:** barra reta, barra angular ou EZ, corda, pegas independentes, unilateral
- **Não afirmar:** que a corda isola uma cabeça, que a barra trabalha uma cabeça específica, ou que a supinação/pronação prediz hipertrofia regional
- **Estado:** `approved_public`
- **Evidência da ênfase específica por pega:** `insufficient_evidence`

A ordem das mãos pode alterar o conforto, a trajetória permitida e a atividade aguda de músculos do antebraço. O estudo de Rendos et al. comparou uma pega padrão com pegas esféricas, não corda com barra. Não deve ser citado como prova direta de superioridade da corda. O estudo de Villalba et al. é agudo e suporta diferenças de atividade e desempenho entre configurações, mas não uma nova identidade canónica nem um resultado longitudinal.

### 4.2 `overhead_triceps_extension`

- **Nome PT-PT:** Extensão de tricípite acima da cabeça
- **Tipo:** `canonical_exercise`
- **Movimento ativo:** `elbow_joint` -> `elbow_extension`
- **Ombro:** elevado ou flexionado, predominantemente fixo durante a repetição
- **Cadeia:** aberta
- **Músculo primário:** `triceps_brachii`
- **Componentes:** todas as cabeças contribuem; cabeça longa em comprimento aumentado no ombro
- **Sinergista:** `anconeus`
- **Variantes de equipamento:** cabo, halter, barra EZ, banda
- **Configurações:** uma ou duas mãos, sentado ou de pé
- **Ênfase suportada:** `moderate_supported_emphasis` para contexto de maior comprimento e adaptação do tricípite em comparação com extensão no cabo com braço neutro
- **Estado:** `approved_public`

Maeo et al. encontraram maior aumento de volume do tricípite após 12 semanas de extensão no cabo acima da cabeça do que em posição neutra, incluindo a cabeça longa e o conjunto lateral/medial. A inferência deve ser limitada ao protocolo comparado. Um estudo anterior pequeno de Stasinaki et al. encontrou adaptações de força e arquitetura semelhantes durante seis semanas, e estudos agudos não demonstram isolamento consistente. Assim:

- é defensável apresentar a posição acima da cabeça como uma identidade mecânica distinta;
- é defensável indicar maior comprimento da cabeça longa;
- é defensável uma ênfase contextual moderada;
- não é defensável dizer que "só trabalha a cabeça longa";
- não é defensável afirmar superioridade universal de qualquer versão acima da cabeça.

### 4.3 `lying_triceps_extension`

- **Nome PT-PT:** Extensão de tricípite deitado
- **Sinónimos:** extensão de tríceps deitado; skull crusher
- **Tipo:** `canonical_exercise`
- **Movimento ativo:** `elbow_joint` -> `elbow_extension`
- **Ombro:** elevado em relação ao tronco e estabilizado; o grau exato depende do trajeto
- **Cadeia:** aberta
- **Músculo primário:** `triceps_brachii`
- **Componentes:** todas as cabeças; ênfase da cabeça longa moderadamente suportada quando comparada com o supino no estudo longitudinal disponível
- **Sinergista:** `anconeus`
- **Variantes:** barra reta ou EZ, halteres, trajeto à testa ou ligeiramente atrás da cabeça
- **Estado:** `approved_public`

O trajeto "atrás da cabeça" pode ser tratado como `technique_variant` se alterar de modo explícito a posição do ombro e o perfil externo. Não deve ser criado como mero sinónimo. Brandão et al. suportam diferença de adaptação regional entre extensão deitada e supino, mas não demonstram superioridade sobre todas as extensões isoladas. Alves et al. encontraram padrões agudos semelhantes entre extensões com halter acima da cabeça e deitadas, o que reforça a necessidade de evitar alegações rígidas de isolamento por posição.

### 4.4 `cross_body_cable_triceps_extension`

- **Nome PT-PT:** Extensão cruzada de tricípite no cabo
- **Tipo:** `canonical_exercise`
- **Definição necessária:** extensão unilateral do cotovelo com o braço colocado à frente ou cruzado em relação ao tronco e cabo vindo do lado contralateral
- **Movimento ativo principal:** `elbow_joint` -> `elbow_extension`
- **Ombro:** flexionado e horizontalmente aduzido como posição predominantemente isométrica
- **Cadeia:** aberta
- **Músculo primário:** `triceps_brachii`
- **Componentes:** sem alegação pública de cabeça específica
- **Sinergista:** `anconeus`
- **Estado:** `approved_with_limits`
- **Confiança da identidade:** moderada
- **Confiança de ênfase regional:** insuficiente

A identidade é defensável pela direção contralateral da força e posição do braço, mas o nome é usado de forma inconsistente no treino. O catálogo deve incluir uma descrição técnica ou imagem de referência. Se a execução for apenas um pushdown unilateral em diagonal, deve ser fundida com o pushdown, não publicada como novo exercício.

### 4.5 `triceps_kickback`

- **Nome PT-PT:** Extensão de tricípite com o braço atrás do tronco
- **Sinónimo:** kickback de tríceps
- **Tipo:** `canonical_exercise`
- **Movimento ativo:** `elbow_joint` -> `elbow_extension`
- **Ombro:** em extensão, mantido predominantemente isométrico
- **Cadeia:** aberta
- **Músculo primário:** `triceps_brachii`
- **Componentes:** sem alegação pública de isolamento
- **Sinergista:** `anconeus`
- **Variantes:** halter e cabo
- **Estado:** `approved_with_limits`

No halter, o torque externo do cotovelo tende a ser baixo quando o antebraço se aproxima da vertical e aumenta quando o antebraço se aproxima da horizontal. No cabo, o perfil depende da direção do cabo, que pode manter resistência relevante noutras partes da amplitude. Esta diferença justifica perfis mecânicos próprios por variante, mas não duas identidades canónicas.

A cabeça longa está encurtada no ombro em extensão e encurta adicionalmente no cotovelo durante a extensão. A possibilidade de menor capacidade ativa perto do fim da amplitude é uma inferência mecânica plausível, não uma prova de que o exercício "retira" a cabeça longa ou isola as outras.

### 4.6 `supported_machine_elbow_extension`

- **Nome PT-PT:** Extensão do cotovelo na máquina com braço apoiado
- **Tipo:** `canonical_exercise`
- **Definição necessária:** utilizador sentado, braços ou cotovelos apoiados, rotação principal no cotovelo e resistência por alavanca ou came
- **Movimento ativo:** `elbow_joint` -> `elbow_extension`
- **Cadeia:** aberta
- **Músculo primário:** `triceps_brachii`
- **Componentes:** todas as cabeças, sem ênfase regional presumida
- **Sinergista:** `anconeus`
- **Estado:** `approved_with_limits`

Não deve existir uma curva de resistência universal para "a máquina de tríceps". A posição do eixo, o comprimento das alavancas, o came e o encosto são específicos de cada máquina. Uma máquina de fundos ou uma máquina de press vertical deve ser ligada à família de fundos ou presses, não a esta identidade.

### 4.7 `parallel_bar_dip`

- **Nome PT-PT:** Fundos em paralelas
- **Tipo:** `canonical_exercise`
- **Movimentos ativos:** extensão do cotovelo e movimento do ombro para elevar o corpo; a contribuição exata do ombro depende da inclinação e trajetória
- **Cadeia:** fechada e estável
- **Músculos primários contextuais:** `triceps_brachii` e `pectoralis_major`
- **Secundário:** deltoide, conforme a trajetória
- **Sinergista:** `anconeus`
- **Estabilizadores:** cintura escapular, tronco e preensão
- **Variantes:** assistido, com carga adicional, argolas
- **Estado:** `approved_with_limits`

Argolas são uma variante de equipamento e instabilidade, não outro exercício canónico. Assistência é regressão e carga externa é progressão. A profundidade deve ser condicionada pela amplitude confortável do ombro e pelo controlo escapular.

### 4.8 `bench_dip`

- **Nome PT-PT:** Fundos no banco
- **Tipo:** `canonical_exercise`
- **Movimentos ativos:** extensão do cotovelo e movimento do ombro com as mãos atrás do tronco
- **Cadeia:** fechada com apoio posterior das mãos e apoio dos pés
- **Músculo primário contextual:** `triceps_brachii`
- **Secundários contextuais:** `pectoralis_major` e deltoide
- **Sinergista:** `anconeus`
- **Estado:** `approved_with_limits`

McKenzie et al. observaram maior extensão do ombro nos fundos no banco do que nos fundos em barras ou argolas. No protocolo, a amplitude média aproximou-se ou ultrapassou ligeiramente a amplitude máxima individual medida no teste de referência. Isto justifica uma nota de cautela e progressão de amplitude, não uma afirmação absoluta de que o exercício é sempre lesivo.

### 4.9 `narrow_hand_push_up`

- **Nome PT-PT:** Flexão de braços com as mãos próximas
- **Tipo:** `canonical_exercise`
- **Movimentos ativos:** extensão do cotovelo, adução horizontal do ombro e movimento escapular
- **Cadeia:** fechada e estável
- **Músculos primários contextuais:** `triceps_brachii` e `pectoralis_major`
- **Secundário:** deltoide
- **Estabilizadores:** serrátil anterior, músculos da cintura escapular e tronco
- **Sinergista do cotovelo:** `anconeus`
- **Variantes:** apoio elevado, joelhos, carga adicional, posição "diamante"
- **Estado:** `approved_with_limits`

Uma posição muito estreita ou "diamante" é variante de pega ou técnica. A identidade não deve exigir contacto entre as mãos. Cogley et al. observaram maior atividade aguda do tricípite com base estreita do que com base larga, mas isto não é evidência longitudinal de hipertrofia nem demonstra que o peitoral deixa de ser relevante.

### 4.10 `close_grip_barbell_bench_press`

- **Nome PT-PT:** Supino com pega fechada
- **Tipo:** `canonical_exercise`
- **Movimentos ativos:** extensão do cotovelo e adução horizontal do ombro
- **Cadeia:** aberta para o membro superior
- **Músculos primários contextuais:** `triceps_brachii` e `pectoralis_major`
- **Secundário:** deltoide anterior
- **Sinergista do cotovelo:** `anconeus`
- **Estabilizadores:** cintura escapular e preensão
- **Estado:** `approved_with_limits`

"Pega fechada" deve significar mais estreita do que a pega habitual do utilizador, com trajetória controlada e punhos toleráveis. Não deve ser definida por uma distância universal. Estudos agudos mostram alterações de atividade e momentos articulares com a largura da pega, mas não permitem excluir o peitoral nem garantir maior hipertrofia do tricípite. A barra EZ ou halteres podem ser variantes de equipamento se a tarefa continuar a ser um press horizontal, mas não devem ser confundidos com extensão deitada.

### 4.11 `suspension_triceps_extension`

- **Nome PT-PT:** Extensão de tricípite em suspensão
- **Tipo:** `canonical_exercise`
- **Movimento ativo principal:** `elbow_joint` -> `elbow_extension`
- **Ombro:** elevado ou flexionado e estabilizado, com possível movimento contextual
- **Cadeia:** mista ou fechada instável, porque as mãos contactam pegas móveis ligadas a um ponto fixo
- **Músculo primário:** `triceps_brachii`
- **Componentes:** todas as cabeças; sem alegação regional
- **Sinergista:** `anconeus`
- **Estabilizadores:** cintura escapular, tronco, punho e preensão
- **Progressão ou regressão:** alteração da inclinação do corpo, posição dos pés e distância ao ponto de ancoragem
- **Estado:** `approved_with_limits`
- **Evidência específica:** `insufficient_evidence`

Há evidência aguda de que dispositivos de suspensão podem alterar as exigências de estabilização em flexões de braços, mas isso não valida diretamente a extensão de tricípite em suspensão. A identidade é aceite pela mecânica clara e uso reconhecível, com alegações musculares conservadoras.

## 5. Relações músculo-articulação-ação

### 5.1 Exercícios predominantemente monoarticulares

Aplica-se a pushdown, extensão acima da cabeça, extensão deitada, extensão cruzada, kickback e máquina apoiada:

| Estrutura | Articulação | Ação | Papel |
|---|---|---|---|
| `triceps_brachii` | `elbow_joint` | `elbow_extension` | `primary` |
| `triceps_brachii_long_head` | `elbow_joint` | `elbow_extension` | `primary_contextual` |
| `triceps_brachii_lateral_head` | `elbow_joint` | `elbow_extension` | `primary_contextual` |
| `triceps_brachii_medial_head` | `elbow_joint` | `elbow_extension` | `primary_contextual` |
| `anconeus` | `elbow_joint` | `elbow_extension` | `synergist` |

Regras:

- as três cabeças são componentes de `triceps_brachii`, não músculos independentes para contagem;
- o músculo principal e as cabeças não podem ser somados como quatro alvos;
- a posição do ombro é contexto isométrico quando o úmero não se move;
- uma pega pronada não significa que o exercício treina dinamicamente a pronação;
- estabilizadores do ombro, escápula, tronco e punho só devem ser ligados com contexto.

### 5.2 Exercícios compostos

| Exercício | Cotovelo | Ombro e escápula | Papéis principais recomendados |
|---|---|---|---|
| Fundos em paralelas | Extensão | Movimento do ombro dependente da trajetória | Tricípite e peitoral como `primary_contextual`; deltoide como `secondary` |
| Fundos no banco | Extensão | Saída de extensão do ombro com mãos atrás | Tricípite como `primary_contextual`; peitoral e deltoide como `secondary` |
| Flexão estreita | Extensão | Adução horizontal e protração escapular | Tricípite e peitoral como `primary_contextual`; serrátil como estabilizador ou secundário contextual |
| Supino fechado | Extensão | Adução horizontal | Tricípite e peitoral como `primary_contextual`; deltoide anterior como `secondary` |

Não é defensável publicar estes exercícios como "isolamentos de tríceps". O grau de ênfase muda com a geometria, amplitude, inclinação, largura da pega, carga e características individuais.

## 6. Auditoria das cabeças do tricípite

### 6.1 Estado da base v0.1.1

A base local identifica:

- `triceps_brachii` como `principal_contributor` da extensão do cotovelo;
- `triceps_brachii_long_head`, `triceps_brachii_lateral_head` e `triceps_brachii_medial_head` como componentes com contribuição contextual;
- a cabeça longa também relacionada com extensão e adução do ombro;
- `anconeus` como contribuidor secundário ou contextual da extensão do cotovelo;
- política de contagem mutuamente exclusiva entre músculo principal e componentes.

Esta estrutura é coerente com o catálogo proposto e foi preservada.

### 6.2 O que pode ser dito

| Contexto | Formulação pública admissível | Evidência |
|---|---|---|
| Extensão acima da cabeça | Trabalha o tricípite com a cabeça longa em maior comprimento no ombro; pode favorecer adaptações em maior comprimento | `moderate_supported_emphasis` |
| Extensão deitada | Envolve todas as cabeças; existe evidência de adaptação regional diferente de um press de peito | `moderate_supported_emphasis` na comparação estudada |
| Pushdown | Envolve todas as cabeças com o ombro próximo do tronco | Função anatómica suportada; ênfase por pega insuficiente |
| Kickback | Envolve todas as cabeças com o ombro em extensão | Mecânica plausível; sem suporte para isolamento |
| Compostos | A contribuição relativa depende da tarefa, técnica e carga | `moderate_supported_emphasis` para diferenças de tarefa, não para isolamento |

### 6.3 O que deve ser bloqueado

- "A corda trabalha a cabeça lateral e a barra a cabeça longa."
- "A pega supinada isola a cabeça medial."
- "Acima da cabeça só trabalha a cabeça longa."
- "Kickback isola a cabeça lateral."
- "Fundos são apenas um exercício de tríceps."
- "Supino fechado elimina o peitoral."
- Qualquer conclusão de hipertrofia baseada apenas em amplitude de EMG.

Kholinne et al. observaram padrões diferentes entre cabeças com diferentes elevações do ombro, mas o estudo combinou modelação e EMG num grupo pequeno. Alves et al. não encontraram padrões de ativação suficientemente diferentes para justificar prescrever extensão acima da cabeça e deitada apenas com base em ativação. Estes resultados devem moderar, não substituir, a anatomia e os estudos longitudinais.

## 7. Perfis de resistência e amplitude

### 7.1 Regra geral

O torque externo no cotovelo depende da força externa e da distância perpendicular entre a linha de força e o eixo articular. Nem um cabo, nem uma banda, nem um halter têm um "perfil constante" universal.

Murray et al. demonstraram que os braços de momento musculares também variam com o ângulo do cotovelo e a posição do antebraço. Não deve ser publicada uma zona universal de maior ou menor vantagem mecânica sem definir a variante e o ângulo.

### 7.2 Por família

| Família | Perfil que pode ser descrito |
|---|---|
| Pushdown no cabo | Depende da posição da polia, distância ao aparelho e ângulo entre cabo e antebraço |
| Extensão acima da cabeça no cabo | Pode manter resistência em amplitude diferente da versão gravítica; depende da linha do cabo |
| Extensão acima da cabeça com halter ou EZ | Torque gravítico maior quando o antebraço está mais perpendicular à gravidade |
| Extensão deitada com peso livre | Torque baixo quando o antebraço alinha com a gravidade e maior quando se afasta dessa linha |
| Kickback com halter | Tende a exigir mais perto da posição em que o antebraço fica horizontal |
| Kickback no cabo | A curva depende da direção do cabo e pode manter tensão onde o halter oferece pouco torque |
| Máquina | Perfil desconhecido sem geometria do came, alavancas e eixo |
| Fundos e flexões | Carga articular varia com a posição do centro de massa, apoios e trajetória |
| Suspensão | A inclinação corporal e a distância ao ponto de ancoragem alteram a componente da carga |
| Banda | A força tende a aumentar com o alongamento, mas o torque articular também depende do braço de momento |

Uchida et al. confirmam que a tensão das bandas aumenta com o alongamento e que valores comerciais podem não representar a força real. Isto não permite afirmar que o torque no cotovelo aumenta de forma monotónica em qualquer montagem.

## 8. Segurança e revisão especialista

Estas notas destinam-se a classificação de exercícios, não a aconselhamento clínico individual.

### 8.1 Regras transversais

- parar perante dor aguda, parestesia, instabilidade ou perda de controlo;
- usar carga e amplitude compatíveis com controlo;
- não forçar bloqueio do cotovelo;
- controlar a fase excêntrica;
- manter punho e pega em posição tolerável;
- distinguir desconforto muscular esperado de sintomas articulares ou neurológicos;
- encaminhar história clínica relevante para revisão especialista.

### 8.2 Riscos e limites por família

| Família | Nota de segurança |
|---|---|
| Pushdown, cruzada e cabo | Confirmar mosquetão, cabo e trajetória; evitar balanço do tronco e queda descontrolada da carga |
| Acima da cabeça | A elevação do ombro, mobilidade torácica e compensação lombar podem limitar a posição; reduzir amplitude ou mudar variante se necessário |
| Deitada | Controlar o implemento sobre a cabeça ou face; usar carga gerível, travas e assistência quando apropriado |
| Kickback | Exige controlo do tronco e tolerância à extensão do ombro; evitar impulso e bloqueio balístico |
| Máquina | Ajustar banco e eixo conforme o equipamento; não presumir que todas as máquinas têm a mesma amplitude |
| Fundos em paralelas | A profundidade depende da amplitude confortável do ombro; assistência e menor amplitude são regressões válidas |
| Fundos no banco | Exposição elevada à extensão do ombro; classificar `approved_with_limits` e ensinar progressão de amplitude |
| Flexão estreita | Não exigir mãos excessivamente juntas; adaptar largura, inclinação e apoio ao conforto do punho e ombro |
| Supino fechado | Usar suportes e assistência adequados; não impor largura extrema; controlar punho e trajetória |
| Suspensão | Verificar ancoragem e correias; usar apoio antiderrapante; diminuir inclinação como regressão |
| Banda | Inspecionar danos, fixar a ancoragem e manter rosto e terceiros fora da trajetória de recuo |

Fundos no banco não devem ser rotulados como universalmente perigosos. A evidência disponível justifica uma nota específica sobre a elevada extensão do ombro e sobre a seleção individual de amplitude.

## 9. Evidência e limitações

### 9.1 Fontes principais

| ID sugerido | Fonte | Identificador | Uso neste relatório |
|---|---|---|---|
| `src_murray_elbow_1995_corrected` | Murray WM, Delp SL, Buchanan TS. *Variation of muscle moment arms with elbow and forearm position*. J Biomech. 1995 | [PMID 7775488](https://pubmed.ncbi.nlm.nih.gov/7775488/); [DOI 10.1016/0021-9290(94)00114-J](https://doi.org/10.1016/0021-9290(94)00114-J) | Variação angular dos braços de momento |
| `src_maeo_overhead_2023` | Maeo S et al. *Triceps brachii hypertrophy is substantially greater after elbow extension training performed in the overhead versus neutral arm position*. Eur J Sport Sci. 2023 | [PMID 35819335](https://pubmed.ncbi.nlm.nih.gov/35819335/); [DOI 10.1080/17461391.2022.2100279](https://doi.org/10.1080/17461391.2022.2100279) | Evidência longitudinal para posição acima da cabeça |
| `src_kholinne_shoulder_2018` | Kholinne E et al. *The different role of each head of the triceps brachii muscle in elbow extension*. Acta Orthop Traumatol Turc. 2018 | [PMID 29503079](https://pubmed.ncbi.nlm.nih.gov/29503079/); [PMCID PMC6136322](https://pmc.ncbi.nlm.nih.gov/articles/PMC6136322/); [DOI 10.1016/j.aott.2018.02.005](https://doi.org/10.1016/j.aott.2018.02.005) | Modulação das cabeças com elevação do ombro |
| `src_alves_shoulder_2018` | Alves D et al. *Shoulder position and triceps brachii activation during elbow extension exercise*. J Sports Med Phys Fitness. 2018 | [PMID 28677940](https://pubmed.ncbi.nlm.nih.gov/28677940/); [DOI 10.23736/S0022-4707.17.06849-9](https://doi.org/10.23736/S0022-4707.17.06849-9) | Limites das alegações de ativação por posição |
| `src_stasinaki_architecture_2018` | Stasinaki AN et al. *Triceps brachii muscle strength and architectural adaptations with resistance training exercises at short or long fascicle length*. J Funct Morphol Kinesiol. 2018 | [DOI 10.3390/jfmk3020028](https://doi.org/10.3390/jfmk3020028) | Evidência longitudinal pequena e de curta duração |
| `src_rendos_handles_2016` | Rendos NK et al. *Differences in muscle activity during the triceps push-down exercise using different handle types*. J Strength Cond Res. 2016 | [PMID 26694502](https://pubmed.ncbi.nlm.nih.gov/26694502/); [DOI 10.1519/JSC.0000000000001293](https://doi.org/10.1519/JSC.0000000000001293) | Pegas e atividade aguda; não compara diretamente corda com barra |
| `src_villalba_pushdown_2024` | Villalba C et al. *Influence of forearm position and handle type on neuromuscular activation during unilateral triceps pushdown*. Int J Strength Cond. 2024 | [DOI 10.47206/ijsc.v4i1.250](https://doi.org/10.47206/ijsc.v4i1.250) | Configuração de pega; evidência aguda |
| `src_brandao_single_multi_2020` | Brandão L et al. *Muscular adaptations to single-joint and multi-joint resistance training*. J Strength Cond Res. 2020 | [PMID 32149887](https://pubmed.ncbi.nlm.nih.gov/32149887/); [DOI 10.1519/JSC.0000000000003550](https://doi.org/10.1519/JSC.0000000000003550) | Adaptação regional de extensão deitada versus press |
| `src_mckenzie_dips_2022` | McKenzie CR et al. *Bench, bar, and ring dips: do kinematics and muscle activity differ?* Int J Environ Res Public Health. 2022 | [PMID 36293792](https://pubmed.ncbi.nlm.nih.gov/36293792/); [PMCID PMC9603242](https://pmc.ncbi.nlm.nih.gov/articles/PMC9603242/); [DOI 10.3390/ijerph192013211](https://doi.org/10.3390/ijerph192013211) | Distinção entre tipos de fundos e extensão do ombro |
| `src_saeterbakken_grip_2021` | Saeterbakken AH et al. *The effects of bench press variations in competitive athletes on muscle activity and performance*. Int J Environ Res Public Health. 2021 | [PMID 34198674](https://pubmed.ncbi.nlm.nih.gov/34198674/); [PMCID PMC8296276](https://pmc.ncbi.nlm.nih.gov/articles/PMC8296276/); [DOI 10.3390/ijerph18126444](https://doi.org/10.3390/ijerph18126444) | Atividade aguda e largura da pega |
| `src_larsen_bench_2021` | Larsen S et al. *A biomechanical analysis of wide, medium, and narrow grip width effects on kinematics, horizontal kinetics, and muscle activity on the sticking region in recreationally trained males during 1-RM bench pressing*. Front Sports Act Living. 2021 | [PMID 33554113](https://pubmed.ncbi.nlm.nih.gov/33554113/); [DOI 10.3389/fspor.2020.637066](https://doi.org/10.3389/fspor.2020.637066) | Momentos, cinemática e pega no supino |
| `src_cogley_pushup_2005` | Cogley RM et al. *Comparison of muscle activation using various hand positions during the push-up exercise*. J Strength Cond Res. 2005 | [PMID 16095413](https://pubmed.ncbi.nlm.nih.gov/16095413/); [DOI 10.1519/15094.1](https://doi.org/10.1519/15094.1) | Atividade aguda em flexões estreitas |
| `src_calatayud_suspension_2014` | Calatayud J et al. *Muscle activation during push-ups with different suspension training systems*. J Sports Sci Med. 2014 | [PMID 25177174](https://pubmed.ncbi.nlm.nih.gov/25177174/); [PMCID PMC4126284](https://pmc.ncbi.nlm.nih.gov/articles/PMC4126284/) | Evidência indireta para exigência de estabilidade em suspensão |
| `src_farias_press_modes_2017` | Farias DA et al. *Maximal strength performance and muscle activation for the bench press and triceps extension exercises adopting dumbbell, barbell, and machine modalities*. J Strength Cond Res. 2017 | [PMID 27669189](https://pubmed.ncbi.nlm.nih.gov/27669189/); [DOI 10.1519/JSC.0000000000001651](https://doi.org/10.1519/JSC.0000000000001651) | Implemento, desempenho e atividade aguda |
| `src_uchida_bands_2016` | Uchida MC et al. *Effect of bench angle and elastic band tension on muscle activation and force*. J Phys Ther Sci. 2016 | [PMID 27190465](https://pubmed.ncbi.nlm.nih.gov/27190465/); [PMCID PMC4868225](https://pmc.ncbi.nlm.nih.gov/articles/PMC4868225/); [DOI 10.1589/jpts.28.1266](https://doi.org/10.1589/jpts.28.1266) | Comportamento da tensão elástica |
| `src_vigotsky_emg_2018` | Vigotsky AD et al. *Interpreting signal amplitudes in surface electromyography studies in sport and rehabilitation sciences*. Front Physiol. 2017 | [PMID 29354060](https://pubmed.ncbi.nlm.nih.gov/29354060/); [PMCID PMC5758546](https://pmc.ncbi.nlm.nih.gov/articles/PMC5758546/); [DOI 10.3389/fphys.2017.00985](https://doi.org/10.3389/fphys.2017.00985) | Limites de interpretação da EMG |
| `src_vigotsky_hypertrophy_2022` | Vigotsky AD et al. *Acute surface EMG amplitude is not a validated predictor of muscle hypertrophy*. Sports Med. 2022 | [PMID 35006527](https://pubmed.ncbi.nlm.nih.gov/35006527/); [DOI 10.1007/s40279-021-01619-2](https://doi.org/10.1007/s40279-021-01619-2) | Bloqueio de inferências de hipertrofia a partir de EMG aguda |

### 9.2 Hierarquia de confiança usada

- **Anatomia e ação articular:** confiança moderada a alta, coerente com a base v0.1.1.
- **Identidade mecânica dos canónicos:** confiança moderada a alta, exceto extensão cruzada e suspensão, ambas com limites.
- **Ênfase por posição acima da cabeça:** confiança moderada.
- **Ênfase da extensão deitada em comparação com press:** confiança moderada dentro do protocolo estudado.
- **Diferenças de pega, corda, barra e supinação no pushdown:** evidência aguda e indireta; confiança baixa para adaptações.
- **Ênfase de cabeça no kickback, cruzada, máquina, suspensão ou banda:** evidência insuficiente.
- **Segurança dos fundos no banco:** confiança moderada para a maior exposição à extensão do ombro; insuficiente para uma classificação universal de lesivo.

## 10. Finding de proveniência para revisão da base

Foi detetada uma possível falha no `SOURCE_LEDGER.csv` da v0.1.1:

- ID local: `src_murray_elbow_1995`
- título local: *Variation of muscle moment arms with elbow and forearm position*
- PMID/URL local observado: `7581389`
- PMID correto para esse artigo: `7775488`
- DOI correto: `10.1016/0021-9290(94)00114-J`

O PMID `7581389` não corresponde ao artigo biomecânico de Murray, Delp e Buchanan. Este finding deve entrar numa fila de revisão de proveniência da base muscular. Em cumprimento do mandato, o ficheiro original não foi alterado e nenhuma conclusão anatómica foi reescrita.

**Prioridade recomendada:** alta, porque a fonte é usada para biomecânica do cotovelo e o identificador atual conduz a um artigo de outra área.

## 11. Regras de validação recomendadas para integração

1. Cada exercício canónico deve ter um `canonical_id` único.
2. Uma variante deve apontar para exatamente um exercício canónico.
3. Unilateralidade deve ser configuração, não duplicação de identidade.
4. Uma ação apresentada tem de existir na base e ser compatível com a articulação.
5. Uma posição isométrica do ombro não pode ser publicada automaticamente como ação dinâmica.
6. Componentes do tricípite não podem duplicar a contagem do músculo principal.
7. Alegações sobre cabeça específica exigem claim, fonte e nível de evidência.
8. EMG aguda não pode ser convertida em alegação de hipertrofia.
9. A versão em cabo e a versão com peso livre do mesmo exercício devem poder ter perfis de resistência distintos sem duplicar o canónico.
10. "Máquina de tríceps" e "extensão com banda" devem falhar validação se a geometria não estiver definida.
11. Exercícios compostos devem incluir os músculos principais contextuais do ombro, não apenas o tricípite.
12. A camada pública deve bloquear "isolamento absoluto", "melhor cabeça" e equivalentes.
13. A descrição dos fundos no banco deve conter a nota sobre extensão do ombro.
14. Todas as fontes devem validar DOI, PMID e URL entre si.
15. A geração deve ser determinística e independente da ordem física dos registos.

## 12. Questões para o integrador

### 12.1 Decisões que considero fechadas

- 11 canónicos listados no resumo.
- Barra e corda como variantes do pushdown.
- Cabo, halter e EZ como variantes da extensão acima da cabeça.
- Barra e halteres como variantes da extensão deitada.
- Halter e cabo como variantes do kickback.
- Unilateralidade como configuração.
- Banda apenas como variante depois de definir ancoragem.
- Fundos em paralelas, fundos no banco, flexão estreita e supino fechado como canónicos distintos.
- Sem isolamento absoluto ou promoção automática de EMG a hipertrofia.

### 12.2 Decisões que exigem integração cuidadosa

- A extensão cruzada deve ser acompanhada por uma definição visual ou técnica para evitar duplicação com pushdown unilateral diagonal.
- A máquina deve ser definida como extensão apoiada do cotovelo, não pelo nome comercial.
- A extensão em suspensão é canónica por mecânica, mas deve manter `approved_with_limits` e `insufficient_evidence` para ênfase específica.
- O integrador deve corrigir ou escalar o PMID errado da fonte Murray sem alterar silenciosamente a base.

## 13. Conclusão

O conjunto proposto cobre as principais famílias de extensão do cotovelo sem multiplicar entidades por implemento, lado ou pequena alteração de pega. Preserva a base muscular v0.1.1, trata as cabeças do tricípite como componentes contextuais e separa capacidade anatómica, mecânica do exercício e evidência de adaptação.

Foram auditados todos os candidatos pedidos. Não foi alterado qualquer ficheiro da base muscular, da EveFit ou do pacote final.
