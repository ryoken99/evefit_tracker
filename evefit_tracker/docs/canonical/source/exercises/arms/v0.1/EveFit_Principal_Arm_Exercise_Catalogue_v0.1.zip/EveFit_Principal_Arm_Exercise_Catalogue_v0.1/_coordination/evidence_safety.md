# Relatório independente da Equipa 7: evidência e segurança

## Catálogo Canónico dos Principais Exercícios de Braços v0.1

**Âmbito:** força da evidência, limites de interpretação da EMG, segurança pública, preensão, suspensões, transportes, posições do ombro, cotovelo e punho, fila de revisão especialista e findings da base.

**Base obrigatória:** `EveFit_Muscular_Knowledge_Base_v0.1.1`

**SHA-256 declarado e verificado pelos relatórios de domínio:** `a1876a1d4bc21ab54b3828774f66a99519a4953dc00191e69475d8c15b8b30b0`

**Independência:** este relatório revê os três relatórios existentes e o construtor apenas como objetos de auditoria. Não altera a base muscular, o catálogo final, a aplicação EveFit, qualquer claim ou qualquer fonte.

## 1. Conclusão executiva

O catálogo pode ter uma camada pública útil, mas deve separar cinco perguntas que não são equivalentes:

1. O músculo possui capacidade anatómica para a ação?
2. O músculo participa nesta tarefa concreta?
3. A posição ou variante muda a coordenação ou o momento articular?
4. A variante produz uma adaptação longitudinal diferente?
5. A tarefa é adequada para publicação geral ou exige limites?

As conclusões com melhor suporte são:

- as posições do antebraço e os ângulos do cotovelo alteram a capacidade mecânica e a coordenação dos flexores do cotovelo;
- a posição do ombro é material para curls e extensões de tríceps, mas não autoriza regras universais de seleção por cabeça muscular;
- existe evidência longitudinal moderada para maior hipertrofia do tríceps no protocolo específico de extensão acima da cabeça estudado por Maeo et al., mas não para superioridade universal de qualquer exercício acima da cabeça;
- flexão, extensão, desvios e rotação resistida do antebraço podem ser descritos publicamente como tarefas mecânicas, sem promessas preventivas ou terapêuticas;
- exercícios de hand gripper ou bola podem melhorar força e resistência de preensão em populações estudadas, mas a transferência entre `crush`, `support`, `pinch` e `open_hand` não deve ser presumida;
- carries, holds e hangs são mecanicamente distintos, mas a evidência direta de adaptação específica da mão é muito mais escassa do que a sua popularidade sugere;
- um dead hang numa barra não deve ser apresentado como tratamento, descompressão, correção postural ou prevenção de lesão;
- EMG de superfície pode apoiar participação e diferenças agudas sob condições equivalentes, mas não mede diretamente força muscular, tensão de todas as fibras, segurança nem hipertrofia futura.

O principal problema evidencial observado no construtor é de proveniência demasiado ampla. `src_labott_grip_2019` apoia um efeito médio pequeno de vários programas de treino na força de preensão de adultos mais velhos. Não sustenta, por si só, a identidade, os músculos principais, a segurança ou a eficácia específica de hand gripper, pinça com discos, pega espessa, farmer carry, suitcase carry, dead hang ou towel hang.

## 2. Política de evidência obrigatória

### 2.1 Unidade mínima

Cada claim público deve ligar:

- exercício ou variante;
- condição concreta;
- resultado concreto;
- tipo de evidência;
- fonte ou fontes;
- confiança;
- limitações;
- estado de revisão.

Uma lista global de `source_ids` no exercício não substitui proveniência ao nível do claim.

### 2.2 Hierarquia operacional

| Nível | Uso permitido | Exemplos |
|---|---|---|
| `strong_supported_emphasis` | Evidência longitudinal convergente e diretamente aplicável à configuração publicada | Não atribuído automaticamente nesta versão |
| `moderate_supported_emphasis` | Um ensaio longitudinal relevante, ou anatomia e biomecânica direta convergentes, com limites claros | Extensão do cotovelo acima da cabeça no âmbito do protocolo de Maeo et al.; treino especializado de handgrip na população estudada |
| `plausible_mechanical_emphasis` | Linha de tração, posição, ação e relação anatómica coerentes, sem confirmação longitudinal específica | Desvios do punho, pinça com discos, support hold, carries |
| `weak_or_indirect_evidence` | EMG aguda isolada, população ou tarefa adjacente, estudo pequeno ou inferência de outro implemento | Dead hang em barra inferido de hangs em hangboard; pega espessa; suspensão em toalha |
| `disputed` | Resultados divergentes ou dependentes de método que impedem conclusão pública simples | Alegações universais sobre cabeça longa ou curta do bicípite |
| `insufficient_evidence` | Sem dados diretos suficientes para o resultado afirmado | Superioridade hipertrófica de plate pinch, farmer carry, towel hang ou fat-grip hold |

### 2.3 Regra para `primary`

Um músculo só pode receber `primary` ou `primary_contextual` quando existe:

- ação compatível aprovada na base;
- articulação realmente atravessada ou função estabilizadora explicitamente contextual;
- fase e condição declaradas;
- justificação anatómica ou biomecânica rastreável;
- confiança e limitação.

EMG maior numa condição não promove automaticamente um músculo a `primary`. Coativação durante power grip, por exemplo, não cria uma nova ação anatómica.

### 2.4 Regra para segurança

Ausência de estudos de lesão não significa segurança demonstrada. Um aviso público deve ser classificado como:

- `equipment_or_environmental_control`, quando deriva de risco de queda, libertação ou falha de ancoragem;
- `mechanical_caution`, quando deriva de carga, amplitude, posição ou controlo;
- `symptom_stop_rule`, quando descreve o que obriga a terminar;
- `specialist_review_trigger`, quando existe patologia, pós-lesão, pós-cirurgia ou défice neurológico;
- `clinical_claim`, que fica proibido nesta missão.

## 3. Limites obrigatórios da EMG

Os dois artigos de Vigotsky et al. devem funcionar como validadores negativos do catálogo, não apenas como referências decorativas.

### 3.1 O que a EMG pode apoiar

- presença de excitação mensurável num músculo superficial na tarefa estudada;
- diferenças agudas entre condições quando normalização, colocação de elétrodos, amplitude, carga e execução são comparáveis;
- mudança de estratégia de coordenação;
- formulação de hipóteses sobre ênfase.

### 3.2 O que a EMG não demonstra isoladamente

- força produzida pelo músculo;
- tensão mecânica total;
- recrutamento uniforme de todas as regiões ou cabeças;
- contribuição causal para o movimento;
- isolamento;
- hipertrofia futura;
- superioridade de um exercício;
- risco de lesão ou segurança;
- transferência entre tarefas de preensão.

### 3.3 Validações automáticas recomendadas

1. Se `evidence_type == surface_emg`, bloquear `strong_supported_emphasis`.
2. Se um claim contiver “maior hipertrofia”, “mais crescimento”, “superior” ou equivalente, exigir fonte longitudinal.
3. Se `primary` se apoiar apenas em EMG, falhar a validação.
4. Se houver claim por cabeça muscular, exigir `component_id`, condição, fonte direta e limites.
5. Se duas condições usarem cargas relativas, amplitudes ou normalizações diferentes, bloquear comparação causal simples.
6. Não converter ausência de diferença estatística em equivalência.

## 4. Revisão dos relatórios de domínio

### 4.1 Flexão do cotovelo

O relatório `elbow_flexion.md` é evidencialmente prudente nos pontos principais:

- a orientação do antebraço é material;
- posição mantida não é ação dinâmica;
- `brachialis` como contribuinte principal mecânico é defensável com confiança moderada;
- `biceps_brachii` deve ser contextualizado pela supinação e posição do ombro;
- a classificação do `brachioradialis` em neutro e pronação deve manter confiança moderada, porque os estudos de sEMG não são perfeitamente convergentes;
- não se deve publicar preferência pela cabeça longa ou curta do bicípite;
- barra reta e barra EZ não possuem evidência longitudinal que justifique superioridade;
- curl inclinado e Scott têm identidade posicional defensável, mas os resultados dos ensaios aplicam-se às configurações realmente testadas.

Limite adicional: o mecanismo observado em ruturas distais do bicípite, com carga excêntrica perto da extensão do cotovelo e antebraço supinado, não prova que curls sejam causadores. Serve para justificar controlo da descida, evitar carga súbita e encaminhar pós-lesão ou pós-cirurgia para especialista.

### 4.2 Extensão do cotovelo

O relatório `elbow_extension.md` também é adequado se forem preservados estes limites:

- todas as cabeças do tríceps participam na extensão do cotovelo;
- a posição acima da cabeça é material para a cabeça longa e possui evidência longitudinal moderada num protocolo específico;
- o estudo de Maeo et al. não demonstra que qualquer extensão acima da cabeça seja sempre superior a qualquer pushdown;
- corda versus barra no pushdown tem suporte predominantemente agudo e de implemento, não de hipertrofia;
- fundos, flexão estreita e supino fechado são multiarticulares e não devem ser apresentados como isolamento de tríceps;
- a maior extensão do ombro observada nos fundos no banco justifica amplitude progressiva e `approved_with_limits`, não a frase “sempre lesivo”.

### 4.3 Antebraço, punho e dedos

O relatório `forearm_wrist.md` mantém uma boa separação entre ação anatómica e aplicação:

- pronação e supinação com alavanca, cabo, banda ou resistência manual são variantes de equipamento;
- um halter simétrico seguro exatamente no centro produz pouco momento axial por gravidade;
- o punho humano apresenta acoplamento entre planos, pelo que “ênfase em desvio radial” é mais rigoroso do que “desvio radial puro”;
- os extensores do punho coativam em grip, mas isso não torna todo o grip um exercício primário de extensão do punho;
- tarefas isoladas de PIP, DIP e IP do polegar devem permanecer em `specialist_review`.

Os estudos de pressão do túnel cárpico mostram que postura, rotação do antebraço, carga tendinosa e carga na polpa dos dedos podem aumentar pressão em condições experimentais. Não fornecem um limiar de carga seguro para o ginásio e não demonstram que um exercício cause síndrome do túnel cárpico. A tradução pública correta é manter o punho próximo de neutro quando a tarefa não exige movimento do punho, evitar insistir em posições terminais sintomáticas e terminar perante parestesias.

## 5. Preensão, suportes, carries e hangs

### 5.1 Taxonomia de preensão

`crush`, `support`, `pinch` e `open_hand` devem ser tratados como rótulos funcionais do catálogo, não como compartimentos anatómicos nem como capacidades com transferência total.

| Tipo | Definição operacional | Evidência de treino específica |
|---|---|---|
| `crush` | Fechar dedos e polegar contra um objeto ou mola | Moderada para hand gripper/bola em população estudada |
| `support` | Impedir que um implemento puxe a mão para abertura durante hold, carry ou hang | Plausível mecanicamente; adaptação específica depende da tarefa |
| `pinch` | Produzir força entre polegar e dedos sem envolver plenamente a palma | Plausível mecanicamente; evidência longitudinal de plate pinch insuficiente |
| `open_hand` | Support grip com maior diâmetro ou mão menos fechada | Evidência aguda baixa a moderada; transferência e hipertrofia insuficientes |
| `finger_extension` | Abrir os dedos contra resistência externa | Relação mecânica plausível; evidência longitudinal específica limitada |

Não usar uma melhoria em dinamómetro de mão como prova de melhoria em dead hang, towel hang ou plate pinch sem um estudo de transferência.

### 5.2 Hand gripper e bola

Gerodimos et al. observaram melhoria de força máxima e resistência após oito semanas de treino especializado com bolas e hand grippers em 36 mulheres mais velhas saudáveis. A aplicação ao catálogo é `moderate_supported_emphasis` para preensão geral nessa classe de tarefa, com limitação de população e protocolo.

Finding de identidade: `hand_gripper_close` e `hand_squeeze` não devem ser dois canónicos apenas por equipamento. Recomenda-se um canónico funcional de fecho/aperto da mão, com gripper e bola como variantes, salvo se o integrador documentar diferença material entre fecho dinâmico de amplitude definida e compressão isométrica de objeto deformável.

Finding mecânico: os dois registos foram agrupados como `grip_isometric`, mas as descrições incluem fechar e regressar ou comprimir e libertar. Devem declarar fase dinâmica e, quando usada, retenção isométrica. O rótulo não pode contradizer a execução.

### 5.3 Pinça com discos

`plate_pinch_hold` é uma tarefa reconhecível e distinta de support grip cilíndrico. A área de contacto, fricção, espessura dos discos e largura da pinça são determinantes. O claim público deve limitar-se a:

- tarefa de pinça isométrica;
- participação do polegar e dedos;
- exigência de estabilização do punho;
- confiança `plausible_mechanical_emphasis`.

Não alegar isolamento do adutor do polegar, prevenção de lesão ou superioridade para força global da mão.

`plate_pinch_carry` pode ser distinguido do hold pela locomoção e controlo do corpo, mas não deve alegar maior estímulo de pinça sem dados.

### 5.4 Support hold e pega espessa

O diâmetro do handle altera força, distribuição de contacto e coordenação. Krings et al. suportam diferenças agudas de desempenho e EMG com fat grips em exercícios estudados. Kong e Lowe mostram que força e conforto em preensão máxima variam com o diâmetro e dimensão da mão.

Isto justifica guardar `handle_diameter_class`, `hand_size_fit` e `contact_surface`, mas não justifica uma promessa universal de maior ativação ou crescimento.

Finding de identidade: `thick_grip_hold` deve ser `equipment_variant` ou `grip_orientation_variant` de `support_grip_hold`, não um novo canónico. A diferença é material para a configuração e para a exigência, mas a tarefa continua a ser sustentação estática.

### 5.5 Farmer carry e suitcase carry

Os dois carries devem manter identidades distintas:

- farmer carry: carga bilateral e aproximadamente simétrica;
- suitcase carry: carga unilateral, momento externo assimétrico e maior exigência contextual de controlo lateral.

Winwood et al. documentam diferenças biomecânicas entre farmer walk, deadlift e marcha sem carga em apenas seis strongmen. Bordelon et al. e Ellestad et al. suportam diferenças de ativação com carga, posição e locomoção. Estes estudos são adequados para identidade e exigência de estabilidade, não para superioridade hipertrófica, prevenção de dor lombar ou adaptação específica da preensão.

Finding de cadeia cinética: para o membro superior, o implemento não está fixo ao ambiente. Classificar os carries como `closed_chain` sem qualificador é enganador. Recomenda-se `mixed_chain`, com:

- membros superiores em tarefa de suporte isométrico de implemento livre;
- membros inferiores em cadeia fechada alternada durante marcha;
- corpo em locomoção.

Finding de proveniência: classificar flexores dos dedos como `grip_limiter` é uma inferência anatómico-mecânica defensável, mas deve ser marcada como tal. Os estudos de carries citados não mediram diretamente todos os flexores digitais nem demonstraram qual deles limitou a série.

### 5.6 Dead hang

Exel et al. estudaram 17 escaladores recreativos em hangs isométricos num hangboard, com braços estendidos e lock-offs a 90 e 135 graus. Os momentos no cotovelo e ombro aumentaram com maior flexão do cotovelo, enquanto a ativação medida dos flexores dos dedos não diferiu entre condições.

A fonte não é equivalente a um dead hang geral numa barra cilíndrica:

- o contacto era um hold de escalada;
- os participantes eram escaladores;
- a tarefa foi curta e isométrica;
- a investigação não testou tratamento de dor, mobilidade ou descompressão;
- a estimativa de “efeito de treino” dos flexores baseou-se em EMG e modelação.

Estado recomendado: `approved_with_limits`.

Campos obrigatórios:

- `hang_mode`: `active`, `passive` ou `mixed`;
- tipo e diâmetro da pega;
- assistência dos pés ou corpo inteiro;
- posição do cotovelo;
- entrada e saída por caixa ou apoio, sem salto;
- ancoragem e capacidade de carga verificadas;
- espaço livre por baixo;
- condição de paragem por dor, parestesia, instabilidade ou abertura involuntária da mão.

Bloquear claims públicos de “descompressão da coluna”, “abre o espaço subacromial”, “cura impingement”, “corrige postura” ou “previne lesões”.

Finding estrutural observado no construtor: `dead_hang` e `towel_hang` usam as articulações digitais e o punho como relações ativas por defeito, mas ombro, cintura escapular e cotovelo aparecem apenas como limitantes. Isto é insuficiente para uma tarefa que transmite o peso corporal através de todo o membro superior. O grafo deve incluir essas articulações e separar estabilização/posição de ação dinâmica.

### 5.7 Towel hang

A toalha altera contacto, fricção, deformabilidade e diâmetro efetivo, mas não cria uma nova cadeia ou objetivo.

Recomendação:

- `equipment_variant` de `dead_hang`;
- `approved_with_limits`;
- evidência `weak_or_indirect_evidence`;
- ancoragem da toalha e inspeção do material obrigatórias;
- não alegar que é superior para força de preensão;
- regressão com assistência dos pés.

### 5.8 Apoio nas paralelas

O `parallel_bar_support_hold` é um suporte de peso corporal, não uma tarefa primária de grip de esmagamento. A carga pode ser transmitida sobretudo pela palma para a barra, com dedos a manter contacto e orientação.

Recomendação:

- manter como exercício multiarticular de suporte, cruzado na família de braços;
- tríceps como `primary_contextual` para manter extensão do cotovelo;
- estabilizadores escapulares e glenoumerais contextualizados;
- flexores dos dedos apenas como `stabilizer` ou `grip_limiter` quando o formato da barra e a técnica realmente o exigirem;
- não contabilizar como cobertura principal de flexão dos dedos.

## 6. Segurança pública

### 6.1 Regras universais

Toda a ficha pública deve incluir:

- equipamento, cabos, bandas, toalhas, barras e pontos de ancoragem inspecionados;
- percurso e zona de queda livres;
- forma controlada de iniciar e terminar;
- amplitude confortável, sem forçar o fim articular;
- carga e duração que permitam manter contacto e alinhamento;
- respiração contínua em treino geral;
- término antes de falha imprevisível da pega.

### 6.2 Condições de paragem

Terminar de imediato perante:

- dor aguda, crescente ou articular;
- parestesia, dormência, sensação de choque ou fraqueza súbita;
- sensação de instabilidade, deslocamento ou estalido doloroso;
- perda de controlo do punho, cotovelo ou ombro;
- abertura involuntária da mão;
- deslizamento, rotação ou falha do implemento;
- falha de ancoragem;
- tontura, visão alterada, falta de ar anormal ou mal-estar.

Estas regras não constituem diagnóstico.

### 6.3 Respiração e isometrias

Hand grippers, holds, carries e hangs podem envolver contrações isométricas intensas. Em adultos saudáveis, estudos de handgrip mostram subida de pressão arterial com intensidade e duração, e Watanabe et al. observaram que prender a respiração amplificou a resposta pressora durante handgrip isométrico.

Texto público permitido: “Respira continuamente e evita prender a respiração durante retenções prolongadas.”

Não publicar:

- uma dose cardiovascular terapêutica;
- a alegação de que handgrip intenso baixa imediatamente a tensão arterial;
- a ideia de que todas as pessoas com hipertensão estão proibidas.

Doença cardiovascular conhecida, tensão arterial não controlada ou restrição clínica ao esforço isométrico exige decisão individual fora desta missão.

## 7. Fila de revisão especialista

| Alvo | Gatilho | Estado recomendado | Motivo |
|---|---|---|---|
| `dead_hang`, `towel_hang`, variantes em argolas | instabilidade glenoumeral, luxação prévia sintomática, hipermobilidade sintomática, pós-cirurgia, défice de controlo escapular doloroso | `specialist_review` contextual | peso corporal em elevação completa e risco de saída não controlada |
| Fundos e apoios nas paralelas | instabilidade do ombro, dor anterior, cirurgia do ombro/cotovelo/esterno, incapacidade de suportar peso | `specialist_review` contextual | suporte de peso corporal multiarticular |
| Curls e chin-up | rutura distal do bicípite, reparação cirúrgica, dor distal ativa, perda súbita de força | `specialist_review` contextual | carga do flexor/supinador e risco de progressão inadequada |
| Extensões de cotovelo | lesão ou cirurgia do tríceps/cotovelo, dor posterior ativa, neuropatia ulnar sintomática | `specialist_review` contextual | carga direta e posições de flexão do cotovelo |
| Pronação e supinação resistidas | lesão ou cirurgia recente da DRUJ, suspeita de TFCC, instabilidade ou estalido doloroso | `specialist_review` contextual | rotação resistida do rádio/ulna e punho |
| Flexão, extensão e desvios do punho | trauma recente, cirurgia, dor persistente ou instabilidade | `specialist_review` contextual | necessidade de dose e amplitude individual |
| Grip, pinch, carries e hangs | síndrome do túnel cárpico sintomática, neuropatia, reparação tendinosa, artrite inflamatória ativa, dor ou parestesias | `specialist_review` contextual | carga digital e compressão dependentes da posição |
| `isolated_finger_pip_flexion_resisted`, `isolated_finger_dip_flexion_resisted`, `thumb_ip_flexion_resisted`, `thumb_ip_extension_resisted`, `resisted_thumb_opposition` | qualquer uso público inicial | `specialist_review` | proximidade a testes tendinosos e reabilitação específica |
| Isometrias intensas ou prolongadas | doença cardiovascular conhecida, tensão arterial não controlada ou restrição ao esforço | `specialist_review` contextual | resposta pressora e necessidade de dose individual |

## 8. Findings para integração

### `BASE-SOURCE-001`

- **Severidade:** alta.
- **Objeto:** `src_murray_elbow_1995` na base v0.1.1.
- **Observado:** título e autores de Murray, Delp e Buchanan, mas URL para PMID `7581389`, um artigo de genética ocular.
- **Correção proposta:** PMID `7775488`, DOI `10.1016/0021-9290(94)00114-J`.
- **Ação:** manter a base intacta nesta missão e colocar na fila de revisão da base. O catálogo derivado pode registar a correção como finding explícito, sem alegar que a base foi modificada.

### `EVIDENCE-GRIP-001`

- **Severidade:** alta.
- **Objeto:** uso de `src_labott_grip_2019`.
- **Problema:** revisão ampla em adultos mais velhos usada como suporte genérico para várias tarefas de grip.
- **Ação:** limitar ao efeito de transferência médio de programas de exercício na força de handgrip. Adicionar fontes específicas para hand gripper, handle diameter, hangs e carries.

### `EVIDENCE-ATOMIC-001`

- **Severidade:** alta.
- **Objeto:** `source_ids` globais por exercício.
- **Problema:** a mesma fonte pode aparecer como se suportasse execução, músculo principal, perfil de resistência, segurança e eficácia.
- **Ação:** claims atómicos com `claim_id`, `target_id`, `condition`, `outcome`, `source_ids`, `evidence_type`, `confidence` e `limitations`.

### `GRIP-MECHANICS-001`

- **Severidade:** alta.
- **Objeto:** `hand_gripper_close` e `hand_squeeze`.
- **Problema:** classificados na família `grip_isometric`, mas descritos com fecho/compressão e regresso.
- **Ação:** declarar ação dinâmica e retenção isométrica opcional. Resolver também se bola e gripper são variantes do mesmo canónico.

### `CHAIN-CARRY-001`

- **Severidade:** alta.
- **Objeto:** farmer carry, suitcase carry e plate pinch carry.
- **Problema:** `closed_chain` sem qualificador.
- **Ação:** `mixed_chain` ou campos separados por membro. Membro superior sustenta implemento livre; membros inferiores alternam apoio no solo.

### `HANG-GRAPH-001`

- **Severidade:** alta.
- **Objeto:** dead hang e towel hang.
- **Problema:** articulações do ombro, escápula e cotovelo ausentes do grafo mecânico principal, embora recebam peso corporal.
- **Ação:** integrar posições e papéis de suporte sem inventar ações dinâmicas.

### `HANG-PUBLIC-001`

- **Severidade:** alta.
- **Objeto:** dead hang.
- **Problema:** evidência direta em barra geral e benefícios terapêuticos insuficientes.
- **Ação:** `approved_with_limits`, sem claims de descompressão, cura, prevenção ou correção postural.

### `IDENTITY-GRIP-001`

- **Severidade:** moderada.
- **Objeto:** `thick_grip_hold`.
- **Problema:** a espessura do handle é material, mas constitui variante do support hold.
- **Ação:** reclassificar como variante de equipamento/contacto.

### `IDENTITY-HANG-001`

- **Severidade:** moderada.
- **Objeto:** `towel_hang`.
- **Problema:** altera interface, não a identidade fundamental da suspensão.
- **Ação:** variante de equipamento do dead hang.

### `SUPPORT-ROLE-001`

- **Severidade:** moderada.
- **Objeto:** apoio isométrico nas paralelas.
- **Problema:** pode ser contabilizado indevidamente como exercício de grip principal.
- **Ação:** exercício multiarticular de suporte com participação da mão contextual.

### `SAFETY-PROVENANCE-001`

- **Severidade:** moderada.
- **Objeto:** avisos públicos.
- **Problema:** cautelas mecânicas, critérios clínicos e riscos ambientais podem ficar misturados.
- **Ação:** tipar avisos e ligar fonte quando o aviso excede controlo ambiental ou regra de paragem conservadora.

## 9. Ledger de fontes proposto

| `source_id` | Fonte e identificadores | Tipo | Uso permitido | Confiança e limite |
|---|---|---|---|---|
| `src_murray_elbow_1995_corrected` | Murray WM, Delp SL, Buchanan TS. *Variation of muscle moment arms with elbow and forearm position*. PMID [7775488](https://pubmed.ncbi.nlm.nih.gov/7775488/), DOI [10.1016/0021-9290(94)00114-J](https://doi.org/10.1016/0021-9290(94)00114-J) | biomecânica cadavérica/modelação | dependência de ângulo e posição | moderada; não prova adaptação |
| `src_murray_capacity_2000` | Murray WM, Buchanan TS, Delp SL. *The isometric functional capacity of muscles that cross the elbow*. PMID [10828324](https://pubmed.ncbi.nlm.nih.gov/10828324/), DOI [10.1016/S0021-9290(00)00051-8](https://doi.org/10.1016/S0021-9290(00)00051-8) | biomecânica/modelação | capacidade funcional do cotovelo | moderada |
| `src_vigotsky_semg_2017` | Vigotsky AD et al. *Interpreting Signal Amplitudes in Surface Electromyography Studies in Sport and Rehabilitation Sciences*. PMID [29354060](https://pubmed.ncbi.nlm.nih.gov/29354060/), DOI [10.3389/fphys.2017.00985](https://doi.org/10.3389/fphys.2017.00985) | revisão metodológica | limites da sEMG | alta |
| `src_vigotsky_hypertrophy_2022` | Vigotsky AD et al. *Acute surface EMG amplitude is not a validated predictor of muscle hypertrophy*. PMID [35006527](https://pubmed.ncbi.nlm.nih.gov/35006527/), DOI [10.1007/s40279-021-01619-2](https://doi.org/10.1007/s40279-021-01619-2) | revisão metodológica | bloqueio EMG para hipertrofia | alta |
| `src_lappen_distal_biceps_2022` | Lappen S et al. *Distal biceps tendon ruptures occur with the almost extended elbow and supinated forearm*. PMID [35733124](https://pubmed.ncbi.nlm.nih.gov/35733124/), DOI [10.1186/s12891-022-05546-9](https://doi.org/10.1186/s12891-022-05546-9) | observacional de lesão | cautela mecânica distal | moderada; não atribui causalidade a curls |
| `src_maeo_overhead_2023` | Maeo S et al. *Triceps brachii hypertrophy is substantially greater after elbow extension training performed in the overhead versus neutral arm position*. PMID [35819335](https://pubmed.ncbi.nlm.nih.gov/35819335/), DOI [10.1080/17461391.2022.2100279](https://doi.org/10.1080/17461391.2022.2100279) | ensaio longitudinal | resultado do protocolo acima da cabeça | moderada; não universalizar |
| `src_kholinne_triceps_2018` | Kholinne E et al. *The different role of each head of the triceps brachii muscle in elbow extension*. PMID [29503079](https://pubmed.ncbi.nlm.nih.gov/29503079/), DOI [10.1016/j.aott.2018.02.005](https://doi.org/10.1016/j.aott.2018.02.005) | modelo biomecânico e sEMG | modulação por elevação do ombro | moderada |
| `src_mckenzie_dips_2022` | McKenzie CR et al. *Bench, bar, and ring dips: do kinematics and muscle activity differ?* PMID [36293792](https://pubmed.ncbi.nlm.nih.gov/36293792/), DOI [10.3390/ijerph192013211](https://doi.org/10.3390/ijerph192013211) | cinemática e sEMG | identidade e extensão do ombro nos fundos | moderada para tarefa aguda |
| `src_keir_tendon_posture_1997` | Keir PJ et al. *The effects of tendon load and posture on carpal tunnel pressure*. PMID [9260617](https://pubmed.ncbi.nlm.nih.gov/9260617/), DOI [10.1016/S0363-5023(97)80119-0](https://doi.org/10.1016/S0363-5023(97)80119-0) | experiência biomecânica | postura, carga e pressão | moderada; não é incidência de lesão |
| `src_rempel_rotation_pressure_1998` | Rempel DM et al. *Effects of forearm pronation/supination on carpal tunnel pressure*. PMID [9523952](https://pubmed.ncbi.nlm.nih.gov/9523952/), DOI [10.1016/S0363-5023(98)80086-5](https://doi.org/10.1016/S0363-5023(98)80086-5) | experiência in vivo | rotação, MCP e pressão | moderada; sem limiar de treino |
| `src_keir_pinch_pressure_1998` | Keir PJ, Bach JM, Rempel DM. *Fingertip loading and carpal tunnel pressure: differences between a pinching and a pressing task*. PMID [9565082](https://pubmed.ncbi.nlm.nih.gov/9565082/), DOI [10.1002/jor.1100160119](https://doi.org/10.1002/jor.1100160119) | experiência biomecânica | pinça, carga digital e pressão | moderada; não prova síndrome |
| `src_labott_grip_2019_limited` | Labott BK et al. *Effects of Exercise Training on Handgrip Strength in Older Adults: A Meta-Analytical Review*. PMID [31499496](https://pubmed.ncbi.nlm.nih.gov/31499496/), DOI [10.1159/000501203](https://doi.org/10.1159/000501203) | revisão sistemática/meta-análise | transferência média para handgrip em adultos mais velhos | moderada; não exercício-específica |
| `src_gerodimos_grip_2021` | Gerodimos V et al. *Can maximal handgrip strength and endurance be improved by an 8-week specialized strength training program in older women?* PMID [33340721](https://pubmed.ncbi.nlm.nih.gov/33340721/), DOI [10.1016/j.hansur.2020.11.007](https://doi.org/10.1016/j.hansur.2020.11.007) | ensaio aleatorizado | gripper/bola e força de preensão | moderada; mulheres mais velhas |
| `src_kong_handle_2005` | Kong YK, Lowe BD. *Optimal cylindrical handle diameter for grip force tasks*. DOI [10.1016/j.ergon.2004.11.003](https://doi.org/10.1016/j.ergon.2004.11.003) | ergonomia experimental | diâmetro, força, conforto e contacto | moderada; tarefa máxima, não treino |
| `src_krings_fat_grip_2021` | Krings BM et al. *Impact of Fat Grip Attachments on Muscular Strength and Neuromuscular Activation During Resistance Exercise*. PMID [30694963](https://pubmed.ncbi.nlm.nih.gov/30694963/), DOI [10.1519/JSC.0000000000002954](https://doi.org/10.1519/JSC.0000000000002954) | estudo agudo de força e sEMG | configuração de pega espessa | baixa a moderada; sem adaptação |
| `src_winwood_farmer_2014` | Winwood PW et al. *A Biomechanical Analysis of the Farmers Walk, and Comparison with the Deadlift and Unloaded Walk*. DOI [10.1260/1747-9541.9.5.1127](https://doi.org/10.1260/1747-9541.9.5.1127) | biomecânica | identidade do farmer walk | baixa a moderada; seis strongmen |
| `src_bordelon_carry_2021` | Bordelon NM et al. *The Effects of Load Magnitude and Carry Position on Lumbopelvic-Hip Complex and Scapular Stabilizer Muscle Activation During Unilateral Dumbbell Carries*. PMID [33298714](https://pubmed.ncbi.nlm.nih.gov/33298714/), DOI [10.1519/JSC.0000000000003880](https://doi.org/10.1519/JSC.0000000000003880) | estudo agudo de sEMG | posição, carga e estabilidade no carry unilateral | baixa a moderada |
| `src_ellestad_loaded_carry_2024` | Ellestad SH et al. *The Quantification of Muscle Activation During the Loaded Carry Movement Pattern*. PMID [38665162](https://pubmed.ncbi.nlm.nih.gov/38665162/), DOI [10.70252/NWUE9985](https://doi.org/10.70252/NWUE9985) | estudo agudo de sEMG | carry versus hold e padrão de locomoção | baixa a moderada |
| `src_exel_finger_hang_2023` | Exel J et al. *Neuromechanics of finger hangs with arm lock-offs*. PMID [37927449](https://pubmed.ncbi.nlm.nih.gov/37927449/), DOI [10.3389/fspor.2023.1251089](https://doi.org/10.3389/fspor.2023.1251089) | modelação, força e sEMG | cargas por ângulo em hangs de escalada | moderada para a tarefa; indireta para barra geral |
| `src_watanabe_breath_hold_2022` | Watanabe H et al. *Effect of breath-hold on the responses of arterial blood pressure and cerebral blood velocity to isometric exercise*. PMID [34618221](https://pubmed.ncbi.nlm.nih.gov/34618221/), DOI [10.1007/s00421-021-04822-1](https://doi.org/10.1007/s00421-021-04822-1) | experiência fisiológica | respiração durante handgrip isométrico | moderada; adultos saudáveis |

## 10. Validações recomendadas para o pacote

1. Todos os claims públicos têm fonte compatível com o resultado.
2. Nenhuma fonte EMG suporta sozinha `primary`, hipertrofia, superioridade ou segurança.
3. Nenhum claim terapêutico aparece em hangs, grip, punho ou carries.
4. `technical_inference` nunca é a única proveniência de um claim público importante.
5. Fontes internas e externas são distinguíveis.
6. DOI, PMID, título, autores e ano são coerentes.
7. `src_murray_elbow_1995` gera finding até correção formal da base.
8. Hangs incluem ombro, escápula, cotovelo, punho e dedos no grafo.
9. Carries usam cadeia mista ou classificação segmentar.
10. Towel hang e thick-grip hold têm pai canónico.
11. Hand gripper e bola não contradizem execução dinâmica/isométrica.
12. Pinch, support, crush e open-hand não são tratados como capacidades equivalentes.
13. Parallel-bar support não conta automaticamente como cobertura principal de grip.
14. Toda a suspensão possui entrada e saída controladas, ancoragem e espaço livre.
15. Toda a banda possui ancoragem, inspeção e direção de libertação segura.
16. Toda a máquina sem geometria suficiente fica `approved_with_limits` ou `internal_only`.
17. Pós-lesão, pós-cirurgia e sintomas neurológicos ativam `specialist_review`.
18. Avisos não diagnosticam nem prescrevem tratamento.
19. Publicação PT-PT usa “preensão”, “pega”, “punho”, “cotovelo”, “halteres”, “barra fixa”, “fundos” e “flexão de braços”.
20. Duas construções determinísticas produzem claims, ledgers, manifestos, hashes e ZIP idênticos.

## 11. Decisão final da Equipa 7

**Estado:** `approved_with_required_corrections`.

Os três relatórios de domínio são utilizáveis e maioritariamente prudentes. A integração não deve ser aprovada enquanto não forem resolvidos:

- proveniência atómica;
- fonte específica para grip, carries e hangs;
- cadeia cinética dos carries;
- grafo articular dos hangs;
- classificação dinâmica/isométrica de gripper e bola;
- relação variante-pai de towel hang e thick-grip hold;
- finding do PMID incorreto na base;
- limites públicos e fila de revisão especialista.

Não se recomenda qualquer alteração anatómica à base muscular v0.1.1. A única correção proposta para a base é de metadados de fonte e deve seguir a fila de revisão, sem edição silenciosa.

