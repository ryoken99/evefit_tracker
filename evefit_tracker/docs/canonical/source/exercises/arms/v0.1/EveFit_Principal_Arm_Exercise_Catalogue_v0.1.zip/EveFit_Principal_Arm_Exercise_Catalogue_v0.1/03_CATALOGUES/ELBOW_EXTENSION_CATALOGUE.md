# Extensão do cotovelo

O papel muscular é contextual e nunca significa isolamento absoluto.

## Extensão cruzada de tríceps no cabo

- ID: `cross_body_cable_triceps_extension`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Coluna de cabos, polia ajustável e pega unilateral.
- Mecânica: Exercício com o ombro à frente do corpo, com ligeira adução horizontal contextual e resistência oblíqua ao longo do cabo. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão de tríceps acima da cabeça

- ID: `overhead_triceps_extension`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Coluna de cabos, polia ajustável e corda para polia.
- Mecânica: Exercício com o ombro elevado acima da cabeça e resistência definida por cabo, peso livre ou banda. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão de tríceps deitado

- ID: `lying_triceps_extension`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Banco plano e Barra EZ.
- Mecânica: Exercício com o ombro em flexão aproximada de 90 graus, estabilizado sobre banco e resistência vertical pela gravidade. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão de tríceps em suspensão

- ID: `suspension_triceps_extension`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão do cotovelo em cadeia mista através de pegas móveis num sistema de suspensão.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal e sistema de suspensão.
- Mecânica: A dificuldade muda com a inclinação corporal; os pés mantêm contacto com o solo, as pegas movem-se e ombro e tronco devem permanecer controlados.

### Execução

1. Segurar as pegas com braços à frente, corpo alinhado e tensão no sistema.
2. Fletir os cotovelos levando a cabeça entre as mãos e estendê-los para afastar o corpo.
3. Terminar antes de perder alinhamento do tronco ou posição do ombro.

**Cues:** Manter cotovelos apontados em frente, corpo alinhado e controlar a descida.

**Erros frequentes:** Transformar o gesto num empurrar de ombro, dobrar a anca e usar ancoragem instável.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão de tríceps na máquina

- ID: `machine_triceps_extension`
- Estado: `approved_with_limits`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Máquina de tríceps com pesos selecionados.
- Mecânica: Exercício com o ombro definido pela máquina, geralmente com braço apoiado e resistência definida por came, cabo ou braço de alavanca. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão de tríceps na polia

- ID: `cable_triceps_pushdown`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Coluna de cabos, polia alta e barra reta para polia.
- Mecânica: Exercício com o ombro neutro, com o braço junto ao tronco e resistência ao longo do cabo a partir de uma polia alta. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Flexão de braços com mãos próximas

- ID: `close_grip_push_up`
- Estado: `approved_public`
- Família: `elbow_extension_compound`
- Objetivo: Flexão de braços multiarticular com mãos próximas, aumentando a exigência contextual de extensão do cotovelo.
- Músculos principais/contextuais: Peitoral maior e tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal.
- Mecânica: Cadeia fechada com extensão do cotovelo e adução horizontal do ombro; não é isolamento de tríceps.

### Execução

1. Em prancha, mãos abaixo ou ligeiramente dentro da largura dos ombros, corpo alinhado.
2. Descer o corpo com controlo e empurrar o solo até regressar à prancha.
3. Terminar a descida antes de perder alinhamento; subir sem bloquear agressivamente os cotovelos.

**Cues:** Manter corpo alinhado, cotovelos orientados para trás e empurrar o chão de forma uniforme.

**Erros frequentes:** Abrir excessivamente os cotovelos, deixar a anca cair e forçar uma posição estreita dolorosa.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Fundos em paralelas

- ID: `parallel_bar_dip`
- Estado: `approved_public`
- Família: `elbow_extension_compound`
- Objetivo: Exercício multiarticular em apoio nas paralelas, com extensão do cotovelo relevante e participação do ombro e peito.
- Músculos principais/contextuais: Peitoral maior e tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal e paralelas.
- Mecânica: Cadeia fechada. O tricípite é importante, mas o gesto também exige extensão/adução do ombro, depressão escapular e controlo do tronco.

### Execução

1. Apoiar o corpo nas paralelas com cotovelos estendidos, ombros organizados e pés sem apoio.
2. Descer por flexão controlada dos cotovelos e ombros; subir estendendo os cotovelos sem perder a posição escapular.
3. Terminar a descida antes de dor ou perda de controlo do ombro; subir até extensão confortável.

**Cues:** Manter as barras firmemente seguras, controlar a profundidade e evitar encolher os ombros.

**Erros frequentes:** Descer além da amplitude tolerada, balançar o corpo e bloquear o cotovelo de forma agressiva.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Fundos no banco

- ID: `bench_dip`
- Estado: `approved_with_limits`
- Família: `elbow_extension_compound`
- Objetivo: Extensão do cotovelo com as mãos apoiadas atrás do tronco; opção pública com limites pela extensão do ombro.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide, peitoral maior e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal e banco plano.
- Mecânica: Apoio posterior que combina extensão do cotovelo com extensão do ombro. A amplitude deve ser conservadora.

### Execução

1. Apoiar as mãos na borda de um banco estável, com o tronco próximo do apoio e cotovelos estendidos.
2. Descer através de flexão do cotovelo mantendo o ombro confortável; regressar estendendo o cotovelo.
3. Parar a descida antes de desconforto anterior no ombro ou perda de alinhamento.

**Cues:** Manter o tronco perto do banco, usar amplitude curta e confortável e apontar os cotovelos para trás.

**Erros frequentes:** Descer demasiado, afastar o tronco do banco e usar apoio instável.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Kickback de tríceps

- ID: `triceps_kickback`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Halter.
- Mecânica: Exercício com o ombro em extensão atrás do tronco e resistência vertical pela gravidade ou ao longo do cabo. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Supino com pega fechada

- ID: `close_grip_bench_press`
- Estado: `approved_public`
- Família: `elbow_extension_compound`
- Objetivo: Supino multiarticular com pega relativamente estreita, no qual a extensão do cotovelo tem papel relevante.
- Músculos principais/contextuais: Peitoral maior e tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Barra reta e banco plano.
- Mecânica: A largura de pega altera momentos e carga tolerada. Continua a ser um exercício de empurrar multiarticular.

### Execução

1. Deitado no banco, pés estáveis, barra segura com pega ligeiramente mais estreita do que a habitual.
2. Descer a barra ao tronco com controlo e empurrar por extensão do cotovelo e adução horizontal do ombro.
3. Aproximar do tronco sem perder posição do ombro; subir até extensão controlada.

**Cues:** Manter antebraços alinhados, controlar a descida e usar observador ou suportes de segurança.

**Erros frequentes:** Pega estreita ao ponto de colapsar o punho, cotovelos sem controlo e treinar sem suportes adequados.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.
