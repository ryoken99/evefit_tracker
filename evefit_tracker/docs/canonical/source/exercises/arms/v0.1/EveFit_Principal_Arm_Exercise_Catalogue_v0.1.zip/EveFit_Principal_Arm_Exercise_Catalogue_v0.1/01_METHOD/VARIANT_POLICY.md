# Política de variantes

Tipos aceites: `exercise_variant`, `equipment_variant`, `grip_orientation_variant`, `technique_variant`, `progression`, `regression`, `isometric_variant`, `eccentric_variant`, `duplicate`, `excluded` e `specialist_review`.

| Tipo | Número |
|---|---:|
| `equipment_variant` | 64 |
| `grip_orientation_variant` | 4 |
| `progression` | 2 |
| `regression` | 5 |
| `technique_variant` | 10 |

As 85 variantes materializadas cobrem os equipamentos e configurações obrigatórios sem inflacionar o núcleo canónico.
