# Fila de revisão especialista

| Item | Estado | Motivo |
|---|---|---|
| `resisted_thumb_opposition` | `specialist_review` | Proximidade a uso clínico e necessidade de dose/resistência individual. |
| Máquinas de curl e tríceps | `approved_with_limits` | Came, eixo e trajetória variam entre modelos. |
| `bench_dip` | `approved_with_limits` | Extensão do ombro pode ser limitante. |
| `dead_hang` e `towel_hang` | `approved_with_limits` | Tolerância do ombro, preensão e segurança da ancoragem. |
| Desvios radial/ulnar e wrist roller | `approved_with_limits` | Alavanca e amplitude exigem controlo fino. |
| Achado `src_murray_elbow_1995` | `unresolved_base_fix` | Corrigir apenas em missão própria da base muscular. |
