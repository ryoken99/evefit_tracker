# Antebraço, punho e dedos

O papel muscular é contextual e nunca significa isolamento absoluto.

## Desvio radial resistido do punho

- ID: `wrist_radial_deviation`
- Estado: `approved_with_limits`
- Família: `wrist_deviation`
- Objetivo: Desvio radial do punho contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Extensor radial curto do carpo, extensor radial longo do carpo e flexor radial do carpo.
- Secundários/estabilizadores: Abdutor longo do polegar.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Halter.
- Mecânica: Exercício monoação destinado a carregar desvio radial do punho. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar desvio radial do punho contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Desvio ulnar resistido do punho

- ID: `wrist_ulnar_deviation`
- Estado: `approved_with_limits`
- Família: `wrist_deviation`
- Objetivo: Desvio ulnar do punho contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Extensor ulnar do carpo e flexor ulnar do carpo.
- Secundários/estabilizadores: Nenhum identificado.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Halter.
- Mecânica: Exercício monoação destinado a carregar desvio ulnar do punho. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar desvio ulnar do punho contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão do punho com antebraço apoiado

- ID: `supported_wrist_extension`
- Estado: `approved_public`
- Família: `wrist_flexion_extension`
- Objetivo: Extensão do punho contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Extensor radial curto do carpo, extensor radial longo do carpo e extensor ulnar do carpo.
- Secundários/estabilizadores: Extensor dos dedos.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Halter e banco plano.
- Mecânica: Exercício monoação destinado a carregar extensão do punho. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar extensão do punho contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão dos dedos com banda

- ID: `resisted_finger_extension`
- Estado: `approved_public`
- Família: `digital_flexion_extension`
- Objetivo: Abrir os dedos contra uma banda colocada à volta das falanges.
- Músculos principais/contextuais: Extensor do dedo mínimo, extensor do indicador e extensor dos dedos.
- Secundários/estabilizadores: Extensor radial curto do carpo e primeiro lumbrical da mão.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Banda elástica.
- Mecânica: Exercício de resistência elástica para extensão MCP e contribuição através das expansões extensoras. A carga individual de cada dedo não é uniforme.

### Execução

1. Colocar uma banda leve em torno dos dedos com a mão fechada de forma confortável.
2. Abrir os dedos contra a banda e regressar lentamente.
3. Terminar antes de a banda escorregar ou forçar as articulações.

**Cues:** Abrir de forma uniforme, manter o punho neutro e usar banda leve.

**Erros frequentes:** Usar banda demasiado forte, deixar a banda enrolar nas articulações e compensar com extensão do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Flexão do punho com antebraço apoiado

- ID: `supported_wrist_curl`
- Estado: `approved_public`
- Família: `wrist_flexion_extension`
- Objetivo: Flexão do punho contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Flexor radial do carpo e flexor ulnar do carpo.
- Secundários/estabilizadores: Flexor profundo dos dedos, flexor superficial dos dedos e palmar longo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Halter e banco plano.
- Mecânica: Exercício monoação destinado a carregar flexão do punho. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar flexão do punho contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Flexão resistida dos dedos

- ID: `finger_curl`
- Estado: `approved_public`
- Família: `digital_flexion_extension`
- Objetivo: Flexão dos dedos contra resistência, mantendo o punho controlado.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Extensor radial curto do carpo, extensor ulnar do carpo e flexor longo do polegar.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Barra reta.
- Mecânica: Carrega flexores superficiais e profundos dos dedos através das articulações MCP, PIP e DIP; a contribuição varia com a forma do objeto e posição do punho.

### Execução

1. Apoiar os antebraços e segurar o implemento nas falanges com dedos parcialmente estendidos.
2. Fechar os dedos para trazer o implemento para a palma; abrir de forma controlada sem o deixar cair.
3. Terminar com preensão segura, sem flexão excessiva do punho.

**Cues:** Mover pelos dedos, manter o punho estável e usar carga pequena e segura.

**Erros frequentes:** Deixar a barra rolar sem controlo, substituir o gesto por flexão do punho e usar carga que ameaça cair.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Oposição resistida do polegar

- ID: `resisted_thumb_opposition`
- Estado: `specialist_review`
- Família: `thumb_specific`
- Objetivo: Oposição do polegar contra resistência leve, mantida fora da camada pública inicial.
- Músculos principais/contextuais: Abdutor curto do polegar, flexor curto do polegar e oponente do polegar.
- Secundários/estabilizadores: Nenhum identificado.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Resistência manual.
- Mecânica: Tarefa específica dos músculos tenares e do controlo carpometacárpico do polegar; fica em revisão especialista por proximidade a usos clínicos.

### Execução

1. Mão apoiada e polegar numa posição confortável.
2. Levar a polpa do polegar em direção aos dedos contra resistência manual leve.
3. Terminar antes de dor, colapso da articulação ou compensação do punho.

**Cues:** Usar resistência mínima, mover sem dor e manter o punho estável.

**Erros frequentes:** Forçar a base do polegar, usar resistência alta e aplicar em presença de dor sem avaliação.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Pronação resistida do antebraço

- ID: `resisted_forearm_pronation`
- Estado: `approved_public`
- Família: `forearm_rotation`
- Objetivo: Pronação do antebraço contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Pronador quadrado e pronador redondo.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Martelo ou alavanca.
- Mecânica: Exercício monoação destinado a carregar pronação do antebraço. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar pronação do antebraço contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Rolo de punho

- ID: `wrist_roller`
- Estado: `approved_with_limits`
- Família: `wrist_flexion_extension`
- Objetivo: Enrolar e desenrolar uma carga através de flexão e extensão repetida do punho e dos dedos.
- Músculos principais/contextuais: Extensor radial curto do carpo, extensor radial longo do carpo, extensor ulnar do carpo, flexor radial do carpo e flexor ulnar do carpo.
- Secundários/estabilizadores: Nenhum identificado.
- Possíveis limitadores de preensão: Flexor profundo dos dedos.
- Equipamento base: Rolo de punho.
- Mecânica: Tarefa cíclica bilateral que combina punho, dedos e preensão. O sentido de enrolamento determina a predominância relativa, pelo que ambas as direções ficam como variantes.

### Execução

1. Segurar o rolo com os braços numa posição estável e o cabo totalmente desenrolado.
2. Rodar alternadamente os punhos para enrolar a carga; desenrolar de forma controlada.
3. Terminar antes de o punho perder alinhamento ou a carga cair.

**Cues:** Usar movimentos curtos do punho, manter ombros relaxados e controlar também a descida.

**Erros frequentes:** Rodar todo o braço, deixar a carga cair e usar carga que força compensação do ombro.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Supinação resistida do antebraço

- ID: `resisted_forearm_supination`
- Estado: `approved_public`
- Família: `forearm_rotation`
- Objetivo: Supinação do antebraço contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Bicípite braquial e supinador.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Martelo ou alavanca.
- Mecânica: Exercício monoação destinado a carregar supinação do antebraço. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar supinação do antebraço contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.
