# Relatório independente: antebraço, punho e dedos

## Catálogo Canónico dos Principais Exercícios de Braços v0.1

**Equipa:** 3, antebraço e punho  
**Âmbito:** investigação e recomendação, sem edição da base canónica ou do pacote final  
**Base obrigatória:** `EveFit_Muscular_Knowledge_Base_v0.1.1`  
**SHA-256 da base:** `a1876a1d4bc21ab54b3828774f66a99519a4953dc00191e69475d8c15b8b30b0`  
**Data da revisão:** 2026-07-30

## 1. Conclusão executiva

Recomendo nove exercícios canónicos para o núcleo de antebraço, punho e dedos:

1. pronação resistida do antebraço;
2. supinação resistida do antebraço;
3. flexão do punho com antebraço apoiado;
4. extensão do punho com antebraço apoiado;
5. desvio radial resistido do punho;
6. desvio ulnar resistido do punho;
7. rolo de punho;
8. flexão dos dedos com carga;
9. extensão dos dedos com banda elástica.

Halter seguro por uma extremidade, martelo/alavanca, cabo, banda e resistência manual não justificam exercícios canónicos separados para pronação ou supinação. São variantes de equipamento, perfil de resistência, execução ou isometria. Da mesma forma, barra, halteres, cabo e banda são variantes da flexão ou extensão do punho. A posição atrás do corpo é uma variante técnica da flexão do punho, não um exercício independente.

O rolo de punho deve manter identidade própria. Combina preensão sustentada, ciclos alternados de flexão e extensão, coordenação bilateral e uma carga externa cujo braço de momento é definido pelo raio do rolo e pelo cabo. Não é apenas uma troca de equipamento do wrist curl.

Quatro tarefas adicionais devem existir apenas na camada interna ou em revisão especialista:

- flexão resistida isolada da articulação interfalângica proximal dos dedos;
- flexão resistida isolada da articulação interfalângica distal dos dedos;
- flexão resistida da articulação interfalângica do polegar;
- extensão resistida da articulação interfalângica do polegar.

Estas tarefas são úteis para cobrir `flexor_digitorum_superficialis`, `flexor_digitorum_profundus`, `flexor_pollicis_longus` e `extensor_pollicis_longus`, mas aproximam-se de testes tendinosos e trabalho terapêutico específico. Não devem ser apresentadas como exercícios gerais sem revisão especialista.

Não encontrei evidência que justifique alterar relações ou papéis musculares da base v0.1.1. Em particular, a base está coerente ao marcar:

- `flexor_digitorum_superficialis` como `principal_contributor` em `finger_pip_flexion`;
- `flexor_digitorum_profundus` como `principal_contributor` em `finger_dip_flexion`;
- `flexor_pollicis_longus` como `principal_contributor` em `thumb_ip_flexion`;
- `extensor_pollicis_longus` como `principal_contributor` em `thumb_ip_extension`;
- os extensores longos dos dedos como contribuintes secundários ou contextuais na extensão interfalângica, porque a transmissão distal depende da expansão extensora e da posição das articulações.

Foi, contudo, identificado um erro de proveniência na base. `src_murray_elbow_1995` apresenta o título correto, mas o URL/PMID `7581389` aponta para um artigo sobre retinite pigmentosa. O artigo biomecânico correto é PMID `7775488`, DOI `10.1016/0021-9290(94)00114-J`. Este finding deve entrar na fila de revisão de metadados. A base original não foi editada e o erro não muda as decisões deste relatório.

## 2. Política de identidade aplicada

| Decisão | Classificação | Justificação |
|---|---|---|
| Pronação com halter excêntrico, martelo ou alavanca | `equipment_variant` | A ação, articulações e objetivo técnico são os mesmos. O comprimento da alavanca altera a magnitude do momento, não a identidade. |
| Pronação com cabo | `equipment_variant` | Muda a direção e o perfil da resistência. Mantém a ação canónica. |
| Pronação com banda | `equipment_variant` | A tensão cresce com o alongamento da banda. Mantém a ação canónica. |
| Pronação manual dinâmica | `equipment_variant` | O parceiro substitui a carga externa. Dose e direção são menos reproduzíveis. |
| Pronação manual estática | `isometric_variant` | Não existe deslocamento articular líquido. |
| Supinação com os mesmos meios | mesmas classes da pronação | Não criar uma entrada por objeto. |
| Halter simétrico seguro exatamente no centro para rotação axial | `excluded_configuration` | A gravidade passa aproximadamente pelo eixo da pega, pelo que produz pouco ou nenhum momento útil de pronação ou supinação. O halter deve ser seguro fora do centro ou funcionar como alavanca. |
| Flexão do punho com barra ou halteres | `equipment_variant` | Bilateralidade e liberdade de alinhamento mudam, mas a ação canónica mantém-se. |
| Flexão do punho com cabo ou banda | `equipment_variant` | Perfil de resistência diferente, sem mudança suficiente de ação ou cadeia. |
| Flexão do punho atrás do corpo | `technique_variant` | Remove o apoio do antebraço, acrescenta estabilização do ombro e risco de manuseamento, mas não cria uma função articular nova. |
| Extensão do punho com barra, halter, cabo ou banda | `equipment_variant` | Mesma decisão da flexão. |
| Desvio radial e desvio ulnar | dois `canonical_exercise` | São ações opostas com conjuntos principais diferentes. Não são apenas configurações do mesmo exercício. |
| Rolo de punho | `canonical_exercise` | Preensão contínua, trabalho alternado e perfil próprio tornam-no materialmente distinto. |
| Direção de enrolamento do rolo | `technique_variant` ou configuração obrigatória | Muda a fase em que flexores ou extensores dominam, mas ambas as famílias participam no ciclo completo. |
| Flexão dos dedos com barra ou halter | `equipment_variant` | A distribuição entre dedos pode mudar, sem exigir nova identidade. |
| Extensão dos dedos com banda ou dispositivo multi-alça | `equipment_variant` | A geometria da banda deve ser registada porque pode acrescentar abdução dos dedos. |

## 3. Exercícios canónicos recomendados

### 3.1 `forearm_pronation_resisted`

**Nome PT-PT:** Pronação resistida do antebraço  
**Nome inglês:** Resisted forearm pronation  
**Estado recomendado:** `approved_public`  
**Evidência de ênfase:** `moderate_supported_emphasis`

**Mecânica e execução**

- Articulações funcionais: `proximal_radioulnar_joint` e `distal_radioulnar_joint`.
- Ação: `forearm_pronation`.
- Plano/eixo: rotação no plano transversal em torno do eixo longitudinal do antebraço.
- Cadeia: aberta.
- Segmento proximal: braço e ulna relativamente estabilizados.
- Segmento móvel: rádio, mão e implemento em rotação.
- Posição-base recomendada: sentado ou de pé, cotovelo perto de 90 graus e junto ao tronco, punho neutro, ombro sem rodar.
- Movimento: rodar o antebraço para que a palma se oriente progressivamente para baixo, sem transformar o movimento em rotação interna do ombro.
- Implemento preferido para a ficha pública: martelo ou halter seguro por uma extremidade, porque torna o braço de alavanca visível.
- Perfil de resistência com alavanca e gravidade: depende do ângulo entre a alavanca e a vertical; não é constante ao longo da amplitude.
- Perfil com cabo: depende da posição da polia e da linha de tração.
- Perfil com banda: tensão crescente com o alongamento, além da mudança do braço de momento.

**Relações musculares no exercício**

| Músculo | Papel no exercício | Contexto | Confiança |
|---|---|---|---|
| `pronator_quadratus` | `primary` | Produção de pronação, com relação principal da base na articulação radioulnar distal | moderada |
| `pronator_teres` | `primary_contextual` | Contribuição importante sob resistência, especialmente quando cotovelo e antebraço são estabilizados | moderada |
| `extensor_carpi_radialis_brevis` | `stabilizer` | Apenas quando a pega ou o implemento exigem força de preensão e controlo do punho | moderada |
| `flexor_carpi_radialis` | `stabilizer` | Pode aumentar atividade durante pronação com power grip, sem ser classificado como pronador | baixa a moderada |
| `palmaris_longus` | `stabilizer` | Contextual em tarefas com preensão; não universal | baixa |
| flexores longos dos dedos | `grip_limiter` | Quando é necessário segurar fortemente a alavanca | moderada |

Atividade EMG de um músculo que não possui relação de ação de pronação na base não deve convertê-lo em motor da pronação. O estudo de Bader et al. mostra coativação ampla com power grip, não uma nova ação anatómica.

**Variantes**

- martelo/alavanca: variante de equipamento preferida;
- halter excêntrico: variante de equipamento equivalente;
- cabo: variante de equipamento e perfil;
- banda: variante de equipamento e perfil;
- resistência manual dinâmica: variante com menor reprodutibilidade;
- resistência manual estática: variante isométrica;
- implemento próprio de pronação/supinação: variante de equipamento.

**Erros e cautelas**

- segurar um halter simétrico ao centro e assumir que a gravidade cria torque axial;
- deixar o punho desviar ou flexionar;
- rodar o ombro e deslocar o cotovelo;
- usar alavanca demasiado longa ou carga excessiva;
- forçar o fim da amplitude;
- ignorar dor ulnar ou radial no punho, instabilidade, estalido doloroso, dormência ou perda súbita de força.

Patologia ou cirurgia recente do cotovelo, rádio/ulna, articulação radioulnar distal ou complexo fibrocartilagíneo triangular exige `specialist_review`.

### 3.2 `forearm_supination_resisted`

**Nome PT-PT:** Supinação resistida do antebraço  
**Nome inglês:** Resisted forearm supination  
**Estado recomendado:** `approved_public`  
**Evidência de ênfase:** `moderate_supported_emphasis`

**Mecânica e execução**

- Articulações: `proximal_radioulnar_joint` e `distal_radioulnar_joint`.
- Ação: `forearm_supination`.
- Cadeia e setup: iguais aos da pronação.
- Movimento: rodar o antebraço para orientar a palma para cima, preservando punho neutro e braço estável.
- A capacidade de torque varia com a posição inicial do antebraço e com o ângulo do cotovelo. A ficha não deve publicar uma posição universalmente superior.

**Relações musculares no exercício**

| Músculo | Papel no exercício | Contexto | Confiança |
|---|---|---|---|
| `supinator` | `primary` | Motor principal da supinação no modelo canónico | moderada |
| `biceps_brachii` | `primary_contextual` | Contribuição substancial sob resistência; o ângulo do cotovelo e a posição do antebraço alteram a vantagem mecânica | moderada |
| `extensor_carpi_radialis_brevis` | `stabilizer` | Quando a tarefa inclui power grip ou exige manter o punho | moderada |
| flexores longos dos dedos | `grip_limiter` | Quando a alavanca precisa de preensão forte | moderada |

`brachioradialis` não deve receber relação pública de supinação nesta versão. A base v0.1.1 só aprova `elbow_flexion` para este músculo, e levar o antebraço para neutro não equivale a afirmar supinação universal.

**Variantes e cautelas**

Aplicam-se as mesmas classes e regras da pronação. A supinação com cabo ou banda só é válida se a linha de resistência criar momento de supinação no antebraço. A banda deve ser inspecionada e ancorada de modo a evitar libertação na direção do rosto.

### 3.3 `supported_wrist_flexion`

**Nome PT-PT:** Flexão do punho com antebraço apoiado  
**Nome inglês:** Supported wrist curl  
**Estado recomendado:** `approved_public`  
**Evidência de ênfase:** `moderate_supported_emphasis`

**Mecânica e execução**

- Articulação canónica: `radiocarpal_joint`.
- Ação: `wrist_flexion`.
- Cadeia: aberta.
- Antebraço: apoiado numa coxa, banco ou superfície estável.
- Posição-base: palma para cima ou numa posição definida e registada; punho fora da borda do apoio; dedos fechados apenas o necessário para segurar a carga.
- Movimento: flexionar o punho sem elevar o antebraço, controlando o retorno em extensão.
- A amplitude deve ser confortável. Não é necessário carregar no limite passivo.
- Barra e halteres: maior momento quando a linha do centro de massa está mais perpendicular ao segmento mão.
- Cabo: momento dependente da direção da polia.
- Banda: resistência crescente e dependente da ancoragem.

**Relações musculares no exercício**

| Músculo | Papel | Contexto | Confiança |
|---|---|---|---|
| `flexor_carpi_radialis` | `primary` | Flexão com componente radial neutralizado pelo flexor ulnar | moderada |
| `flexor_carpi_ulnaris` | `primary` | Flexão com componente ulnar neutralizado pelo flexor radial | moderada |
| `palmaris_longus` | `secondary` | Quando presente; grande variação anatómica, não é alvo isolável | moderada |
| `flexor_digitorum_superficialis` | `secondary` ou `grip_limiter` | Segurar a carga acrescenta flexão dos dedos | moderada |
| `flexor_digitorum_profundus` | `secondary` ou `grip_limiter` | Idem, com maior relevância distal conforme o contacto | moderada |
| `flexor_pollicis_longus` | `secondary` | Apenas se o polegar participa materialmente na pega | moderada |
| extensores do punho | `antagonist_control` e `stabilizer` | Controlo excêntrico e coativação dependente da tarefa | moderada |

**Variantes**

- barra reta: `equipment_variant`, bilateral;
- halteres: `equipment_variant`, unilateral ou bilateral com alinhamento independente;
- cabo: `equipment_variant`;
- banda: `equipment_variant`;
- atrás do corpo: `technique_variant`, não uma entrada canónica;
- execução isométrica: `isometric_variant`.

**Atrás do corpo**

A variante atrás do corpo mantém `wrist_flexion`, mas remove o apoio do antebraço, exige estabilização do ombro em extensão e torna mais difícil observar a posição do punho e largar a barra. Deve ficar subordinada ao canónico e não ser a alternativa pública inicial.

**Erros e cautelas**

- transformar o exercício em flexão dos dedos;
- deixar a barra rolar sem controlo;
- usar o cotovelo ou ombro para deslocar a carga;
- insistir em amplitude terminal dolorosa;
- combinar carga elevada, repetição e postura extrema em pessoas sintomáticas.

### 3.4 `supported_wrist_extension`

**Nome PT-PT:** Extensão do punho com antebraço apoiado  
**Nome inglês:** Supported reverse wrist curl  
**Estado recomendado:** `approved_public`  
**Evidência de ênfase:** `moderate_supported_emphasis`

**Mecânica e execução**

- Articulação: `radiocarpal_joint`.
- Ação: `wrist_extension`.
- Cadeia: aberta.
- Antebraço apoiado, normalmente em pronação para uma execução simples e estável.
- Dorso da mão sobe contra a resistência sem o antebraço perder contacto.
- A orientação do antebraço afeta o recrutamento. Em dados recentes, a pronação aumentou atividade do `extensor_carpi_radialis_brevis`, enquanto a atividade do `extensor_carpi_ulnaris` foi menos sensível à rotação.

**Relações musculares no exercício**

| Músculo | Papel | Contexto | Confiança |
|---|---|---|---|
| `extensor_carpi_radialis_longus` | `primary` | Extensão com componente radial | moderada |
| `extensor_carpi_radialis_brevis` | `primary` | Extensão e estabilização, particularmente relevante em pronação | moderada |
| `extensor_carpi_ulnaris` | `primary` | Extensão com componente ulnar | moderada |
| `extensor_digitorum` | `secondary` | Depende da força de preensão e da posição digital | moderada |
| `extensor_digiti_minimi` | `secondary` | Contribuição do dedo V, não universal | baixa a moderada |
| `extensor_indicis` | `secondary` | Contribuição do indicador, não universal | baixa a moderada |
| `extensor_pollicis_longus` | `secondary` | Só quando a posição do polegar e a pega o exigem | baixa a moderada |
| flexores do punho e dedos | `antagonist_control` ou `grip_limiter` | Dependente da pega | moderada |

Os extensores do punho coativam fortemente em tarefas de preensão e estabilização. Isto não significa que qualquer exercício de grip seja um exercício primário de extensão do punho.

**Variantes e cautelas**

Barra, halter, cabo e banda são variantes de equipamento. A banda e o cabo precisam de alinhamento que realmente produza momento de extensão. Evitar compensação por extensão dos dedos, elevação do cotovelo e amplitude terminal forçada. Sintomas laterais persistentes do cotovelo ou dor dorsal do punho exigem redução ou revisão, não uma conclusão diagnóstica automática.

### 3.5 `wrist_radial_deviation_resisted`

**Nome PT-PT:** Desvio radial resistido do punho  
**Nome inglês:** Resisted wrist radial deviation  
**Estado recomendado:** `approved_with_limits`  
**Evidência de ênfase:** `plausible_mechanical_emphasis` a `moderate_supported_emphasis`

**Mecânica**

- Articulação: `radiocarpal_joint`.
- Ação: `wrist_radial_deviation`.
- Antebraço apoiado e mão em posição neutra, com o lado do polegar para cima, é o setup público mais claro.
- A mão desloca-se para o lado radial sem rodar o antebraço nem combinar de forma excessiva extensão.
- A cinemática real do punho é acoplada. Flexão/extensão e desvio radial/ulnar não são planos perfeitamente independentes. A descrição deve dizer "ênfase em desvio radial", não "movimento puro".

**Relações musculares**

| Músculo | Papel | Confiança |
|---|---|---|
| `flexor_carpi_radialis` | `primary_contextual` | moderada |
| `extensor_carpi_radialis_longus` | `primary_contextual` | moderada |
| `extensor_carpi_radialis_brevis` | `primary_contextual` | moderada |
| `abductor_pollicis_longus` | `secondary` | moderada |
| `extensor_pollicis_brevis` | `secondary` | baixa a moderada |
| flexores longos dos dedos | `grip_limiter` | moderada |

FCR e extensores radiais podem neutralizar parcialmente as componentes opostas de flexão e extensão enquanto somam o momento radial.

**Variantes**

- halter curto ou martelo/alavanca: equipamento;
- cabo: equipamento e perfil;
- banda: equipamento e perfil;
- resistência manual: equipamento ou isometria.

O valor público é moderado: é simples, cobre uma ação canónica pouco representada e tem utilidade geral, mas a evidência longitudinal de superioridade para adaptação é insuficiente. Não deve ser vendido como preventivo de lesão.

### 3.6 `wrist_ulnar_deviation_resisted`

**Nome PT-PT:** Desvio ulnar resistido do punho  
**Nome inglês:** Resisted wrist ulnar deviation  
**Estado recomendado:** `approved_with_limits`  
**Evidência de ênfase:** `plausible_mechanical_emphasis` a `moderate_supported_emphasis`

**Mecânica**

- Articulação: `radiocarpal_joint`.
- Ação: `wrist_ulnar_deviation`.
- Mesmo setup geral do desvio radial, com resistência orientada no sentido oposto.
- Não confundir desvio ulnar com pronação ou flexão do punho.

**Relações musculares**

| Músculo | Papel | Confiança |
|---|---|---|
| `flexor_carpi_ulnaris` | `primary` | moderada |
| `extensor_carpi_ulnaris` | `primary` | moderada |
| flexores longos dos dedos | `grip_limiter` | moderada |

FCU e ECU neutralizam parcialmente as componentes opostas de flexão e extensão enquanto somam o momento ulnar.

**Utilidade e cautela**

Aplicam-se as mesmas variantes do desvio radial. A utilidade pública é moderada. Dor no lado ulnar, sensação de instabilidade, estalido doloroso ou história recente de trauma deve colocar a tarefa em `specialist_review`.

### 3.7 `wrist_roller`

**Nome PT-PT:** Rolo de punho  
**Nome inglês:** Wrist roller  
**Estado recomendado:** `approved_with_limits`  
**Evidência de ênfase:** `plausible_mechanical_emphasis`

**Identidade própria**

O rolo exige preensão isométrica contínua e pequenos ciclos alternados entre as mãos para enrolar e desenrolar uma carga suspensa. O momento externo depende da força no cabo e do raio do cilindro. A carga também muda de altura durante a tarefa. Esta combinação é materialmente distinta de uma flexão ou extensão apoiada do punho.

**Articulações e ações**

- `radiocarpal_joint`;
- `wrist_flexion`;
- `wrist_extension`;
- ações dos dedos como suporte da preensão, sem criar automaticamente relações de flexão dinâmica completa;
- cotovelo e ombro sobretudo como estabilizadores de posição.

**Relações musculares**

| Músculo ou grupo | Papel | Contexto |
|---|---|---|
| FCR, FCU e `palmaris_longus` | `primary_contextual` | Fases dominadas por flexão do punho |
| ECRL, ECRB e ECU | `primary_contextual` | Fases dominadas por extensão do punho |
| FDP e FDS | `grip_limiter` e `stabilizer` | Segurar o cilindro |
| FPL e músculos tenares | `secondary` | Apenas conforme a pega do polegar |
| deltoide e estabilizadores escapulares | `stabilizer` | Se o rolo é mantido à frente do corpo sem suporte |

**Configurações**

- direção de enrolamento: campo obrigatório;
- altura do rolo: configuração, não nova entidade;
- carga e comprimento do cabo: prescrição;
- rolo montado num suporte: regressão mecânica relevante, porque reduz a limitação do ombro, mas não nova identidade;
- rolo segurado à frente: execução padrão com maior exigência estabilizadora.

**Cautelas**

- não deixar a carga cair livremente;
- não usar um cabo danificado;
- manter os dedos afastados do ponto onde o cabo enrola;
- não confundir fadiga do ombro com estímulo específico do antebraço;
- parar perante dor aguda, parestesias ou perda de controlo da pega.

### 3.8 `loaded_finger_flexion_curl`

**Nome PT-PT:** Flexão dos dedos com carga  
**Nome inglês:** Loaded finger curl  
**Estado recomendado:** `approved_with_limits`  
**Evidência de ênfase:** `plausible_mechanical_emphasis`

**Mecânica e execução**

- Articulações: `finger_metacarpophalangeal_joints`, `finger_proximal_interphalangeal_joints` e `finger_distal_interphalangeal_joints`.
- Ações: `finger_mcp_flexion`, `finger_pip_flexion` e `finger_dip_flexion`.
- O antebraço deve estar apoiado e a barra ou halter deve ter batentes, espaço e carga que permitam controlo.
- A carga pode rolar de uma preensão mais profunda para os dedos e voltar a ser fechada, sem ser deixada cair até às pontas sem controlo.
- A geometria de contacto determina que articulação e tendão recebem maior momento. A ficha não deve prometer seleção perfeita de FDS ou FDP num curl composto.

**Relações musculares**

| Músculo | Papel | Contexto | Confiança |
|---|---|---|---|
| `flexor_digitorum_superficialis` | `primary_contextual` | Principal relação da base em flexão IFP | moderada |
| `flexor_digitorum_profundus` | `primary_contextual` | Principal relação da base em flexão IFD | moderada |
| `flexor_pollicis_longus` | `secondary` | Apenas se o polegar cria força relevante sobre a barra | moderada |
| FCR, FCU e `palmaris_longus` | `secondary` | Tendência para flexão do punho | moderada |
| extensores do punho | `stabilizer` | Mantêm posição útil do punho durante força digital | moderada |

O FDP e o FDS têm excursões e contribuições articulares diferentes. Estudos in vitro confirmam que carga igual nos tendões não produz desempenho idêntico entre as articulações. Por isso, o exercício composto deve manter os dois como `primary_contextual`, com limitações explícitas.

**Cautelas**

- risco de deixar cair a barra ou prender os dedos;
- não usar carga que force hiperextensão passiva descontrolada;
- evitar combinar grande carga digital com punho em posição extrema;
- sintomas de dedo em gatilho, dor tendinosa localizada, lesão ou reparação tendinosa colocam o exercício em revisão especialista.

Esta entrada deve ser coordenada com a Equipa 4. É uma tarefa dinâmica de flexão dos dedos, enquanto hand gripper, holds e carries pertencem à taxonomia de preensão.

### 3.9 `elastic_band_finger_extension`

**Nome PT-PT:** Extensão dos dedos com banda elástica  
**Nome inglês:** Elastic-band finger extension  
**Estado recomendado:** `approved_with_limits`  
**Evidência de ênfase:** `plausible_mechanical_emphasis`

**Mecânica e execução**

- Articulações: MCP, IFP e IFD dos dedos II a V, conforme o setup.
- Ações: `finger_mcp_extension`, `finger_pip_extension` e `finger_dip_extension`.
- A banda deve permitir abrir a mão contra resistência sem escorregar.
- Uma banda única em torno das pontas pode acrescentar abdução dos dedos. Um dispositivo com laços individuais produz direção mais controlável. Este campo de geometria é obrigatório.
- A execução deve distinguir extensão dos dedos de extensão excessiva do punho.

**Relações musculares**

| Músculo | Papel | Contexto | Confiança |
|---|---|---|---|
| `extensor_digitorum` | `primary_contextual` | Principal motor contextual da extensão MCP no exercício | moderada |
| `extensor_digiti_minimi` | `secondary` | Dedo V | baixa a moderada |
| `extensor_indicis` | `secondary` | Indicador | baixa a moderada |
| lumbricais e interósseos | `synergist` | Extensão interfalângica através da expansão extensora, dependente da posição MCP | moderada |
| extensores do punho | `stabilizer` | Evitam que a tarefa se transforme em movimento do punho | moderada |

A base está correta ao não promover automaticamente ED, EDM ou EI a principais universais da extensão IFP/IFD. A expansão extensora acopla músculos extrínsecos e intrínsecos. A ficha pública deve apresentar "extensores dos dedos" e não prometer isolamento do `extensor_digitorum`.

**Polegar**

Se a banda também envolve o polegar, a direção pode produzir abdução, extensão CMC/MCP ou extensão IP. Isso deve ser uma configuração explícita. Não atribuir `thumb_ip_extension` ao `extensor_pollicis_brevis`, porque este não possui a relação principal distal aprovada. A extensão IP resistida pertence ao `extensor_pollicis_longus`.

**Cautelas**

- inspecionar a banda e evitar que a libertação ocorra na direção dos olhos;
- começar com resistência baixa;
- não bloquear ou colapsar articulações em hiperextensão;
- dor digital, instabilidade, lesão tendinosa ou pós-cirurgia exigem revisão especialista.

## 4. Exercícios internos ou em revisão especialista

| ID proposto | Estado | Ação e articulação | Relação principal | Decisão |
|---|---|---|---|---|
| `isolated_finger_pip_flexion_resisted` | `specialist_review` | `finger_pip_flexion` em `finger_proximal_interphalangeal_joints` | `flexor_digitorum_superficialis` | Útil para teste ou carga seletiva do FDS, mas depende de estabilização digital e aproxima-se de reabilitação da mão. |
| `isolated_finger_dip_flexion_resisted` | `specialist_review` | `finger_dip_flexion` em `finger_distal_interphalangeal_joints` | `flexor_digitorum_profundus` | Útil para distinguir FDP, mas a imobilização das outras articulações e a dose devem ser supervisionadas. |
| `thumb_ip_flexion_resisted` | `specialist_review` | `thumb_ip_flexion` em `thumb_interphalangeal_joint` | `flexor_pollicis_longus` | Relação distal forte, utilidade geral limitada e risco de confundir com flexão MCP/CMC ou pinça. |
| `thumb_ip_extension_resisted` | `specialist_review` | `thumb_ip_extension` em `thumb_interphalangeal_joint` | `extensor_pollicis_longus` | O EPL é o alvo distal. EPB e APL não devem ser usados como substitutos desta relação. |

Estas quatro entradas podem ter banda, putty, cabo muito leve ou resistência manual como variantes, mas não devem entrar na camada pública inicial.

## 5. Auditoria específica dos flexores e extensores longos

### 5.1 Dedos II a V

| Estrutura | Relação distal da v0.1.1 | Decisão da auditoria |
|---|---|---|
| `flexor_digitorum_superficialis` | `finger_pip_flexion`, `principal_contributor` | Correta. Inserção na falange média e dados biomecânicos apoiam papel principal na IFP. |
| `flexor_digitorum_profundus` | `finger_dip_flexion`, `principal_contributor` | Correta. Inserção na falange distal e dados biomecânicos apoiam papel principal na IFD. |
| `extensor_digitorum` | extensão MCP, IFP e IFD como secundária/contextual | Manter. É fortemente relevante na MCP, mas a extensão interfalângica depende da expansão extensora e da ação conjunta de intrínsecos. O papel de exercício pode ser `primary_contextual` na extensão MCP sem alterar a relação geral da base. |
| `extensor_digiti_minimi` | extensão do dedo V como secundária/contextual | Manter. Atua com o aparelho extensor e não garante isolamento distal. |
| `extensor_indicis` | extensão do indicador como secundária/contextual | Manter. Atua com o aparelho extensor e não garante isolamento distal. |

### 5.2 Polegar

| Estrutura | Relação distal da v0.1.1 | Decisão da auditoria |
|---|---|---|
| `flexor_pollicis_longus` | `thumb_ip_flexion`, `principal_contributor` | Correta. Não inferir que toda pinça ou hand gripper produz ênfase seletiva no FPL. |
| `extensor_pollicis_longus` | `thumb_ip_extension`, `principal_contributor` | Correta. É a relação a usar numa tarefa específica de extensão IP. |
| `extensor_pollicis_brevis` | extensão CMC/MCP e desvio radial, sem extensão IP principal | Correta. Não ligar a extensão IP do polegar ao EPB. |
| `abductor_pollicis_longus` | abdução radial CMC e desvio radial | Correta. Atividade durante supinação com power grip não o transforma num supinador canónico. |

**Finding anatómico/funcional:** nenhum pedido de alteração de relações ou papéis da base v0.1.1.

**Finding de proveniência `FOREARM-SOURCE-001`:**

- registo afetado: `src_murray_elbow_1995`;
- estado atual: título/autores/ano corretos, URL incorreto `https://pubmed.ncbi.nlm.nih.gov/7581389/`;
- problema: PMID `7581389` corresponde a Bardien et al., *An eighth locus for autosomal dominant retinitis pigmentosa is linked to chromosome 17q*;
- correção proposta: URL `https://pubmed.ncbi.nlm.nih.gov/7775488/`, PMID `7775488`, DOI `10.1016/0021-9290(94)00114-J`;
- estado recomendado: `source_metadata_review`;
- impacto: erro de rastreabilidade, sem alteração das relações musculares usadas neste relatório;
- ação executada: apenas documentação. A base v0.1.1 permanece intacta.

## 6. Segurança transversal e regras públicas

### Regras de execução

- estabilizar o antebraço quando o objetivo é punho ou rotação do antebraço;
- manter o punho aproximadamente neutro nos exercícios de pronação e supinação;
- usar alavanca curta e carga baixa antes de aumentar torque;
- não forçar amplitude terminal;
- registar direção da carga, posição do antebraço e geometria da pega;
- distinguir esforço de preensão de ação articular do punho;
- não interpretar EMG como prova de superioridade para hipertrofia.

### Condições de paragem

- dor aguda ou progressiva;
- dormência, formigueiro ou irradiação;
- estalido doloroso acompanhado de perda de controlo;
- sensação de instabilidade no punho ou articulação radioulnar;
- incapacidade de segurar o implemento em segurança;
- perda súbita de força ou amplitude.

### `specialist_review`

- pós-fratura ou pós-cirurgia do membro superior;
- reparação tendinosa;
- instabilidade radioulnar distal ou suspeita de lesão do complexo fibrocartilagíneo triangular;
- síndrome do túnel cárpico sintomática ou outra vulnerabilidade neural;
- tendinopatia ou dor persistente não esclarecida;
- artrite inflamatória ou instabilidade digital;
- patologia específica do polegar.

Estudos in vivo mostram que carga tendinosa, postura do punho, posição dos dedos e rotação do antebraço podem aumentar a pressão no túnel cárpico. Isto suporta evitar combinações prolongadas de força elevada e posições extremas em pessoas sintomáticas. Não permite diagnosticar nem prescrever tratamento individual.

## 7. Campos que o integrador deve tornar obrigatórios

Para estes exercícios, além do schema geral da missão, recomendo:

| Campo | Regra |
|---|---|
| `forearm_rotation_start` | obrigatório em pronação, supinação, flexão/extensão e desvios |
| `elbow_angle_context` | obrigatório em pronação e supinação |
| `wrist_position_context` | obrigatório em todos |
| `lever_length` | obrigatório quando existe martelo, alavanca ou halter excêntrico |
| `load_line_relative_to_axis` | obrigatório para cabo, banda e resistência manual |
| `grip_requirement` | `none`, `light`, `moderate`, `high` |
| `forearm_support` | `supported`, `unsupported`, `mounted_device` |
| `band_geometry` | obrigatório para extensão dos dedos |
| `wrist_roller_direction` | obrigatório no rolo de punho |
| `digit_scope` | obrigatório em todos os exercícios digitais |
| `thumb_involvement` | obrigatório quando o polegar toca ou move resistência |
| `specialist_gate` | obrigatório nas quatro tarefas distais isoladas |

## 8. Lista de fontes

### Base canónica e anatomia

1. EveFit Muscular Knowledge Base v0.1.1, ficheiros locais `muscles.jsonl`, `muscle_action_relations.csv`, `joints.json`, `joint_actions.json` e `EXERCISE_LINKING_SPEC.md`.
2. Mitchell B, Whited L. *Anatomy, Shoulder and Upper Limb, Forearm Muscles*. StatPearls, 2023. URL: https://www.ncbi.nlm.nih.gov/books/NBK536975/
3. Dawson-Amoah K, Varacallo M. *Anatomy, Shoulder and Upper Limb, Hand Intrinsic Muscles*. StatPearls, 2023. URL: https://www.ncbi.nlm.nih.gov/books/NBK539810/

### Pronação e supinação

4. Gordon KD, Pardo RD, Johnson JA, King GJW, Miller TA. Electromyographic activity and strength during maximum isometric pronation and supination efforts in healthy adults. *Journal of Orthopaedic Research*. 2004;22(1):208-213. PMID: 14656682. DOI: https://doi.org/10.1016/S0736-0266(03)00115-3
5. O'Sullivan LW, Gallwey TJ. Upper-limb surface electro-myography at maximum supination and pronation torques: the effect of elbow and forearm angle. *Journal of Electromyography and Kinesiology*. 2002;12(4):275-285. PMID: 12121684. DOI: https://doi.org/10.1016/S1050-6411(02)00014-7
6. Bader J, Boland MR, Greybe D, Nitz A, Uhl T, Pienkowski D. Muscle activity during maximal isometric forearm rotation using a power grip. *Journal of Biomechanics*. 2018;68:24-32. PMID: 29305049. DOI: https://doi.org/10.1016/j.jbiomech.2017.12.011
7. Buchanan TS, Rovai GP, Rymer WZ. Strategies for muscle activation during isometric torque generation at the human elbow. *Journal of Neurophysiology*. 1989;62(6):1201-1212. PMID: 2600619. DOI: https://doi.org/10.1152/jn.1989.62.6.1201
8. Murray WM, Delp SL, Buchanan TS. Variation of muscle moment arms with elbow and forearm position. *Journal of Biomechanics*. 1995;28(5):513-525. PMID: 7775488. DOI: https://doi.org/10.1016/0021-9290(94)00114-J

### Punho

9. Forman DA, Forman GN, Avila-Mireles EJ, et al. Characterizing forearm muscle activity in young adults during dynamic wrist flexion-extension movement using a wrist robot. *Journal of Biomechanics*. 2020;108:109908. PMID: 32636014. DOI: https://doi.org/10.1016/j.jbiomech.2020.109908
10. Forman DA, Forman GN, Avila-Mireles EJ, et al. Characterizing forearm muscle activity in university-aged males during dynamic radial-ulnar deviation of the wrist using a wrist robot. *Journal of Biomechanics*. 2020;108:109897. PMID: 32636008. DOI: https://doi.org/10.1016/j.jbiomech.2020.109897
11. Forman DA, Forman GN, Robathan J, Holmes MWR. The influence of simultaneous handgrip and wrist force on forearm muscle activity. *Journal of Electromyography and Kinesiology*. 2019;45:53-60. PMID: 30822679. DOI: https://doi.org/10.1016/j.jelekin.2019.02.004
12. Ikeda K, Kaneoka K, Matsunaga N, et al. Effects of forearm rotation on wrist flexor and extensor muscle activities. *Journal of Orthopaedic Surgery and Research*. 2025;20:53. PMID: 39819577. DOI: https://doi.org/10.1186/s13018-024-05363-x
13. Werner FW, Short WH, Palmer AK, Sutton LG. Wrist tendon forces during various dynamic wrist motions. *Journal of Hand Surgery*. 2010;35(4):628-632. PMID: 20353863. DOI: https://doi.org/10.1016/j.jhsa.2010.01.006
14. Shah DS, Middleton C, Gurdezi S, Horwitz MD, Kedgley AE. The effects of wrist motion and hand orientation on muscle forces: a physiologic wrist simulator study. *Journal of Biomechanics*. 2017;60. PMID: 28669547. DOI: https://doi.org/10.1016/j.jbiomech.2017.06.017
15. Li ZM, Kuxhaus L, Fisk JA, Christophel TH. Coupling between wrist flexion-extension and radial-ulnar deviation. *Clinical Biomechanics*. 2005;20(2):177-183. PMID: 15621323. DOI: https://doi.org/10.1016/j.clinbiomech.2004.10.002
16. Mogk JPM, Keir PJ. Prediction of forearm muscle activity during gripping. *Ergonomics*. 2006;49(11):1121-1130. PMID: 16950725. DOI: https://doi.org/10.1080/00140130600777433

### Dedos e polegar

17. Yang TH, Lu SC, Lin WJ, et al. Assessing Finger Joint Biomechanics by Applying Equal Force to Flexor Tendons In Vitro Using a Novel Simultaneous Approach. *PLOS ONE*. 2016;11:e0160301. PMID: 27513744. DOI: https://doi.org/10.1371/journal.pone.0160301
18. Li ZM, Zatsiorsky VM, Latash ML. The effect of finger extensor mechanism on the flexor force during isometric tasks. *Journal of Biomechanics*. 2001;34(8):1097-1102. PMID: 11448702. DOI: https://doi.org/10.1016/S0021-9290(01)00061-6
19. Smutz WP, Kongsayreepong A, Hughes RE, et al. Mechanical advantage of the thumb muscles. *Journal of Biomechanics*. 1998;31(6):565-570. PMID: 9755041. DOI: https://doi.org/10.1016/S0021-9290(98)00043-8
20. Johanson ME, Skinner SR, Lamoreux LW. Forearm muscle activation during power grip and release. *Journal of Hand Surgery*. 1998. PMID: 9763276. URL: https://pubmed.ncbi.nlm.nih.gov/9763276/

### Segurança mecânica

21. Keir PJ, Wells RP, Ranney DA, Lavery W. The effects of tendon load and posture on carpal tunnel pressure. *Journal of Hand Surgery*. 1997;22(4):628-634. PMID: 9260617. DOI: https://doi.org/10.1016/S0363-5023(97)80119-0
22. Keir PJ, Bach JM, Rempel DM. Effects of finger posture on carpal tunnel pressure during wrist motion. *Journal of Hand Surgery*. 1998;23(6):1004-1009. PMID: 9848550. DOI: https://doi.org/10.1016/S0363-5023(98)80007-5
23. Rempel D, Bach JM, Gordon L, So Y. Effects of forearm pronation/supination on carpal tunnel pressure. *Journal of Hand Surgery*. 1998;23(1):38-42. PMID: 9523952. DOI: https://doi.org/10.1016/S0363-5023(98)80086-5
24. Rempel D, Keir PJ, Smutz WP, Hargens A. Effects of static fingertip loading on carpal tunnel pressure. *Journal of Orthopaedic Research*. 1997;15(3):422-426. PMID: 9246089. DOI: https://doi.org/10.1002/jor.1100150315

## 9. Limitações

- A maior parte da evidência é anatómica, biomecânica, cadavérica ou EMG. Não existem comparações longitudinais suficientes para afirmar superioridade de um implemento para hipertrofia ou força geral.
- EMG com power grip inclui coativação necessária para estabilização. Não deve ser interpretada como nova ação muscular.
- A direção exata da resistência em cabos e bandas pode alterar muito o momento externo; o nome do equipamento não basta.
- O punho tem movimento acoplado. As etiquetas de flexão, extensão e desvios são objetivos dominantes, não movimentos perfeitamente puros.
- Exercícios digitais compostos não isolam FDS, FDP, intrínsecos ou longos extensores.
- O relatório não cobre hangs, carries, plate pinch, fat grip, grippers ou suportes como catálogo principal. Esses pertencem à Equipa 4, embora os flexores longos e extensores do punho devam ser ligados como músculos relevantes.

## 10. Entrega ao integrador

**Exercícios canónicos públicos propostos:** 9  
**Entradas internas ou especialista propostas:** 4  
**Variantes ou configurações avaliadas:** halter, barra, martelo/alavanca, cabo, banda, manual, isométrica, atrás do corpo, unilateral/bilateral e direção do rolo  
**Alterações propostas à base muscular:** 0  
**Findings para fila de revisão da base:** 1 erro de metadados de fonte, `FOREARM-SOURCE-001`  
**Implementação na EveFit:** 0
