# Relatório final e cobertura

## Resumo executivo

Foram investigados 133 candidatos: 36 exercícios canónicos, 85 variantes e 12 duplicados/exclusões. A camada pública contém 35 exercícios.

| Resultado | Número |
|---|---:|
| Candidatos investigados | 133 |
| Exercícios canónicos | 36 |
| Variantes | 85 |
| Duplicados/exclusões | 12 |
| Famílias | 15 |
| Equipamentos | 33 |
| Relações com músculos | 228 |
| Relações com articulações | 86 |
| Relações com ações | 68 |
| Exercícios públicos | 35 |
| Exercícios `approved_with_limits` | 6 |
| Exercícios `specialist_review` | 1 |

## Cobertura por estado

| Estado | Número |
|---|---:|
| `approved_public` | 29 |
| `approved_with_limits` | 6 |
| `specialist_review` | 1 |

## Cobertura por família

| Família | Número |
|---|---:|
| `digital_flexion_extension` | 2 |
| `elbow_extension_compound` | 4 |
| `elbow_extension_local` | 7 |
| `elbow_flexion_neutral` | 1 |
| `elbow_flexion_pronated` | 1 |
| `elbow_flexion_supinated` | 6 |
| `forearm_rotation` | 2 |
| `grip_dynamic` | 1 |
| `grip_isometric` | 2 |
| `loaded_carry` | 2 |
| `suspension_support` | 1 |
| `thumb_specific` | 1 |
| `upper_limb_support` | 1 |
| `wrist_deviation` | 2 |
| `wrist_flexion_extension` | 3 |

## Cobertura por equipamento

| Equipamento | Número |
|---|---:|
| `adjustable_pulley` | 6 |
| `bodyweight` | 15 |
| `cable_stack` | 22 |
| `carry_object` | 1 |
| `dumbbell` | 34 |
| `elastic_band` | 16 |
| `ez_bar` | 11 |
| `fat_grip` | 2 |
| `flat_bench` | 15 |
| `hand_gripper` | 3 |
| `high_pulley` | 4 |
| `incline_bench` | 5 |
| `kettlebell` | 2 |
| `lever_hammer` | 6 |
| `low_pulley` | 8 |
| `manual_resistance` | 3 |
| `parallel_bars` | 5 |
| `plate_loaded_curl_machine` | 1 |
| `plate_loaded_triceps_machine` | 2 |
| `preacher_bench` | 4 |
| `pull_up_bar` | 7 |
| `rings` | 5 |
| `rope_attachment` | 6 |
| `selectorized_curl_machine` | 3 |
| `selectorized_triceps_machine` | 2 |
| `single_handle` | 10 |
| `soft_ball` | 1 |
| `straight_bar_attachment` | 4 |
| `straight_barbell` | 15 |
| `suspension_trainer` | 2 |
| `towel` | 2 |
| `weight_plate` | 5 |
| `wrist_roller` | 3 |

## Cobertura muscular

| Músculo | Número |
|---|---:|
| `abductor_pollicis_brevis` | 1 |
| `abductor_pollicis_longus` | 1 |
| `adductor_pollicis` | 6 |
| `anconeus` | 12 |
| `biceps_brachii` | 21 |
| `brachialis` | 8 |
| `brachioradialis` | 10 |
| `deltoid` | 4 |
| `dorsal_interosseous_hand_1` | 1 |
| `extensor_carpi_radialis_brevis` | 27 |
| `extensor_carpi_radialis_longus` | 4 |
| `extensor_carpi_ulnaris` | 9 |
| `extensor_digiti_minimi` | 1 |
| `extensor_digitorum` | 2 |
| `extensor_indicis` | 1 |
| `external_oblique` | 2 |
| `flexor_carpi_radialis` | 4 |
| `flexor_carpi_ulnaris` | 3 |
| `flexor_digitorum_profundus` | 17 |
| `flexor_digitorum_superficialis` | 16 |
| `flexor_pollicis_brevis` | 2 |
| `flexor_pollicis_longus` | 7 |
| `latissimus_dorsi` | 3 |
| `lumbrical_hand_1` | 1 |
| `opponens_pollicis` | 1 |
| `palmaris_longus` | 1 |
| `pectoralis_major` | 4 |
| `pectoralis_minor` | 1 |
| `pronator_quadratus` | 1 |
| `pronator_teres` | 1 |
| `serratus_anterior` | 5 |
| `supinator` | 1 |
| `trapezius` | 5 |
| `triceps_brachii` | 45 |

## Candidatos excluídos

| Classificação | Número |
|---|---:|
| `duplicate` | 5 |
| `excluded` | 7 |

## Controvérsias e limites

- Ênfase entre cabeças do bicípite não foi convertida em promessa pública.
- A posição acima da cabeça no tricípite tem evidência longitudinal específica, mas não autoriza isolamento.
- EMG serve como evidência aguda limitada, não como preditor validado de hipertrofia.
- Perfis de máquinas permanecem dependentes da geometria concreta.
- Grip pode ser limitado por fricção, contacto, pele, punho e estabilidade proximal, além da força muscular.

## Lacunas restantes

- O `coracobrachialis` não recebe relação direta porque as suas ações pertencem ao ombro e não existe justificação específica da tarefa neste catálogo.
- Perfis concretos de máquinas aguardam uma ontologia de came, eixo e trajetória.
- A oposição resistida do polegar permanece em `specialist_review`.
- O PMID incorreto de Murray na base v0.1.1 foi reportado, mas a base permaneceu imutável.

## Decisões e auditorias

As decisões de identidade estão fechadas no `DECISION_LOG.md`. As validações internas e externas passaram sem falhas; as auditorias independentes são preservadas em `_coordination`.

## Recomendação

Auditar este pacote e só depois criar uma missão de implementação que transforme canónicos e variantes numa UI, preservando estados, proveniência e relações.
