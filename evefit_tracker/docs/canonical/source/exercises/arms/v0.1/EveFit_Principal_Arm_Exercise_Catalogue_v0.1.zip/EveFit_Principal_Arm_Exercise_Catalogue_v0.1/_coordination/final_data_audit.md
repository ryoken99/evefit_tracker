# Auditoria final independente de dados

## Resultado

**PASS**

Pacote auditado:

`_arm_catalogue_workspace/test_build8/EveFit_Principal_Arm_Exercise_Catalogue_v0.1`

ZIP auditado:

`_arm_catalogue_workspace/test_build8/EveFit_Principal_Arm_Exercise_Catalogue_v0.1.zip`

SHA-256 do ZIP auditado:

`a6a0f5982cfba6c33686be0f2105105ae39a2f479550ba44764b463e638644c0`

Blockers estruturais: **nenhum**.

O pacote, o ZIP, a base muscular, o gerador e o validador foram apenas lidos.

## Verificações executadas

- Validador externo: 9 033 verificações, zero falhas.
- Validação interna registada no pacote: 6 214 verificações, zero falhas.
- Auditoria independente adicional: 12 636 asserções, zero falhas.
- CRC integral do ZIP: `PASS`.
- Manifest, somas SHA-256, inventários e bytes do ZIP: `PASS`.
- Auditorias anatómica e pública preservadas no pacote: `PASS`.

A prova final de duas construções byte a byte não foi executada nesta etapa por
instrução do integrador. Deve ser executada depois de este relatório ficar
congelado e ser incorporado na construção final. Isto não constitui blocker
estrutural do alvo auditado.

## Schemas

- Existem 14 schemas no draft JSON Schema 2020-12.
- Os 11 exports obrigatórios, os dois ledgers e o manifest possuem schema.
- Todos os schemas são JSON válido e declaram versão, tipo e campos
  obrigatórios.
- Todos os registos possuem os campos obrigatórios do schema correspondente.
- O schema de relações musculares inclui:
  - `role_scope`;
  - `grip_role_default`;
  - `grip_limiter_default`;
  - `grip_limiter_observed`.
- O schema público inclui `potential_grip_limiters`.
- Os domínios dos campos de preensão são válidos em todas as 228 relações
  musculares.
- Nenhum resultado individual de limitação foi inventado:
  `grip_limiter_observed` permanece `unknown`.

## IDs e referências

- IDs de exercícios, variantes, famílias, equipamentos, fontes, claims e
  relações são canónicos em snake_case.
- Não existem IDs duplicados dentro das respetivas entidades.
- Os IDs relacionais são globalmente únicos entre os seis exports de relações.
- Todos os exercícios resolvem para famílias, equipamentos, articulações,
  ações e fontes existentes.
- As 228 relações musculares resolvem para músculos da base v0.1.1.
- Cada `component_id` pertence ao `muscle_id` declarado.
- As 86 relações articulares resolvem contra a base v0.1.1.
- As 68 relações de ação resolvem contra a base v0.1.1.
- As 91 relações de equipamento resolvem contra a taxonomia do catálogo.
- Os conjuntos de articulações, ações e equipamentos derivados coincidem com
  os campos declarados em cada exercício.
- Não existem relações órfãs.

## Variantes, pais e equipamentos

- Existem 85 variantes com exercício pai válido.
- As variantes estão particionadas sem sobreposição:
  - 78 relações de equivalência;
  - 7 relações de progressão ou regressão.
- A união das duas relações cobre exatamente as 85 variantes.
- O `exercise_id` de cada relação coincide com o `parent_exercise_id` da
  variante.
- Os 33 equipamentos têm IDs únicos e são usados por pelo menos um exercício
  ou variante.
- Os equipamentos obrigatórios, opcionais e alternativos são disjuntos por
  exercício.
- O export relacional reproduz exatamente o tipo de cada ligação a
  equipamento.

## Claims e fontes

Existem 545 claims:

| Alvo | Claims |
|---|---:|
| Relações musculares | 228 |
| Relações articulares | 86 |
| Relações de ação | 68 |
| Relações de equipamento | 91 |
| Exercícios | 72 |
| Total | 545 |

- Existe exatamente um claim por cada uma das 473 relações musculares,
  articulares, de ação e de equipamento.
- Existem exatamente dois claims ao nível de cada um dos 36 exercícios.
- Cada claim relacional aponta para uma relação existente.
- `exercise_id` e `target_id` são compatíveis com a relação afetada.
- As fontes do claim relacional coincidem com as fontes da relação.
- Todos os IDs de fonte resolvem no `SOURCE_LEDGER.csv`.
- Nenhum claim importante depende apenas de `src_technical_inference`.
- A contagem de fontes permanece em 24.

## Projeção pública de preensão

- `primary_muscles` coincide exatamente com relações `primary` e
  `primary_contextual`.
- `potential_grip_limiters` coincide exatamente com relações em que:
  - `grip_role_default = potential_limiter`;
  - `grip_limiter_default` é `likely` ou `possible`.
- Uma relação cujo papel é apenas `grip_limiter` não é promovida
  automaticamente a músculo principal.
- Um músculo que seja alvo real da tarefa pode também aparecer como potencial
  limitador, sem perder a distinção entre os dois campos.
- A projeção pública contém 35 IDs únicos e coincide com os estados públicos
  elegíveis.

No apoio isométrico nas paralelas:

- o flexor profundo dos dedos é `stabilizer`;
- o flexor superficial dos dedos é `stabilizer`;
- ambos têm `grip_role_default = stabilizer`;
- ambos têm `grip_limiter_default = unlikely`;
- nenhum aparece em `primary_muscles`;
- nenhum aparece em `potential_grip_limiters`.

## Contagens confirmadas

| Entidade | Número |
|---|---:|
| Candidatos investigados | 133 |
| Exercícios canónicos | 36 |
| Variantes | 85 |
| Duplicados ou exclusões | 12 |
| Famílias | 15 |
| Equipamentos | 33 |
| Exercícios públicos | 35 |
| `approved_public` | 29 |
| `approved_with_limits` | 6 |
| `specialist_review` | 1 |
| Relações musculares | 228 |
| Relações articulares | 86 |
| Relações de ação | 68 |
| Relações de equipamento | 91 |
| Relações de equivalência | 78 |
| Relações de progressão/regressão | 7 |
| Claims | 545 |
| Fontes | 24 |

As contagens dos exports, do `MANIFEST.json`, do README e dos relatórios
coincidem.

## Manifest, SHA256SUMS e ZIP

- A árvore auditada contém 60 ficheiros.
- O manifest enumera exatamente 58 ficheiros de payload, excluindo apenas o
  próprio manifest e `SHA256SUMS.txt`.
- Tamanhos e SHA-256 dos 58 ficheiros coincidem com o manifest.
- `SHA256SUMS.txt` contém exatamente 59 entradas, todos os ficheiros exceto o
  próprio ficheiro de somas.
- Todos os hashes de `SHA256SUMS.txt` são válidos.
- O ZIP contém exatamente 60 entradas.
- Não existem entradas duplicadas.
- A ordem das entradas é determinística.
- Cada entrada do ZIP é byte a byte igual ao ficheiro correspondente da árvore.
- Os timestamps estão fixos em `2026-07-30 00:00:00`.
- O modo dos ficheiros no ZIP é `0644`.
- O teste CRC não encontrou corrupção.

## Base canónica e ausência de alterações

SHA-256 confirmado do ZIP da base v0.1.1:

`a1876a1d4bc21ab54b3828774f66a99519a4953dc00191e69475d8c15b8b30b0`

Digest independente confirmado da árvore da base:

`3b5259d471551e52e44ec99d564cdde9e7a57c37fc213f9be112d2366755633f`

Os valores são iguais aos registados antes das reconstruções e reauditorias.
A base muscular permaneceu imutável.

Não foram encontrados ficheiros Flutter, migrations, base de dados, UI ou
release no pacote. Dentro do âmbito auditável, não houve implementação nem
alteração à aplicação EveFit.

## Ausência de regressões

- Os exports estruturados de `test_build8` são byte a byte iguais aos exports
  estruturados aprovados no alvo provisório `test_build7`.
- As diferenças entre esses alvos limitam-se ao gerador incorporado, relatórios
  finais, manifest e ficheiro de somas.
- As auditorias anatómica e pública agora preservadas no pacote estão em
  `PASS`.
- A correção da projeção de preensão não alterou pais de variantes, taxonomia de
  equipamentos, IDs da base, estados públicos ou número de exercícios.

## Conclusão

O alvo `test_build8` passa a auditoria estrutural independente de schemas, IDs,
referências, variantes-pai, equipamentos, claims atómicas, projeção pública de
preensão, suporte em paralelas, fontes, contagens, manifest, SHA256SUMS, CRC,
integridade do ZIP e imutabilidade da base.

Estado final desta auditoria: **PASS**, sem blockers estruturais.
