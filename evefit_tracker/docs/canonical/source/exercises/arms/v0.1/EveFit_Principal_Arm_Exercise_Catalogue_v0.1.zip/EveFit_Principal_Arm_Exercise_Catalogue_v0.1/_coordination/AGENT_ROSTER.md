# Registo de equipas

- Flexão do cotovelo: investigação independente e integração.
- Extensão do cotovelo: investigação independente e integração.
- Antebraço e punho: investigação independente e integração.
- Preensão, carries e suportes: investigação independente e integração.
- Identidade e equipamentos: crítica transversal.
- Evidência e segurança: crítica transversal.
- Auditoria final: anatomia, biomecânica/dados e PT-PT.

Os relatórios independentes foram preservados nesta pasta. Os achados críticos foram corrigidos ou escalados no pacote final.
