# Âmbito e completude

## Incluído

- Flexão do cotovelo em supinação, posição neutra e pronação.
- Extensão do cotovelo local e multiarticular.
- Pronação e supinação resistidas.
- Flexão, extensão e desvios do punho.
- Flexão e extensão dos dedos.
- Preensão crush, support, pinch e open-hand.
- Hangs, suportes e carries com papel relevante dos braços.

## Excluído

- Catálogo de peito, costas, ombros ou tronco.
- Marcas comerciais e geometrias de máquinas não documentadas.
- Séries, repetições, carga, cadência, RPE, RIR, 21s, drop sets e AMRAP.
- Prescrição clínica ou individual.
- Implementação Flutter, base de dados, migrations, UI e release.

## Músculo prioritário sem relação direta

O `coracobrachialis` foi auditado, mas não recebeu uma relação artificial neste
catálogo. As suas ações diretas pertencem à articulação glenoumeral, sobretudo
flexão e adução do ombro, e não existe no núcleo um exercício de braço em que a
evidência disponível justifique promovê-lo a alvo principal, secundário ou
estabilizador específico. A cobertura direta fica deferida para um futuro catálogo
de ombro; esta decisão evita usar uma função anatómica geral como prova de
participação relevante numa tarefa concreta.

O núcleo contém 36 exercícios canónicos. Fica abaixo da meta indicativa de 40 porque hand gripper/bola foram unificados, pega espessa e towel hang passaram a variantes de interface, e o transporte em pinça passou a variante da pinça isométrica. A cobertura continua completa dentro do âmbito sem preencher uma quota com microvariações.
