# Política de identidade dos exercícios

Cria-se um exercício canónico apenas quando muda materialmente pelo menos um dos seguintes elementos: ação articular, posição relevante do ombro/antebraço, cadeia cinética, trajetória, perfil de resistência, segmento fixo, aplicação de força, estabilidade ou objetivo técnico.

Não criam identidade nova: carga, séries, repetições, velocidade, cadência, descanso, RPE, RIR, lado, pequenas larguras de pega, marca de máquina ou protocolo.

## Regras

1. O canónico representa a tarefa mecânica.
2. O equipamento é variante quando preserva a tarefa, mesmo que altere o perfil de resistência.
3. A variante deve ter pai, alteração e justificação explícitos.
4. Uma máquina só entra com limites quando a sua geometria não é universal.
5. Exercícios multiarticulares mantêm identidade própria e os músculos do braço recebem papéis contextuais.
