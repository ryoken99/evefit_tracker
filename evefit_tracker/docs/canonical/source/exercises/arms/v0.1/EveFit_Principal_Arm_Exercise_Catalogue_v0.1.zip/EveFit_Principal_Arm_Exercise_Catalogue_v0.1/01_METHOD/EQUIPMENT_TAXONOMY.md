# Taxonomia de equipamento

| ID | Nome PT-PT | Tipo |
|---|---|---|
| `bodyweight` | Peso corporal | `resistance` |
| `straight_barbell` | Barra reta | `free_weight` |
| `ez_bar` | Barra EZ | `free_weight` |
| `dumbbell` | Halter | `free_weight` |
| `kettlebell` | Kettlebell | `free_weight` |
| `cable_stack` | Coluna de cabos | `cable` |
| `high_pulley` | Polia alta | `anchor` |
| `low_pulley` | Polia baixa | `anchor` |
| `adjustable_pulley` | Polia ajustável | `anchor` |
| `rope_attachment` | Corda para polia | `attachment` |
| `straight_bar_attachment` | Barra reta para polia | `attachment` |
| `single_handle` | Pega unilateral | `attachment` |
| `elastic_band` | Banda elástica | `elastic` |
| `selectorized_curl_machine` | Máquina de curl com pesos selecionados | `machine` |
| `plate_loaded_curl_machine` | Máquina de curl com discos | `machine` |
| `selectorized_triceps_machine` | Máquina de tríceps com pesos selecionados | `machine` |
| `plate_loaded_triceps_machine` | Máquina de tríceps com discos | `machine` |
| `preacher_bench` | Banco Scott | `support` |
| `flat_bench` | Banco plano | `support` |
| `incline_bench` | Banco inclinado | `support` |
| `pull_up_bar` | Barra fixa | `support` |
| `parallel_bars` | Paralelas | `support` |
| `rings` | Argolas | `suspension` |
| `suspension_trainer` | Sistema de suspensão | `suspension` |
| `weight_plate` | Disco | `free_weight` |
| `towel` | Toalha | `attachment` |
| `fat_grip` | Adaptador de pega espessa | `attachment` |
| `hand_gripper` | Hand gripper | `grip_tool` |
| `wrist_roller` | Rolo de punho | `grip_tool` |
| `lever_hammer` | Martelo ou alavanca | `lever` |
| `carry_object` | Objeto de transporte | `free_weight` |
| `manual_resistance` | Resistência manual | `manual` |
| `soft_ball` | Bola macia de preensão | `grip_tool` |

Equipamento obrigatório significa a manifestação base da ficha canónica. As variantes podem substituir esse conjunto por outro implemento explicitamente ligado.
