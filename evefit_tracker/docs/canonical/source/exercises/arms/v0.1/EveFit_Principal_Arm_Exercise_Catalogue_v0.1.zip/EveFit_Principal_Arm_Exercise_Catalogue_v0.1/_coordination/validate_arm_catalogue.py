#!/usr/bin/env python3
"""Independent structural validator for the EveFit arm exercise catalogue."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def read_csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def validate(package: Path, base: Path) -> dict:
    export = package / "13_EXPORTS"
    base_export = base / "13_EXPORTS"
    checks = 0
    failures: list[str] = []

    def check(condition: bool, message: str) -> None:
        nonlocal checks
        checks += 1
        if not condition:
            failures.append(message)

    exercises = read_jsonl(export / "exercises.jsonl")
    variants = read_jsonl(export / "exercise_variants.jsonl")
    families = json.loads((export / "exercise_families.json").read_text(encoding="utf-8"))
    equipment = json.loads((export / "equipment.json").read_text(encoding="utf-8"))
    public = json.loads((export / "public_arm_exercises.json").read_text(encoding="utf-8"))
    muscle_rel = read_csv(export / "exercise_muscle_relations.csv")
    joint_rel = read_csv(export / "exercise_joint_relations.csv")
    action_rel = read_csv(export / "exercise_action_relations.csv")
    equipment_rel = read_csv(export / "exercise_equipment_relations.csv")
    progression_rel = read_csv(export / "exercise_progression_relations.csv")
    equivalence_rel = read_csv(export / "exercise_equivalence_relations.csv")
    claims = read_csv(package / "11_EVIDENCE" / "CLAIMS_LEDGER.csv")
    sources = read_csv(package / "11_EVIDENCE" / "SOURCE_LEDGER.csv")

    base_muscles = {}
    for row in read_jsonl(base_export / "muscles.jsonl"):
        base_muscles[row["canonical_id"]] = row
    base_components = {
        row["canonical_id"]: row["parent_muscle_id"]
        for row in read_jsonl(base_export / "muscle_components.jsonl")
    }
    base_joints = {
        row["canonical_id"]
        for row in json.loads((base_export / "joints.json").read_text(encoding="utf-8"))
    }
    base_actions = {
        row["canonical_id"]
        for filename in ("joint_actions.json", "functional_actions.json")
        for row in json.loads((base_export / filename).read_text(encoding="utf-8"))
    }
    base_muscle_actions: dict[str, set[str]] = {}
    for row in read_csv(base_export / "muscle_action_relations.csv"):
        base_muscle_actions.setdefault(row["muscle_id"], set()).add(row["action_id"])

    schemas = {}
    for path in sorted((export / "schemas").glob("*.schema.json")):
        schemas[path.name] = json.loads(path.read_text(encoding="utf-8"))
        check(bool(schemas[path.name].get("$schema")), f"Schema sem versão: {path.name}")

    ex_ids = [row["exercise_id"] for row in exercises]
    variant_ids = [row["variant_id"] for row in variants]
    family_ids = {row["family_id"] for row in families}
    equipment_ids = {row["equipment_id"] for row in equipment}
    source_ids = {row["source_id"] for row in sources}
    relation_ids = {
        row["relation_id"]
        for rows in (muscle_rel, joint_rel, action_rel, equipment_rel)
        for row in rows
    }
    check(len(ex_ids) == 36, f"Esperados 36 exercícios canónicos após crítica de identidade, obtidos {len(ex_ids)}")
    check(len(ex_ids) == len(set(ex_ids)), "exercise_id duplicado")
    check(len(variant_ids) == len(set(variant_ids)), "variant_id duplicado")
    check(len(relation_ids) == len(muscle_rel) + len(joint_rel) + len(action_rel) + len(equipment_rel), "relation_id duplicado")
    base_zip = base.parent / f"{base.name}.zip"
    check(base_zip.exists(), "ZIP canónico v0.1.1 ausente")
    if base_zip.exists():
        check(sha256(base_zip) == "a1876a1d4bc21ab54b3828774f66a99519a4953dc00191e69475d8c15b8b30b0", "Base muscular v0.1.1 alterada")
    downclassified = {"hand_squeeze", "plate_pinch_carry", "thick_grip_hold", "towel_hang"}
    check(not (set(ex_ids) & downclassified), "Microvariante permaneceu como canónico")
    check(downclassified <= set(variant_ids), "Variante obrigatoriamente demovida ausente")

    required_exercise = set(schemas["exercises.schema.json"]["required"])
    required_variant = set(schemas["exercise_variants.schema.json"]["required"])
    for row in exercises:
        exid = row["exercise_id"]
        check(required_exercise <= set(row), f"Campos obrigatórios ausentes em {exid}")
        check(exid == exid.lower() and " " not in exid, f"ID não canónico: {exid}")
        check(row["family_id"] in family_ids, f"Família inválida em {exid}")
        check(row["status"] in {"approved_public", "approved_with_limits", "specialist_review", "internal_only", "duplicate", "excluded"}, f"Estado inválido em {exid}")
        check(bool(row["execution"]["cues"]) and bool(row["execution"]["common_errors"]), f"Execução incompleta em {exid}")
        check(bool(row["safety"]["general_cautions"]) and bool(row["safety"]["regressions"]), f"Segurança incompleta em {exid}")
        for joint in row["mechanics"]["joint_ids"]:
            check(joint in base_joints, f"Articulação fora da base em {exid}: {joint}")
        for action in row["mechanics"]["action_ids"]:
            check(action in base_actions, f"Ação fora da base em {exid}: {action}")
        for eq in row["equipment"]["required_ids"] + row["equipment"]["optional_ids"] + row["equipment"]["alternative_ids"]:
            check(eq in equipment_ids, f"Equipamento inválido em {exid}: {eq}")
        for source in row["source_ids"]:
            check(source in source_ids, f"Fonte inválida em {exid}: {source}")
        check(set(row["source_ids"]) != {"src_technical_inference"}, f"Inferência técnica isolada em {exid}")
        public_text = json.dumps(row, ensure_ascii=False).lower()
        check("isolamento absoluto" not in public_text, f"Isolamento absoluto em {exid}")
        check("garante hipertrofia" not in public_text, f"Promessa de hipertrofia em {exid}")

    for row in variants:
        check(required_variant <= set(row), f"Campos de variante ausentes em {row['variant_id']}")
        check(row["parent_exercise_id"] in set(ex_ids), f"Pai órfão em {row['variant_id']}")
        for eq in row["equipment_ids"]:
            check(eq in equipment_ids, f"Equipamento de variante inválido em {row['variant_id']}")
        for source in row["source_ids"]:
            check(source in source_ids, f"Fonte de variante inválida em {row['variant_id']}")

    primary_roles = {"primary", "primary_contextual", "specialist_review"}
    claims_by_relation = {row["affected_relation_id"] for row in claims if row["affected_relation_id"]}
    exercise_actions = {}
    for row in action_rel:
        exercise_actions.setdefault(row["exercise_id"], set()).add(row["action_id"])
    required_muscle_relation = set(schemas["exercise_muscle_relations.schema.json"]["required"])
    for row in muscle_rel:
        check(required_muscle_relation <= set(row), f"Campos musculares obrigatórios ausentes: {row['relation_id']}")
        check(row["exercise_id"] in set(ex_ids), f"Relação muscular órfã: {row['relation_id']}")
        check(row["muscle_id"] in base_muscles, f"Músculo inválido: {row['relation_id']}")
        check(not row["component_id"] or base_components.get(row["component_id"]) == row["muscle_id"], f"Componente inválido: {row['relation_id']}")
        check(bool(row["context"]) and bool(row["limitations"]), f"Contexto/limite ausente: {row['relation_id']}")
        check(row["grip_role_default"] in {"primary_target", "potential_limiter", "stabilizer", "not_applicable"}, f"Papel de preensão inválido: {row['relation_id']}")
        check(row["grip_limiter_default"] in {"likely", "possible", "unlikely", "not_applicable"}, f"Estado de limitação inválido: {row['relation_id']}")
        check(row["grip_limiter_observed"] == "unknown", f"Observação de série inventada: {row['relation_id']}")
        if row["role"] == "grip_limiter":
            check(row["role_scope"] == "default_potential_limiter_not_observed_series_outcome", f"Âmbito de grip_limiter inválido: {row['relation_id']}")
            check(row["grip_role_default"] == "potential_limiter", f"Grip limiter confundido com alvo: {row['relation_id']}")
        if row["role"] in primary_roles:
            check(row["relation_id"] in claims_by_relation, f"Papel principal sem claim: {row['relation_id']}")
            check(
                bool(exercise_actions.get(row["exercise_id"], set()) & base_muscle_actions.get(row["muscle_id"], set())),
                f"Papel principal sem ação compatível na base: {row['relation_id']}",
            )
        for source in row["source_ids"].split(";"):
            check(source in source_ids, f"Fonte muscular inválida: {row['relation_id']}")

    for row in joint_rel:
        check(row["exercise_id"] in set(ex_ids), f"Relação articular órfã: {row['relation_id']}")
        check(row["joint_id"] in base_joints, f"Articulação inválida: {row['relation_id']}")
    for row in action_rel:
        check(row["exercise_id"] in set(ex_ids), f"Relação de ação órfã: {row['relation_id']}")
        check(row["action_id"] in base_actions, f"Ação inválida: {row['relation_id']}")
    for row in equipment_rel:
        check(row["exercise_id"] in set(ex_ids), f"Relação de equipamento órfã: {row['relation_id']}")
        check(row["equipment_id"] in equipment_ids, f"Equipamento inválido: {row['relation_id']}")
    for row in progression_rel:
        check(row["exercise_id"] in set(ex_ids), f"Progressão órfã: {row['relation_id']}")
        check(row["variant_id"] in set(variant_ids), f"Variante de progressão inválida: {row['relation_id']}")
    for row in equivalence_rel:
        check(row["exercise_id"] in set(ex_ids), f"Equivalência órfã: {row['relation_id']}")
        check(row["variant_id"] in set(variant_ids), f"Variante de equivalência inválida: {row['relation_id']}")

    for row in claims:
        check(row["exercise_id"] in set(ex_ids), f"Claim órfã: {row['claim_id']}")
        check(not row["affected_relation_id"] or row["affected_relation_id"] in relation_ids, f"Claim aponta para relação inválida: {row['claim_id']}")
        for source in row["source_ids"].split(";"):
            check(source in source_ids, f"Fonte de claim inválida: {row['claim_id']}")
        check(row["source_ids"] != "src_technical_inference", f"Claim importante só com inferência técnica: {row['claim_id']}")
        if "hypertrophy" in row["claim_summary"].lower() or "hipertrofia" in row["claim_summary"].lower():
            check("src_maeo_triceps_2023" in row["source_ids"], f"Claim de hipertrofia sem estudo longitudinal: {row['claim_id']}")

    public_ids = {row["exercise_id"] for row in public}
    eligible_ids = {
        row["exercise_id"]
        for row in exercises
        if row["public_eligible"] and row["status"] in {"approved_public", "approved_with_limits"}
    }
    check(public_ids == eligible_ids, "Camada pública não coincide com estados elegíveis")
    required_public = set(schemas["public_arm_exercises.schema.json"]["items"]["required"])
    for row in public:
        check(required_public <= set(row), f"Campos públicos obrigatórios ausentes: {row['exercise_id']}")
        check(bool(row["name"]) and bool(row["objective"]), f"Conteúdo público incompleto: {row['exercise_id']}")
        check(bool(row["instructions"]) and bool(row["common_errors"]) and bool(row["cautions"]), f"Ficha pública incompleta: {row['exercise_id']}")
        check(bool(row["environmental_controls"]), f"Controlos ambientais públicos ausentes: {row['exercise_id']}")
        if row["status"] == "approved_with_limits":
            check(bool(row["limit_reason"]), f"Razão do limite público ausente: {row['exercise_id']}")
            check(row["limit_reason"] in row["cautions"], f"Razão do limite não propagada para cautelas: {row['exercise_id']}")
        else:
            check(row["limit_reason"] == "", f"Razão de limite aplicada a estado público sem limites: {row['exercise_id']}")
        relation_subset = [
            rel
            for rel in muscle_rel
            if rel["exercise_id"] == row["exercise_id"] and not rel["component_id"]
        ]
        expected_primary = {
            base_muscles[rel["muscle_id"]]["names"]["pt_pt"]
            for rel in relation_subset
            if rel["role"] in {"primary", "primary_contextual"}
        }
        expected_limiters = {
            base_muscles[rel["muscle_id"]]["names"]["pt_pt"]
            for rel in relation_subset
            if rel["grip_role_default"] == "potential_limiter"
            and rel["grip_limiter_default"] in {"likely", "possible"}
        }
        non_target_limiters = {
            base_muscles[rel["muscle_id"]]["names"]["pt_pt"]
            for rel in relation_subset
            if rel["role"] == "grip_limiter"
        }
        check(set(row["primary_muscles"]) == expected_primary, f"Projeção pública de músculos principais incorreta: {row['exercise_id']}")
        check(set(row["potential_grip_limiters"]) == expected_limiters, f"Projeção pública de limitadores de preensão incorreta: {row['exercise_id']}")
        check(not (set(row["primary_muscles"]) & non_target_limiters), f"Grip limiter promovido a principal: {row['exercise_id']}")
        text = json.dumps(row, ensure_ascii=False).lower()
        for banned in ("pegada", "contração muscular isolada garantida", "sem risco"):
            check(banned not in text, f"Termo/alegação pública proibida em {row['exercise_id']}: {banned}")

    for exid in ex_ids:
        check(any(row["exercise_id"] == exid for row in muscle_rel), f"Sem relação muscular: {exid}")
        check(any(row["exercise_id"] == exid for row in joint_rel), f"Sem relação articular: {exid}")
        check(any(row["exercise_id"] == exid for row in action_rel), f"Sem relação de ação: {exid}")
        roles = {row["role"] for row in muscle_rel if row["exercise_id"] == exid}
        check(bool(roles & primary_roles), f"Sem papel principal/contextual: {exid}")

    exercise_by_id = {row["exercise_id"]: row for row in exercises}
    for exid in ("farmers_carry", "suitcase_carry"):
        check(exercise_by_id[exid]["mechanics"]["kinetic_chain"] == "mixed_chain", f"Carry sem cadeia mista: {exid}")
        check(bool(exercise_by_id[exid]["mechanics"].get("segment_chain_classification")), f"Carry sem classificação segmentar: {exid}")
    hang_joints = set(exercise_by_id["dead_hang"]["mechanics"]["joint_ids"])
    check({"glenohumeral_joint", "scapulothoracic_articulation", "elbow_joint", "radiocarpal_joint"} <= hang_joints, "Dead hang sem grafo proximal completo")
    check(exercise_by_id["dead_hang"]["status"] == "approved_with_limits", "Dead hang sem limites públicos")
    check(bool(exercise_by_id["dead_hang"]["mechanics"].get("hang_mode")), "Dead hang sem modo de suspensão")
    check(exercise_by_id["resisted_hand_close"]["family_id"] == "grip_dynamic", "Fecho da mão ainda classificado como isométrico")
    check("concentric" in exercise_by_id["resisted_hand_close"]["mechanics"].get("contraction_modes", []), "Fecho da mão sem fase dinâmica")
    check(exercise_by_id["parallel_bar_support_hold"]["family_id"] == "upper_limb_support", "Apoio nas paralelas contado como grip principal")
    for muscle_id in ("flexor_digitorum_profundus", "flexor_digitorum_superficialis"):
        support_hand = next(
            rel
            for rel in muscle_rel
            if rel["exercise_id"] == "parallel_bar_support_hold" and rel["muscle_id"] == muscle_id
        )
        check(support_hand["role"] == "stabilizer", f"Mão promovida no apoio em paralelas: {muscle_id}")
        check(support_hand["grip_role_default"] == "stabilizer", f"Papel de contacto ausente no apoio em paralelas: {muscle_id}")
        check(support_hand["grip_limiter_default"] == "unlikely", f"Limitação universal indevida no apoio em paralelas: {muscle_id}")
    for exid in ("machine_triceps_extension",):
        check(exercise_by_id[exid]["status"] == "approved_with_limits", f"Máquina genérica sem limites: {exid}")
    for exid in ("suspension_bodyweight_curl", "suspension_triceps_extension"):
        check(exercise_by_id[exid]["mechanics"]["kinetic_chain"] == "mixed_chain", f"Suspensão sem cadeia mista: {exid}")
        check(bool(exercise_by_id[exid]["mechanics"].get("segment_chain_classification")), f"Suspensão sem classificação por segmento: {exid}")
        check("geometricamente fixo" in exercise_by_id[exid]["mechanics"]["distal_fixed_segment"], f"Campo distal enganador em {exid}")
    for exid in ("parallel_bar_dip", "bench_dip"):
        profiles = exercise_by_id[exid]["mechanics"].get("action_phase_profiles", {})
        check(profiles.get("shoulder_extension", {}).get("contraction_mode") == "descent_under_eccentric_flexor_control", f"Fundos sem descida fásica: {exid}")
        check(profiles.get("shoulder_flexion", {}).get("contraction_mode") == "concentric_ascent_toward_neutral", f"Fundos sem subida fásica: {exid}")
        action_profiles = {
            rel["action_id"]: rel
            for rel in action_rel
            if rel["exercise_id"] == exid
        }
        check(action_profiles["shoulder_extension"]["contraction_mode"] == "descent_under_eccentric_flexor_control", f"CSV perde fase de descida: {exid}")
        check(action_profiles["shoulder_flexion"]["contraction_mode"] == "concentric_ascent_toward_neutral", f"CSV perde fase de subida: {exid}")
    suspension_lats = next(
        rel
        for rel in muscle_rel
        if rel["exercise_id"] == "suspension_bodyweight_curl" and rel["muscle_id"] == "latissimus_dorsi"
    )
    check(suspension_lats["role"] == "stabilizer", "Grande dorsal promovido sem ação glenoumeral no curl em suspensão")
    for exid in ("standing_supinated_curl", "shoulder_extended_supinated_curl", "preacher_curl", "spider_curl"):
        biceps = next(
            rel
            for rel in muscle_rel
            if rel["exercise_id"] == exid and rel["muscle_id"] == "biceps_brachii" and not rel["component_id"]
        )
        check(biceps["role"] == "primary_contextual" and biceps["confidence"] == "moderate_confidence", f"Bicípite sobrepromovido em {exid}")
    for rel in muscle_rel:
        if rel["component_id"].startswith("triceps_brachii_"):
            expected_emphasis = (
                "moderate_supported_emphasis"
                if rel["exercise_id"] == "overhead_triceps_extension"
                and rel["component_id"] == "triceps_brachii_long_head"
                else "insufficient_evidence"
            )
            check(rel["emphasis_evidence"] == expected_emphasis, f"Ênfase automática de cabeça do tricípite: {rel['relation_id']}")
    used_equipment = {
        eq
        for row in exercises
        for eq in row["equipment"]["required_ids"] + row["equipment"]["optional_ids"] + row["equipment"]["alternative_ids"]
    } | {eq for row in variants for eq in row["equipment_ids"]}
    check(used_equipment == equipment_ids, "Cobertura de equipamento incompleta")
    source_by_id = {row["source_id"]: row for row in sources}
    check(source_by_id["src_murray_elbow_1995"]["url"] == "https://pubmed.ncbi.nlm.nih.gov/7775488/", "Catálogo não usa o PMID corrigido de Murray")

    public_by_id = {row["exercise_id"]: row for row in public}
    environmental_expectations = {
        "dead_hang": ("ancoragem", "zona inferior", "entrar e sair"),
        "farmers_carry": ("percurso", "plano", "pousar"),
        "parallel_bar_support_hold": ("estabilidade das paralelas", "zona", "saída segura"),
        "plate_pinch_hold": ("zona inferior", "discos", "pessoas ou objetos"),
        "suitcase_carry": ("percurso", "plano", "pousar"),
        "support_grip_hold": ("zona inferior", "implemento", "pessoas ou objetos"),
    }
    for exid, expected_terms in environmental_expectations.items():
        controls = " ".join(public_by_id[exid]["environmental_controls"]).lower()
        for term in expected_terms:
            check(term in controls, f"Controlo ambiental público incompleto em {exid}: {term}")

    scope_path = package / "01_METHOD" / "SCOPE_AND_COMPLETENESS.md"
    if scope_path.exists():
        scope_text = " ".join(scope_path.read_text(encoding="utf-8").lower().split())
        check("coracobrachialis" in scope_text, "Ausência do coracobrachialis não documentada")
        check("catálogo de ombro" in scope_text, "Encaminhamento do coracobrachialis não documentado")
        check(not any(row["muscle_id"] == "coracobrachialis" for row in muscle_rel), "Coracobrachialis recebeu relação não sustentada")

    catalogue_dir = package / "03_CATALOGUES"
    if catalogue_dir.exists():
        for path in sorted(catalogue_dir.glob("*.md")):
            text = path.read_text(encoding="utf-8")
            check("., " not in text, f"Pontuação de lista inválida: {path.name}")
            check(".." not in text, f"Pontuação terminal duplicada: {path.name}")
            check(": ." not in text, f"Lista vazia mal representada: {path.name}")
            rendered_list_prefixes = (
                "- Músculos principais/contextuais:",
                "- Secundários/estabilizadores:",
                "- Possíveis limitadores de preensão:",
                "- Equipamento base:",
                "**Cues:**",
                "**Erros frequentes:**",
                "**Cautelas:**",
            )
            for line in text.splitlines():
                if line.startswith(rendered_list_prefixes):
                    check(not re.search(r", [A-ZÁÉÍÓÚÂÊÔÃÕÇ]", line), f"Capitalização de lista inválida: {path.name}")

    manifest = package / "MANIFEST.json"
    if manifest.exists():
        data = json.loads(manifest.read_text(encoding="utf-8"))
        for row in data["files"]:
            path = package / row["path"]
            check(path.exists(), f"Ficheiro do manifest ausente: {row['path']}")
            check(path.stat().st_size == row["size"], f"Tamanho divergente: {row['path']}")
            check(sha256(path) == row["sha256"], f"Hash divergente: {row['path']}")
    sums = package / "SHA256SUMS.txt"
    if sums.exists():
        for line in sums.read_text(encoding="utf-8").splitlines():
            digest, relative = line.split("  ", 1)
            path = package / relative
            check(path.exists(), f"Ficheiro de checksum ausente: {relative}")
            check(sha256(path) == digest, f"Checksum divergente: {relative}")

    return {
        "status": "PASS" if not failures else "FAIL",
        "checks": checks,
        "failures": failures,
        "counts": {
            "canonical_exercises": len(exercises),
            "variants": len(variants),
            "public_exercises": len(public),
            "muscle_relations": len(muscle_rel),
            "joint_relations": len(joint_rel),
            "action_relations": len(action_rel),
            "equipment_relations": len(equipment_rel),
            "claims": len(claims),
            "sources": len(sources),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("package", type=Path)
    parser.add_argument("base", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result = validate(args.package.resolve(), args.base.resolve())
    if args.json:
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    else:
        print(f"{result['status']}: {result['checks']} verificações")
        for failure in result["failures"]:
            print(f"- {failure}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
