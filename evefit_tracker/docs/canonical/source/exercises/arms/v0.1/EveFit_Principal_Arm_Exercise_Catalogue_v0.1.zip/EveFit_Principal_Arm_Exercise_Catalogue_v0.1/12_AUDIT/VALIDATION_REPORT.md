# Relatório de validação

| Camada | Verificações | Falhas | Estado |
|---|---:|---:|---|
| Construtor interno | 6214 | 0 | PASS |
| Validador externo | 9033 | 0 | PASS |

Validações cobrem IDs únicos, pais de variantes, equipamentos, músculos, componentes, articulações, ações, relações órfãs, compatibilidade músculo-ação, fases dos fundos, cadeia mista de pegas móveis, campos de preensão, projeção pública, claims de papéis principais, fontes, estados públicos, PT-PT, proibição de isolamento absoluto e proibição de inferência de hipertrofia baseada apenas em EMG.

Manifest, hashes, CRC e determinismo são verificados na fase de embalagem final.
