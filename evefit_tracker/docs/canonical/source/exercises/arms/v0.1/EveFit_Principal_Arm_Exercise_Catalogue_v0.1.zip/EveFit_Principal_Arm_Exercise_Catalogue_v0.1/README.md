# EveFit Principal Arm Exercise Catalogue v0.1

Catálogo canónico dos principais exercícios de braços, construído sobre a base muscular v0.1.1 imutável.

## Resultado

| Métrica | Valor |
|---|---:|
| Candidatos investigados | 133 |
| Exercícios canónicos | 36 |
| Variantes materializadas | 85 |
| Candidatos duplicados/excluídos | 12 |
| Famílias | 15 |
| Equipamentos | 33 |
| Exercícios públicos | 35 |
| Relações musculares | 228 |
| Relações articulares | 86 |
| Relações com ações | 68 |
| Claims | 545 |
| Fontes | 24 |

“Completo” significa cobertura dos principais exercícios reconhecidos e mecanicamente distintos para braços dentro do âmbito EveFit. Não significa todas as marcas, pegas, cargas, protocolos ou microvariações possíveis.

## Estado

| Estado | Número |
|---|---:|
| `approved_public` | 29 |
| `approved_with_limits` | 6 |
| `specialist_review` | 1 |

## Limites

- Não é prescrição individual nem aconselhamento clínico.
- Nenhuma relação implica isolamento muscular absoluto.
- EMG aguda não foi usada isoladamente para inferir hipertrofia.
- Máquinas só são equivalentes quando eixo, trajetória e resistência estão definidos.
- A base muscular v0.1.1 não foi modificada.
