#!/usr/bin/env python3
"""Deterministic builder for the EveFit principal arm exercise catalogue v0.1.

The muscular knowledge base v0.1.1 is an immutable input. This builder creates
an exercise catalogue beside it and never writes into the source package.
"""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import sys
import zipfile
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "EveFit_Muscular_Knowledge_Base_v0.1.1"
BASE_ZIP = ROOT / "EveFit_Muscular_Knowledge_Base_v0.1.1.zip"
OUT_NAME = "EveFit_Principal_Arm_Exercise_Catalogue_v0.1"
OUT = ROOT / OUT_NAME
ZIP_PATH = ROOT / f"{OUT_NAME}.zip"
SCHEMA_VERSION = "0.1"
BUILD_DATE = "2026-07-30"
EXPECTED_BASE_SHA256 = "a1876a1d4bc21ab54b3828774f66a99519a4953dc00191e69475d8c15b8b30b0"
ZIP_TIMESTAMP = (2026, 7, 30, 0, 0, 0)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = "".join(
        json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
        for row in sorted(rows, key=lambda r: r[next(iter([k for k in r if k.endswith("_id")]))])
    )
    path.write_text(text, encoding="utf-8")


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def compact_list(items: list[str]) -> str:
    cleaned = [str(item).strip().rstrip(" .;") for item in items if str(item).strip()]
    if not cleaned:
        return "Nenhum identificado"
    for index in range(1, len(cleaned)):
        item = cleaned[index]
        has_internal_uppercase = any(char.isupper() for char in item[1:])
        if item[:1].isupper() and not has_internal_uppercase:
            cleaned[index] = item[:1].lower() + item[1:]
    if len(cleaned) == 1:
        return cleaned[0]
    return ", ".join(cleaned[:-1]) + " e " + cleaned[-1]


SOURCES = [
    {
        "source_id": "src_base_muscular_kb_v0_1_1",
        "title": "EveFit Muscular Knowledge Base v0.1.1",
        "authors": "Sandro e EVE",
        "year": 2026,
        "source_type": "canonical_internal_knowledge_base",
        "url": "",
        "scope": "IDs, anatomia, articulações, ações e relações musculares canónicas.",
        "quality": "high_confidence_within_approved_scope",
    },
    {
        "source_id": "src_murray_elbow_1995",
        "title": "Variation of muscle moment arms with elbow and forearm position",
        "authors": "Murray, Delp e Buchanan",
        "year": 1995,
        "source_type": "cadaveric_biomechanics",
        "url": "https://pubmed.ncbi.nlm.nih.gov/7775488/",
        "scope": "Dependência angular e da posição do antebraço nos braços de momento do cotovelo.",
        "quality": "moderate_confidence",
    },
    {
        "source_id": "src_oliveira_biceps_2009",
        "title": "Effect of the shoulder position on the biceps brachii EMG in different dumbbell curls",
        "authors": "Oliveira et al.",
        "year": 2009,
        "source_type": "surface_emg_experiment",
        "url": "https://pubmed.ncbi.nlm.nih.gov/24150552/",
        "scope": "Atividade aguda da cabeça longa do bicípite em posições distintas do ombro.",
        "quality": "low_to_moderate_for_emphasis",
    },
    {
        "source_id": "src_attarieh_curls_2025",
        "title": "Preacher versus Bayesian Cable Curls",
        "authors": "Attarieh et al.",
        "year": 2025,
        "source_type": "longitudinal_training_study",
        "url": "https://pubmed.ncbi.nlm.nih.gov/40082069/",
        "scope": "Comparação longitudinal de duas posições do ombro em flexão do cotovelo.",
        "quality": "moderate_confidence",
    },
    {
        "source_id": "src_dickie_pullup_2017",
        "title": "Electromyographic analysis of muscle activation during pull-up variations",
        "authors": "Dickie et al.",
        "year": 2017,
        "source_type": "surface_emg_experiment",
        "url": "https://pubmed.ncbi.nlm.nih.gov/28011412/",
        "scope": "Participação muscular em variantes de tração vertical com diferentes pegas.",
        "quality": "low_to_moderate_for_emphasis",
    },
    {
        "source_id": "src_maeo_triceps_2023",
        "title": "Triceps brachii hypertrophy is substantially greater after elbow extension training performed in the overhead versus neutral arm position",
        "authors": "Maeo et al.",
        "year": 2023,
        "source_type": "longitudinal_training_study",
        "url": "https://pubmed.ncbi.nlm.nih.gov/35819335/",
        "scope": "Efeito da posição do ombro em treino longitudinal de extensão do cotovelo.",
        "quality": "moderate_confidence",
    },
    {
        "source_id": "src_kholinne_triceps_2018",
        "title": "The different role of each head of the triceps brachii muscle in elbow extension",
        "authors": "Kholinne et al.",
        "year": 2018,
        "source_type": "biomechanical_model_and_surface_emg",
        "url": "https://pubmed.ncbi.nlm.nih.gov/29503079/",
        "scope": "Contribuição dependente da elevação do ombro das cabeças do tricípite.",
        "quality": "moderate_confidence",
    },
    {
        "source_id": "src_saeterbakken_bench_2021",
        "title": "The Effect of Grip Width on Muscle Strength and Electromyographic Activity in Bench Press",
        "authors": "Saeterbakken et al.",
        "year": 2021,
        "source_type": "surface_emg_and_strength_experiment",
        "url": "https://pubmed.ncbi.nlm.nih.gov/34198674/",
        "scope": "Efeito da largura de pega no supino, carga e atividade do tricípite.",
        "quality": "moderate_for_acute_task",
    },
    {
        "source_id": "src_cogley_pushup_2005",
        "title": "Comparison of muscle activation using various hand positions during the push-up exercise",
        "authors": "Cogley et al.",
        "year": 2005,
        "source_type": "surface_emg_experiment",
        "url": "https://pubmed.ncbi.nlm.nih.gov/16095413/",
        "scope": "Efeito da posição estreita das mãos na flexão de braços.",
        "quality": "low_to_moderate_for_emphasis",
    },
    {
        "source_id": "src_vigotsky_semg_2018",
        "title": "Interpreting Signal Amplitudes in Surface Electromyography Studies",
        "authors": "Vigotsky et al.",
        "year": 2018,
        "source_type": "peer_reviewed_review",
        "url": "https://pubmed.ncbi.nlm.nih.gov/29354060/",
        "scope": "Limitações de interpretação de amplitudes de sEMG.",
        "quality": "high_confidence",
    },
    {
        "source_id": "src_vigotsky_hypertrophy_2022",
        "title": "Acutely Measured Surface EMG Amplitude is not a Validated Predictor of Muscle Hypertrophy",
        "authors": "Vigotsky et al.",
        "year": 2022,
        "source_type": "peer_reviewed_review",
        "url": "https://pubmed.ncbi.nlm.nih.gov/35006527/",
        "scope": "Separação entre ativação aguda e adaptação longitudinal.",
        "quality": "high_confidence",
    },
    {
        "source_id": "src_ikeda_wrist_2025",
        "title": "Effects of forearm rotation on wrist flexor and extensor muscle activity",
        "authors": "Ikeda et al.",
        "year": 2025,
        "source_type": "surface_emg_experiment",
        "url": "https://pubmed.ncbi.nlm.nih.gov/39819577/",
        "scope": "Efeito da rotação do antebraço na atividade de flexores e extensores do punho.",
        "quality": "low_to_moderate_for_emphasis",
    },
    {
        "source_id": "src_labott_grip_2019",
        "title": "Effects of Exercise Training on Handgrip Strength in Older People",
        "authors": "Labott et al.",
        "year": 2019,
        "source_type": "systematic_review_meta_analysis",
        "url": "https://pubmed.ncbi.nlm.nih.gov/31499496/",
        "scope": "Efeito de treino na força de preensão; não resolve identidade fina dos exercícios.",
        "quality": "moderate_confidence",
    },
    {
        "source_id": "src_gerodimos_grip_2021",
        "title": "Can maximal handgrip strength and endurance be improved by an 8-week specialized strength training program in older women?",
        "authors": "Gerodimos et al.",
        "year": 2021,
        "source_type": "randomized_training_study",
        "url": "https://pubmed.ncbi.nlm.nih.gov/33340721/",
        "scope": "Treino especializado com bolas e hand grippers; população e protocolo limitam generalização.",
        "quality": "moderate_confidence",
    },
    {
        "source_id": "src_kong_handle_2005",
        "title": "Optimal cylindrical handle diameter for grip force tasks",
        "authors": "Kong e Lowe",
        "year": 2005,
        "source_type": "experimental_ergonomics",
        "url": "https://doi.org/10.1016/j.ergon.2004.11.003",
        "scope": "Efeito do diâmetro na força e conforto de preensão máxima.",
        "quality": "moderate_confidence_for_contact_geometry",
    },
    {
        "source_id": "src_krings_fat_grip_2021",
        "title": "Impact of Fat Grip Attachments on Muscular Strength and Neuromuscular Activation During Resistance Exercise",
        "authors": "Krings et al.",
        "year": 2021,
        "source_type": "acute_strength_and_surface_emg_study",
        "url": "https://pubmed.ncbi.nlm.nih.gov/30694963/",
        "scope": "Efeito agudo de adaptadores de pega espessa em tarefas estudadas.",
        "quality": "low_to_moderate_for_emphasis",
    },
    {
        "source_id": "src_winwood_farmer_2014",
        "title": "A Biomechanical Analysis of the Farmers Walk, and Comparison with the Deadlift and Unloaded Walk",
        "authors": "Winwood et al.",
        "year": 2014,
        "source_type": "biomechanical_study",
        "url": "https://doi.org/10.1260/1747-9541.9.5.1127",
        "scope": "Identidade biomecânica do farmer walk; amostra pequena de strongmen.",
        "quality": "low_to_moderate_confidence",
    },
    {
        "source_id": "src_bordelon_carry_2021",
        "title": "Effects of Load Magnitude and Carry Position During Unilateral Dumbbell Carries",
        "authors": "Bordelon et al.",
        "year": 2021,
        "source_type": "acute_surface_emg_study",
        "url": "https://pubmed.ncbi.nlm.nih.gov/33298714/",
        "scope": "Carga, posição e estabilidade no carry unilateral.",
        "quality": "low_to_moderate_for_emphasis",
    },
    {
        "source_id": "src_ellestad_loaded_carry_2024",
        "title": "The Quantification of Muscle Activation During the Loaded Carry Movement Pattern",
        "authors": "Ellestad et al.",
        "year": 2024,
        "source_type": "acute_surface_emg_study",
        "url": "https://pubmed.ncbi.nlm.nih.gov/38665162/",
        "scope": "Diferenças agudas entre carries e holds; não prova adaptação.",
        "quality": "low_to_moderate_for_emphasis",
    },
    {
        "source_id": "src_exel_finger_hang_2023",
        "title": "Neuromechanics of finger hangs with arm lock-offs",
        "authors": "Exel et al.",
        "year": 2023,
        "source_type": "biomechanical_model_and_surface_emg",
        "url": "https://pubmed.ncbi.nlm.nih.gov/37927449/",
        "scope": "Hangs de escalada; evidência indireta para suspensão geral em barra.",
        "quality": "moderate_for_studied_task_indirect_for_bar",
    },
    {
        "source_id": "src_mckenzie_dips_2022",
        "title": "Bench, bar, and ring dips: do kinematics and muscle activity differ?",
        "authors": "McKenzie et al.",
        "year": 2022,
        "source_type": "kinematic_and_surface_emg_study",
        "url": "https://pubmed.ncbi.nlm.nih.gov/36293792/",
        "scope": "Diferenças cinemáticas e agudas entre tipos de fundos.",
        "quality": "moderate_for_acute_task",
    },
    {
        "source_id": "src_watanabe_breath_hold_2022",
        "title": "Effect of breath-hold on arterial blood pressure and cerebral blood velocity during isometric exercise",
        "authors": "Watanabe et al.",
        "year": 2022,
        "source_type": "experimental_physiology",
        "url": "https://pubmed.ncbi.nlm.nih.gov/34618221/",
        "scope": "Resposta pressora ao handgrip isométrico com retenção da respiração.",
        "quality": "moderate_confidence_for_studied_task",
    },
    {
        "source_id": "src_acsm_progression_2009",
        "title": "Progression models in resistance training for healthy adults",
        "authors": "American College of Sports Medicine",
        "year": 2009,
        "source_type": "professional_position_stand",
        "url": "https://pubmed.ncbi.nlm.nih.gov/19204579/",
        "scope": "Princípios gerais de treino resistido e diversidade de ações/exercícios.",
        "quality": "high_confidence_for_general_training",
    },
    {
        "source_id": "src_technical_inference",
        "title": "Inferência técnica controlada do catálogo v0.1",
        "authors": "EVE",
        "year": 2026,
        "source_type": "technical_inference",
        "url": "",
        "scope": "Derivação explícita entre posição, articulação, ação canónica e direção da resistência; nunca usada sozinha para alegar hipertrofia.",
        "quality": "context_dependent",
    },
]


FAMILIES = [
    ("elbow_flexion_supinated", "Flexão do cotovelo com antebraço supinado", "elbow_flexion"),
    ("elbow_flexion_neutral", "Flexão do cotovelo com antebraço neutro", "elbow_flexion"),
    ("elbow_flexion_pronated", "Flexão do cotovelo com antebraço pronado", "elbow_flexion"),
    ("elbow_extension_local", "Extensão local do cotovelo", "elbow_extension"),
    ("elbow_extension_compound", "Extensão do cotovelo em exercício multiarticular", "elbow_extension"),
    ("forearm_rotation", "Rotação resistida do antebraço", "forearm_rotation"),
    ("wrist_flexion_extension", "Flexão e extensão resistida do punho", "wrist_motion"),
    ("wrist_deviation", "Desvio radial e ulnar resistido", "wrist_motion"),
    ("digital_flexion_extension", "Flexão e extensão resistida dos dedos", "digital_motion"),
    ("grip_dynamic", "Fecho resistido da mão", "grip"),
    ("grip_isometric", "Preensão isométrica", "grip"),
    ("loaded_carry", "Transporte com preensão", "grip"),
    ("suspension_support", "Suspensão e apoio", "grip"),
    ("upper_limb_support", "Suporte multiarticular do membro superior", "compound_support"),
    ("thumb_specific", "Resistência específica do polegar", "digital_motion"),
]


EQUIPMENT = [
    ("bodyweight", "Peso corporal", "resistance"),
    ("straight_barbell", "Barra reta", "free_weight"),
    ("ez_bar", "Barra EZ", "free_weight"),
    ("dumbbell", "Halter", "free_weight"),
    ("kettlebell", "Kettlebell", "free_weight"),
    ("cable_stack", "Coluna de cabos", "cable"),
    ("high_pulley", "Polia alta", "anchor"),
    ("low_pulley", "Polia baixa", "anchor"),
    ("adjustable_pulley", "Polia ajustável", "anchor"),
    ("rope_attachment", "Corda para polia", "attachment"),
    ("straight_bar_attachment", "Barra reta para polia", "attachment"),
    ("single_handle", "Pega unilateral", "attachment"),
    ("elastic_band", "Banda elástica", "elastic"),
    ("selectorized_curl_machine", "Máquina de curl com pesos selecionados", "machine"),
    ("plate_loaded_curl_machine", "Máquina de curl com discos", "machine"),
    ("selectorized_triceps_machine", "Máquina de tríceps com pesos selecionados", "machine"),
    ("plate_loaded_triceps_machine", "Máquina de tríceps com discos", "machine"),
    ("preacher_bench", "Banco Scott", "support"),
    ("flat_bench", "Banco plano", "support"),
    ("incline_bench", "Banco inclinado", "support"),
    ("pull_up_bar", "Barra fixa", "support"),
    ("parallel_bars", "Paralelas", "support"),
    ("rings", "Argolas", "suspension"),
    ("suspension_trainer", "Sistema de suspensão", "suspension"),
    ("weight_plate", "Disco", "free_weight"),
    ("towel", "Toalha", "attachment"),
    ("fat_grip", "Adaptador de pega espessa", "attachment"),
    ("hand_gripper", "Hand gripper", "grip_tool"),
    ("wrist_roller", "Rolo de punho", "grip_tool"),
    ("lever_hammer", "Martelo ou alavanca", "lever"),
    ("carry_object", "Objeto de transporte", "free_weight"),
    ("manual_resistance", "Resistência manual", "manual"),
    ("soft_ball", "Bola macia de preensão", "grip_tool"),
]


BASE_CAUTION = [
    "Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica.",
    "A carga e a amplitude devem permitir controlo sem balanço ou compensação relevante.",
    "Respirar continuamente e evitar prender a respiração durante retenções prolongadas.",
]


def exercise(
    exercise_id: str,
    name_pt: str,
    name_en: str,
    family_id: str,
    short: str,
    *,
    synonyms: list[str] | None = None,
    status: str = "approved_public",
    technical: str = "",
    start: str,
    movement: str,
    trajectory: str,
    end: str,
    cues: list[str],
    errors: list[str],
    setup: list[str],
    stop: list[str] | None = None,
    joints: list[str],
    actions: list[str],
    planes: list[str],
    chain: str,
    proximal_fixed: str,
    distal_fixed: str,
    shoulder: str,
    forearm: str,
    wrist: str,
    resistance: str,
    rom: str,
    resistance_profile: str,
    hardest_zone: str,
    stability: str,
    laterality: str,
    required_equipment: list[str],
    optional_equipment: list[str] | None = None,
    alternatives: list[str] | None = None,
    anchorage: str = "Não aplicável.",
    support: str = "Não obrigatório.",
    space: str = "Espaço imediato em torno do praticante.",
    accessibility: str = "Acessível quando o equipamento e a posição podem ser ajustados com controlo.",
    limiting_joints: list[str] | None = None,
    risk_errors: list[str] | None = None,
    regressions: list[str] | None = None,
    specialist_review: str = "Não exigida em treino geral assintomático; necessária perante dor, lesão ou cirurgia.",
    source_ids: list[str] | None = None,
    public_eligible: bool = True,
) -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "exercise_id": exercise_id,
        "name_pt_pt": name_pt,
        "name_en": name_en,
        "synonyms": synonyms or [],
        "family_id": family_id,
        "entity_type": "canonical_exercise",
        "status": status,
        "public_eligible": public_eligible,
        "short_description": short,
        "technical_description": technical or short,
        "execution": {
            "start_position": start,
            "movement": movement,
            "trajectory": trajectory,
            "end_position": end,
            "cues": cues,
            "common_errors": errors,
            "setup": setup,
            "general_breathing": "Respirar continuamente; expirar durante a fase de maior esforço e inspirar no regresso, sem tornar esta indicação uma prescrição clínica.",
            "stop_conditions": stop or BASE_CAUTION,
        },
        "mechanics": {
            "joint_ids": joints,
            "action_ids": actions,
            "planes": planes,
            "kinetic_chain": chain,
            "proximal_fixed_segment": proximal_fixed,
            "distal_fixed_segment": distal_fixed,
            "shoulder_position": shoulder,
            "forearm_position": forearm,
            "wrist_position": wrist,
            "resistance_direction": resistance,
            "functional_range": rom,
            "resistance_profile": resistance_profile,
            "hardest_zone": hardest_zone,
            "stability_demand": stability,
            "laterality": laterality,
        },
        "equipment": {
            "required_ids": required_equipment,
            "optional_ids": optional_equipment or [],
            "alternative_ids": alternatives or [],
            "anchorage": anchorage,
            "bench_or_support": support,
            "space": space,
            "accessibility": accessibility,
        },
        "safety": {
            "potentially_limiting_joint_ids": limiting_joints or joints,
            "risk_errors": risk_errors or errors,
            "general_cautions": BASE_CAUTION,
            "regressions": regressions or [],
            "specialist_review": specialist_review,
        },
        "source_ids": source_ids or ["src_base_muscular_kb_v0_1_1", "src_technical_inference"],
    }


def curl_ex(
    exercise_id: str,
    name_pt: str,
    name_en: str,
    family_id: str,
    *,
    shoulder: str,
    forearm: str,
    resistance: str,
    profile: str,
    hardest: str,
    equipment: list[str],
    optional: list[str] | None = None,
    alternatives: list[str] | None = None,
    anchorage: str = "Não aplicável.",
    support: str = "Não obrigatório.",
    stability: str = "Moderada: manter braço, punho e tronco estáveis.",
    status: str = "approved_public",
    source_ids: list[str] | None = None,
    synonyms: list[str] | None = None,
) -> dict:
    return exercise(
        exercise_id,
        name_pt,
        name_en,
        family_id,
        f"Flexão controlada do cotovelo com o antebraço {forearm.lower()}, mantendo o punho estável.",
        synonyms=synonyms,
        status=status,
        technical=(
            f"Exercício de cadeia aberta para flexão do cotovelo. O ombro fica {shoulder.lower()} "
            f"e a resistência é {resistance.lower()}. A posição altera comprimentos e braços de momento, "
            "mas não permite alegar isolamento de uma cabeça muscular."
        ),
        start="Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.",
        movement="Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.",
        trajectory="A mão aproxima-se do ombro em torno do eixo do cotovelo, acompanhando a linha de resistência.",
        end="Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.",
        cues=["Manter o punho neutro.", "Mover sobretudo pelo cotovelo.", "Controlar a descida."],
        errors=["Balançar o tronco.", "Projetar o cotovelo sem intenção técnica.", "Deixar o punho colapsar."],
        setup=["Ajustar apoio e carga.", "Garantir espaço para a trajetória.", "Adotar a orientação de antebraço indicada."],
        joints=["elbow_joint"],
        actions=["elbow_flexion"],
        planes=["sagittal"],
        chain="open_chain",
        proximal_fixed="Braço e cintura escapular relativamente estáveis.",
        distal_fixed="Nenhum; a mão desloca o implemento.",
        shoulder=shoulder,
        forearm=forearm,
        wrist="Neutro ou ligeiramente ajustado ao implemento, sem flexão/extensão deliberada.",
        resistance=resistance,
        rom="Da extensão confortável do cotovelo à flexão controlada sem perda de posição.",
        resistance_profile=profile,
        hardest_zone=hardest,
        stability=stability,
        laterality="Bilateral ou unilateral conforme a variante.",
        required_equipment=equipment,
        optional_equipment=optional,
        alternatives=alternatives,
        anchorage=anchorage,
        support=support,
        regressions=["Reduzir carga.", "Reduzir amplitude apenas até manter controlo.", "Usar apoio externo para o braço ou tronco."],
        source_ids=source_ids
        or ["src_base_muscular_kb_v0_1_1", "src_murray_elbow_1995", "src_technical_inference"],
    )


def triceps_ex(
    exercise_id: str,
    name_pt: str,
    name_en: str,
    *,
    family_id: str = "elbow_extension_local",
    shoulder: str,
    resistance: str,
    profile: str,
    hardest: str,
    equipment: list[str],
    optional: list[str] | None = None,
    alternatives: list[str] | None = None,
    chain: str = "open_chain",
    proximal_fixed: str = "Braço e cintura escapular relativamente estáveis.",
    distal_fixed: str = "Nenhum; a mão desloca o implemento.",
    support: str = "Não obrigatório.",
    stability: str = "Moderada: controlar braço, punho e tronco.",
    status: str = "approved_public",
    joints: list[str] | None = None,
    actions: list[str] | None = None,
    planes: list[str] | None = None,
    source_ids: list[str] | None = None,
    synonyms: list[str] | None = None,
) -> dict:
    return exercise(
        exercise_id,
        name_pt,
        name_en,
        family_id,
        "Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.",
        synonyms=synonyms,
        status=status,
        technical=(
            f"Exercício com o ombro {shoulder.lower()} e resistência {resistance.lower()}. "
            "A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças."
        ),
        start="Começar com o cotovelo fletido, braço organizado e punho estável.",
        movement="Estender o cotovelo contra a resistência e regressar sob controlo.",
        trajectory="A mão afasta-se do ombro em torno do cotovelo, alinhada com a resistência.",
        end="Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.",
        cues=["Fixar a posição do braço.", "Manter o punho neutro.", "Controlar o regresso."],
        errors=["Abrir ou fechar excessivamente os cotovelos.", "Usar balanço do tronco.", "Perder o alinhamento do punho."],
        setup=["Ajustar carga e apoio.", "Escolher uma pega confortável.", "Confirmar liberdade de movimento do cotovelo."],
        joints=joints or ["elbow_joint"],
        actions=actions or ["elbow_extension"],
        planes=planes or ["sagittal"],
        chain=chain,
        proximal_fixed=proximal_fixed,
        distal_fixed=distal_fixed,
        shoulder=shoulder,
        forearm="Neutro ou pronado conforme a pega, sem rotação deliberada durante a repetição.",
        wrist="Neutro.",
        resistance=resistance,
        rom="Da flexão confortável à extensão controlada do cotovelo.",
        resistance_profile=profile,
        hardest_zone=hardest,
        stability=stability,
        laterality="Bilateral ou unilateral conforme a variante.",
        required_equipment=equipment,
        optional_equipment=optional,
        alternatives=alternatives,
        support=support,
        limiting_joints=["elbow_joint", "glenohumeral_joint"],
        regressions=["Reduzir carga.", "Reduzir amplitude até manter conforto e controlo.", "Escolher uma variante com mais apoio."],
        source_ids=source_ids
        or ["src_base_muscular_kb_v0_1_1", "src_kholinne_triceps_2018", "src_technical_inference"],
    )


def wrist_ex(
    exercise_id: str,
    name_pt: str,
    name_en: str,
    family_id: str,
    action_ids: list[str],
    *,
    forearm: str,
    resistance: str,
    equipment: list[str],
    profile: str = "Dependente do implemento e da distância perpendicular ao eixo articular.",
    status: str = "approved_public",
    support: str = "Antebraço apoiado.",
    source_ids: list[str] | None = None,
) -> dict:
    action_label = {
        "wrist_flexion": "flexão do punho",
        "wrist_extension": "extensão do punho",
        "wrist_radial_deviation": "desvio radial do punho",
        "wrist_ulnar_deviation": "desvio ulnar do punho",
        "forearm_pronation": "pronação do antebraço",
        "forearm_supination": "supinação do antebraço",
    }[action_ids[0]]
    rotation = action_ids[0].startswith("forearm_")
    joints = (
        ["proximal_radioulnar_joint", "distal_radioulnar_joint"]
        if rotation
        else ["radiocarpal_joint", "midcarpal_joint"]
    )
    plane = "transverse" if rotation else ("frontal" if "deviation" in action_ids[0] else "sagittal")
    return exercise(
        exercise_id,
        name_pt,
        name_en,
        family_id,
        f"{action_label.capitalize()} contra resistência com o antebraço controlado.",
        status=status,
        technical=(
            f"Exercício monoação destinado a carregar {action_label}. A contribuição individual "
            "dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude."
        ),
        start="Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.",
        movement=f"Executar {action_label} contra a resistência e regressar lentamente.",
        trajectory="O implemento descreve um arco curto em torno da articulação-alvo.",
        end="Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.",
        cues=["Manter o antebraço imóvel.", "Usar amplitude controlada.", "Evitar movimento dos dedos para substituir o punho."],
        errors=["Mover o cotovelo ou ombro.", "Usar carga que força amplitude terminal.", "Perder o alinhamento da mão."],
        setup=["Ajustar apoio e alavanca.", "Usar carga leve o suficiente para controlo fino.", "Alinhar a resistência com a ação pretendida."],
        joints=joints,
        actions=action_ids,
        planes=[plane],
        chain="open_chain",
        proximal_fixed="Antebraço estabilizado.",
        distal_fixed="Nenhum; mão ou implemento move-se.",
        shoulder="Neutro e relaxado.",
        forearm=forearm,
        wrist="Move-se apenas na ação declarada." if not rotation else "Mantido neutro durante a rotação do antebraço.",
        resistance=resistance,
        rom="Amplitude confortável, sem forçar o fim da amplitude.",
        resistance_profile=profile,
        hardest_zone="Depende da orientação do implemento e da linha de resistência.",
        stability="Baixa a moderada, desde que o antebraço esteja apoiado.",
        laterality="Unilateral ou bilateral conforme o implemento.",
        required_equipment=equipment,
        support=support,
        regressions=["Reduzir a alavanca.", "Reduzir carga.", "Usar resistência manual suave e controlada."],
        source_ids=source_ids
        or ["src_base_muscular_kb_v0_1_1", "src_ikeda_wrist_2025", "src_technical_inference"],
    )


def grip_ex(
    exercise_id: str,
    name_pt: str,
    name_en: str,
    family_id: str,
    *,
    short: str,
    movement: str,
    equipment: list[str],
    chain: str,
    resistance: str,
    stability: str,
    status: str = "approved_public",
    joints: list[str] | None = None,
    actions: list[str] | None = None,
    limiting: list[str] | None = None,
    space: str = "Espaço imediato em torno do praticante.",
    anchorage: str = "Não aplicável.",
    source_ids: list[str] | None = None,
) -> dict:
    return exercise(
        exercise_id,
        name_pt,
        name_en,
        family_id,
        short,
        status=status,
        technical=(
            "Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, "
            "contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado."
        ),
        start="Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.",
        movement=movement,
        trajectory="Predominantemente isométrica na mão; quando existe transporte, o corpo desloca-se mantendo a preensão.",
        end="Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.",
        cues=["Envolver o implemento com controlo.", "Manter o punho próximo de neutro.", "Terminar antes da abertura involuntária da mão."],
        errors=["Continuar depois de a pega começar a escapar.", "Compensar com flexão excessiva do punho.", "Usar superfície ou carga sem margem de segurança."],
        setup=["Verificar o estado do implemento.", "Remover obstáculos.", "Escolher carga e duração controláveis."],
        joints=joints
        or [
            "finger_metacarpophalangeal_joints",
            "finger_proximal_interphalangeal_joints",
            "finger_distal_interphalangeal_joints",
            "radiocarpal_joint",
        ],
        actions=actions or ["finger_mcp_flexion", "finger_pip_flexion", "finger_dip_flexion"],
        planes=["multiplanar"],
        chain=chain,
        proximal_fixed="Antebraço e cintura escapular estabilizam conforme a tarefa.",
        distal_fixed="Contacto fixo no implemento durante a fase isométrica.",
        shoulder="Dependente da tarefa, sem objetivo de treino do ombro.",
        forearm="Neutro ou ajustado ao implemento.",
        wrist="Próximo de neutro; estabilização isométrica contextual.",
        resistance=resistance,
        rom="Sem amplitude dinâmica obrigatória na mão; o contacto deve manter-se seguro.",
        resistance_profile="Isométrico na mão; a exigência aumenta com carga, duração, espessura e menor vantagem de contacto.",
        hardest_zone="Próximo do limite individual de contacto ou duração, que não deve ser ultrapassado de forma descontrolada.",
        stability=stability,
        laterality="Unilateral ou bilateral conforme a tarefa.",
        required_equipment=equipment,
        anchorage=anchorage,
        space=space,
        limiting_joints=limiting
        or [
            "radiocarpal_joint",
            "finger_metacarpophalangeal_joints",
            "finger_proximal_interphalangeal_joints",
            "finger_distal_interphalangeal_joints",
        ],
        regressions=["Reduzir carga ou duração.", "Aumentar área de contacto.", "Usar apoio que permita libertar a mão imediatamente."],
        source_ids=source_ids
        or ["src_base_muscular_kb_v0_1_1", "src_technical_inference"],
    )


EXERCISES: list[dict] = [
    curl_ex(
        "standing_supinated_curl",
        "Curl em pé com pega supinada",
        "Standing supinated curl",
        "elbow_flexion_supinated",
        shoulder="Neutro junto ao tronco",
        forearm="Supinado",
        resistance="Vertical pela gravidade",
        profile="Momento externo dependente da horizontalidade do antebraço.",
        hardest="Tende a aumentar na zona média quando o antebraço fica mais perpendicular à gravidade.",
        equipment=["straight_barbell"],
        optional=["ez_bar", "dumbbell"],
        alternatives=["cable_stack", "elastic_band"],
        synonyms=["curl com barra", "curl de bíceps em pé"],
    ),
    curl_ex(
        "standing_cable_curl",
        "Curl em pé no cabo",
        "Standing cable curl",
        "elbow_flexion_supinated",
        shoulder="Neutro junto ao tronco",
        forearm="Supinado",
        resistance="Ao longo do cabo, habitualmente a partir de polia baixa",
        profile="A direção mantém-se alinhada com o cabo e muda relativamente ao antebraço ao longo da amplitude.",
        hardest="Depende da altura e distância à polia; não é universalmente igual ao curl com peso livre.",
        equipment=["cable_stack", "low_pulley", "straight_bar_attachment"],
        optional=["single_handle", "rope_attachment"],
        anchorage="Polia baixa ou ajustável abaixo da mão.",
        alternatives=["elastic_band"],
    ),
    curl_ex(
        "elastic_band_curl",
        "Curl com banda elástica",
        "Elastic-band curl",
        "elbow_flexion_supinated",
        shoulder="Neutro junto ao tronco",
        forearm="Supinado",
        resistance="Elástica, aumentando com o alongamento da banda",
        profile="Resistência geralmente ascendente com o alongamento, dependente da banda e ancoragem.",
        hardest="Tende a deslocar-se para a parte final se a tensão aumentar continuamente.",
        equipment=["elastic_band"],
        alternatives=["cable_stack", "dumbbell"],
        anchorage="Sob os pés ou num ponto baixo estável.",
    ),
    curl_ex(
        "shoulder_extended_supinated_curl",
        "Curl supinado com ombro em extensão",
        "Shoulder-extended supinated curl",
        "elbow_flexion_supinated",
        shoulder="Em extensão relativa atrás do tronco, apoiado num banco inclinado",
        forearm="Supinado",
        resistance="Vertical pela gravidade",
        profile="Momento externo dependente do ângulo do cotovelo e da orientação do braço.",
        hardest="Habitualmente na zona média; o ombro em extensão altera o comprimento do bicípite.",
        equipment=["dumbbell", "incline_bench"],
        support="Costas apoiadas num banco inclinado.",
        source_ids=[
            "src_base_muscular_kb_v0_1_1",
            "src_murray_elbow_1995",
            "src_oliveira_biceps_2009",
            "src_attarieh_curls_2025",
            "src_vigotsky_semg_2018",
            "src_technical_inference",
        ],
    ),
    curl_ex(
        "preacher_curl",
        "Curl no banco Scott",
        "Preacher curl",
        "elbow_flexion_supinated",
        shoulder="Em flexão, com o braço apoiado no banco Scott",
        forearm="Supinado ou semissupinado conforme a barra",
        resistance="Vertical pela gravidade ou definida pela máquina/cabo",
        profile="Depende do implemento; com peso livre pode ser exigente perto da extensão inicial.",
        hardest="Apoio reduz deslocamento do braço; a zona crítica depende do implemento e geometria.",
        equipment=["preacher_bench", "ez_bar"],
        optional=["dumbbell", "straight_barbell"],
        alternatives=["selectorized_curl_machine", "cable_stack"],
        support="Braços apoiados integralmente no banco Scott.",
        source_ids=[
            "src_base_muscular_kb_v0_1_1",
            "src_oliveira_biceps_2009",
            "src_attarieh_curls_2025",
            "src_technical_inference",
        ],
        synonyms=["curl Scott", "preacher curl"],
    ),
    curl_ex(
        "spider_curl",
        "Curl spider",
        "Spider curl",
        "elbow_flexion_supinated",
        shoulder="Em flexão, com o peito apoiado num banco inclinado e braços pendentes",
        forearm="Supinado",
        resistance="Vertical pela gravidade",
        profile="Momento externo dependente do ângulo do cotovelo com braço à frente do tronco.",
        hardest="Tende a concentrar exigência quando o antebraço fica mais horizontal.",
        equipment=["dumbbell", "incline_bench"],
        optional=["ez_bar"],
        support="Peito apoiado no encosto inclinado.",
    ),
    curl_ex(
        "concentration_curl",
        "Curl de concentração",
        "Concentration curl",
        "elbow_flexion_supinated",
        shoulder="Em ligeira flexão, com o braço apoiado na face interna da coxa",
        forearm="Supinado",
        resistance="Vertical pela gravidade",
        profile="Momento externo dependente da orientação do antebraço.",
        hardest="Habitualmente na zona média.",
        equipment=["dumbbell", "flat_bench"],
        support="Braço apoiado na coxa; tronco sentado e estável.",
        source_ids=[
            "src_base_muscular_kb_v0_1_1",
            "src_oliveira_biceps_2009",
            "src_vigotsky_semg_2018",
            "src_technical_inference",
        ],
    ),
    curl_ex(
        "hammer_curl",
        "Curl martelo",
        "Hammer curl",
        "elbow_flexion_neutral",
        shoulder="Neutro junto ao tronco",
        forearm="Neutro",
        resistance="Vertical pela gravidade",
        profile="Momento externo dependente da horizontalidade do antebraço.",
        hardest="Habitualmente na zona média.",
        equipment=["dumbbell"],
        optional=["rope_attachment", "cable_stack"],
        alternatives=["elastic_band"],
        synonyms=["curl com pega neutra"],
    ),
    curl_ex(
        "reverse_curl",
        "Curl inverso",
        "Reverse curl",
        "elbow_flexion_pronated",
        shoulder="Neutro junto ao tronco",
        forearm="Pronado",
        resistance="Vertical pela gravidade",
        profile="Momento externo dependente da horizontalidade do antebraço.",
        hardest="Habitualmente na zona média; a pega pronada pode limitar a carga pela mão e punho.",
        equipment=["ez_bar"],
        optional=["straight_barbell", "dumbbell"],
        alternatives=["cable_stack"],
        synonyms=["curl pronado"],
    ),
    curl_ex(
        "machine_elbow_curl",
        "Curl na máquina",
        "Machine elbow curl",
        "elbow_flexion_supinated",
        shoulder="Definido pela máquina, geralmente com braço apoiado ou junto ao tronco",
        forearm="Definido pela pega, geralmente supinado ou semissupinado",
        resistance="Definida pela came, cabo ou braço de alavanca da máquina",
        profile="Não generalizável entre máquinas; depende da geometria do fabricante.",
        hardest="Só pode ser descrita após conhecer a came, eixo e trajetória.",
        equipment=["selectorized_curl_machine"],
        optional=["plate_loaded_curl_machine"],
        support="Assento e apoio do braço definidos pela máquina.",
        status="approved_with_limits",
    ),
    exercise(
        "supinated_chin_up",
        "Elevação na barra com pega supinada",
        "Supinated chin-up",
        "elbow_flexion_supinated",
        "Tração vertical multiarticular com pega supinada, na qual os flexores do cotovelo têm papel relevante mas não exclusivo.",
        synonyms=["chin-up"],
        technical="Exercício de cadeia fechada para cotovelo e ombro. O bicípite e o braquial contribuem para a flexão do cotovelo, enquanto músculos das costas e cintura escapular também são determinantes.",
        start="Suspender-se numa barra fixa com pega supinada segura, cotovelos estendidos sem relaxamento descontrolado.",
        movement="Puxar o corpo para cima através de flexão do cotovelo e movimento coordenado do ombro/escápula; descer sob controlo.",
        trajectory="O tronco aproxima-se da barra num percurso vertical ou ligeiramente arqueado.",
        end="Terminar a subida sem projetar a cabeça ou perder o controlo escapular; regressar à suspensão controlada.",
        cues=["Iniciar com controlo escapular.", "Manter a pega fechada.", "Evitar balanço das pernas."],
        errors=["Usar impulso excessivo.", "Soltar bruscamente para a extensão.", "Forçar amplitude do ombro dolorosa."],
        setup=["Confirmar estabilidade da barra.", "Escolher largura de pega confortável.", "Garantir espaço livre por baixo."],
        joints=["elbow_joint", "glenohumeral_joint", "scapulothoracic_articulation"],
        actions=["elbow_flexion", "shoulder_extension", "shoulder_adduction", "scapular_depression"],
        planes=["sagittal", "frontal"],
        chain="closed_chain",
        proximal_fixed="O tronco desloca-se relativamente à mão fixa.",
        distal_fixed="Mãos fixas na barra.",
        shoulder="Elevação inicial seguida de extensão/adução contextual.",
        forearm="Supinado.",
        wrist="Neutro ou ligeiramente estendido conforme a barra.",
        resistance="Peso corporal vertical pela gravidade.",
        rom="Da suspensão controlada à elevação compatível com a mobilidade individual.",
        resistance_profile="Varia com a posição do corpo, cotovelo e ombro; não é constante.",
        hardest_zone="Individual e dependente da força relativa e da técnica.",
        stability="Elevada exigência de cintura escapular, tronco e preensão.",
        laterality="Bilateral.",
        required_equipment=["bodyweight", "pull_up_bar"],
        optional_equipment=["elastic_band"],
        anchorage="Barra fixa certificada e estável.",
        space="Espaço vertical livre.",
        limiting_joints=["elbow_joint", "glenohumeral_joint", "radiocarpal_joint"],
        regressions=["Usar assistência elástica.", "Usar máquina assistida quando disponível.", "Reduzir amplitude mantendo controlo."],
        source_ids=["src_base_muscular_kb_v0_1_1", "src_dickie_pullup_2017", "src_vigotsky_semg_2018", "src_technical_inference"],
    ),
    exercise(
        "suspension_bodyweight_curl",
        "Curl em suspensão com peso corporal",
        "Suspension bodyweight curl",
        "elbow_flexion_supinated",
        "Flexão do cotovelo em cadeia mista, aproximando o corpo das mãos através de pegas móveis num sistema de suspensão.",
        technical="A resistência resulta da componente do peso corporal perpendicular à linha entre pés e mãos. A posição dos pés regula a dificuldade sem alterar a identidade.",
        start="Segurar as pegas com o corpo alinhado e cotovelos estendidos, mantendo tensão no sistema.",
        movement="Fletir os cotovelos para aproximar a testa ou ombros das mãos, sem perder o alinhamento corporal.",
        trajectory="O corpo roda em torno do apoio dos pés enquanto as mãos permanecem ligadas às fitas.",
        end="Terminar antes de os ombros avançarem ou o tronco perder rigidez; regressar sob controlo.",
        cues=["Manter o corpo alinhado.", "Apontar as palmas para cima.", "Mover pelos cotovelos."],
        errors=["Dobrar a anca.", "Transformar o gesto numa remada.", "Usar ancoragem instável."],
        setup=["Fixar o sistema num ponto certificado.", "Ajustar o comprimento das fitas.", "Posicionar os pés para uma dificuldade controlável."],
        joints=["elbow_joint", "glenohumeral_joint"],
        actions=["elbow_flexion"],
        planes=["sagittal"],
        chain="mixed_chain",
        proximal_fixed="Os pés mantêm contacto com o solo; o tronco desloca-se como segmento controlado.",
        distal_fixed="Nenhum segmento distal é geometricamente fixo; as mãos mantêm contacto com pegas móveis.",
        shoulder="Em flexão relativa, mantido estável.",
        forearm="Supinado ou semissupinado conforme as pegas.",
        wrist="Neutro.",
        resistance="Componente do peso corporal oposta pela tensão das fitas.",
        rom="Da extensão controlada à flexão do cotovelo sem transformar o gesto numa remada.",
        resistance_profile="Aumenta quando o corpo fica mais horizontal.",
        hardest_zone="Depende da inclinação e da posição relativa do cotovelo.",
        stability="Elevada exigência de tronco, ombro e ancoragem.",
        laterality="Bilateral.",
        required_equipment=["bodyweight", "suspension_trainer"],
        optional_equipment=["rings"],
        anchorage="Ponto alto certificado para suspensão.",
        space="Espaço longitudinal para inclinar o corpo.",
        limiting_joints=["elbow_joint", "glenohumeral_joint", "radiocarpal_joint"],
        regressions=["Aproximar os pés da vertical do ponto de ancoragem.", "Reduzir amplitude.", "Usar curl apoiado em vez de suspensão."],
    ),
]


EXERCISES += [
    triceps_ex(
        "cable_triceps_pushdown",
        "Extensão de tríceps na polia",
        "Cable triceps pushdown",
        shoulder="Neutro, com o braço junto ao tronco",
        resistance="Ao longo do cabo a partir de uma polia alta",
        profile="Dependente da posição em relação à polia e do percurso do cabo.",
        hardest="Muda ao longo da amplitude; não se presume uma came universal.",
        equipment=["cable_stack", "high_pulley", "straight_bar_attachment"],
        optional=["rope_attachment", "single_handle"],
        alternatives=["elastic_band"],
        synonyms=["pushdown de tríceps"],
    ),
    triceps_ex(
        "overhead_triceps_extension",
        "Extensão de tríceps acima da cabeça",
        "Overhead triceps extension",
        shoulder="Elevado acima da cabeça",
        resistance="Definida por cabo, peso livre ou banda",
        profile="Materialmente dependente do implemento e da posição do ombro.",
        hardest="Com peso livre varia com o antebraço; com cabo depende da ancoragem.",
        equipment=["cable_stack", "adjustable_pulley", "rope_attachment"],
        optional=["dumbbell", "ez_bar", "elastic_band"],
        support="Em pé ou sentado, com apoio opcional para o tronco.",
        source_ids=[
            "src_base_muscular_kb_v0_1_1",
            "src_maeo_triceps_2023",
            "src_kholinne_triceps_2018",
            "src_technical_inference",
        ],
    ),
    triceps_ex(
        "lying_triceps_extension",
        "Extensão de tríceps deitado",
        "Lying triceps extension",
        shoulder="Em flexão aproximada de 90 graus, estabilizado sobre banco",
        resistance="Vertical pela gravidade",
        profile="Depende da posição do braço e de onde o implemento termina relativamente ao ombro.",
        hardest="Pode ser elevada quando o antebraço se aproxima da horizontal.",
        equipment=["flat_bench", "ez_bar"],
        optional=["dumbbell", "straight_barbell"],
        support="Tronco apoiado num banco plano.",
        synonyms=["skull crusher"],
    ),
    triceps_ex(
        "cross_body_cable_triceps_extension",
        "Extensão cruzada de tríceps no cabo",
        "Cross-body cable triceps extension",
        shoulder="À frente do corpo, com ligeira adução horizontal contextual",
        resistance="Oblíqua ao longo do cabo",
        profile="A direção para a polia pode carregar o cotovelo em ângulos diferentes do pushdown.",
        hardest="Depende da altura da polia e da posição do braço.",
        equipment=["cable_stack", "adjustable_pulley", "single_handle"],
        stability="Moderada a elevada no ombro para manter a trajetória cruzada.",
    ),
    triceps_ex(
        "triceps_kickback",
        "Kickback de tríceps",
        "Triceps kickback",
        shoulder="Em extensão atrás do tronco",
        resistance="Vertical pela gravidade ou ao longo do cabo",
        profile="Com halter, o momento externo tende a aumentar perto da extensão; com cabo depende da linha.",
        hardest="Com halter, geralmente perto da extensão horizontal do antebraço.",
        equipment=["dumbbell"],
        optional=["cable_stack", "low_pulley", "single_handle"],
        support="Apoio opcional da mão e joelho num banco.",
    ),
    triceps_ex(
        "machine_triceps_extension",
        "Extensão de tríceps na máquina",
        "Machine triceps extension",
        shoulder="Definido pela máquina, geralmente com braço apoiado",
        resistance="Definida por came, cabo ou braço de alavanca",
        profile="Não generalizável entre máquinas.",
        hardest="Só pode ser descrita com a geometria concreta da máquina.",
        equipment=["selectorized_triceps_machine"],
        optional=["plate_loaded_triceps_machine"],
        support="Assento e apoio de braço definidos pela máquina.",
        status="approved_with_limits",
    ),
    exercise(
        "parallel_bar_dip",
        "Fundos em paralelas",
        "Parallel-bar dip",
        "elbow_extension_compound",
        "Exercício multiarticular em apoio nas paralelas, com extensão do cotovelo relevante e participação do ombro e peito.",
        synonyms=["dips em paralelas"],
        technical="Cadeia fechada. O tricípite é importante, mas o gesto também exige extensão/adução do ombro, depressão escapular e controlo do tronco.",
        start="Apoiar o corpo nas paralelas com cotovelos estendidos, ombros organizados e pés sem apoio.",
        movement="Descer por flexão controlada dos cotovelos e ombros; subir estendendo os cotovelos sem perder a posição escapular.",
        trajectory="O corpo desloca-se verticalmente entre as barras.",
        end="Terminar a descida antes de dor ou perda de controlo do ombro; subir até extensão confortável.",
        cues=["Manter as barras firmemente seguras.", "Controlar a profundidade.", "Evitar encolher os ombros."],
        errors=["Descer além da amplitude tolerada.", "Balançar o corpo.", "Bloquear o cotovelo de forma agressiva."],
        setup=["Confirmar estabilidade das paralelas.", "Garantir espaço livre.", "Usar assistência se necessário."],
        joints=["elbow_joint", "glenohumeral_joint", "scapulothoracic_articulation"],
        actions=["elbow_extension", "shoulder_extension", "shoulder_flexion", "shoulder_adduction", "scapular_depression"],
        planes=["sagittal", "frontal"],
        chain="closed_chain",
        proximal_fixed="O tronco desloca-se entre os apoios.",
        distal_fixed="Mãos fixas nas paralelas.",
        shoulder="Move-se para extensão na descida e regressa na subida, dentro da tolerância.",
        forearm="Neutro.",
        wrist="Neutro ou ligeiramente estendido conforme a barra.",
        resistance="Peso corporal vertical pela gravidade.",
        rom="Profundidade limitada pela mobilidade, controlo e conforto do ombro.",
        resistance_profile="Varia com a inclinação do tronco e os ângulos articulares.",
        hardest_zone="Frequentemente a transição inferior, mas varia individualmente.",
        stability="Elevada no ombro, escápula, tronco e preensão.",
        laterality="Bilateral.",
        required_equipment=["bodyweight", "parallel_bars"],
        optional_equipment=["elastic_band"],
        space="Espaço vertical e lateral livre.",
        limiting_joints=["glenohumeral_joint", "elbow_joint", "radiocarpal_joint"],
        regressions=["Usar assistência.", "Reduzir profundidade.", "Usar flexão de braços estreita."],
        source_ids=["src_base_muscular_kb_v0_1_1", "src_mckenzie_dips_2022", "src_vigotsky_semg_2018", "src_technical_inference"],
    ),
    exercise(
        "bench_dip",
        "Fundos no banco",
        "Bench dip",
        "elbow_extension_compound",
        "Extensão do cotovelo com as mãos apoiadas atrás do tronco; opção pública com limites pela extensão do ombro.",
        status="approved_with_limits",
        technical="Apoio posterior que combina extensão do cotovelo com extensão do ombro. A amplitude deve ser conservadora.",
        start="Apoiar as mãos na borda de um banco estável, com o tronco próximo do apoio e cotovelos estendidos.",
        movement="Descer através de flexão do cotovelo mantendo o ombro confortável; regressar estendendo o cotovelo.",
        trajectory="O tronco desloca-se verticalmente junto ao banco.",
        end="Parar a descida antes de desconforto anterior no ombro ou perda de alinhamento.",
        cues=["Manter o tronco perto do banco.", "Usar amplitude curta e confortável.", "Apontar os cotovelos para trás."],
        errors=["Descer demasiado.", "Afastar o tronco do banco.", "Usar apoio instável."],
        setup=["Fixar o banco.", "Apoiar os pés de forma segura.", "Escolher amplitude conservadora."],
        joints=["elbow_joint", "glenohumeral_joint"],
        actions=["elbow_extension", "shoulder_extension", "shoulder_flexion"],
        planes=["sagittal"],
        chain="closed_chain",
        proximal_fixed="Pés no solo e tronco deslocam-se entre os apoios.",
        distal_fixed="Mãos fixas no banco.",
        shoulder="Em extensão atrás do tronco, potencialmente limitante.",
        forearm="Neutro.",
        wrist="Em extensão sob carga.",
        resistance="Peso corporal vertical pela gravidade.",
        rom="Conservadora e limitada pelo conforto do ombro.",
        resistance_profile="Varia com a posição dos pés e a distância do tronco ao banco.",
        hardest_zone="Próximo da posição inferior.",
        stability="Moderada a elevada no ombro e punho.",
        laterality="Bilateral.",
        required_equipment=["bodyweight", "flat_bench"],
        limiting_joints=["glenohumeral_joint", "radiocarpal_joint", "elbow_joint"],
        risk_errors=["Extensão excessiva do ombro.", "Banco instável.", "Punho em extensão dolorosa."],
        regressions=["Reduzir amplitude.", "Aproximar os pés.", "Preferir pushdown ou flexão estreita."],
        specialist_review="Rever por especialista perante instabilidade, dor anterior do ombro, pós-lesão ou pós-cirurgia.",
        source_ids=["src_base_muscular_kb_v0_1_1", "src_mckenzie_dips_2022", "src_vigotsky_semg_2018", "src_technical_inference"],
    ),
    exercise(
        "close_grip_push_up",
        "Flexão de braços com mãos próximas",
        "Close-grip push-up",
        "elbow_extension_compound",
        "Flexão de braços multiarticular com mãos próximas, aumentando a exigência contextual de extensão do cotovelo.",
        synonyms=["flexão diamante", "push-up estreita"],
        technical="Cadeia fechada com extensão do cotovelo e adução horizontal do ombro; não é isolamento de tríceps.",
        start="Em prancha, mãos abaixo ou ligeiramente dentro da largura dos ombros, corpo alinhado.",
        movement="Descer o corpo com controlo e empurrar o solo até regressar à prancha.",
        trajectory="O tronco aproxima-se e afasta-se do solo como uma unidade.",
        end="Terminar a descida antes de perder alinhamento; subir sem bloquear agressivamente os cotovelos.",
        cues=["Manter corpo alinhado.", "Cotovelos orientados para trás.", "Empurrar o chão de forma uniforme."],
        errors=["Abrir excessivamente os cotovelos.", "Deixar a anca cair.", "Forçar uma posição estreita dolorosa."],
        setup=["Escolher largura confortável.", "Usar superfície firme.", "Ajustar apoio dos joelhos ou altura se necessário."],
        joints=["elbow_joint", "glenohumeral_joint", "scapulothoracic_articulation", "radiocarpal_joint"],
        actions=["elbow_extension", "shoulder_horizontal_adduction", "scapular_protraction"],
        planes=["sagittal", "transverse"],
        chain="closed_chain",
        proximal_fixed="Pés ou joelhos e tronco estabilizam o corpo.",
        distal_fixed="Mãos fixas no solo.",
        shoulder="Em flexão aproximada de 90 graus, com adução horizontal durante a subida.",
        forearm="Neutro.",
        wrist="Em extensão; alternativa em pegas para neutralidade.",
        resistance="Peso corporal vertical pela gravidade.",
        rom="Do apoio alto à profundidade compatível com controlo do tronco e ombro.",
        resistance_profile="Varia com a distribuição do peso corporal e o apoio escolhido.",
        hardest_zone="Próximo da posição inferior.",
        stability="Elevada no tronco, ombro e escápula.",
        laterality="Bilateral.",
        required_equipment=["bodyweight"],
        optional_equipment=["dumbbell"],
        alternatives=["parallel_bars"],
        limiting_joints=["radiocarpal_joint", "elbow_joint", "glenohumeral_joint"],
        regressions=["Apoiar os joelhos.", "Elevar as mãos.", "Usar pegas para reduzir extensão do punho."],
        source_ids=["src_base_muscular_kb_v0_1_1", "src_cogley_pushup_2005", "src_vigotsky_semg_2018", "src_technical_inference"],
    ),
    exercise(
        "close_grip_bench_press",
        "Supino com pega fechada",
        "Close-grip bench press",
        "elbow_extension_compound",
        "Supino multiarticular com pega relativamente estreita, no qual a extensão do cotovelo tem papel relevante.",
        technical="A largura de pega altera momentos e carga tolerada. Continua a ser um exercício de empurrar multiarticular.",
        start="Deitado no banco, pés estáveis, barra segura com pega ligeiramente mais estreita do que a habitual.",
        movement="Descer a barra ao tronco com controlo e empurrar por extensão do cotovelo e adução horizontal do ombro.",
        trajectory="Barra desce e sobe numa trajetória controlada.",
        end="Aproximar do tronco sem perder posição do ombro; subir até extensão controlada.",
        cues=["Manter antebraços alinhados.", "Controlar a descida.", "Usar observador ou suportes de segurança."],
        errors=["Pega estreita ao ponto de colapsar o punho.", "Cotovelos sem controlo.", "Treinar sem suportes adequados."],
        setup=["Ajustar suportes.", "Usar banco estável.", "Definir pega que mantenha punhos sobre antebraços."],
        joints=["elbow_joint", "glenohumeral_joint", "scapulothoracic_articulation", "radiocarpal_joint"],
        actions=["elbow_extension", "shoulder_horizontal_adduction"],
        planes=["sagittal", "transverse"],
        chain="open_chain",
        proximal_fixed="Tronco apoiado no banco.",
        distal_fixed="Nenhum; a barra desloca-se.",
        shoulder="Em abdução moderada e adução horizontal na subida.",
        forearm="Pronado.",
        wrist="Próximo de neutro, alinhado sobre o antebraço.",
        resistance="Vertical pela gravidade.",
        rom="Da extensão controlada à profundidade compatível com ombro e controlo da barra.",
        resistance_profile="Momentos no cotovelo e ombro mudam com a posição da barra e largura da pega.",
        hardest_zone="Habitualmente perto da parte inferior ou transição, variando com técnica e proporções.",
        stability="Elevada; requer banco, suportes e controlo bilateral.",
        laterality="Bilateral.",
        required_equipment=["straight_barbell", "flat_bench"],
        space="Rack e área de segurança em torno do banco.",
        limiting_joints=["radiocarpal_joint", "elbow_joint", "glenohumeral_joint"],
        regressions=["Reduzir carga.", "Usar halteres com pega neutra.", "Usar flexão elevada com mãos próximas."],
        source_ids=["src_base_muscular_kb_v0_1_1", "src_saeterbakken_bench_2021", "src_vigotsky_semg_2018", "src_technical_inference"],
    ),
    exercise(
        "suspension_triceps_extension",
        "Extensão de tríceps em suspensão",
        "Suspension triceps extension",
        "elbow_extension_local",
        "Extensão do cotovelo em cadeia mista através de pegas móveis num sistema de suspensão.",
        technical="A dificuldade muda com a inclinação corporal; os pés mantêm contacto com o solo, as pegas movem-se e ombro e tronco devem permanecer controlados.",
        start="Segurar as pegas com braços à frente, corpo alinhado e tensão no sistema.",
        movement="Fletir os cotovelos levando a cabeça entre as mãos e estendê-los para afastar o corpo.",
        trajectory="O corpo roda em torno dos pés enquanto as mãos permanecem ligadas às fitas.",
        end="Terminar antes de perder alinhamento do tronco ou posição do ombro.",
        cues=["Manter cotovelos apontados em frente.", "Corpo alinhado.", "Controlar a descida."],
        errors=["Transformar o gesto num empurrar de ombro.", "Dobrar a anca.", "Usar ancoragem instável."],
        setup=["Certificar a ancoragem.", "Ajustar fitas simetricamente.", "Escolher inclinação adequada."],
        joints=["elbow_joint", "glenohumeral_joint"],
        actions=["elbow_extension"],
        planes=["sagittal"],
        chain="mixed_chain",
        proximal_fixed="Os pés mantêm contacto com o solo; o tronco desloca-se como segmento controlado.",
        distal_fixed="Nenhum segmento distal é geometricamente fixo; as mãos mantêm contacto com pegas móveis.",
        shoulder="Em flexão, mantido relativamente estável.",
        forearm="Neutro.",
        wrist="Neutro.",
        resistance="Componente do peso corporal através das fitas.",
        rom="Flexão do cotovelo compatível com controlo do ombro e tronco.",
        resistance_profile="Aumenta quando o corpo fica mais horizontal.",
        hardest_zone="Depende da inclinação e do ângulo do cotovelo.",
        stability="Elevada no ombro, tronco e ancoragem.",
        laterality="Bilateral.",
        required_equipment=["bodyweight", "suspension_trainer"],
        optional_equipment=["rings"],
        anchorage="Ponto alto certificado.",
        space="Espaço longitudinal para inclinação.",
        limiting_joints=["elbow_joint", "glenohumeral_joint", "radiocarpal_joint"],
        regressions=["Colocar o corpo mais vertical.", "Reduzir amplitude.", "Usar pushdown com carga leve."],
    ),
]


# Independent identity review downclassified five initially enumerated candidates.
# They remain represented below as variants, so no mandatory candidate disappears.
DOWNCLASSIFIED_TO_VARIANT = {
    "standing_cable_curl",
    "elastic_band_curl",
    "concentration_curl",
    "machine_elbow_curl",
    "behind_back_wrist_curl",
    "hand_squeeze",
    "plate_pinch_carry",
    "thick_grip_hold",
    "towel_hang",
}
EXERCISES = [row for row in EXERCISES if row["exercise_id"] not in DOWNCLASSIFIED_TO_VARIANT]
for _exercise in EXERCISES:
    _exercise["safety"]["caution_types"] = {
        "equipment_or_environmental_control": _exercise["execution"]["setup"],
        "mechanical_caution": _exercise["safety"]["general_cautions"],
        "symptom_stop_rule": _exercise["execution"]["stop_conditions"],
        "specialist_review_trigger": _exercise["safety"]["specialist_review"],
    }
    if _exercise["exercise_id"] in {"farmers_carry", "suitcase_carry"}:
        _exercise["mechanics"]["segment_chain_classification"] = {
            "upper_limbs": "free_implement_isometric_support",
            "lower_limbs": "alternating_closed_chain_gait",
            "whole_body": "mixed_chain_locomotion",
        }
    if _exercise["exercise_id"] in {"suspension_bodyweight_curl", "suspension_triceps_extension"}:
        _exercise["mechanics"]["segment_chain_classification"] = {
            "feet": "closed_contact_with_floor",
            "hands": "closed_contact_with_movable_handles",
            "whole_body": "mixed_chain_unstable_movable_handle",
        }
    if _exercise["exercise_id"] in {"parallel_bar_dip", "bench_dip"}:
        _exercise["mechanics"]["movement_phases"] = {
            "descent": {
                "joint_movements": ["elbow_flexion", "shoulder_extension"],
                "muscular_control": "Controlo excêntrico da extensão do cotovelo e dos músculos que fazem regressar o ombro a neutro.",
            },
            "ascent": {
                "joint_movements": ["elbow_extension", "shoulder_flexion"],
                "muscular_control": "Extensão concêntrica do cotovelo e regresso do ombro desde extensão em direção a neutro.",
            },
        }
        _exercise["mechanics"]["action_phase_profiles"] = {
            "elbow_extension": {
                "role": "primary",
                "contraction_mode": "concentric_ascent_eccentric_descent",
                "context": "Extensão na subida e controlo da flexão na descida.",
            },
            "shoulder_extension": {
                "role": "phase_kinematic",
                "contraction_mode": "descent_under_eccentric_flexor_control",
                "context": "Movimento cinemático da descida; não representa ação concêntrica do peitoral maior.",
            },
            "shoulder_flexion": {
                "role": "primary_contextual",
                "contraction_mode": "concentric_ascent_toward_neutral",
                "context": "Regresso desde extensão em direção a neutro durante a subida.",
            },
        }
        if _exercise["exercise_id"] == "parallel_bar_dip":
            _exercise["mechanics"]["action_phase_profiles"].update(
                {
                    "shoulder_adduction": {
                        "role": "primary_contextual",
                        "contraction_mode": "concentric_ascent_eccentric_descent",
                        "context": "Contribuição dependente da trajetória do ombro nos fundos em paralelas.",
                    },
                    "scapular_depression": {
                        "role": "isometric_contextual",
                        "contraction_mode": "isometric_contextual",
                        "context": "Controlo escapular ao longo da tarefa.",
                    },
                }
            )
    if _exercise["exercise_id"] == "dead_hang":
        _exercise["mechanics"]["hang_mode"] = "passive_controlled"
        _exercise["mechanics"]["elbow_position"] = "extended_without_aggressive_locking"
        _exercise["mechanics"]["entry_exit"] = "supported_entry_and_exit_without_drop"
    if _exercise["exercise_id"] == "resisted_hand_close":
        _exercise["mechanics"]["contraction_modes"] = ["concentric", "eccentric", "optional_isometric_hold"]


def variant(
    variant_id: str,
    parent_exercise_id: str,
    name_pt_pt: str,
    classification: str,
    changes: str,
    justification: str,
    *,
    status: str = "approved_public",
    equipment_ids: list[str] | None = None,
    source_ids: list[str] | None = None,
) -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "variant_id": variant_id,
        "parent_exercise_id": parent_exercise_id,
        "name_pt_pt": name_pt_pt,
        "classification": classification,
        "changes": changes,
        "mechanical_justification": justification,
        "status": status,
        "equipment_ids": equipment_ids or [],
        "source_ids": source_ids or ["src_base_muscular_kb_v0_1_1", "src_technical_inference"],
    }


VARIANTS = [
    variant("standing_curl_straight_bar", "standing_supinated_curl", "Curl em pé com barra reta", "equipment_variant", "Barra reta e pega fixa bilateral.", "O implemento muda a liberdade do punho, mas preserva ação, posição do ombro e direção gravitacional.", equipment_ids=["straight_barbell"]),
    variant("standing_curl_ez_bar", "standing_supinated_curl", "Curl em pé com barra EZ", "grip_orientation_variant", "Barra angulada e pega semissupinada.", "A orientação altera conforto e contribuição relativa sem criar uma família mecânica nova.", equipment_ids=["ez_bar"]),
    variant("standing_curl_dumbbells", "standing_supinated_curl", "Curl em pé com halteres", "equipment_variant", "Halteres permitem trajetórias independentes.", "Unilateralidade possível não altera a identidade base.", equipment_ids=["dumbbell"]),
    variant("standing_curl_alternating", "standing_supinated_curl", "Curl alternado com halteres", "technique_variant", "Alternância entre lados.", "A ordem entre lados é configuração temporal, mantida como variante pública e não como canónico.", equipment_ids=["dumbbell"]),
    variant("standing_curl_unilateral", "standing_supinated_curl", "Curl unilateral em pé", "technique_variant", "Execução de um lado de cada vez.", "Lateralidade não cria nova identidade.", equipment_ids=["dumbbell"]),
    variant("standing_cable_curl", "standing_supinated_curl", "Curl em pé no cabo", "equipment_variant", "Polia baixa e resistência alinhada com o cabo.", "O perfil muda materialmente, mas articulação, ação e posição principal mantêm-se; fica exposto como variante.", equipment_ids=["cable_stack", "low_pulley", "straight_bar_attachment"]),
    variant("standing_unilateral_cable_curl", "standing_supinated_curl", "Curl unilateral no cabo", "equipment_variant", "Pega unilateral numa polia baixa.", "Combina equipamento e lateralidade sem justificar exercício canónico adicional.", equipment_ids=["cable_stack", "low_pulley", "single_handle"]),
    variant("standing_band_curl", "standing_supinated_curl", "Curl com banda elástica", "equipment_variant", "Resistência elástica ascendente.", "A banda altera o perfil, não a identidade articular.", equipment_ids=["elastic_band"]),
    variant("standing_machine_curl", "standing_supinated_curl", "Curl na máquina com braço junto ao tronco", "equipment_variant", "Trajetória definida por máquina.", "Só é equivalente quando ombro e eixo estão definidos; status limitado pela geometria variável.", status="approved_with_limits", equipment_ids=["selectorized_curl_machine"]),
    variant("shoulder_extended_dumbbell_curl", "shoulder_extended_supinated_curl", "Curl inclinado com halteres", "equipment_variant", "Banco inclinado e halteres.", "Manifestação gravitacional principal da identidade com ombro em extensão.", equipment_ids=["dumbbell", "incline_bench"]),
    variant("shoulder_extended_cable_curl", "shoulder_extended_supinated_curl", "Curl Bayesian no cabo", "equipment_variant", "Polia atrás do corpo.", "Mantém ombro em extensão e muda direção/perfil de resistência.", equipment_ids=["cable_stack", "low_pulley", "single_handle"]),
    variant("preacher_ez_curl", "preacher_curl", "Curl Scott com barra EZ", "equipment_variant", "Barra EZ sobre banco Scott.", "Implemento principal sem mudança de identidade.", equipment_ids=["preacher_bench", "ez_bar"]),
    variant("preacher_dumbbell_curl", "preacher_curl", "Curl Scott unilateral com halter", "equipment_variant", "Halter e um braço apoiado.", "Lateralidade e implemento não criam canónico novo.", equipment_ids=["preacher_bench", "dumbbell"]),
    variant("preacher_cable_curl", "preacher_curl", "Curl Scott no cabo", "equipment_variant", "Banco Scott e cabo.", "Muda o perfil de resistência mantendo apoio e posição do ombro.", equipment_ids=["preacher_bench", "cable_stack", "low_pulley"]),
    variant("preacher_machine_curl", "preacher_curl", "Curl Scott na máquina", "equipment_variant", "Máquina com braço apoiado.", "Equivalência depende de eixo e trajetória definidos.", status="approved_with_limits", equipment_ids=["selectorized_curl_machine"]),
    variant("preacher_plate_loaded_machine_curl", "preacher_curl", "Curl Scott em máquina carregada com discos", "equipment_variant", "Braço de alavanca e discos com apoio Scott.", "Equivalência depende de eixo, came e trajetória documentados.", status="approved_with_limits", equipment_ids=["plate_loaded_curl_machine"]),
    variant("concentration_curl", "preacher_curl", "Curl de concentração", "technique_variant", "Braço apoiado na coxa em vez de banco Scott.", "Apoio e flexão do ombro aproximam a identidade; diferenças não justificam canónico adicional no núcleo.", equipment_ids=["dumbbell", "flat_bench"]),
    variant("spider_ez_curl", "spider_curl", "Curl spider com barra EZ", "equipment_variant", "Barra EZ com peito apoiado.", "Implemento muda sem alterar posição e trajetória principal.", equipment_ids=["ez_bar", "incline_bench"]),
    variant("spider_dumbbell_curl", "spider_curl", "Curl spider com halteres", "equipment_variant", "Halteres com peito apoiado.", "Permite independência dos lados sem nova identidade.", equipment_ids=["dumbbell", "incline_bench"]),
    variant("cross_body_hammer_curl", "hammer_curl", "Curl martelo cruzado", "technique_variant", "Trajetória diagonal em direção ao ombro oposto.", "A orientação neutra mantém-se; a trajetória não fecha uma família separada.", equipment_ids=["dumbbell"]),
    variant("rope_hammer_curl", "hammer_curl", "Curl martelo com corda no cabo", "equipment_variant", "Corda numa polia baixa.", "Muda equipamento e perfil mantendo pega neutra.", equipment_ids=["cable_stack", "low_pulley", "rope_attachment"]),
    variant("straight_bar_reverse_curl", "reverse_curl", "Curl inverso com barra reta", "equipment_variant", "Barra reta em pronação.", "Implemento não altera a ação principal.", equipment_ids=["straight_barbell"]),
    variant("dumbbell_reverse_curl", "reverse_curl", "Curl inverso com halteres", "equipment_variant", "Halteres em pronação.", "Independência dos lados sem nova identidade.", equipment_ids=["dumbbell"]),
    variant("assisted_supinated_chin_up", "supinated_chin_up", "Elevação supinada assistida", "regression", "Banda ou assistência mecânica reduz a carga efetiva.", "Preserva a trajetória e cadeia cinética.", equipment_ids=["elastic_band", "pull_up_bar"]),
    variant("weighted_supinated_chin_up", "supinated_chin_up", "Elevação supinada com carga adicional", "progression", "Carga externa adicional.", "A carga é progressão e não nova identidade.", equipment_ids=["pull_up_bar", "weight_plate"]),
    variant("pronated_pull_up", "supinated_chin_up", "Elevação na barra com pega pronada", "grip_orientation_variant", "Antebraço pronado.", "Muda contribuição contextual dos flexores, mas permanece tração vertical multiarticular.", status="approved_with_limits", equipment_ids=["pull_up_bar"]),
    variant("neutral_grip_pull_up", "supinated_chin_up", "Elevação na barra com pega neutra", "grip_orientation_variant", "Antebraço neutro.", "Orientação de pega é relevante, mas tratada como variante da tração vertical.", status="approved_with_limits", equipment_ids=["pull_up_bar"]),
    variant("ring_bodyweight_curl", "suspension_bodyweight_curl", "Curl em argolas com peso corporal", "equipment_variant", "Argolas em vez de fitas com pegas.", "Mantém cadeia mista com contacto dos pés e pegas móveis.", equipment_ids=["bodyweight", "rings"]),
    variant("pushdown_straight_bar", "cable_triceps_pushdown", "Pushdown com barra", "equipment_variant", "Barra reta na polia alta.", "Implemento não cria ação diferente.", equipment_ids=["cable_stack", "high_pulley", "straight_bar_attachment"]),
    variant("pushdown_rope", "cable_triceps_pushdown", "Pushdown com corda", "equipment_variant", "Corda permite separação das mãos.", "A liberdade distal não prova identidade muscular diferente.", equipment_ids=["cable_stack", "high_pulley", "rope_attachment"]),
    variant("pushdown_unilateral", "cable_triceps_pushdown", "Pushdown unilateral", "technique_variant", "Um braço de cada vez.", "Lateralidade não cria canónico novo.", equipment_ids=["cable_stack", "high_pulley", "single_handle"]),
    variant("pushdown_band", "cable_triceps_pushdown", "Extensão descendente com banda", "equipment_variant", "Banda ancorada acima.", "Perfil elástico distinto, ação e posição preservadas.", equipment_ids=["elastic_band"]),
    variant("overhead_cable_extension", "overhead_triceps_extension", "Extensão acima da cabeça no cabo", "equipment_variant", "Cabo e corda.", "Manifestação de resistência por cabo.", equipment_ids=["cable_stack", "adjustable_pulley", "rope_attachment"]),
    variant("overhead_dumbbell_extension", "overhead_triceps_extension", "Extensão acima da cabeça com halter", "equipment_variant", "Um halter seguro com uma ou duas mãos.", "Implemento gravitacional sem nova identidade.", equipment_ids=["dumbbell"]),
    variant("overhead_ez_extension", "overhead_triceps_extension", "Extensão acima da cabeça com barra EZ", "equipment_variant", "Barra EZ bilateral.", "Implemento muda a pega, não a posição do ombro.", equipment_ids=["ez_bar"]),
    variant("overhead_band_extension", "overhead_triceps_extension", "Extensão acima da cabeça com banda", "equipment_variant", "Banda ancorada abaixo/atrás.", "Perfil elástico sem nova identidade.", equipment_ids=["elastic_band"]),
    variant("lying_ez_extension", "lying_triceps_extension", "Extensão deitada com barra EZ", "equipment_variant", "Barra EZ.", "Implemento principal do exercício.", equipment_ids=["flat_bench", "ez_bar"]),
    variant("lying_dumbbell_extension", "lying_triceps_extension", "Extensão deitada com halteres", "equipment_variant", "Halteres independentes.", "Independência dos lados sem nova identidade.", equipment_ids=["flat_bench", "dumbbell"]),
    variant("cross_body_cable_unilateral", "cross_body_cable_triceps_extension", "Extensão cruzada unilateral no cabo", "technique_variant", "Um braço cruza à frente do corpo.", "Manifestação unilateral da identidade.", equipment_ids=["cable_stack", "adjustable_pulley", "single_handle"]),
    variant("dumbbell_kickback", "triceps_kickback", "Kickback com halter", "equipment_variant", "Resistência gravitacional.", "Implemento altera o perfil sem mudar posição do ombro.", equipment_ids=["dumbbell"]),
    variant("cable_kickback", "triceps_kickback", "Kickback no cabo", "equipment_variant", "Cabo baixo ou ajustável.", "Direção do cabo mantém resistência fora da horizontal.", equipment_ids=["cable_stack", "low_pulley", "single_handle"]),
    variant("selectorized_triceps_extension", "machine_triceps_extension", "Extensão de tríceps em máquina de pesos selecionados", "equipment_variant", "Torre de pesos e came.", "Requer eixo e trajetória documentados.", status="approved_with_limits", equipment_ids=["selectorized_triceps_machine"]),
    variant("plate_loaded_triceps_extension", "machine_triceps_extension", "Extensão de tríceps em máquina de discos", "equipment_variant", "Braço de alavanca carregado com discos.", "Requer eixo e trajetória documentados.", status="approved_with_limits", equipment_ids=["plate_loaded_triceps_machine"]),
    variant("assisted_parallel_dip", "parallel_bar_dip", "Fundos assistidos", "regression", "Assistência reduz peso corporal efetivo.", "Preserva cadeia e trajetória.", equipment_ids=["parallel_bars", "elastic_band"]),
    variant("weighted_parallel_dip", "parallel_bar_dip", "Fundos com carga adicional", "progression", "Carga externa adicional.", "Progressão de carga, não identidade nova.", equipment_ids=["parallel_bars", "weight_plate"]),
    variant("bent_knee_bench_dip", "bench_dip", "Fundos no banco com joelhos fletidos", "regression", "Pés aproximados reduzem braço de alavanca.", "Configuração de dificuldade.", status="approved_with_limits", equipment_ids=["flat_bench"]),
    variant("diamond_push_up", "close_grip_push_up", "Flexão diamante", "grip_orientation_variant", "Mãos aproximadas em forma de diamante.", "Pequena alteração de base; não cria canónico.", equipment_ids=["bodyweight"]),
    variant("kneeling_close_push_up", "close_grip_push_up", "Flexão estreita com joelhos apoiados", "regression", "Joelhos reduzem carga relativa.", "Regressão de dificuldade.", equipment_ids=["bodyweight"]),
    variant("elevated_close_push_up", "close_grip_push_up", "Flexão estreita com mãos elevadas", "regression", "Mãos num apoio elevado.", "Reduz a fração do peso corporal.", equipment_ids=["bodyweight", "flat_bench"]),
    variant("close_grip_dumbbell_press", "close_grip_bench_press", "Supino fechado com halteres", "equipment_variant", "Halteres com pega neutra.", "Muda implemento e liberdade do punho, mantendo empurrar multiarticular.", equipment_ids=["dumbbell", "flat_bench"]),
    variant("ring_triceps_extension", "suspension_triceps_extension", "Extensão de tríceps em argolas", "equipment_variant", "Argolas em vez de fitas.", "Mantém cadeia mista com pegas móveis e ajuste pela inclinação.", equipment_ids=["bodyweight", "rings"]),
    variant("lever_pronation", "resisted_forearm_pronation", "Pronação com martelo ou alavanca", "equipment_variant", "Carga excêntrica ao eixo longitudinal.", "Cria torque axial mensurável e controlável.", equipment_ids=["lever_hammer"]),
    variant("cable_pronation", "resisted_forearm_pronation", "Pronação no cabo", "equipment_variant", "Pega ligada a cabo.", "Muda perfil mantendo ação.", equipment_ids=["cable_stack", "adjustable_pulley", "single_handle"]),
    variant("band_pronation", "resisted_forearm_pronation", "Pronação com banda", "equipment_variant", "Banda lateral.", "Perfil elástico mantendo ação.", equipment_ids=["elastic_band"]),
    variant("manual_pronation", "resisted_forearm_pronation", "Pronação com resistência manual", "equipment_variant", "Resistência aplicada por outra mão ou pessoa.", "Aplicação variável, adequada apenas quando controlada.", status="approved_with_limits", equipment_ids=["manual_resistance"]),
    variant("lever_supination", "resisted_forearm_supination", "Supinação com martelo ou alavanca", "equipment_variant", "Carga excêntrica ao eixo longitudinal.", "Cria torque axial mensurável e controlável.", equipment_ids=["lever_hammer"]),
    variant("cable_supination", "resisted_forearm_supination", "Supinação no cabo", "equipment_variant", "Pega ligada a cabo.", "Muda perfil mantendo ação.", equipment_ids=["cable_stack", "adjustable_pulley", "single_handle"]),
    variant("band_supination", "resisted_forearm_supination", "Supinação com banda", "equipment_variant", "Banda lateral.", "Perfil elástico mantendo ação.", equipment_ids=["elastic_band"]),
    variant("manual_supination", "resisted_forearm_supination", "Supinação com resistência manual", "equipment_variant", "Resistência aplicada manualmente.", "Aplicação variável e dependente de controlo.", status="approved_with_limits", equipment_ids=["manual_resistance"]),
    variant("barbell_wrist_curl", "supported_wrist_curl", "Flexão do punho com barra", "equipment_variant", "Barra bilateral.", "Implemento não altera a ação.", equipment_ids=["straight_barbell", "flat_bench"]),
    variant("dumbbell_wrist_curl", "supported_wrist_curl", "Flexão do punho com halteres", "equipment_variant", "Halteres independentes.", "Permite unilateralidade sem nova identidade.", equipment_ids=["dumbbell", "flat_bench"]),
    variant("cable_wrist_curl", "supported_wrist_curl", "Flexão do punho no cabo", "equipment_variant", "Cabo baixo.", "Muda perfil de resistência.", equipment_ids=["cable_stack", "low_pulley", "straight_bar_attachment"]),
    variant("band_wrist_curl", "supported_wrist_curl", "Flexão do punho com banda", "equipment_variant", "Banda elástica.", "Muda perfil de resistência.", equipment_ids=["elastic_band"]),
    variant("behind_back_wrist_curl", "supported_wrist_curl", "Flexão do punho atrás do corpo", "technique_variant", "Antebraço sem apoio e barra atrás do corpo.", "Muda setup e estabilidade, mas não a ação canónica.", status="approved_with_limits", equipment_ids=["straight_barbell"]),
    variant("barbell_wrist_extension", "supported_wrist_extension", "Extensão do punho com barra", "equipment_variant", "Barra bilateral.", "Implemento não altera a ação.", equipment_ids=["straight_barbell", "flat_bench"]),
    variant("dumbbell_wrist_extension", "supported_wrist_extension", "Extensão do punho com halteres", "equipment_variant", "Halteres independentes.", "Permite unilateralidade.", equipment_ids=["dumbbell", "flat_bench"]),
    variant("wrist_roller_flexion_direction", "wrist_roller", "Rolo de punho no sentido de flexão", "technique_variant", "Sentido de enrolamento favorece a fase de flexão.", "O mesmo dispositivo e tarefa cíclica permanecem.", status="approved_with_limits", equipment_ids=["wrist_roller"]),
    variant("wrist_roller_extension_direction", "wrist_roller", "Rolo de punho no sentido de extensão", "technique_variant", "Sentido de enrolamento favorece a fase de extensão.", "O mesmo dispositivo e tarefa cíclica permanecem.", status="approved_with_limits", equipment_ids=["wrist_roller"]),
    variant("radial_deviation_lever", "wrist_radial_deviation", "Desvio radial com alavanca", "equipment_variant", "Carga afastada do eixo.", "Aumenta torque com alavanca definida.", status="approved_with_limits", equipment_ids=["lever_hammer"]),
    variant("ulnar_deviation_lever", "wrist_ulnar_deviation", "Desvio ulnar com alavanca", "equipment_variant", "Carga afastada do eixo.", "Aumenta torque com alavanca definida.", status="approved_with_limits", equipment_ids=["lever_hammer"]),
    variant("barbell_finger_curl", "finger_curl", "Flexão dos dedos com barra", "equipment_variant", "Barra rola entre dedos e palma.", "Implemento principal da identidade.", equipment_ids=["straight_barbell"]),
    variant("band_finger_extension", "resisted_finger_extension", "Extensão dos dedos com banda", "equipment_variant", "Banda em torno dos dedos.", "Manifestação principal da identidade.", equipment_ids=["elastic_band"]),
    variant("hand_gripper_close", "resisted_hand_close", "Fecho com hand gripper", "equipment_variant", "Mola articulada com amplitude de fecho.", "É uma manifestação do fecho resistido da mão.", equipment_ids=["hand_gripper"], source_ids=["src_base_muscular_kb_v0_1_1", "src_gerodimos_grip_2021", "src_technical_inference"]),
    variant("hand_squeeze", "resisted_hand_close", "Aperto de bola macia", "equipment_variant", "Objeto deformável comprimido pela mão.", "Muda contacto e perfil, mantendo a tarefa funcional de fecho resistido.", equipment_ids=["soft_ball"], source_ids=["src_base_muscular_kb_v0_1_1", "src_gerodimos_grip_2021", "src_technical_inference"]),
    variant("adjustable_hand_gripper", "resisted_hand_close", "Fecho de hand gripper ajustável", "equipment_variant", "Resistência regulável.", "Regulação de carga não cria nova identidade.", equipment_ids=["hand_gripper"]),
    variant("barbell_support_hold", "support_grip_hold", "Sustentação estática com barra", "equipment_variant", "Barra bilateral.", "Implemento principal.", equipment_ids=["straight_barbell"]),
    variant("dumbbell_support_hold", "support_grip_hold", "Sustentação estática com halteres", "equipment_variant", "Cargas independentes.", "Implemento e lateralidade sem mudança de família.", equipment_ids=["dumbbell"]),
    variant("thick_grip_hold", "support_grip_hold", "Sustentação com pega espessa", "equipment_variant", "Barra ou halter com diâmetro aumentado.", "A interface muda a abertura da mão, mas a tarefa continua a ser sustentação estática.", status="approved_with_limits", equipment_ids=["straight_barbell", "fat_grip"], source_ids=["src_base_muscular_kb_v0_1_1", "src_kong_handle_2005", "src_krings_fat_grip_2021", "src_technical_inference"]),
    variant("kettlebell_farmers_carry", "farmers_carry", "Passeio do agricultor com kettlebells", "equipment_variant", "Kettlebells nas duas mãos.", "Implemento não altera transporte bilateral.", equipment_ids=["kettlebell"]),
    variant("thick_grip_farmers_carry", "farmers_carry", "Passeio do agricultor com pega espessa", "equipment_variant", "Diâmetro aumentado.", "Altera exigência de contacto sem nova identidade.", status="approved_with_limits", equipment_ids=["dumbbell", "fat_grip"]),
    variant("towel_carry", "farmers_carry", "Transporte com toalha", "equipment_variant", "Carga suspensa por toalha.", "Pega deformável altera contacto, mantendo transporte bilateral.", status="approved_with_limits", equipment_ids=["carry_object", "towel"]),
    variant("kettlebell_suitcase_carry", "suitcase_carry", "Transporte unilateral com kettlebell", "equipment_variant", "Kettlebell numa mão.", "Implemento não altera transporte unilateral.", equipment_ids=["kettlebell"]),
    variant("ring_dead_hang", "dead_hang", "Suspensão em argolas", "equipment_variant", "Argolas permitem rotação livre.", "Muda apoio sem eliminar suspensão.", status="approved_with_limits", equipment_ids=["bodyweight", "rings"]),
    variant("towel_hang", "dead_hang", "Suspensão em toalha", "equipment_variant", "Toalha deformável altera contacto, fricção e diâmetro efetivo.", "A interface muda, mas permanecem suspensão corporal e objetivo de suporte.", status="approved_with_limits", equipment_ids=["bodyweight", "pull_up_bar", "towel"], source_ids=["src_base_muscular_kb_v0_1_1", "src_exel_finger_hang_2023", "src_technical_inference"]),
    variant("plate_pinch_carry", "plate_pinch_hold", "Transporte em pinça com discos", "technique_variant", "Acrescenta locomoção à pinça mantida.", "A exigência corporal muda, mas a tarefa de mão continua pinça isométrica.", status="approved_with_limits", equipment_ids=["weight_plate"], source_ids=["src_base_muscular_kb_v0_1_1", "src_technical_inference"]),
]


CANDIDATE_EXCLUSIONS = [
    ("curl_21s", "excluded", "Protocolo de amplitude/repetições, não identidade de exercício."),
    ("curl_drop_set", "excluded", "Método de prescrição."),
    ("curl_rest_pause", "excluded", "Método de prescrição."),
    ("curl_brand_machine_entries", "duplicate", "Marcas não definem identidades canónicas."),
    ("pushdown_rope_as_canonical", "duplicate", "A corda é variante de implemento."),
    ("pushdown_bar_as_canonical", "duplicate", "A barra é variante de implemento."),
    ("barbell_hold_as_separate_family", "duplicate", "É variante de support_grip_hold."),
    ("dumbbell_hold_as_separate_family", "duplicate", "É variante de support_grip_hold."),
    ("minor_grip_width_entries", "excluded", "Pequenas larguras pertencem à configuração."),
    ("amrap_entries", "excluded", "Protocolo de prescrição."),
    ("tempo_entries", "excluded", "Cadência pertence à prescrição."),
    ("symmetric_center_loaded_pronation_dumbbell", "excluded", "Sem carga excêntrica relevante não produz torque axial útil."),
]


EXERCISES += [
    wrist_ex(
        "resisted_forearm_pronation",
        "Pronação resistida do antebraço",
        "Resisted forearm pronation",
        "forearm_rotation",
        ["forearm_pronation"],
        forearm="Começa supinado ou neutro e roda para pronação.",
        resistance="Aplicada por alavanca, cabo, banda ou resistência manual.",
        equipment=["lever_hammer"],
        support="Cotovelo fletido e antebraço apoiado ou firmemente estabilizado.",
    ),
    wrist_ex(
        "resisted_forearm_supination",
        "Supinação resistida do antebraço",
        "Resisted forearm supination",
        "forearm_rotation",
        ["forearm_supination"],
        forearm="Começa pronado ou neutro e roda para supinação.",
        resistance="Aplicada por alavanca, cabo, banda ou resistência manual.",
        equipment=["lever_hammer"],
        support="Cotovelo fletido e antebraço apoiado ou firmemente estabilizado.",
    ),
    wrist_ex(
        "supported_wrist_curl",
        "Flexão do punho com antebraço apoiado",
        "Supported wrist curl",
        "wrist_flexion_extension",
        ["wrist_flexion"],
        forearm="Supinado.",
        resistance="Vertical pela gravidade ou alinhada com cabo/banda.",
        equipment=["dumbbell", "flat_bench"],
    ),
    wrist_ex(
        "behind_back_wrist_curl",
        "Flexão do punho atrás do corpo",
        "Behind-the-back wrist curl",
        "wrist_flexion_extension",
        ["wrist_flexion"],
        forearm="Pronado relativamente ao tronco, com a barra segura atrás do corpo.",
        resistance="Vertical pela gravidade.",
        equipment=["straight_barbell"],
        status="approved_with_limits",
        support="Sem apoio direto do antebraço; ombro e cotovelo mantêm a barra atrás do corpo.",
    ),
    wrist_ex(
        "supported_wrist_extension",
        "Extensão do punho com antebraço apoiado",
        "Supported wrist extension",
        "wrist_flexion_extension",
        ["wrist_extension"],
        forearm="Pronado.",
        resistance="Vertical pela gravidade ou alinhada com cabo/banda.",
        equipment=["dumbbell", "flat_bench"],
    ),
    exercise(
        "wrist_roller",
        "Rolo de punho",
        "Wrist roller",
        "wrist_flexion_extension",
        "Enrolar e desenrolar uma carga através de flexão e extensão repetida do punho e dos dedos.",
        status="approved_with_limits",
        technical="Tarefa cíclica bilateral que combina punho, dedos e preensão. O sentido de enrolamento determina a predominância relativa, pelo que ambas as direções ficam como variantes.",
        start="Segurar o rolo com os braços numa posição estável e o cabo totalmente desenrolado.",
        movement="Rodar alternadamente os punhos para enrolar a carga; desenrolar de forma controlada.",
        trajectory="A carga sobe e desce verticalmente enquanto o rolo gira.",
        end="Terminar antes de o punho perder alinhamento ou a carga cair.",
        cues=["Usar movimentos curtos do punho.", "Manter ombros relaxados.", "Controlar também a descida."],
        errors=["Rodar todo o braço.", "Deixar a carga cair.", "Usar carga que força compensação do ombro."],
        setup=["Verificar corda e fixação.", "Escolher carga leve.", "Garantir espaço livre sob a carga."],
        joints=["radiocarpal_joint", "midcarpal_joint", "finger_metacarpophalangeal_joints", "finger_proximal_interphalangeal_joints"],
        actions=["wrist_flexion", "wrist_extension", "finger_mcp_flexion", "finger_pip_flexion"],
        planes=["sagittal"],
        chain="open_chain",
        proximal_fixed="Braços mantêm o rolo numa posição estável.",
        distal_fixed="Mãos em contacto contínuo com o rolo.",
        shoulder="Em flexão baixa a moderada ou junto ao tronco, conforme o dispositivo.",
        forearm="Pronado.",
        wrist="Alterna flexão e extensão.",
        resistance="Carga suspensa verticalmente por uma corda.",
        rom="Pequenos arcos repetidos, sem forçar amplitude terminal.",
        resistance_profile="A carga externa é constante, mas a fadiga acumulada muda a dificuldade.",
        hardest_zone="Não existe zona angular única; a exigência acumula com as rotações.",
        stability="Moderada no ombro e elevada na preensão.",
        laterality="Bilateral.",
        required_equipment=["wrist_roller"],
        optional_equipment=["weight_plate"],
        space="Espaço vertical livre para a carga suspensa.",
        limiting_joints=["radiocarpal_joint", "elbow_joint", "glenohumeral_joint"],
        regressions=["Reduzir carga.", "Reduzir a distância de enrolamento.", "Apoiar os antebraços quando o dispositivo o permitir."],
    ),
    wrist_ex(
        "wrist_radial_deviation",
        "Desvio radial resistido do punho",
        "Resisted wrist radial deviation",
        "wrist_deviation",
        ["wrist_radial_deviation"],
        forearm="Neutro ou pronado, estabilizado.",
        resistance="Aplicada por halter, alavanca, cabo ou banda no plano frontal.",
        equipment=["dumbbell"],
        status="approved_with_limits",
    ),
    wrist_ex(
        "wrist_ulnar_deviation",
        "Desvio ulnar resistido do punho",
        "Resisted wrist ulnar deviation",
        "wrist_deviation",
        ["wrist_ulnar_deviation"],
        forearm="Neutro ou pronado, estabilizado.",
        resistance="Aplicada por halter, alavanca, cabo ou banda no plano frontal.",
        equipment=["dumbbell"],
        status="approved_with_limits",
    ),
    exercise(
        "finger_curl",
        "Flexão resistida dos dedos",
        "Resisted finger curl",
        "digital_flexion_extension",
        "Flexão dos dedos contra resistência, mantendo o punho controlado.",
        technical="Carrega flexores superficiais e profundos dos dedos através das articulações MCP, PIP e DIP; a contribuição varia com a forma do objeto e posição do punho.",
        start="Apoiar os antebraços e segurar o implemento nas falanges com dedos parcialmente estendidos.",
        movement="Fechar os dedos para trazer o implemento para a palma; abrir de forma controlada sem o deixar cair.",
        trajectory="O implemento rola ou desloca-se entre falanges e palma.",
        end="Terminar com preensão segura, sem flexão excessiva do punho.",
        cues=["Mover pelos dedos.", "Manter o punho estável.", "Usar carga pequena e segura."],
        errors=["Deixar a barra rolar sem controlo.", "Substituir o gesto por flexão do punho.", "Usar carga que ameaça cair."],
        setup=["Usar barra leve ou ferramenta própria.", "Apoiar antebraços.", "Manter área livre abaixo."],
        joints=["finger_metacarpophalangeal_joints", "finger_proximal_interphalangeal_joints", "finger_distal_interphalangeal_joints"],
        actions=["finger_mcp_flexion", "finger_pip_flexion", "finger_dip_flexion"],
        planes=["sagittal"],
        chain="open_chain",
        proximal_fixed="Antebraço apoiado.",
        distal_fixed="Nenhum; dedos movem o implemento.",
        shoulder="Neutro.",
        forearm="Supinado.",
        wrist="Neutro ou ligeiramente estendido, sem movimento deliberado.",
        resistance="Vertical pela gravidade ou definida por ferramenta.",
        rom="Da extensão digital controlada à preensão completa sem dor.",
        resistance_profile="Depende do diâmetro e da posição do implemento nos dedos.",
        hardest_zone="Perto da abertura, quando o objeto está mais distal e menos seguro.",
        stability="Moderada no punho e antebraço.",
        laterality="Bilateral ou unilateral.",
        required_equipment=["straight_barbell"],
        optional_equipment=["dumbbell"],
        limiting_joints=["finger_metacarpophalangeal_joints", "finger_proximal_interphalangeal_joints", "finger_distal_interphalangeal_joints"],
        regressions=["Usar objeto mais leve.", "Reduzir abertura dos dedos.", "Usar bola macia."],
    ),
    exercise(
        "resisted_finger_extension",
        "Extensão dos dedos com banda",
        "Band-resisted finger extension",
        "digital_flexion_extension",
        "Abrir os dedos contra uma banda colocada à volta das falanges.",
        technical="Exercício de resistência elástica para extensão MCP e contribuição através das expansões extensoras. A carga individual de cada dedo não é uniforme.",
        start="Colocar uma banda leve em torno dos dedos com a mão fechada de forma confortável.",
        movement="Abrir os dedos contra a banda e regressar lentamente.",
        trajectory="Os dedos afastam-se e estendem-se a partir da mão.",
        end="Terminar antes de a banda escorregar ou forçar as articulações.",
        cues=["Abrir de forma uniforme.", "Manter o punho neutro.", "Usar banda leve."],
        errors=["Usar banda demasiado forte.", "Deixar a banda enrolar nas articulações.", "Compensar com extensão do punho."],
        setup=["Inspecionar a banda.", "Escolher resistência baixa.", "Posicionar a banda fora das pregas articulares."],
        joints=["finger_metacarpophalangeal_joints", "finger_proximal_interphalangeal_joints", "finger_distal_interphalangeal_joints"],
        actions=["finger_mcp_extension", "finger_pip_extension", "finger_dip_extension"],
        planes=["sagittal"],
        chain="open_chain",
        proximal_fixed="Antebraço e punho estáveis.",
        distal_fixed="Banda em contacto com os dedos, sem ancoragem externa.",
        shoulder="Neutro.",
        forearm="Neutro ou pronado.",
        wrist="Neutro.",
        resistance="Elástica, aumentando com a abertura.",
        rom="Da flexão confortável à extensão controlada dos dedos.",
        resistance_profile="Ascendente com o alongamento da banda.",
        hardest_zone="Perto da abertura máxima.",
        stability="Baixa.",
        laterality="Unilateral.",
        required_equipment=["elastic_band"],
        limiting_joints=["finger_metacarpophalangeal_joints", "finger_proximal_interphalangeal_joints", "finger_distal_interphalangeal_joints"],
        regressions=["Usar banda mais leve.", "Reduzir amplitude.", "Mover menos dedos de cada vez apenas sob orientação adequada."],
    ),
]


EXERCISES += [
    grip_ex(
        "resisted_hand_close",
        "Fecho resistido da mão",
        "Resisted hand close",
        "grip_dynamic",
        short="Fechar a mão contra resistência através de preensão de esmagamento controlada.",
        movement="Fechar as pegas com os dedos e polegar; regressar sem deixar a mola abrir bruscamente.",
        equipment=["hand_gripper"],
        chain="open_chain",
        resistance="Mola ou mecanismo do gripper.",
        stability="Baixa proximalmente; elevada exigência local de dedos e polegar.",
        source_ids=["src_base_muscular_kb_v0_1_1", "src_gerodimos_grip_2021", "src_technical_inference"],
    ),
    grip_ex(
        "hand_squeeze",
        "Aperto de bola",
        "Soft-ball hand squeeze",
        "grip_isometric",
        short="Comprimir uma bola macia com a mão inteira para treinar preensão geral.",
        movement="Comprimir a bola de forma progressiva, manter brevemente e libertar sob controlo.",
        equipment=["soft_ball"],
        chain="open_chain",
        resistance="Deformação elástica da bola.",
        stability="Baixa.",
    ),
    grip_ex(
        "plate_pinch_hold",
        "Pinça isométrica com discos",
        "Plate pinch hold",
        "grip_isometric",
        short="Sustentar discos por pinça entre o polegar e os dedos.",
        movement="Elevar os discos apenas o suficiente para ficarem livres e manter a pinça sem deslocamento.",
        equipment=["weight_plate"],
        chain="open_chain",
        resistance="Peso dos discos pela gravidade, limitado pela fricção da superfície.",
        stability="Moderada no punho e ombro.",
        joints=["thumb_carpometacarpal_joint", "thumb_metacarpophalangeal_joint", "finger_metacarpophalangeal_joints", "radiocarpal_joint"],
        actions=["thumb_cmc_adduction", "thumb_mcp_flexion", "finger_mcp_flexion"],
    ),
    grip_ex(
        "plate_pinch_carry",
        "Transporte em pinça com discos",
        "Plate pinch carry",
        "loaded_carry",
        short="Caminhar enquanto se mantêm discos em pinça, combinando preensão e transporte.",
        movement="Elevar os discos, caminhar numa trajetória curta e pousá-los de forma controlada.",
        equipment=["weight_plate"],
        chain="mixed_chain",
        resistance="Peso dos discos pela gravidade durante deslocamento.",
        stability="Elevada no punho, ombro e tronco durante a marcha.",
        joints=["thumb_carpometacpal_joint"] if False else ["thumb_carpometacarpal_joint", "thumb_metacarpophalangeal_joint", "finger_metacarpophalangeal_joints", "radiocarpal_joint"],
        actions=["thumb_cmc_adduction", "thumb_mcp_flexion", "finger_mcp_flexion"],
        space="Percurso plano e livre para transporte.",
    ),
    grip_ex(
        "support_grip_hold",
        "Sustentação estática com barra",
        "Static support grip hold",
        "grip_isometric",
        short="Manter uma barra ou halteres suspensos nas mãos sem deslocamento.",
        movement="Elevar o implemento para uma posição segura e manter a preensão antes de o pousar.",
        equipment=["straight_barbell"],
        chain="open_chain",
        resistance="Carga vertical pela gravidade.",
        stability="Moderada no punho, cotovelo, ombro e tronco.",
        source_ids=["src_base_muscular_kb_v0_1_1", "src_kong_handle_2005", "src_technical_inference"],
    ),
    grip_ex(
        "thick_grip_hold",
        "Sustentação com pega espessa",
        "Thick-grip hold",
        "grip_isometric",
        short="Manter um implemento de pega espessa, exigindo preensão em mão mais aberta.",
        movement="Elevar e manter o implemento sem permitir que a pega rode ou escape.",
        equipment=["fat_grip", "dumbbell"],
        chain="open_chain",
        resistance="Carga vertical pela gravidade com maior diâmetro de contacto.",
        stability="Moderada a elevada na mão e punho.",
        status="approved_with_limits",
    ),
    grip_ex(
        "farmers_carry",
        "Passeio do agricultor",
        "Farmer's carry",
        "loaded_carry",
        short="Transportar cargas nas duas mãos mantendo preensão, postura e marcha controladas.",
        movement="Elevar as cargas, caminhar em linha controlada e pousá-las sem perder a preensão.",
        equipment=["dumbbell"],
        chain="mixed_chain",
        resistance="Cargas verticais nas duas mãos durante a marcha.",
        stability="Elevada no corpo inteiro; preensão pode ser limitante.",
        space="Percurso plano e livre para marcha.",
        source_ids=["src_base_muscular_kb_v0_1_1", "src_winwood_farmer_2014", "src_ellestad_loaded_carry_2024", "src_technical_inference"],
    ),
    grip_ex(
        "suitcase_carry",
        "Transporte unilateral tipo mala",
        "Suitcase carry",
        "loaded_carry",
        short="Transportar uma carga numa só mão, mantendo preensão e controlo lateral do tronco.",
        movement="Elevar a carga, caminhar sem inclinar o tronco e pousar de forma controlada.",
        equipment=["dumbbell"],
        chain="mixed_chain",
        resistance="Carga vertical unilateral durante a marcha.",
        stability="Elevada no punho, ombro e controlo lateral do tronco.",
        space="Percurso plano e livre para marcha.",
        source_ids=["src_base_muscular_kb_v0_1_1", "src_bordelon_carry_2021", "src_ellestad_loaded_carry_2024", "src_technical_inference"],
    ),
    grip_ex(
        "dead_hang",
        "Suspensão passiva controlada na barra",
        "Dead hang",
        "suspension_support",
        short="Suspender o peso corporal numa barra fixa mantendo a pega segura.",
        movement="Assumir suspensão controlada e manter o contacto; sair através de apoio seguro, sem largar em queda.",
        equipment=["bodyweight", "pull_up_bar"],
        chain="closed_chain",
        resistance="Peso corporal vertical através das mãos.",
        stability="Elevada exigência de preensão e tolerância do ombro.",
        status="approved_with_limits",
        joints=["glenohumeral_joint", "scapulothoracic_articulation", "elbow_joint", "radiocarpal_joint", "finger_metacarpophalangeal_joints", "finger_proximal_interphalangeal_joints", "finger_distal_interphalangeal_joints"],
        limiting=["glenohumeral_joint", "scapulothoracic_articulation", "elbow_joint", "radiocarpal_joint", "finger_metacarpophalangeal_joints"],
        space="Espaço vertical livre e apoio seguro para entrar/sair.",
        anchorage="Barra fixa certificada, inspecionada e com capacidade adequada.",
        source_ids=["src_base_muscular_kb_v0_1_1", "src_exel_finger_hang_2023", "src_technical_inference"],
    ),
    grip_ex(
        "towel_hang",
        "Suspensão em toalha",
        "Towel hang",
        "suspension_support",
        short="Suspender o peso corporal segurando uma toalha fixa, aumentando a exigência de preensão e fricção.",
        movement="Segurar a toalha, assumir suspensão controlada e sair sem largar em queda.",
        equipment=["bodyweight", "pull_up_bar", "towel"],
        chain="closed_chain",
        resistance="Peso corporal através de uma pega deformável e vertical.",
        stability="Elevada exigência de preensão, ombro e segurança da ancoragem.",
        status="approved_with_limits",
        limiting=["glenohumeral_joint", "radiocarpal_joint", "finger_metacarpophalangeal_joints"],
        space="Espaço vertical livre e apoio seguro.",
    ),
    grip_ex(
        "parallel_bar_support_hold",
        "Apoio isométrico nas paralelas",
        "Parallel-bar support hold",
        "upper_limb_support",
        short="Sustentar o corpo com os braços estendidos nas paralelas, mantendo mãos, cotovelos e ombros estáveis.",
        movement="Elevar-se para apoio, manter cotovelos estendidos e sair através de apoio controlado.",
        equipment=["bodyweight", "parallel_bars"],
        chain="closed_chain",
        resistance="Peso corporal transmitido verticalmente pelas mãos.",
        stability="Elevada no punho, cotovelo, ombro, escápula e tronco.",
        joints=["elbow_joint", "radiocarpal_joint", "glenohumeral_joint", "scapulothoracic_articulation"],
        actions=["elbow_extension", "scapular_depression"],
        limiting=["elbow_joint", "radiocarpal_joint", "glenohumeral_joint"],
        space="Espaço livre em torno e por baixo das paralelas.",
    ),
    exercise(
        "resisted_thumb_opposition",
        "Oposição resistida do polegar",
        "Resisted thumb opposition",
        "thumb_specific",
        "Oposição do polegar contra resistência leve, mantida fora da camada pública inicial.",
        status="specialist_review",
        public_eligible=False,
        technical="Tarefa específica dos músculos tenares e do controlo carpometacárpico do polegar; fica em revisão especialista por proximidade a usos clínicos.",
        start="Mão apoiada e polegar numa posição confortável.",
        movement="Levar a polpa do polegar em direção aos dedos contra resistência manual leve.",
        trajectory="Movimento multiplanar de oposição.",
        end="Terminar antes de dor, colapso da articulação ou compensação do punho.",
        cues=["Usar resistência mínima.", "Mover sem dor.", "Manter o punho estável."],
        errors=["Forçar a base do polegar.", "Usar resistência alta.", "Aplicar em presença de dor sem avaliação."],
        setup=["Apoiar a mão.", "Aplicar resistência manual graduada.", "Não usar como prescrição clínica."],
        joints=["thumb_carpometacarpal_joint"],
        actions=["thumb_opposition"],
        planes=["multiplanar"],
        chain="open_chain",
        proximal_fixed="Mão e punho apoiados.",
        distal_fixed="Polegar move-se contra resistência manual.",
        shoulder="Neutro.",
        forearm="Neutro.",
        wrist="Neutro.",
        resistance="Manual e leve.",
        rom="Apenas amplitude confortável.",
        resistance_profile="Dependente da aplicação manual.",
        hardest_zone="Não definida para uso público.",
        stability="Baixa.",
        laterality="Unilateral.",
        required_equipment=["manual_resistance"],
        limiting_joints=["thumb_carpometacpal_joint"] if False else ["thumb_carpometacarpal_joint"],
        regressions=["Movimento ativo sem resistência."],
        specialist_review="Obrigatória antes de qualquer utilização clínica ou pós-lesão.",
    ),
]


# Apply the identity decision after every catalogue family has been assembled.
EXERCISES = [row for row in EXERCISES if row["exercise_id"] not in DOWNCLASSIFIED_TO_VARIANT]
for _exercise in EXERCISES:
    _exercise["safety"]["caution_types"] = {
        "equipment_or_environmental_control": _exercise["execution"]["setup"],
        "mechanical_caution": _exercise["safety"]["general_cautions"],
        "symptom_stop_rule": _exercise["execution"]["stop_conditions"],
        "specialist_review_trigger": _exercise["safety"]["specialist_review"],
    }
    if _exercise["exercise_id"] in {"farmers_carry", "suitcase_carry"}:
        _exercise["mechanics"]["segment_chain_classification"] = {
            "upper_limbs": "free_implement_isometric_support",
            "lower_limbs": "alternating_closed_chain_gait",
            "whole_body": "mixed_chain_locomotion",
        }
    if _exercise["exercise_id"] == "dead_hang":
        _exercise["mechanics"]["hang_mode"] = "passive_controlled"
        _exercise["mechanics"]["elbow_position"] = "extended_without_aggressive_locking"
        _exercise["mechanics"]["entry_exit"] = "supported_entry_and_exit_without_drop"
    if _exercise["exercise_id"] == "resisted_hand_close":
        _exercise["mechanics"]["contraction_modes"] = ["concentric", "eccentric", "optional_isometric_hold"]


MUSCLE_NAMES = {}
COMPONENT_PARENT = {}
JOINT_IDS = set()
ACTION_IDS = set()
EQUIPMENT_IDS = {row[0] for row in EQUIPMENT}
SOURCE_IDS = {row["source_id"] for row in SOURCES}


def load_base_ids() -> None:
    global MUSCLE_NAMES, COMPONENT_PARENT, JOINT_IDS, ACTION_IDS
    export = BASE / "13_EXPORTS"
    muscles = []
    with (export / "muscles.jsonl").open(encoding="utf-8") as fh:
        for line in fh:
            row = json.loads(line)
            muscles.append(row)
    MUSCLE_NAMES = {
        row["canonical_id"]: row["names"]["pt_pt"]
        for row in muscles
    }
    with (export / "muscle_components.jsonl").open(encoding="utf-8") as fh:
        for line in fh:
            row = json.loads(line)
            COMPONENT_PARENT[row["canonical_id"]] = row["parent_muscle_id"]
    JOINT_IDS = {row["canonical_id"] for row in json.loads((export / "joints.json").read_text(encoding="utf-8"))}
    ACTION_IDS = {
        row["canonical_id"]
        for filename in ("joint_actions.json", "functional_actions.json")
        for row in json.loads((export / filename).read_text(encoding="utf-8"))
    }


def mr(
    muscle_id: str,
    role: str,
    context: str,
    *,
    component_id: str = "",
    confidence: str = "moderate_confidence",
    evidence_type: str = "functional_anatomy_and_technical_inference",
    emphasis: str = "plausible_mechanical_emphasis",
    limitations: str = "A contribuição relativa depende da técnica, posição, carga e indivíduo; não implica isolamento.",
    sources: list[str] | None = None,
    grip_role: str | None = None,
    grip_limiter_default: str | None = None,
) -> dict:
    resolved_grip_role = grip_role or ("potential_limiter" if role == "grip_limiter" else "not_applicable")
    resolved_grip_limiter = grip_limiter_default or ("possible" if role == "grip_limiter" else "not_applicable")
    return {
        "muscle_id": muscle_id,
        "component_id": component_id,
        "role": role,
        "role_scope": "default_potential_limiter_not_observed_series_outcome" if role == "grip_limiter" else "task_context_role",
        "grip_role_default": resolved_grip_role,
        "grip_limiter_default": resolved_grip_limiter,
        "grip_limiter_observed": "unknown",
        "context": context,
        "confidence": confidence,
        "evidence_type": evidence_type,
        "emphasis_evidence": emphasis,
        "limitations": limitations,
        "source_ids": sources or ["src_base_muscular_kb_v0_1_1", "src_technical_inference"],
    }


BICEPS_COMPONENTS = [
    mr("biceps_brachii", "primary_contextual", "Componente do bicípite durante flexão supinada.", component_id="biceps_brachii_long_head", confidence="moderate_confidence", emphasis="insufficient_evidence"),
    mr("biceps_brachii", "primary_contextual", "Componente do bicípite durante flexão supinada.", component_id="biceps_brachii_short_head", confidence="moderate_confidence", emphasis="insufficient_evidence"),
]
TRICEPS_COMPONENTS = [
    mr("triceps_brachii", "primary_contextual", "Componente do tricípite durante extensão do cotovelo.", component_id="triceps_brachii_long_head", confidence="moderate_confidence", emphasis="insufficient_evidence"),
    mr("triceps_brachii", "primary_contextual", "Componente do tricípite durante extensão do cotovelo.", component_id="triceps_brachii_lateral_head", confidence="moderate_confidence", emphasis="insufficient_evidence"),
    mr("triceps_brachii", "primary_contextual", "Componente do tricípite durante extensão do cotovelo.", component_id="triceps_brachii_medial_head", confidence="moderate_confidence", emphasis="insufficient_evidence"),
]


def muscle_template(exercise_id: str) -> list[dict]:
    supinated_local = {
        "standing_supinated_curl",
        "shoulder_extended_supinated_curl",
        "preacher_curl",
        "spider_curl",
    }
    if exercise_id in supinated_local:
        rows = [
            mr("biceps_brachii", "primary_contextual", "Flexão do cotovelo com antebraço supinado.", confidence="moderate_confidence"),
            mr("brachialis", "primary", "Flexão do cotovelo independentemente da rotação do antebraço.", confidence="moderate_confidence"),
            mr("brachioradialis", "secondary", "Contribuição contextual para flexão do cotovelo."),
            mr("flexor_digitorum_superficialis", "grip_limiter", "Mantém a pega no implemento.", emphasis="weak_or_indirect_evidence"),
            mr("flexor_digitorum_profundus", "grip_limiter", "Mantém a pega no implemento.", emphasis="weak_or_indirect_evidence"),
            mr("extensor_carpi_radialis_brevis", "stabilizer", "Estabiliza o punho contra flexão indesejada.", emphasis="plausible_mechanical_emphasis"),
        ] + [dict(row) for row in BICEPS_COMPONENTS]
        if exercise_id == "shoulder_extended_supinated_curl":
            for row in rows:
                if row.get("component_id") == "biceps_brachii_long_head":
                    row["context"] = "Cabeça longa colocada em maior comprimento pelo ombro em extensão; não se presume superioridade."
                    row["source_ids"] = ["src_base_muscular_kb_v0_1_1", "src_oliveira_biceps_2009", "src_attarieh_curls_2025", "src_vigotsky_semg_2018"]
        return rows
    if exercise_id == "hammer_curl":
        return [
            mr("brachialis", "primary", "Flexão do cotovelo com antebraço neutro.", confidence="high_confidence"),
            mr("brachioradialis", "primary_contextual", "Orientação neutra favorece participação mecânica contextual.", confidence="moderate_confidence"),
            mr("biceps_brachii", "secondary", "Contribui para flexão do cotovelo sem vantagem de supinação."),
            mr("flexor_digitorum_superficialis", "grip_limiter", "Mantém a pega.", emphasis="weak_or_indirect_evidence"),
            mr("extensor_carpi_radialis_brevis", "stabilizer", "Estabiliza o punho."),
        ]
    if exercise_id == "reverse_curl":
        return [
            mr("brachialis", "primary", "Flexão do cotovelo com antebraço pronado.", confidence="high_confidence"),
            mr("brachioradialis", "primary_contextual", "Contribuição relevante em pronação, dependente do ângulo.", confidence="moderate_confidence"),
            mr("biceps_brachii", "secondary", "Contribuição reduzida pela posição pronada, sem ser nula."),
            mr("extensor_carpi_radialis_longus", "stabilizer", "Estabiliza o punho pronado."),
            mr("extensor_carpi_radialis_brevis", "stabilizer", "Estabiliza o punho pronado."),
            mr("flexor_digitorum_profundus", "grip_limiter", "Mantém a pega pronada.", emphasis="weak_or_indirect_evidence"),
        ]
    if exercise_id in {"supinated_chin_up", "suspension_bodyweight_curl"}:
        rows = [
            mr("biceps_brachii", "primary_contextual", "Flexão do cotovelo numa tarefa multiarticular ou de cadeia mista.", confidence="moderate_confidence"),
            mr("brachialis", "primary_contextual", "Flexão do cotovelo numa tarefa multiarticular ou de cadeia mista.", confidence="moderate_confidence"),
            mr("brachioradialis", "secondary", "Auxilia a flexão do cotovelo."),
            mr("flexor_digitorum_profundus", "grip_limiter", "A preensão pode limitar a tarefa.", emphasis="weak_or_indirect_evidence"),
            mr("flexor_digitorum_superficialis", "grip_limiter", "A preensão pode limitar a tarefa.", emphasis="weak_or_indirect_evidence"),
            mr("trapezius", "stabilizer", "Controlo escapular contextual."),
        ] + [dict(row) for row in BICEPS_COMPONENTS]
        if exercise_id == "supinated_chin_up":
            rows.insert(
                5,
                mr("latissimus_dorsi", "primary", "Move o ombro na tração vertical; não é alvo de expansão deste catálogo."),
            )
        else:
            rows.insert(
                5,
                mr(
                    "latissimus_dorsi",
                    "stabilizer",
                    "Contribuição isométrica contextual para manter o ombro; o exercício não inclui uma remada.",
                    confidence="low_confidence",
                    emphasis="weak_or_indirect_evidence",
                ),
            )
        return rows
    local_triceps = {
        "cable_triceps_pushdown",
        "overhead_triceps_extension",
        "lying_triceps_extension",
        "cross_body_cable_triceps_extension",
        "triceps_kickback",
        "machine_triceps_extension",
        "suspension_triceps_extension",
    }
    if exercise_id in local_triceps:
        rows = [
            mr("triceps_brachii", "primary", "Extensão do cotovelo.", confidence="high_confidence"),
            mr("anconeus", "synergist", "Auxilia a extensão e controlo do cotovelo."),
            mr("extensor_carpi_radialis_brevis", "stabilizer", "Estabiliza o punho."),
        ] + [dict(row) for row in TRICEPS_COMPONENTS]
        if exercise_id == "overhead_triceps_extension":
            for row in rows:
                if row.get("component_id") == "triceps_brachii_long_head":
                    row["context"] = "Cabeça longa em maior comprimento com ombro elevado; existe evidência longitudinal específica, sem isolamento."
                    row["emphasis_evidence"] = "moderate_supported_emphasis"
                    row["source_ids"] = ["src_base_muscular_kb_v0_1_1", "src_maeo_triceps_2023", "src_kholinne_triceps_2018"]
        return rows
    if exercise_id in {"parallel_bar_dip", "bench_dip"}:
        rows = [
            mr("triceps_brachii", "primary_contextual", "Extensão do cotovelo numa tarefa multiarticular.", confidence="high_confidence"),
            mr(
                "pectoralis_major",
                "primary_contextual" if exercise_id == "parallel_bar_dip" else "secondary",
                "Controla excentricamente a entrada em extensão do ombro e contribui para o regresso em direção a neutro na subida.",
                confidence="moderate_confidence",
            ),
            mr(
                "deltoid",
                "secondary",
                "A porção anterior controla a descida e contribui contextualmente para o regresso do ombro em direção a neutro.",
                confidence="moderate_confidence",
                emphasis="insufficient_evidence",
            ),
            mr("anconeus", "synergist", "Auxilia extensão do cotovelo."),
            mr("serratus_anterior", "stabilizer", "Controlo escapular contextual."),
        ] + [dict(row) for row in TRICEPS_COMPONENTS]
        return rows
    if exercise_id in {"close_grip_push_up", "close_grip_bench_press"}:
        rows = [
            mr("triceps_brachii", "primary_contextual", "Extensão do cotovelo numa tarefa multiarticular.", confidence="high_confidence"),
            mr("pectoralis_major", "primary_contextual", "Contribui para a adução horizontal do ombro no empurrar.", confidence="moderate_confidence"),
            mr("deltoid", "secondary", "Porção anterior contribui para o ombro.", emphasis="insufficient_evidence"),
            mr("anconeus", "synergist", "Auxilia extensão do cotovelo."),
            mr("serratus_anterior", "stabilizer", "Controlo escapular contextual."),
        ] + [dict(row) for row in TRICEPS_COMPONENTS]
        return rows
    if exercise_id == "resisted_forearm_pronation":
        return [
            mr("pronator_teres", "primary", "Pronação resistida.", confidence="high_confidence"),
            mr("pronator_quadratus", "primary", "Pronação resistida.", confidence="high_confidence"),
            mr("brachioradialis", "neutralizer", "Pode ajudar retorno à posição neutra conforme o início.", confidence="low_confidence", emphasis="weak_or_indirect_evidence"),
            mr("extensor_carpi_radialis_brevis", "stabilizer", "Estabiliza o punho."),
        ]
    if exercise_id == "resisted_forearm_supination":
        return [
            mr("supinator", "primary", "Supinação resistida.", confidence="high_confidence"),
            mr("biceps_brachii", "primary_contextual", "Supinação e flexão do cotovelo dependentes do ângulo.", confidence="high_confidence"),
            mr("brachioradialis", "neutralizer", "Pode contribuir para retorno à posição neutra.", confidence="low_confidence", emphasis="weak_or_indirect_evidence"),
            mr("extensor_carpi_radialis_brevis", "stabilizer", "Estabiliza o punho."),
        ]
    if exercise_id == "supported_wrist_curl":
        return [
            mr("flexor_carpi_radialis", "primary", "Flexão do punho com neutralização de desvio.", confidence="high_confidence"),
            mr("flexor_carpi_ulnaris", "primary", "Flexão do punho com neutralização de desvio.", confidence="high_confidence"),
            mr("palmaris_longus", "secondary", "Contribui quando presente."),
            mr("flexor_digitorum_superficialis", "synergist", "Pode contribuir se a pega for fechada."),
            mr("flexor_digitorum_profundus", "synergist", "Pode contribuir se a pega for fechada."),
        ]
    if exercise_id == "supported_wrist_extension":
        return [
            mr("extensor_carpi_radialis_longus", "primary", "Extensão do punho com neutralização de desvio.", confidence="high_confidence"),
            mr("extensor_carpi_radialis_brevis", "primary", "Extensão do punho com neutralização de desvio.", confidence="high_confidence"),
            mr("extensor_carpi_ulnaris", "primary", "Extensão do punho com neutralização de desvio.", confidence="high_confidence"),
            mr("extensor_digitorum", "secondary", "Contribuição contextual se os dedos estiverem ativos."),
        ]
    if exercise_id == "wrist_roller":
        return [
            mr("flexor_carpi_radialis", "primary_contextual", "Fase de enrolamento em flexão."),
            mr("flexor_carpi_ulnaris", "primary_contextual", "Fase de enrolamento em flexão."),
            mr("extensor_carpi_radialis_longus", "primary_contextual", "Fase de enrolamento em extensão."),
            mr("extensor_carpi_radialis_brevis", "primary_contextual", "Fase de enrolamento em extensão."),
            mr("extensor_carpi_ulnaris", "primary_contextual", "Fase de enrolamento em extensão."),
            mr("flexor_digitorum_profundus", "grip_limiter", "Mantém contacto no rolo.", emphasis="weak_or_indirect_evidence"),
        ]
    if exercise_id == "wrist_radial_deviation":
        return [
            mr("flexor_carpi_radialis", "primary", "Desvio radial."),
            mr("extensor_carpi_radialis_longus", "primary", "Desvio radial."),
            mr("extensor_carpi_radialis_brevis", "primary", "Desvio radial."),
            mr("abductor_pollicis_longus", "secondary", "Contribuição radial contextual."),
        ]
    if exercise_id == "wrist_ulnar_deviation":
        return [
            mr("flexor_carpi_ulnaris", "primary", "Desvio ulnar."),
            mr("extensor_carpi_ulnaris", "primary", "Desvio ulnar."),
        ]
    if exercise_id == "finger_curl":
        return [
            mr("flexor_digitorum_profundus", "primary", "Flexão DIP e contribuição para PIP/MCP.", confidence="high_confidence"),
            mr("flexor_digitorum_superficialis", "primary", "Flexão PIP e contribuição MCP.", confidence="high_confidence"),
            mr("flexor_pollicis_longus", "secondary", "Estabiliza a pega pelo polegar."),
            mr("extensor_carpi_radialis_brevis", "stabilizer", "Estabiliza o punho."),
            mr("extensor_carpi_ulnaris", "stabilizer", "Estabiliza o punho."),
        ]
    if exercise_id == "resisted_finger_extension":
        return [
            mr("extensor_digitorum", "primary", "Extensão MCP e contribuição pelas expansões extensoras.", confidence="high_confidence"),
            mr("extensor_indicis", "primary_contextual", "Extensão do indicador."),
            mr("extensor_digiti_minimi", "primary_contextual", "Extensão do quinto dedo."),
            mr("lumbrical_hand_1", "synergist", "Coordenação contextual das expansões extensoras.", confidence="low_confidence"),
            mr("extensor_carpi_radialis_brevis", "stabilizer", "Estabiliza o punho."),
        ]
    if exercise_id == "resisted_thumb_opposition":
        return [
            mr("opponens_pollicis", "specialist_review", "Oposição do polegar.", confidence="high_confidence", emphasis="specialist_review"),
            mr("abductor_pollicis_brevis", "specialist_review", "Contribuição contextual para oposição.", confidence="moderate_confidence", emphasis="specialist_review"),
            mr("flexor_pollicis_brevis", "specialist_review", "Contribuição contextual para oposição.", confidence="moderate_confidence", emphasis="specialist_review"),
        ]
    if exercise_id in {"plate_pinch_hold", "plate_pinch_carry"}:
        return [
            mr("adductor_pollicis", "primary", "Produz força de pinça do polegar.", confidence="high_confidence"),
            mr("flexor_pollicis_longus", "primary_contextual", "Flexão e estabilização do polegar."),
            mr("flexor_pollicis_brevis", "primary_contextual", "Flexão e estabilização do polegar."),
            mr(
                "flexor_digitorum_profundus",
                "primary_contextual",
                "Gera e mantém força dos dedos contra o polegar.",
                confidence="high_confidence",
                emphasis="moderate_supported_emphasis",
                grip_role="primary_target",
                grip_limiter_default="likely",
            ),
            mr(
                "flexor_digitorum_superficialis",
                "primary_contextual",
                "Contribui para manter a flexão dos dedos contra o polegar.",
                confidence="high_confidence",
                emphasis="moderate_supported_emphasis",
                grip_role="primary_target",
                grip_limiter_default="likely",
            ),
            mr("first_dorsal_interosseous" if "first_dorsal_interosseous" in MUSCLE_NAMES else "dorsal_interosseous_hand_1", "stabilizer", "Estabiliza o indicador na pinça."),
            mr("extensor_carpi_radialis_brevis", "stabilizer", "Estabiliza o punho."),
        ]
    if exercise_id == "parallel_bar_support_hold":
        return [
            mr("triceps_brachii", "primary_contextual", "Mantém extensão isométrica do cotovelo.", confidence="high_confidence"),
            mr("anconeus", "synergist", "Auxilia estabilidade do cotovelo."),
            mr("pectoralis_minor", "stabilizer", "Depressão e controlo escapular contextual."),
            mr("serratus_anterior", "stabilizer", "Controlo escapular."),
            mr(
                "flexor_digitorum_profundus",
                "stabilizer",
                "Mantém contacto da mão com a barra sem ser alvo universal da tarefa.",
                confidence="moderate_confidence",
                emphasis="weak_or_indirect_evidence",
                grip_role="stabilizer",
                grip_limiter_default="unlikely",
            ),
            mr(
                "flexor_digitorum_superficialis",
                "stabilizer",
                "Mantém contacto da mão com a barra sem ser alvo universal da tarefa.",
                confidence="moderate_confidence",
                emphasis="weak_or_indirect_evidence",
                grip_role="stabilizer",
                grip_limiter_default="unlikely",
            ),
            mr("flexor_carpi_radialis", "stabilizer", "Coestabiliza o punho no apoio."),
            mr("extensor_carpi_radialis_brevis", "stabilizer", "Coestabiliza o punho no apoio."),
        ]
    if exercise_id in {"resisted_hand_close", "support_grip_hold", "farmers_carry", "suitcase_carry", "dead_hang"}:
        limiter_default = "likely" if exercise_id in {"resisted_hand_close", "support_grip_hold"} else "possible"
        grip_role = "primary_target" if exercise_id in {"resisted_hand_close", "support_grip_hold"} else "potential_limiter"
        rows = [
            mr(
                "flexor_digitorum_profundus",
                "primary" if exercise_id == "resisted_hand_close" else "primary_contextual",
                "Flexão digital e manutenção da preensão.",
                confidence="high_confidence",
                emphasis="moderate_supported_emphasis",
                grip_role=grip_role,
                grip_limiter_default=limiter_default,
            ),
            mr(
                "flexor_digitorum_superficialis",
                "primary" if exercise_id == "resisted_hand_close" else "primary_contextual",
                "Flexão digital e manutenção da preensão.",
                confidence="high_confidence",
                emphasis="moderate_supported_emphasis",
                grip_role=grip_role,
                grip_limiter_default=limiter_default,
            ),
            mr("flexor_pollicis_longus", "secondary", "Participação do polegar no fecho da pega."),
            mr("adductor_pollicis", "secondary", "Estabiliza o polegar contra o implemento."),
            mr("extensor_carpi_radialis_brevis", "stabilizer", "Mantém o punho contra flexão indesejada."),
            mr("extensor_carpi_ulnaris", "stabilizer", "Coestabiliza o punho."),
        ]
        if exercise_id in {"farmers_carry", "suitcase_carry"}:
            rows += [
                mr("trapezius", "stabilizer", "Estabiliza a cintura escapular durante transporte."),
                mr("external_oblique", "stabilizer", "Controlo do tronco; maior assimetria no transporte unilateral."),
            ]
        if exercise_id in {"dead_hang", "towel_hang"}:
            rows += [
                mr("latissimus_dorsi", "stabilizer", "Contribuição contextual para estabilidade do ombro."),
                mr("trapezius", "stabilizer", "Controlo escapular contextual."),
            ]
        return rows
    raise KeyError(f"Sem template muscular para {exercise_id}")


ACTION_TO_JOINTS = {
    "scapular_elevation": ["scapulothoracic_articulation"],
    "scapular_depression": ["scapulothoracic_articulation"],
    "scapular_protraction": ["scapulothoracic_articulation"],
    "scapular_retraction": ["scapulothoracic_articulation"],
    "shoulder_flexion": ["glenohumeral_joint"],
    "shoulder_extension": ["glenohumeral_joint"],
    "shoulder_abduction": ["glenohumeral_joint"],
    "shoulder_adduction": ["glenohumeral_joint"],
    "shoulder_horizontal_abduction": ["glenohumeral_joint"],
    "shoulder_horizontal_adduction": ["glenohumeral_joint"],
    "elbow_flexion": ["elbow_joint"],
    "elbow_extension": ["elbow_joint"],
    "forearm_pronation": ["proximal_radioulnar_joint", "distal_radioulnar_joint"],
    "forearm_supination": ["proximal_radioulnar_joint", "distal_radioulnar_joint"],
    "wrist_flexion": ["radiocarpal_joint", "midcarpal_joint"],
    "wrist_extension": ["radiocarpal_joint", "midcarpal_joint"],
    "wrist_radial_deviation": ["radiocarpal_joint", "midcarpal_joint"],
    "wrist_ulnar_deviation": ["radiocarpal_joint", "midcarpal_joint"],
    "finger_mcp_flexion": ["finger_metacarpophalangeal_joints"],
    "finger_mcp_extension": ["finger_metacarpophalangeal_joints"],
    "finger_pip_flexion": ["finger_proximal_interphalangeal_joints"],
    "finger_pip_extension": ["finger_proximal_interphalangeal_joints"],
    "finger_dip_flexion": ["finger_distal_interphalangeal_joints"],
    "finger_dip_extension": ["finger_distal_interphalangeal_joints"],
    "thumb_cmc_adduction": ["thumb_carpometacarpal_joint"],
    "thumb_mcp_flexion": ["thumb_metacarpophalangeal_joint"],
    "thumb_opposition": ["thumb_carpometacarpal_joint"],
}


def derive_relations():
    muscle_rows = []
    joint_rows = []
    action_rows = []
    equipment_rows = []
    claim_rows = []
    for ex in sorted(EXERCISES, key=lambda row: row["exercise_id"]):
        exid = ex["exercise_id"]
        active_joints = {
            joint
            for action in ex["mechanics"]["action_ids"]
            for joint in ACTION_TO_JOINTS.get(action, [])
        }
        for index, joint_id in enumerate(ex["mechanics"]["joint_ids"], 1):
            relation_id = f"ejr_{exid}_{index:02d}"
            joint_rows.append(
                {
                    "relation_id": relation_id,
                    "exercise_id": exid,
                    "joint_id": joint_id,
                    "role": "active" if joint_id in active_joints else "stabilized_or_limiting",
                    "context": ex["mechanics"]["kinetic_chain"],
                    "confidence": "high_confidence" if joint_id in active_joints else "moderate_confidence",
                    "source_ids": ";".join(ex["source_ids"]),
                }
            )
            claim_rows.append(
                {
                    "claim_id": f"claim_{relation_id}",
                    "exercise_id": exid,
                    "target_id": joint_id,
                    "condition": ex["mechanics"]["kinetic_chain"],
                    "outcome": "joint_participation",
                    "claim_type": "exercise_joint_role",
                    "claim_summary": f"{joint_id} tem papel {joint_rows[-1]['role']} na tarefa declarada.",
                    "affected_relation_id": relation_id,
                    "source_ids": ";".join(ex["source_ids"]),
                    "evidence_type": "canonical_joint_action_and_technical_inference",
                    "strength": "plausible_mechanical_emphasis",
                    "confidence": joint_rows[-1]["confidence"],
                    "limitations": "A relação articular não quantifica carga, compressão, cisalhamento ou risco.",
                    "review_status": "reviewed_internal",
                }
            )
        for index, action_id in enumerate(ex["mechanics"]["action_ids"], 1):
            is_grip = ex["family_id"] in {"grip_isometric", "loaded_carry", "suspension_support", "upper_limb_support"}
            phase_profile = ex["mechanics"].get("action_phase_profiles", {}).get(action_id)
            relation_id = f"ear_{exid}_{index:02d}"
            action_rows.append(
                {
                    "relation_id": relation_id,
                    "exercise_id": exid,
                    "action_id": action_id,
                    "role": (
                        phase_profile["role"]
                        if phase_profile
                        else ("isometric_contextual" if is_grip else ("primary" if index == 1 else "primary_contextual"))
                    ),
                    "contraction_mode": (
                        phase_profile["contraction_mode"]
                        if phase_profile
                        else ("isometric" if is_grip else "concentric_eccentric")
                    ),
                    "context": phase_profile["context"] if phase_profile else ex["mechanics"]["kinetic_chain"],
                    "confidence": "high_confidence",
                    "source_ids": ";".join(ex["source_ids"]),
                }
            )
            claim_rows.append(
                {
                    "claim_id": f"claim_{relation_id}",
                    "exercise_id": exid,
                    "target_id": action_id,
                    "condition": action_rows[-1]["contraction_mode"],
                    "outcome": "action_role",
                    "claim_type": "exercise_action_role",
                    "claim_summary": f"{action_id} tem papel {action_rows[-1]['role']} na tarefa declarada.",
                    "affected_relation_id": relation_id,
                    "source_ids": ";".join(ex["source_ids"]),
                    "evidence_type": "canonical_action_and_technical_inference",
                    "strength": "plausible_mechanical_emphasis",
                    "confidence": "high_confidence",
                    "limitations": "A ação não determina isoladamente contribuição muscular, adaptação ou segurança.",
                    "review_status": "reviewed_internal",
                }
            )
        muscles = muscle_template(exid)
        for index, row in enumerate(muscles, 1):
            relation_id = f"emr_{exid}_{index:02d}"
            out = {
                "relation_id": relation_id,
                "exercise_id": exid,
                **row,
                "source_ids": ";".join(row["source_ids"]),
            }
            muscle_rows.append(out)
            claim_rows.append(
                {
                    "claim_id": f"claim_{relation_id}",
                    "exercise_id": exid,
                    "target_id": row["component_id"] or row["muscle_id"],
                    "condition": row["context"],
                    "outcome": row["role"],
                    "claim_type": "exercise_muscle_role",
                    "claim_summary": f"{row['muscle_id']} tem papel {row['role']} no contexto declarado.",
                    "affected_relation_id": relation_id,
                    "source_ids": ";".join(row["source_ids"]),
                    "evidence_type": row["evidence_type"],
                    "strength": row["emphasis_evidence"],
                    "confidence": row["confidence"],
                    "limitations": row["limitations"],
                    "review_status": "reviewed_internal",
                }
            )
        for relation_type, key in (
            ("required", "required_ids"),
            ("optional", "optional_ids"),
            ("alternative", "alternative_ids"),
        ):
            for index, equipment_id in enumerate(ex["equipment"][key], 1):
                equipment_rows.append(
                    {
                        "relation_id": f"eeq_{exid}_{relation_type}_{index:02d}",
                        "exercise_id": exid,
                        "equipment_id": equipment_id,
                        "relation_type": relation_type,
                        "context": ex["equipment"]["anchorage"],
                        "source_ids": ";".join(ex["source_ids"]),
                    }
                )
                relation_id = equipment_rows[-1]["relation_id"]
                claim_rows.append(
                    {
                        "claim_id": f"claim_{relation_id}",
                        "exercise_id": exid,
                        "target_id": equipment_id,
                        "condition": relation_type,
                        "outcome": "equipment_relation",
                        "claim_type": "exercise_equipment_role",
                        "claim_summary": f"{equipment_id} é equipamento {relation_type} na manifestação declarada.",
                        "affected_relation_id": relation_id,
                        "source_ids": ";".join(ex["source_ids"]),
                        "evidence_type": "exercise_identity_and_technical_inference",
                        "strength": "plausible_mechanical_emphasis",
                        "confidence": "high_confidence",
                        "limitations": "Variantes podem substituir o equipamento base sem criar exercício canónico.",
                        "review_status": "reviewed_internal",
                    }
                )
        claim_rows.append(
            {
                "claim_id": f"claim_identity_{exid}",
                "exercise_id": exid,
                "target_id": exid,
                "condition": json.dumps(
                    {
                        "chain": ex["mechanics"]["kinetic_chain"],
                        "shoulder": ex["mechanics"]["shoulder_position"],
                        "forearm": ex["mechanics"]["forearm_position"],
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "outcome": "canonical_identity_and_mechanics",
                "claim_type": "exercise_identity_and_mechanics",
                "claim_summary": ex["technical_description"],
                "affected_relation_id": "",
                "source_ids": ";".join(ex["source_ids"]),
                "evidence_type": "mixed_source_and_technical_inference",
                "strength": "moderate_supported_emphasis",
                "confidence": "moderate_confidence",
                "limitations": "A identidade não implica superioridade de adaptação nem prescrição individual.",
                "review_status": "reviewed_internal",
            }
        )
        claim_rows.append(
            {
                "claim_id": f"claim_safety_{exid}",
                "exercise_id": exid,
                "target_id": exid,
                "condition": "general_training_and_declared_equipment",
                "outcome": "mechanical_environmental_caution",
                "claim_type": "exercise_safety_boundary",
                "claim_summary": compact_list(ex["safety"]["general_cautions"]),
                "affected_relation_id": "",
                "source_ids": ";".join(
                    sorted(
                        set(ex["source_ids"])
                        | {"src_acsm_progression_2009", "src_technical_inference"}
                        | ({"src_watanabe_breath_hold_2022"} if ex["family_id"] in {"grip_dynamic", "grip_isometric", "loaded_carry", "suspension_support", "upper_limb_support"} else set())
                    )
                ),
                "evidence_type": "professional_consensus_and_conservative_safety_inference",
                "strength": "moderate_supported_emphasis",
                "confidence": "moderate_confidence",
                "limitations": "Regras gerais de controlo e paragem; não diagnosticam nem substituem avaliação individual.",
                "review_status": "reviewed_internal",
            }
        )
    return muscle_rows, joint_rows, action_rows, equipment_rows, claim_rows


SCHEMAS = {
    "exercises.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": "EveFit canonical arm exercise",
        "type": "object",
        "required": [
            "schema_version",
            "exercise_id",
            "name_pt_pt",
            "name_en",
            "synonyms",
            "family_id",
            "entity_type",
            "status",
            "public_eligible",
            "short_description",
            "technical_description",
            "execution",
            "mechanics",
            "equipment",
            "safety",
            "source_ids",
        ],
        "properties": {
            "exercise_id": {"type": "string", "pattern": "^[a-z0-9_]+$"},
            "status": {"enum": ["approved_public", "approved_with_limits", "specialist_review", "internal_only", "duplicate", "excluded"]},
            "entity_type": {"const": "canonical_exercise"},
        },
        "additionalProperties": True,
    },
    "exercise_variants.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": ["schema_version", "variant_id", "parent_exercise_id", "name_pt_pt", "classification", "changes", "mechanical_justification", "status", "equipment_ids", "source_ids"],
        "properties": {
            "variant_id": {"type": "string", "pattern": "^[a-z0-9_]+$"},
            "classification": {"enum": ["canonical_exercise", "exercise_variant", "equipment_variant", "grip_orientation_variant", "technique_variant", "progression", "regression", "isometric_variant", "eccentric_variant", "duplicate", "excluded", "specialist_review"]},
        },
    },
    "exercise_families.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "array",
        "items": {"type": "object", "required": ["family_id", "name_pt_pt", "domain", "schema_version"]},
    },
    "equipment.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "array",
        "items": {"type": "object", "required": ["equipment_id", "name_pt_pt", "equipment_type", "schema_version"]},
    },
    "exercise_equipment_relations.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": ["relation_id", "exercise_id", "equipment_id", "relation_type", "context", "source_ids"],
    },
    "exercise_joint_relations.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": ["relation_id", "exercise_id", "joint_id", "role", "context", "confidence", "source_ids"],
    },
    "exercise_action_relations.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": ["relation_id", "exercise_id", "action_id", "role", "contraction_mode", "context", "confidence", "source_ids"],
    },
    "exercise_muscle_relations.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": [
            "relation_id",
            "exercise_id",
            "muscle_id",
            "component_id",
            "role",
            "role_scope",
            "grip_role_default",
            "grip_limiter_default",
            "grip_limiter_observed",
            "context",
            "confidence",
            "evidence_type",
            "emphasis_evidence",
            "limitations",
            "source_ids",
        ],
    },
    "exercise_progression_relations.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": ["relation_id", "exercise_id", "variant_id", "relation_type", "rationale"],
    },
    "exercise_equivalence_relations.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": ["relation_id", "exercise_id", "variant_id", "equivalence_type", "rationale"],
    },
    "public_arm_exercises.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "array",
        "items": {
            "type": "object",
            "required": [
                "exercise_id",
                "name",
                "objective",
                "primary_muscles",
                "secondary_muscles",
                "potential_grip_limiters",
                "equipment",
                "instructions",
                "common_errors",
                "cautions",
                "environmental_controls",
                "limit_reason",
                "simple_alternatives",
                "status",
            ],
        },
    },
    "source_ledger.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": ["source_id", "title", "authors", "year", "source_type", "url", "scope", "quality"],
    },
    "claims_ledger.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": ["claim_id", "exercise_id", "target_id", "condition", "outcome", "claim_type", "claim_summary", "affected_relation_id", "source_ids", "evidence_type", "strength", "confidence", "limitations", "review_status"],
    },
    "manifest.schema.json": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": ["package_id", "version", "build_date", "canonical_input", "counts", "files"],
    },
}


def internal_validate(
    exercises: list[dict],
    variants: list[dict],
    muscle_rows: list[dict],
    joint_rows: list[dict],
    action_rows: list[dict],
    equipment_rows: list[dict],
    claims: list[dict],
) -> int:
    checks = 0

    def check(condition: bool, message: str) -> None:
        nonlocal checks
        checks += 1
        if not condition:
            raise AssertionError(message)

    check(sha256_file(BASE_ZIP) == EXPECTED_BASE_SHA256, "Hash da base v0.1.1 incorreto")
    ex_ids = [row["exercise_id"] for row in exercises]
    check(len(ex_ids) == len(set(ex_ids)), "exercise_id duplicado")
    check(len(ex_ids) == 36, f"Esperados 36 canónicos após crítica de identidade, obtidos {len(ex_ids)}")
    variant_ids = [row["variant_id"] for row in variants]
    check(len(variant_ids) == len(set(variant_ids)), "variant_id duplicado")
    family_ids = {row[0] for row in FAMILIES}
    for ex in exercises:
        check(ex["family_id"] in family_ids, f"Família órfã: {ex['exercise_id']}")
        check(ex["status"] in {"approved_public", "approved_with_limits", "specialist_review", "internal_only", "duplicate", "excluded"}, f"Estado inválido: {ex['exercise_id']}")
        check(bool(ex["name_pt_pt"]) and bool(ex["technical_description"]), f"Identidade incompleta: {ex['exercise_id']}")
        check("isolamento absoluto" not in ex["technical_description"].lower(), f"Alegação de isolamento: {ex['exercise_id']}")
        for joint_id in ex["mechanics"]["joint_ids"]:
            check(joint_id in JOINT_IDS, f"Articulação inválida {joint_id} em {ex['exercise_id']}")
        for action_id in ex["mechanics"]["action_ids"]:
            check(action_id in ACTION_IDS, f"Ação inválida {action_id} em {ex['exercise_id']}")
        for equipment_id in ex["equipment"]["required_ids"] + ex["equipment"]["optional_ids"] + ex["equipment"]["alternative_ids"]:
            check(equipment_id in EQUIPMENT_IDS, f"Equipamento inválido {equipment_id} em {ex['exercise_id']}")
        for source_id in ex["source_ids"]:
            check(source_id in SOURCE_IDS, f"Fonte inválida {source_id} em {ex['exercise_id']}")
    limited_public_ids = {
        ex["exercise_id"]
        for ex in exercises
        if ex["public_eligible"] and ex["status"] == "approved_with_limits"
    }
    check(
        limited_public_ids == set(PUBLIC_LIMIT_REASONS),
        "Justificações públicas específicas não coincidem com os estados approved_with_limits",
    )
    check(
        set(PUBLIC_ENVIRONMENTAL_CONTROLS) <= set(ex_ids),
        "Controlo ambiental público aponta para exercício inexistente",
    )
    for row in variants:
        check(row["parent_exercise_id"] in set(ex_ids), f"Pai de variante inválido {row['variant_id']}")
        for equipment_id in row["equipment_ids"]:
            check(equipment_id in EQUIPMENT_IDS, f"Equipamento de variante inválido {row['variant_id']}")
        for source_id in row["source_ids"]:
            check(source_id in SOURCE_IDS, f"Fonte de variante inválida {row['variant_id']}")
    for row in muscle_rows:
        check(row["exercise_id"] in set(ex_ids), f"Relação muscular órfã {row['relation_id']}")
        check(row["muscle_id"] in MUSCLE_NAMES, f"Músculo inválido {row['muscle_id']}")
        check(not row["component_id"] or COMPONENT_PARENT.get(row["component_id"]) == row["muscle_id"], f"Componente inválido {row['relation_id']}")
        check(row["role"] in {"primary", "primary_contextual", "secondary", "synergist", "stabilizer", "neutralizer", "grip_limiter", "antagonist_control", "disputed", "specialist_review"}, f"Papel inválido {row['relation_id']}")
        check(row["grip_role_default"] in {"primary_target", "potential_limiter", "stabilizer", "not_applicable"}, f"Papel de preensão inválido {row['relation_id']}")
        check(row["grip_limiter_default"] in {"likely", "possible", "unlikely", "not_applicable"}, f"Estado potencial de limitação inválido {row['relation_id']}")
        check(row["grip_limiter_observed"] == "unknown", f"Resultado de série inventado {row['relation_id']}")
        if row["role"] == "grip_limiter":
            check(row["role_scope"] == "default_potential_limiter_not_observed_series_outcome", f"Âmbito de grip_limiter inválido {row['relation_id']}")
            check(row["grip_role_default"] == "potential_limiter", f"Grip limiter confundido com alvo {row['relation_id']}")
        check(bool(row["context"]) and bool(row["limitations"]), f"Justificação ausente {row['relation_id']}")
        for source_id in row["source_ids"].split(";"):
            check(source_id in SOURCE_IDS, f"Fonte inválida em {row['relation_id']}")
    for row in joint_rows:
        check(row["exercise_id"] in set(ex_ids) and row["joint_id"] in JOINT_IDS, f"Relação articular inválida {row['relation_id']}")
    for row in action_rows:
        check(row["exercise_id"] in set(ex_ids) and row["action_id"] in ACTION_IDS, f"Relação de ação inválida {row['relation_id']}")
    for row in equipment_rows:
        check(row["exercise_id"] in set(ex_ids) and row["equipment_id"] in EQUIPMENT_IDS, f"Relação de equipamento inválida {row['relation_id']}")
    relation_ids = {
        row["relation_id"]
        for rows in (muscle_rows, joint_rows, action_rows, equipment_rows)
        for row in rows
    }
    for row in claims:
        check(row["exercise_id"] in set(ex_ids), f"Claim órfã {row['claim_id']}")
        check(not row["affected_relation_id"] or row["affected_relation_id"] in relation_ids, f"Claim aponta para relação inválida {row['claim_id']}")
        for source_id in row["source_ids"].split(";"):
            check(source_id in SOURCE_IDS, f"Fonte de claim inválida {row['claim_id']}")
    for exid in ex_ids:
        roles = [row["role"] for row in muscle_rows if row["exercise_id"] == exid]
        check(any(role in {"primary", "primary_contextual", "specialist_review"} for role in roles), f"Sem relação muscular principal/contextual: {exid}")
        check(any(row["exercise_id"] == exid for row in action_rows), f"Sem ação: {exid}")
        check(any(row["exercise_id"] == exid for row in joint_rows), f"Sem articulação: {exid}")
    for exid in {
        "standing_supinated_curl",
        "shoulder_extended_supinated_curl",
        "preacher_curl",
        "spider_curl",
    }:
        biceps_row = next(
            row
            for row in muscle_rows
            if row["exercise_id"] == exid and row["muscle_id"] == "biceps_brachii" and not row["component_id"]
        )
        check(biceps_row["role"] == "primary_contextual", f"Bicípite sobrepromovido em {exid}")
        check(biceps_row["confidence"] == "moderate_confidence", f"Confiança excessiva do bicípite em {exid}")
    for row in muscle_rows:
        if row["component_id"] and row["component_id"].startswith("triceps_brachii_"):
            if row["exercise_id"] == "overhead_triceps_extension" and row["component_id"] == "triceps_brachii_long_head":
                check(row["emphasis_evidence"] == "moderate_supported_emphasis", "Ênfase suportada da cabeça longa acima da cabeça perdida")
            else:
                check(row["emphasis_evidence"] == "insufficient_evidence", f"Ênfase automática de cabeça do tricípite: {row['relation_id']}")
    suspension_curl_lats = next(
        row
        for row in muscle_rows
        if row["exercise_id"] == "suspension_bodyweight_curl" and row["muscle_id"] == "latissimus_dorsi"
    )
    check(suspension_curl_lats["role"] == "stabilizer", "Grande dorsal impossível como principal no curl em suspensão")
    for muscle_id in {"flexor_digitorum_profundus", "flexor_digitorum_superficialis"}:
        support_hand = next(
            row
            for row in muscle_rows
            if row["exercise_id"] == "parallel_bar_support_hold" and row["muscle_id"] == muscle_id
        )
        check(support_hand["role"] == "stabilizer", f"Mão sobrepromovida no apoio em paralelas: {muscle_id}")
        check(support_hand["grip_role_default"] == "stabilizer", f"Papel de contacto ausente no apoio em paralelas: {muscle_id}")
        check(support_hand["grip_limiter_default"] == "unlikely", f"Limitação universal no apoio em paralelas: {muscle_id}")
    exercise_by_id = {row["exercise_id"]: row for row in exercises}
    for exid in {"suspension_bodyweight_curl", "suspension_triceps_extension"}:
        check(exercise_by_id[exid]["mechanics"]["kinetic_chain"] == "mixed_chain", f"Suspensão sem cadeia mista: {exid}")
        check(bool(exercise_by_id[exid]["mechanics"].get("segment_chain_classification")), f"Suspensão sem classificação segmentar: {exid}")
    for exid in {"parallel_bar_dip", "bench_dip"}:
        profiles = exercise_by_id[exid]["mechanics"].get("action_phase_profiles", {})
        check(profiles.get("shoulder_extension", {}).get("contraction_mode") == "descent_under_eccentric_flexor_control", f"Descida dos fundos sem fase: {exid}")
        check(profiles.get("shoulder_flexion", {}).get("contraction_mode") == "concentric_ascent_toward_neutral", f"Subida dos fundos sem fase: {exid}")
    check(all("hipertrofia" not in row["claim_summary"].lower() or "src_maeo_triceps_2023" in row["source_ids"] for row in claims), "Inferência de hipertrofia sem fonte longitudinal")
    return checks


PUBLIC_LIMIT_REASONS = {
    "bench_dip": (
        "A extensão do ombro pode limitar a amplitude; manter o tronco próximo do banco "
        "e parar antes de desconforto anterior."
    ),
    "dead_hang": (
        "Requer ancoragem verificada, entrada e saída apoiadas e tolerância confortável "
        "do ombro, cotovelo, punho e mão."
    ),
    "machine_triceps_extension": (
        "A came, o eixo e a trajetória variam entre máquinas; confirmar o alinhamento "
        "e a amplitude do modelo utilizado."
    ),
    "wrist_radial_deviation": (
        "A alavanca e a amplitude devem permanecer curtas e controladas; evitar fim de "
        "amplitude sintomático."
    ),
    "wrist_roller": (
        "A fadiga e o momento externo acumulam rapidamente; usar carga controlável e "
        "impedir a queda da carga suspensa."
    ),
    "wrist_ulnar_deviation": (
        "A alavanca e a amplitude devem permanecer curtas e controladas; evitar fim de "
        "amplitude sintomático."
    ),
}

PUBLIC_ENVIRONMENTAL_CONTROLS = {
    "dead_hang": [
        "Confirmar a estabilidade, inspeção e capacidade da ancoragem antes da suspensão.",
        "Manter livre a zona inferior e usar um apoio seguro para entrar e sair.",
    ],
    "farmers_carry": [
        "Confirmar antecipadamente que o percurso é plano, livre e suficientemente largo.",
        "Manter uma zona livre para pousar as cargas com controlo.",
    ],
    "parallel_bar_support_hold": [
        "Confirmar a estabilidade das paralelas antes do apoio.",
        "Manter livres as zonas lateral e inferior para uma saída segura.",
    ],
    "plate_pinch_hold": [
        "Manter livre a zona inferior para pousar ou largar os discos sem atingir pessoas ou objetos.",
    ],
    "suitcase_carry": [
        "Confirmar antecipadamente que o percurso é plano, livre e suficientemente largo.",
        "Manter uma zona livre para pousar a carga com controlo.",
    ],
    "support_grip_hold": [
        "Manter livre a zona inferior para pousar ou largar o implemento sem atingir pessoas ou objetos.",
    ],
}


def public_rows(exercises: list[dict], muscle_rows: list[dict]) -> list[dict]:
    equipment_name = {row[0]: row[1] for row in EQUIPMENT}
    rows = []
    for ex in sorted(exercises, key=lambda row: row["name_pt_pt"]):
        if not ex["public_eligible"] or ex["status"] not in {"approved_public", "approved_with_limits"}:
            continue
        rels = [row for row in muscle_rows if row["exercise_id"] == ex["exercise_id"] and not row["component_id"]]
        primary = [
            MUSCLE_NAMES[row["muscle_id"]]
            for row in rels
            if row["role"] in {"primary", "primary_contextual"}
        ]
        secondary = [
            MUSCLE_NAMES[row["muscle_id"]]
            for row in rels
            if row["role"] in {"secondary", "synergist", "stabilizer"}
        ]
        potential_grip_limiters = [
            MUSCLE_NAMES[row["muscle_id"]]
            for row in rels
            if row["grip_role_default"] == "potential_limiter"
            and row["grip_limiter_default"] in {"likely", "possible"}
        ]
        environmental_controls = list(ex["execution"]["setup"])
        if ex["equipment"]["anchorage"] != "Não aplicável.":
            environmental_controls.append(ex["equipment"]["anchorage"])
        if ex["equipment"]["bench_or_support"] != "Não obrigatório.":
            environmental_controls.append(ex["equipment"]["bench_or_support"])
        environmental_controls.append(ex["equipment"]["space"])
        environmental_controls.extend(PUBLIC_ENVIRONMENTAL_CONTROLS.get(ex["exercise_id"], []))
        environmental_controls = list(dict.fromkeys(environmental_controls))
        limit_reason = PUBLIC_LIMIT_REASONS.get(ex["exercise_id"], "")
        cautions = list(ex["safety"]["general_cautions"])
        if limit_reason:
            cautions.append(limit_reason)
        if ex["status"] == "approved_with_limits":
            cautions.append(ex["safety"]["specialist_review"])
        rows.append(
            {
                "exercise_id": ex["exercise_id"],
                "name": ex["name_pt_pt"],
                "objective": ex["short_description"],
                "primary_muscles": sorted(dict.fromkeys(primary)),
                "secondary_muscles": sorted(dict.fromkeys(secondary)),
                "potential_grip_limiters": sorted(dict.fromkeys(potential_grip_limiters)),
                "equipment": [equipment_name[eid] for eid in ex["equipment"]["required_ids"]],
                "instructions": [
                    ex["execution"]["start_position"],
                    ex["execution"]["movement"],
                    ex["execution"]["end_position"],
                ],
                "common_errors": ex["execution"]["common_errors"],
                "cautions": list(dict.fromkeys(cautions)),
                "environmental_controls": environmental_controls,
                "limit_reason": limit_reason,
                "simple_alternatives": ex["safety"]["regressions"],
                "status": ex["status"],
            }
        )
    return rows


def exercise_markdown(exercises: list[dict], muscle_rows: list[dict], title: str, selected_ids: set[str] | None = None) -> str:
    equipment_name = {row[0]: row[1] for row in EQUIPMENT}
    lines = [f"# {title}", "", "O papel muscular é contextual e nunca significa isolamento absoluto.", ""]
    selected = [row for row in exercises if selected_ids is None or row["exercise_id"] in selected_ids]
    for ex in sorted(selected, key=lambda row: row["name_pt_pt"]):
        rels = [row for row in muscle_rows if row["exercise_id"] == ex["exercise_id"] and not row["component_id"]]
        primary = [MUSCLE_NAMES[row["muscle_id"]] for row in rels if row["role"] in {"primary", "primary_contextual", "specialist_review"}]
        secondary = [MUSCLE_NAMES[row["muscle_id"]] for row in rels if row["role"] in {"secondary", "synergist", "stabilizer", "neutralizer"}]
        potential_grip_limiters = [
            MUSCLE_NAMES[row["muscle_id"]]
            for row in rels
            if row["grip_role_default"] == "potential_limiter"
            and row["grip_limiter_default"] in {"likely", "possible"}
        ]
        lines += [
            f"## {ex['name_pt_pt']}",
            "",
            f"- ID: `{ex['exercise_id']}`",
            f"- Estado: `{ex['status']}`",
            f"- Família: `{ex['family_id']}`",
            f"- Objetivo: {ex['short_description']}",
            f"- Músculos principais/contextuais: {compact_list(sorted(dict.fromkeys(primary)))}.",
            f"- Secundários/estabilizadores: {compact_list(sorted(dict.fromkeys(secondary)))}.",
            f"- Possíveis limitadores de preensão: {compact_list(sorted(dict.fromkeys(potential_grip_limiters)))}.",
            f"- Equipamento base: {compact_list([equipment_name[eid] for eid in ex['equipment']['required_ids']])}.",
            f"- Mecânica: {ex['technical_description']}",
            "",
            "### Execução",
            "",
            f"1. {ex['execution']['start_position']}",
            f"2. {ex['execution']['movement']}",
            f"3. {ex['execution']['end_position']}",
            "",
            f"**Cues:** {compact_list(ex['execution']['cues'])}.",
            "",
            f"**Erros frequentes:** {compact_list(ex['execution']['common_errors'])}.",
            "",
            f"**Cautelas:** {compact_list(ex['safety']['general_cautions'])}.",
            "",
        ]
    return "\n".join(lines)


def coverage_table(counter: Counter, left: str) -> str:
    lines = [f"| {left} | Número |", "|---|---:|"]
    for key, value in sorted(counter.items()):
        lines.append(f"| `{key}` | {value} |")
    return "\n".join(lines)


def build_documents(
    out: Path,
    exercises: list[dict],
    variants: list[dict],
    muscle_rows: list[dict],
    joint_rows: list[dict],
    action_rows: list[dict],
    equipment_rows: list[dict],
    claims: list[dict],
    public: list[dict],
    internal_checks: int,
    external_result: dict,
) -> None:
    status_counts = Counter(row["status"] for row in exercises)
    family_counts = Counter(row["family_id"] for row in exercises)
    equipment_counts = Counter(row["equipment_id"] for row in equipment_rows)
    all_equipment_counts = Counter(equipment_counts)
    for variant_row in variants:
        all_equipment_counts.update(variant_row["equipment_ids"])
    muscle_counts = Counter(row["muscle_id"] for row in muscle_rows)
    variant_counts = Counter(row["classification"] for row in variants)
    exclusion_counts = Counter(row[1] for row in CANDIDATE_EXCLUSIONS)
    candidate_count = len(exercises) + len(variants) + len(CANDIDATE_EXCLUSIONS)

    readme = f"""# EveFit Principal Arm Exercise Catalogue v0.1

Catálogo canónico dos principais exercícios de braços, construído sobre a base muscular v0.1.1 imutável.

## Resultado

| Métrica | Valor |
|---|---:|
| Candidatos investigados | {candidate_count} |
| Exercícios canónicos | {len(exercises)} |
| Variantes materializadas | {len(variants)} |
| Candidatos duplicados/excluídos | {len(CANDIDATE_EXCLUSIONS)} |
| Famílias | {len(FAMILIES)} |
| Equipamentos | {len(EQUIPMENT)} |
| Exercícios públicos | {len(public)} |
| Relações musculares | {len(muscle_rows)} |
| Relações articulares | {len(joint_rows)} |
| Relações com ações | {len(action_rows)} |
| Claims | {len(claims)} |
| Fontes | {len(SOURCES)} |

“Completo” significa cobertura dos principais exercícios reconhecidos e mecanicamente distintos para braços dentro do âmbito EveFit. Não significa todas as marcas, pegas, cargas, protocolos ou microvariações possíveis.

## Estado

{coverage_table(status_counts, "Estado")}

## Limites

- Não é prescrição individual nem aconselhamento clínico.
- Nenhuma relação implica isolamento muscular absoluto.
- EMG aguda não foi usada isoladamente para inferir hipertrofia.
- Máquinas só são equivalentes quando eixo, trajetória e resistência estão definidos.
- A base muscular v0.1.1 não foi modificada.
"""
    write_text(out / "README.md", readme)

    scope = f"""# Âmbito e completude

## Incluído

- Flexão do cotovelo em supinação, posição neutra e pronação.
- Extensão do cotovelo local e multiarticular.
- Pronação e supinação resistidas.
- Flexão, extensão e desvios do punho.
- Flexão e extensão dos dedos.
- Preensão crush, support, pinch e open-hand.
- Hangs, suportes e carries com papel relevante dos braços.

## Excluído

- Catálogo de peito, costas, ombros ou tronco.
- Marcas comerciais e geometrias de máquinas não documentadas.
- Séries, repetições, carga, cadência, RPE, RIR, 21s, drop sets e AMRAP.
- Prescrição clínica ou individual.
- Implementação Flutter, base de dados, migrations, UI e release.

## Músculo prioritário sem relação direta

O `coracobrachialis` foi auditado, mas não recebeu uma relação artificial neste
catálogo. As suas ações diretas pertencem à articulação glenoumeral, sobretudo
flexão e adução do ombro, e não existe no núcleo um exercício de braço em que a
evidência disponível justifique promovê-lo a alvo principal, secundário ou
estabilizador específico. A cobertura direta fica deferida para um futuro catálogo
de ombro; esta decisão evita usar uma função anatómica geral como prova de
participação relevante numa tarefa concreta.

O núcleo contém {len(exercises)} exercícios canónicos. Fica abaixo da meta indicativa de 40 porque hand gripper/bola foram unificados, pega espessa e towel hang passaram a variantes de interface, e o transporte em pinça passou a variante da pinça isométrica. A cobertura continua completa dentro do âmbito sem preencher uma quota com microvariações.
"""
    write_text(out / "01_METHOD" / "SCOPE_AND_COMPLETENESS.md", scope)

    identity = """# Política de identidade dos exercícios

Cria-se um exercício canónico apenas quando muda materialmente pelo menos um dos seguintes elementos: ação articular, posição relevante do ombro/antebraço, cadeia cinética, trajetória, perfil de resistência, segmento fixo, aplicação de força, estabilidade ou objetivo técnico.

Não criam identidade nova: carga, séries, repetições, velocidade, cadência, descanso, RPE, RIR, lado, pequenas larguras de pega, marca de máquina ou protocolo.

## Regras

1. O canónico representa a tarefa mecânica.
2. O equipamento é variante quando preserva a tarefa, mesmo que altere o perfil de resistência.
3. A variante deve ter pai, alteração e justificação explícitos.
4. Uma máquina só entra com limites quando a sua geometria não é universal.
5. Exercícios multiarticulares mantêm identidade própria e os músculos do braço recebem papéis contextuais.
"""
    write_text(out / "01_METHOD" / "EXERCISE_IDENTITY_POLICY.md", identity)

    variant_policy = f"""# Política de variantes

Tipos aceites: `exercise_variant`, `equipment_variant`, `grip_orientation_variant`, `technique_variant`, `progression`, `regression`, `isometric_variant`, `eccentric_variant`, `duplicate`, `excluded` e `specialist_review`.

{coverage_table(variant_counts, "Tipo")}

As {len(variants)} variantes materializadas cobrem os equipamentos e configurações obrigatórios sem inflacionar o núcleo canónico.
"""
    write_text(out / "01_METHOD" / "VARIANT_POLICY.md", variant_policy)

    candidate_coverage = """# Cobertura dos candidatos obrigatórios

| Candidato da ordem | Resolução | ID |
|---|---|---|
| Curl com barra reta | Variante de equipamento | `standing_curl_straight_bar` |
| Curl com barra EZ | Variante de pega/equipamento | `standing_curl_ez_bar` |
| Curl com halteres | Variante de equipamento | `standing_curl_dumbbells` |
| Curl alternado | Variante técnica | `standing_curl_alternating` |
| Curl inclinado | Canónico posicional | `shoulder_extended_supinated_curl` |
| Curl Scott/preacher | Canónico apoiado | `preacher_curl` |
| Curl de concentração | Variante técnica apoiada | `concentration_curl` |
| Curl spider | Canónico posicional | `spider_curl` |
| Curl no cabo | Variante de equipamento | `standing_cable_curl` |
| Curl unilateral no cabo | Variante de equipamento/técnica | `standing_unilateral_cable_curl` |
| Curl na máquina | Variante com limites | `standing_machine_curl` / `preacher_machine_curl` |
| Curl martelo | Canónico de pega neutra | `hammer_curl` |
| Curl martelo cruzado | Variante técnica | `cross_body_hammer_curl` |
| Curl inverso | Canónico pronado | `reverse_curl` |
| Chin-up supinado | Canónico multiarticular | `supinated_chin_up` |
| Curl com banda | Variante de equipamento | `standing_band_curl` |
| Curl em suspensão | Canónico de cadeia fechada | `suspension_bodyweight_curl` |
| Pushdown barra/corda/unilateral | Canónico + variantes | `cable_triceps_pushdown` |
| Extensão acima da cabeça cabo/halter/EZ/banda | Canónico + variantes | `overhead_triceps_extension` |
| Extensão deitada barra/halteres | Canónico + variantes | `lying_triceps_extension` |
| Extensão cruzada no cabo | Canónico | `cross_body_cable_triceps_extension` |
| Kickback halter/cabo | Canónico + variantes | `triceps_kickback` |
| Máquina de tríceps | Canónico com limites + variantes | `machine_triceps_extension` |
| Fundos em paralelas | Canónico multiarticular | `parallel_bar_dip` |
| Fundos no banco | Canónico com limites | `bench_dip` |
| Flexão de braços estreita | Canónico multiarticular | `close_grip_push_up` |
| Supino com pega fechada | Canónico multiarticular | `close_grip_bench_press` |
| Extensão em suspensão | Canónico de cadeia fechada | `suspension_triceps_extension` |
| Extensão de tríceps com banda | Variante de pushdown ou overhead | `pushdown_band` / `overhead_band_extension` |
| Pronação/supinação: alavanca, cabo, banda, manual | Dois canónicos de ação + variantes | `resisted_forearm_pronation` / `resisted_forearm_supination` |
| Flexão/extensão do punho | Canónicos apoiados + variantes | `supported_wrist_curl` / `supported_wrist_extension` |
| Flexão do punho atrás do corpo | Variante técnica | `behind_back_wrist_curl` |
| Rolo de punho | Canónico cíclico com limites | `wrist_roller` |
| Desvios radial/ulnar | Canónicos com limites | `wrist_radial_deviation` / `wrist_ulnar_deviation` |
| Hand gripper e bola | Um canónico funcional + variantes | `resisted_hand_close` |
| Plate pinch | Canónico de pinça | `plate_pinch_hold` |
| Barbell/dumbbell hold | Canónico de suporte + variantes | `support_grip_hold` |
| Fat-grip hold | Variante de contacto | `thick_grip_hold` |
| Farmer carry | Canónico bilateral | `farmers_carry` |
| Suitcase carry | Canónico unilateral | `suitcase_carry` |
| Dead hang | Canónico com limites | `dead_hang` |
| Towel hang | Variante de interface | `towel_hang` |
| Extensão dos dedos com banda | Canónico | `resisted_finger_extension` |
| Suporte em paralelas | Canónico multiarticular de suporte | `parallel_bar_support_hold` |
| Carry com toalha/pega espessa | Variantes de interface | `towel_carry` / `thick_grip_farmers_carry` |

Todos os candidatos foram investigados. A coluna “variante” não representa omissão: evita duplicação quando a diferença pertence ao implemento, pega, lado ou configuração.
"""
    write_text(out / "01_METHOD" / "MANDATORY_CANDIDATE_COVERAGE.md", candidate_coverage)

    equipment_lines = ["# Taxonomia de equipamento", "", "| ID | Nome PT-PT | Tipo |", "|---|---|---|"]
    for equipment_id, name, kind in EQUIPMENT:
        equipment_lines.append(f"| `{equipment_id}` | {name} | `{kind}` |")
    equipment_lines += [
        "",
        "Equipamento obrigatório significa a manifestação base da ficha canónica. As variantes podem substituir esse conjunto por outro implemento explicitamente ligado.",
    ]
    write_text(out / "01_METHOD" / "EQUIPMENT_TAXONOMY.md", "\n".join(equipment_lines))

    flex_ids = {row["exercise_id"] for row in exercises if row["family_id"].startswith("elbow_flexion")}
    ext_ids = {row["exercise_id"] for row in exercises if row["family_id"].startswith("elbow_extension")}
    forearm_ids = {row["exercise_id"] for row in exercises if row["family_id"] in {"forearm_rotation", "wrist_flexion_extension", "wrist_deviation", "digital_flexion_extension", "thumb_specific"}}
    grip_ids = {row["exercise_id"] for row in exercises if row["family_id"] in {"grip_dynamic", "grip_isometric", "loaded_carry", "suspension_support", "upper_limb_support"}}
    write_text(out / "03_CATALOGUES" / "PRINCIPAL_ARM_EXERCISES.md", exercise_markdown(exercises, muscle_rows, "Principais exercícios de braços"))
    write_text(out / "03_CATALOGUES" / "ELBOW_FLEXION_CATALOGUE.md", exercise_markdown(exercises, muscle_rows, "Flexão do cotovelo", flex_ids))
    write_text(out / "03_CATALOGUES" / "ELBOW_EXTENSION_CATALOGUE.md", exercise_markdown(exercises, muscle_rows, "Extensão do cotovelo", ext_ids))
    write_text(out / "03_CATALOGUES" / "FOREARM_WRIST_CATALOGUE.md", exercise_markdown(exercises, muscle_rows, "Antebraço, punho e dedos", forearm_ids))
    write_text(out / "03_CATALOGUES" / "GRIP_AND_FINGER_CATALOGUE.md", exercise_markdown(exercises, muscle_rows, "Preensão, carries, hangs e suportes", grip_ids))
    compound_ids = {
        row["exercise_id"]
        for row in exercises
        if row["mechanics"]["kinetic_chain"] == "closed_chain"
        or row["family_id"] in {"elbow_extension_compound", "loaded_carry", "suspension_support"}
    }
    write_text(out / "03_CATALOGUES" / "BODYWEIGHT_AND_COMPOUND_EXERCISES.md", exercise_markdown(exercises, muscle_rows, "Peso corporal e exercícios multiarticulares", compound_ids))

    public_policy = """# Política de conteúdo público

A camada pública inclui apenas `approved_public` e `approved_with_limits`.

Cada ficha apresenta nome, objetivo geral, músculos principais/contextuais, secundários, possíveis limitadores de preensão, equipamento, instruções, erros, cautelas, controlos ambientais e alternativas simples. `grip_limiter` nunca é promovido automaticamente a músculo principal; o alvo da tarefa e o potencial de limitação são campos distintos. Os registos `approved_with_limits` incluem ainda uma justificação pública específica. Claims frágeis ou controvérsias complexas permanecem no ledger interno. `specialist_review`, `internal_only`, `duplicate` e `excluded` não são publicados.
"""
    write_text(out / "09_PUBLIC_LAYER" / "PUBLIC_CONTENT_POLICY.md", public_policy)

    decisions = """# Registo de decisões

| Decisão | Resultado | Justificação |
|---|---|---|
| Barra reta vs barra EZ | Variantes de pega/equipamento | Preservam ação, posição e cadeia; mudam liberdade do punho. |
| Halteres vs barra | Variantes de equipamento | A independência dos lados não basta para nova identidade. |
| Curl inclinado | Canónico | Ombro em extensão altera comprimento e contexto mecânico. |
| Curl Scott | Canónico | Apoio do braço e ombro em flexão alteram estabilidade e perfil. |
| Curl spider | Canónico | Peito apoiado e braço pendente à frente criam trajetória própria. |
| Curl martelo | Canónico | Posição neutra do antebraço muda contribuição dos flexores. |
| Curl inverso | Canónico | Pronação muda contribuição e limitação pela pega/punho. |
| Pushdown barra vs corda | Variantes | Implemento não muda a ação principal. |
| Extensão acima da cabeça | Canónico | Posição do ombro altera comprimento da cabeça longa. |
| Extensão deitada | Canónico | Apoio, posição do ombro e trajetória justificam identidade. |
| Fundos, flexão estreita e supino fechado | Canónicos distintos | Cadeias, apoios, trajetórias e estabilidade diferem materialmente. |
| Farmer carry vs sustentação estática | Canónicos distintos | Transporte dinâmico e suporte isométrico têm exigências diferentes. |
| Curl de concentração | Variante do curl apoiado | Apoio muda, mas não fecha família mecânica adicional no núcleo. |
| Flexão do punho atrás do corpo | Variante técnica | Mesma ação; muda setup e estabilidade. |
| Hand gripper vs bola | Um canónico com variantes | Ambos são fecho resistido da mão; contacto e perfil ficam na variante. |
| Pega espessa | Variante de sustentação | O diâmetro muda contacto e desempenho, não o objetivo de suporte. |
| Towel hang | Variante do dead hang | A interface deformável muda a exigência, mas preserva a suspensão. |
| Transporte em pinça | Variante da pinça isométrica | Acrescenta locomoção sem criar nova capacidade de pinça. |
| `coracobrachialis` | Sem relação direta neste catálogo | As ações diretas são glenoumerais; não se força uma relação contextual sem evidência específica da tarefa. |
| `grip_limiter` | Campo separado do alvo muscular | Um potencial limitador não é promovido a músculo principal e nunca representa um resultado observado da série. |
| Pegas móveis de suspensão | Cadeia mista | Pés mantêm contacto com o solo, mãos mantêm contacto com pegas móveis e nenhum segmento distal é geometricamente fixo. |
| Fundos | Modelação por fase | A extensão do ombro descreve a descida; o regresso em direção a neutro ocorre na subida e é registado separadamente. |
| Cabeças do tríceps | Participação sem ênfase automática | Só a cabeça longa acima da cabeça conserva ênfase moderadamente suportada; as restantes ficam em evidência insuficiente. |

## Achado de proveniência

`src_murray_elbow_1995` na base v0.1.1 aponta para o PMID `7581389`, que não corresponde ao artigo. O PMID correto é `7775488`, DOI `10.1016/0021-9290(94)00114-J`. A base não foi alterada; este catálogo usa o URL correto e envia a correção para revisão.
"""
    write_text(out / "01_METHOD" / "DECISION_LOG.md", decisions)

    open_questions = """# Questões em aberto

1. Definir uma ontologia de geometrias de máquinas antes de expor perfis de resistência específicos.
2. Validar com especialista o exercício de oposição resistida do polegar.
3. Decidir na futura UI se variantes de equipamento aparecem como seletor ou fichas filhas.
4. Rever se o towel hang deve permanecer canónico após dados comparativos de preensão.
5. Corrigir o PMID de Murray numa futura versão aprovada da base muscular, sem alteração silenciosa.
"""
    write_text(out / "01_METHOD" / "OPEN_QUESTIONS.md", open_questions)

    specialist = """# Fila de revisão especialista

| Item | Estado | Motivo |
|---|---|---|
| `resisted_thumb_opposition` | `specialist_review` | Proximidade a uso clínico e necessidade de dose/resistência individual. |
| Máquinas de curl e tríceps | `approved_with_limits` | Came, eixo e trajetória variam entre modelos. |
| `bench_dip` | `approved_with_limits` | Extensão do ombro pode ser limitante. |
| `dead_hang` e `towel_hang` | `approved_with_limits` | Tolerância do ombro, preensão e segurança da ancoragem. |
| Desvios radial/ulnar e wrist roller | `approved_with_limits` | Alavanca e amplitude exigem controlo fino. |
| Achado `src_murray_elbow_1995` | `unresolved_base_fix` | Corrigir apenas em missão própria da base muscular. |
"""
    write_text(out / "11_EVIDENCE" / "SPECIALIST_REVIEW_QUEUE.md", specialist)

    coverage = f"""# Relatório final e cobertura

## Resumo executivo

Foram investigados {candidate_count} candidatos: {len(exercises)} exercícios canónicos, {len(variants)} variantes e {len(CANDIDATE_EXCLUSIONS)} duplicados/exclusões. A camada pública contém {len(public)} exercícios.

| Resultado | Número |
|---|---:|
| Candidatos investigados | {candidate_count} |
| Exercícios canónicos | {len(exercises)} |
| Variantes | {len(variants)} |
| Duplicados/exclusões | {len(CANDIDATE_EXCLUSIONS)} |
| Famílias | {len(FAMILIES)} |
| Equipamentos | {len(EQUIPMENT)} |
| Relações com músculos | {len(muscle_rows)} |
| Relações com articulações | {len(joint_rows)} |
| Relações com ações | {len(action_rows)} |
| Exercícios públicos | {len(public)} |
| Exercícios `approved_with_limits` | {status_counts["approved_with_limits"]} |
| Exercícios `specialist_review` | {status_counts["specialist_review"]} |

## Cobertura por estado

{coverage_table(status_counts, "Estado")}

## Cobertura por família

{coverage_table(family_counts, "Família")}

## Cobertura por equipamento

{coverage_table(all_equipment_counts, "Equipamento")}

## Cobertura muscular

{coverage_table(muscle_counts, "Músculo")}

## Candidatos excluídos

{coverage_table(exclusion_counts, "Classificação")}

## Controvérsias e limites

- Ênfase entre cabeças do bicípite não foi convertida em promessa pública.
- A posição acima da cabeça no tricípite tem evidência longitudinal específica, mas não autoriza isolamento.
- EMG serve como evidência aguda limitada, não como preditor validado de hipertrofia.
- Perfis de máquinas permanecem dependentes da geometria concreta.
- Grip pode ser limitado por fricção, contacto, pele, punho e estabilidade proximal, além da força muscular.

## Lacunas restantes

- O `coracobrachialis` não recebe relação direta porque as suas ações pertencem ao ombro e não existe justificação específica da tarefa neste catálogo.
- Perfis concretos de máquinas aguardam uma ontologia de came, eixo e trajetória.
- A oposição resistida do polegar permanece em `specialist_review`.
- O PMID incorreto de Murray na base v0.1.1 foi reportado, mas a base permaneceu imutável.

## Decisões e auditorias

As decisões de identidade estão fechadas no `DECISION_LOG.md`. As validações internas e externas passaram sem falhas; as auditorias independentes são preservadas em `_coordination`.

## Recomendação

Auditar este pacote e só depois criar uma missão de implementação que transforme canónicos e variantes numa UI, preservando estados, proveniência e relações.
"""
    write_text(out / "00_README" / "FINAL_REPORT.md", coverage)

    audit = f"""# Relatório de auditoria

Estado integrado: `PASS`.

## Auditorias

- Anatomia: auditoria independente `PASS`; ANAT-B01 a ANAT-B07 resolvidos.
- Biomecânica: ações compatíveis com articulações, fases e cadeia declarada.
- Identidade: 12 decisões obrigatórias e microvariações revistas.
- Evidência: cada relação muscular possui claim e fontes.
- Segurança: estados com limites e revisão especialista separados.
- PT-PT: auditoria independente da camada pública `PASS`; listas, cautelas e termos validados.
- Dados: auditoria estrutural independente `PASS`; zero relações órfãs e schemas presentes.
- Preensão: alvo, potencial de limitação e resultado observado são campos separados.
- Compatibilidade: todo papel muscular principal possui uma ação compatível na base v0.1.1.

## Verificações

- Internas: {internal_checks}, zero falhas.
- Externas: {external_result['checks']}, zero falhas.
- Estado externo: `{external_result['status']}`.

## Independência

Investigadores de flexão, extensão, antebraço/punho, preensão, identidade/equipamento e evidência trabalharam em relatórios separados. As reauditorias anatómica, pública/PT-PT e de dados estão preservadas em `_coordination`. A integração resolveu divergências sem editar a base canónica.
"""
    write_text(out / "12_AUDIT" / "AUDIT_REPORT.md", audit)

    validation = f"""# Relatório de validação

| Camada | Verificações | Falhas | Estado |
|---|---:|---:|---|
| Construtor interno | {internal_checks} | 0 | PASS |
| Validador externo | {external_result['checks']} | {len(external_result['failures'])} | {external_result['status']} |

Validações cobrem IDs únicos, pais de variantes, equipamentos, músculos, componentes, articulações, ações, relações órfãs, compatibilidade músculo-ação, fases dos fundos, cadeia mista de pegas móveis, campos de preensão, projeção pública, claims de papéis principais, fontes, estados públicos, PT-PT, proibição de isolamento absoluto e proibição de inferência de hipertrofia baseada apenas em EMG.

Manifest, hashes, CRC e determinismo são verificados na fase de embalagem final.
"""
    write_text(out / "12_AUDIT" / "VALIDATION_REPORT.md", validation)


def write_core_exports(
    out: Path,
    exercises: list[dict],
    variants: list[dict],
    muscle_rows: list[dict],
    joint_rows: list[dict],
    action_rows: list[dict],
    equipment_rows: list[dict],
    claims: list[dict],
    public: list[dict],
) -> None:
    export = out / "13_EXPORTS"
    write_jsonl(export / "exercises.jsonl", exercises)
    write_jsonl(export / "exercise_variants.jsonl", variants)
    write_json(
        export / "exercise_families.json",
        [
            {"schema_version": SCHEMA_VERSION, "family_id": family_id, "name_pt_pt": name, "domain": domain}
            for family_id, name, domain in sorted(FAMILIES)
        ],
    )
    write_json(
        export / "equipment.json",
        [
            {"schema_version": SCHEMA_VERSION, "equipment_id": equipment_id, "name_pt_pt": name, "equipment_type": kind}
            for equipment_id, name, kind in sorted(EQUIPMENT)
        ],
    )
    write_csv(
        export / "exercise_equipment_relations.csv",
        ["relation_id", "exercise_id", "equipment_id", "relation_type", "context", "source_ids"],
        sorted(equipment_rows, key=lambda row: row["relation_id"]),
    )
    write_csv(
        export / "exercise_joint_relations.csv",
        ["relation_id", "exercise_id", "joint_id", "role", "context", "confidence", "source_ids"],
        sorted(joint_rows, key=lambda row: row["relation_id"]),
    )
    write_csv(
        export / "exercise_action_relations.csv",
        ["relation_id", "exercise_id", "action_id", "role", "contraction_mode", "context", "confidence", "source_ids"],
        sorted(action_rows, key=lambda row: row["relation_id"]),
    )
    write_csv(
        export / "exercise_muscle_relations.csv",
        [
            "relation_id",
            "exercise_id",
            "muscle_id",
            "component_id",
            "role",
            "role_scope",
            "grip_role_default",
            "grip_limiter_default",
            "grip_limiter_observed",
            "context",
            "confidence",
            "evidence_type",
            "emphasis_evidence",
            "limitations",
            "source_ids",
        ],
        sorted(muscle_rows, key=lambda row: row["relation_id"]),
    )
    progression_rows = [
        {
            "relation_id": f"epr_{row['variant_id']}",
            "exercise_id": row["parent_exercise_id"],
            "variant_id": row["variant_id"],
            "relation_type": row["classification"],
            "rationale": row["mechanical_justification"],
        }
        for row in variants
        if row["classification"] in {"progression", "regression"}
    ]
    equivalence_rows = [
        {
            "relation_id": f"eev_{row['variant_id']}",
            "exercise_id": row["parent_exercise_id"],
            "variant_id": row["variant_id"],
            "equivalence_type": row["classification"],
            "rationale": row["mechanical_justification"],
        }
        for row in variants
        if row["classification"] not in {"progression", "regression"}
    ]
    write_csv(
        export / "exercise_progression_relations.csv",
        ["relation_id", "exercise_id", "variant_id", "relation_type", "rationale"],
        sorted(progression_rows, key=lambda row: row["relation_id"]),
    )
    write_csv(
        export / "exercise_equivalence_relations.csv",
        ["relation_id", "exercise_id", "variant_id", "equivalence_type", "rationale"],
        sorted(equivalence_rows, key=lambda row: row["relation_id"]),
    )
    write_json(export / "public_arm_exercises.json", public)
    for filename, schema in sorted(SCHEMAS.items()):
        write_json(export / "schemas" / filename, schema)

    write_csv(
        out / "11_EVIDENCE" / "SOURCE_LEDGER.csv",
        ["source_id", "title", "authors", "year", "source_type", "url", "scope", "quality"],
        sorted(SOURCES, key=lambda row: row["source_id"]),
    )
    write_csv(
        out / "11_EVIDENCE" / "CLAIMS_LEDGER.csv",
        ["claim_id", "exercise_id", "target_id", "condition", "outcome", "claim_type", "claim_summary", "affected_relation_id", "source_ids", "evidence_type", "strength", "confidence", "limitations", "review_status"],
        sorted(claims, key=lambda row: row["claim_id"]),
    )


def copy_coordination(out: Path) -> None:
    target = out / "_coordination"
    target.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(__file__), target / "build_arm_catalogue.py")
    validator = Path(__file__).with_name("validate_arm_catalogue.py")
    shutil.copy2(validator, target / "validate_arm_catalogue.py")
    reports = Path(__file__).with_name("agent_reports")
    if reports.exists():
        for path in sorted(reports.glob("*.md")):
            shutil.copy2(path, target / path.name)
    roster = """# Registo de equipas

- Flexão do cotovelo: investigação independente e integração.
- Extensão do cotovelo: investigação independente e integração.
- Antebraço e punho: investigação independente e integração.
- Preensão, carries e suportes: investigação independente e integração.
- Identidade e equipamentos: crítica transversal.
- Evidência e segurança: crítica transversal.
- Auditoria final: anatomia, biomecânica/dados e PT-PT.

Os relatórios independentes foram preservados nesta pasta. Os achados críticos foram corrigidos ou escalados no pacote final.
"""
    write_text(target / "AGENT_ROSTER.md", roster)


def make_manifest(out: Path, counts: dict) -> None:
    payload = [
        path
        for path in sorted(out.rglob("*"))
        if path.is_file() and path.name not in {"MANIFEST.json", "SHA256SUMS.txt"}
    ]
    manifest = {
        "package_id": OUT_NAME,
        "version": SCHEMA_VERSION,
        "build_date": BUILD_DATE,
        "canonical_input": {
            "filename": BASE_ZIP.name,
            "sha256": EXPECTED_BASE_SHA256,
            "immutability": "verified_no_writes_to_source_package",
        },
        "counts": counts,
        "files": [
            {
                "path": path.relative_to(out).as_posix(),
                "size": path.stat().st_size,
                "sha256": sha256_file(path),
            }
            for path in payload
        ],
    }
    write_json(out / "MANIFEST.json", manifest)
    checksum_files = [
        path
        for path in sorted(out.rglob("*"))
        if path.is_file() and path.name != "SHA256SUMS.txt"
    ]
    write_text(
        out / "SHA256SUMS.txt",
        "\n".join(f"{sha256_file(path)}  {path.relative_to(out).as_posix()}" for path in checksum_files),
    )


def deterministic_zip(out: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(out.rglob("*")):
            if not path.is_file():
                continue
            arcname = f"{OUT_NAME}/{path.relative_to(out).as_posix()}"
            info = zipfile.ZipInfo(arcname, ZIP_TIMESTAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            zf.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(zip_path) as zf:
        bad = zf.testzip()
        if bad is not None:
            raise AssertionError(f"CRC inválido: {bad}")


def run_external_validator(out: Path) -> dict:
    import subprocess

    validator = Path(__file__).with_name("validate_arm_catalogue.py")
    result = subprocess.run(
        [sys.executable, str(validator), str(out), str(BASE), "--json"],
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise AssertionError(f"Validador externo falhou:\n{result.stdout}\n{result.stderr}")
    parsed = json.loads(result.stdout)
    if parsed["status"] != "PASS":
        raise AssertionError(f"Validador externo reprovou: {parsed['failures']}")
    return parsed


def build(output_parent: Path) -> dict:
    load_base_ids()
    muscle_rows, joint_rows, action_rows, equipment_rows, claims = derive_relations()
    internal_checks = internal_validate(EXERCISES, VARIANTS, muscle_rows, joint_rows, action_rows, equipment_rows, claims)
    public = public_rows(EXERCISES, muscle_rows)

    output_parent.mkdir(parents=True, exist_ok=True)
    out = output_parent / OUT_NAME
    zip_path = output_parent / f"{OUT_NAME}.zip"
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    write_core_exports(out, EXERCISES, VARIANTS, muscle_rows, joint_rows, action_rows, equipment_rows, claims, public)
    copy_coordination(out)

    preliminary = run_external_validator(out)
    build_documents(
        out,
        EXERCISES,
        VARIANTS,
        muscle_rows,
        joint_rows,
        action_rows,
        equipment_rows,
        claims,
        public,
        internal_checks,
        preliminary,
    )

    counts = {
        "candidates_investigated": len(EXERCISES) + len(VARIANTS) + len(CANDIDATE_EXCLUSIONS),
        "canonical_exercises": len(EXERCISES),
        "variants": len(VARIANTS),
        "candidate_duplicates_or_exclusions": len(CANDIDATE_EXCLUSIONS),
        "families": len(FAMILIES),
        "equipment": len(EQUIPMENT),
        "muscle_relations": len(muscle_rows),
        "joint_relations": len(joint_rows),
        "action_relations": len(action_rows),
        "equipment_relations": len(equipment_rows),
        "claims": len(claims),
        "sources": len(SOURCES),
        "public_exercises": len(public),
        "approved_public": sum(row["status"] == "approved_public" for row in EXERCISES),
        "approved_with_limits": sum(row["status"] == "approved_with_limits" for row in EXERCISES),
        "specialist_review": sum(row["status"] == "specialist_review" for row in EXERCISES),
    }
    make_manifest(out, counts)
    first_final = run_external_validator(out)
    build_documents(
        out,
        EXERCISES,
        VARIANTS,
        muscle_rows,
        joint_rows,
        action_rows,
        equipment_rows,
        claims,
        public,
        internal_checks,
        first_final,
    )
    make_manifest(out, counts)
    final_external = run_external_validator(out)
    if final_external["checks"] != first_final["checks"]:
        raise AssertionError("A contagem do validador externo mudou após estabilização do manifest")
    deterministic_zip(out, zip_path)
    return {
        "output_directory": str(out),
        "zip_path": str(zip_path),
        "zip_sha256": sha256_file(zip_path),
        "zip_entries": len(zipfile.ZipFile(zip_path).infolist()),
        "internal_checks": internal_checks,
        "external_checks": final_external["checks"],
        "counts": counts,
    }


def main() -> int:
    output_parent = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT
    result = build(output_parent)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
