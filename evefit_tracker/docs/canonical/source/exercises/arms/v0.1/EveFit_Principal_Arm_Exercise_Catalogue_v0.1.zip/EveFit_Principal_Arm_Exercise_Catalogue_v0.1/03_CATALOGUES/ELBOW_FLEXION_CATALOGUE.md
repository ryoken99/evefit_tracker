# Flexão do cotovelo

O papel muscular é contextual e nunca significa isolamento absoluto.

## Curl em pé com pega supinada

- ID: `standing_supinated_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Flexão controlada do cotovelo com o antebraço supinado, mantendo o punho estável.
- Músculos principais/contextuais: Bicípite braquial e braquial.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Barra reta.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica neutro junto ao tronco e a resistência é vertical pela gravidade. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl em suspensão com peso corporal

- ID: `suspension_bodyweight_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Flexão do cotovelo em cadeia mista, aproximando o corpo das mãos através de pegas móveis num sistema de suspensão.
- Músculos principais/contextuais: Bicípite braquial e braquial.
- Secundários/estabilizadores: Braquiorradial, grande dorsal e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Peso corporal e sistema de suspensão.
- Mecânica: A resistência resulta da componente do peso corporal perpendicular à linha entre pés e mãos. A posição dos pés regula a dificuldade sem alterar a identidade.

### Execução

1. Segurar as pegas com o corpo alinhado e cotovelos estendidos, mantendo tensão no sistema.
2. Fletir os cotovelos para aproximar a testa ou ombros das mãos, sem perder o alinhamento corporal.
3. Terminar antes de os ombros avançarem ou o tronco perder rigidez; regressar sob controlo.

**Cues:** Manter o corpo alinhado, apontar as palmas para cima e mover pelos cotovelos.

**Erros frequentes:** Dobrar a anca, transformar o gesto numa remada e usar ancoragem instável.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl inverso

- ID: `reverse_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_pronated`
- Objetivo: Flexão controlada do cotovelo com o antebraço pronado, mantendo o punho estável.
- Músculos principais/contextuais: Braquial e braquiorradial.
- Secundários/estabilizadores: Bicípite braquial, extensor radial curto do carpo e extensor radial longo do carpo.
- Possíveis limitadores de preensão: Flexor profundo dos dedos.
- Equipamento base: Barra EZ.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica neutro junto ao tronco e a resistência é vertical pela gravidade. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl martelo

- ID: `hammer_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_neutral`
- Objetivo: Flexão controlada do cotovelo com o antebraço neutro, mantendo o punho estável.
- Músculos principais/contextuais: Braquial e braquiorradial.
- Secundários/estabilizadores: Bicípite braquial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Flexor superficial dos dedos.
- Equipamento base: Halter.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica neutro junto ao tronco e a resistência é vertical pela gravidade. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl no banco Scott

- ID: `preacher_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Flexão controlada do cotovelo com o antebraço supinado ou semissupinado conforme a barra, mantendo o punho estável.
- Músculos principais/contextuais: Bicípite braquial e braquial.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Banco Scott e Barra EZ.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica em flexão, com o braço apoiado no banco scott e a resistência é vertical pela gravidade ou definida pela máquina/cabo. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl spider

- ID: `spider_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Flexão controlada do cotovelo com o antebraço supinado, mantendo o punho estável.
- Músculos principais/contextuais: Bicípite braquial e braquial.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Halter e banco inclinado.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica em flexão, com o peito apoiado num banco inclinado e braços pendentes e a resistência é vertical pela gravidade. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl supinado com ombro em extensão

- ID: `shoulder_extended_supinated_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Flexão controlada do cotovelo com o antebraço supinado, mantendo o punho estável.
- Músculos principais/contextuais: Bicípite braquial e braquial.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Halter e banco inclinado.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica em extensão relativa atrás do tronco, apoiado num banco inclinado e a resistência é vertical pela gravidade. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Elevação na barra com pega supinada

- ID: `supinated_chin_up`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Tração vertical multiarticular com pega supinada, na qual os flexores do cotovelo têm papel relevante mas não exclusivo.
- Músculos principais/contextuais: Bicípite braquial, braquial e grande dorsal.
- Secundários/estabilizadores: Braquiorradial e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Peso corporal e barra fixa.
- Mecânica: Exercício de cadeia fechada para cotovelo e ombro. O bicípite e o braquial contribuem para a flexão do cotovelo, enquanto músculos das costas e cintura escapular também são determinantes.

### Execução

1. Suspender-se numa barra fixa com pega supinada segura, cotovelos estendidos sem relaxamento descontrolado.
2. Puxar o corpo para cima através de flexão do cotovelo e movimento coordenado do ombro/escápula; descer sob controlo.
3. Terminar a subida sem projetar a cabeça ou perder o controlo escapular; regressar à suspensão controlada.

**Cues:** Iniciar com controlo escapular, manter a pega fechada e evitar balanço das pernas.

**Erros frequentes:** Usar impulso excessivo, soltar bruscamente para a extensão e forçar amplitude do ombro dolorosa.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.
