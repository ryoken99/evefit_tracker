# Verificação pública localizada final

## Veredito

**PASS**

Alvo auditado:

`test_build7/EveFit_Principal_Arm_Exercise_Catalogue_v0.1`

Blockers: **nenhum**.

Esta verificação foi apenas de leitura. Nenhum ficheiro do pacote, da base muscular
ou da aplicação foi alterado.

## FDP/FDS em hangs e carries

**PASS**

`dead_hang`, `farmers_carry` e `suitcase_carry` publicam simultaneamente:

- Flexor profundo dos dedos em `primary_muscles`;
- Flexor superficial dos dedos em `primary_muscles`;
- Flexor profundo dos dedos em `potential_grip_limiters`;
- Flexor superficial dos dedos em `potential_grip_limiters`.

Nas relações estruturadas, ambos possuem:

- `role = primary_contextual`;
- `role_scope = task_context_role`;
- `grip_role_default = potential_limiter`;
- `grip_limiter_default = possible`;
- `grip_limiter_observed = unknown`;
- contexto de flexão digital e manutenção da preensão.

O modelo representa corretamente os dois factos distintos: FDP/FDS são
contribuintes principais contextuais da tarefa e podem também limitar a execução
pela preensão, sem afirmar que essa limitação foi observada numa série concreta.

## Curls e rolo de punho

**PASS**

Foram auditados:

- `hammer_curl`;
- `preacher_curl`;
- `reverse_curl`;
- `shoulder_extended_supinated_curl`;
- `spider_curl`;
- `standing_supinated_curl`;
- `supinated_chin_up`;
- `suspension_bodyweight_curl`;
- `wrist_roller`.

Nenhuma relação `grip_limiter` é promovida a `primary_muscles`.

Os músculos permanecem apenas em `potential_grip_limiters`, enquanto os músculos
principais refletem a ação ou tarefa principal. Exemplos confirmados:

- curls supinados: bicípite braquial e braquial;
- curl martelo e curl inverso: braquial e braquiorradial;
- curl em suspensão: bicípite braquial e braquial;
- rolo de punho: flexores e extensores do punho, sem promover o flexor profundo dos
  dedos a principal apenas por poder limitar a preensão.

## Apoio isométrico nas paralelas

**PASS**

Em `parallel_bar_support_hold`:

- FDP e FDS possuem `role = stabilizer`;
- `grip_role_default = stabilizer`;
- `grip_limiter_default = unlikely`;
- `grip_limiter_observed = unknown`;
- ambos aparecem apenas em `secondary_muscles`;
- nenhum aparece em `primary_muscles`;
- `potential_grip_limiters` está vazio.

O tricípite braquial permanece como único músculo principal. A camada pública não
apresenta a preensão como limitador universal do apoio nas paralelas.

## PT-PT

**PASS**

Foram reconfirmadas:

- zero sequências geradas `.,`;
- zero sequências geradas `..`;
- zero campos vazios renderizados como `Secundários/estabilizadores: .`;
- zero maiúsculas indevidas após vírgula nas linhas de `Cues`, `Erros frequentes`
  e `Cautelas`;
- capitalização coerente nas enumerações de músculos e equipamentos;
- uso de `Nenhum identificado` quando uma lista pública está vazia;
- ausência dos termos brasileiros bloqueados `pegada`, `usuário`, `academia` e
  `celular`.

Os catálogos Markdown e `public_arm_exercises.json` representam de forma coerente
os músculos principais, secundários e potenciais limitadores.

## Estados e integridade estrutural

Mantêm-se:

| Entidade | Número |
|---|---:|
| Exercícios canónicos | 36 |
| Variantes | 85 |
| Exercícios públicos | 35 |
| `approved_public` | 29 |
| `approved_with_limits` | 6 |
| `specialist_review` | 1 |
| Relações musculares | 228 |
| Claims | 545 |

O validador incluído foi reexecutado contra `test_build7` e a base muscular
v0.1.1:

- **9033 verificações**;
- **zero falhas**;
- estado `PASS`.

## Conclusão

O alvo `test_build7` passa a verificação pública localizada. A distinção entre
contribuição muscular contextual, estabilização e potencial limitação pela
preensão está coerente nos dados estruturados, no export público e nos catálogos
PT-PT.
