# Política de conteúdo público

A camada pública inclui apenas `approved_public` e `approved_with_limits`.

Cada ficha apresenta nome, objetivo geral, músculos principais/contextuais, secundários, possíveis limitadores de preensão, equipamento, instruções, erros, cautelas, controlos ambientais e alternativas simples. `grip_limiter` nunca é promovido automaticamente a músculo principal; o alvo da tarefa e o potencial de limitação são campos distintos. Os registos `approved_with_limits` incluem ainda uma justificação pública específica. Claims frágeis ou controvérsias complexas permanecem no ledger interno. `specialist_review`, `internal_only`, `duplicate` e `excluded` não são publicados.
