# Relatório independente das Equipas 5 e 6

## Equipamentos, identidade, variantes e equivalências

**Missão:** Catálogo Canónico dos Principais Exercícios de Braços v0.1  
**Âmbito:** revisão independente de identidade, variantes, máquinas, equipamentos, equivalências, duplicados e microvariações  
**Base anatómica preservada:** `EveFit_Muscular_Knowledge_Base_v0.1.1`  
**SHA-256 da base:** `a1876a1d4bc21ab54b3828774f66a99519a4953dc00191e69475d8c15b8b30b0`  
**Alterações à base, aplicação ou pacote final:** nenhuma  
**Data:** 2026-07-30

## 1. Conclusão executiva

A identidade deve ser definida pela tarefa mecânica, não pelo nome do aparelho ou pela combinação comercial de acessórios. O mesmo exercício pode possuir variantes com barra reta, barra EZ, halteres, cabo, banda ou máquina desde que se mantenham a posição estrutural definidora, as articulações ativas, a cadeia cinética e o objetivo técnico. O perfil de resistência e a interface devem ficar registados na variante, nunca apagados por uma falsa equivalência.

As doze decisões obrigatórias fecham assim:

1. Barra reta e barra EZ no curl: mesma identidade canónica, variantes de equipamento e de orientação da pega.
2. Barra e halteres: variantes de equipamento quando ombro, antebraço e trajetória se mantêm; supinação dinâmica com halter é uma variante técnica adicional.
3. Curl inclinado: identidade canónica própria, preferencialmente com ID posicional `shoulder_extended_supinated_curl`.
4. Curl Scott/preacher: identidade canónica própria.
5. Curl spider: identidade canónica própria, distinta do Scott pela ausência de apoio direto do braço.
6. Curl martelo: identidade canónica própria pela orientação neutra mantida do antebraço.
7. Curl inverso: identidade canónica própria pela pronação mantida.
8. Pushdown com barra e com corda: mesma identidade canónica; são variantes de implemento e pega.
9. Extensão acima da cabeça: identidade canónica própria pela elevação do ombro e mudança de comprimento da cabeça longa.
10. Extensão deitada: identidade canónica própria pela posição supina, posição do ombro, suporte e perfil gravítico.
11. Fundos em paralelas, flexão de braços com mãos próximas e supino com pega fechada: três identidades canónicas distintas. Fundos no banco também permanece distinto, mas com limites.
12. Farmer carry e sustentação com barra: duas identidades canónicas distintas, porque uma inclui locomoção e controlo dinâmico global e a outra é uma sustentação estática sem deslocamento.

O inventário observado durante esta revisão tinha 41 entradas e 33 IDs de equipamento. A remoção recente de `standing_cable_curl`, `elastic_band_curl`, `concentration_curl` e `machine_elbow_curl` como canónicos independentes está alinhada com esta auditoria, desde que esses candidatos reapareçam como variantes ou configurações e não desapareçam da cobertura pública.

Persistem problemas estruturais antes de aprovação:

- o construtor atribui `entity_type = canonical_exercise` a todas as entradas através da função comum;
- não existe ainda um modelo materializado de variantes com herança e sobreposições mecânicas;
- `required_ids`, `optional_ids` e `alternative_ids` não distinguem com segurança conjunção, alternativa e equipamento específico da variante;
- `kettlebell`, `carry_object` e `plate_loaded_curl_machine` não têm qualquer relação no inventário revisto;
- a máquina Scott/preacher não está representada de forma inequívoca;
- algumas descrições e relações de equipamento contradizem-se;
- o URL de `src_murray_elbow_1995` aponta para o PMID errado.

Estes pontos são blockers de dados e embalagem, não de anatomia.

## 2. Política de identidade proposta

### 2.1 Regra de identidade

Criar uma identidade canónica quando existe diferença material e estável em pelo menos um destes eixos:

- conjunto de articulações ativamente movidas;
- ação articular dinâmica;
- posição estrutural do ombro ou antebraço;
- cadeia cinética;
- segmento distal fixo ou móvel;
- trajetória reconhecível;
- suporte direto do braço ou do corpo;
- direção de aplicação da força;
- perfil externo de resistência;
- modo de preensão;
- exigência de estabilidade;
- amplitude funcional característica;
- objetivo técnico da tarefa.

Um equipamento diferente não cria automaticamente um exercício diferente. Contudo, uma variante de equipamento deve guardar as mudanças que efetivamente produz. “Equivalente” significa mesma identidade-pai, não mecânica byte a byte igual.

### 2.2 Hierarquia recomendada

| Camada | Função | Exemplo |
|---|---|---|
| `canonical_exercise` | Tarefa mecânica estável | `standing_supinated_curl` |
| `exercise_variant` | Manifestação reconhecida com diferença prática subordinada | curl de concentração |
| `equipment_variant` | Implemento ou fonte de resistência diferente | barra, halteres, cabo ou banda |
| `grip_orientation_variant` | Orientação da mão dentro de uma identidade que a tolera | barra EZ semissupinada |
| `technique_variant` | Trajetória ou ação acessória definida | curl com supinação dinâmica |
| `configuration` | Ajuste sem identidade própria | unilateral, bilateral, alternado, largura pequena de pega |
| `progression` / `regression` | Mudança de dificuldade | assistência elástica no chin-up |
| `duplicate` | Outro nome para a mesma entidade | “skull crusher” como sinónimo, quando a trajetória é a mesma |
| `excluded` | Termo sem geometria suficiente | “extensão com banda” sem posição ou ancoragem |

### 2.3 Campos mínimos da variante

Cada variante deve possuir:

- `variant_id`;
- `parent_exercise_id`;
- `variant_type`;
- `name_pt_pt`;
- `name_en`;
- `overrides`;
- `required_equipment_any_of`;
- `required_equipment_all_of`;
- `optional_equipment`;
- `forearm_position`;
- `wrist_position`;
- `shoulder_position`;
- `resistance_direction`;
- `resistance_profile`;
- `laterality`;
- `support_geometry`;
- `anchorage`;
- `stability_delta`;
- `public_status`;
- `source_ids`;
- `limitations`.

`overrides` deve conter apenas os campos que mudam. Os campos ausentes são herdados do exercício-pai. Uma variante não pode alterar silenciosamente articulações, ações ou cadeia cinética. Se essas alterações excederem o limiar de identidade, deve ser promovida a canónico.

### 2.4 Semântica necessária para equipamentos

O modelo atual usa listas simples, mas precisa de distinguir:

- **todos obrigatórios:** por exemplo, coluna de cabos + polia alta + acessório;
- **um de vários obrigatório:** por exemplo, barra reta ou barra EZ ou halteres;
- **opcional em adição:** por exemplo, fat grips sobre um halter;
- **alternativa de implementação:** equipamento que substitui toda a fonte de resistência;
- **suporte:** banco, banco Scott, rack;
- **ancoragem:** alta, baixa, ajustável;
- **interface:** corda, barra, pega unilateral;
- **mecanismo:** peso livre, cabo, elástico, came, alavanca;
- **configuração da máquina:** selectorized ou plate-loaded.

Sem esta separação, `optional_ids=["dumbbell"]` pode ser lido erradamente como “usar halteres juntamente com a barra”, quando a intenção real é escolher uma variante.

## 3. Matriz das decisões obrigatórias

| Questão | Decisão | Tipo | Identidade-pai ou ID recomendado | Razão mecânica | Confiança |
|---|---|---|---|---|---|
| Curl com barra reta | representação de variante | `equipment_variant` | `standing_supinated_curl` | Pega bilateral fixa e resistência gravítica, sem nova ação | alta |
| Curl com barra EZ | não criar canónico | `equipment_variant` + `grip_orientation_variant` | `standing_supinated_curl` | Semissupinação e conforto podem mudar; tarefa principal mantém-se | alta |
| Curl com halteres | não criar canónico apenas pelo implemento | `equipment_variant` | `standing_supinated_curl` | Permite braços independentes e alinhamento livre, mas não muda necessariamente a tarefa | alta |
| Curl alternado | não criar entidade | `configuration` | variante com halteres | Sequência temporal entre lados não muda a repetição de cada braço | alta |
| Curl com supinação dinâmica | manter subordinado | `technique_variant` | `standing_supinated_curl` | Acrescenta rotação radioulnar dinâmica; deve declarar `forearm_supination` | alta |
| Curl inclinado | manter identidade | `canonical_exercise` | `shoulder_extended_supinated_curl` | Ombro em extensão, tronco apoiado e comprimento muscular diferentes | alta |
| Curl Scott/preacher | manter identidade | `canonical_exercise` | `preacher_curl` | Braço apoiado, ombro flexionado e perfil externo característico | alta |
| Curl de concentração | não manter como canónico | `exercise_variant` | `preacher_curl` ou família de curl apoiado | Apoio na coxa e geometria menos padronizada; diferença insuficiente para novo canónico | moderada |
| Curl spider | manter identidade | `canonical_exercise` | `spider_curl` | Ombro flexionado e tronco apoiado, mas braço livre; difere do Scott em apoio e estabilidade | moderada-alta |
| Curl no cabo em pé | não manter como canónico | `equipment_variant` | identidade posicional correspondente | Polia muda direção e perfil, não a posição definidora | alta |
| Curl com banda | não manter como canónico | `equipment_variant` | identidade posicional correspondente | Elasticidade muda o perfil, não a tarefa-base | alta |
| Curl na máquina | não aceitar nome genérico como canónico | `equipment_variant` ou `excluded_pending_geometry` | em pé, Scott ou outra identidade geométrica | Came, eixo, apoio e pega variam entre máquinas | alta |
| Curl martelo | manter identidade | `canonical_exercise` | `hammer_curl` | Antebraço neutro mantido altera coordenação e identidade pública | alta |
| Curl martelo cruzado | não criar canónico | `technique_variant` | `hammer_curl` | Trajetória cruza o tronco, mantendo a ação principal e a pega neutra | moderada-alta |
| Curl inverso | manter identidade | `canonical_exercise` | `reverse_curl` | Pronação mantida é material e reconhecível | alta |
| Pushdown com barra | representação-base | `equipment_variant` do canónico | `cable_triceps_pushdown` | Ombro junto ao tronco, polia alta, extensão do cotovelo | alta |
| Pushdown com corda | não criar canónico | `equipment_variant` + pega neutra | `cable_triceps_pushdown` | Mãos independentes e interface mudam, sem nova tarefa articular | alta |
| Pushdown unilateral | não criar entidade | `configuration` | `cable_triceps_pushdown` | O lado não cria identidade; estabilidade pode ser sobreposta | alta |
| Extensão acima da cabeça | manter identidade | `canonical_exercise` | `overhead_triceps_extension` | Ombro elevado e cabeça longa em maior comprimento | alta |
| Overhead com cabo, halter, EZ ou banda | variantes | `equipment_variant` | `overhead_triceps_extension` | Perfil e estabilidade mudam, posição definidora mantém-se | alta |
| Extensão deitada | manter identidade | `canonical_exercise` | `lying_triceps_extension` | Corpo apoiado, ombro elevado e perfil gravítico próprio | alta |
| Deitada com barra, EZ ou halteres | variantes | `equipment_variant` | `lying_triceps_extension` | Liberdade bilateral e pega mudam, tarefa mantém-se | alta |
| Fundos em paralelas | manter identidade | `canonical_exercise` | `parallel_bar_dip` | Cadeia fechada, corpo desloca-se entre apoios | alta |
| Flexão estreita | manter identidade | `canonical_exercise` | `close_grip_push_up` | Mãos fixas no solo e corpo move-se como unidade | alta |
| Supino fechado | manter identidade | `canonical_exercise` | `close_grip_bench_press` | Carga externa móvel, tronco apoiado e cadeia aberta do membro superior | alta |
| Fundos no banco | manter distinto com limites | `canonical_exercise` | `bench_dip` | Apoio posterior e maior extensão do ombro | moderada-alta |
| Farmer carry | manter identidade | `canonical_exercise` | `farmers_carry` | Locomoção bilateral carregada, preensão sustentada e estabilidade dinâmica | alta |
| Barbell/dumbbell hold | fundir por implemento | `canonical_exercise` + variantes | `support_grip_hold` | Sustentação estática sem deslocamento | alta |
| Thick-grip hold | manter como modo de preensão ou variante material | `exercise_variant` por defeito; promover apenas se a taxonomia exigir alvo `open_hand` de topo | `support_grip_hold` | Diâmetro muda abertura da mão, mas não a tarefa de sustentação | moderada |

## 4. Justificação evidencial das decisões mecânicas

### 4.1 Barra reta, EZ e halteres

Marcolin et al. compararam agudamente curl com halteres, barra reta e barra EZ. Encontraram diferenças de sEMG entre condições, mas concluíram que a pequena diferença entre barra reta e EZ deixa a escolha largamente dependente de conforto. Coratella et al. encontraram uma vantagem aguda moderada da barra reta em algumas condições, mostrando que a direção do efeito não é universal. Estes estudos suportam o registo da pega e do implemento, mas não três identidades canónicas nem alegações de superioridade adaptativa.

Fontes primárias:

- [Marcolin et al., 2018, PeerJ, texto integral](https://pmc.ncbi.nlm.nih.gov/articles/PMC6047503/)
- [Coratella et al., 2023, JFMK, texto integral](https://pmc.ncbi.nlm.nih.gov/articles/PMC9944112/)

Limitação: ambos são estudos agudos de excitação muscular. Não demonstram diferenças de hipertrofia e não tornam o implemento uma identidade.

### 4.2 Posição do ombro no curl

Oliveira et al. compararam curl clássico, inclinado e preacher com halteres. Os padrões de ativação ao longo da amplitude diferiram em função da posição e do momento externo. Isto sustenta a descrição mecânica distinta do inclinado e do Scott, mas não prova isolamento de cabeças nem superioridade longitudinal.

Attarieh et al. compararam longitudinalmente preacher e Bayesian cable curl, com resultados semelhantes de hipertrofia e força quando as condições foram aproximadas. A posição continua a ser uma diferença de identidade, mas não deve ser traduzida em promessa de adaptação superior.

Fontes primárias:

- [Oliveira et al., 2009, Journal of Sports Science and Medicine](https://pmc.ncbi.nlm.nih.gov/articles/PMC3737788/)
- [Attarieh et al., 2025, PubMed](https://pubmed.ncbi.nlm.nih.gov/40082069/)

Não foi localizada evidência primária direta suficiente para declarar o spider superior ou seletivo. A identidade do spider é uma decisão geométrica: ombro em flexão, tronco apoiado e braço sem apoio direto.

### 4.3 Orientação do antebraço

Murray, Delp e Buchanan demonstraram que os braços de momento dos músculos do cotovelo variam com o ângulo e a posição do antebraço. Isto sustenta a separação das orientações supinada, neutra e pronada quando mantidas como característica definidora, sem permitir promessas universais de recrutamento ou adaptação.

Fonte primária correta:

- [Murray, Delp e Buchanan, 1995, PMID 7775488](https://pubmed.ncbi.nlm.nih.gov/7775488/)

O construtor observado contém `https://pubmed.ncbi.nlm.nih.gov/7581389/` para `src_murray_elbow_1995`. Esse PMID é incorreto para este artigo e deve ser corrigido no ledger da missão. A base muscular não foi alterada.

### 4.4 Pushdown com barra versus corda

Não existe evidência longitudinal que transforme a corda e a barra em exercícios distintos. Rendos et al. não estudaram diretamente corda versus barra reta; compararam condições de pega e não encontraram diferenças significativas de sEMG do tricípite entre condições. O artigo não pode ser usado como prova de superioridade da corda.

Fonte primária:

- [Rendos et al., 2016, PubMed](https://pubmed.ncbi.nlm.nih.gov/26694502/)

A corda permite mãos independentes, pega mais neutra e separação terminal. A barra fixa as mãos num implemento comum. Estas diferenças devem ficar na variante e na execução, sem alegar isolamento de cabeças.

### 4.5 Extensão acima da cabeça

Maeo et al. compararam 12 semanas de extensão do cotovelo no cabo acima da cabeça e com braço neutro. A posição acima da cabeça produziu maior hipertrofia do tricípite no protocolo estudado. A evidência sustenta uma identidade posicional própria e uma ênfase contextual moderada, nunca a alegação de que só a cabeça longa trabalha ou de que qualquer variante overhead é universalmente superior.

Fonte primária:

- [Maeo et al., 2023, PubMed](https://pubmed.ncbi.nlm.nih.gov/35819335/)

### 4.6 Fundos, flexão estreita e supino fechado

Os três exercícios não são equivalentes:

- fundos: mãos fixas, corpo desloca-se verticalmente, grande participação do ombro e cintura escapular;
- flexão estreita: mãos fixas no solo, corpo move-se em prancha, adução horizontal e protração escapular;
- supino fechado: tronco apoiado, barra móvel, necessidade de rack e trajetória externa.

McKenzie et al. mostraram diferenças cinemáticas entre fundos no banco, barras e argolas, incluindo maior extensão do ombro nos fundos no banco. Cogley et al. e Saeterbakken et al. suportam que a largura das mãos/pega altera a tarefa aguda, mas não transformam cada largura num exercício novo.

Fontes primárias:

- [McKenzie et al., 2022, texto integral](https://pmc.ncbi.nlm.nih.gov/articles/PMC9603242/)
- [Cogley et al., 2005, PubMed](https://pubmed.ncbi.nlm.nih.gov/16095413/)
- [Saeterbakken et al., 2021, PubMed](https://pubmed.ncbi.nlm.nih.gov/34198674/)

## 5. Cobertura de equipamentos

### 5.1 Matriz de cobertura observada

| Requisito | Estado observado | Registos associados | Decisão |
|---|---|---|---|
| Peso corporal | coberto | chin-up, suspensão, fundos, flexão, hangs e apoio | manter |
| Barra reta | coberto | curl, supino, hold, dedos, variante de extensão | manter como equipamento/variante |
| Barra EZ | coberto | preacher, inverso, extensão overhead/deitada | manter como variante |
| Halteres | coberto | curls, extensões, punho, desvios, carries | manter |
| Kettlebell | **ausente** | nenhum | adicionar como variante de `farmers_carry`, `suitcase_carry` e `support_grip_hold`; não criar exercício novo |
| Cabos | coberto | pushdown, overhead, cruzada, kickback e curls alternativos | manter |
| Polia alta | coberto | pushdown | manter como ancoragem |
| Polia baixa | coberto | kickback e implicitamente curl alternativo | criar variante explícita do curl em pé |
| Polia ajustável | coberto | overhead e cruzada | manter |
| Corda | coberto | pushdown, overhead, martelo | manter como interface |
| Banda elástica | coberto | curl, pushdown, overhead, extensão de dedos e assistência | exigir ancoragem e identidade-pai |
| Máquina selectorized | coberto parcialmente | máquina de tríceps e alternativa de curl | manter mecanismo |
| Máquina plate-loaded | coberto parcialmente | opcional na máquina de tríceps; **ausente no curl** | ligar a variante de máquina de curl/preacher |
| Máquina de curl | cobertura parcial | `selectorized_curl_machine` apenas como alternativa do preacher | restringir por geometria |
| Máquina Scott/preacher | **ambígua** | `preacher_bench` + máquina genérica | adicionar `support_geometry=preacher` ou ID específico |
| Máquina de tríceps | coberto com limites | `machine_triceps_extension` | exigir braço apoiado e eixo identificável |
| Banco | coberto | plano, inclinado e Scott | manter subtipos |
| Barra fixa | coberto | chin-up e hangs | manter |
| Paralelas | coberto | fundos e apoio | remover uso como “alternativa” genérica da flexão estreita |
| Argolas | cobertura parcial | opção em exercícios de suspensão | adicionar variante de fundos/apoio em argolas, sem novo canónico automático |
| Suspensão | coberto | curls e extensões com peso corporal | manter |
| Discos | coberto | pinça e rolo de punho | manter |
| Toalha | coberto | towel hang | reclassificar como variante de `dead_hang`, não canónico independente |
| Fat grips | coberto | thick-grip hold | modelar como acessório sobre implemento |
| Hand grippers | coberto | fecho de hand gripper | manter |
| Wrist roller | coberto | rolo de punho | manter identidade própria |
| Martelo/alavanca | coberto | pronação e supinação | manter |
| Objetos de transporte | **ausente** | nenhum | ligar a carries; não criar identidade por objeto |
| Resistência manual | cobertura insuficiente | apenas oposição do polegar em revisão | ligar como variante a pronação/supinação; definir parceiro ou auto-resistência |

### 5.2 Taxonomia de máquina recomendada

Não usar a marca nem “máquina de bíceps/tríceps” como identidade. Separar:

| Eixo | Valores recomendados |
|---|---|
| Função | `elbow_curl`, `supported_elbow_extension`, `dip_press` |
| Mecanismo | `selectorized`, `plate_loaded`, `pneumatic`, `other_known` |
| Apoio | `preacher_arm_support`, `neutral_arm_support`, `unsupported`, `manufacturer_specific` |
| Pega | `supinated`, `semisupinated`, `neutral`, `pronated`, `independent` |
| Eixo | `aligned_adjustable`, `fixed`, `unknown` |
| Perfil | `cam_defined`, `lever_defined`, `unknown_manufacturer_specific` |

Uma máquina de curl com apoio Scott deve apontar para `preacher_curl`. Uma máquina com braços junto ao tronco e sem apoio Scott deve apontar para a identidade posicional correspondente. Uma máquina de fundos não é `machine_triceps_extension`.

## 6. Duplicados e microvariações

### 6.1 Devem ser variantes, configurações ou sinónimos

| Candidato | Classificação | Pai | Observação |
|---|---|---|---|
| `standing_cable_curl` | `equipment_variant` | `standing_supinated_curl` | restaurar como variante explícita após remoção do canónico |
| `elastic_band_curl` | `equipment_variant` | `standing_supinated_curl` | ancoragem baixa obrigatória |
| `concentration_curl` | `exercise_variant` | `preacher_curl` ou família de curl apoiado | público, mas não canónico |
| `machine_elbow_curl` | `equipment_variant` condicionado | identidade determinada pela geometria | termo genérico não publicável sem metadados |
| pushdown com corda | `equipment_variant` | `cable_triceps_pushdown` | não criar nova entrada canónica |
| pushdown unilateral | `configuration` | `cable_triceps_pushdown` | guardar lado e estabilidade |
| overhead com halter/EZ/banda | `equipment_variant` | `overhead_triceps_extension` | fonte de resistência e estabilidade em override |
| extensão deitada com halteres | `equipment_variant` | `lying_triceps_extension` | mãos independentes |
| kickback no cabo | `equipment_variant` | `triceps_kickback` | perfil não equivalente ao halter |
| `behind_back_wrist_curl` | `technique_variant` | identidade geral de flexão resistida do punho | o pai não deve exigir apoio se esta variante for herdada |
| `hand_squeeze` | `equipment_variant` ou `regression` | família de crush grip | bola macia não justifica automaticamente novo canónico |
| `towel_hang` | `equipment_variant` + `grip_variant` | `dead_hang` | mesma suspensão, interface deformável |
| barra ou halteres no `support_grip_hold` | `equipment_variant` | `support_grip_hold` | corrigir relação atual que só exige barra |
| posição “diamante” | `technique_variant` | `close_grip_push_up` | contacto entre mãos não define a identidade |
| argolas nos fundos | `equipment_variant` com `stability_delta=high` | `parallel_bar_dip` | não criar canónico por instabilidade |
| assistência elástica em chin-up/fundos | `regression` | respetivo canónico | não é equipamento opcional neutro |

### 6.2 Devem permanecer distintos

| Par | Decisão | Razão |
|---|---|---|
| Inclinado vs curl em pé | distintos | ombro em extensão e suporte do tronco |
| Scott vs spider | distintos | braço apoiado vs braço livre |
| Martelo vs supinado | distintos | antebraço neutro mantido |
| Inverso vs supinado | distintos | pronação mantida |
| Pushdown vs overhead | distintos | posição do ombro |
| Overhead vs deitada | distintos | orientação do corpo, direção da força e suporte |
| Kickback vs pushdown | distintos | ombro em extensão atrás do tronco e perfil externo |
| Fundos vs flexão estreita | distintos | trajetória corporal e articulações |
| Flexão estreita vs supino fechado | distintos | cadeia fechada vs carga externa móvel |
| Hold vs farmer carry | distintos | estático vs locomoção |
| Pinch hold vs pinch carry | distintos | estático vs locomoção, mantendo o modo de pinça |
| Farmer carry vs suitcase carry | distintos | carga bilateral simétrica vs tarefa unilateral assimétrica com controlo lateral do tronco |
| Dead hang vs support hold | distintos | peso corporal com mãos fixas acima vs implemento suspenso nas mãos |
| Rolo de punho vs wrist curl | distintos | tarefa cíclica coordenada com preensão contínua e raio do rolo |

### 6.3 Casos limítrofes

**Thick-grip hold.** Por defeito, tratar como variante material de `support_grip_hold`, porque a tarefa continua a ser sustentar uma carga. Pode ser promovido a identidade canónica apenas se o catálogo exigir uma entidade de topo para o modo `open_hand` e se o nome for generalizado para além do acessório `fat_grip`.

**Cross-body cable triceps extension.** Manter como canónico `approved_with_limits` apenas se a definição exigir braço à frente/cruzado e cabo contralateral. Se for apenas um pushdown unilateral diagonal, é duplicado do pushdown.

**Machine triceps extension.** Manter como canónico limitado apenas se significar braço apoiado, cotovelo alinhado com eixo identificável e extensão local. Se o aparelho for máquina de fundos/press, pertence à família multiarticular.

## 7. Inconsistências concretas no inventário revisto

1. `support_grip_hold` diz “barra ou halteres” na descrição, mas só relaciona `straight_barbell`.
2. `close_grip_push_up` apresenta `parallel_bars` como alternativa. Paralelas altas transformam a tarefa em fundos ou apoio; pegas de flexão/parallettes precisariam de um ID próprio.
3. `rings` aparece como opção de curls e extensões em suspensão, mas não como variante de fundos ou apoio, apesar de essa cobertura ser explicitamente relevante.
4. `selectorized_curl_machine` surge como alternativa do `preacher_curl` sem garantir geometria Scott.
5. `plate_loaded_curl_machine` existe na taxonomia e não é usado.
6. `kettlebell` e `carry_object` existem na taxonomia e não são usados.
7. `manual_resistance` só aparece na oposição do polegar, que está em revisão especialista, deixando a cobertura pública por resistência manual incompleta.
8. `fat_grip` e `dumbbell` estão ambos em `required_ids` no thick-grip hold. Isto é válido apenas para essa representação específica, não para uma barra grossa ou kettlebell de pega espessa.
9. O helper comum fixa `entity_type` como `canonical_exercise`, impedindo a exportação honesta dos candidatos subordinados.
10. `laterality` é frequentemente texto livre, por exemplo “bilateral ou unilateral conforme a variante”, em vez de um valor controlado na entidade-pai com override na variante.
11. O source `src_murray_elbow_1995` possui URL errado.

## 8. Equivalências recomendadas

As relações de equivalência devem ser direcionais e tipadas. Não usar um booleano `equivalent`.

| Origem | Destino | Tipo | Limite |
|---|---|---|---|
| curl barra reta | `standing_supinated_curl` | `equipment_realization_of` | supinação fixa |
| curl barra EZ | `standing_supinated_curl` | `equipment_realization_of` | semissupinação |
| curl com halteres | `standing_supinated_curl` | `equipment_realization_of` | trajetória independente |
| curl no cabo baixo | `standing_supinated_curl` | `resistance_profile_variant_of` | linha do cabo definida |
| curl com banda baixa | `standing_supinated_curl` | `resistance_profile_variant_of` | ancoragem e pré-tensão definidas |
| curl de concentração | `preacher_curl` | `supported_position_variant_of` | apoio na coxa, geometria variável |
| pushdown corda | `cable_triceps_pushdown` | `attachment_variant_of` | pega neutra e mãos independentes |
| pushdown unilateral | `cable_triceps_pushdown` | `configuration_of` | um lado |
| overhead com halter | `overhead_triceps_extension` | `equipment_realization_of` | gravidade |
| overhead com banda | `overhead_triceps_extension` | `resistance_profile_variant_of` | ancoragem atrás/abaixo |
| lying extension com halteres | `lying_triceps_extension` | `equipment_realization_of` | braços independentes |
| kickback no cabo | `triceps_kickback` | `resistance_profile_variant_of` | linha do cabo definida |
| wrist curl atrás do corpo | flexão resistida do punho | `technique_variant_of` | sem apoio do antebraço |
| dumbbell hold | `support_grip_hold` | `equipment_realization_of` | duas ou uma mão como configuração |
| thick-grip hold | `support_grip_hold` | `grip_geometry_variant_of` | mão mais aberta |
| towel hang | `dead_hang` | `grip_interface_variant_of` | interface deformável |
| ring dip | `parallel_bar_dip` | `stability_equipment_variant_of` | apoios móveis |

Uma relação de equivalência nunca deve permitir herdar:

- um perfil de resistência incompatível;
- uma posição do ombro diferente;
- uma ação dinâmica adicional;
- uma cadeia cinética diferente;
- um suporte inexistente;
- uma cautela específica da variante.

## 9. Validações automáticas necessárias

1. Toda variante aponta para exatamente um `parent_exercise_id` existente.
2. Nenhuma variante reutiliza o `exercise_id` do pai.
3. Um registo em `exercise_variants.jsonl` não pode ter `entity_type=canonical_exercise`.
4. Nenhum candidato classificado como `configuration` aparece em `exercises.jsonl`.
5. `required_equipment_all_of` tem semântica conjuntiva.
6. `required_equipment_any_of` tem pelo menos um elemento e semântica disjuntiva.
7. Um equipamento alternativo que muda o perfil exige override de `resistance_profile`.
8. Cabo e banda exigem ancoragem e direção da resistência.
9. Máquina exige função, apoio, eixo e perfil conhecido ou explicitamente desconhecido.
10. `manufacturer_specific` não pode gerar alegação pública universal.
11. Unilateralidade, alternância e pequenas larguras de pega não geram canónicos.
12. Corda e barra no pushdown partilham o mesmo pai.
13. Barra reta, EZ e halteres no curl em pé partilham o mesmo pai, exceto quando outra posição do ombro prevalece.
14. `farmers_carry` não é equivalente a `support_grip_hold`.
15. Todas as entradas da taxonomia de equipamento exigidas pela missão têm pelo menos uma relação ou uma exclusão documentada.
16. Não há marcas comerciais em IDs ou nomes canónicos.
17. A descrição pública do equipamento coincide com as relações estruturadas.
18. Equipamentos de assistência, como banda num chin-up, são `regression_equipment`, não acessórios neutros.
19. Duas gerações com a mesma entrada produzem relações e ordenação idênticas.
20. O source `src_murray_elbow_1995` resolve para PMID `7775488`.

## 10. Blockers

### B1. Modelo de variantes ainda não materializado

**Severidade:** blocker de aprovação.  
**Problema:** o helper `exercise()` fixa `entity_type` como `canonical_exercise`, e os ficheiros de variantes/equivalências ainda não estão demonstrados.  
**Correção:** separar construtores de canónico, variante, configuração e relação de equivalência.  
**Impacto anatómico:** nenhum.

### B2. Semântica de equipamento ambígua

**Severidade:** blocker de dados.  
**Problema:** listas de obrigatório, opcional e alternativa não exprimem com segurança “todos”, “um de vários”, suporte, interface e mecanismo.  
**Correção:** adotar os campos da secção 2.4 ou gerar variantes explícitas.  
**Impacto:** evita indicar que barra e halteres são usados simultaneamente.

### B3. Cobertura incompleta

**Severidade:** blocker de completude.  
**Itens:** `kettlebell`, `carry_object`, `plate_loaded_curl_machine` e máquina Scott/preacher inequívoca. Resistência manual pública também está incompleta.  
**Correção:** adicionar relações de variante sem criar exercícios canónicos novos.

### B4. Máquina de curl sem geometria

**Severidade:** blocker de publicação dessa variante.  
**Problema:** uma máquina genérica não pode ser assumida como Scott.  
**Correção:** exigir `support_geometry`, orientação da pega, eixo e perfil.

### B5. Metadado de fonte incorreto

**Severidade:** blocker de proveniência localizada.  
**Problema:** URL do artigo de Murray aponta para PMID `7581389`.  
**Correção:** usar PMID `7775488` e DOI `10.1016/0021-9290(94)00114-J`.  
**Impacto nas decisões:** não altera a conclusão, mas impede fechar o ledger com o URL atual.

### B6. Contradições públicas de equipamento

**Severidade:** blocker de validação.  
**Casos mínimos:** `support_grip_hold` e `close_grip_push_up`.  
**Correção:** alinhar texto, relações e variantes.

## 11. Decisões prontas para o `DECISION_LOG`

1. Identidade por mecânica, não por implemento.
2. Barra reta e EZ são variantes do mesmo curl quando a posição corporal é igual.
3. Halteres são variante; supinação dinâmica é variante técnica com ação radioulnar declarada.
4. Inclinado, Scott e spider são três identidades posicionais distintas.
5. Martelo e inverso são identidades próprias por orientação mantida do antebraço.
6. Cabo, banda e máquina não são identidades genéricas.
7. Barra e corda no pushdown partilham identidade.
8. Overhead e extensão deitada são identidades distintas.
9. Fundos, flexão estreita e supino fechado não são equivalentes.
10. Carries e holds não são equivalentes.
11. Objetos de transporte, kettlebells e máquinas plate-loaded fecham cobertura por variante, não por novos canónicos.
12. Máquinas só são publicáveis quando a geometria está definida.
13. Towel hang, hand squeeze, behind-back wrist curl e concentration curl não devem inflacionar o núcleo canónico.
14. O resultado pode ficar abaixo de 40 canónicos se todas as variantes obrigatórias permanecerem acessíveis e a cobertura for demonstrada.

## 12. Estado final desta equipa

**Decisões obrigatórias:** fechadas.  
**Cobertura de equipamentos:** auditada, com cinco lacunas/ambiguidades materiais.  
**Duplicados e microvariações:** identificados.  
**Fontes primárias usadas:** dez artigos de biomecânica, treino ou atividade muscular, com limitações declaradas.  
**Alterações à base muscular:** zero.  
**Alterações à aplicação EveFit:** zero.  
**Alterações ao pacote final:** zero.  
**Estado recomendado:** `approved_with_blockers` até B1-B6 serem resolvidos e revalidados pelo integrador.
