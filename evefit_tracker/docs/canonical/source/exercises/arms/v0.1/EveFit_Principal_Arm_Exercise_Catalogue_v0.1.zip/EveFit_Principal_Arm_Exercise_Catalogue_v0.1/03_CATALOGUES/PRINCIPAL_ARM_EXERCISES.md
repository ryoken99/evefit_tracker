# Principais exercícios de braços

O papel muscular é contextual e nunca significa isolamento absoluto.

## Apoio isométrico nas paralelas

- ID: `parallel_bar_support_hold`
- Estado: `approved_public`
- Família: `upper_limb_support`
- Objetivo: Sustentar o corpo com os braços estendidos nas paralelas, mantendo mãos, cotovelos e ombros estáveis.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo, extensor radial curto do carpo, flexor profundo dos dedos, flexor radial do carpo, flexor superficial dos dedos, peitoral menor e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal e paralelas.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar-se para apoio, manter cotovelos estendidos e sair através de apoio controlado.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl em pé com pega supinada

- ID: `standing_supinated_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Flexão controlada do cotovelo com o antebraço supinado, mantendo o punho estável.
- Músculos principais/contextuais: Bicípite braquial e braquial.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Barra reta.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica neutro junto ao tronco e a resistência é vertical pela gravidade. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl em suspensão com peso corporal

- ID: `suspension_bodyweight_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Flexão do cotovelo em cadeia mista, aproximando o corpo das mãos através de pegas móveis num sistema de suspensão.
- Músculos principais/contextuais: Bicípite braquial e braquial.
- Secundários/estabilizadores: Braquiorradial, grande dorsal e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Peso corporal e sistema de suspensão.
- Mecânica: A resistência resulta da componente do peso corporal perpendicular à linha entre pés e mãos. A posição dos pés regula a dificuldade sem alterar a identidade.

### Execução

1. Segurar as pegas com o corpo alinhado e cotovelos estendidos, mantendo tensão no sistema.
2. Fletir os cotovelos para aproximar a testa ou ombros das mãos, sem perder o alinhamento corporal.
3. Terminar antes de os ombros avançarem ou o tronco perder rigidez; regressar sob controlo.

**Cues:** Manter o corpo alinhado, apontar as palmas para cima e mover pelos cotovelos.

**Erros frequentes:** Dobrar a anca, transformar o gesto numa remada e usar ancoragem instável.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl inverso

- ID: `reverse_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_pronated`
- Objetivo: Flexão controlada do cotovelo com o antebraço pronado, mantendo o punho estável.
- Músculos principais/contextuais: Braquial e braquiorradial.
- Secundários/estabilizadores: Bicípite braquial, extensor radial curto do carpo e extensor radial longo do carpo.
- Possíveis limitadores de preensão: Flexor profundo dos dedos.
- Equipamento base: Barra EZ.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica neutro junto ao tronco e a resistência é vertical pela gravidade. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl martelo

- ID: `hammer_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_neutral`
- Objetivo: Flexão controlada do cotovelo com o antebraço neutro, mantendo o punho estável.
- Músculos principais/contextuais: Braquial e braquiorradial.
- Secundários/estabilizadores: Bicípite braquial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Flexor superficial dos dedos.
- Equipamento base: Halter.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica neutro junto ao tronco e a resistência é vertical pela gravidade. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl no banco Scott

- ID: `preacher_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Flexão controlada do cotovelo com o antebraço supinado ou semissupinado conforme a barra, mantendo o punho estável.
- Músculos principais/contextuais: Bicípite braquial e braquial.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Banco Scott e Barra EZ.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica em flexão, com o braço apoiado no banco scott e a resistência é vertical pela gravidade ou definida pela máquina/cabo. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl spider

- ID: `spider_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Flexão controlada do cotovelo com o antebraço supinado, mantendo o punho estável.
- Músculos principais/contextuais: Bicípite braquial e braquial.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Halter e banco inclinado.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica em flexão, com o peito apoiado num banco inclinado e braços pendentes e a resistência é vertical pela gravidade. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Curl supinado com ombro em extensão

- ID: `shoulder_extended_supinated_curl`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Flexão controlada do cotovelo com o antebraço supinado, mantendo o punho estável.
- Músculos principais/contextuais: Bicípite braquial e braquial.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Halter e banco inclinado.
- Mecânica: Exercício de cadeia aberta para flexão do cotovelo. O ombro fica em extensão relativa atrás do tronco, apoiado num banco inclinado e a resistência é vertical pela gravidade. A posição altera comprimentos e braços de momento, mas não permite alegar isolamento de uma cabeça muscular.

### Execução

1. Segurar o implemento com o cotovelo estendido sem o bloquear, braço controlado e tronco estável.
2. Fletir o cotovelo sem transformar o gesto numa elevação do ombro; regressar de forma controlada.
3. Terminar antes de perder a posição do punho ou deslocar o braço para retirar tensão ao cotovelo.

**Cues:** Manter o punho neutro, mover sobretudo pelo cotovelo e controlar a descida.

**Erros frequentes:** Balançar o tronco, projetar o cotovelo sem intenção técnica e deixar o punho colapsar.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Desvio radial resistido do punho

- ID: `wrist_radial_deviation`
- Estado: `approved_with_limits`
- Família: `wrist_deviation`
- Objetivo: Desvio radial do punho contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Extensor radial curto do carpo, extensor radial longo do carpo e flexor radial do carpo.
- Secundários/estabilizadores: Abdutor longo do polegar.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Halter.
- Mecânica: Exercício monoação destinado a carregar desvio radial do punho. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar desvio radial do punho contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Desvio ulnar resistido do punho

- ID: `wrist_ulnar_deviation`
- Estado: `approved_with_limits`
- Família: `wrist_deviation`
- Objetivo: Desvio ulnar do punho contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Extensor ulnar do carpo e flexor ulnar do carpo.
- Secundários/estabilizadores: Nenhum identificado.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Halter.
- Mecânica: Exercício monoação destinado a carregar desvio ulnar do punho. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar desvio ulnar do punho contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Elevação na barra com pega supinada

- ID: `supinated_chin_up`
- Estado: `approved_public`
- Família: `elbow_flexion_supinated`
- Objetivo: Tração vertical multiarticular com pega supinada, na qual os flexores do cotovelo têm papel relevante mas não exclusivo.
- Músculos principais/contextuais: Bicípite braquial, braquial e grande dorsal.
- Secundários/estabilizadores: Braquiorradial e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Peso corporal e barra fixa.
- Mecânica: Exercício de cadeia fechada para cotovelo e ombro. O bicípite e o braquial contribuem para a flexão do cotovelo, enquanto músculos das costas e cintura escapular também são determinantes.

### Execução

1. Suspender-se numa barra fixa com pega supinada segura, cotovelos estendidos sem relaxamento descontrolado.
2. Puxar o corpo para cima através de flexão do cotovelo e movimento coordenado do ombro/escápula; descer sob controlo.
3. Terminar a subida sem projetar a cabeça ou perder o controlo escapular; regressar à suspensão controlada.

**Cues:** Iniciar com controlo escapular, manter a pega fechada e evitar balanço das pernas.

**Erros frequentes:** Usar impulso excessivo, soltar bruscamente para a extensão e forçar amplitude do ombro dolorosa.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão cruzada de tríceps no cabo

- ID: `cross_body_cable_triceps_extension`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Coluna de cabos, polia ajustável e pega unilateral.
- Mecânica: Exercício com o ombro à frente do corpo, com ligeira adução horizontal contextual e resistência oblíqua ao longo do cabo. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão de tríceps acima da cabeça

- ID: `overhead_triceps_extension`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Coluna de cabos, polia ajustável e corda para polia.
- Mecânica: Exercício com o ombro elevado acima da cabeça e resistência definida por cabo, peso livre ou banda. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão de tríceps deitado

- ID: `lying_triceps_extension`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Banco plano e Barra EZ.
- Mecânica: Exercício com o ombro em flexão aproximada de 90 graus, estabilizado sobre banco e resistência vertical pela gravidade. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão de tríceps em suspensão

- ID: `suspension_triceps_extension`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão do cotovelo em cadeia mista através de pegas móveis num sistema de suspensão.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal e sistema de suspensão.
- Mecânica: A dificuldade muda com a inclinação corporal; os pés mantêm contacto com o solo, as pegas movem-se e ombro e tronco devem permanecer controlados.

### Execução

1. Segurar as pegas com braços à frente, corpo alinhado e tensão no sistema.
2. Fletir os cotovelos levando a cabeça entre as mãos e estendê-los para afastar o corpo.
3. Terminar antes de perder alinhamento do tronco ou posição do ombro.

**Cues:** Manter cotovelos apontados em frente, corpo alinhado e controlar a descida.

**Erros frequentes:** Transformar o gesto num empurrar de ombro, dobrar a anca e usar ancoragem instável.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão de tríceps na máquina

- ID: `machine_triceps_extension`
- Estado: `approved_with_limits`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Máquina de tríceps com pesos selecionados.
- Mecânica: Exercício com o ombro definido pela máquina, geralmente com braço apoiado e resistência definida por came, cabo ou braço de alavanca. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão de tríceps na polia

- ID: `cable_triceps_pushdown`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Coluna de cabos, polia alta e barra reta para polia.
- Mecânica: Exercício com o ombro neutro, com o braço junto ao tronco e resistência ao longo do cabo a partir de uma polia alta. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão do punho com antebraço apoiado

- ID: `supported_wrist_extension`
- Estado: `approved_public`
- Família: `wrist_flexion_extension`
- Objetivo: Extensão do punho contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Extensor radial curto do carpo, extensor radial longo do carpo e extensor ulnar do carpo.
- Secundários/estabilizadores: Extensor dos dedos.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Halter e banco plano.
- Mecânica: Exercício monoação destinado a carregar extensão do punho. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar extensão do punho contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Extensão dos dedos com banda

- ID: `resisted_finger_extension`
- Estado: `approved_public`
- Família: `digital_flexion_extension`
- Objetivo: Abrir os dedos contra uma banda colocada à volta das falanges.
- Músculos principais/contextuais: Extensor do dedo mínimo, extensor do indicador e extensor dos dedos.
- Secundários/estabilizadores: Extensor radial curto do carpo e primeiro lumbrical da mão.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Banda elástica.
- Mecânica: Exercício de resistência elástica para extensão MCP e contribuição através das expansões extensoras. A carga individual de cada dedo não é uniforme.

### Execução

1. Colocar uma banda leve em torno dos dedos com a mão fechada de forma confortável.
2. Abrir os dedos contra a banda e regressar lentamente.
3. Terminar antes de a banda escorregar ou forçar as articulações.

**Cues:** Abrir de forma uniforme, manter o punho neutro e usar banda leve.

**Erros frequentes:** Usar banda demasiado forte, deixar a banda enrolar nas articulações e compensar com extensão do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Fecho resistido da mão

- ID: `resisted_hand_close`
- Estado: `approved_public`
- Família: `grip_dynamic`
- Objetivo: Fechar a mão contra resistência através de preensão de esmagamento controlada.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo e flexor longo do polegar.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Hand gripper.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Fechar as pegas com os dedos e polegar; regressar sem deixar a mola abrir bruscamente.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Flexão de braços com mãos próximas

- ID: `close_grip_push_up`
- Estado: `approved_public`
- Família: `elbow_extension_compound`
- Objetivo: Flexão de braços multiarticular com mãos próximas, aumentando a exigência contextual de extensão do cotovelo.
- Músculos principais/contextuais: Peitoral maior e tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal.
- Mecânica: Cadeia fechada com extensão do cotovelo e adução horizontal do ombro; não é isolamento de tríceps.

### Execução

1. Em prancha, mãos abaixo ou ligeiramente dentro da largura dos ombros, corpo alinhado.
2. Descer o corpo com controlo e empurrar o solo até regressar à prancha.
3. Terminar a descida antes de perder alinhamento; subir sem bloquear agressivamente os cotovelos.

**Cues:** Manter corpo alinhado, cotovelos orientados para trás e empurrar o chão de forma uniforme.

**Erros frequentes:** Abrir excessivamente os cotovelos, deixar a anca cair e forçar uma posição estreita dolorosa.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Flexão do punho com antebraço apoiado

- ID: `supported_wrist_curl`
- Estado: `approved_public`
- Família: `wrist_flexion_extension`
- Objetivo: Flexão do punho contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Flexor radial do carpo e flexor ulnar do carpo.
- Secundários/estabilizadores: Flexor profundo dos dedos, flexor superficial dos dedos e palmar longo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Halter e banco plano.
- Mecânica: Exercício monoação destinado a carregar flexão do punho. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar flexão do punho contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Flexão resistida dos dedos

- ID: `finger_curl`
- Estado: `approved_public`
- Família: `digital_flexion_extension`
- Objetivo: Flexão dos dedos contra resistência, mantendo o punho controlado.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Extensor radial curto do carpo, extensor ulnar do carpo e flexor longo do polegar.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Barra reta.
- Mecânica: Carrega flexores superficiais e profundos dos dedos através das articulações MCP, PIP e DIP; a contribuição varia com a forma do objeto e posição do punho.

### Execução

1. Apoiar os antebraços e segurar o implemento nas falanges com dedos parcialmente estendidos.
2. Fechar os dedos para trazer o implemento para a palma; abrir de forma controlada sem o deixar cair.
3. Terminar com preensão segura, sem flexão excessiva do punho.

**Cues:** Mover pelos dedos, manter o punho estável e usar carga pequena e segura.

**Erros frequentes:** Deixar a barra rolar sem controlo, substituir o gesto por flexão do punho e usar carga que ameaça cair.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Fundos em paralelas

- ID: `parallel_bar_dip`
- Estado: `approved_public`
- Família: `elbow_extension_compound`
- Objetivo: Exercício multiarticular em apoio nas paralelas, com extensão do cotovelo relevante e participação do ombro e peito.
- Músculos principais/contextuais: Peitoral maior e tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal e paralelas.
- Mecânica: Cadeia fechada. O tricípite é importante, mas o gesto também exige extensão/adução do ombro, depressão escapular e controlo do tronco.

### Execução

1. Apoiar o corpo nas paralelas com cotovelos estendidos, ombros organizados e pés sem apoio.
2. Descer por flexão controlada dos cotovelos e ombros; subir estendendo os cotovelos sem perder a posição escapular.
3. Terminar a descida antes de dor ou perda de controlo do ombro; subir até extensão confortável.

**Cues:** Manter as barras firmemente seguras, controlar a profundidade e evitar encolher os ombros.

**Erros frequentes:** Descer além da amplitude tolerada, balançar o corpo e bloquear o cotovelo de forma agressiva.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Fundos no banco

- ID: `bench_dip`
- Estado: `approved_with_limits`
- Família: `elbow_extension_compound`
- Objetivo: Extensão do cotovelo com as mãos apoiadas atrás do tronco; opção pública com limites pela extensão do ombro.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide, peitoral maior e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal e banco plano.
- Mecânica: Apoio posterior que combina extensão do cotovelo com extensão do ombro. A amplitude deve ser conservadora.

### Execução

1. Apoiar as mãos na borda de um banco estável, com o tronco próximo do apoio e cotovelos estendidos.
2. Descer através de flexão do cotovelo mantendo o ombro confortável; regressar estendendo o cotovelo.
3. Parar a descida antes de desconforto anterior no ombro ou perda de alinhamento.

**Cues:** Manter o tronco perto do banco, usar amplitude curta e confortável e apontar os cotovelos para trás.

**Erros frequentes:** Descer demasiado, afastar o tronco do banco e usar apoio instável.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Kickback de tríceps

- ID: `triceps_kickback`
- Estado: `approved_public`
- Família: `elbow_extension_local`
- Objetivo: Extensão controlada do cotovelo contra resistência, sem prometer isolamento das cabeças do tricípite.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Halter.
- Mecânica: Exercício com o ombro em extensão atrás do tronco e resistência vertical pela gravidade ou ao longo do cabo. A posição do ombro altera o comprimento da cabeça longa e pode mudar a contribuição relativa das cabeças.

### Execução

1. Começar com o cotovelo fletido, braço organizado e punho estável.
2. Estender o cotovelo contra a resistência e regressar sob controlo.
3. Terminar próximo da extensão confortável, sem bloquear agressivamente nem deslocar o ombro.

**Cues:** Fixar a posição do braço, manter o punho neutro e controlar o regresso.

**Erros frequentes:** Abrir ou fechar excessivamente os cotovelos, usar balanço do tronco e perder o alinhamento do punho.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Oposição resistida do polegar

- ID: `resisted_thumb_opposition`
- Estado: `specialist_review`
- Família: `thumb_specific`
- Objetivo: Oposição do polegar contra resistência leve, mantida fora da camada pública inicial.
- Músculos principais/contextuais: Abdutor curto do polegar, flexor curto do polegar e oponente do polegar.
- Secundários/estabilizadores: Nenhum identificado.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Resistência manual.
- Mecânica: Tarefa específica dos músculos tenares e do controlo carpometacárpico do polegar; fica em revisão especialista por proximidade a usos clínicos.

### Execução

1. Mão apoiada e polegar numa posição confortável.
2. Levar a polpa do polegar em direção aos dedos contra resistência manual leve.
3. Terminar antes de dor, colapso da articulação ou compensação do punho.

**Cues:** Usar resistência mínima, mover sem dor e manter o punho estável.

**Erros frequentes:** Forçar a base do polegar, usar resistência alta e aplicar em presença de dor sem avaliação.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Passeio do agricultor

- ID: `farmers_carry`
- Estado: `approved_public`
- Família: `loaded_carry`
- Objetivo: Transportar cargas nas duas mãos mantendo preensão, postura e marcha controladas.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo, flexor longo do polegar, oblíquo externo do abdómen e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Halter.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar as cargas, caminhar em linha controlada e pousá-las sem perder a preensão.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Pinça isométrica com discos

- ID: `plate_pinch_hold`
- Estado: `approved_public`
- Família: `grip_isometric`
- Objetivo: Sustentar discos por pinça entre o polegar e os dedos.
- Músculos principais/contextuais: Adutor do polegar, flexor curto do polegar, flexor longo do polegar, flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Extensor radial curto do carpo e primeiro interósseo dorsal da mão.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Disco.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar os discos apenas o suficiente para ficarem livres e manter a pinça sem deslocamento.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Pronação resistida do antebraço

- ID: `resisted_forearm_pronation`
- Estado: `approved_public`
- Família: `forearm_rotation`
- Objetivo: Pronação do antebraço contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Pronador quadrado e pronador redondo.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Martelo ou alavanca.
- Mecânica: Exercício monoação destinado a carregar pronação do antebraço. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar pronação do antebraço contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Rolo de punho

- ID: `wrist_roller`
- Estado: `approved_with_limits`
- Família: `wrist_flexion_extension`
- Objetivo: Enrolar e desenrolar uma carga através de flexão e extensão repetida do punho e dos dedos.
- Músculos principais/contextuais: Extensor radial curto do carpo, extensor radial longo do carpo, extensor ulnar do carpo, flexor radial do carpo e flexor ulnar do carpo.
- Secundários/estabilizadores: Nenhum identificado.
- Possíveis limitadores de preensão: Flexor profundo dos dedos.
- Equipamento base: Rolo de punho.
- Mecânica: Tarefa cíclica bilateral que combina punho, dedos e preensão. O sentido de enrolamento determina a predominância relativa, pelo que ambas as direções ficam como variantes.

### Execução

1. Segurar o rolo com os braços numa posição estável e o cabo totalmente desenrolado.
2. Rodar alternadamente os punhos para enrolar a carga; desenrolar de forma controlada.
3. Terminar antes de o punho perder alinhamento ou a carga cair.

**Cues:** Usar movimentos curtos do punho, manter ombros relaxados e controlar também a descida.

**Erros frequentes:** Rodar todo o braço, deixar a carga cair e usar carga que força compensação do ombro.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Supinação resistida do antebraço

- ID: `resisted_forearm_supination`
- Estado: `approved_public`
- Família: `forearm_rotation`
- Objetivo: Supinação do antebraço contra resistência com o antebraço controlado.
- Músculos principais/contextuais: Bicípite braquial e supinador.
- Secundários/estabilizadores: Braquiorradial e extensor radial curto do carpo.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Martelo ou alavanca.
- Mecânica: Exercício monoação destinado a carregar supinação do antebraço. A contribuição individual dos músculos depende da rotação do antebraço, do punho, do implemento e da amplitude.

### Execução

1. Apoiar ou estabilizar o antebraço e começar numa posição confortável, sem desvio compensatório.
2. Executar supinação do antebraço contra a resistência e regressar lentamente.
3. Terminar antes de perder o apoio, o alinhamento ou a amplitude confortável.

**Cues:** Manter o antebraço imóvel, usar amplitude controlada e evitar movimento dos dedos para substituir o punho.

**Erros frequentes:** Mover o cotovelo ou ombro, usar carga que força amplitude terminal e perder o alinhamento da mão.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Supino com pega fechada

- ID: `close_grip_bench_press`
- Estado: `approved_public`
- Família: `elbow_extension_compound`
- Objetivo: Supino multiarticular com pega relativamente estreita, no qual a extensão do cotovelo tem papel relevante.
- Músculos principais/contextuais: Peitoral maior e tricípite braquial.
- Secundários/estabilizadores: Ancóneo, deltoide e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Barra reta e banco plano.
- Mecânica: A largura de pega altera momentos e carga tolerada. Continua a ser um exercício de empurrar multiarticular.

### Execução

1. Deitado no banco, pés estáveis, barra segura com pega ligeiramente mais estreita do que a habitual.
2. Descer a barra ao tronco com controlo e empurrar por extensão do cotovelo e adução horizontal do ombro.
3. Aproximar do tronco sem perder posição do ombro; subir até extensão controlada.

**Cues:** Manter antebraços alinhados, controlar a descida e usar observador ou suportes de segurança.

**Erros frequentes:** Pega estreita ao ponto de colapsar o punho, cotovelos sem controlo e treinar sem suportes adequados.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Suspensão passiva controlada na barra

- ID: `dead_hang`
- Estado: `approved_with_limits`
- Família: `suspension_support`
- Objetivo: Suspender o peso corporal numa barra fixa mantendo a pega segura.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo, flexor longo do polegar, grande dorsal e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Peso corporal e barra fixa.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Assumir suspensão controlada e manter o contacto; sair através de apoio seguro, sem largar em queda.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Sustentação estática com barra

- ID: `support_grip_hold`
- Estado: `approved_public`
- Família: `grip_isometric`
- Objetivo: Manter uma barra ou halteres suspensos nas mãos sem deslocamento.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo e flexor longo do polegar.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Barra reta.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar o implemento para uma posição segura e manter a preensão antes de o pousar.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Transporte unilateral tipo mala

- ID: `suitcase_carry`
- Estado: `approved_public`
- Família: `loaded_carry`
- Objetivo: Transportar uma carga numa só mão, mantendo preensão e controlo lateral do tronco.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo, flexor longo do polegar, oblíquo externo do abdómen e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Halter.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar a carga, caminhar sem inclinar o tronco e pousar de forma controlada.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.
