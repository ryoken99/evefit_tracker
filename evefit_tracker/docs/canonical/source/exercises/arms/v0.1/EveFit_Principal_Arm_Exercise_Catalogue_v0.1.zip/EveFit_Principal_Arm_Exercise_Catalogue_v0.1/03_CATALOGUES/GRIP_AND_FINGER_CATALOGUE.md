# Preensão, carries, hangs e suportes

O papel muscular é contextual e nunca significa isolamento absoluto.

## Apoio isométrico nas paralelas

- ID: `parallel_bar_support_hold`
- Estado: `approved_public`
- Família: `upper_limb_support`
- Objetivo: Sustentar o corpo com os braços estendidos nas paralelas, mantendo mãos, cotovelos e ombros estáveis.
- Músculos principais/contextuais: Tricípite braquial.
- Secundários/estabilizadores: Ancóneo, extensor radial curto do carpo, flexor profundo dos dedos, flexor radial do carpo, flexor superficial dos dedos, peitoral menor e serrátil anterior.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Peso corporal e paralelas.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar-se para apoio, manter cotovelos estendidos e sair através de apoio controlado.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Fecho resistido da mão

- ID: `resisted_hand_close`
- Estado: `approved_public`
- Família: `grip_dynamic`
- Objetivo: Fechar a mão contra resistência através de preensão de esmagamento controlada.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo e flexor longo do polegar.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Hand gripper.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Fechar as pegas com os dedos e polegar; regressar sem deixar a mola abrir bruscamente.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Passeio do agricultor

- ID: `farmers_carry`
- Estado: `approved_public`
- Família: `loaded_carry`
- Objetivo: Transportar cargas nas duas mãos mantendo preensão, postura e marcha controladas.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo, flexor longo do polegar, oblíquo externo do abdómen e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Halter.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar as cargas, caminhar em linha controlada e pousá-las sem perder a preensão.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Pinça isométrica com discos

- ID: `plate_pinch_hold`
- Estado: `approved_public`
- Família: `grip_isometric`
- Objetivo: Sustentar discos por pinça entre o polegar e os dedos.
- Músculos principais/contextuais: Adutor do polegar, flexor curto do polegar, flexor longo do polegar, flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Extensor radial curto do carpo e primeiro interósseo dorsal da mão.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Disco.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar os discos apenas o suficiente para ficarem livres e manter a pinça sem deslocamento.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Suspensão passiva controlada na barra

- ID: `dead_hang`
- Estado: `approved_with_limits`
- Família: `suspension_support`
- Objetivo: Suspender o peso corporal numa barra fixa mantendo a pega segura.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo, flexor longo do polegar, grande dorsal e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Peso corporal e barra fixa.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Assumir suspensão controlada e manter o contacto; sair através de apoio seguro, sem largar em queda.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Sustentação estática com barra

- ID: `support_grip_hold`
- Estado: `approved_public`
- Família: `grip_isometric`
- Objetivo: Manter uma barra ou halteres suspensos nas mãos sem deslocamento.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo e flexor longo do polegar.
- Possíveis limitadores de preensão: Nenhum identificado.
- Equipamento base: Barra reta.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar o implemento para uma posição segura e manter a preensão antes de o pousar.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.

## Transporte unilateral tipo mala

- ID: `suitcase_carry`
- Estado: `approved_public`
- Família: `loaded_carry`
- Objetivo: Transportar uma carga numa só mão, mantendo preensão e controlo lateral do tronco.
- Músculos principais/contextuais: Flexor profundo dos dedos e flexor superficial dos dedos.
- Secundários/estabilizadores: Adutor do polegar, extensor radial curto do carpo, extensor ulnar do carpo, flexor longo do polegar, oblíquo externo do abdómen e trapézio.
- Possíveis limitadores de preensão: Flexor profundo dos dedos e flexor superficial dos dedos.
- Equipamento base: Halter.
- Mecânica: Tarefa de preensão ou suporte cuja limitação pode resultar da força digital, posição do punho, contacto, fricção, tolerância da pele e estabilidade proximal. Não identifica um músculo isolado.

### Execução

1. Organizar mão e punho em torno do implemento ou apoio, com contacto seguro.
2. Elevar a carga, caminhar sem inclinar o tronco e pousar de forma controlada.
3. Terminar antes de perder o contacto, a posição do punho ou o controlo do corpo.

**Cues:** Envolver o implemento com controlo, manter o punho próximo de neutro e terminar antes da abertura involuntária da mão.

**Erros frequentes:** Continuar depois de a pega começar a escapar, compensar com flexão excessiva do punho e usar superfície ou carga sem margem de segurança.

**Cautelas:** Parar se surgir dor articular aguda, dormência, perda súbita de força ou alteração clara da técnica, a carga e a amplitude devem permitir controlo sem balanço ou compensação relevante e respirar continuamente e evitar prender a respiração durante retenções prolongadas.
