# Questões em aberto

1. Definir uma ontologia de geometrias de máquinas antes de expor perfis de resistência específicos.
2. Validar com especialista o exercício de oposição resistida do polegar.
3. Decidir na futura UI se variantes de equipamento aparecem como seletor ou fichas filhas.
4. Rever se o towel hang deve permanecer canónico após dados comparativos de preensão.
5. Corrigir o PMID de Murray numa futura versão aprovada da base muscular, sem alteração silenciosa.
