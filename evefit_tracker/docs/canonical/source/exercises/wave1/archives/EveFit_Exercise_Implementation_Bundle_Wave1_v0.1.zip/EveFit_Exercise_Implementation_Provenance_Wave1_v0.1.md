# EveFit Exercise Implementation Provenance Wave1 v0.1

## Fontes e precedência

| Fonte | SHA-256 | Papel |
|---|---|---|
| `EveFit_Exercise_Catalogue_Wave1_Non_Muscular_Corrected_v0.1.zip` | `1c2446b31be95b8d35819ad7310ffb022cd74a3733bd83b00ab2a201345f8036` | fonte prevalecente do catálogo Wave1 |
| `EveFit_Canonical_Exercise_Classification_Spec_v0.1.md` | `9c6c65caa36e785bd82c4d8e4f5d37e1d21e3a974f9676d80658a82d10d9911c` | estrutura canónica dos exercícios |
| `EveFit_Training_Intentions_Production_Registry_v0.4.md` | `d9cf51727dc28aa078b7cc55fa0f6246360e86bcba93b40fe34feac9ac7f50ad` | origem semântica das intenções |
| `EveFit_Training_Intentions_Production_Registry_v0.4.1.md` | `4d6f6d06f8f593f549dfd0ab132ce09f92ec760dfed11966cdd816be3506c0d8` | correções, papéis e risco prevalecentes |

Precedência aplicada sem reinterpretar nem reconsolidar as fontes.

## Preflight

- ZIP corretivo: SHA aprovado.
- Ficheiros no ZIP: 209.
- Hashes internos: 208 verificados.
- Divergências internas: 0.
- Ontologia: 7 contextos, 8 capacidades, 35 conceitos, 40 relações capacidade-conceito, 280 percursos, 261 compatíveis, 19 incompatíveis, 591 intenções e 771 ocorrências.

## IDs abreviados na ordem e IDs canónicos usados

Foram resolvidas 21 diferenças inequívocas. Nenhum ID canónico foi alterado.

| ID da ordem | ID canónico do pacote |
|---|---|
| `bent_knee_wall_soleus_stretch` | `standing_soleus_wall_stretch` |
| `butterfly_adductor_stretch` | `seated_butterfly_adductor_stretch` |
| `continuous_stair_climbing` | `continuous_stair_ascent` |
| `countermovement_vertical_jump` | `countermovement_jump` |
| `directional_first_touch_in_football` | `football_directional_first_touch` |
| `forward_backward_leg_swing` | `front_to_back_leg_swing` |
| `full_body_elliptical_motion` | `full_body_elliptical` |
| `jab_cross_sequence_to_focus_mitts` | `boxing_jab_cross_to_focus_mitts` |
| `marching_in_place_to_external_pulse` | `march_in_place_to_external_beat` |
| `repeated_short_two_foot_reactive_hops` | `bilateral_pogo_jump` |
| `resisted_sled_sprint` | `sled_resisted_sprint` |
| `seated_thoracic_extension_over_support` | `seated_supported_thoracic_extension` |
| `seated_unilateral_hamstring_stretch` | `seated_single_leg_hamstring_stretch` |
| `standing_two_foot_horizontal_jump` | `standing_broad_jump` |
| `stationary_basketball_set_shot_to_basket` | `basketball_set_shot_to_basket` |
| `stationary_rowing_ergometry` | `static_rowing_ergometer` |
| `straight_knee_wall_calf_stretch` | `standing_gastrocnemius_wall_stretch` |
| `supine_hamstring_stretch_with_hands` | `supine_self_assisted_hamstring_stretch` |
| `supine_hamstring_stretch_with_strap` | `supine_hamstring_strap_stretch` |
| `tandem_walking` | `tandem_walk` |
| `two_foot_jump_rope` | `two_foot_rope_skipping` |

## Referências de identidade removidas do registry técnico

Referências a registos excluídos ou ausentes foram retiradas do subconjunto principal e mantidas apenas nesta proveniência.

| Exercício aprovado | Campo | Referência removida | Motivo |
|---|---|---|---|
| `clockwise_four_quadrant_step_sequence` | `commonly_confused_with` | `four_square_step_test` | referência fora do subconjunto dos 49 aprovados |
| `clockwise_four_quadrant_step_sequence` | `commonly_confused_with` | `square_stepping_exercise_program` | referência fora do subconjunto dos 49 aprovados |
| `diaphragmatic_breathing` | `commonly_confused_with` | `abdominal_bracing` | referência fora do subconjunto dos 49 aprovados |
| `diaphragmatic_breathing` | `commonly_confused_with` | `deep_breathing` | referência fora do subconjunto dos 49 aprovados |
| `doorway_pectoral_stretch` | `commonly_confused_with` | `corner_pectoral_stretch` | referência fora do subconjunto dos 49 aprovados |
| `front_to_back_leg_swing` | `commonly_confused_with` | `ballistic_leg_swing` | referência fora do subconjunto dos 49 aprovados |
| `full_body_elliptical` | `commonly_confused_with` | `total_body_recumbent_stepper` | referência fora do subconjunto dos 49 aprovados |
| `lateral_costal_breathing` | `commonly_confused_with` | `deep_breathing` | referência fora do subconjunto dos 49 aprovados |
| `lateral_costal_breathing` | `commonly_confused_with` | `segmental_breathing_with_manual_pressure` | referência fora do subconjunto dos 49 aprovados |
| `lateral_leg_swing` | `commonly_confused_with` | `ballistic_leg_swing` | referência fora do subconjunto dos 49 aprovados |
| `manual_wheelchair_propulsion_overground` | `sibling_exercise_ids` | `racing_wheelchair_sprint` | referência fora do subconjunto dos 49 aprovados |
| `manual_wheelchair_propulsion_overground` | `commonly_confused_with` | `racing_wheelchair_sprint` | referência fora do subconjunto dos 49 aprovados |
| `march_in_place_to_external_beat` | `commonly_confused_with` | `auditory_cueing_therapy` | referência fora do subconjunto dos 49 aprovados |
| `march_in_place_to_external_beat` | `commonly_confused_with` | `walking_to_external_beat` | referência fora do subconjunto dos 49 aprovados |
| `overground_running` | `commonly_confused_with` | `treadmill_running` | referência fora do subconjunto dos 49 aprovados |
| `overground_walking` | `commonly_confused_with` | `race_walking` | referência fora do subconjunto dos 49 aprovados |
| `paced_breathing` | `commonly_confused_with` | `box_breathing_protocol` | referência fora do subconjunto dos 49 aprovados |
| `paced_breathing` | `commonly_confused_with` | `hrv_biofeedback_protocol` | referência fora do subconjunto dos 49 aprovados |
| `paced_breathing` | `commonly_confused_with` | `resonance_frequency_assessment` | referência fora do subconjunto dos 49 aprovados |
| `respiratory_sensation_observation` | `commonly_confused_with` | `body_scan_activity` | referência fora do subconjunto dos 49 aprovados |
| `respiratory_sensation_observation` | `commonly_confused_with` | `breath_counting_task` | referência fora do subconjunto dos 49 aprovados |
| `respiratory_sensation_observation` | `commonly_confused_with` | `clinical_symptom_assessment` | referência fora do subconjunto dos 49 aprovados |
| `seated_butterfly_adductor_stretch` | `commonly_confused_with` | `seated_straddle_forward_hinge` | referência fora do subconjunto dos 49 aprovados |
| `seated_single_leg_hamstring_stretch` | `commonly_confused_with` | `neural_tensioner` | referência fora do subconjunto dos 49 aprovados |
| `single_leg_stance` | `commonly_confused_with` | `single_leg_strength_exercises` | referência fora do subconjunto dos 49 aprovados |
| `standing_multidirectional_weight_shift` | `commonly_confused_with` | `multidirectional_step_drill` | referência fora do subconjunto dos 49 aprovados |
| `stationary_arm_crank_ergometry` | `commonly_confused_with` | `overground_handcycling` | referência fora do subconjunto dos 49 aprovados |
| `supine_hamstring_strap_stretch` | `sibling_exercise_ids` | `supine_partner_assisted_hamstring_stretch` | referência fora do subconjunto dos 49 aprovados |
| `supine_hamstring_strap_stretch` | `commonly_confused_with` | `neural_tensioner` | referência fora do subconjunto dos 49 aprovados |
| `supine_self_assisted_hamstring_stretch` | `commonly_confused_with` | `straight_leg_raise_test` | referência fora do subconjunto dos 49 aprovados |
| `tandem_stance` | `commonly_confused_with` | `four_stage_balance_test` | referência fora do subconjunto dos 49 aprovados |
| `tandem_stance` | `commonly_confused_with` | `semi_tandem_stance` | referência fora do subconjunto dos 49 aprovados |
| `tandem_walk` | `commonly_confused_with` | `balance_beam_walk` | referência fora do subconjunto dos 49 aprovados |
| `upright_stationary_cycling` | `commonly_confused_with` | `overground_cycling` | referência fora do subconjunto dos 49 aprovados |

## Transformações autorizadas

- Seleção exata dos 49 `approved`.
- Separação das relações `compatible` e `conditional`.
- Classificação fail-closed das condicionais.
- Projeção dos campos canónicos para uma forma técnica, sem dose nem prescrição.
- Multimédia normalizada para `not_yet_approved`.
- Valores sem fonte suficiente marcados `omitted_by_scope`.
- Vocabulários limitados aos valores realmente usados pelos 49 exercícios.
