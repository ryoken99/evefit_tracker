# EveFit Exercise Implementation Equipment and Location Report Wave1 v0.1

## Modelo preparado, não implementado

```text
AvailableExercisesForLocation =
Exercises
∩ LocationCompatibility
∩ AvailableEquipmentCompatibility
∩ EnvironmentCompatibility
```

O pacote não inventa inventário do utilizador, não cria locais predefinidos como fonte de verdade e não mistura equipamentos de locais diferentes.

## Contagens

- Equipamentos e equipamento pessoal usados: 46.
- Exercícios que suportam ausência de equipamento: 30.
- Compatíveis com interior: 49.
- Compatíveis com exterior: 43.
- Aquáticos: 0.
- Valores ambientais ou características de local: 120.
- Superfícies: 40.
- Classes de espaço: 6.
- Requisitos de supervisão: 2.

## Equipamento

`approved_archery_bow`, `approved_arrows`, `archery_target_butt`, `arm_guard`, `audio_playback_device`, `auditory_pacer`, `auditory_pacing_app`, `basketball`, `basketball_hoop`, `boxing_gloves`, `distance_markers`, `drag_sled`, `exercise_mat`, `finger_protection`, `firm_rolled_towel`, `fitted_manual_wheelchair`, `flat_floor_marking_tape`, `floor_markers`, `floor_target_marker`, `foam_roller`, `football`, `freestanding_stable_support`, `full_body_elliptical_trainer`, `hand_wraps`, `haptic_pacer`, `head_or_knee_support`, `low_friction_slider`, `medicine_ball`, `metronome`, `motorized_treadmill`, `pair_of_focus_mitts`, `skipping_rope`, `sport_appropriate_footwear`, `sprint_harness`, `stable_chair`, `stable_chair_without_wheels`, `stable_support`, `static_rowing_ergometer`, `stationary_arm_crank_ergometer`, `stretching_strap`, `towel`, `upright_stationary_cycle`, `verified_backstop`, `visual_pacer`, `volleyball`, `waist_belt_attachment`

## Superfícies

`cluttered_surface`, `damaged_or_slippery_steps`, `damaged_or_unverified_treadmill`, `firm_even_impact_tolerant_surface`, `firm_even_non_slip_surface`, `firm_even_surface`, `firm_level_non_slip_floor_under_chair`, `firm_level_non_slip_surface`, `firm_level_supine_support`, `firm_level_surface_or_short_turf`, `firm_stable_surface`, `fixed_uniform_stair_treads`, `flush_non_trip_floor_markings`, `fragile_surface`, `level_machine_support_surface`, `loose_markers`, `low_ceiling`, `moving_treadmill_belt`, `moving_vehicle`, `obstructed_or_unstable_surface`, `raised_rods`, `rear_knee_tolerable_surface`, `sharp_or_unstable_fulcrum`, `slippery_floor`, `slippery_or_obstructed_surface`, `slippery_surface`, `stable_non_slip_surface`, `stable_shooting_line`, `surface_allowing_controlled_heel_slide`, `surface_causing_uncontrolled_slip`, `surface_exceeding_wheelchair_or_user_control`, `uncontrolled_shared_space`, `uneven_surface`, `unsafe_or_unstable_support`, `unsecured_public_space`, `unstable_machine_base`, `unstable_or_wheeled_seating`, `unstable_surface`, `unverified_backstop`, `wheelchair_accessible_surface`

## Classes de espaço

`linear_displacement`, `minimal_stationary`, `moderate_stationary`, `multidirectional_displacement`, `small_stationary`, `specialized_facility`
