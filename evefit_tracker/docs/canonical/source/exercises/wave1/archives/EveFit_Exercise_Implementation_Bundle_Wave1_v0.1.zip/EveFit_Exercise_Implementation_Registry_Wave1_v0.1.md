# EveFit Exercise Implementation Registry Wave1 v0.1

**Estado:** pacote técnico documental para auditoria antes do Planner. Não implementado nem publicado.

O JSON homónimo é a representação técnica completa. Esta vista Markdown fixa os mesmos 49 IDs, nomes, estados, capacidades, variantes, riscos e contagens de relações.

| Exercise ID | Nome PT-PT | Capacidade principal | Tipo | Variante de | Risco | Relações |
|---|---|---|---|---|---|---:|
| `active_ankle_circumduction` | Circundução ativa do tornozelo | `mobility` | `canonical_exercise` | `none` | `low` | 4 |
| `active_ankle_dorsiflexion_plantarflexion` | Flexão dorsal e plantar ativa do tornozelo | `mobility` | `canonical_exercise` | `none` | `low` | 4 |
| `archery_shot_cycle_to_target` | Ciclo de tiro com arco para alvo | `technique_skill` | `canonical_exercise` | `none` | `high` | 3 |
| `basketball_set_shot_to_basket` | Lançamento parado de basquetebol ao cesto | `technique_skill` | `canonical_exercise` | `none` | `low` | 3 |
| `bilateral_pogo_jump` | Saltos reativos curtos bipodais | `speed_power` | `canonical_exercise` | `none` | `high` | 1 |
| `boxing_jab_cross_to_focus_mitts` | Sequência jab-direto para manoplas | `technique_skill` | `technique_drill` | `none` | `moderate` | 4 |
| `clockwise_four_quadrant_step_sequence` | Sequência de passos em quatro quadrantes no sentido horário | `motor_control_coordination` | `technique_drill` | `none` | `moderate` | 4 |
| `continuous_stair_ascent` | Subida contínua de escadas | `cardio_conditioning` | `canonical_exercise` | `none` | `moderate` | 3 |
| `countermovement_jump` | Salto vertical com contramovimento | `speed_power` | `canonical_exercise` | `none` | `high` | 2 |
| `diaphragmatic_breathing` | Respiração diafragmática | `breathing_regulation` | `canonical_exercise` | `none` | `low` | 7 |
| `doorway_pectoral_stretch` | Alongamento peitoral no vão da porta | `flexibility` | `canonical_exercise` | `none` | `moderate` | 2 |
| `football_directional_first_touch` | Primeiro toque direcional no futebol | `technique_skill` | `canonical_exercise` | `none` | `low` | 3 |
| `front_to_back_leg_swing` | Balanço da perna à frente e atrás | `flexibility` | `canonical_exercise` | `none` | `moderate` | 3 |
| `full_body_elliptical` | Movimento elíptico de corpo inteiro | `cardio_conditioning` | `canonical_exercise` | `none` | `low` | 3 |
| `half_kneeling_ankle_dorsiflexion_rock` | Avanço de dorsiflexão do tornozelo em meio-ajoelhado | `mobility` | `canonical_exercise` | `none` | `moderate` | 3 |
| `lateral_costal_breathing` | Respiração com expansão costal lateral | `breathing_regulation` | `technique_drill` | `none` | `low` | 3 |
| `lateral_leg_swing` | Balanço lateral da perna | `flexibility` | `canonical_exercise` | `none` | `moderate` | 3 |
| `linear_sprint` | Sprint linear | `speed_power` | `canonical_exercise` | `none` | `high` | 2 |
| `manual_wheelchair_propulsion_overground` | Propulsão manual de cadeira de rodas no solo | `cardio_conditioning` | `canonical_exercise` | `none` | `moderate` | 3 |
| `march_in_place_to_external_beat` | Marcha no lugar sincronizada com pulso externo | `motor_control_coordination` | `technique_drill` | `none` | `moderate` | 5 |
| `marching_in_place` | Marcha no lugar | `cardio_conditioning` | `canonical_exercise` | `none` | `low` | 4 |
| `overground_running` | Corrida terrestre | `cardio_conditioning` | `canonical_exercise` | `none` | `moderate` | 3 |
| `overground_walking` | Caminhada terrestre | `cardio_conditioning` | `canonical_exercise` | `none` | `low` | 5 |
| `paced_breathing` | Respiração ritmada | `breathing_regulation` | `technique_drill` | `none` | `low` | 11 |
| `plyometric_push_up` | Flexão de braços pliométrica | `speed_power` | `canonical_exercise` | `none` | `high` | 2 |
| `respiratory_sensation_observation` | Observação das sensações respiratórias | `breathing_regulation` | `technique_drill` | `none` | `low` | 1 |
| `seated_butterfly_adductor_stretch` | Alongamento borboleta dos adutores | `flexibility` | `canonical_exercise` | `none` | `low` | 2 |
| `seated_single_leg_hamstring_stretch` | Alongamento unilateral dos isquiotibiais sentado | `flexibility` | `canonical_exercise` | `none` | `low` | 2 |
| `seated_supported_thoracic_extension` | Extensão torácica sentada sobre apoio | `mobility` | `canonical_exercise` | `none` | `moderate` | 3 |
| `single_leg_stance` | Postura unipodal | `motor_control_coordination` | `canonical_exercise` | `none` | `moderate` | 4 |
| `sled_resisted_sprint` | Sprint resistido com trenó | `speed_power` | `exercise_variant` | `linear_sprint` | `high` | 1 |
| `sprint_to_controlled_stop` | Sprint com paragem controlada | `speed_power` | `technique_drill` | `none` | `high` | 2 |
| `standing_broad_jump` | Salto horizontal bipodal parado | `speed_power` | `canonical_exercise` | `none` | `high` | 1 |
| `standing_gastrocnemius_wall_stretch` | Alongamento dos gémeos à parede com joelho estendido | `flexibility` | `canonical_exercise` | `none` | `low` | 3 |
| `standing_medicine_ball_chest_pass` | Passe de peito com bola medicinal em pé | `speed_power` | `canonical_exercise` | `none` | `moderate` | 1 |
| `standing_multidirectional_weight_shift` | Transferência de peso multidirecional em pé | `motor_control_coordination` | `canonical_exercise` | `none` | `low` | 3 |
| `standing_soleus_wall_stretch` | Alongamento do sóleo à parede com joelho fletido | `flexibility` | `canonical_exercise` | `none` | `low` | 2 |
| `static_rowing_ergometer` | Remo em ergómetro estático | `cardio_conditioning` | `canonical_exercise` | `none` | `moderate` | 6 |
| `stationary_arm_crank_ergometry` | Ergometria estacionária de manivela para braços | `cardio_conditioning` | `canonical_exercise` | `none` | `low` | 3 |
| `supine_hamstring_strap_stretch` | Alongamento dos isquiotibiais em decúbito dorsal com correia | `flexibility` | `exercise_variant` | `supine_self_assisted_hamstring_stretch` | `low` | 2 |
| `supine_heel_slide` | Deslizamento do calcanhar em decúbito dorsal | `mobility` | `canonical_exercise` | `none` | `low` | 3 |
| `supine_self_assisted_hamstring_stretch` | Alongamento dos isquiotibiais em decúbito dorsal com as mãos | `flexibility` | `canonical_exercise` | `none` | `low` | 2 |
| `tandem_stance` | Postura tandem | `motor_control_coordination` | `canonical_exercise` | `none` | `moderate` | 3 |
| `tandem_walk` | Marcha tandem | `motor_control_coordination` | `canonical_exercise` | `none` | `moderate` | 4 |
| `treadmill_walking` | Caminhada em passadeira | `cardio_conditioning` | `exercise_variant` | `overground_walking` | `moderate` | 3 |
| `two_foot_rope_skipping` | Salto à corda a dois pés | `cardio_conditioning` | `canonical_exercise` | `none` | `moderate` | 5 |
| `two_point_sprint_start` | Arranque de sprint de dois apoios | `speed_power` | `technique_drill` | `none` | `high` | 2 |
| `upright_stationary_cycling` | Pedalada em bicicleta estacionária vertical | `cardio_conditioning` | `canonical_exercise` | `none` | `low` | 4 |
| `volleyball_forearm_pass_to_target` | Passe de antebraços de voleibol para alvo | `technique_skill` | `canonical_exercise` | `none` | `low` | 2 |

## Regras do subconjunto

- Exatamente 49 registos com `record_status = approved`.
- Zero exercícios `specialist_review` e zero capacidade principal `muscular_capacity`.
- Exatamente três relações formais `variant_of`.
- Multimédia marcada como `not_yet_approved`.
- O campo `breathing_guidance_pt_pt` está `omitted_by_scope` porque a fonte não o fornece separadamente.
- Dose, carga, séries, repetições, duração, intensidade, ritmo, descanso e frequência não são prescritos.
