# EveFit Exercise Implementation Validation Report Wave1 v0.1

**Resultado:** 1461 verificações aprovadas; 0 falhas.

**Segunda geração byte a byte idêntica:** confirmada.

| Verificação | Estado | Detalhe |
|---|---|---|
| `source_zip_sha256` | `passed` |  |
| `source_spec_sha256` | `passed` |  |
| `source_v04_sha256` | `passed` |  |
| `source_v041_sha256` | `passed` |  |
| `source_zip_file_count` | `passed` | 209 |
| `source_internal_hash_count` | `passed` | 208 |
| `source_internal_hash_failures` | `passed` | 0 |
| `approved_exercise_count` | `passed` | 49 |
| `approved_id_uniqueness` | `passed` | 49 |
| `approved_name_uniqueness` | `passed` |  |
| `specialist_review_excluded_count` | `passed` | 25 |
| `pending_relation_excluded_count` | `passed` | 52 |
| `nonapproved_conditional_excluded_count` | `passed` | 13 |
| `relation_total` | `passed` | 154 |
| `compatible_relation_count` | `passed` | 88 |
| `conditional_relation_count` | `passed` | 66 |
| `muscular_candidate_count` | `passed` | 159 |
| `variant_count` | `passed` |  |
| `record_status:active_ankle_circumduction` | `passed` |  |
| `primary_capability_non_muscular:active_ankle_circumduction` | `passed` |  |
| `media_status:active_ankle_circumduction` | `passed` |  |
| `required_identity_fields:active_ankle_circumduction` | `passed` |  |
| `required_structures:active_ankle_circumduction` | `passed` |  |
| `excluded_identity_references_absent:active_ankle_circumduction` | `passed` |  |
| `record_status:active_ankle_dorsiflexion_plantarflexion` | `passed` |  |
| `primary_capability_non_muscular:active_ankle_dorsiflexion_plantarflexion` | `passed` |  |
| `media_status:active_ankle_dorsiflexion_plantarflexion` | `passed` |  |
| `required_identity_fields:active_ankle_dorsiflexion_plantarflexion` | `passed` |  |
| `required_structures:active_ankle_dorsiflexion_plantarflexion` | `passed` |  |
| `excluded_identity_references_absent:active_ankle_dorsiflexion_plantarflexion` | `passed` |  |
| `record_status:archery_shot_cycle_to_target` | `passed` |  |
| `primary_capability_non_muscular:archery_shot_cycle_to_target` | `passed` |  |
| `media_status:archery_shot_cycle_to_target` | `passed` |  |
| `required_identity_fields:archery_shot_cycle_to_target` | `passed` |  |
| `required_structures:archery_shot_cycle_to_target` | `passed` |  |
| `excluded_identity_references_absent:archery_shot_cycle_to_target` | `passed` |  |
| `record_status:basketball_set_shot_to_basket` | `passed` |  |
| `primary_capability_non_muscular:basketball_set_shot_to_basket` | `passed` |  |
| `media_status:basketball_set_shot_to_basket` | `passed` |  |
| `required_identity_fields:basketball_set_shot_to_basket` | `passed` |  |
| `required_structures:basketball_set_shot_to_basket` | `passed` |  |
| `excluded_identity_references_absent:basketball_set_shot_to_basket` | `passed` |  |
| `record_status:bilateral_pogo_jump` | `passed` |  |
| `primary_capability_non_muscular:bilateral_pogo_jump` | `passed` |  |
| `media_status:bilateral_pogo_jump` | `passed` |  |
| `required_identity_fields:bilateral_pogo_jump` | `passed` |  |
| `required_structures:bilateral_pogo_jump` | `passed` |  |
| `excluded_identity_references_absent:bilateral_pogo_jump` | `passed` |  |
| `record_status:boxing_jab_cross_to_focus_mitts` | `passed` |  |
| `primary_capability_non_muscular:boxing_jab_cross_to_focus_mitts` | `passed` |  |
| `media_status:boxing_jab_cross_to_focus_mitts` | `passed` |  |
| `required_identity_fields:boxing_jab_cross_to_focus_mitts` | `passed` |  |
| `required_structures:boxing_jab_cross_to_focus_mitts` | `passed` |  |
| `excluded_identity_references_absent:boxing_jab_cross_to_focus_mitts` | `passed` |  |
| `record_status:clockwise_four_quadrant_step_sequence` | `passed` |  |
| `primary_capability_non_muscular:clockwise_four_quadrant_step_sequence` | `passed` |  |
| `media_status:clockwise_four_quadrant_step_sequence` | `passed` |  |
| `required_identity_fields:clockwise_four_quadrant_step_sequence` | `passed` |  |
| `required_structures:clockwise_four_quadrant_step_sequence` | `passed` |  |
| `excluded_identity_references_absent:clockwise_four_quadrant_step_sequence` | `passed` |  |
| `record_status:continuous_stair_ascent` | `passed` |  |
| `primary_capability_non_muscular:continuous_stair_ascent` | `passed` |  |
| `media_status:continuous_stair_ascent` | `passed` |  |
| `required_identity_fields:continuous_stair_ascent` | `passed` |  |
| `required_structures:continuous_stair_ascent` | `passed` |  |
| `excluded_identity_references_absent:continuous_stair_ascent` | `passed` |  |
| `record_status:countermovement_jump` | `passed` |  |
| `primary_capability_non_muscular:countermovement_jump` | `passed` |  |
| `media_status:countermovement_jump` | `passed` |  |
| `required_identity_fields:countermovement_jump` | `passed` |  |
| `required_structures:countermovement_jump` | `passed` |  |
| `excluded_identity_references_absent:countermovement_jump` | `passed` |  |
| `record_status:diaphragmatic_breathing` | `passed` |  |
| `primary_capability_non_muscular:diaphragmatic_breathing` | `passed` |  |
| `media_status:diaphragmatic_breathing` | `passed` |  |
| `required_identity_fields:diaphragmatic_breathing` | `passed` |  |
| `required_structures:diaphragmatic_breathing` | `passed` |  |
| `excluded_identity_references_absent:diaphragmatic_breathing` | `passed` |  |
| `record_status:doorway_pectoral_stretch` | `passed` |  |
| `primary_capability_non_muscular:doorway_pectoral_stretch` | `passed` |  |
| `media_status:doorway_pectoral_stretch` | `passed` |  |
| `required_identity_fields:doorway_pectoral_stretch` | `passed` |  |
| `required_structures:doorway_pectoral_stretch` | `passed` |  |
| `excluded_identity_references_absent:doorway_pectoral_stretch` | `passed` |  |
| `record_status:football_directional_first_touch` | `passed` |  |
| `primary_capability_non_muscular:football_directional_first_touch` | `passed` |  |
| `media_status:football_directional_first_touch` | `passed` |  |
| `required_identity_fields:football_directional_first_touch` | `passed` |  |
| `required_structures:football_directional_first_touch` | `passed` |  |
| `excluded_identity_references_absent:football_directional_first_touch` | `passed` |  |
| `record_status:front_to_back_leg_swing` | `passed` |  |
| `primary_capability_non_muscular:front_to_back_leg_swing` | `passed` |  |
| `media_status:front_to_back_leg_swing` | `passed` |  |
| `required_identity_fields:front_to_back_leg_swing` | `passed` |  |
| `required_structures:front_to_back_leg_swing` | `passed` |  |
| `excluded_identity_references_absent:front_to_back_leg_swing` | `passed` |  |
| `record_status:full_body_elliptical` | `passed` |  |
| `primary_capability_non_muscular:full_body_elliptical` | `passed` |  |
| `media_status:full_body_elliptical` | `passed` |  |
| `required_identity_fields:full_body_elliptical` | `passed` |  |
| `required_structures:full_body_elliptical` | `passed` |  |
| `excluded_identity_references_absent:full_body_elliptical` | `passed` |  |
| `record_status:half_kneeling_ankle_dorsiflexion_rock` | `passed` |  |
| `primary_capability_non_muscular:half_kneeling_ankle_dorsiflexion_rock` | `passed` |  |
| `media_status:half_kneeling_ankle_dorsiflexion_rock` | `passed` |  |
| `required_identity_fields:half_kneeling_ankle_dorsiflexion_rock` | `passed` |  |
| `required_structures:half_kneeling_ankle_dorsiflexion_rock` | `passed` |  |
| `excluded_identity_references_absent:half_kneeling_ankle_dorsiflexion_rock` | `passed` |  |
| `record_status:lateral_costal_breathing` | `passed` |  |
| `primary_capability_non_muscular:lateral_costal_breathing` | `passed` |  |
| `media_status:lateral_costal_breathing` | `passed` |  |
| `required_identity_fields:lateral_costal_breathing` | `passed` |  |
| `required_structures:lateral_costal_breathing` | `passed` |  |
| `excluded_identity_references_absent:lateral_costal_breathing` | `passed` |  |
| `record_status:lateral_leg_swing` | `passed` |  |
| `primary_capability_non_muscular:lateral_leg_swing` | `passed` |  |
| `media_status:lateral_leg_swing` | `passed` |  |
| `required_identity_fields:lateral_leg_swing` | `passed` |  |
| `required_structures:lateral_leg_swing` | `passed` |  |
| `excluded_identity_references_absent:lateral_leg_swing` | `passed` |  |
| `record_status:linear_sprint` | `passed` |  |
| `primary_capability_non_muscular:linear_sprint` | `passed` |  |
| `media_status:linear_sprint` | `passed` |  |
| `required_identity_fields:linear_sprint` | `passed` |  |
| `required_structures:linear_sprint` | `passed` |  |
| `excluded_identity_references_absent:linear_sprint` | `passed` |  |
| `record_status:manual_wheelchair_propulsion_overground` | `passed` |  |
| `primary_capability_non_muscular:manual_wheelchair_propulsion_overground` | `passed` |  |
| `media_status:manual_wheelchair_propulsion_overground` | `passed` |  |
| `required_identity_fields:manual_wheelchair_propulsion_overground` | `passed` |  |
| `required_structures:manual_wheelchair_propulsion_overground` | `passed` |  |
| `excluded_identity_references_absent:manual_wheelchair_propulsion_overground` | `passed` |  |
| `record_status:march_in_place_to_external_beat` | `passed` |  |
| `primary_capability_non_muscular:march_in_place_to_external_beat` | `passed` |  |
| `media_status:march_in_place_to_external_beat` | `passed` |  |
| `required_identity_fields:march_in_place_to_external_beat` | `passed` |  |
| `required_structures:march_in_place_to_external_beat` | `passed` |  |
| `excluded_identity_references_absent:march_in_place_to_external_beat` | `passed` |  |
| `record_status:marching_in_place` | `passed` |  |
| `primary_capability_non_muscular:marching_in_place` | `passed` |  |
| `media_status:marching_in_place` | `passed` |  |
| `required_identity_fields:marching_in_place` | `passed` |  |
| `required_structures:marching_in_place` | `passed` |  |
| `excluded_identity_references_absent:marching_in_place` | `passed` |  |
| `record_status:overground_running` | `passed` |  |
| `primary_capability_non_muscular:overground_running` | `passed` |  |
| `media_status:overground_running` | `passed` |  |
| `required_identity_fields:overground_running` | `passed` |  |
| `required_structures:overground_running` | `passed` |  |
| `excluded_identity_references_absent:overground_running` | `passed` |  |
| `record_status:overground_walking` | `passed` |  |
| `primary_capability_non_muscular:overground_walking` | `passed` |  |
| `media_status:overground_walking` | `passed` |  |
| `required_identity_fields:overground_walking` | `passed` |  |
| `required_structures:overground_walking` | `passed` |  |
| `excluded_identity_references_absent:overground_walking` | `passed` |  |
| `record_status:paced_breathing` | `passed` |  |
| `primary_capability_non_muscular:paced_breathing` | `passed` |  |
| `media_status:paced_breathing` | `passed` |  |
| `required_identity_fields:paced_breathing` | `passed` |  |
| `required_structures:paced_breathing` | `passed` |  |
| `excluded_identity_references_absent:paced_breathing` | `passed` |  |
| `record_status:plyometric_push_up` | `passed` |  |
| `primary_capability_non_muscular:plyometric_push_up` | `passed` |  |
| `media_status:plyometric_push_up` | `passed` |  |
| `required_identity_fields:plyometric_push_up` | `passed` |  |
| `required_structures:plyometric_push_up` | `passed` |  |
| `excluded_identity_references_absent:plyometric_push_up` | `passed` |  |
| `record_status:respiratory_sensation_observation` | `passed` |  |
| `primary_capability_non_muscular:respiratory_sensation_observation` | `passed` |  |
| `media_status:respiratory_sensation_observation` | `passed` |  |
| `required_identity_fields:respiratory_sensation_observation` | `passed` |  |
| `required_structures:respiratory_sensation_observation` | `passed` |  |
| `excluded_identity_references_absent:respiratory_sensation_observation` | `passed` |  |
| `record_status:seated_butterfly_adductor_stretch` | `passed` |  |
| `primary_capability_non_muscular:seated_butterfly_adductor_stretch` | `passed` |  |
| `media_status:seated_butterfly_adductor_stretch` | `passed` |  |
| `required_identity_fields:seated_butterfly_adductor_stretch` | `passed` |  |
| `required_structures:seated_butterfly_adductor_stretch` | `passed` |  |
| `excluded_identity_references_absent:seated_butterfly_adductor_stretch` | `passed` |  |
| `record_status:seated_single_leg_hamstring_stretch` | `passed` |  |
| `primary_capability_non_muscular:seated_single_leg_hamstring_stretch` | `passed` |  |
| `media_status:seated_single_leg_hamstring_stretch` | `passed` |  |
| `required_identity_fields:seated_single_leg_hamstring_stretch` | `passed` |  |
| `required_structures:seated_single_leg_hamstring_stretch` | `passed` |  |
| `excluded_identity_references_absent:seated_single_leg_hamstring_stretch` | `passed` |  |
| `record_status:seated_supported_thoracic_extension` | `passed` |  |
| `primary_capability_non_muscular:seated_supported_thoracic_extension` | `passed` |  |
| `media_status:seated_supported_thoracic_extension` | `passed` |  |
| `required_identity_fields:seated_supported_thoracic_extension` | `passed` |  |
| `required_structures:seated_supported_thoracic_extension` | `passed` |  |
| `excluded_identity_references_absent:seated_supported_thoracic_extension` | `passed` |  |
| `record_status:single_leg_stance` | `passed` |  |
| `primary_capability_non_muscular:single_leg_stance` | `passed` |  |
| `media_status:single_leg_stance` | `passed` |  |
| `required_identity_fields:single_leg_stance` | `passed` |  |
| `required_structures:single_leg_stance` | `passed` |  |
| `excluded_identity_references_absent:single_leg_stance` | `passed` |  |
| `record_status:sled_resisted_sprint` | `passed` |  |
| `primary_capability_non_muscular:sled_resisted_sprint` | `passed` |  |
| `media_status:sled_resisted_sprint` | `passed` |  |
| `required_identity_fields:sled_resisted_sprint` | `passed` |  |
| `required_structures:sled_resisted_sprint` | `passed` |  |
| `excluded_identity_references_absent:sled_resisted_sprint` | `passed` |  |
| `record_status:sprint_to_controlled_stop` | `passed` |  |
| `primary_capability_non_muscular:sprint_to_controlled_stop` | `passed` |  |
| `media_status:sprint_to_controlled_stop` | `passed` |  |
| `required_identity_fields:sprint_to_controlled_stop` | `passed` |  |
| `required_structures:sprint_to_controlled_stop` | `passed` |  |
| `excluded_identity_references_absent:sprint_to_controlled_stop` | `passed` |  |
| `record_status:standing_broad_jump` | `passed` |  |
| `primary_capability_non_muscular:standing_broad_jump` | `passed` |  |
| `media_status:standing_broad_jump` | `passed` |  |
| `required_identity_fields:standing_broad_jump` | `passed` |  |
| `required_structures:standing_broad_jump` | `passed` |  |
| `excluded_identity_references_absent:standing_broad_jump` | `passed` |  |
| `record_status:standing_gastrocnemius_wall_stretch` | `passed` |  |
| `primary_capability_non_muscular:standing_gastrocnemius_wall_stretch` | `passed` |  |
| `media_status:standing_gastrocnemius_wall_stretch` | `passed` |  |
| `required_identity_fields:standing_gastrocnemius_wall_stretch` | `passed` |  |
| `required_structures:standing_gastrocnemius_wall_stretch` | `passed` |  |
| `excluded_identity_references_absent:standing_gastrocnemius_wall_stretch` | `passed` |  |
| `record_status:standing_medicine_ball_chest_pass` | `passed` |  |
| `primary_capability_non_muscular:standing_medicine_ball_chest_pass` | `passed` |  |
| `media_status:standing_medicine_ball_chest_pass` | `passed` |  |
| `required_identity_fields:standing_medicine_ball_chest_pass` | `passed` |  |
| `required_structures:standing_medicine_ball_chest_pass` | `passed` |  |
| `excluded_identity_references_absent:standing_medicine_ball_chest_pass` | `passed` |  |
| `record_status:standing_multidirectional_weight_shift` | `passed` |  |
| `primary_capability_non_muscular:standing_multidirectional_weight_shift` | `passed` |  |
| `media_status:standing_multidirectional_weight_shift` | `passed` |  |
| `required_identity_fields:standing_multidirectional_weight_shift` | `passed` |  |
| `required_structures:standing_multidirectional_weight_shift` | `passed` |  |
| `excluded_identity_references_absent:standing_multidirectional_weight_shift` | `passed` |  |
| `record_status:standing_soleus_wall_stretch` | `passed` |  |
| `primary_capability_non_muscular:standing_soleus_wall_stretch` | `passed` |  |
| `media_status:standing_soleus_wall_stretch` | `passed` |  |
| `required_identity_fields:standing_soleus_wall_stretch` | `passed` |  |
| `required_structures:standing_soleus_wall_stretch` | `passed` |  |
| `excluded_identity_references_absent:standing_soleus_wall_stretch` | `passed` |  |
| `record_status:static_rowing_ergometer` | `passed` |  |
| `primary_capability_non_muscular:static_rowing_ergometer` | `passed` |  |
| `media_status:static_rowing_ergometer` | `passed` |  |
| `required_identity_fields:static_rowing_ergometer` | `passed` |  |
| `required_structures:static_rowing_ergometer` | `passed` |  |
| `excluded_identity_references_absent:static_rowing_ergometer` | `passed` |  |
| `record_status:stationary_arm_crank_ergometry` | `passed` |  |
| `primary_capability_non_muscular:stationary_arm_crank_ergometry` | `passed` |  |
| `media_status:stationary_arm_crank_ergometry` | `passed` |  |
| `required_identity_fields:stationary_arm_crank_ergometry` | `passed` |  |
| `required_structures:stationary_arm_crank_ergometry` | `passed` |  |
| `excluded_identity_references_absent:stationary_arm_crank_ergometry` | `passed` |  |
| `record_status:supine_hamstring_strap_stretch` | `passed` |  |
| `primary_capability_non_muscular:supine_hamstring_strap_stretch` | `passed` |  |
| `media_status:supine_hamstring_strap_stretch` | `passed` |  |
| `required_identity_fields:supine_hamstring_strap_stretch` | `passed` |  |
| `required_structures:supine_hamstring_strap_stretch` | `passed` |  |
| `excluded_identity_references_absent:supine_hamstring_strap_stretch` | `passed` |  |
| `record_status:supine_heel_slide` | `passed` |  |
| `primary_capability_non_muscular:supine_heel_slide` | `passed` |  |
| `media_status:supine_heel_slide` | `passed` |  |
| `required_identity_fields:supine_heel_slide` | `passed` |  |
| `required_structures:supine_heel_slide` | `passed` |  |
| `excluded_identity_references_absent:supine_heel_slide` | `passed` |  |
| `record_status:supine_self_assisted_hamstring_stretch` | `passed` |  |
| `primary_capability_non_muscular:supine_self_assisted_hamstring_stretch` | `passed` |  |
| `media_status:supine_self_assisted_hamstring_stretch` | `passed` |  |
| `required_identity_fields:supine_self_assisted_hamstring_stretch` | `passed` |  |
| `required_structures:supine_self_assisted_hamstring_stretch` | `passed` |  |
| `excluded_identity_references_absent:supine_self_assisted_hamstring_stretch` | `passed` |  |
| `record_status:tandem_stance` | `passed` |  |
| `primary_capability_non_muscular:tandem_stance` | `passed` |  |
| `media_status:tandem_stance` | `passed` |  |
| `required_identity_fields:tandem_stance` | `passed` |  |
| `required_structures:tandem_stance` | `passed` |  |
| `excluded_identity_references_absent:tandem_stance` | `passed` |  |
| `record_status:tandem_walk` | `passed` |  |
| `primary_capability_non_muscular:tandem_walk` | `passed` |  |
| `media_status:tandem_walk` | `passed` |  |
| `required_identity_fields:tandem_walk` | `passed` |  |
| `required_structures:tandem_walk` | `passed` |  |
| `excluded_identity_references_absent:tandem_walk` | `passed` |  |
| `record_status:treadmill_walking` | `passed` |  |
| `primary_capability_non_muscular:treadmill_walking` | `passed` |  |
| `media_status:treadmill_walking` | `passed` |  |
| `required_identity_fields:treadmill_walking` | `passed` |  |
| `required_structures:treadmill_walking` | `passed` |  |
| `excluded_identity_references_absent:treadmill_walking` | `passed` |  |
| `record_status:two_foot_rope_skipping` | `passed` |  |
| `primary_capability_non_muscular:two_foot_rope_skipping` | `passed` |  |
| `media_status:two_foot_rope_skipping` | `passed` |  |
| `required_identity_fields:two_foot_rope_skipping` | `passed` |  |
| `required_structures:two_foot_rope_skipping` | `passed` |  |
| `excluded_identity_references_absent:two_foot_rope_skipping` | `passed` |  |
| `record_status:two_point_sprint_start` | `passed` |  |
| `primary_capability_non_muscular:two_point_sprint_start` | `passed` |  |
| `media_status:two_point_sprint_start` | `passed` |  |
| `required_identity_fields:two_point_sprint_start` | `passed` |  |
| `required_structures:two_point_sprint_start` | `passed` |  |
| `excluded_identity_references_absent:two_point_sprint_start` | `passed` |  |
| `record_status:upright_stationary_cycling` | `passed` |  |
| `primary_capability_non_muscular:upright_stationary_cycling` | `passed` |  |
| `media_status:upright_stationary_cycling` | `passed` |  |
| `required_identity_fields:upright_stationary_cycling` | `passed` |  |
| `required_structures:upright_stationary_cycling` | `passed` |  |
| `excluded_identity_references_absent:upright_stationary_cycling` | `passed` |  |
| `record_status:volleyball_forearm_pass_to_target` | `passed` |  |
| `primary_capability_non_muscular:volleyball_forearm_pass_to_target` | `passed` |  |
| `media_status:volleyball_forearm_pass_to_target` | `passed` |  |
| `required_identity_fields:volleyball_forearm_pass_to_target` | `passed` |  |
| `required_structures:volleyball_forearm_pass_to_target` | `passed` |  |
| `excluded_identity_references_absent:volleyball_forearm_pass_to_target` | `passed` |  |
| `variant_mapping_exact` | `passed` | {'sled_resisted_sprint': 'linear_sprint', 'supine_hamstring_strap_stretch': 'supine_self_assisted_hamstring_stretch', 'treadmill_walking': 'overground_walking'} |
| `variant_bases_exist` | `passed` |  |
| `relation_exercise_approved:active_ankle_circumduction__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` |  |
| `relation_status_allowed:active_ankle_circumduction__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` |  |
| `relation_path_exists:active_ankle_circumduction__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` |  |
| `relation_path_compatible:active_ankle_circumduction__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` | compatible |
| `relation_intention_in_path:active_ankle_circumduction__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` |  |
| `relation_role_match:active_ankle_circumduction__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:active_ankle_circumduction__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` |  |
| `relation_exercise_approved:active_ankle_circumduction__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` |  |
| `relation_status_allowed:active_ankle_circumduction__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` |  |
| `relation_path_exists:active_ankle_circumduction__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` |  |
| `relation_path_compatible:active_ankle_circumduction__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` | compatible |
| `relation_intention_in_path:active_ankle_circumduction__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` |  |
| `relation_role_match:active_ankle_circumduction__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:active_ankle_circumduction__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` |  |
| `relation_exercise_approved:active_ankle_circumduction__recovery__mobility__active_joint_exploration__maintain_light_joint_mobility_activity` | `passed` |  |
| `relation_status_allowed:active_ankle_circumduction__recovery__mobility__active_joint_exploration__maintain_light_joint_mobility_activity` | `passed` |  |
| `relation_path_exists:active_ankle_circumduction__recovery__mobility__active_joint_exploration__maintain_light_joint_mobility_activity` | `passed` |  |
| `relation_path_compatible:active_ankle_circumduction__recovery__mobility__active_joint_exploration__maintain_light_joint_mobility_activity` | `passed` | compatible |
| `relation_intention_in_path:active_ankle_circumduction__recovery__mobility__active_joint_exploration__maintain_light_joint_mobility_activity` | `passed` |  |
| `relation_role_match:active_ankle_circumduction__recovery__mobility__active_joint_exploration__maintain_light_joint_mobility_activity` | `passed` | complementary == complementary |
| `compatible_ready:active_ankle_circumduction__recovery__mobility__active_joint_exploration__maintain_light_joint_mobility_activity` | `passed` |  |
| `relation_exercise_approved:active_ankle_circumduction__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` |  |
| `relation_status_allowed:active_ankle_circumduction__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` |  |
| `relation_path_exists:active_ankle_circumduction__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` |  |
| `relation_path_compatible:active_ankle_circumduction__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` | compatible |
| `relation_intention_in_path:active_ankle_circumduction__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` |  |
| `relation_role_match:active_ankle_circumduction__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:active_ankle_circumduction__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` |  |
| `relation_exercise_approved:active_ankle_dorsiflexion_plantarflexion__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` |  |
| `relation_status_allowed:active_ankle_dorsiflexion_plantarflexion__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` |  |
| `relation_path_exists:active_ankle_dorsiflexion_plantarflexion__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` |  |
| `relation_path_compatible:active_ankle_dorsiflexion_plantarflexion__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` | compatible |
| `relation_intention_in_path:active_ankle_dorsiflexion_plantarflexion__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` |  |
| `relation_role_match:active_ankle_dorsiflexion_plantarflexion__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:active_ankle_dorsiflexion_plantarflexion__main_training__mobility__active_joint_exploration__increase_active_joint_range_of_motion` | `passed` |  |
| `relation_exercise_approved:active_ankle_dorsiflexion_plantarflexion__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` |  |
| `relation_status_allowed:active_ankle_dorsiflexion_plantarflexion__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` |  |
| `relation_path_exists:active_ankle_dorsiflexion_plantarflexion__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` |  |
| `relation_path_compatible:active_ankle_dorsiflexion_plantarflexion__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` | compatible |
| `relation_intention_in_path:active_ankle_dorsiflexion_plantarflexion__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` |  |
| `relation_role_match:active_ankle_dorsiflexion_plantarflexion__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:active_ankle_dorsiflexion_plantarflexion__prevention__mobility__active_joint_exploration__maintain_active_joint_range_capacity` | `passed` |  |
| `relation_exercise_approved:active_ankle_dorsiflexion_plantarflexion__recovery__mobility__active_joint_exploration__resume_comfortable_joint_motion_after_effort` | `passed` |  |
| `relation_status_allowed:active_ankle_dorsiflexion_plantarflexion__recovery__mobility__active_joint_exploration__resume_comfortable_joint_motion_after_effort` | `passed` |  |
| `relation_path_exists:active_ankle_dorsiflexion_plantarflexion__recovery__mobility__active_joint_exploration__resume_comfortable_joint_motion_after_effort` | `passed` |  |
| `relation_path_compatible:active_ankle_dorsiflexion_plantarflexion__recovery__mobility__active_joint_exploration__resume_comfortable_joint_motion_after_effort` | `passed` | compatible |
| `relation_intention_in_path:active_ankle_dorsiflexion_plantarflexion__recovery__mobility__active_joint_exploration__resume_comfortable_joint_motion_after_effort` | `passed` |  |
| `relation_role_match:active_ankle_dorsiflexion_plantarflexion__recovery__mobility__active_joint_exploration__resume_comfortable_joint_motion_after_effort` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:active_ankle_dorsiflexion_plantarflexion__recovery__mobility__active_joint_exploration__resume_comfortable_joint_motion_after_effort` | `passed` |  |
| `relation_exercise_approved:active_ankle_dorsiflexion_plantarflexion__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` |  |
| `relation_status_allowed:active_ankle_dorsiflexion_plantarflexion__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` |  |
| `relation_path_exists:active_ankle_dorsiflexion_plantarflexion__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` |  |
| `relation_path_compatible:active_ankle_dorsiflexion_plantarflexion__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` | compatible |
| `relation_intention_in_path:active_ankle_dorsiflexion_plantarflexion__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` |  |
| `relation_role_match:active_ankle_dorsiflexion_plantarflexion__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:active_ankle_dorsiflexion_plantarflexion__warmup__mobility__active_joint_exploration__prepare_required_joint_ranges` | `passed` |  |
| `relation_exercise_approved:archery_shot_cycle_to_target__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` |  |
| `relation_status_allowed:archery_shot_cycle_to_target__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` |  |
| `relation_path_exists:archery_shot_cycle_to_target__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` |  |
| `relation_path_compatible:archery_shot_cycle_to_target__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` | compatible |
| `relation_intention_in_path:archery_shot_cycle_to_target__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` |  |
| `relation_role_match:archery_shot_cycle_to_target__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:archery_shot_cycle_to_target__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` |  |
| `relation_exercise_approved:archery_shot_cycle_to_target__main_training__technique_skill__repeated_motor_sequence__improve_sequence_accuracy` | `passed` |  |
| `relation_status_allowed:archery_shot_cycle_to_target__main_training__technique_skill__repeated_motor_sequence__improve_sequence_accuracy` | `passed` |  |
| `relation_path_exists:archery_shot_cycle_to_target__main_training__technique_skill__repeated_motor_sequence__improve_sequence_accuracy` | `passed` |  |
| `relation_path_compatible:archery_shot_cycle_to_target__main_training__technique_skill__repeated_motor_sequence__improve_sequence_accuracy` | `passed` | compatible |
| `relation_intention_in_path:archery_shot_cycle_to_target__main_training__technique_skill__repeated_motor_sequence__improve_sequence_accuracy` | `passed` |  |
| `relation_role_match:archery_shot_cycle_to_target__main_training__technique_skill__repeated_motor_sequence__improve_sequence_accuracy` | `passed` | complementary == complementary |
| `compatible_ready:archery_shot_cycle_to_target__main_training__technique_skill__repeated_motor_sequence__improve_sequence_accuracy` | `passed` |  |
| `relation_exercise_approved:archery_shot_cycle_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` |  |
| `relation_status_allowed:archery_shot_cycle_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` |  |
| `relation_path_exists:archery_shot_cycle_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` |  |
| `relation_path_compatible:archery_shot_cycle_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` | compatible |
| `relation_intention_in_path:archery_shot_cycle_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` |  |
| `relation_role_match:archery_shot_cycle_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:archery_shot_cycle_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` |  |
| `relation_exercise_approved:basketball_set_shot_to_basket__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` |  |
| `relation_status_allowed:basketball_set_shot_to_basket__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` |  |
| `relation_path_exists:basketball_set_shot_to_basket__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` |  |
| `relation_path_compatible:basketball_set_shot_to_basket__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` | compatible |
| `relation_intention_in_path:basketball_set_shot_to_basket__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` |  |
| `relation_role_match:basketball_set_shot_to_basket__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:basketball_set_shot_to_basket__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` |  |
| `relation_exercise_approved:basketball_set_shot_to_basket__main_training__technique_skill__target_oriented_precision__improve_target_accuracy` | `passed` |  |
| `relation_status_allowed:basketball_set_shot_to_basket__main_training__technique_skill__target_oriented_precision__improve_target_accuracy` | `passed` |  |
| `relation_path_exists:basketball_set_shot_to_basket__main_training__technique_skill__target_oriented_precision__improve_target_accuracy` | `passed` |  |
| `relation_path_compatible:basketball_set_shot_to_basket__main_training__technique_skill__target_oriented_precision__improve_target_accuracy` | `passed` | compatible |
| `relation_intention_in_path:basketball_set_shot_to_basket__main_training__technique_skill__target_oriented_precision__improve_target_accuracy` | `passed` |  |
| `relation_role_match:basketball_set_shot_to_basket__main_training__technique_skill__target_oriented_precision__improve_target_accuracy` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:basketball_set_shot_to_basket__main_training__technique_skill__target_oriented_precision__improve_target_accuracy` | `passed` |  |
| `relation_exercise_approved:basketball_set_shot_to_basket__warmup__technique_skill__target_oriented_precision__prepare_target_control` | `passed` |  |
| `relation_status_allowed:basketball_set_shot_to_basket__warmup__technique_skill__target_oriented_precision__prepare_target_control` | `passed` |  |
| `relation_path_exists:basketball_set_shot_to_basket__warmup__technique_skill__target_oriented_precision__prepare_target_control` | `passed` |  |
| `relation_path_compatible:basketball_set_shot_to_basket__warmup__technique_skill__target_oriented_precision__prepare_target_control` | `passed` | compatible |
| `relation_intention_in_path:basketball_set_shot_to_basket__warmup__technique_skill__target_oriented_precision__prepare_target_control` | `passed` |  |
| `relation_role_match:basketball_set_shot_to_basket__warmup__technique_skill__target_oriented_precision__prepare_target_control` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:basketball_set_shot_to_basket__warmup__technique_skill__target_oriented_precision__prepare_target_control` | `passed` |  |
| `conditional_fail_closed:basketball_set_shot_to_basket__warmup__technique_skill__target_oriented_precision__prepare_target_control` | `passed` |  |
| `relation_exercise_approved:bilateral_pogo_jump__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` |  |
| `relation_status_allowed:bilateral_pogo_jump__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` |  |
| `relation_path_exists:bilateral_pogo_jump__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` |  |
| `relation_path_compatible:bilateral_pogo_jump__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` | compatible |
| `relation_intention_in_path:bilateral_pogo_jump__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` |  |
| `relation_role_match:bilateral_pogo_jump__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:bilateral_pogo_jump__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` |  |
| `relation_exercise_approved:boxing_jab_cross_to_focus_mitts__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_status_allowed:boxing_jab_cross_to_focus_mitts__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_path_exists:boxing_jab_cross_to_focus_mitts__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_path_compatible:boxing_jab_cross_to_focus_mitts__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` | compatible |
| `relation_intention_in_path:boxing_jab_cross_to_focus_mitts__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_role_match:boxing_jab_cross_to_focus_mitts__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` | complementary == complementary |
| `compatible_ready:boxing_jab_cross_to_focus_mitts__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_exercise_approved:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` |  |
| `relation_status_allowed:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` |  |
| `relation_path_exists:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` |  |
| `relation_path_compatible:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` | compatible |
| `relation_intention_in_path:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` |  |
| `relation_role_match:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` |  |
| `relation_exercise_approved:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__repeated_motor_sequence__improve_technical_sequence_fluency` | `passed` |  |
| `relation_status_allowed:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__repeated_motor_sequence__improve_technical_sequence_fluency` | `passed` |  |
| `relation_path_exists:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__repeated_motor_sequence__improve_technical_sequence_fluency` | `passed` |  |
| `relation_path_compatible:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__repeated_motor_sequence__improve_technical_sequence_fluency` | `passed` | compatible |
| `relation_intention_in_path:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__repeated_motor_sequence__improve_technical_sequence_fluency` | `passed` |  |
| `relation_role_match:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__repeated_motor_sequence__improve_technical_sequence_fluency` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__repeated_motor_sequence__improve_technical_sequence_fluency` | `passed` |  |
| `relation_exercise_approved:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__target_oriented_precision__improve_target_spatial_precision` | `passed` |  |
| `relation_status_allowed:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__target_oriented_precision__improve_target_spatial_precision` | `passed` |  |
| `relation_path_exists:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__target_oriented_precision__improve_target_spatial_precision` | `passed` |  |
| `relation_path_compatible:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__target_oriented_precision__improve_target_spatial_precision` | `passed` | compatible |
| `relation_intention_in_path:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__target_oriented_precision__improve_target_spatial_precision` | `passed` |  |
| `relation_role_match:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__target_oriented_precision__improve_target_spatial_precision` | `passed` | complementary == complementary |
| `compatible_ready:boxing_jab_cross_to_focus_mitts__main_training__technique_skill__target_oriented_precision__improve_target_spatial_precision` | `passed` |  |
| `relation_exercise_approved:clockwise_four_quadrant_step_sequence__activation__motor_control_coordination__repeated_motor_sequence__prime_sequence_timing` | `passed` |  |
| `relation_status_allowed:clockwise_four_quadrant_step_sequence__activation__motor_control_coordination__repeated_motor_sequence__prime_sequence_timing` | `passed` |  |
| `relation_path_exists:clockwise_four_quadrant_step_sequence__activation__motor_control_coordination__repeated_motor_sequence__prime_sequence_timing` | `passed` |  |
| `relation_path_compatible:clockwise_four_quadrant_step_sequence__activation__motor_control_coordination__repeated_motor_sequence__prime_sequence_timing` | `passed` | compatible |
| `relation_intention_in_path:clockwise_four_quadrant_step_sequence__activation__motor_control_coordination__repeated_motor_sequence__prime_sequence_timing` | `passed` |  |
| `relation_role_match:clockwise_four_quadrant_step_sequence__activation__motor_control_coordination__repeated_motor_sequence__prime_sequence_timing` | `passed` | complementary == complementary |
| `conditional_classified:clockwise_four_quadrant_step_sequence__activation__motor_control_coordination__repeated_motor_sequence__prime_sequence_timing` | `passed` |  |
| `conditional_fail_closed:clockwise_four_quadrant_step_sequence__activation__motor_control_coordination__repeated_motor_sequence__prime_sequence_timing` | `passed` |  |
| `relation_exercise_approved:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` |  |
| `relation_status_allowed:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` |  |
| `relation_path_exists:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` |  |
| `relation_path_compatible:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` | compatible |
| `relation_intention_in_path:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` |  |
| `relation_role_match:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` |  |
| `relation_exercise_approved:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` |  |
| `relation_status_allowed:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` |  |
| `relation_path_exists:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` |  |
| `relation_path_compatible:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` | compatible |
| `relation_intention_in_path:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` |  |
| `relation_role_match:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:clockwise_four_quadrant_step_sequence__main_training__motor_control_coordination__repeated_motor_sequence__improve_motor_sequence_ordering` | `passed` |  |
| `relation_exercise_approved:clockwise_four_quadrant_step_sequence__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_status_allowed:clockwise_four_quadrant_step_sequence__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_path_exists:clockwise_four_quadrant_step_sequence__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_path_compatible:clockwise_four_quadrant_step_sequence__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` | compatible |
| `relation_intention_in_path:clockwise_four_quadrant_step_sequence__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_role_match:clockwise_four_quadrant_step_sequence__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:clockwise_four_quadrant_step_sequence__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `conditional_fail_closed:clockwise_four_quadrant_step_sequence__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_exercise_approved:continuous_stair_ascent__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_status_allowed:continuous_stair_ascent__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_exists:continuous_stair_ascent__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_compatible:continuous_stair_ascent__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` | compatible |
| `relation_intention_in_path:continuous_stair_ascent__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_role_match:continuous_stair_ascent__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:continuous_stair_ascent__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_exercise_approved:continuous_stair_ascent__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_status_allowed:continuous_stair_ascent__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_path_exists:continuous_stair_ascent__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_path_compatible:continuous_stair_ascent__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` | compatible |
| `relation_intention_in_path:continuous_stair_ascent__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_role_match:continuous_stair_ascent__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:continuous_stair_ascent__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_exercise_approved:continuous_stair_ascent__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `relation_status_allowed:continuous_stair_ascent__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `relation_path_exists:continuous_stair_ascent__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `relation_path_compatible:continuous_stair_ascent__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` | compatible |
| `relation_intention_in_path:continuous_stair_ascent__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `relation_role_match:continuous_stair_ascent__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` | complementary == complementary |
| `conditional_classified:continuous_stair_ascent__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `conditional_fail_closed:continuous_stair_ascent__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `relation_exercise_approved:countermovement_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_status_allowed:countermovement_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_path_exists:countermovement_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_path_compatible:countermovement_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` | compatible |
| `relation_intention_in_path:countermovement_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_role_match:countermovement_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:countermovement_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_exercise_approved:countermovement_jump__warmup__speed_power__ballistic_projection__rehearse_landing_or_reception` | `passed` |  |
| `relation_status_allowed:countermovement_jump__warmup__speed_power__ballistic_projection__rehearse_landing_or_reception` | `passed` |  |
| `relation_path_exists:countermovement_jump__warmup__speed_power__ballistic_projection__rehearse_landing_or_reception` | `passed` |  |
| `relation_path_compatible:countermovement_jump__warmup__speed_power__ballistic_projection__rehearse_landing_or_reception` | `passed` | compatible |
| `relation_intention_in_path:countermovement_jump__warmup__speed_power__ballistic_projection__rehearse_landing_or_reception` | `passed` |  |
| `relation_role_match:countermovement_jump__warmup__speed_power__ballistic_projection__rehearse_landing_or_reception` | `passed` | complementary == complementary |
| `conditional_classified:countermovement_jump__warmup__speed_power__ballistic_projection__rehearse_landing_or_reception` | `passed` |  |
| `conditional_fail_closed:countermovement_jump__warmup__speed_power__ballistic_projection__rehearse_landing_or_reception` | `passed` |  |
| `relation_exercise_approved:diaphragmatic_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` |  |
| `relation_status_allowed:diaphragmatic_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` |  |
| `relation_path_exists:diaphragmatic_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` |  |
| `relation_path_compatible:diaphragmatic_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` | compatible |
| `relation_intention_in_path:diaphragmatic_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` |  |
| `relation_role_match:diaphragmatic_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:diaphragmatic_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` |  |
| `conditional_fail_closed:diaphragmatic_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` |  |
| `relation_exercise_approved:diaphragmatic_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_status_allowed:diaphragmatic_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_path_exists:diaphragmatic_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_path_compatible:diaphragmatic_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` | compatible |
| `relation_intention_in_path:diaphragmatic_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_role_match:diaphragmatic_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` | alternative_primary == alternative_primary |
| `conditional_classified:diaphragmatic_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `conditional_fail_closed:diaphragmatic_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_exercise_approved:diaphragmatic_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_status_allowed:diaphragmatic_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_path_exists:diaphragmatic_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_path_compatible:diaphragmatic_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` | compatible |
| `relation_intention_in_path:diaphragmatic_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_role_match:diaphragmatic_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:diaphragmatic_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_exercise_approved:diaphragmatic_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `relation_status_allowed:diaphragmatic_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `relation_path_exists:diaphragmatic_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `relation_path_compatible:diaphragmatic_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` | compatible |
| `relation_intention_in_path:diaphragmatic_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `relation_role_match:diaphragmatic_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:diaphragmatic_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `conditional_fail_closed:diaphragmatic_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `relation_exercise_approved:diaphragmatic_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `relation_status_allowed:diaphragmatic_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `relation_path_exists:diaphragmatic_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `relation_path_compatible:diaphragmatic_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` | compatible |
| `relation_intention_in_path:diaphragmatic_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `relation_role_match:diaphragmatic_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:diaphragmatic_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `conditional_fail_closed:diaphragmatic_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `relation_exercise_approved:diaphragmatic_breathing__return_to_function__breathing_regulation__voluntary_breath_cycle_control__restore_voluntary_breath_control` | `passed` |  |
| `relation_status_allowed:diaphragmatic_breathing__return_to_function__breathing_regulation__voluntary_breath_cycle_control__restore_voluntary_breath_control` | `passed` |  |
| `relation_path_exists:diaphragmatic_breathing__return_to_function__breathing_regulation__voluntary_breath_cycle_control__restore_voluntary_breath_control` | `passed` |  |
| `relation_path_compatible:diaphragmatic_breathing__return_to_function__breathing_regulation__voluntary_breath_cycle_control__restore_voluntary_breath_control` | `passed` | compatible |
| `relation_intention_in_path:diaphragmatic_breathing__return_to_function__breathing_regulation__voluntary_breath_cycle_control__restore_voluntary_breath_control` | `passed` |  |
| `relation_role_match:diaphragmatic_breathing__return_to_function__breathing_regulation__voluntary_breath_cycle_control__restore_voluntary_breath_control` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:diaphragmatic_breathing__return_to_function__breathing_regulation__voluntary_breath_cycle_control__restore_voluntary_breath_control` | `passed` |  |
| `conditional_fail_closed:diaphragmatic_breathing__return_to_function__breathing_regulation__voluntary_breath_cycle_control__restore_voluntary_breath_control` | `passed` |  |
| `relation_exercise_approved:diaphragmatic_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_status_allowed:diaphragmatic_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_path_exists:diaphragmatic_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_path_compatible:diaphragmatic_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` | compatible |
| `relation_intention_in_path:diaphragmatic_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_role_match:diaphragmatic_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:diaphragmatic_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `conditional_fail_closed:diaphragmatic_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_exercise_approved:doorway_pectoral_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_status_allowed:doorway_pectoral_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_path_exists:doorway_pectoral_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_path_compatible:doorway_pectoral_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` | compatible |
| `relation_intention_in_path:doorway_pectoral_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_role_match:doorway_pectoral_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:doorway_pectoral_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_exercise_approved:doorway_pectoral_stretch__warmup__flexibility__assisted_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_status_allowed:doorway_pectoral_stretch__warmup__flexibility__assisted_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_path_exists:doorway_pectoral_stretch__warmup__flexibility__assisted_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_path_compatible:doorway_pectoral_stretch__warmup__flexibility__assisted_lengthening__prepare_required_joint_ranges` | `passed` | compatible |
| `relation_intention_in_path:doorway_pectoral_stretch__warmup__flexibility__assisted_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_role_match:doorway_pectoral_stretch__warmup__flexibility__assisted_lengthening__prepare_required_joint_ranges` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:doorway_pectoral_stretch__warmup__flexibility__assisted_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `conditional_fail_closed:doorway_pectoral_stretch__warmup__flexibility__assisted_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_exercise_approved:football_directional_first_touch__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` |  |
| `relation_status_allowed:football_directional_first_touch__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` |  |
| `relation_path_exists:football_directional_first_touch__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` |  |
| `relation_path_compatible:football_directional_first_touch__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` | compatible |
| `relation_intention_in_path:football_directional_first_touch__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` |  |
| `relation_role_match:football_directional_first_touch__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:football_directional_first_touch__main_training__technique_skill__contextual_technical_application__integrate_skill_in_task_context` | `passed` |  |
| `relation_exercise_approved:football_directional_first_touch__main_training__technique_skill__isolated_technical_practice__improve_technical_consistency` | `passed` |  |
| `relation_status_allowed:football_directional_first_touch__main_training__technique_skill__isolated_technical_practice__improve_technical_consistency` | `passed` |  |
| `relation_path_exists:football_directional_first_touch__main_training__technique_skill__isolated_technical_practice__improve_technical_consistency` | `passed` |  |
| `relation_path_compatible:football_directional_first_touch__main_training__technique_skill__isolated_technical_practice__improve_technical_consistency` | `passed` | compatible |
| `relation_intention_in_path:football_directional_first_touch__main_training__technique_skill__isolated_technical_practice__improve_technical_consistency` | `passed` |  |
| `relation_role_match:football_directional_first_touch__main_training__technique_skill__isolated_technical_practice__improve_technical_consistency` | `passed` | complementary == complementary |
| `compatible_ready:football_directional_first_touch__main_training__technique_skill__isolated_technical_practice__improve_technical_consistency` | `passed` |  |
| `relation_exercise_approved:football_directional_first_touch__warmup__technique_skill__contextual_technical_application__rehearse_familiar_skill` | `passed` |  |
| `relation_status_allowed:football_directional_first_touch__warmup__technique_skill__contextual_technical_application__rehearse_familiar_skill` | `passed` |  |
| `relation_path_exists:football_directional_first_touch__warmup__technique_skill__contextual_technical_application__rehearse_familiar_skill` | `passed` |  |
| `relation_path_compatible:football_directional_first_touch__warmup__technique_skill__contextual_technical_application__rehearse_familiar_skill` | `passed` | compatible |
| `relation_intention_in_path:football_directional_first_touch__warmup__technique_skill__contextual_technical_application__rehearse_familiar_skill` | `passed` |  |
| `relation_role_match:football_directional_first_touch__warmup__technique_skill__contextual_technical_application__rehearse_familiar_skill` | `passed` | complementary == complementary |
| `conditional_classified:football_directional_first_touch__warmup__technique_skill__contextual_technical_application__rehearse_familiar_skill` | `passed` |  |
| `conditional_fail_closed:football_directional_first_touch__warmup__technique_skill__contextual_technical_application__rehearse_familiar_skill` | `passed` |  |
| `relation_exercise_approved:front_to_back_leg_swing__activation__flexibility__dynamic_lengthening__prime_dynamic_end_range_control` | `passed` |  |
| `relation_status_allowed:front_to_back_leg_swing__activation__flexibility__dynamic_lengthening__prime_dynamic_end_range_control` | `passed` |  |
| `relation_path_exists:front_to_back_leg_swing__activation__flexibility__dynamic_lengthening__prime_dynamic_end_range_control` | `passed` |  |
| `relation_path_compatible:front_to_back_leg_swing__activation__flexibility__dynamic_lengthening__prime_dynamic_end_range_control` | `passed` | compatible |
| `relation_intention_in_path:front_to_back_leg_swing__activation__flexibility__dynamic_lengthening__prime_dynamic_end_range_control` | `passed` |  |
| `relation_role_match:front_to_back_leg_swing__activation__flexibility__dynamic_lengthening__prime_dynamic_end_range_control` | `passed` | complementary == complementary |
| `conditional_classified:front_to_back_leg_swing__activation__flexibility__dynamic_lengthening__prime_dynamic_end_range_control` | `passed` |  |
| `conditional_fail_closed:front_to_back_leg_swing__activation__flexibility__dynamic_lengthening__prime_dynamic_end_range_control` | `passed` |  |
| `relation_exercise_approved:front_to_back_leg_swing__main_training__flexibility__dynamic_lengthening__increase_dynamic_range_of_motion` | `passed` |  |
| `relation_status_allowed:front_to_back_leg_swing__main_training__flexibility__dynamic_lengthening__increase_dynamic_range_of_motion` | `passed` |  |
| `relation_path_exists:front_to_back_leg_swing__main_training__flexibility__dynamic_lengthening__increase_dynamic_range_of_motion` | `passed` |  |
| `relation_path_compatible:front_to_back_leg_swing__main_training__flexibility__dynamic_lengthening__increase_dynamic_range_of_motion` | `passed` | compatible |
| `relation_intention_in_path:front_to_back_leg_swing__main_training__flexibility__dynamic_lengthening__increase_dynamic_range_of_motion` | `passed` |  |
| `relation_role_match:front_to_back_leg_swing__main_training__flexibility__dynamic_lengthening__increase_dynamic_range_of_motion` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:front_to_back_leg_swing__main_training__flexibility__dynamic_lengthening__increase_dynamic_range_of_motion` | `passed` |  |
| `relation_exercise_approved:front_to_back_leg_swing__warmup__flexibility__dynamic_lengthening__rehearse_range_specific_movement` | `passed` |  |
| `relation_status_allowed:front_to_back_leg_swing__warmup__flexibility__dynamic_lengthening__rehearse_range_specific_movement` | `passed` |  |
| `relation_path_exists:front_to_back_leg_swing__warmup__flexibility__dynamic_lengthening__rehearse_range_specific_movement` | `passed` |  |
| `relation_path_compatible:front_to_back_leg_swing__warmup__flexibility__dynamic_lengthening__rehearse_range_specific_movement` | `passed` | compatible |
| `relation_intention_in_path:front_to_back_leg_swing__warmup__flexibility__dynamic_lengthening__rehearse_range_specific_movement` | `passed` |  |
| `relation_role_match:front_to_back_leg_swing__warmup__flexibility__dynamic_lengthening__rehearse_range_specific_movement` | `passed` | complementary == complementary |
| `compatible_ready:front_to_back_leg_swing__warmup__flexibility__dynamic_lengthening__rehearse_range_specific_movement` | `passed` |  |
| `relation_exercise_approved:full_body_elliptical__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_status_allowed:full_body_elliptical__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_exists:full_body_elliptical__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_compatible:full_body_elliptical__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` | compatible |
| `relation_intention_in_path:full_body_elliptical__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_role_match:full_body_elliptical__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:full_body_elliptical__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_exercise_approved:full_body_elliptical__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_status_allowed:full_body_elliptical__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_path_exists:full_body_elliptical__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_path_compatible:full_body_elliptical__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` | compatible |
| `relation_intention_in_path:full_body_elliptical__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_role_match:full_body_elliptical__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:full_body_elliptical__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_exercise_approved:full_body_elliptical__warmup__cardio_conditioning__repetitive_rhythmic_movement__raise_whole_body_temperature` | `passed` |  |
| `relation_status_allowed:full_body_elliptical__warmup__cardio_conditioning__repetitive_rhythmic_movement__raise_whole_body_temperature` | `passed` |  |
| `relation_path_exists:full_body_elliptical__warmup__cardio_conditioning__repetitive_rhythmic_movement__raise_whole_body_temperature` | `passed` |  |
| `relation_path_compatible:full_body_elliptical__warmup__cardio_conditioning__repetitive_rhythmic_movement__raise_whole_body_temperature` | `passed` | compatible |
| `relation_intention_in_path:full_body_elliptical__warmup__cardio_conditioning__repetitive_rhythmic_movement__raise_whole_body_temperature` | `passed` |  |
| `relation_role_match:full_body_elliptical__warmup__cardio_conditioning__repetitive_rhythmic_movement__raise_whole_body_temperature` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:full_body_elliptical__warmup__cardio_conditioning__repetitive_rhythmic_movement__raise_whole_body_temperature` | `passed` |  |
| `conditional_fail_closed:full_body_elliptical__warmup__cardio_conditioning__repetitive_rhythmic_movement__raise_whole_body_temperature` | `passed` |  |
| `relation_exercise_approved:half_kneeling_ankle_dorsiflexion_rock__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` |  |
| `relation_status_allowed:half_kneeling_ankle_dorsiflexion_rock__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` |  |
| `relation_path_exists:half_kneeling_ankle_dorsiflexion_rock__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` |  |
| `relation_path_compatible:half_kneeling_ankle_dorsiflexion_rock__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` | compatible |
| `relation_intention_in_path:half_kneeling_ankle_dorsiflexion_rock__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` |  |
| `relation_role_match:half_kneeling_ankle_dorsiflexion_rock__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:half_kneeling_ankle_dorsiflexion_rock__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` |  |
| `relation_exercise_approved:half_kneeling_ankle_dorsiflexion_rock__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` |  |
| `relation_status_allowed:half_kneeling_ankle_dorsiflexion_rock__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` |  |
| `relation_path_exists:half_kneeling_ankle_dorsiflexion_rock__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` |  |
| `relation_path_compatible:half_kneeling_ankle_dorsiflexion_rock__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` | compatible |
| `relation_intention_in_path:half_kneeling_ankle_dorsiflexion_rock__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` |  |
| `relation_role_match:half_kneeling_ankle_dorsiflexion_rock__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:half_kneeling_ankle_dorsiflexion_rock__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` |  |
| `relation_exercise_approved:half_kneeling_ankle_dorsiflexion_rock__warmup__mobility__range_transition__rehearse_session_specific_position_changes` | `passed` |  |
| `relation_status_allowed:half_kneeling_ankle_dorsiflexion_rock__warmup__mobility__range_transition__rehearse_session_specific_position_changes` | `passed` |  |
| `relation_path_exists:half_kneeling_ankle_dorsiflexion_rock__warmup__mobility__range_transition__rehearse_session_specific_position_changes` | `passed` |  |
| `relation_path_compatible:half_kneeling_ankle_dorsiflexion_rock__warmup__mobility__range_transition__rehearse_session_specific_position_changes` | `passed` | compatible |
| `relation_intention_in_path:half_kneeling_ankle_dorsiflexion_rock__warmup__mobility__range_transition__rehearse_session_specific_position_changes` | `passed` |  |
| `relation_role_match:half_kneeling_ankle_dorsiflexion_rock__warmup__mobility__range_transition__rehearse_session_specific_position_changes` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:half_kneeling_ankle_dorsiflexion_rock__warmup__mobility__range_transition__rehearse_session_specific_position_changes` | `passed` |  |
| `relation_exercise_approved:lateral_costal_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_status_allowed:lateral_costal_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_path_exists:lateral_costal_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_path_compatible:lateral_costal_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` | compatible |
| `relation_intention_in_path:lateral_costal_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_role_match:lateral_costal_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` | alternative_primary == alternative_primary |
| `conditional_classified:lateral_costal_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `conditional_fail_closed:lateral_costal_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_exercise_approved:lateral_costal_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_status_allowed:lateral_costal_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_path_exists:lateral_costal_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_path_compatible:lateral_costal_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` | compatible |
| `relation_intention_in_path:lateral_costal_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_role_match:lateral_costal_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:lateral_costal_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_exercise_approved:lateral_costal_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_status_allowed:lateral_costal_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_path_exists:lateral_costal_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_path_compatible:lateral_costal_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` | compatible |
| `relation_intention_in_path:lateral_costal_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_role_match:lateral_costal_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:lateral_costal_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `conditional_fail_closed:lateral_costal_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_exercise_approved:lateral_leg_swing__main_training__flexibility__dynamic_lengthening__increase_repeated_lengthening_tolerance` | `passed` |  |
| `relation_status_allowed:lateral_leg_swing__main_training__flexibility__dynamic_lengthening__increase_repeated_lengthening_tolerance` | `passed` |  |
| `relation_path_exists:lateral_leg_swing__main_training__flexibility__dynamic_lengthening__increase_repeated_lengthening_tolerance` | `passed` |  |
| `relation_path_compatible:lateral_leg_swing__main_training__flexibility__dynamic_lengthening__increase_repeated_lengthening_tolerance` | `passed` | compatible |
| `relation_intention_in_path:lateral_leg_swing__main_training__flexibility__dynamic_lengthening__increase_repeated_lengthening_tolerance` | `passed` |  |
| `relation_role_match:lateral_leg_swing__main_training__flexibility__dynamic_lengthening__increase_repeated_lengthening_tolerance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:lateral_leg_swing__main_training__flexibility__dynamic_lengthening__increase_repeated_lengthening_tolerance` | `passed` |  |
| `relation_exercise_approved:lateral_leg_swing__prevention__flexibility__dynamic_lengthening__maintain_functional_dynamic_range` | `passed` |  |
| `relation_status_allowed:lateral_leg_swing__prevention__flexibility__dynamic_lengthening__maintain_functional_dynamic_range` | `passed` |  |
| `relation_path_exists:lateral_leg_swing__prevention__flexibility__dynamic_lengthening__maintain_functional_dynamic_range` | `passed` |  |
| `relation_path_compatible:lateral_leg_swing__prevention__flexibility__dynamic_lengthening__maintain_functional_dynamic_range` | `passed` | compatible |
| `relation_intention_in_path:lateral_leg_swing__prevention__flexibility__dynamic_lengthening__maintain_functional_dynamic_range` | `passed` |  |
| `relation_role_match:lateral_leg_swing__prevention__flexibility__dynamic_lengthening__maintain_functional_dynamic_range` | `passed` | alternative_primary == alternative_primary |
| `conditional_classified:lateral_leg_swing__prevention__flexibility__dynamic_lengthening__maintain_functional_dynamic_range` | `passed` |  |
| `conditional_fail_closed:lateral_leg_swing__prevention__flexibility__dynamic_lengthening__maintain_functional_dynamic_range` | `passed` |  |
| `relation_exercise_approved:lateral_leg_swing__warmup__flexibility__dynamic_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_status_allowed:lateral_leg_swing__warmup__flexibility__dynamic_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_path_exists:lateral_leg_swing__warmup__flexibility__dynamic_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_path_compatible:lateral_leg_swing__warmup__flexibility__dynamic_lengthening__prepare_required_joint_ranges` | `passed` | compatible |
| `relation_intention_in_path:lateral_leg_swing__warmup__flexibility__dynamic_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_role_match:lateral_leg_swing__warmup__flexibility__dynamic_lengthening__prepare_required_joint_ranges` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:lateral_leg_swing__warmup__flexibility__dynamic_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_exercise_approved:linear_sprint__main_training__speed_power__cyclic_locomotion__increase_maximal_locomotor_speed` | `passed` |  |
| `relation_status_allowed:linear_sprint__main_training__speed_power__cyclic_locomotion__increase_maximal_locomotor_speed` | `passed` |  |
| `relation_path_exists:linear_sprint__main_training__speed_power__cyclic_locomotion__increase_maximal_locomotor_speed` | `passed` |  |
| `relation_path_compatible:linear_sprint__main_training__speed_power__cyclic_locomotion__increase_maximal_locomotor_speed` | `passed` | compatible |
| `relation_intention_in_path:linear_sprint__main_training__speed_power__cyclic_locomotion__increase_maximal_locomotor_speed` | `passed` |  |
| `relation_role_match:linear_sprint__main_training__speed_power__cyclic_locomotion__increase_maximal_locomotor_speed` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:linear_sprint__main_training__speed_power__cyclic_locomotion__increase_maximal_locomotor_speed` | `passed` |  |
| `relation_exercise_approved:linear_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` |  |
| `relation_status_allowed:linear_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` |  |
| `relation_path_exists:linear_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` |  |
| `relation_path_compatible:linear_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` | compatible |
| `relation_intention_in_path:linear_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` |  |
| `relation_role_match:linear_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:linear_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` |  |
| `relation_exercise_approved:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_status_allowed:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_path_exists:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_path_compatible:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` | compatible |
| `relation_intention_in_path:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_role_match:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_exercise_approved:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_status_allowed:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_exists:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_compatible:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` | compatible |
| `relation_intention_in_path:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_role_match:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_exercise_approved:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_status_allowed:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_path_exists:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_path_compatible:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` | compatible |
| `relation_intention_in_path:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_role_match:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:manual_wheelchair_propulsion_overground__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_exercise_approved:march_in_place_to_external_beat__activation__motor_control_coordination__rhythm_synchronization__prime_external_cue_synchronization` | `passed` |  |
| `relation_status_allowed:march_in_place_to_external_beat__activation__motor_control_coordination__rhythm_synchronization__prime_external_cue_synchronization` | `passed` |  |
| `relation_path_exists:march_in_place_to_external_beat__activation__motor_control_coordination__rhythm_synchronization__prime_external_cue_synchronization` | `passed` |  |
| `relation_path_compatible:march_in_place_to_external_beat__activation__motor_control_coordination__rhythm_synchronization__prime_external_cue_synchronization` | `passed` | compatible |
| `relation_intention_in_path:march_in_place_to_external_beat__activation__motor_control_coordination__rhythm_synchronization__prime_external_cue_synchronization` | `passed` |  |
| `relation_role_match:march_in_place_to_external_beat__activation__motor_control_coordination__rhythm_synchronization__prime_external_cue_synchronization` | `passed` | complementary == complementary |
| `conditional_classified:march_in_place_to_external_beat__activation__motor_control_coordination__rhythm_synchronization__prime_external_cue_synchronization` | `passed` |  |
| `conditional_fail_closed:march_in_place_to_external_beat__activation__motor_control_coordination__rhythm_synchronization__prime_external_cue_synchronization` | `passed` |  |
| `relation_exercise_approved:march_in_place_to_external_beat__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_status_allowed:march_in_place_to_external_beat__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_path_exists:march_in_place_to_external_beat__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_path_compatible:march_in_place_to_external_beat__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` | compatible |
| `relation_intention_in_path:march_in_place_to_external_beat__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_role_match:march_in_place_to_external_beat__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` | alternative_primary == alternative_primary |
| `conditional_classified:march_in_place_to_external_beat__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `conditional_fail_closed:march_in_place_to_external_beat__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_exercise_approved:march_in_place_to_external_beat__main_training__motor_control_coordination__rhythm_synchronization__synchronize_with_external_rhythm` | `passed` |  |
| `relation_status_allowed:march_in_place_to_external_beat__main_training__motor_control_coordination__rhythm_synchronization__synchronize_with_external_rhythm` | `passed` |  |
| `relation_path_exists:march_in_place_to_external_beat__main_training__motor_control_coordination__rhythm_synchronization__synchronize_with_external_rhythm` | `passed` |  |
| `relation_path_compatible:march_in_place_to_external_beat__main_training__motor_control_coordination__rhythm_synchronization__synchronize_with_external_rhythm` | `passed` | compatible |
| `relation_intention_in_path:march_in_place_to_external_beat__main_training__motor_control_coordination__rhythm_synchronization__synchronize_with_external_rhythm` | `passed` |  |
| `relation_role_match:march_in_place_to_external_beat__main_training__motor_control_coordination__rhythm_synchronization__synchronize_with_external_rhythm` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:march_in_place_to_external_beat__main_training__motor_control_coordination__rhythm_synchronization__synchronize_with_external_rhythm` | `passed` |  |
| `relation_exercise_approved:march_in_place_to_external_beat__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `relation_status_allowed:march_in_place_to_external_beat__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `relation_path_exists:march_in_place_to_external_beat__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `relation_path_compatible:march_in_place_to_external_beat__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` | compatible |
| `relation_intention_in_path:march_in_place_to_external_beat__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `relation_role_match:march_in_place_to_external_beat__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` | complementary == complementary |
| `conditional_classified:march_in_place_to_external_beat__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `conditional_fail_closed:march_in_place_to_external_beat__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `relation_exercise_approved:march_in_place_to_external_beat__warmup__motor_control_coordination__rhythm_synchronization__rehearse_external_rhythm` | `passed` |  |
| `relation_status_allowed:march_in_place_to_external_beat__warmup__motor_control_coordination__rhythm_synchronization__rehearse_external_rhythm` | `passed` |  |
| `relation_path_exists:march_in_place_to_external_beat__warmup__motor_control_coordination__rhythm_synchronization__rehearse_external_rhythm` | `passed` |  |
| `relation_path_compatible:march_in_place_to_external_beat__warmup__motor_control_coordination__rhythm_synchronization__rehearse_external_rhythm` | `passed` | compatible |
| `relation_intention_in_path:march_in_place_to_external_beat__warmup__motor_control_coordination__rhythm_synchronization__rehearse_external_rhythm` | `passed` |  |
| `relation_role_match:march_in_place_to_external_beat__warmup__motor_control_coordination__rhythm_synchronization__rehearse_external_rhythm` | `passed` | complementary == complementary |
| `conditional_classified:march_in_place_to_external_beat__warmup__motor_control_coordination__rhythm_synchronization__rehearse_external_rhythm` | `passed` |  |
| `conditional_fail_closed:march_in_place_to_external_beat__warmup__motor_control_coordination__rhythm_synchronization__rehearse_external_rhythm` | `passed` |  |
| `relation_exercise_approved:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__develop_aerobic_endurance` | `passed` |  |
| `relation_status_allowed:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__develop_aerobic_endurance` | `passed` |  |
| `relation_path_exists:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__develop_aerobic_endurance` | `passed` |  |
| `relation_path_compatible:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__develop_aerobic_endurance` | `passed` | compatible |
| `relation_intention_in_path:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__develop_aerobic_endurance` | `passed` |  |
| `relation_role_match:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__develop_aerobic_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__develop_aerobic_endurance` | `passed` |  |
| `relation_exercise_approved:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_status_allowed:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_path_exists:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_path_compatible:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` | compatible |
| `relation_intention_in_path:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_role_match:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:marching_in_place__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_exercise_approved:marching_in_place__recovery__cardio_conditioning__repetitive_rhythmic_movement__resume_gentle_rhythmic_movement_after_effort` | `passed` |  |
| `relation_status_allowed:marching_in_place__recovery__cardio_conditioning__repetitive_rhythmic_movement__resume_gentle_rhythmic_movement_after_effort` | `passed` |  |
| `relation_path_exists:marching_in_place__recovery__cardio_conditioning__repetitive_rhythmic_movement__resume_gentle_rhythmic_movement_after_effort` | `passed` |  |
| `relation_path_compatible:marching_in_place__recovery__cardio_conditioning__repetitive_rhythmic_movement__resume_gentle_rhythmic_movement_after_effort` | `passed` | compatible |
| `relation_intention_in_path:marching_in_place__recovery__cardio_conditioning__repetitive_rhythmic_movement__resume_gentle_rhythmic_movement_after_effort` | `passed` |  |
| `relation_role_match:marching_in_place__recovery__cardio_conditioning__repetitive_rhythmic_movement__resume_gentle_rhythmic_movement_after_effort` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:marching_in_place__recovery__cardio_conditioning__repetitive_rhythmic_movement__resume_gentle_rhythmic_movement_after_effort` | `passed` |  |
| `conditional_fail_closed:marching_in_place__recovery__cardio_conditioning__repetitive_rhythmic_movement__resume_gentle_rhythmic_movement_after_effort` | `passed` |  |
| `relation_exercise_approved:marching_in_place__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `relation_status_allowed:marching_in_place__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `relation_path_exists:marching_in_place__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `relation_path_compatible:marching_in_place__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` | compatible |
| `relation_intention_in_path:marching_in_place__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `relation_role_match:marching_in_place__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` | complementary == complementary |
| `conditional_classified:marching_in_place__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `conditional_fail_closed:marching_in_place__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `passed` |  |
| `relation_exercise_approved:overground_running__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_status_allowed:overground_running__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_exists:overground_running__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_compatible:overground_running__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` | compatible |
| `relation_intention_in_path:overground_running__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_role_match:overground_running__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:overground_running__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_exercise_approved:overground_running__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_status_allowed:overground_running__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_path_exists:overground_running__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_path_compatible:overground_running__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` | compatible |
| `relation_intention_in_path:overground_running__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_role_match:overground_running__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:overground_running__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_exercise_approved:overground_running__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_status_allowed:overground_running__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_path_exists:overground_running__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_path_compatible:overground_running__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` | compatible |
| `relation_intention_in_path:overground_running__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_role_match:overground_running__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` | complementary == complementary |
| `conditional_classified:overground_running__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `conditional_fail_closed:overground_running__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_exercise_approved:overground_walking__cooldown__cardio_conditioning__cyclic_locomotion__facilitate_transition_to_rest` | `passed` |  |
| `relation_status_allowed:overground_walking__cooldown__cardio_conditioning__cyclic_locomotion__facilitate_transition_to_rest` | `passed` |  |
| `relation_path_exists:overground_walking__cooldown__cardio_conditioning__cyclic_locomotion__facilitate_transition_to_rest` | `passed` |  |
| `relation_path_compatible:overground_walking__cooldown__cardio_conditioning__cyclic_locomotion__facilitate_transition_to_rest` | `passed` | compatible |
| `relation_intention_in_path:overground_walking__cooldown__cardio_conditioning__cyclic_locomotion__facilitate_transition_to_rest` | `passed` |  |
| `relation_role_match:overground_walking__cooldown__cardio_conditioning__cyclic_locomotion__facilitate_transition_to_rest` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:overground_walking__cooldown__cardio_conditioning__cyclic_locomotion__facilitate_transition_to_rest` | `passed` |  |
| `conditional_fail_closed:overground_walking__cooldown__cardio_conditioning__cyclic_locomotion__facilitate_transition_to_rest` | `passed` |  |
| `relation_exercise_approved:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_status_allowed:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_exists:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_compatible:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` | compatible |
| `relation_intention_in_path:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_role_match:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_exercise_approved:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_status_allowed:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_path_exists:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_path_compatible:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` | compatible |
| `relation_intention_in_path:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_role_match:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:overground_walking__main_training__cardio_conditioning__cyclic_locomotion__improve_locomotor_economy` | `passed` |  |
| `relation_exercise_approved:overground_walking__recovery__cardio_conditioning__cyclic_locomotion__resume_comfortable_locomotion_after_effort` | `passed` |  |
| `relation_status_allowed:overground_walking__recovery__cardio_conditioning__cyclic_locomotion__resume_comfortable_locomotion_after_effort` | `passed` |  |
| `relation_path_exists:overground_walking__recovery__cardio_conditioning__cyclic_locomotion__resume_comfortable_locomotion_after_effort` | `passed` |  |
| `relation_path_compatible:overground_walking__recovery__cardio_conditioning__cyclic_locomotion__resume_comfortable_locomotion_after_effort` | `passed` | compatible |
| `relation_intention_in_path:overground_walking__recovery__cardio_conditioning__cyclic_locomotion__resume_comfortable_locomotion_after_effort` | `passed` |  |
| `relation_role_match:overground_walking__recovery__cardio_conditioning__cyclic_locomotion__resume_comfortable_locomotion_after_effort` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:overground_walking__recovery__cardio_conditioning__cyclic_locomotion__resume_comfortable_locomotion_after_effort` | `passed` |  |
| `conditional_fail_closed:overground_walking__recovery__cardio_conditioning__cyclic_locomotion__resume_comfortable_locomotion_after_effort` | `passed` |  |
| `relation_exercise_approved:overground_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_status_allowed:overground_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_path_exists:overground_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_path_compatible:overground_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` | compatible |
| `relation_intention_in_path:overground_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_role_match:overground_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` | complementary == complementary |
| `conditional_classified:overground_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `conditional_fail_closed:overground_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_exercise_approved:paced_breathing__activation__breathing_regulation__voluntary_breath_cycle_control__prime_respiratory_control` | `passed` |  |
| `relation_status_allowed:paced_breathing__activation__breathing_regulation__voluntary_breath_cycle_control__prime_respiratory_control` | `passed` |  |
| `relation_path_exists:paced_breathing__activation__breathing_regulation__voluntary_breath_cycle_control__prime_respiratory_control` | `passed` |  |
| `relation_path_compatible:paced_breathing__activation__breathing_regulation__voluntary_breath_cycle_control__prime_respiratory_control` | `passed` | compatible |
| `relation_intention_in_path:paced_breathing__activation__breathing_regulation__voluntary_breath_cycle_control__prime_respiratory_control` | `passed` |  |
| `relation_role_match:paced_breathing__activation__breathing_regulation__voluntary_breath_cycle_control__prime_respiratory_control` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:paced_breathing__activation__breathing_regulation__voluntary_breath_cycle_control__prime_respiratory_control` | `passed` |  |
| `conditional_fail_closed:paced_breathing__activation__breathing_regulation__voluntary_breath_cycle_control__prime_respiratory_control` | `passed` |  |
| `relation_exercise_approved:paced_breathing__cooldown__breathing_regulation__autonomic_modulation__transition_arousal_toward_rest` | `passed` |  |
| `relation_status_allowed:paced_breathing__cooldown__breathing_regulation__autonomic_modulation__transition_arousal_toward_rest` | `passed` |  |
| `relation_path_exists:paced_breathing__cooldown__breathing_regulation__autonomic_modulation__transition_arousal_toward_rest` | `passed` |  |
| `relation_path_compatible:paced_breathing__cooldown__breathing_regulation__autonomic_modulation__transition_arousal_toward_rest` | `passed` | compatible |
| `relation_intention_in_path:paced_breathing__cooldown__breathing_regulation__autonomic_modulation__transition_arousal_toward_rest` | `passed` |  |
| `relation_role_match:paced_breathing__cooldown__breathing_regulation__autonomic_modulation__transition_arousal_toward_rest` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:paced_breathing__cooldown__breathing_regulation__autonomic_modulation__transition_arousal_toward_rest` | `passed` |  |
| `conditional_fail_closed:paced_breathing__cooldown__breathing_regulation__autonomic_modulation__transition_arousal_toward_rest` | `passed` |  |
| `relation_exercise_approved:paced_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` |  |
| `relation_status_allowed:paced_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` |  |
| `relation_path_exists:paced_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` |  |
| `relation_path_compatible:paced_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` | compatible |
| `relation_intention_in_path:paced_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` |  |
| `relation_role_match:paced_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:paced_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `passed` |  |
| `relation_exercise_approved:paced_breathing__main_training__breathing_regulation__autonomic_modulation__improve_arousal_self_regulation` | `passed` |  |
| `relation_status_allowed:paced_breathing__main_training__breathing_regulation__autonomic_modulation__improve_arousal_self_regulation` | `passed` |  |
| `relation_path_exists:paced_breathing__main_training__breathing_regulation__autonomic_modulation__improve_arousal_self_regulation` | `passed` |  |
| `relation_path_compatible:paced_breathing__main_training__breathing_regulation__autonomic_modulation__improve_arousal_self_regulation` | `passed` | compatible |
| `relation_intention_in_path:paced_breathing__main_training__breathing_regulation__autonomic_modulation__improve_arousal_self_regulation` | `passed` |  |
| `relation_role_match:paced_breathing__main_training__breathing_regulation__autonomic_modulation__improve_arousal_self_regulation` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:paced_breathing__main_training__breathing_regulation__autonomic_modulation__improve_arousal_self_regulation` | `passed` |  |
| `conditional_fail_closed:paced_breathing__main_training__breathing_regulation__autonomic_modulation__improve_arousal_self_regulation` | `passed` |  |
| `relation_exercise_approved:paced_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_status_allowed:paced_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_path_exists:paced_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_path_compatible:paced_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` | compatible |
| `relation_intention_in_path:paced_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_role_match:paced_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:paced_breathing__main_training__breathing_regulation__voluntary_breath_cycle_control__improve_voluntary_breath_control` | `passed` |  |
| `relation_exercise_approved:paced_breathing__prevention__breathing_regulation__autonomic_modulation__build_state_regulation_capacity` | `passed` |  |
| `relation_status_allowed:paced_breathing__prevention__breathing_regulation__autonomic_modulation__build_state_regulation_capacity` | `passed` |  |
| `relation_path_exists:paced_breathing__prevention__breathing_regulation__autonomic_modulation__build_state_regulation_capacity` | `passed` |  |
| `relation_path_compatible:paced_breathing__prevention__breathing_regulation__autonomic_modulation__build_state_regulation_capacity` | `passed` | compatible |
| `relation_intention_in_path:paced_breathing__prevention__breathing_regulation__autonomic_modulation__build_state_regulation_capacity` | `passed` |  |
| `relation_role_match:paced_breathing__prevention__breathing_regulation__autonomic_modulation__build_state_regulation_capacity` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:paced_breathing__prevention__breathing_regulation__autonomic_modulation__build_state_regulation_capacity` | `passed` |  |
| `conditional_fail_closed:paced_breathing__prevention__breathing_regulation__autonomic_modulation__build_state_regulation_capacity` | `passed` |  |
| `relation_exercise_approved:paced_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `relation_status_allowed:paced_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `relation_path_exists:paced_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `relation_path_compatible:paced_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` | compatible |
| `relation_intention_in_path:paced_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `relation_role_match:paced_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:paced_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `conditional_fail_closed:paced_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `passed` |  |
| `relation_exercise_approved:paced_breathing__recovery__breathing_regulation__autonomic_modulation__support_post_effort_downregulation` | `passed` |  |
| `relation_status_allowed:paced_breathing__recovery__breathing_regulation__autonomic_modulation__support_post_effort_downregulation` | `passed` |  |
| `relation_path_exists:paced_breathing__recovery__breathing_regulation__autonomic_modulation__support_post_effort_downregulation` | `passed` |  |
| `relation_path_compatible:paced_breathing__recovery__breathing_regulation__autonomic_modulation__support_post_effort_downregulation` | `passed` | compatible |
| `relation_intention_in_path:paced_breathing__recovery__breathing_regulation__autonomic_modulation__support_post_effort_downregulation` | `passed` |  |
| `relation_role_match:paced_breathing__recovery__breathing_regulation__autonomic_modulation__support_post_effort_downregulation` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:paced_breathing__recovery__breathing_regulation__autonomic_modulation__support_post_effort_downregulation` | `passed` |  |
| `conditional_fail_closed:paced_breathing__recovery__breathing_regulation__autonomic_modulation__support_post_effort_downregulation` | `passed` |  |
| `relation_exercise_approved:paced_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `relation_status_allowed:paced_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `relation_path_exists:paced_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `relation_path_compatible:paced_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` | compatible |
| `relation_intention_in_path:paced_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `relation_role_match:paced_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:paced_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `conditional_fail_closed:paced_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `passed` |  |
| `relation_exercise_approved:paced_breathing__warmup__breathing_regulation__autonomic_modulation__establish_suitable_preparation_state` | `passed` |  |
| `relation_status_allowed:paced_breathing__warmup__breathing_regulation__autonomic_modulation__establish_suitable_preparation_state` | `passed` |  |
| `relation_path_exists:paced_breathing__warmup__breathing_regulation__autonomic_modulation__establish_suitable_preparation_state` | `passed` |  |
| `relation_path_compatible:paced_breathing__warmup__breathing_regulation__autonomic_modulation__establish_suitable_preparation_state` | `passed` | compatible |
| `relation_intention_in_path:paced_breathing__warmup__breathing_regulation__autonomic_modulation__establish_suitable_preparation_state` | `passed` |  |
| `relation_role_match:paced_breathing__warmup__breathing_regulation__autonomic_modulation__establish_suitable_preparation_state` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:paced_breathing__warmup__breathing_regulation__autonomic_modulation__establish_suitable_preparation_state` | `passed` |  |
| `conditional_fail_closed:paced_breathing__warmup__breathing_regulation__autonomic_modulation__establish_suitable_preparation_state` | `passed` |  |
| `relation_exercise_approved:paced_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_status_allowed:paced_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_path_exists:paced_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_path_compatible:paced_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` | compatible |
| `relation_intention_in_path:paced_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_role_match:paced_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:paced_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `conditional_fail_closed:paced_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `passed` |  |
| `relation_exercise_approved:plyometric_push_up__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_status_allowed:plyometric_push_up__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_path_exists:plyometric_push_up__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_path_compatible:plyometric_push_up__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` | compatible |
| `relation_intention_in_path:plyometric_push_up__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_role_match:plyometric_push_up__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:plyometric_push_up__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_exercise_approved:plyometric_push_up__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` |  |
| `relation_status_allowed:plyometric_push_up__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` |  |
| `relation_path_exists:plyometric_push_up__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` |  |
| `relation_path_compatible:plyometric_push_up__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` | compatible |
| `relation_intention_in_path:plyometric_push_up__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` |  |
| `relation_role_match:plyometric_push_up__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:plyometric_push_up__main_training__speed_power__elastic_reactive_action__increase_reactive_strength` | `passed` |  |
| `relation_exercise_approved:respiratory_sensation_observation__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_status_allowed:respiratory_sensation_observation__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_path_exists:respiratory_sensation_observation__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_path_compatible:respiratory_sensation_observation__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` | compatible |
| `relation_intention_in_path:respiratory_sensation_observation__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_role_match:respiratory_sensation_observation__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:respiratory_sensation_observation__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `passed` |  |
| `relation_exercise_approved:seated_butterfly_adductor_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `relation_status_allowed:seated_butterfly_adductor_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `relation_path_exists:seated_butterfly_adductor_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `relation_path_compatible:seated_butterfly_adductor_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` | compatible |
| `relation_intention_in_path:seated_butterfly_adductor_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `relation_role_match:seated_butterfly_adductor_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:seated_butterfly_adductor_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `conditional_fail_closed:seated_butterfly_adductor_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `relation_exercise_approved:seated_butterfly_adductor_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` |  |
| `relation_status_allowed:seated_butterfly_adductor_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` |  |
| `relation_path_exists:seated_butterfly_adductor_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` |  |
| `relation_path_compatible:seated_butterfly_adductor_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` | compatible |
| `relation_intention_in_path:seated_butterfly_adductor_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` |  |
| `relation_role_match:seated_butterfly_adductor_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:seated_butterfly_adductor_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` |  |
| `relation_exercise_approved:seated_single_leg_hamstring_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `relation_status_allowed:seated_single_leg_hamstring_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `relation_path_exists:seated_single_leg_hamstring_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `relation_path_compatible:seated_single_leg_hamstring_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` | compatible |
| `relation_intention_in_path:seated_single_leg_hamstring_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `relation_role_match:seated_single_leg_hamstring_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:seated_single_leg_hamstring_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `conditional_fail_closed:seated_single_leg_hamstring_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `passed` |  |
| `relation_exercise_approved:seated_single_leg_hamstring_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_status_allowed:seated_single_leg_hamstring_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_path_exists:seated_single_leg_hamstring_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_path_compatible:seated_single_leg_hamstring_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` | compatible |
| `relation_intention_in_path:seated_single_leg_hamstring_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_role_match:seated_single_leg_hamstring_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:seated_single_leg_hamstring_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_exercise_approved:seated_supported_thoracic_extension__cooldown__mobility__supported_loaded_mobility__return_to_comfortable_supported_range` | `passed` |  |
| `relation_status_allowed:seated_supported_thoracic_extension__cooldown__mobility__supported_loaded_mobility__return_to_comfortable_supported_range` | `passed` |  |
| `relation_path_exists:seated_supported_thoracic_extension__cooldown__mobility__supported_loaded_mobility__return_to_comfortable_supported_range` | `passed` |  |
| `relation_path_compatible:seated_supported_thoracic_extension__cooldown__mobility__supported_loaded_mobility__return_to_comfortable_supported_range` | `passed` | compatible |
| `relation_intention_in_path:seated_supported_thoracic_extension__cooldown__mobility__supported_loaded_mobility__return_to_comfortable_supported_range` | `passed` |  |
| `relation_role_match:seated_supported_thoracic_extension__cooldown__mobility__supported_loaded_mobility__return_to_comfortable_supported_range` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:seated_supported_thoracic_extension__cooldown__mobility__supported_loaded_mobility__return_to_comfortable_supported_range` | `passed` |  |
| `relation_exercise_approved:seated_supported_thoracic_extension__recovery__mobility__supported_loaded_mobility__resume_comfortable_range_with_support_after_effort` | `passed` |  |
| `relation_status_allowed:seated_supported_thoracic_extension__recovery__mobility__supported_loaded_mobility__resume_comfortable_range_with_support_after_effort` | `passed` |  |
| `relation_path_exists:seated_supported_thoracic_extension__recovery__mobility__supported_loaded_mobility__resume_comfortable_range_with_support_after_effort` | `passed` |  |
| `relation_path_compatible:seated_supported_thoracic_extension__recovery__mobility__supported_loaded_mobility__resume_comfortable_range_with_support_after_effort` | `passed` | compatible |
| `relation_intention_in_path:seated_supported_thoracic_extension__recovery__mobility__supported_loaded_mobility__resume_comfortable_range_with_support_after_effort` | `passed` |  |
| `relation_role_match:seated_supported_thoracic_extension__recovery__mobility__supported_loaded_mobility__resume_comfortable_range_with_support_after_effort` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:seated_supported_thoracic_extension__recovery__mobility__supported_loaded_mobility__resume_comfortable_range_with_support_after_effort` | `passed` |  |
| `relation_exercise_approved:seated_supported_thoracic_extension__warmup__mobility__supported_loaded_mobility__prepare_supported_loaded_ranges` | `passed` |  |
| `relation_status_allowed:seated_supported_thoracic_extension__warmup__mobility__supported_loaded_mobility__prepare_supported_loaded_ranges` | `passed` |  |
| `relation_path_exists:seated_supported_thoracic_extension__warmup__mobility__supported_loaded_mobility__prepare_supported_loaded_ranges` | `passed` |  |
| `relation_path_compatible:seated_supported_thoracic_extension__warmup__mobility__supported_loaded_mobility__prepare_supported_loaded_ranges` | `passed` | compatible |
| `relation_intention_in_path:seated_supported_thoracic_extension__warmup__mobility__supported_loaded_mobility__prepare_supported_loaded_ranges` | `passed` |  |
| `relation_role_match:seated_supported_thoracic_extension__warmup__mobility__supported_loaded_mobility__prepare_supported_loaded_ranges` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:seated_supported_thoracic_extension__warmup__mobility__supported_loaded_mobility__prepare_supported_loaded_ranges` | `passed` |  |
| `relation_exercise_approved:single_leg_stance__activation__motor_control_coordination__postural_stabilization__prime_postural_stability` | `passed` |  |
| `relation_status_allowed:single_leg_stance__activation__motor_control_coordination__postural_stabilization__prime_postural_stability` | `passed` |  |
| `relation_path_exists:single_leg_stance__activation__motor_control_coordination__postural_stabilization__prime_postural_stability` | `passed` |  |
| `relation_path_compatible:single_leg_stance__activation__motor_control_coordination__postural_stabilization__prime_postural_stability` | `passed` | compatible |
| `relation_intention_in_path:single_leg_stance__activation__motor_control_coordination__postural_stabilization__prime_postural_stability` | `passed` |  |
| `relation_role_match:single_leg_stance__activation__motor_control_coordination__postural_stabilization__prime_postural_stability` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:single_leg_stance__activation__motor_control_coordination__postural_stabilization__prime_postural_stability` | `passed` |  |
| `conditional_fail_closed:single_leg_stance__activation__motor_control_coordination__postural_stabilization__prime_postural_stability` | `passed` |  |
| `relation_exercise_approved:single_leg_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` |  |
| `relation_status_allowed:single_leg_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` |  |
| `relation_path_exists:single_leg_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` |  |
| `relation_path_compatible:single_leg_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` | compatible |
| `relation_intention_in_path:single_leg_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` |  |
| `relation_role_match:single_leg_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:single_leg_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` |  |
| `relation_exercise_approved:single_leg_stance__main_training__motor_control_coordination__postural_stabilization__improve_static_postural_control` | `passed` |  |
| `relation_status_allowed:single_leg_stance__main_training__motor_control_coordination__postural_stabilization__improve_static_postural_control` | `passed` |  |
| `relation_path_exists:single_leg_stance__main_training__motor_control_coordination__postural_stabilization__improve_static_postural_control` | `passed` |  |
| `relation_path_compatible:single_leg_stance__main_training__motor_control_coordination__postural_stabilization__improve_static_postural_control` | `passed` | compatible |
| `relation_intention_in_path:single_leg_stance__main_training__motor_control_coordination__postural_stabilization__improve_static_postural_control` | `passed` |  |
| `relation_role_match:single_leg_stance__main_training__motor_control_coordination__postural_stabilization__improve_static_postural_control` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:single_leg_stance__main_training__motor_control_coordination__postural_stabilization__improve_static_postural_control` | `passed` |  |
| `relation_exercise_approved:single_leg_stance__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `relation_status_allowed:single_leg_stance__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `relation_path_exists:single_leg_stance__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `relation_path_compatible:single_leg_stance__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` | compatible |
| `relation_intention_in_path:single_leg_stance__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `relation_role_match:single_leg_stance__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:single_leg_stance__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `conditional_fail_closed:single_leg_stance__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `relation_exercise_approved:sled_resisted_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` |  |
| `relation_status_allowed:sled_resisted_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` |  |
| `relation_path_exists:sled_resisted_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` |  |
| `relation_path_compatible:sled_resisted_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` | compatible |
| `relation_intention_in_path:sled_resisted_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` |  |
| `relation_role_match:sled_resisted_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:sled_resisted_sprint__main_training__speed_power__explosive_acceleration__increase_initial_acceleration` | `passed` |  |
| `relation_exercise_approved:sprint_to_controlled_stop__main_training__speed_power__braking_redirection__increase_high_speed_deceleration_capacity` | `passed` |  |
| `relation_status_allowed:sprint_to_controlled_stop__main_training__speed_power__braking_redirection__increase_high_speed_deceleration_capacity` | `passed` |  |
| `relation_path_exists:sprint_to_controlled_stop__main_training__speed_power__braking_redirection__increase_high_speed_deceleration_capacity` | `passed` |  |
| `relation_path_compatible:sprint_to_controlled_stop__main_training__speed_power__braking_redirection__increase_high_speed_deceleration_capacity` | `passed` | compatible |
| `relation_intention_in_path:sprint_to_controlled_stop__main_training__speed_power__braking_redirection__increase_high_speed_deceleration_capacity` | `passed` |  |
| `relation_role_match:sprint_to_controlled_stop__main_training__speed_power__braking_redirection__increase_high_speed_deceleration_capacity` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:sprint_to_controlled_stop__main_training__speed_power__braking_redirection__increase_high_speed_deceleration_capacity` | `passed` |  |
| `relation_exercise_approved:sprint_to_controlled_stop__warmup__speed_power__braking_redirection__prepare_deceleration_mechanics` | `passed` |  |
| `relation_status_allowed:sprint_to_controlled_stop__warmup__speed_power__braking_redirection__prepare_deceleration_mechanics` | `passed` |  |
| `relation_path_exists:sprint_to_controlled_stop__warmup__speed_power__braking_redirection__prepare_deceleration_mechanics` | `passed` |  |
| `relation_path_compatible:sprint_to_controlled_stop__warmup__speed_power__braking_redirection__prepare_deceleration_mechanics` | `passed` | compatible |
| `relation_intention_in_path:sprint_to_controlled_stop__warmup__speed_power__braking_redirection__prepare_deceleration_mechanics` | `passed` |  |
| `relation_role_match:sprint_to_controlled_stop__warmup__speed_power__braking_redirection__prepare_deceleration_mechanics` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:sprint_to_controlled_stop__warmup__speed_power__braking_redirection__prepare_deceleration_mechanics` | `passed` |  |
| `conditional_fail_closed:sprint_to_controlled_stop__warmup__speed_power__braking_redirection__prepare_deceleration_mechanics` | `passed` |  |
| `relation_exercise_approved:standing_broad_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_status_allowed:standing_broad_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_path_exists:standing_broad_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_path_compatible:standing_broad_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` | compatible |
| `relation_intention_in_path:standing_broad_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_role_match:standing_broad_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:standing_broad_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power` | `passed` |  |
| `relation_exercise_approved:standing_gastrocnemius_wall_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_status_allowed:standing_gastrocnemius_wall_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_path_exists:standing_gastrocnemius_wall_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_path_compatible:standing_gastrocnemius_wall_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` | compatible |
| `relation_intention_in_path:standing_gastrocnemius_wall_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_role_match:standing_gastrocnemius_wall_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:standing_gastrocnemius_wall_stretch__main_training__flexibility__sustained_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_exercise_approved:standing_gastrocnemius_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `relation_status_allowed:standing_gastrocnemius_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `relation_path_exists:standing_gastrocnemius_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `relation_path_compatible:standing_gastrocnemius_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` | compatible |
| `relation_intention_in_path:standing_gastrocnemius_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `relation_role_match:standing_gastrocnemius_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` | alternative_primary == alternative_primary |
| `conditional_classified:standing_gastrocnemius_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `conditional_fail_closed:standing_gastrocnemius_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `relation_exercise_approved:standing_gastrocnemius_wall_stretch__warmup__flexibility__sustained_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_status_allowed:standing_gastrocnemius_wall_stretch__warmup__flexibility__sustained_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_path_exists:standing_gastrocnemius_wall_stretch__warmup__flexibility__sustained_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_path_compatible:standing_gastrocnemius_wall_stretch__warmup__flexibility__sustained_lengthening__prepare_required_joint_ranges` | `passed` | compatible |
| `relation_intention_in_path:standing_gastrocnemius_wall_stretch__warmup__flexibility__sustained_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_role_match:standing_gastrocnemius_wall_stretch__warmup__flexibility__sustained_lengthening__prepare_required_joint_ranges` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:standing_gastrocnemius_wall_stretch__warmup__flexibility__sustained_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `conditional_fail_closed:standing_gastrocnemius_wall_stretch__warmup__flexibility__sustained_lengthening__prepare_required_joint_ranges` | `passed` |  |
| `relation_exercise_approved:standing_medicine_ball_chest_pass__main_training__speed_power__ballistic_projection__increase_release_velocity` | `passed` |  |
| `relation_status_allowed:standing_medicine_ball_chest_pass__main_training__speed_power__ballistic_projection__increase_release_velocity` | `passed` |  |
| `relation_path_exists:standing_medicine_ball_chest_pass__main_training__speed_power__ballistic_projection__increase_release_velocity` | `passed` |  |
| `relation_path_compatible:standing_medicine_ball_chest_pass__main_training__speed_power__ballistic_projection__increase_release_velocity` | `passed` | compatible |
| `relation_intention_in_path:standing_medicine_ball_chest_pass__main_training__speed_power__ballistic_projection__increase_release_velocity` | `passed` |  |
| `relation_role_match:standing_medicine_ball_chest_pass__main_training__speed_power__ballistic_projection__increase_release_velocity` | `passed` | complementary == complementary |
| `compatible_ready:standing_medicine_ball_chest_pass__main_training__speed_power__ballistic_projection__increase_release_velocity` | `passed` |  |
| `relation_exercise_approved:standing_multidirectional_weight_shift__main_training__motor_control_coordination__base_of_support_control__improve_weight_shift_control` | `passed` |  |
| `relation_status_allowed:standing_multidirectional_weight_shift__main_training__motor_control_coordination__base_of_support_control__improve_weight_shift_control` | `passed` |  |
| `relation_path_exists:standing_multidirectional_weight_shift__main_training__motor_control_coordination__base_of_support_control__improve_weight_shift_control` | `passed` |  |
| `relation_path_compatible:standing_multidirectional_weight_shift__main_training__motor_control_coordination__base_of_support_control__improve_weight_shift_control` | `passed` | compatible |
| `relation_intention_in_path:standing_multidirectional_weight_shift__main_training__motor_control_coordination__base_of_support_control__improve_weight_shift_control` | `passed` |  |
| `relation_role_match:standing_multidirectional_weight_shift__main_training__motor_control_coordination__base_of_support_control__improve_weight_shift_control` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:standing_multidirectional_weight_shift__main_training__motor_control_coordination__base_of_support_control__improve_weight_shift_control` | `passed` |  |
| `relation_exercise_approved:standing_multidirectional_weight_shift__recovery__motor_control_coordination__base_of_support_control__maintain_gentle_weight_shift` | `passed` |  |
| `relation_status_allowed:standing_multidirectional_weight_shift__recovery__motor_control_coordination__base_of_support_control__maintain_gentle_weight_shift` | `passed` |  |
| `relation_path_exists:standing_multidirectional_weight_shift__recovery__motor_control_coordination__base_of_support_control__maintain_gentle_weight_shift` | `passed` |  |
| `relation_path_compatible:standing_multidirectional_weight_shift__recovery__motor_control_coordination__base_of_support_control__maintain_gentle_weight_shift` | `passed` | compatible |
| `relation_intention_in_path:standing_multidirectional_weight_shift__recovery__motor_control_coordination__base_of_support_control__maintain_gentle_weight_shift` | `passed` |  |
| `relation_role_match:standing_multidirectional_weight_shift__recovery__motor_control_coordination__base_of_support_control__maintain_gentle_weight_shift` | `passed` | complementary == complementary |
| `conditional_classified:standing_multidirectional_weight_shift__recovery__motor_control_coordination__base_of_support_control__maintain_gentle_weight_shift` | `passed` |  |
| `conditional_fail_closed:standing_multidirectional_weight_shift__recovery__motor_control_coordination__base_of_support_control__maintain_gentle_weight_shift` | `passed` |  |
| `relation_exercise_approved:standing_multidirectional_weight_shift__warmup__motor_control_coordination__base_of_support_control__rehearse_weight_shifts` | `passed` |  |
| `relation_status_allowed:standing_multidirectional_weight_shift__warmup__motor_control_coordination__base_of_support_control__rehearse_weight_shifts` | `passed` |  |
| `relation_path_exists:standing_multidirectional_weight_shift__warmup__motor_control_coordination__base_of_support_control__rehearse_weight_shifts` | `passed` |  |
| `relation_path_compatible:standing_multidirectional_weight_shift__warmup__motor_control_coordination__base_of_support_control__rehearse_weight_shifts` | `passed` | compatible |
| `relation_intention_in_path:standing_multidirectional_weight_shift__warmup__motor_control_coordination__base_of_support_control__rehearse_weight_shifts` | `passed` |  |
| `relation_role_match:standing_multidirectional_weight_shift__warmup__motor_control_coordination__base_of_support_control__rehearse_weight_shifts` | `passed` | complementary == complementary |
| `compatible_ready:standing_multidirectional_weight_shift__warmup__motor_control_coordination__base_of_support_control__rehearse_weight_shifts` | `passed` |  |
| `relation_exercise_approved:standing_soleus_wall_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` |  |
| `relation_status_allowed:standing_soleus_wall_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` |  |
| `relation_path_exists:standing_soleus_wall_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` |  |
| `relation_path_compatible:standing_soleus_wall_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` | compatible |
| `relation_intention_in_path:standing_soleus_wall_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` |  |
| `relation_role_match:standing_soleus_wall_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:standing_soleus_wall_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` | `passed` |  |
| `relation_exercise_approved:standing_soleus_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `relation_status_allowed:standing_soleus_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `relation_path_exists:standing_soleus_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `relation_path_compatible:standing_soleus_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` | compatible |
| `relation_intention_in_path:standing_soleus_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `relation_role_match:standing_soleus_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` | alternative_primary == alternative_primary |
| `conditional_classified:standing_soleus_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `conditional_fail_closed:standing_soleus_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `passed` |  |
| `relation_exercise_approved:static_rowing_ergometer__main_training__cardio_conditioning__cyclic_propulsion__increase_sustained_propulsive_output` | `passed` |  |
| `relation_status_allowed:static_rowing_ergometer__main_training__cardio_conditioning__cyclic_propulsion__increase_sustained_propulsive_output` | `passed` |  |
| `relation_path_exists:static_rowing_ergometer__main_training__cardio_conditioning__cyclic_propulsion__increase_sustained_propulsive_output` | `passed` |  |
| `relation_path_compatible:static_rowing_ergometer__main_training__cardio_conditioning__cyclic_propulsion__increase_sustained_propulsive_output` | `passed` | compatible |
| `relation_intention_in_path:static_rowing_ergometer__main_training__cardio_conditioning__cyclic_propulsion__increase_sustained_propulsive_output` | `passed` |  |
| `relation_role_match:static_rowing_ergometer__main_training__cardio_conditioning__cyclic_propulsion__increase_sustained_propulsive_output` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:static_rowing_ergometer__main_training__cardio_conditioning__cyclic_propulsion__increase_sustained_propulsive_output` | `passed` |  |
| `relation_exercise_approved:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__improve_transition_efficiency_within_sequence` | `passed` |  |
| `relation_status_allowed:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__improve_transition_efficiency_within_sequence` | `passed` |  |
| `relation_path_exists:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__improve_transition_efficiency_within_sequence` | `passed` |  |
| `relation_path_compatible:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__improve_transition_efficiency_within_sequence` | `passed` | compatible |
| `relation_intention_in_path:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__improve_transition_efficiency_within_sequence` | `passed` |  |
| `relation_role_match:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__improve_transition_efficiency_within_sequence` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__improve_transition_efficiency_within_sequence` | `passed` |  |
| `relation_exercise_approved:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__increase_sequence_endurance_under_fatigue` | `passed` |  |
| `relation_status_allowed:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__increase_sequence_endurance_under_fatigue` | `passed` |  |
| `relation_path_exists:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__increase_sequence_endurance_under_fatigue` | `passed` |  |
| `relation_path_compatible:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__increase_sequence_endurance_under_fatigue` | `passed` | compatible |
| `relation_intention_in_path:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__increase_sequence_endurance_under_fatigue` | `passed` |  |
| `relation_role_match:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__increase_sequence_endurance_under_fatigue` | `passed` | alternative_primary == alternative_primary |
| `conditional_classified:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__increase_sequence_endurance_under_fatigue` | `passed` |  |
| `conditional_fail_closed:static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__increase_sequence_endurance_under_fatigue` | `passed` |  |
| `relation_exercise_approved:static_rowing_ergometer__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_status_allowed:static_rowing_ergometer__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_path_exists:static_rowing_ergometer__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_path_compatible:static_rowing_ergometer__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` | compatible |
| `relation_intention_in_path:static_rowing_ergometer__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_role_match:static_rowing_ergometer__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` | complementary == complementary |
| `conditional_classified:static_rowing_ergometer__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `conditional_fail_closed:static_rowing_ergometer__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_exercise_approved:static_rowing_ergometer__warmup__cardio_conditioning__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_status_allowed:static_rowing_ergometer__warmup__cardio_conditioning__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_path_exists:static_rowing_ergometer__warmup__cardio_conditioning__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_path_compatible:static_rowing_ergometer__warmup__cardio_conditioning__repeated_motor_sequence__rehearse_motor_sequence` | `passed` | compatible |
| `relation_intention_in_path:static_rowing_ergometer__warmup__cardio_conditioning__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_role_match:static_rowing_ergometer__warmup__cardio_conditioning__repeated_motor_sequence__rehearse_motor_sequence` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:static_rowing_ergometer__warmup__cardio_conditioning__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `conditional_fail_closed:static_rowing_ergometer__warmup__cardio_conditioning__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_exercise_approved:static_rowing_ergometer__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_status_allowed:static_rowing_ergometer__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_path_exists:static_rowing_ergometer__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_path_compatible:static_rowing_ergometer__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` | compatible |
| `relation_intention_in_path:static_rowing_ergometer__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_role_match:static_rowing_ergometer__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:static_rowing_ergometer__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `conditional_fail_closed:static_rowing_ergometer__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `passed` |  |
| `relation_exercise_approved:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_status_allowed:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_exists:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_compatible:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` | compatible |
| `relation_intention_in_path:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_role_match:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_exercise_approved:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_status_allowed:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_path_exists:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_path_compatible:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` | compatible |
| `relation_intention_in_path:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_role_match:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:stationary_arm_crank_ergometry__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_exercise_approved:stationary_arm_crank_ergometry__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `relation_status_allowed:stationary_arm_crank_ergometry__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `relation_path_exists:stationary_arm_crank_ergometry__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `relation_path_compatible:stationary_arm_crank_ergometry__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` | compatible |
| `relation_intention_in_path:stationary_arm_crank_ergometry__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `relation_role_match:stationary_arm_crank_ergometry__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:stationary_arm_crank_ergometry__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `conditional_fail_closed:stationary_arm_crank_ergometry__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `relation_exercise_approved:supine_hamstring_strap_stretch__main_training__flexibility__assisted_lengthening__increase_stretch_tolerance` | `passed` |  |
| `relation_status_allowed:supine_hamstring_strap_stretch__main_training__flexibility__assisted_lengthening__increase_stretch_tolerance` | `passed` |  |
| `relation_path_exists:supine_hamstring_strap_stretch__main_training__flexibility__assisted_lengthening__increase_stretch_tolerance` | `passed` |  |
| `relation_path_compatible:supine_hamstring_strap_stretch__main_training__flexibility__assisted_lengthening__increase_stretch_tolerance` | `passed` | compatible |
| `relation_intention_in_path:supine_hamstring_strap_stretch__main_training__flexibility__assisted_lengthening__increase_stretch_tolerance` | `passed` |  |
| `relation_role_match:supine_hamstring_strap_stretch__main_training__flexibility__assisted_lengthening__increase_stretch_tolerance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:supine_hamstring_strap_stretch__main_training__flexibility__assisted_lengthening__increase_stretch_tolerance` | `passed` |  |
| `relation_exercise_approved:supine_hamstring_strap_stretch__recovery__flexibility__assisted_lengthening__resume_comfortable_range_with_support_after_effort` | `passed` |  |
| `relation_status_allowed:supine_hamstring_strap_stretch__recovery__flexibility__assisted_lengthening__resume_comfortable_range_with_support_after_effort` | `passed` |  |
| `relation_path_exists:supine_hamstring_strap_stretch__recovery__flexibility__assisted_lengthening__resume_comfortable_range_with_support_after_effort` | `passed` |  |
| `relation_path_compatible:supine_hamstring_strap_stretch__recovery__flexibility__assisted_lengthening__resume_comfortable_range_with_support_after_effort` | `passed` | compatible |
| `relation_intention_in_path:supine_hamstring_strap_stretch__recovery__flexibility__assisted_lengthening__resume_comfortable_range_with_support_after_effort` | `passed` |  |
| `relation_role_match:supine_hamstring_strap_stretch__recovery__flexibility__assisted_lengthening__resume_comfortable_range_with_support_after_effort` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:supine_hamstring_strap_stretch__recovery__flexibility__assisted_lengthening__resume_comfortable_range_with_support_after_effort` | `passed` |  |
| `conditional_fail_closed:supine_hamstring_strap_stretch__recovery__flexibility__assisted_lengthening__resume_comfortable_range_with_support_after_effort` | `passed` |  |
| `relation_exercise_approved:supine_heel_slide__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` |  |
| `relation_status_allowed:supine_heel_slide__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` |  |
| `relation_path_exists:supine_heel_slide__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` |  |
| `relation_path_compatible:supine_heel_slide__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` | compatible |
| `relation_intention_in_path:supine_heel_slide__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` |  |
| `relation_role_match:supine_heel_slide__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:supine_heel_slide__main_training__mobility__range_transition__improve_transition_between_ranges` | `passed` |  |
| `relation_exercise_approved:supine_heel_slide__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` |  |
| `relation_status_allowed:supine_heel_slide__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` |  |
| `relation_path_exists:supine_heel_slide__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` |  |
| `relation_path_compatible:supine_heel_slide__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` | compatible |
| `relation_intention_in_path:supine_heel_slide__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` |  |
| `relation_role_match:supine_heel_slide__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:supine_heel_slide__prevention__mobility__range_transition__maintain_position_transition_capacity` | `passed` |  |
| `relation_exercise_approved:supine_heel_slide__recovery__mobility__range_transition__resume_comfortable_position_transitions_after_effort` | `passed` |  |
| `relation_status_allowed:supine_heel_slide__recovery__mobility__range_transition__resume_comfortable_position_transitions_after_effort` | `passed` |  |
| `relation_path_exists:supine_heel_slide__recovery__mobility__range_transition__resume_comfortable_position_transitions_after_effort` | `passed` |  |
| `relation_path_compatible:supine_heel_slide__recovery__mobility__range_transition__resume_comfortable_position_transitions_after_effort` | `passed` | compatible |
| `relation_intention_in_path:supine_heel_slide__recovery__mobility__range_transition__resume_comfortable_position_transitions_after_effort` | `passed` |  |
| `relation_role_match:supine_heel_slide__recovery__mobility__range_transition__resume_comfortable_position_transitions_after_effort` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:supine_heel_slide__recovery__mobility__range_transition__resume_comfortable_position_transitions_after_effort` | `passed` |  |
| `relation_exercise_approved:supine_self_assisted_hamstring_stretch__cooldown__flexibility__assisted_lengthening__release_perceived_tension` | `passed` |  |
| `relation_status_allowed:supine_self_assisted_hamstring_stretch__cooldown__flexibility__assisted_lengthening__release_perceived_tension` | `passed` |  |
| `relation_path_exists:supine_self_assisted_hamstring_stretch__cooldown__flexibility__assisted_lengthening__release_perceived_tension` | `passed` |  |
| `relation_path_compatible:supine_self_assisted_hamstring_stretch__cooldown__flexibility__assisted_lengthening__release_perceived_tension` | `passed` | compatible |
| `relation_intention_in_path:supine_self_assisted_hamstring_stretch__cooldown__flexibility__assisted_lengthening__release_perceived_tension` | `passed` |  |
| `relation_role_match:supine_self_assisted_hamstring_stretch__cooldown__flexibility__assisted_lengthening__release_perceived_tension` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:supine_self_assisted_hamstring_stretch__cooldown__flexibility__assisted_lengthening__release_perceived_tension` | `passed` |  |
| `conditional_fail_closed:supine_self_assisted_hamstring_stretch__cooldown__flexibility__assisted_lengthening__release_perceived_tension` | `passed` |  |
| `relation_exercise_approved:supine_self_assisted_hamstring_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_status_allowed:supine_self_assisted_hamstring_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_path_exists:supine_self_assisted_hamstring_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_path_compatible:supine_self_assisted_hamstring_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` | compatible |
| `relation_intention_in_path:supine_self_assisted_hamstring_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_role_match:supine_self_assisted_hamstring_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:supine_self_assisted_hamstring_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion` | `passed` |  |
| `relation_exercise_approved:tandem_stance__activation__motor_control_coordination__base_of_support_control__prime_support_control` | `passed` |  |
| `relation_status_allowed:tandem_stance__activation__motor_control_coordination__base_of_support_control__prime_support_control` | `passed` |  |
| `relation_path_exists:tandem_stance__activation__motor_control_coordination__base_of_support_control__prime_support_control` | `passed` |  |
| `relation_path_compatible:tandem_stance__activation__motor_control_coordination__base_of_support_control__prime_support_control` | `passed` | compatible |
| `relation_intention_in_path:tandem_stance__activation__motor_control_coordination__base_of_support_control__prime_support_control` | `passed` |  |
| `relation_role_match:tandem_stance__activation__motor_control_coordination__base_of_support_control__prime_support_control` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:tandem_stance__activation__motor_control_coordination__base_of_support_control__prime_support_control` | `passed` |  |
| `conditional_fail_closed:tandem_stance__activation__motor_control_coordination__base_of_support_control__prime_support_control` | `passed` |  |
| `relation_exercise_approved:tandem_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` |  |
| `relation_status_allowed:tandem_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` |  |
| `relation_path_exists:tandem_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` |  |
| `relation_path_compatible:tandem_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` | compatible |
| `relation_intention_in_path:tandem_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` |  |
| `relation_role_match:tandem_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:tandem_stance__main_training__motor_control_coordination__base_of_support_control__improve_static_balance` | `passed` |  |
| `relation_exercise_approved:tandem_stance__prevention__motor_control_coordination__base_of_support_control__increase_reduced_base_tolerance` | `passed` |  |
| `relation_status_allowed:tandem_stance__prevention__motor_control_coordination__base_of_support_control__increase_reduced_base_tolerance` | `passed` |  |
| `relation_path_exists:tandem_stance__prevention__motor_control_coordination__base_of_support_control__increase_reduced_base_tolerance` | `passed` |  |
| `relation_path_compatible:tandem_stance__prevention__motor_control_coordination__base_of_support_control__increase_reduced_base_tolerance` | `passed` | compatible |
| `relation_intention_in_path:tandem_stance__prevention__motor_control_coordination__base_of_support_control__increase_reduced_base_tolerance` | `passed` |  |
| `relation_role_match:tandem_stance__prevention__motor_control_coordination__base_of_support_control__increase_reduced_base_tolerance` | `passed` | complementary == complementary |
| `conditional_classified:tandem_stance__prevention__motor_control_coordination__base_of_support_control__increase_reduced_base_tolerance` | `passed` |  |
| `conditional_fail_closed:tandem_stance__prevention__motor_control_coordination__base_of_support_control__increase_reduced_base_tolerance` | `passed` |  |
| `relation_exercise_approved:tandem_walk__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` |  |
| `relation_status_allowed:tandem_walk__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` |  |
| `relation_path_exists:tandem_walk__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` |  |
| `relation_path_compatible:tandem_walk__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` | compatible |
| `relation_intention_in_path:tandem_walk__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` |  |
| `relation_role_match:tandem_walk__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:tandem_walk__main_training__motor_control_coordination__base_of_support_control__improve_dynamic_balance` | `passed` |  |
| `relation_exercise_approved:tandem_walk__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_status_allowed:tandem_walk__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_path_exists:tandem_walk__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_path_compatible:tandem_walk__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` | compatible |
| `relation_intention_in_path:tandem_walk__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_role_match:tandem_walk__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` | complementary == complementary |
| `compatible_ready:tandem_walk__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `passed` |  |
| `relation_exercise_approved:tandem_walk__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `relation_status_allowed:tandem_walk__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `relation_path_exists:tandem_walk__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `relation_path_compatible:tandem_walk__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` | compatible |
| `relation_intention_in_path:tandem_walk__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `relation_role_match:tandem_walk__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:tandem_walk__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `conditional_fail_closed:tandem_walk__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `passed` |  |
| `relation_exercise_approved:tandem_walk__warmup__motor_control_coordination__base_of_support_control__prepare_balance_control` | `passed` |  |
| `relation_status_allowed:tandem_walk__warmup__motor_control_coordination__base_of_support_control__prepare_balance_control` | `passed` |  |
| `relation_path_exists:tandem_walk__warmup__motor_control_coordination__base_of_support_control__prepare_balance_control` | `passed` |  |
| `relation_path_compatible:tandem_walk__warmup__motor_control_coordination__base_of_support_control__prepare_balance_control` | `passed` | compatible |
| `relation_intention_in_path:tandem_walk__warmup__motor_control_coordination__base_of_support_control__prepare_balance_control` | `passed` |  |
| `relation_role_match:tandem_walk__warmup__motor_control_coordination__base_of_support_control__prepare_balance_control` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:tandem_walk__warmup__motor_control_coordination__base_of_support_control__prepare_balance_control` | `passed` |  |
| `conditional_fail_closed:tandem_walk__warmup__motor_control_coordination__base_of_support_control__prepare_balance_control` | `passed` |  |
| `relation_exercise_approved:treadmill_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_status_allowed:treadmill_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_exists:treadmill_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_compatible:treadmill_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` | compatible |
| `relation_intention_in_path:treadmill_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_role_match:treadmill_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:treadmill_walking__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` | `passed` |  |
| `relation_exercise_approved:treadmill_walking__recovery__cardio_conditioning__cyclic_locomotion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `relation_status_allowed:treadmill_walking__recovery__cardio_conditioning__cyclic_locomotion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `relation_path_exists:treadmill_walking__recovery__cardio_conditioning__cyclic_locomotion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `relation_path_compatible:treadmill_walking__recovery__cardio_conditioning__cyclic_locomotion__maintain_light_cardiorespiratory_activity` | `passed` | compatible |
| `relation_intention_in_path:treadmill_walking__recovery__cardio_conditioning__cyclic_locomotion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `relation_role_match:treadmill_walking__recovery__cardio_conditioning__cyclic_locomotion__maintain_light_cardiorespiratory_activity` | `passed` | complementary == complementary |
| `conditional_classified:treadmill_walking__recovery__cardio_conditioning__cyclic_locomotion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `conditional_fail_closed:treadmill_walking__recovery__cardio_conditioning__cyclic_locomotion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `relation_exercise_approved:treadmill_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_status_allowed:treadmill_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_path_exists:treadmill_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_path_compatible:treadmill_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` | compatible |
| `relation_intention_in_path:treadmill_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_role_match:treadmill_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` | complementary == complementary |
| `conditional_classified:treadmill_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `conditional_fail_closed:treadmill_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `passed` |  |
| `relation_exercise_approved:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__improve_coordination_under_sustained_effort` | `passed` |  |
| `relation_status_allowed:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__improve_coordination_under_sustained_effort` | `passed` |  |
| `relation_path_exists:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__improve_coordination_under_sustained_effort` | `passed` |  |
| `relation_path_compatible:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__improve_coordination_under_sustained_effort` | `passed` | compatible |
| `relation_intention_in_path:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__improve_coordination_under_sustained_effort` | `passed` |  |
| `relation_role_match:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__improve_coordination_under_sustained_effort` | `passed` | complementary == complementary |
| `conditional_classified:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__improve_coordination_under_sustained_effort` | `passed` |  |
| `conditional_fail_closed:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__improve_coordination_under_sustained_effort` | `passed` |  |
| `relation_exercise_approved:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_status_allowed:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_path_exists:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_path_compatible:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` | compatible |
| `relation_intention_in_path:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_role_match:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `passed` |  |
| `relation_exercise_approved:two_foot_rope_skipping__main_training__motor_control_coordination__rhythm_synchronization__improve_interlimb_coordination` | `passed` |  |
| `relation_status_allowed:two_foot_rope_skipping__main_training__motor_control_coordination__rhythm_synchronization__improve_interlimb_coordination` | `passed` |  |
| `relation_path_exists:two_foot_rope_skipping__main_training__motor_control_coordination__rhythm_synchronization__improve_interlimb_coordination` | `passed` |  |
| `relation_path_compatible:two_foot_rope_skipping__main_training__motor_control_coordination__rhythm_synchronization__improve_interlimb_coordination` | `passed` | compatible |
| `relation_intention_in_path:two_foot_rope_skipping__main_training__motor_control_coordination__rhythm_synchronization__improve_interlimb_coordination` | `passed` |  |
| `relation_role_match:two_foot_rope_skipping__main_training__motor_control_coordination__rhythm_synchronization__improve_interlimb_coordination` | `passed` | alternative_primary == alternative_primary |
| `conditional_classified:two_foot_rope_skipping__main_training__motor_control_coordination__rhythm_synchronization__improve_interlimb_coordination` | `passed` |  |
| `conditional_fail_closed:two_foot_rope_skipping__main_training__motor_control_coordination__rhythm_synchronization__improve_interlimb_coordination` | `passed` |  |
| `relation_exercise_approved:two_foot_rope_skipping__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `relation_status_allowed:two_foot_rope_skipping__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `relation_path_exists:two_foot_rope_skipping__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `relation_path_compatible:two_foot_rope_skipping__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` | compatible |
| `relation_intention_in_path:two_foot_rope_skipping__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `relation_role_match:two_foot_rope_skipping__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` | complementary == complementary |
| `conditional_classified:two_foot_rope_skipping__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `conditional_fail_closed:two_foot_rope_skipping__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `passed` |  |
| `relation_exercise_approved:two_foot_rope_skipping__warmup__motor_control_coordination__rhythm_synchronization__prepare_interlimb_synchronization` | `passed` |  |
| `relation_status_allowed:two_foot_rope_skipping__warmup__motor_control_coordination__rhythm_synchronization__prepare_interlimb_synchronization` | `passed` |  |
| `relation_path_exists:two_foot_rope_skipping__warmup__motor_control_coordination__rhythm_synchronization__prepare_interlimb_synchronization` | `passed` |  |
| `relation_path_compatible:two_foot_rope_skipping__warmup__motor_control_coordination__rhythm_synchronization__prepare_interlimb_synchronization` | `passed` | compatible |
| `relation_intention_in_path:two_foot_rope_skipping__warmup__motor_control_coordination__rhythm_synchronization__prepare_interlimb_synchronization` | `passed` |  |
| `relation_role_match:two_foot_rope_skipping__warmup__motor_control_coordination__rhythm_synchronization__prepare_interlimb_synchronization` | `passed` | complementary == complementary |
| `conditional_classified:two_foot_rope_skipping__warmup__motor_control_coordination__rhythm_synchronization__prepare_interlimb_synchronization` | `passed` |  |
| `conditional_fail_closed:two_foot_rope_skipping__warmup__motor_control_coordination__rhythm_synchronization__prepare_interlimb_synchronization` | `passed` |  |
| `relation_exercise_approved:two_point_sprint_start__activation__speed_power__explosive_acceleration__prime_start_position_force_organization` | `passed` |  |
| `relation_status_allowed:two_point_sprint_start__activation__speed_power__explosive_acceleration__prime_start_position_force_organization` | `passed` |  |
| `relation_path_exists:two_point_sprint_start__activation__speed_power__explosive_acceleration__prime_start_position_force_organization` | `passed` |  |
| `relation_path_compatible:two_point_sprint_start__activation__speed_power__explosive_acceleration__prime_start_position_force_organization` | `passed` | compatible |
| `relation_intention_in_path:two_point_sprint_start__activation__speed_power__explosive_acceleration__prime_start_position_force_organization` | `passed` |  |
| `relation_role_match:two_point_sprint_start__activation__speed_power__explosive_acceleration__prime_start_position_force_organization` | `passed` | complementary == complementary |
| `compatible_ready:two_point_sprint_start__activation__speed_power__explosive_acceleration__prime_start_position_force_organization` | `passed` |  |
| `relation_exercise_approved:two_point_sprint_start__warmup__speed_power__explosive_acceleration__rehearse_acceleration_mechanics` | `passed` |  |
| `relation_status_allowed:two_point_sprint_start__warmup__speed_power__explosive_acceleration__rehearse_acceleration_mechanics` | `passed` |  |
| `relation_path_exists:two_point_sprint_start__warmup__speed_power__explosive_acceleration__rehearse_acceleration_mechanics` | `passed` |  |
| `relation_path_compatible:two_point_sprint_start__warmup__speed_power__explosive_acceleration__rehearse_acceleration_mechanics` | `passed` | compatible |
| `relation_intention_in_path:two_point_sprint_start__warmup__speed_power__explosive_acceleration__rehearse_acceleration_mechanics` | `passed` |  |
| `relation_role_match:two_point_sprint_start__warmup__speed_power__explosive_acceleration__rehearse_acceleration_mechanics` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:two_point_sprint_start__warmup__speed_power__explosive_acceleration__rehearse_acceleration_mechanics` | `passed` |  |
| `conditional_fail_closed:two_point_sprint_start__warmup__speed_power__explosive_acceleration__rehearse_acceleration_mechanics` | `passed` |  |
| `relation_exercise_approved:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_status_allowed:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_exists:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_path_compatible:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` | compatible |
| `relation_intention_in_path:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_role_match:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__develop_aerobic_endurance` | `passed` |  |
| `relation_exercise_approved:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_status_allowed:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_path_exists:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_path_compatible:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` | compatible |
| `relation_intention_in_path:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_role_match:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:upright_stationary_cycling__main_training__cardio_conditioning__cyclic_propulsion__improve_propulsive_efficiency` | `passed` |  |
| `relation_exercise_approved:upright_stationary_cycling__recovery__cardio_conditioning__cyclic_propulsion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `relation_status_allowed:upright_stationary_cycling__recovery__cardio_conditioning__cyclic_propulsion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `relation_path_exists:upright_stationary_cycling__recovery__cardio_conditioning__cyclic_propulsion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `relation_path_compatible:upright_stationary_cycling__recovery__cardio_conditioning__cyclic_propulsion__maintain_light_cardiorespiratory_activity` | `passed` | compatible |
| `relation_intention_in_path:upright_stationary_cycling__recovery__cardio_conditioning__cyclic_propulsion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `relation_role_match:upright_stationary_cycling__recovery__cardio_conditioning__cyclic_propulsion__maintain_light_cardiorespiratory_activity` | `passed` | complementary == complementary |
| `conditional_classified:upright_stationary_cycling__recovery__cardio_conditioning__cyclic_propulsion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `conditional_fail_closed:upright_stationary_cycling__recovery__cardio_conditioning__cyclic_propulsion__maintain_light_cardiorespiratory_activity` | `passed` |  |
| `relation_exercise_approved:upright_stationary_cycling__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `relation_status_allowed:upright_stationary_cycling__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `relation_path_exists:upright_stationary_cycling__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `relation_path_compatible:upright_stationary_cycling__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` | compatible |
| `relation_intention_in_path:upright_stationary_cycling__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `relation_role_match:upright_stationary_cycling__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` | principal_candidate == principal_candidate |
| `conditional_classified:upright_stationary_cycling__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `conditional_fail_closed:upright_stationary_cycling__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `passed` |  |
| `relation_exercise_approved:volleyball_forearm_pass_to_target__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` |  |
| `relation_status_allowed:volleyball_forearm_pass_to_target__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` |  |
| `relation_path_exists:volleyball_forearm_pass_to_target__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` |  |
| `relation_path_compatible:volleyball_forearm_pass_to_target__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` | compatible |
| `relation_intention_in_path:volleyball_forearm_pass_to_target__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` |  |
| `relation_role_match:volleyball_forearm_pass_to_target__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` | principal_candidate == principal_candidate |
| `compatible_ready:volleyball_forearm_pass_to_target__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `passed` |  |
| `relation_exercise_approved:volleyball_forearm_pass_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` |  |
| `relation_status_allowed:volleyball_forearm_pass_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` |  |
| `relation_path_exists:volleyball_forearm_pass_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` |  |
| `relation_path_compatible:volleyball_forearm_pass_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` | compatible |
| `relation_intention_in_path:volleyball_forearm_pass_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` |  |
| `relation_role_match:volleyball_forearm_pass_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` | alternative_primary == alternative_primary |
| `compatible_ready:volleyball_forearm_pass_to_target__main_training__technique_skill__target_oriented_precision__improve_target_consistency` | `passed` |  |
| `ontology_counts` | `passed` | {'contexts': 7, 'capabilities': 8, 'concepts': 35, 'paths': 280, 'compatible_paths': 261, 'incompatible_paths': 19, 'intentions': 591, 'path_intention_occurrences': 771} |
| `source_manifest_role_mismatches_zero` | `passed` |  |
| `no_unknown_pending_review` | `passed` |  |

A prova de reprodutibilidade compara uma segunda pasta e um segundo ZIP gerados com as mesmas fontes e parâmetros fixos.
