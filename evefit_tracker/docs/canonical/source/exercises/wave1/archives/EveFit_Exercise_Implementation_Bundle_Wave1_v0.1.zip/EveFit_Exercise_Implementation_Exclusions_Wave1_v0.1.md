# EveFit Exercise Implementation Exclusions Wave1 v0.1

Tudo o que consta neste ficheiro fica fora do registry técnico principal.

## Exercícios specialist_review excluídos

| Exercise ID | Nome | Capacidade principal | Motivo da pendência | Revisão necessária | Risco de implementação prematura |
|---|---|---|---|---|---|
| `active_shoulder_circumduction` | Circundução ativa do ombro | `mobility` | A evidência direta específica é limitada; parte do suporte é de família ou profissional. Existe incerteza material de evidência, identidade secundária ou propriedade de capacidade; a revisão especializada da Vaga 4 permanece pendente. | training_review:in_progress, product_review:not_started | Promover antes da revisão preservada poderia tratar como fechado um registo com risco moderate e limites ainda ativos. |
| `arm_elevation_breath_synchronization` | Elevação dos braços sincronizada com a respiração | `breathing_regulation` | A coordenação entre respiração e movimento é defensável, mas a evidência direta desta identidade e a propriedade secundária de mobilidade aguardam revisão cruzada. A aprovação documental interna continua dependente da revisão final de Sandro e EVE. | product_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco low e limites ainda ativos. |
| `boccia_ramp_ball_release_to_target` | Libertação de bola de boccia por rampa para alvo | `technique_skill` | As fontes sustentam a modalidade e a adaptação, mas falta revisão especializada de boccia para fechar os limites entre decisão do atleta, ação do assistente e dispositivo. Ratificação por Sandro/EVE pendente. | product_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco moderate e limites ainda ativos. |
| `breaststroke_pull_breathe_kick_glide_sequence` | Sequência puxar-respirar-pernada-deslizar na bruços | `technique_skill` | A sequência é sustentada por manual técnico, mas exige revisão aquática e cruzada A/E/G antes de aprovação; ratificação final por Sandro/EVE pendente. | product_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco high e limites ainda ativos. |
| `circumferential_breath_bracing_coordination` | Coordenação respiratória com estabilização circunferencial | `breathing_regulation` | A mecânica de pressão e bracing é suportada, mas a identidade, a propriedade muscular secundária e as regras por população continuam por validar. A aprovação documental interna continua dependente da revisão final de Sandro e EVE. | clinical_review:in_progress, product_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco high e limites ainda ativos. |
| `court_wheelchair_brake_turn_accelerate` | Travagem, viragem e re-aceleração em cadeira de court | `speed_power` | A mecânica de cadeira de court é distinta da cadeira de corrida, mas a assinatura e os requisitos necessitam validação por especialista de cadeira desportiva e ratificação por Sandro/EVE. | revisão especializada e ratificação final | Promover antes da revisão preservada poderia tratar como fechado um registo com risco high e limites ainda ativos. |
| `drop_rebound_jump` | Salto com ressalto após queda | `speed_power` | As fontes mostram estratégias materialmente diferentes após a queda, mas a terminologia drop/depth é inconsistente. Mantém-se uma base neutra única até revisão biomecânica/terminológica e ratificação por Sandro/EVE. | revisão especializada e ratificação final | Promover antes da revisão preservada poderia tratar como fechado um registo com risco high e limites ainda ativos. |
| `forward_lean_release_recovery_step` | Passo compensatório após libertação de inclinação anterior | `motor_control_coordination` | A família de perturbação é suportada, mas o uso como treino versus avaliação e a montagem de segurança exigem especialista. A aprovação documental interna não substitui a ratificação final de Sandro/EVE. | clinical_review:in_progress, product_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco clinically_restricted e limites ainda ativos. |
| `goalball_roll_throw_to_goal` | Lançamento rolado de goalball para a baliza | `technique_skill` | A fonte oficial disponível é uma visão geral, insuficiente para fechar biomecânica, progressão segura e linguagem pública sem especialista de goalball. Ratificação por Sandro/EVE pendente. | product_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco moderate e limites ainda ativos. |
| `judo_ippon_seoi_nage_partner_throw` | Ippon-seoi-nage com projeção de parceiro | `technique_skill` | A técnica é identificada oficialmente, mas faltam revisão especializada de ensino, ukemi, controlo da queda e critérios de parceiro para aprovação documental. Ratificação por Sandro/EVE pendente. | product_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco high e limites ainda ativos. |
| `kneeling_child_pose_lengthening_hold` | Alongamento ajoelhado com recuo da bacia e alcance dos braços | `flexibility` | Revisão especialista pendente: a ação foi fechada, mas a propriedade editorial permanece híbrida entre flexibilidade, mobilidade integrada e exigência postural; revisão C/E na Vaga 4 continua pendente | product_review:not_started | Promover antes da revisão preservada poderia tratar como fechado um registo com risco moderate e limites ainda ativos. |
| `lateral_shuffle_shuttle` | Shuttle em shuffle lateral | `cardio_conditioning` | A ação é tecnicamente plausível, mas a capacidade principal e a fronteira com speed_power permanecem pendentes da Vaga 4. | biomechanical_review:in_progress, training_review:in_progress, safety_review:in_progress, product_review:in_progress, final_integrity_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco moderate e limites ainda ativos. |
| `quadruped_active_hip_circumduction` | Circundução ativa da anca em quadrupedia | `mobility` | A evidência direta específica é limitada; parte do suporte é de família ou profissional. Existe incerteza material de evidência, identidade secundária ou propriedade de capacidade; a revisão especializada da Vaga 4 permanece pendente. | training_review:in_progress, product_review:not_started | Promover antes da revisão preservada poderia tratar como fechado um registo com risco moderate e limites ainda ativos. |
| `quadruped_cat_camel` | Gato-camelo em quadrupedia | `mobility` | A evidência sustenta a identidade e a família mecânica, não uma eficácia universal nem uma dose. Existe incerteza material de evidência, identidade secundária ou propriedade de capacidade; a revisão especializada da Vaga 4 permanece pendente. | training_review:in_progress, product_review:not_started | Promover antes da revisão preservada poderia tratar como fechado um registo com risco low e limites ainda ativos. |
| `racing_wheelchair_sprint` | Sprint em cadeira de rodas de corrida | `speed_power` | A separação entre cadeira de corrida e cadeira de court é defensável, mas faltam revisão para-desportiva da técnica, equipamento e linguagem pública e ratificação final por Sandro/EVE. | revisão especializada e ratificação final | Promover antes da revisão preservada poderia tratar como fechado um registo com risco high e limites ainda ativos. |
| `seated_90_90_hip_switch` | Alternância 90/90 da anca sentada | `mobility` | A evidência direta específica é limitada; parte do suporte é de família ou profissional. Existe incerteza material de evidência, identidade secundária ou propriedade de capacidade; a revisão especializada da Vaga 4 permanece pendente. | training_review:in_progress, product_review:not_started | Promover antes da revisão preservada poderia tratar como fechado um registo com risco moderate e limites ainda ativos. |
| `seated_self_assisted_trunk_rotation_hold` | Rotação sustentada do tronco sentado com autoassistência | `flexibility` | Revisão especialista pendente: a capacidade principal permanece em fronteira material com mobilidade e controlo segmentar; requer revisão C/E na Vaga 4 e validação clínica/anatómica adicional | product_review:not_started | Promover antes da revisão preservada poderia tratar como fechado um registo com risco moderate e limites ainda ativos. |
| `seated_thorax_pelvis_dissociation` | Dissociação tórax-bacia sentada | `motor_control_coordination` | A configuração está fechada, mas a evidência direta da identidade é limitada e a propriedade entre controlo motor e mobilidade exige revisão cruzada C/E. A aprovação documental interna não substitui a ratificação final de Sandro/EVE. | product_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco low e limites ainda ativos. |
| `shoulder_wall_slide` | Deslizamento dos braços na parede | `mobility` | A evidência sustenta a identidade e a família mecânica, não uma eficácia universal nem uma dose. Existe incerteza material de evidência, identidade secundária ou propriedade de capacidade; a revisão especializada da Vaga 4 permanece pendente. | training_review:in_progress, product_review:not_started | Promover antes da revisão preservada poderia tratar como fechado um registo com risco moderate e limites ainda ativos. |
| `side_lying_open_book_rotation` | Rotação torácica em livro aberto | `mobility` | A evidência sustenta a identidade e a família mecânica, não uma eficácia universal nem uma dose. Existe incerteza material de evidência, identidade secundária ou propriedade de capacidade; a revisão especializada da Vaga 4 permanece pendente. | training_review:in_progress, product_review:not_started | Promover antes da revisão preservada poderia tratar como fechado um registo com risco low e limites ainda ativos. |
| `supine_partner_assisted_hamstring_stretch` | Alongamento dos isquiotibiais em decúbito dorsal assistido por parceiro | `flexibility` | Revisão especialista pendente: a assistência humana altera controlo de força, competência, consentimento, supervisão e elegibilidade; requer revisão clínica e de segurança antes de seleção pública | clinical_review:in_progress, product_review:not_started | Promover antes da revisão preservada poderia tratar como fechado um registo com risco high e limites ainda ativos. |
| `supported_standing_active_hip_circumduction` | Circundução ativa da anca em pé com apoio | `mobility` | A evidência direta específica é limitada; parte do suporte é de família ou profissional. Existe incerteza material de evidência, identidade secundária ou propriedade de capacidade; a revisão especializada da Vaga 4 permanece pendente. | training_review:in_progress, product_review:not_started | Promover antes da revisão preservada poderia tratar como fechado um registo com risco moderate e limites ainda ativos. |
| `table_tennis_irregular_forehand_backhand_response` | Resposta irregular de direita e esquerda no ténis de mesa | `technique_skill` | A taxonomia técnica e a família decisional são sustentadas, mas a assinatura concreta do feed e a representatividade exigem especialista de ténis de mesa. Ratificação por Sandro/EVE pendente. | product_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco moderate e limites ainda ativos. |
| `treadmill_slip_recovery_step` | Recuperação de escorregamento induzido em passadeira | `motor_control_coordination` | A evidência especializada sustenta a família e distingue escorregamento de tropeção; parâmetros e elegibilidade dependem do dispositivo e da equipa clínica. A aprovação documental interna não substitui a ratificação final de Sandro/EVE. | clinical_review:in_progress, product_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco clinically_restricted e limites ainda ativos. |
| `treadmill_trip_recovery_step` | Recuperação de tropeção induzida em passadeira | `motor_control_coordination` | A evidência especializada distingue tropeção de escorregamento; dispositivos e parâmetros variam e exigem validação clínica e técnica. A aprovação documental interna não substitui a ratificação final de Sandro/EVE. | clinical_review:in_progress, product_review:in_progress | Promover antes da revisão preservada poderia tratar como fechado um registo com risco clinically_restricted e limites ainda ativos. |

## Relações pending_review excluídas

| Exercício | Percurso | Intenção | Motivo | Revisão necessária |
|---|---|---|---|---|
| `active_shoulder_circumduction` | `main_training/mobility/active_joint_exploration` | `increase_active_joint_range_of_motion` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `active_shoulder_circumduction` | `prevention/mobility/active_joint_exploration` | `maintain_active_joint_range_capacity` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `active_shoulder_circumduction` | `warmup/mobility/active_joint_exploration` | `prepare_required_joint_ranges` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `arm_elevation_breath_synchronization` | `activation/breathing_regulation/breath_movement_synchronization` | `prime_breath_movement_timing` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `arm_elevation_breath_synchronization` | `main_training/breathing_regulation/breath_movement_synchronization` | `improve_breath_movement_coordination` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `arm_elevation_breath_synchronization` | `warmup/breathing_regulation/breath_movement_synchronization` | `prepare_breath_movement_coordination` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `boccia_ramp_ball_release_to_target` | `main_training/technique_skill/contextual_technical_application` | `integrate_skill_in_task_context` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `boccia_ramp_ball_release_to_target` | `main_training/technique_skill/target_oriented_precision` | `improve_force_scaling_to_target` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `breaststroke_pull_breathe_kick_glide_sequence` | `main_training/technique_skill/isolated_technical_practice` | `develop_isolated_technical_component` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `breaststroke_pull_breathe_kick_glide_sequence` | `main_training/technique_skill/repeated_motor_sequence` | `improve_technical_sequence_fluency` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `circumferential_breath_bracing_coordination` | `activation/breathing_regulation/internal_pressure_management` | `prime_bracing_coordination` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `circumferential_breath_bracing_coordination` | `main_training/breathing_regulation/internal_pressure_management` | `improve_internal_pressure_control` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `circumferential_breath_bracing_coordination` | `prevention/breathing_regulation/internal_pressure_management` | `build_pressure_management_capacity` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `circumferential_breath_bracing_coordination` | `warmup/breathing_regulation/internal_pressure_management` | `rehearse_breath_bracing_coordination` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `court_wheelchair_brake_turn_accelerate` | `main_training/speed_power/braking_redirection` | `improve_reacceleration_after_braking` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `court_wheelchair_brake_turn_accelerate` | `main_training/speed_power/repeated_multidirectional_displacement` | `increase_multidirectional_speed` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `drop_rebound_jump` | `main_training/speed_power/elastic_reactive_action` | `increase_reactive_strength` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `goalball_roll_throw_to_goal` | `main_training/technique_skill/contextual_technical_application` | `integrate_skill_in_task_context` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `goalball_roll_throw_to_goal` | `main_training/technique_skill/target_oriented_precision` | `improve_target_spatial_precision` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `judo_ippon_seoi_nage_partner_throw` | `main_training/technique_skill/contextual_technical_application` | `integrate_skill_in_task_context` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `judo_ippon_seoi_nage_partner_throw` | `main_training/technique_skill/repeated_motor_sequence` | `learn_technical_sequence` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `kneeling_child_pose_lengthening_hold` | `main_training/flexibility/sustained_lengthening` | `maintain_tolerated_passive_range` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `lateral_shuffle_shuttle` | `main_training/cardio_conditioning/repeated_multidirectional_displacement` | `increase_repeated_change_of_direction_endurance` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `lateral_shuffle_shuttle` | `warmup/cardio_conditioning/repeated_multidirectional_displacement` | `rehearse_change_of_direction_patterns` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `quadruped_active_hip_circumduction` | `activation/mobility/active_joint_exploration` | `activate_joint_stabilizers_through_range` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `quadruped_active_hip_circumduction` | `main_training/mobility/active_joint_exploration` | `improve_joint_control_through_range` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `quadruped_active_hip_circumduction` | `prevention/mobility/active_joint_exploration` | `increase_end_range_control_capacity` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `quadruped_cat_camel` | `main_training/mobility/segmental_dissociation` | `improve_independent_segment_motion` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `quadruped_cat_camel` | `recovery/mobility/segmental_dissociation` | `resume_comfortable_segmental_motion_after_effort` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `quadruped_cat_camel` | `warmup/mobility/segmental_dissociation` | `prepare_selective_segment_control` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `racing_wheelchair_sprint` | `main_training/speed_power/cyclic_locomotion` | `increase_maximal_locomotor_speed` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `seated_90_90_hip_switch` | `main_training/mobility/integrated_chain_mobility` | `improve_chain_coordination_through_range` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `seated_90_90_hip_switch` | `main_training/mobility/range_transition` | `improve_transition_between_ranges` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `seated_90_90_hip_switch` | `prevention/mobility/range_transition` | `improve_control_between_positions` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `seated_90_90_hip_switch` | `warmup/mobility/range_transition` | `rehearse_session_specific_position_changes` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `seated_self_assisted_trunk_rotation_hold` | `main_training/flexibility/sustained_lengthening` | `maintain_tolerated_passive_range` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `seated_thorax_pelvis_dissociation` | `main_training/motor_control_coordination/segmental_dissociation` | `improve_selective_segmental_control` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `seated_thorax_pelvis_dissociation` | `warmup/motor_control_coordination/segmental_dissociation` | `prepare_selective_segment_control` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `shoulder_wall_slide` | `activation/mobility/supported_loaded_mobility` | `activate_stabilizers_in_loaded_range` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `shoulder_wall_slide` | `prevention/mobility/supported_loaded_mobility` | `improve_control_in_loaded_range` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `shoulder_wall_slide` | `warmup/mobility/supported_loaded_mobility` | `prepare_supported_loaded_ranges` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `side_lying_open_book_rotation` | `main_training/mobility/segmental_dissociation` | `improve_rotational_dissociation_control` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `side_lying_open_book_rotation` | `prevention/mobility/segmental_dissociation` | `maintain_rotational_dissociation_capacity` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `side_lying_open_book_rotation` | `warmup/mobility/segmental_dissociation` | `prepare_rotational_tasks` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `supine_partner_assisted_hamstring_stretch` | `main_training/flexibility/assisted_lengthening` | `increase_passive_range_of_motion` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `supine_partner_assisted_hamstring_stretch` | `recovery/flexibility/assisted_lengthening` | `resume_comfortable_range_with_support_after_effort` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `supported_standing_active_hip_circumduction` | `main_training/mobility/active_joint_exploration` | `increase_active_joint_range_of_motion` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `supported_standing_active_hip_circumduction` | `prevention/mobility/active_joint_exploration` | `increase_end_range_control_capacity` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `supported_standing_active_hip_circumduction` | `warmup/mobility/active_joint_exploration` | `prepare_required_joint_ranges` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `table_tennis_irregular_forehand_backhand_response` | `main_training/technique_skill/contextual_technical_application` | `improve_perception_action_coupling` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `table_tennis_irregular_forehand_backhand_response` | `main_training/technique_skill/stimulus_response_decision` | `improve_stimulus_response_mapping` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |
| `table_tennis_irregular_forehand_backhand_response` | `main_training/technique_skill/technical_variability_adaptation` | `develop_adaptable_skill` | `compatibility_status = pending_review` na fonte | revisão especializada da relação |

## Relações conditional de exercícios não aprovados

Foram excluídas 13 relações `conditional` porque pertencem a exercícios `specialist_review`.

| Exercício | Percurso | Intenção |
|---|---|---|
| `forward_lean_release_recovery_step` | `main_training/motor_control_coordination/reactive_adjustment` | `improve_reactive_control` |
| `forward_lean_release_recovery_step` | `prevention/motor_control_coordination/reactive_adjustment` | `increase_unexpected_perturbation_tolerance` |
| `forward_lean_release_recovery_step` | `return_to_function/motor_control_coordination/reactive_adjustment` | `restore_reactive_control` |
| `quadruped_active_hip_circumduction` | `main_training/motor_control_coordination/segmental_dissociation` | `improve_selective_segmental_control` |
| `seated_90_90_hip_switch` | `main_training/motor_control_coordination/repeated_motor_sequence` | `improve_sequence_transition_control` |
| `side_lying_open_book_rotation` | `main_training/motor_control_coordination/segmental_dissociation` | `improve_selective_segmental_control` |
| `side_lying_open_book_rotation` | `warmup/motor_control_coordination/segmental_dissociation` | `prepare_selective_segment_control` |
| `treadmill_slip_recovery_step` | `main_training/motor_control_coordination/reactive_adjustment` | `improve_reactive_control` |
| `treadmill_slip_recovery_step` | `prevention/motor_control_coordination/reactive_adjustment` | `increase_unexpected_perturbation_tolerance` |
| `treadmill_slip_recovery_step` | `return_to_function/motor_control_coordination/reactive_adjustment` | `restore_reactive_control` |
| `treadmill_trip_recovery_step` | `main_training/motor_control_coordination/reactive_adjustment` | `improve_reactive_control` |
| `treadmill_trip_recovery_step` | `prevention/motor_control_coordination/reactive_adjustment` | `increase_unexpected_perturbation_tolerance` |
| `treadmill_trip_recovery_step` | `return_to_function/motor_control_coordination/reactive_adjustment` | `restore_reactive_control` |

## Condicionais diferidas dos 49 aprovados

Foram classificadas e diferidas 66 relações. Nenhuma foi transformada em relação automaticamente apresentável.

| Relation ID | Classe | Base da decisão |
|---|---|---|
| `basketball_set_shot_to_basket__warmup__technique_skill__target_oriented_precision__prepare_target_control` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `clockwise_four_quadrant_step_sequence__activation__motor_control_coordination__repeated_motor_sequence__prime_sequence_timing` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `clockwise_four_quadrant_step_sequence__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `continuous_stair_ascent__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `countermovement_jump__warmup__speed_power__ballistic_projection__rehearse_landing_or_reception` | `unresolved_product_logic` | A condição depende de finalidade da sessão, dose, intensidade, transferência ou outra lógica de produto ainda inexistente. |
| `diaphragmatic_breathing__cooldown__breathing_regulation__voluntary_breath_cycle_control__transition_breathing_toward_rest` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `diaphragmatic_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `diaphragmatic_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `diaphragmatic_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `diaphragmatic_breathing__return_to_function__breathing_regulation__voluntary_breath_cycle_control__restore_voluntary_breath_control` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `diaphragmatic_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `doorway_pectoral_stretch__warmup__flexibility__assisted_lengthening__prepare_required_joint_ranges` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `football_directional_first_touch__warmup__technique_skill__contextual_technical_application__rehearse_familiar_skill` | `unresolved_product_logic` | A condição depende de finalidade da sessão, dose, intensidade, transferência ou outra lógica de produto ainda inexistente. |
| `front_to_back_leg_swing__activation__flexibility__dynamic_lengthening__prime_dynamic_end_range_control` | `unresolved_product_logic` | A condição depende de finalidade da sessão, dose, intensidade, transferência ou outra lógica de produto ainda inexistente. |
| `full_body_elliptical__warmup__cardio_conditioning__repetitive_rhythmic_movement__raise_whole_body_temperature` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `lateral_costal_breathing__main_training__breathing_regulation__interoceptive_monitoring_adjustment__improve_awareness_of_internal_body_signals` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `lateral_costal_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `lateral_leg_swing__prevention__flexibility__dynamic_lengthening__maintain_functional_dynamic_range` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `march_in_place_to_external_beat__activation__motor_control_coordination__rhythm_synchronization__prime_external_cue_synchronization` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `march_in_place_to_external_beat__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `march_in_place_to_external_beat__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `march_in_place_to_external_beat__warmup__motor_control_coordination__rhythm_synchronization__rehearse_external_rhythm` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `marching_in_place__recovery__cardio_conditioning__repetitive_rhythmic_movement__resume_gentle_rhythmic_movement_after_effort` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `marching_in_place__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `unresolved_product_logic` | A condição depende de finalidade da sessão, dose, intensidade, transferência ou outra lógica de produto ainda inexistente. |
| `overground_running__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `overground_walking__cooldown__cardio_conditioning__cyclic_locomotion__facilitate_transition_to_rest` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `overground_walking__recovery__cardio_conditioning__cyclic_locomotion__resume_comfortable_locomotion_after_effort` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `overground_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `paced_breathing__activation__breathing_regulation__voluntary_breath_cycle_control__prime_respiratory_control` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `paced_breathing__cooldown__breathing_regulation__autonomic_modulation__transition_arousal_toward_rest` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `paced_breathing__main_training__breathing_regulation__autonomic_modulation__improve_arousal_self_regulation` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `paced_breathing__prevention__breathing_regulation__autonomic_modulation__build_state_regulation_capacity` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `paced_breathing__prevention__breathing_regulation__voluntary_breath_cycle_control__build_breath_control_capacity` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `paced_breathing__recovery__breathing_regulation__autonomic_modulation__support_post_effort_downregulation` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `paced_breathing__recovery__breathing_regulation__voluntary_breath_cycle_control__resume_comfortable_breathing_after_effort` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `paced_breathing__warmup__breathing_regulation__autonomic_modulation__establish_suitable_preparation_state` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `paced_breathing__warmup__breathing_regulation__voluntary_breath_cycle_control__prepare_pre_activity_breath_control` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `seated_butterfly_adductor_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `seated_single_leg_hamstring_stretch__cooldown__flexibility__sustained_lengthening__release_perceived_tension` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `single_leg_stance__activation__motor_control_coordination__postural_stabilization__prime_postural_stability` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `single_leg_stance__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `sprint_to_controlled_stop__warmup__speed_power__braking_redirection__prepare_deceleration_mechanics` | `unresolved_product_logic` | A condição depende de finalidade da sessão, dose, intensidade, transferência ou outra lógica de produto ainda inexistente. |
| `standing_gastrocnemius_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `standing_gastrocnemius_wall_stretch__warmup__flexibility__sustained_lengthening__prepare_required_joint_ranges` | `unresolved_product_logic` | A condição depende de finalidade da sessão, dose, intensidade, transferência ou outra lógica de produto ainda inexistente. |
| `standing_multidirectional_weight_shift__recovery__motor_control_coordination__base_of_support_control__maintain_gentle_weight_shift` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `standing_soleus_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__increase_sequence_endurance_under_fatigue` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `static_rowing_ergometer__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `static_rowing_ergometer__warmup__cardio_conditioning__repeated_motor_sequence__rehearse_motor_sequence` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `static_rowing_ergometer__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `stationary_arm_crank_ergometry__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `supine_hamstring_strap_stretch__recovery__flexibility__assisted_lengthening__resume_comfortable_range_with_support_after_effort` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `supine_self_assisted_hamstring_stretch__cooldown__flexibility__assisted_lengthening__release_perceived_tension` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `tandem_stance__activation__motor_control_coordination__base_of_support_control__prime_support_control` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `tandem_stance__prevention__motor_control_coordination__base_of_support_control__increase_reduced_base_tolerance` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `tandem_walk__prevention__motor_control_coordination__base_of_support_control__increase_balance_control_capacity` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `tandem_walk__warmup__motor_control_coordination__base_of_support_control__prepare_balance_control` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `treadmill_walking__recovery__cardio_conditioning__cyclic_locomotion__maintain_light_cardiorespiratory_activity` | `unresolved_product_logic` | A condição depende de finalidade da sessão, dose, intensidade, transferência ou outra lógica de produto ainda inexistente. |
| `treadmill_walking__warmup__cardio_conditioning__cyclic_locomotion__rehearse_locomotor_pattern` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `two_foot_rope_skipping__main_training__cardio_conditioning__repetitive_rhythmic_movement__improve_coordination_under_sustained_effort` | `unresolved_product_logic` | A condição depende de finalidade da sessão, dose, intensidade, transferência ou outra lógica de produto ainda inexistente. |
| `two_foot_rope_skipping__main_training__motor_control_coordination__rhythm_synchronization__improve_interlimb_coordination` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `two_foot_rope_skipping__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `two_foot_rope_skipping__warmup__motor_control_coordination__rhythm_synchronization__prepare_interlimb_synchronization` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `two_point_sprint_start__warmup__speed_power__explosive_acceleration__rehearse_acceleration_mechanics` | `unresolved_product_logic` | A condição depende de finalidade da sessão, dose, intensidade, transferência ou outra lógica de produto ainda inexistente. |
| `upright_stationary_cycling__recovery__cardio_conditioning__cyclic_propulsion__maintain_light_cardiorespiratory_activity` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |
| `upright_stationary_cycling__warmup__cardio_conditioning__cyclic_propulsion__rehearse_propulsive_cycle` | `eligibility_engine_required` | A fonte condiciona a relação ao estado, competência, conforto, sintomas, controlo ou elegibilidade da pessoa. |

## Candidatos diferidos para muscular_capacity

Foram preservados 159 nomes normalizados. Nenhum entra no registry técnico principal.

| Nome normalizado | Nome observado | Agentes | Discovery items | Estado |
|---|---|---|---:|---|
| active isolated stretching | Active isolated stretching | D1 | 1 | `deferred_to_muscular_boundary_review` |
| agachamento assistido por suspension trainer | Agachamento assistido por suspension trainer | C1 | 1 | `deferred_to_muscular_boundary_review` |
| agachamento com alcance acima da cabeca | Agachamento com alcance acima da cabeça | C2 | 1 | `deferred_to_muscular_boundary_review` |
| agachamento com barra atras | Agachamento com barra atrás | F2 | 1 | `deferred_to_muscular_boundary_review` |
| agachamento com salto carregado | Agachamento com salto carregado | B2 | 1 | `deferred_to_muscular_boundary_review` |
| agachamento com salto e carga externa | agachamento com salto e carga externa | B1 | 1 | `deferred_to_muscular_boundary_review` |
| agachamento cossack | Agachamento Cossack | C1 | 1 | `deferred_to_muscular_boundary_review` |
| agachamento cossaco | Agachamento cossaco | C2 | 1 | `deferred_to_muscular_boundary_review` |
| agachamento profundo assistido por suspensao | Agachamento profundo assistido por suspensão | C2 | 1 | `deferred_to_muscular_boundary_review` |
| agachamento unipodal | Agachamento unipodal | E2 | 1 | `deferred_to_muscular_boundary_review` |
| ajustes posturais a perturbacoes manuais em pe | Ajustes posturais a perturbações manuais em pé | E2 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento ajoelhado do grande dorsal com apoio no banco | Alongamento ajoelhado do grande dorsal com apoio no banco | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento autoassistido do levantador da escapula | Alongamento autoassistido do levantador da escápula | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento autoassistido do trapezio superior | Alongamento autoassistido do trapézio superior | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento balistico | Alongamento balístico | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento borboleta dos adutores | Alongamento borboleta dos adutores | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de adutores sentado em afastamento lateral | Alongamento de adutores sentado em afastamento lateral | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de adutores supino assistido por parceiro | Alongamento de adutores supino assistido por parceiro | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de adutores supino com correia | Alongamento de adutores supino com correia | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de flexores da anca em meio ajoelhado | Alongamento de flexores da anca em meio-ajoelhado | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de flexores da anca na borda de uma marquesa | Alongamento de flexores da anca na borda de uma marquesa | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de gemeos na parede com joelho estendido | Alongamento de gémeos na parede com joelho estendido | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de gemeos sentado com toalha | Alongamento de gémeos sentado com toalha | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de isquiotibiais com ressaltos | Alongamento de isquiotibiais com ressaltos | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de isquiotibiais supino assistido por parceiro | Alongamento de isquiotibiais supino assistido por parceiro | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de isquiotibiais supino autoassistido pelas maos | Alongamento de isquiotibiais supino autoassistido pelas mãos | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de isquiotibiais supino com correia | Alongamento de isquiotibiais supino com correia | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de quadricipite de pe autoassistido | Alongamento de quadricípite de pé autoassistido | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de quadricipite em decubito lateral | Alongamento de quadricípite em decúbito lateral | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de quadricipite em marcha | Alongamento de quadricípite em marcha | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de quadricipite prono assistido por parceiro | Alongamento de quadricípite prono assistido por parceiro | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de quadricipite prono com correia | Alongamento de quadricípite prono com correia | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de rotacao do tronco sentado | Alongamento de rotação do tronco sentado | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento de triceps acima da cabeca | Alongamento de tríceps acima da cabeça | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento do solear na parede com joelho fletido | Alongamento do solear na parede com joelho fletido | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento dos extensores do punho | Alongamento dos extensores do punho | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento dos flexores do punho | Alongamento dos flexores do punho | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento em posicao de crianca com alcance | Alongamento em posição de criança com alcance | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento frog dos adutores | Alongamento frog dos adutores | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento gluteo figure four supino | Alongamento glúteo figure-four supino | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento joelho ao peito supino | Alongamento joelho ao peito supino | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento lateral da anca de pe junto a parede | Alongamento lateral da anca de pé junto à parede | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento lateral do tronco de pe | Alongamento lateral do tronco de pé | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento peitoral assistido por parceiro | Alongamento peitoral assistido por parceiro | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento peitoral na ombreira | Alongamento peitoral na ombreira | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento pigeon da anca | Alongamento pigeon da anca | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento posterior do ombro cruzado | Alongamento posterior do ombro cruzado | D1 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento sob carga em posicao alongada | Alongamento sob carga em posição alongada | D2 | 1 | `deferred_to_muscular_boundary_review` |
| alongamento unilateral de isquiotibiais sentado | Alongamento unilateral de isquiotibiais sentado | D1 | 1 | `deferred_to_muscular_boundary_review` |
| amplitude passiva realizada por cuidador | Amplitude passiva realizada por cuidador | D1 | 1 | `deferred_to_muscular_boundary_review` |
| animal flow | Animal Flow | C2 | 1 | `deferred_to_muscular_boundary_review` |
| arm bar com kettlebell | Arm bar com kettlebell | C1, C2 | 2 | `deferred_to_muscular_boundary_review` |
| ativacao abdominal profunda com respiracao | Ativação abdominal profunda com respiração | G1 | 1 | `deferred_to_muscular_boundary_review` |
| balanco alternado dos bracos acima da cabeca | Balanço alternado dos braços acima da cabeça | D1 | 1 | `deferred_to_muscular_boundary_review` |
| balanco com kettlebell | Balanço com kettlebell, balanço com kettlebell | B1, B2 | 2 | `deferred_to_muscular_boundary_review` |
| balanco da perna a frente e atras | Balanço da perna à frente e atrás | D1 | 1 | `deferred_to_muscular_boundary_review` |
| balanco de flexores da anca em passada fixa | Balanço de flexores da anca em passada fixa | D1 | 1 | `deferred_to_muscular_boundary_review` |
| balanco de kettlebell | balanço de kettlebell | A1 | 1 | `deferred_to_muscular_boundary_review` |
| balanco em agachamento profundo com contrapeso | Balanço em agachamento profundo com contrapeso | C2 | 1 | `deferred_to_muscular_boundary_review` |
| balanco horizontal dos bracos | Balanço horizontal dos braços | D1 | 1 | `deferred_to_muscular_boundary_review` |
| balanco lateral da perna | Balanço lateral da perna | D1 | 1 | `deferred_to_muscular_boundary_review` |
| batimento de cordas de treino | batimento de cordas de treino | B1 | 1 | `deferred_to_muscular_boundary_review` |
| bear crawl | bear crawl | A1 | 1 | `deferred_to_muscular_boundary_review` |
| bridge hold de ginastica | Bridge hold de ginástica | D1 | 1 | `deferred_to_muscular_boundary_review` |
| burpee | burpee | A1 | 1 | `deferred_to_muscular_boundary_review` |
| burpee repetido | burpee repetido | A2 | 1 | `deferred_to_muscular_boundary_review` |
| cat cow | Cat-cow | D1 | 1 | `deferred_to_muscular_boundary_review` |
| circulo de ombros com indian club | Círculo de ombros com indian club | C2 | 1 | `deferred_to_muscular_boundary_review` |
| circulos do tornozelo | Círculos do tornozelo | D1 | 1 | `deferred_to_muscular_boundary_review` |
| circulos dos bracos | Círculos dos braços | D1 | 1 | `deferred_to_muscular_boundary_review` |
| circunducao da anca em quadrupedia | Circundução da anca em quadrupedia | C2 | 1 | `deferred_to_muscular_boundary_review` |
| coordenacao inspiracao estabilizacao expiracao sob carga | Coordenação inspiração-estabilização-expiração sob carga | G1 | 1 | `deferred_to_muscular_boundary_review` |
| coordenacao respiratoria com contracao do pavimento pelvico | Coordenação respiratória com contração do pavimento pélvico | G1 | 1 | `deferred_to_muscular_boundary_review` |
| derivados dos levantamentos olimpicos | Derivados dos levantamentos olímpicos | B2 | 1 | `deferred_to_muscular_boundary_review` |
| deslizamento neural | Deslizamento neural | D1 | 1 | `deferred_to_muscular_boundary_review` |
| deslizamento neurodinamico | Deslizamento neurodinâmico | D2 | 1 | `deferred_to_muscular_boundary_review` |
| dissociacao pelvica sentada em bola de estabilidade | Dissociação pélvica sentada em bola de estabilidade | E2 | 1 | `deferred_to_muscular_boundary_review` |
| downward facing dog | Downward-facing dog | D1 | 1 | `deferred_to_muscular_boundary_review` |
| elevacao a partir de 90 90 | Elevação a partir de 90/90 | C2 | 1 | `deferred_to_muscular_boundary_review` |
| elevacao de gemeos em pe | Elevação de gémeos em pé | E2 | 1 | `deferred_to_muscular_boundary_review` |
| elevacao dos calcanhares em pe | Elevação dos calcanhares em pé | E1 | 1 | `deferred_to_muscular_boundary_review` |
| empurrar treno | empurrar trenó | A1 | 1 | `deferred_to_muscular_boundary_review` |
| empurrar treno em corrida | Empurrar trenó em corrida | B2 | 1 | `deferred_to_muscular_boundary_review` |
| empurrar treno repetidamente | empurrar trenó repetidamente | A2 | 1 | `deferred_to_muscular_boundary_review` |
| equilibrio bipodal em prancha oscilante | Equilíbrio bipodal em prancha oscilante | E2 | 1 | `deferred_to_muscular_boundary_review` |
| expiracao resistida por balao | expiracao resistida por balao | G2 | 1 | `deferred_to_muscular_boundary_review` |
| extensao alternada de membros em decubito dorsal | Extensão alternada de membros em decúbito dorsal | E1 | 1 | `deferred_to_muscular_boundary_review` |
| extensao contralateral em quadrupedia | Extensão contralateral em quadrupedia | E1, E2 | 2 | `deferred_to_muscular_boundary_review` |
| flexao de bracos pliometrica | flexão de braços pliométrica | B1 | 1 | `deferred_to_muscular_boundary_review` |
| flexao passiva do ombro assistida por parceiro | Flexão passiva do ombro assistida por parceiro | D1 | 1 | `deferred_to_muscular_boundary_review` |
| flexao passiva do ombro supino com bastao | Flexão passiva do ombro supino com bastão | D1 | 1 | `deferred_to_muscular_boundary_review` |
| foam rolling | Foam rolling | D1 | 1 | `deferred_to_muscular_boundary_review` |
| halo com kettlebell | Halo com kettlebell | C2 | 1 | `deferred_to_muscular_boundary_review` |
| inchworm | Inchworm | D1, D2 | 2 | `deferred_to_muscular_boundary_review` |
| inchworm com caminhada das maos | Inchworm com caminhada das mãos | C1 | 1 | `deferred_to_muscular_boundary_review` |
| inclinacao pelvica deitado | Inclinação pélvica deitado | E1 | 1 | `deferred_to_muscular_boundary_review` |
| jefferson curl | Jefferson curl | C1, C2 | 2 | `deferred_to_muscular_boundary_review` |
| jefferson curl carregado | Jefferson curl carregado | D1 | 1 | `deferred_to_muscular_boundary_review` |
| joelho ao peito em marcha | Joelho ao peito em marcha | D1 | 1 | `deferred_to_muscular_boundary_review` |
| lancamento de barra em supino | lançamento de barra em supino | B1 | 1 | `deferred_to_muscular_boundary_review` |
| levantamento terra romeno unipodal | Levantamento terra romeno unipodal | E2 | 1 | `deferred_to_muscular_boundary_review` |
| levantamento turco | Levantamento turco | C2 | 1 | `deferred_to_muscular_boundary_review` |
| levantar a partir de shin box | Levantar a partir de shin-box | C1 | 1 | `deferred_to_muscular_boundary_review` |
| levantar e sentar numa cadeira | Levantar e sentar numa cadeira | E1 | 1 | `deferred_to_muscular_boundary_review` |
| lunge em marcha com alcance acima da cabeca | Lunge em marcha com alcance acima da cabeça | D1 | 1 | `deferred_to_muscular_boundary_review` |
| mace 360 | Mace 360 | C2 | 1 | `deferred_to_muscular_boundary_review` |
| manutencao da postura bipodal estavel | Manutenção da postura bipodal estável | E2 | 1 | `deferred_to_muscular_boundary_review` |
| manutencao de equilibrio em meio ajoelhado | Manutenção de equilíbrio em meio-ajoelhado | E2 | 1 | `deferred_to_muscular_boundary_review` |
| marcha com carga transportada | marcha com carga transportada | A2 | 1 | `deferred_to_muscular_boundary_review` |
| marcha com perna estendida | Marcha com perna estendida | D1 | 1 | `deferred_to_muscular_boundary_review` |
| mobilizacao articular manual | Mobilização articular manual | D1 | 1 | `deferred_to_muscular_boundary_review` |
| mountain climber | mountain climber | A1 | 1 | `deferred_to_muscular_boundary_review` |
| mountain climber repetido | mountain climber repetido | A2 | 1 | `deferred_to_muscular_boundary_review` |
| movimentos de halterofilismo | movimentos de halterofilismo | B1 | 1 | `deferred_to_muscular_boundary_review` |
| mudanca de direcao reativa repetida | mudança de direção reativa repetida | A1 | 1 | `deferred_to_muscular_boundary_review` |
| nadador do ombro em decubito ventral | Nadador do ombro em decúbito ventral | C2 | 1 | `deferred_to_muscular_boundary_review` |
| nordic hamstring | Nordic hamstring | D1 | 1 | `deferred_to_muscular_boundary_review` |
| ondas alternadas com cordas de batalha | ondas alternadas com cordas de batalha | A2 | 1 | `deferred_to_muscular_boundary_review` |
| ondas alternadas com cordas navais | ondas alternadas com cordas navais | A1 | 1 | `deferred_to_muscular_boundary_review` |
| padrao dentro dentro fora fora em escada de coordenacao | Padrão dentro-dentro-fora-fora em escada de coordenação | E1 | 1 | `deferred_to_muscular_boundary_review` |
| passe alternado a parede com os pes | Passe alternado à parede com os pés | E1 | 1 | `deferred_to_muscular_boundary_review` |
| peso morto romeno | Peso morto romeno | D1 | 1 | `deferred_to_muscular_boundary_review` |
| pnf contract relax | PNF contract-relax | D1 | 1 | `deferred_to_muscular_boundary_review` |
| pnf contract relax antagonist contract | PNF contract-relax-antagonist-contract | D1, D2 | 2 | `deferred_to_muscular_boundary_review` |
| pnf hold relax | PNF hold-relax | D1 | 1 | `deferred_to_muscular_boundary_review` |
| press anti rotacao com cabo ou elastico | Press anti-rotação com cabo ou elástico | E2 | 1 | `deferred_to_muscular_boundary_review` |
| press up prono lombar | Press-up prono lombar | D1 | 1 | `deferred_to_muscular_boundary_review` |
| progressao tecnica de clean com barra | Progressão técnica de clean com barra | F1 | 1 | `deferred_to_muscular_boundary_review` |
| push press | Push press | B2 | 1 | `deferred_to_muscular_boundary_review` |
| rock back em quadrupedia com coluna estavel | Rock-back em quadrupedia com coluna estável | E1 | 1 | `deferred_to_muscular_boundary_review` |
| rotacao externa passiva do ombro com bastao | Rotação externa passiva do ombro com bastão | D1 | 1 | `deferred_to_muscular_boundary_review` |
| rotacao interna passiva do ombro com bastao atras das costas | Rotação interna passiva do ombro com bastão atrás das costas | D1 | 1 | `deferred_to_muscular_boundary_review` |
| rotina de alongamento dinamico | Rotina de alongamento dinâmico | D1 | 1 | `deferred_to_muscular_boundary_review` |
| rotina de alongamento estatico | Rotina de alongamento estático | D1 | 1 | `deferred_to_muscular_boundary_review` |
| saltar a corda | Saltar à corda | E1 | 1 | `deferred_to_muscular_boundary_review` |
| salto alternado em afundo | salto alternado em afundo | B1 | 1 | `deferred_to_muscular_boundary_review` |
| sentar e levantar | Sentar e levantar | C2 | 1 | `deferred_to_muscular_boundary_review` |
| sentar e levantar da cadeira | Sentar e levantar da cadeira | E2 | 1 | `deferred_to_muscular_boundary_review` |
| sequencia em escada de agilidade | sequência em escada de agilidade | A1 | 1 | `deferred_to_muscular_boundary_review` |
| sleeper stretch do ombro | Sleeper stretch do ombro | D1 | 1 | `deferred_to_muscular_boundary_review` |
| split frontal assistido por parede | Split frontal assistido por parede | D1 | 1 | `deferred_to_muscular_boundary_review` |
| split lateral assistido por blocos | Split lateral assistido por blocos | D1 | 1 | `deferred_to_muscular_boundary_review` |
| split squat carregado com enfase em extensao da anca | Split squat carregado com ênfase em extensão da anca | D1 | 1 | `deferred_to_muscular_boundary_review` |
| sprint | sprint | A1 | 1 | `deferred_to_muscular_boundary_review` |
| supino balistico com libertacao da barra | Supino balístico com libertação da barra | B2 | 1 | `deferred_to_muscular_boundary_review` |
| suspensao passiva na barra | Suspensão passiva na barra | D1, D2 | 2 | `deferred_to_muscular_boundary_review` |
| sustentacao de split frontal | Sustentação de split frontal | D1 | 1 | `deferred_to_muscular_boundary_review` |
| sustentacao de split lateral | Sustentação de split lateral | D1 | 1 | `deferred_to_muscular_boundary_review` |
| transferencia anteroposterior de peso em pe | Transferência anteroposterior de peso em pé | E2 | 1 | `deferred_to_muscular_boundary_review` |
| transferencia lateral cossaca com apoio | Transferência lateral cossaca com apoio | C2 | 1 | `deferred_to_muscular_boundary_review` |
| transferencia lateral dinamica para alongamento de adutores | Transferência lateral dinâmica para alongamento de adutores | D1 | 1 | `deferred_to_muscular_boundary_review` |
| transporte carregado | transporte carregado | A1 | 1 | `deferred_to_muscular_boundary_review` |
| treino muscular expiratorio com carga limiar | Treino muscular expiratório com carga limiar | G1 | 1 | `deferred_to_muscular_boundary_review` |
| treino muscular expiratorio com resistencia | treino muscular expiratorio com resistencia | G2 | 1 | `deferred_to_muscular_boundary_review` |
| treino muscular inspiratorio com carga limiar | Treino muscular inspiratório com carga limiar | G1 | 1 | `deferred_to_muscular_boundary_review` |
| treino muscular inspiratorio com resistencia | treino muscular inspiratorio com resistencia | G2 | 1 | `deferred_to_muscular_boundary_review` |
| varredura dinamica de isquiotibiais em marcha | Varredura dinâmica de isquiotibiais em marcha | D1 | 1 | `deferred_to_muscular_boundary_review` |
| world s greatest stretch | World's greatest stretch | D1 | 1 | `deferred_to_muscular_boundary_review` |
| yoga | Yoga | D1 | 1 | `deferred_to_muscular_boundary_review` |

## Outras exclusões normalizadas

| Categoria | Itens de descoberta excluídos |
|---|---:|
| Protocolos | 80 |
| Prescrições | 95 |
| Atividades amplas ou não selecionáveis | 60 |
| Não-exercícios | 9 |
| Itens rejeitados normalizados | 69 |
| Multimédia não aprovada | 49 registos, todos com `media_status = not_yet_approved` |
