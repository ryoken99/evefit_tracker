# EveFit Exercise Implementation Media Requirements Wave1 v0.1

Nenhuma imagem, vídeo, URL ou media ID foi aprovado ou incorporado.

| Exercise ID | Imagem necessária | Vídeo necessário | Estado |
|---|---:|---:|---|
| `active_ankle_circumduction` | true | true | `not_yet_approved` |
| `active_ankle_dorsiflexion_plantarflexion` | true | true | `not_yet_approved` |
| `archery_shot_cycle_to_target` | true | true | `not_yet_approved` |
| `basketball_set_shot_to_basket` | true | true | `not_yet_approved` |
| `bilateral_pogo_jump` | true | true | `not_yet_approved` |
| `boxing_jab_cross_to_focus_mitts` | true | true | `not_yet_approved` |
| `clockwise_four_quadrant_step_sequence` | true | true | `not_yet_approved` |
| `continuous_stair_ascent` | true | true | `not_yet_approved` |
| `countermovement_jump` | true | true | `not_yet_approved` |
| `diaphragmatic_breathing` | true | true | `not_yet_approved` |
| `doorway_pectoral_stretch` | true | true | `not_yet_approved` |
| `football_directional_first_touch` | true | true | `not_yet_approved` |
| `front_to_back_leg_swing` | true | true | `not_yet_approved` |
| `full_body_elliptical` | true | true | `not_yet_approved` |
| `half_kneeling_ankle_dorsiflexion_rock` | true | true | `not_yet_approved` |
| `lateral_costal_breathing` | true | true | `not_yet_approved` |
| `lateral_leg_swing` | true | true | `not_yet_approved` |
| `linear_sprint` | true | true | `not_yet_approved` |
| `manual_wheelchair_propulsion_overground` | true | true | `not_yet_approved` |
| `march_in_place_to_external_beat` | true | true | `not_yet_approved` |
| `marching_in_place` | true | true | `not_yet_approved` |
| `overground_running` | true | true | `not_yet_approved` |
| `overground_walking` | true | true | `not_yet_approved` |
| `paced_breathing` | true | true | `not_yet_approved` |
| `plyometric_push_up` | true | true | `not_yet_approved` |
| `respiratory_sensation_observation` | true | true | `not_yet_approved` |
| `seated_butterfly_adductor_stretch` | true | true | `not_yet_approved` |
| `seated_single_leg_hamstring_stretch` | true | true | `not_yet_approved` |
| `seated_supported_thoracic_extension` | true | true | `not_yet_approved` |
| `single_leg_stance` | true | true | `not_yet_approved` |
| `sled_resisted_sprint` | true | true | `not_yet_approved` |
| `sprint_to_controlled_stop` | true | true | `not_yet_approved` |
| `standing_broad_jump` | true | true | `not_yet_approved` |
| `standing_gastrocnemius_wall_stretch` | true | true | `not_yet_approved` |
| `standing_medicine_ball_chest_pass` | true | true | `not_yet_approved` |
| `standing_multidirectional_weight_shift` | true | true | `not_yet_approved` |
| `standing_soleus_wall_stretch` | true | true | `not_yet_approved` |
| `static_rowing_ergometer` | true | true | `not_yet_approved` |
| `stationary_arm_crank_ergometry` | true | true | `not_yet_approved` |
| `supine_hamstring_strap_stretch` | true | true | `not_yet_approved` |
| `supine_heel_slide` | true | true | `not_yet_approved` |
| `supine_self_assisted_hamstring_stretch` | true | true | `not_yet_approved` |
| `tandem_stance` | true | true | `not_yet_approved` |
| `tandem_walk` | true | true | `not_yet_approved` |
| `treadmill_walking` | true | true | `not_yet_approved` |
| `two_foot_rope_skipping` | true | true | `not_yet_approved` |
| `two_point_sprint_start` | true | true | `not_yet_approved` |
| `upright_stationary_cycling` | true | true | `not_yet_approved` |
| `volleyball_forearm_pass_to_target` | true | true | `not_yet_approved` |

A seleção, produção, licenciamento, validação técnica e aprovação editorial de multimédia permanecem fora desta missão.
