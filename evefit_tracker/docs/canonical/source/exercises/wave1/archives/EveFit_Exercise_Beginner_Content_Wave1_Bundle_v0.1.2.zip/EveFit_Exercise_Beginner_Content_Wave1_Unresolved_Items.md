# EveFit Beginner Content Wave1 — Itens não resolvidos

Campos editoriais pendentes no conteúdo aprovado: 0.

Não existem blockers abertos. Permanecem fora do âmbito: dose, prescrição, elegibilidade individual, eficácia individual, multimédia, implementação e publicação.
