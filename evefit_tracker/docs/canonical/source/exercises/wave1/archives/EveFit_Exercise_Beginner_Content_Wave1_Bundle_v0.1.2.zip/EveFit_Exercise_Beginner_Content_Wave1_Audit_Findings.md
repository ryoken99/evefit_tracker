# EveFit Beginner Content Wave1 — Findings de auditoria

Foram executadas sete auditorias por capacidade e sete especialidades transversais.
Os blockers encontrados foram corrigidos antes desta integração; nenhum exercício failed entrou no master.

## Relatórios

| Relatório | Findings declarados | Menções de blocker | SHA-256 |
|---|---:|---:|---|
| capability/AUD-A_cardio_conditioning.md | 4 | 5 | `fd26f3b725ebdadcee1f7b40b980fe8a21671beae114afc2f099bbb953caec52` |
| capability/AUD-B_speed_power.md | 5 | 5 | `0e8e9dc98004a4a00bec8171100722c10afe02e592b4b26d81b4439f088b2d8e` |
| capability/AUD-C_mobility.md | 4 | 4 | `75ca18b990a44e25e12aea1b4ea2ff8e7169091e9f0c35e3d27ed128ade5094c` |
| capability/AUD-D_flexibility.md | 3 | 4 | `937b5c9eadcfe5361fea02e329809e2176c7440fa167ae8dd8c2a94c19df2498` |
| capability/AUD-E_motor_control_coordination.md | 3 | 4 | `d1a8b196e91ac93d247e540aff6b9f9debf6efc6bd5c83c2f2708ea55603252a` |
| capability/AUD-F_technique_skill.md | 4 | 4 | `d7fbf0bef22915340fcc393b79aad09bca4c72ee7532c57af4cc508d59522a8a` |
| capability/AUD-G_breathing_regulation.md | 4 | 5 | `0341681266ef70bdba9c0eb111325e33b315157a5aa8d9c55f317c7c2df5b0b6` |
| transverse/TRANS-01_product_language_ptpt.md | 7 | 9 | `38262c940386949dbdfd55d808a76577c2fcf2316ac95b3ca643e0f3437762a0` |
| transverse/TRANS-02_biomechanics.md | 8 | 9 | `eb1e07167b73e631af5d0677dbc7315a357ec68d80ebba917942c3cc1edb817e` |
| transverse/TRANS-03_training_scope.md | 6 | 6 | `18ba25461fe2ef8b5fd69c8693c8d0de1e459f4774cf1d24789935cf0aef9eb8` |
| transverse/TRANS-04_safety.md | 8 | 9 | `53ebacd8b848ffd7390ab76cbebfd62b125cc3ff05a574a8759fc90f3a861492` |
| transverse/TRANS-05_accessibility_comprehension.md | 11 | 14 | `63a034eeb0cdb759b9c75b0375604d2ac3d75710b96c06e5def56f348439323f` |
| transverse/TRANS-06_data_consistency.md | 8 | 11 | `998ebeed86b381ad8671a7acf7f222ecb8cff6588b1e5723c8f2808a48df7e53` |
| transverse/TRANS-07_integrity_determinism.md | 8 | 10 | `99594b4984a4d043b1ba96aee6a4982aead78d4ba5b309bd5480ae865c8dcfa4` |

## Revisões aplicadas

| Exercício | Revisão |
|---|---|
| `stationary_arm_crank_ergometry` | Removida a opção de cadeira de rodas não especificada e fechada a primeira configuração com supervisão. |
| `upright_stationary_cycling` | Acrescentada sequência observável de montagem com bicicleta e pedais parados. |
| `two_foot_rope_skipping` | Removido ciclo aberto que podia funcionar como dose implícita. |
| `two_point_sprint_start` | Sincronizados os sinais de alerta e de paragem com uma saída operacional. |
| `two_point_sprint_start` | Tornada obrigatória a supervisão qualificada na primeira exposição. |
| `standing_medicine_ball_chest_pass` | Sincronizados os sinais de alerta e de paragem com uma saída operacional. |
| `standing_broad_jump` | Completada a mecânica observável da receção. |
| `standing_broad_jump` | Sincronizados os sinais de alerta e de paragem com uma saída operacional. |
| `bilateral_pogo_jump` | Removido ciclo aberto que podia funcionar como dose implícita. |
| `linear_sprint` | Sincronizados os sinais de alerta e de paragem com uma saída operacional. |
| `sled_resisted_sprint` | Tornada obrigatória a supervisão qualificada na primeira exposição. |
| `seated_supported_thoracic_extension` | Fechadas a localização e a estabilidade do apoio; removida a sincronização respiratória sem suporte. |
| `supine_hamstring_strap_stretch` | Acrescentadas demonstração inicial e saída segura perante deslizamento da correia. |
| `tandem_stance` | Uniformizado o critério de prontidão sem direção universal. |
| `standing_multidirectional_weight_shift` | Removidos requisitos universais de equipamento pessoal e de apoio. |
| `standing_multidirectional_weight_shift` | Removido ciclo aberto que podia funcionar como dose implícita. |
| `volleyball_forearm_pass_to_target` | Sincronizados os sinais de alerta e de paragem com uma saída operacional. |
| `football_directional_first_touch` | Acrescentado exemplo não universal de superfície de contacto e estabilidade do tornozelo. |
| `football_directional_first_touch` | Sincronizados os sinais de alerta e de paragem com uma saída operacional. |
| `boxing_jab_cross_to_focus_mitts` | Desambiguada a orientação das manoplas e clarificado o pivô do pé de trás. |
| `lateral_costal_breathing` | Tornado condicional o fim relativo ao contacto opcional das mãos. |
| `paced_breathing` | Incluída a via canónica de ritmo escolhido pela pessoa; o sinal externo passou a opcional. |
| `paced_breathing` | Removido ciclo aberto que podia funcionar como dose implícita. |
