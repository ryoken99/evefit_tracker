# AUD-G — Auditoria independente de `breathing_regulation`

## Resultado

**Estado global: revisão obrigatória.**

Foram auditados quatro exercícios e doze artefactos de conteúdo. Três exercícios ficam aprovados ou aprovados com ressalvas editoriais; `paced_breathing` fica bloqueado por uma redução não autorizada da identidade canónica no JSON e no Markdown. Não foram encontradas contagens respiratórias prescritas, retenções impostas, instruções de hiperventilação, tratamento, diagnóstico ou promessas de resultado.

## Âmbito

Exercícios incluídos por `capability_primary == "breathing_regulation"`:

1. `respiratory_sensation_observation` — JSON, Markdown e relatório de investigação;
2. `lateral_costal_breathing` — JSON, Markdown e relatório de investigação;
3. `diaphragmatic_breathing` — JSON, Markdown e relatório de investigação;
4. `paced_breathing` — JSON, Markdown e relatório de investigação.

Foram ainda consultados, apenas para confirmar invariantes, os pacotes `EX-46`, `EX-47`, `EX-48` e `EX-49` em `_beginner_content_workspace/agent_inputs`.

Ficaram fora do âmbito todos os restantes exercícios e todos os relatórios de outros auditores.

## Método

- Seleção mecânica pelo valor de `capability_primary`.
- Comparação por exercício entre JSON, Markdown, relatório de investigação e registo canónico do respetivo pacote.
- Validação de identidade, família, variante/base, risco, equipamento, ambiente, supervisão, elegibilidade, relações e ausência de implementação.
- Leitura técnica das fases de inspiração, transição, expiração, retorno/saída e respetivas instruções de conforto e interrupção.
- Pesquisa de contagens, retenções, dose, cadência universal, hiperventilação induzida, promessas, tratamento, diagnóstico e autorização universal.
- Verificação da distinção entre observação não interventiva, expansão costal lateral, excursão diafragmática e ritmo respiratório.
- Validação mecânica de JSON, ordem das chaves, mínimos contratuais, forma dos erros comuns, estado permitido e normalização Unicode NFC.

## Estados por exercício

| Exercício | Estado | Fundamentação |
|---|---|---|
| `respiratory_sensation_observation` | **Aprovado** | Mantém a tarefa estritamente observacional; não conduz profundidade, via, ritmo ou pausa; distingue descrição de diagnóstico e inclui saída perante sofrimento interoceptivo. |
| `lateral_costal_breathing` | **Aprovado com ressalva editorial** | Define inspiração dirigida aos lados das costelas, transição contínua e expiração confortável; exclui inspiração máxima, retenção, pressão manual e correção clínica de assimetria. Ver F-003. |
| `diaphragmatic_breathing` | **Aprovado com ressalvas editoriais** | Mantém expansão inferior/circunferencial do tronco, permite movimento torácico, não impõe amplitude, ritmo, via ou retenção e enquadra adequadamente supervisão. Ver F-002 e F-004. |
| `paced_breathing` | **Revisão obrigatória** | A segurança, as fases e a ausência de dose/retenção estão adequadas, mas o conteúdo reduz a identidade canónica à modalidade com sinal externo. Ver F-001. |

## Findings

### Grupo A — identidade e invariantes

#### F-001 — A modalidade autoescolhida desaparece de `paced_breathing`

- **Severidade:** média
- **Blocker:** sim
- **Campo:** `short_description_pt_pt`, `beginner_definition_pt_pt`, `what_you_will_do_pt_pt`, `execution_steps_pt_pt`; secções Markdown correspondentes
- **Evidência:** o pacote EX-49 define a identidade como ritmo regular “autoescolhido ou fornecido por um sinal externo” (`EX-49__paced_breathing.json`, linha 15) e preserva execução sem equipamento (`no_equipment_supported: true`, linha 156). O relatório de investigação repete corretamente as duas modalidades (`paced_breathing_research_report_v0.1.md`, linha 11). Porém, o JSON público restringe a definição e a execução à escolha e seguimento de um sinal externo (`paced_breathing_beginner_content_v0.1.json`, linhas 11–13 e 43–51), e o Markdown faz o mesmo (`paced_breathing_beginner_content_v0.1.md`, linhas 18, 22, 28 e 82–89).
- **Impacto:** reduz a identidade canónica, torna opaca a modalidade sem equipamento e cria divergência entre conteúdo e relatório.
- **Revisão requerida:** documentar explicitamente as duas vias canónicas — ritmo regular autoescolhido ou sinal externo opcional — e adaptar preparação, execução e saída para ambas, sem introduzir cadência, contagem ou dose.

### Grupo B — clareza e consistência editorial

#### F-002 — Formulação pouco clara na mudança para a inspiração seguinte

- **Severidade:** baixa
- **Blocker:** não
- **Campo:** `execution_steps_pt_pt[5].instruction_pt_pt`
- **Evidência:** “Passa diretamente para a inspiração seguinte quando o corpo a iniciar” aparece no JSON (`diaphragmatic_breathing_beginner_content_v0.1.json`, linha 62) e no Markdown (`diaphragmatic_breathing_beginner_content_v0.1.md`, linha 54). Embora analisável gramaticalmente, a referência pronominal e o futuro do conjuntivo são pouco imediatos para um principiante absoluto.
- **Revisão requerida:** substituir por formulação inequívoca, por exemplo “quando sentires o início natural da inspiração seguinte”, preservando a continuidade sem retenção.

#### F-003 — O Markdown manda retirar mãos que podem não estar em uso

- **Severidade:** baixa
- **Blocker:** não
- **Campo:** `ending_the_exercise_pt_pt` / “Como terminar”
- **Evidência:** o JSON condiciona corretamente “retira as mãos **se as estiveres a usar**” (`lateral_costal_breathing_beginner_content_v0.1.json`, linha 163). O Markdown perde essa condição e diz simplesmente “retira as mãos” (`lateral_costal_breathing_beginner_content_v0.1.md`, linha 121), apesar de o contacto manual ser opcional.
- **Revisão requerida:** repor no Markdown a condição existente no JSON.

#### F-004 — O teste de compreensão perde as respostas no Markdown

- **Severidade:** baixa
- **Blocker:** não
- **Campo:** `beginner_comprehension_test` / “Verificação de compreensão”
- **Evidência:** o JSON de `diaphragmatic_breathing` contém doze pares pergunta/resposta (`diaphragmatic_breathing_beginner_content_v0.1.json`, linhas 266–326). O Markdown apresenta apenas as doze perguntas (`diaphragmatic_breathing_beginner_content_v0.1.md`, linhas 125–138), ao contrário da informação estruturada e dos outros conteúdos auditados.
- **Revisão requerida:** incluir as respostas esperadas no Markdown ou declarar explicitamente que a secção é uma autoavaliação sem chave de respostas; a primeira opção mantém melhor a equivalência entre artefactos.

## Padrões observados

### Conformes

- Os quatro conteúdos distinguem corretamente:
  - observação: notar localização, fase, ritmo e esforço sem alterar o ciclo;
  - expansão costal: dirigir a inspiração aos lados das costelas;
  - diafragmática: favorecer excursão diafragmática e expansão inferior/circunferencial sem imobilizar o tórax;
  - ritmada: organizar temporalmente inspiração e expiração, sem contagem ou retenção.
- Inspiração e expiração estão explicitamente descritas nos quatro exercícios; as transições são contínuas e sem pausa voluntária nas três técnicas dirigidas.
- A prevenção de hiperventilação é consistente: amplitude confortável, não inspirar ao máximo, não respirar demasiado depressa ou fundo, interromper perante tontura/formigueiro/pré-síncope e regressar à respiração espontânea.
- A supervisão por defeito permanece “nenhuma” em contexto geral de baixo risco, com encaminhamento coerente perante restrição clínica, incapacidade de parar/ajustar, doença relevante, história de síncope ou sintomas novos.
- Não há tratamento, promessa de resultado, diagnóstico, interpretação de assimetrias, HRV ou dióxido de carbono, nem autorização universal.
- O português é europeu e todos os doze artefactos estão em Unicode NFC.

### A rever

- Há três perdas editoriais pontuais entre JSON e Markdown.
- O único padrão materialmente bloqueante é a transformação de uma alternativa canónica (“autoescolhido ou sinal externo”) numa execução exclusivamente dependente de sinal externo.

## Contagens

| Métrica | Resultado |
|---|---:|
| Exercícios auditados | 4 |
| Artefactos de conteúdo auditados | 12 |
| Pacotes de invariantes confirmados | 4 |
| JSON válidos | 4/4 |
| Ordem integral das chaves contratuais | 4/4 |
| ID, nome, tipo, capacidade, família, base e variante exatos | 4/4 |
| Estados de conteúdo permitidos | 4/4 |
| Unicode NFC | 12/12 |
| Passos de execução | 7 / 7 / 7 / 8 |
| Cues principais | 5 / 6 / 6 / 6 |
| Erros comuns com reconhecimento e correção | 5 / 6 / 5 / 6 |
| Perguntas no teste de compreensão | 12 / 12 / 12 / 12 |
| Findings | 4 |
| Findings blocker | 1 |
| Severidade média | 1 |
| Severidade baixa | 3 |
| Contagens, retenções ou dose impostas | 0 |
| Tratamentos, diagnósticos ou promessas | 0 |

A ordem dos quádruplos de contagem é: observação / expansão costal / diafragmática / ritmada.

## Independência

AUD-G não foi autor dos conteúdos. A revisão foi realizada de forma independente e sem consulta de relatórios de outros auditores. A evidência considerada limitou-se aos doze artefactos dos quatro exercícios no âmbito e aos quatro pacotes canónicos correspondentes.

## Implementação

**Implementação realizada: não.**

Nenhum conteúdo foi editado, não houve código, publicação, alteração de relações, aprovação multimédia ou mudança de risco. O único artefacto produzido por AUD-G é este relatório de auditoria.
