# Relatório de investigação — `standing_broad_jump`

## Âmbito

Este relatório sustenta apenas o conteúdo documental para principiantes do exercício canónico `standing_broad_jump` — **Salto horizontal bipodal parado**.

Foram investigados:

- execução e preparação;
- respiração;
- segurança e superfície;
- receção e travagem;
- erros observáveis;
- competência prévia e supervisão;
- limites da evidência.

Ficaram fora do âmbito:

- dose, volume, intensidade, distância e carga;
- programação ou progressão individual;
- diagnóstico, tratamento ou autorização clínica;
- criação ou alteração de identidade, variante, equipamento, risco ou relações;
- código, publicação e implementação.

## Registo canónico preservado

| Campo | Valor preservado |
|---|---|
| `exercise_id` | `standing_broad_jump` |
| Nome | Salto horizontal bipodal parado |
| Tipo | `canonical_exercise` |
| Capacidade principal | `speed_power` |
| Família | `lower_body_ballistic_jump` |
| Variante de | `none` |
| Exercício-base | `none` |
| Risco operacional | `high` |
| Equipamento obrigatório | nenhum |
| Superfície | `firm_even_non_slip_surface` |
| Caminho | área de receção e espaço frontal livres |
| Supervisão | `recommended` |

Relação aprovada preservada, sem criar novas combinações:

`standing_broad_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power`

- contexto: `main_training`;
- capacidade: `speed_power`;
- conceito: `ballistic_projection`;
- intenção: `increase_ballistic_power`;
- estado: `compatible`;
- papel: `principal_candidate`;
- modificador de risco contextual: `high`;
- limite: sem distância-alvo ou esforço obrigatório; área de receção livre.

## Estratégia de pesquisa

Foram priorizadas fontes profissionais de organizações de exercício e força e condicionamento, uma instituição ortopédica especializada e literatura biomecânica primária. As conclusões só foram transpostas quando eram compatíveis com a identidade canónica e não introduziam dose, promessa ou autorização universal.

Data de acesso: 2026-07-23.

## Fontes e contributos

### 1. American Council on Exercise — técnica profissional

**Fonte:** [Forward Linear Jumps](https://www.acefitness.org/resources/everyone/exercise-library/177/forward-linear-jumps/)

**Contributo defensável:**

- partida bipodal;
- movimento preparatório da anca e dos joelhos;
- braços atrás na preparação e à frente na impulsão;
- extensão coordenada da anca, joelhos e tornozelos;
- pés próximos durante a fase aérea;
- preparação da receção com flexão da anca e dos joelhos;
- absorção do contacto sem joelhos rígidos.

**Limite:** a página descreve saltos lineares à frente e inclui uma variante repetida. Apenas a execução isolada e compatível foi usada; a repetição ligada foi excluída por contrariar a identidade canónica.

### 2. National Strength and Conditioning Association — técnica e aprendizagem profissional

**Fonte:** [Plyometric Implementation: Setup and Execution of Jump Landing Positions to Decrease Likelihood of Injuries](https://www.nsca.com/education/videos/plyometric-implementation-setup-and-execution-of-jump-landing-positions-to-decrease-likelihood-of-injuries/)

**Contributo defensável:**

- a aterragem é uma competência a preparar;
- a seleção deve respeitar competência e capacidade;
- os saltos bilaterais de menor exigência precedem tarefas com maior exigência de desaceleração;
- a observação técnica é relevante para preparar as estruturas para cargas posteriores.

**Limite:** é formação profissional geral sobre saltos e aterragem, não um ensaio específico do salto horizontal parado.

### 3. Hospital for Special Surgery — orientação profissional para principiantes

**Fonte:** [A Beginner’s Guide to Plyometrics Workouts](https://www.hss.edu/health-library/move-better/plyometrics-workouts-for-beginner)

**Contributo defensável:**

- a aprendizagem do principiante começa pela posição e controlo da receção;
- joelhos e pés devem manter orientação coerente;
- uma aterragem ruidosa pode indicar absorção insuficiente;
- movimentos explosivos mais complexos só devem ser considerados depois de existir conforto no controlo da força.

**Limite:** é orientação clínica-profissional geral e não uma regra universal de elegibilidade.

### 4. Wakai e Linthorne — estudo biomecânico primário direto

**Fonte:** Wakai M, Linthorne NP. [Optimum take-off angle in the standing long jump](https://bura.brunel.ac.uk/bitstream/2438/537/1/%27Standing%20Long%20Jump%27%20Post-print.pdf). *Human Movement Science*. 2005;24(1):81–96. DOI: 10.1016/j.humov.2004.12.001.

**Contributo defensável:**

- o movimento parte de posição estática;
- usa contramovimento, balanço bilateral dos braços e impulsão com as duas pernas;
- exige coordenação da projeção do centro de massa;
- durante o voo, as pernas avançam para preparar a receção;
- o equilíbrio após a receção é parte observável de uma execução concluída.

**Limite:** a amostra foi pequena e composta por homens fisicamente ativos. Os saltos do estudo procuravam desempenho máximo; os ângulos e resultados de distância não foram convertidos em instruções para principiantes.

### 5. Wu e colaboradores — estudo biomecânico primário direto

**Fonte:** Wu W-L, Wu J-H, Lin H-T, Wang G-J. [Biomechanical Analysis of the Standing Long Jump](https://www.worldscientific.com/doi/abs/10.4015/S1016237203000286). 2003. DOI: 10.4015/S1016237203000286.

**Contributo defensável:**

- confirma o papel mecânico do movimento dos braços;
- analisa a posição inicial do joelho e a produção de força;
- apoia a descrição do salto como tarefa coordenada de corpo inteiro.

**Limite:** a amostra foi composta por mulheres adultas saudáveis e o objetivo foi desempenho. Não sustenta uma posição angular obrigatória nem autoriza execução autónoma.

### 6. Chen e colaboradores — estudo biomecânico primário de receção

**Fonte:** Chen L, Jiang Z, Yang C, Cheng R, Zheng S, Qian J. [Effect of different landing actions on knee joint biomechanics of female college athletes: Based on OpenSim simulation](https://www.frontiersin.org/journals/bioengineering-and-biotechnology/articles/10.3389/fbioe.2022.899799/full). *Frontiers in Bioengineering and Biotechnology*. 2022;10:899799. DOI: 10.3389/fbioe.2022.899799.

**Contributo defensável:**

- diferentes estratégias de receção alteram a mecânica do joelho;
- maior flexão do joelho integra uma estratégia de absorção;
- apoia evitar uma receção rígida.

**Limite:** estudou atletas universitárias e usou simulação musculoesquelética. Não estudou especificamente principiantes no salto horizontal parado e não permite inferir risco individual.

### 7. American College of Sports Medicine — orientação geral de respiração

**Fonte:** [Exercise for the Prevention and Treatment of Hypertension](https://acsm.org/exercise-for-the-prevention-and-treatment-of-hypertension/)

**Contributo defensável:**

- evitar retenção voluntária da respiração durante esforço;
- manter respiração regular.

**Limite:** não é uma fonte específica do salto horizontal. Não foi encontrada cadência respiratória validada para esta tarefa. Por isso, o conteúdo usa respiração natural e contínua, admite a saída não forçada de ar na impulsão e exclui contagens ou retenções.

## Síntese por tema

| Tema | Síntese adotada | Base |
|---|---|---|
| Preparação | Pés paralelos e apoiados; anca atrás; flexão de anca e joelhos; braços atrás | ACE; Wakai e Linthorne; Wu et al. |
| Impulsão | Saída coordenada com os dois pés, extensão dos membros inferiores e balanço dos braços | ACE; Wakai e Linthorne; Wu et al. |
| Voo | Pés próximos e paralelos; pernas preparam a receção | ACE; Wakai e Linthorne |
| Receção | Contacto bipodal quase simultâneo, absorção com anca e joelhos e estabilização | ACE; HSS; Chen et al. |
| Respiração | Natural e contínua; sem retenção; sem cadência imposta | ACSM; ausência de evidência específica |
| Segurança | Piso firme, regular e não escorregadio; corredor frontal livre | registo canónico; ACE |
| Erros | área não verificada, perda de apoio bipodal, pés demasiado à frente, rigidez, joelhos para dentro, ressalto | síntese observável das fontes técnicas e do registo |
| Supervisão | primeira exposição demonstrada e observada; competência de receção antes do salto completo | NSCA; HSS; risco canónico high |

## Decisões editoriais

### Receção antes de distância

O conteúdo prioriza travar e estabilizar. A literatura primária direta estuda frequentemente distância e desempenho, mas esses resultados não foram convertidos em metas porque isso introduziria prescrição e poderia incentivar uma estratégia incompatível com controlo.

### Primeiro dia não autónomo

O registo canónico classifica o risco como alto e inclui “primeira exposição técnica” como gatilho de supervisão. A orientação profissional converge na aprendizagem prévia da aterragem e no acompanhamento por competência. Assim, foi incluída de forma explícita a frase: **“Esta explicação não autoriza execução autónoma no primeiro dia.”**

### Estratégia perante falha

Durante a fase aérea não é possível cancelar o movimento. A estratégia documental é:

- não procurar distância adicional;
- preparar os dois pés;
- não bloquear os joelhos;
- usar passos depois do contacto apenas para evitar uma queda;
- terminar a tentativa e informar o supervisor;
- parar perante queda, dor, mal-estar ou perda de coordenação.

Isto não redefine a execução canónica: passos ou mãos no chão são tratados como falha de estabilização e não como forma válida.

### Respiração

Não foi encontrada uma sequência respiratória específica suportada para o salto horizontal parado. Foi aplicada a regra conservadora de respiração natural e contínua, sem retenção, contagem ou promessa de efeito.

## Campos adicionais de risco alto

Os cinco campos obrigatórios foram preenchidos:

1. `prerequisite_skill_pt_pt`;
2. `supervision_recommendation_pt_pt`;
3. `safe_space_requirement_pt_pt`;
4. `landing_or_braking_control_pt_pt`;
5. `failure_exit_strategy_pt_pt`.

Todos mantêm o risco `high`, a supervisão `recommended`, a superfície firme e não escorregadia e o caminho frontal desimpedido.

## Cobertura do contrato

| Requisito | Resultado |
|---|---|
| Português europeu | cumprido |
| UTF-8 / NFC | preparado para validação |
| Passos de execução | 7 |
| Indicações principais | 6 |
| Erros comuns estruturados | 6 |
| Perguntas de compreensão | 12 |
| Fontes independentes | ACE, NSCA, HSS, ACSM e três grupos de investigação |
| Literatura primária | Wakai e Linthorne; Wu et al.; Chen et al. |
| Primeiro dia autónomo | explicitamente não autorizado |
| Dose ou prescrição | ausente |
| Promessa ou diagnóstico | ausente |
| Nova relação | nenhuma |
| Alteração de identidade, risco, equipamento ou superfície | nenhuma |

## Limitações e confiança

**Confiança global:** moderada a alta.

- **Técnica nuclear:** alta, por convergência de uma fonte profissional direta e estudos biomecânicos diretos.
- **Receção e segurança:** moderada a alta, por convergência profissional e biomecânica, embora parte da evidência provenha de outras tarefas de aterragem.
- **Respiração:** moderada, porque existe orientação geral para não reter a respiração, mas não uma sequência validada específica.
- **Supervisão:** moderada a alta, por coerência entre risco canónico, formação profissional e orientação clínica para principiantes.

Limites:

- amostras primárias pequenas ou específicas;
- foco frequente em desempenho máximo;
- ausência de ensaios sobre execução autónoma de principiantes;
- ausência de cadência respiratória específica;
- impossibilidade de inferir risco, elegibilidade ou resultado individual a partir destas fontes.

Não existem campos factuais obrigatórios por resolver; os limites foram registados em vez de preenchidos por inferência.

## Conclusão

O conteúdo é defensável como documentação técnica para principiante com limites. Preserva identidade, risco, equipamento, superfície e relação aprovada. Não fornece dose, prescrição, promessa, diagnóstico, autorização clínica ou autorização de execução autónoma no primeiro dia.

**Implementação realizada: não**
