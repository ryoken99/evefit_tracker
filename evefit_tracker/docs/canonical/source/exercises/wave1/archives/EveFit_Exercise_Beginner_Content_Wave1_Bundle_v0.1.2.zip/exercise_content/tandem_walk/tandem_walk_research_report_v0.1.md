# Relatório de investigação — marcha tandem (`tandem_walk`)

## Estado

- **Agente:** EX-36
- **Objeto exclusivo:** `tandem_walk`
- **Data da pesquisa:** 24-07-2026
- **Idioma de entrega:** português europeu
- **Implementação realizada:** não

## Questão documental

Produzir orientação para um principiante absoluto sobre marcha tandem em frente, incluindo execução calcanhar–ponta, preparação do percurso, respiração, risco de queda, erros frequentes, saída e supervisão, sem alterar identidade, risco, equipamento, superfície, espaço ou relações canónicas e sem introduzir dose, promessa, diagnóstico ou tratamento.

## Limites canónicos preservados

| Dimensão | Decisão preservada |
|---|---|
| Identidade | Locomoção linear em frente com apoios tandem sucessivos, colocando cada calcanhar diretamente junto à ponta do pé oposto |
| Tipo | `canonical_exercise` |
| Família | `narrow_base_locomotion` |
| Direção | Apenas em frente |
| Risco | Moderado; queda, passo falhado e base dinâmica estreita |
| Equipamento | Nenhum obrigatório; apoio estável opcional |
| Superfície | Firme, nivelada e antiderrapante |
| Espaço | Percurso linear livre de obstáculos |
| Supervisão | Recomendada; sem vigilante obrigatório por defeito |
| Relações | Mantidas sem adição, remoção ou reformulação |
| Prescrição | Ausente |

## Estratégia de pesquisa

Foram priorizadas fontes oficiais do NHS, um manual profissional do programa Otago, orientação clínica hospitalar recente e literatura primária específica sobre marcha tandem. Para respiração, como não foi localizada uma relação específica e validada entre fase respiratória e fase do passo, foi usada orientação profissional geral de exercício e mantida a formulação conservadora “respiração natural, regular e contínua, sem retenção”.

## Fontes e extração crítica

### 1. Oxford University Hospitals NHS Foundation Trust — Otago

**Fonte:** [OTAGO Strength and Balance — Home Exercise Programme](https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf)  
**Tipo:** manual profissional oficial; fonte já existente no registo (`E1-SRC-003`).

Elementos aproveitados:

- marcha calcanhar–ponta em frente;
- pés diretamente um à frente do outro, formando uma linha;
- postura direita e olhar em frente;
- ação de marcha estável;
- apoio lateral seguro de acordo com a necessidade;
- retorno dos pés a uma base confortável antes de virar;
- respiração normal ao longo do exercício;
- apoio firme e estável, roupa confortável e calçado de suporte no contexto do programa.

Limites:

- o manual destina-se sobretudo a adultos mais velhos;
- contém doses e progressões próprias do programa, que não foram importadas;
- contém afirmações de benefício do programa completo que não foram atribuídas ao exercício isolado.

### 2. NHS — exercício calcanhar–ponta

**Fonte:** [Balance exercises — Heel-to-toe walk](https://www.nhs.uk/live-well/exercise/balance-exercises/)  
**Tipo:** orientação pública oficial; independente do manual hospitalar.

Elementos aproveitados:

- início em pé;
- calcanhar diretamente em frente da ponta do outro pé;
- alternância dos pés;
- olhar em frente;
- dedos na parede como apoio opcional para estabilidade.

Limites:

- é conteúdo público breve, sem análise biomecânica detalhada;
- a dose sugerida na página não foi importada.

### 3. Royal Berkshire NHS Foundation Trust

**Fonte:** [Balance exercises for older patients](https://www.royalberkshire.nhs.uk/media/dijm12l5/balance-exercises-for-older-patients_pd-3_jan26.pdf)  
**Tipo:** material clínico profissional oficial, revisto em janeiro de 2026.

Elementos aproveitados:

- percurso ou corredor bem iluminado;
- ausência de objetos que possam causar queda;
- presença de alguém a observar quando apropriado;
- realização perto de uma posição de suporte quando não existe observador;
- interrupção e recuperação do equilíbrio se houver sensação de queda ou desequilíbrio marcado;
- marcha calcanhar–ponta controlada.

Limites:

- dirige-se a pessoas mais velhas num contexto de equilíbrio;
- inclui outras tarefas e prescrições que ficaram fora do conteúdo.

### 4. Dozza et al. — literatura primária

**Fonte:** Dozza M, Wall C III, Peterka RJ, Chiari L, Horak FB. [Effects of practicing tandem gait with and without vibrotactile biofeedback in subjects with unilateral vestibular loss](https://doi.org/10.3233/VES-2007-17405). *Journal of Vestibular Research*.  
**Tipo:** estudo primário com desenho cruzado.

Elementos aproveitados:

- a marcha tandem é uma tarefa dinâmica de base estreita;
- desvio do tronco, deslocamento do centro de massa, distância mediolateral dos pés e frequência de erros de passo foram medidas observáveis;
- os dados dão fundamento para reconhecer perda de alinhamento, inclinação/desvio e passos de correção como erros ou sinais de controlo insuficiente.

Limites:

- amostra de nove participantes com perda vestibular unilateral;
- intervenção associada a um dispositivo de biofeedback vibrotátil;
- os resultados não permitem prometer benefício, prevenção de quedas ou generalização para principiantes sem condição clínica;
- o estudo não define uma técnica respiratória própria da marcha tandem.

### 5. American Heart Association — respiração

**Fonte:** [Getting Active to Control High Blood Pressure](https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure)  
**Tipo:** orientação profissional oficial.

Elementos aproveitados:

- respiração regular ao longo do exercício;
- evitar prender a respiração.

Limites:

- é orientação geral de atividade física, não investigação específica da marcha tandem;
- as explicações sobre pressão arterial e intensidade não foram transpostas para o conteúdo, evitando diagnóstico e prescrição.

## Síntese de decisões

| Tema | Decisão para o conteúdo | Fundamento |
|---|---|---|
| Contacto dos pés | Calcanhar diretamente junto à ponta do pé oposto | NHS e Otago |
| Linha de progressão | Ambos os pés na mesma linha; não cruzar lateralmente | Definição canónica, NHS/Otago e métricas mediolaterais do estudo primário |
| Transferência | Aceitar o peso no pé da frente antes de avançar o outro | Registo canónico e controlo de apoios sucessivos |
| Olhar | Orientado para a frente | NHS e Otago |
| Tronco | Direito, sem inclinação para vigiar continuamente os pés | Otago e observação de desvio do tronco na literatura primária |
| Percurso | Linear, livre, bem iluminado; piso firme, nivelado e antiderrapante | Registo canónico e Royal Berkshire |
| Apoio | Opcional, lateral, fixo e estável, ao alcance | Registo canónico, NHS e Otago |
| Respiração | Natural, regular e contínua; sem retenção ou contagens | Otago e AHA; ausência de evidência para sincronização específica |
| Supervisão | Recomendada; reforçada pelos gatilhos canónicos | Registo canónico e Royal Berkshire |
| Saída | Parar, recuperar apoio bipodal e só depois reposicionar | Otago e pré-requisitos canónicos |
| Erros | Pé fora da linha, cruzamento lateral, passo antes de controlar o peso, olhar contínuo para baixo, virar em base tandem | Coerência mecânica, instruções profissionais e medidas de desempenho do estudo primário |

## Exclusões deliberadas

- Não foi importado qualquer número de passos, repetições, séries, minutos, metros, sessões ou frequência.
- Não foram importadas progressões de retirada do apoio, olhos fechados, aumento de velocidade ou superfícies instáveis.
- Marcha para trás e marcha em trave foram mantidas fora da identidade.
- Não foi criada promessa de melhoria do equilíbrio nem de prevenção de quedas.
- Não foram criados diagnósticos, tratamentos ou autorizações universais.
- Não foram aprovados média, código ou publicação.
- Não foram alteradas relações canónicas.

## Avaliação da confiança

- **Execução calcanhar–ponta:** alta, pela convergência de duas fontes NHS independentes e do manual Otago.
- **Ambiente e apoio:** alta, pela convergência do registo canónico com fontes hospitalares.
- **Respiração:** moderada, porque a indicação é geral e não específica da tarefa.
- **Erros frequentes:** moderada, combinando coerência mecânica, instruções profissionais e um estudo primário pequeno.
- **Aplicação universal:** não suportada.

## Conclusão

O conteúdo pode ser aprovado com limites para principiantes, preservando risco moderado e supervisão recomendada. A execução é descrita por pelo menos cinco passos, inclui pistas e erros observáveis, prepara explicitamente o percurso e fornece uma saída segura. A respiração permanece natural e contínua porque não foi encontrada base para associar inspiração ou expiração a uma fase específica. As fontes não sustentam dose, promessa de prevenção de quedas, diagnóstico ou autorização universal.

**Implementação realizada: não**
