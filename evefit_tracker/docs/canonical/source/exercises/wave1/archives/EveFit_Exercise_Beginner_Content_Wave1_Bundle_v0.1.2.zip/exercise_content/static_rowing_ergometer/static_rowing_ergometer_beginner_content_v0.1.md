# Remo em ergómetro estático

Conteúdo para principiantes em português europeu.

## Descrição curta

Ciclo técnico de remo num ergómetro fixo, com fase propulsiva e recuperação ordenadas.

## O que é

Exercício cíclico, sentado num ergómetro de remo estático, em que empurras primeiro com as pernas, continuas com o tronco e terminas com os braços; regressas ao ataque pela ordem inversa.

## O que vais fazer

Sentar-te no assento deslizante com os pés presos nas plataformas e as duas mãos na pega. Passar de uma posição de ataque controlada para a finalização através da sequência pernas, tronco e braços. Voltar ao ataque pela sequência braços, tronco e pernas, mantendo a pega e o assento sob controlo. Ligar as fases num ciclo contínuo, sem transformar o exercício em remo em água, ergómetro dinâmico, sweep ou scull.

## Porque existe este movimento

O propósito técnico imediato é executar repetidamente o ciclo completo de remo indoor. A ação permite aplicar força cíclica contra o ergómetro e praticar as transições entre pernas, tronco e braços. Pode integrar percursos aprovados de condicionamento cardiorrespiratório e de controlo/coordenação motora, mas não define dose nem garante qualquer resultado individual.

## Antes de começares

1. Confirma que consegues manter os pés apoiados, a bacia no assento e as duas mãos na pega durante o ciclo.
2. Confirma que o ergómetro está funcional, estável e colocado num local interior adequado.
3. Não comeces se houver uma peça solta, danificada ou com funcionamento anormal.
4. Mantém roupa, dedos, cabelo, objetos soltos, crianças e animais afastados dos roletes do assento e das partes móveis.
5. Se o equipamento ou o ambiente não te forem familiares, pede orientação antes de começares.

## Preparar o equipamento

1. Usa um ergómetro de remo estático funcional; não substituas por ergómetro dinâmico nem por embarcação.
2. Verifica visualmente o assento, a calha, a pega, a corrente ou sistema de tração, as plataformas dos pés e as correias.
3. Ajusta a altura das plataformas para que as correias passem sobre a zona mais larga de cada pé e para que consigas chegar ao ataque sem levar as canelas além da vertical.
4. Aperta as correias de modo a manter os pés estáveis, sem comprometer o conforto.
5. Se não souberes usar uma regulação específica do modelo, consulta o manual do fabricante ou pede ajuda a um profissional.

## Preparar o espaço

1. Coloca o ergómetro no interior, sobre uma superfície firme, estável e nivelada.
2. Deixa desimpedida toda a trajetória do assento e da pega.
3. Garante visibilidade suficiente para reconhecer a posição do corpo, os apoios e qualquer anomalia do equipamento.
4. Afasta pessoas e objetos das partes móveis e evita uma base instável ou um ergómetro danificado.

## Verificação do corpo

1. Consegues sentar-te de forma estável e deslocar o assento sem perder os apoios?
2. Consegues manter uma pega bilateral e simétrica?
3. Consegues inclinar o tronco a partir das ancas sem colapsar a postura?
4. Consegues chegar a uma posição confortável com as canelas verticais ou tão próximas da vertical quanto for confortável?
5. Estás sem desconforto no peito, falta de ar atípica, tonturas, confusão, dor nova ou perda de controlo?

## Posição inicial

Senta-te no assento com os pés apoiados e presos, segura a pega com as duas mãos e aproxima o assento do ataque de forma controlada. Mantém os braços estendidos, a cabeça neutra, os ombros baixos, o tronco longo e ligeiramente inclinado para a frente a partir das ancas; deixa as canelas verticais ou tão próximas da vertical quanto for confortável, sem as levar para além desse ponto.

## Confirmar a posição inicial

1. Bacia apoiada no centro do assento.
2. Pés estáveis nas plataformas, com as correias sobre a zona mais larga dos pés.
3. Duas mãos na pega, punhos alinhados e preensão leve.
4. Braços estendidos e ombros relaxados.
5. Cabeça neutra e tronco longo, inclinado a partir das ancas.
6. Canelas verticais ou tão próximas da vertical quanto for confortável.
7. Pega e corrente alinhadas com o volante, sem desvio lateral.

## Passos de execução

1. No ataque, confirma braços estendidos, tronco inclinado para a frente a partir das ancas, ombros relaxados e canelas verticais ou tão próximas da vertical quanto for confortável.
2. Inicia a fase propulsiva pressionando as plataformas com as duas pernas; mantém os braços estendidos e o tronco firme no início.
3. Quando as pernas estiverem quase estendidas, passa o tronco de ligeiramente inclinado para a frente para ligeiramente inclinado para trás, sem uma inclinação extrema.
4. Termina a fase propulsiva dobrando os cotovelos e levando a pega em linha reta até à zona inferior das costelas; mantém os punhos alinhados e os ombros baixos.
5. Começa a recuperação afastando a pega do corpo e estendendo completamente os braços.
6. Com as pernas ainda estendidas, inclina o tronco para a frente a partir das ancas.
7. Só depois de a pega ultrapassar os joelhos, dobra-os e deixa o assento deslizar para a frente sob controlo.
8. Regressa ao ataque sem bater com o assento nos limites e liga o ciclo seguinte mantendo a ordem pernas–tronco–braços e braços–tronco–pernas.

## Fases do movimento

### Ataque

Posição preparada, com braços estendidos, tronco inclinado para a frente a partir das ancas e canelas verticais ou tão próximas da vertical quanto for confortável.

### Fase propulsiva

Pressão das pernas, seguida da passagem controlada do tronco e, por fim, da tração dos braços.

### Finalização

Pernas estendidas, tronco ligeiramente inclinado para trás e pega junto à zona inferior das costelas, com ombros baixos e punhos alinhados.

### Recuperação

Braços estendem, tronco inclina-se para a frente a partir das ancas e só depois os joelhos dobram para o regresso controlado ao ataque.

## Respiração

Respira de forma natural e contínua ao longo do ciclo. Não prendas a respiração. Uma expiração pode acompanhar a fase propulsiva e a inspiração pode acontecer durante a recuperação se isso surgir confortavelmente, mas não forces uma contagem nem uma sincronização rígida. Se a respiração se tornar atípica, difícil de controlar ou acompanhada por desconforto no peito, interrompe o exercício.

## Sensações esperadas

1. Pressão simétrica dos dois pés nas plataformas durante o início da fase propulsiva.
2. Participação sucessiva das pernas, do tronco e dos braços, sem puxão brusco.
3. Trabalho de estabilização do tronco enquanto o assento se desloca.
4. Aumento da ventilação compatível com movimento contínuo, sem necessidade de reter a respiração.
5. Deslizamento suave do assento e trajetória linear da pega.

## Sensações inesperadas ou de alerta

1. Desconforto no peito ou falta de ar atípica.
2. Tonturas, sensação de desmaio ou confusão.
3. Dor nova, aguda ou crescente.
4. Perda de controlo da pega, do assento, da postura ou dos apoios.
5. Estalido, bloqueio, retorno irregular ou outro funcionamento anormal do ergómetro.

## Indicações técnicas principais

1. Pernas, tronco e braços na fase propulsiva.
2. Braços, tronco e pernas na recuperação.
3. Pega em linha reta; punhos alinhados e ombros baixos.
4. Canelas até à vertical confortável, sem ultrapassar.
5. Respiração natural e contínua, sem retenção.
6. Assento e pega sempre sob controlo.

## Erros comuns e correções

### Erro 1: Puxar primeiro com os braços.

- Como reconhecer: Os cotovelos dobram antes de o assento começar a afastar-se do volante, e as pernas deixam de iniciar a fase propulsiva.
- Como corrigir: Mantém os braços estendidos no início e pensa em pressionar primeiro as plataformas; acrescenta o tronco e os braços apenas depois.

### Erro 2: Dobrar os joelhos demasiado cedo na recuperação.

- Como reconhecer: A pega encontra os joelhos ou precisa de subir por cima deles.
- Como corrigir: Afasta primeiro a pega, inclina depois o tronco para a frente e só dobra os joelhos quando as mãos os tiverem ultrapassado.

### Erro 3: Arredondar o tronco ou inclinar-se excessivamente para trás.

- Como reconhecer: A cabeça avança, os ombros colapsam ou a finalização depende de uma grande inclinação para trás.
- Como corrigir: Mantém o tronco longo, roda a partir das ancas e limita a finalização a uma ligeira inclinação controlada.

### Erro 4: Desviar a pega, dobrar os punhos ou puxar a corrente para um lado.

- Como reconhecer: A pega descreve uma curva, os punhos ficam fletidos ou a corrente deixa de seguir diretamente para o volante.
- Como corrigir: Usa as duas mãos de forma simétrica, mantém os punhos alinhados e desloca a pega em linha reta para a zona inferior das costelas.

### Erro 5: Apressar o assento ou deixar a pega regressar sem controlo.

- Como reconhecer: O assento bate no limite, a recuperação termina num choque ou a pega é largada em direção ao guia da corrente.
- Como corrigir: Mantém a pega nas mãos, controla o seu regresso e deixa o assento aproximar-se do ataque sem embate.

## Formas de simplificar ou ensaiar

1. Antes de ligar o ciclo, memoriza a ordem verbal: pernas–tronco–braços; braços–tronco–pernas.
2. Se perderes a ordem, termina o movimento sob controlo, pára e volta a organizar a posição de ataque.
3. Usa uma observação lateral por um profissional, ou uma referência visual adequada, para confirmar postura, trajetória da pega e momento em que os joelhos dobram.
4. Mantém o foco na sequência e no controlo; qualquer decisão sobre dose, regulação ou exigência pertence a uma prescrição separada.

## Supervisão

A supervisão é recomendada, sobretudo para principiantes absolutos, pessoas previamente sedentárias, adultos mais velhos, pessoas com limitações de equilíbrio, quem regressa após lesão ou cirurgia e quem apresenta sintomas cardiorrespiratórios relevantes. Procura supervisão quando houver instabilidade marcada ou equipamento/ambiente desconhecido. Um instrutor qualificado pode confirmar o ajuste, a ordem segmentar e o controlo da pega e do assento; um profissional de saúde é a referência adequada quando existirem sintomas ou uma situação clínica relevante. Não é necessário assistente de segurança por definição.

## Como terminar

Deixa de iniciar novas fases propulsivas e conclui o ciclo presente sob controlo. Permite que a pega regresse sem a largar e coloca-a no apoio previsto pelo fabricante. Espera que o assento esteja imóvel antes de desapertar as correias dos pés. Sai do ergómetro com atenção às partes móveis e confirma que a máquina fica estável e desimpedida. Se terminaste por um sinal de alerta, não retomes de imediato; procura a ajuda adequada à gravidade e ao contexto.

## Nota de segurança

O risco operacional é moderado. O ajuste dos pés, a técnica, o controlo do retorno e o estado do ergómetro são determinantes. A fadiga ou uma regulação que degrade a sequência não justificam puxões bruscos, inversão da ordem ou perda de controlo. A elegibilidade não é automática.

## Quando parar ou reduzir

1. Desconforto no peito ou falta de ar atípica. — Interrompe o exercício e procura avaliação adequada; em situação intensa, súbita ou preocupante, segue os procedimentos de emergência locais.
2. Tonturas, sensação de desmaio ou confusão. — Pára imediatamente, mantém-te em segurança e pede ajuda.
3. Perda de controlo ou dor nova. — Interrompe o movimento de forma controlada e não retomes enquanto a causa não estiver esclarecida.
4. Sequência a degradar-se sem conseguir corrigi-la. — Reduz a exigência ou termina o exercício; a fadiga não deve sobrepor-se ao controlo técnico.

## Segurança do equipamento

Retira de uso qualquer ergómetro com assento, pega, corrente, sistema de retorno, plataforma, correia ou estrutura danificados. Usa as duas mãos e puxa a pega em linha reta; não torças a corrente nem puxes lateralmente. Não largues a pega em movimento; devolve-a ao apoio previsto pelo fabricante. Mantém dedos, roupa, cabelo, crianças e animais afastados dos roletes e de outras partes móveis. Segue o manual do modelo para montagem, bloqueios, manutenção e limites de utilização.

## Segurança do espaço

Usa o ergómetro apenas num local interior adequado e sobre uma superfície nivelada e estável. Mantém a trajetória da pega e do assento livre de obstáculos. Evita utilização com visibilidade reduzida. Não uses uma máquina instável, danificada ou colocada onde outras pessoas possam entrar na zona das partes móveis.

## Limitações

1. O conteúdo descreve execução documental para principiantes; não prescreve repetições, séries, duração, distância, carga, intensidade, cadência, descanso ou progressão.
2. A identidade está limitada ao ergómetro estático e não abrange ergómetro dinâmico, embarcação, sweep ou scull em água.
3. A orientação não determina elegibilidade individual, não diagnostica, não trata e não substitui avaliação profissional quando existirem sintomas ou necessidades de adaptação.
4. Os detalhes de montagem, bloqueio, manutenção e limites de utilização variam por modelo e devem ser confirmados no manual do fabricante.
5. Não foi imposta uma sincronização respiratória rígida por falta de suporte universal suficiente; mantém-se respiração natural e contínua sem retenção.
6. As relações canónicas aprovadas e condicionais foram preservadas, sem criação, remoção ou reclassificação.
7. Não existe suporte oficial independente suficiente para impor um padrão respiratório universal; mantém uma respiração natural e contínua sem retenção.
8. Os comandos dependem do ergómetro concreto e do respetivo manual; não alteram o requisito canónico de ergómetro estático funcional.

## Teste de compreensão

### 1. Que equipamento é obrigatório para este exercício?

Resposta esperada: Um ergómetro de remo estático funcional.

### 2. Qual é a ordem dos segmentos na fase propulsiva?

Resposta esperada: Pernas, tronco e braços.

### 3. Qual é a ordem dos segmentos na recuperação?

Resposta esperada: Braços, tronco e pernas.

### 4. Quando devem os joelhos começar a dobrar na recuperação?

Resposta esperada: Depois de os braços estarem estendidos, o tronco inclinado para a frente e a pega ter ultrapassado os joelhos.

### 5. Onde deve passar a correia de cada pé?

Resposta esperada: Sobre a zona mais larga, ou bola, do pé.

### 6. Até onde devem avançar as canelas no ataque?

Resposta esperada: Até à vertical, ou tão próximas da vertical quanto for confortável, sem a ultrapassar.

### 7. Como deve deslocar-se a pega?

Resposta esperada: Em linha reta para e a partir do volante, com as duas mãos e os punhos alinhados.

### 8. Deves prender a respiração durante a fase propulsiva?

Resposta esperada: Não; a respiração deve permanecer natural e contínua, sem retenção.

### 9. O que fazes se a pega embater nos joelhos na recuperação?

Resposta esperada: Corrijo a ordem: braços primeiro, tronco depois e joelhos apenas quando a pega já os ultrapassou.

### 10. Que sinais obrigam a interromper o exercício?

Resposta esperada: Desconforto no peito ou falta de ar atípica, tonturas ou confusão, perda de controlo ou dor nova.

### 11. O que deves fazer se encontrares uma peça danificada?

Resposta esperada: Não usar o ergómetro e mantê-lo fora de serviço até ser reparado.

### 12. Quando é especialmente recomendada supervisão?

Resposta esperada: Quando és principiante, há instabilidade marcada, o equipamento ou ambiente é desconhecido, existem limitações relevantes ou regressas após lesão ou cirurgia.

## Fontes e limites da evidência

### Fonte 1: Indoor Rowing Technique

- Autor ou entidade: Concept2
- Tipo: Documentação técnica oficial do fabricante
- Localizador: https://www.concept2.com/training/rowing-technique
- Usada para: Fases do ciclo, posições, sequência da fase propulsiva e da recuperação, trajetória da pega e postura.
- Limite: Fonte comercial; utilizada apenas para mecânica, execução e requisitos do ergómetro.

### Fonte 2: Learn About Rowing

- Autor ou entidade: USRowing
- Tipo: Federação nacional
- Localizador: https://usrowing.org/learn-about-rowing
- Usada para: Confirmação de que o remo indoor ocorre num ergómetro.
- Limite: Não fornece detalhe suficiente para fundamentar todas as instruções de execução.

### Fonte 3: Indoor Events

- Autor ou entidade: World Rowing
- Tipo: Federação internacional
- Localizador: https://worldrowing.com/events/indoor-events/
- Usada para: Confirmação da modalidade indoor em ergómetro.
- Limite: Não resolve por si só ajustes, erros ou segurança do equipamento.

### Fonte 4: Training and Education

- Autor ou entidade: Concept2
- Tipo: Documentação oficial do fabricante
- Localizador: https://www.concept2.com/training
- Usada para: Enquadramento da aprendizagem técnica no RowErg.
- Limite: Fonte comercial e geral; não usada para promessas nem prescrição.

### Fonte 5: RowErg Product Manual

- Autor ou entidade: Concept2
- Tipo: Manual oficial do fabricante
- Localizador: https://cms.concept2.com/sites/default/files/2024-11/RowErg_Manual_1024.pdf
- Usada para: Superfície estável, peças defeituosas, partes móveis, uso bilateral da pega, corrente sem torção, devolução controlada da pega e interrupção perante sensação de desmaio.
- Limite: Algumas instruções são específicas do Concept2 RowErg; outros modelos exigem consulta do respetivo manual.

### Fonte 6: British Rowing Technique

- Autor ou entidade: British Rowing
- Tipo: Orientação técnica de federação nacional
- Localizador: https://www.britishrowing.org/indoor-rowing/go-row-indoor/how-to-indoor-row/british-rowing-technique/
- Usada para: Validação independente da sequência pernas–tronco–braços e braços–tronco–pernas, posições, postura e controlo da recuperação.
- Limite: Alguns elementos quantitativos de treino presentes na página foram excluídos por estarem fora do âmbito.

### Fonte 7: Perfect Your Technique

- Autor ou entidade: British Rowing
- Tipo: Orientação técnica de federação nacional
- Localizador: https://www.britishrowing.org/indoor-rowing/go-row-indoor/how-to-indoor-row/perfect-your-technique/
- Usada para: Ajuste do apoio dos pés, postura, trajetória da pega, sequência da recuperação e erros técnicos.
- Limite: Recomendações de dose, regulação e cadência foram deliberadamente excluídas.

### Fonte 8: RowSafe 2026

- Autor ou entidade: British Rowing
- Tipo: Guia oficial de segurança
- Localizador: https://www.britishrowing.org/wp-content/uploads/2026/02/2026-RowSafe.pdf
- Usada para: Técnica correta, interrupção perante dor, espaço adequado, controlo da exigência e responsabilidades de treinadores e locais.
- Limite: Documento amplo de gestão de risco; foram usados apenas os pontos diretamente aplicáveis ao remo indoor.

### Fonte 9: Improve Your Rowing Technique

- Autor ou entidade: Concept2
- Tipo: Documentação técnica oficial do fabricante
- Localizador: https://www.concept2.com/training/improve-your-rowing-technique
- Usada para: Erros de braços precoces, preensão excessiva, inclinação extrema, joelhos precoces, recuperação apressada e sobrecompressão.
- Limite: Fonte comercial; os erros foram cruzados com orientação federativa.

### Fonte 10: Find Your Optimal Foot Position on the RowErg

- Autor ou entidade: Concept2
- Tipo: Documentação técnica oficial do fabricante
- Localizador: https://www.concept2.com/blog/find-your-optimal-foot-position-on-the-rowerg
- Usada para: Posição da correia sobre a zona mais larga do pé e relação entre ajuste e canelas verticais no ataque.
- Limite: Detalhe específico do sistema Flexfoot; o princípio foi generalizado apenas quando compatível com o ergómetro em uso.
