# Sprint com paragem controlada

Conteúdo para principiantes em português europeu.

## Descrição curta

exercício técnico linear de risco elevado que liga uma corrida de sprint a uma desaceleração por vários passos e termina numa posição bipodal estável, de frente.

## O que é

Neste exercício técnico, corres em frente em sprint, começas a travar antes de chegares ao limite da zona disponível, distribuis a redução da velocidade por vários contactos alternados e terminas parado sobre os dois pés, ainda orientado para a frente. A velocidade de entrada e o espaço necessário não são escolhidos por um principiante sem supervisão.

## O que vais fazer

Partirás de uma posição em pé com um pé à frente, correrás em linha reta, passarás de passos de propulsão para passos de travagem e estabilizarás numa base de dois pés. Não há corte, rotação, salto final nem tentativa de parar num único apoio.

## Porque existe este movimento

O propósito técnico imediato é praticar a transição entre sprint e travagem horizontal controlada, incluindo a absorção progressiva da velocidade e a estabilização final.

## Antes de começares

1. Esta explicação não autoriza uma primeira prática autónoma: a primeira exposição técnica deve ocorrer com supervisão presencial de um profissional qualificado.
2. Confirma que compreendes a tarefa, os sinais para interromper e a estratégia de saída antes de começares.
3. Confirma que já consegues executar o padrão antecedente de corrida e uma paragem linear controlada segundo avaliação do supervisor.
4. Não inicies se houver dor aguda, mal-estar, tonturas, perda de coordenação ou receio de não conseguires travar com controlo.
5. O supervisor deve definir a velocidade de entrada e confirmar que o espaço de travagem e a zona de saída são adequados naquele contexto.

## Preparar o equipamento

1. Não é necessário equipamento. Não acrescentes carga, resistência vestível, barreiras ou objetos para obrigar a paragem; isso alteraria as condições aprovadas e poderia aumentar o risco.

## Preparar o espaço

1. Usa apenas um corredor linear, desimpedido e com visibilidade de toda a trajetória.
2. A superfície tem de ser firme, regular e antiderrapante; não uses piso molhado, solto, instável, irregular ou com objetos.
3. Define uma zona de travagem ampla e, para lá do local onde esperas parar, mantém uma zona de saída reta adicional onde possas continuar a desacelerar sem encontrar parede, vedação, trânsito, espectadores ou cruzamentos.
4. A zona nunca deve terminar num obstáculo e não deve ser atravessada por outras pessoas durante a execução.
5. Confirma iluminação suficiente e condições ambientais que permitam ver o piso e manter controlo.

## Verificação do corpo

1. Consegues ficar em pé e caminhar sem dor aguda, mal-estar ou instabilidade?
2. Consegues compreender e executar a instrução de continuar em frente para abortar uma paragem?
3. O profissional que supervisiona confirmou a competência no padrão antecedente e a adequação desta exposição?
4. Sentes-te coordenado e suficientemente atento para vigiar toda a trajetória?
5. Se alguma resposta for não, não executes o exercício técnico.

## Posição inicial

Fica em pé no início do corredor, orientado para a frente, com um pé ligeiramente à frente do outro, joelhos descontraídos, tronco organizado, braços livres e olhos dirigidos para a trajetória.

## Confirmar a posição inicial

1. Corpo e pés apontam ao longo do corredor, sem rotação.
2. O corredor, a zona de travagem e a zona de saída estão totalmente livres.
3. O supervisor está colocado fora da trajetória e consegue ver toda a ação.
4. Não tens objetos nas mãos nem equipamento preso ao corpo.
5. Sabes onde começarás a travar, onde pretendes estabilizar e para onde continuarás se precisares de mais espaço.

## Passos de execução

1. Olha em frente e confirma uma última vez que o corredor e a zona de saída continuam livres.
2. Inicia a corrida a partir da base assimétrica e desloca-te em linha reta, com alternância natural de braços e pernas.
3. Ao aproximares-te da zona de travagem previamente definida pelo supervisor, começa a reduzir a velocidade antes de ficares sem espaço.
4. Usa vários passos alternados para travar; deixa tornozelos, joelhos e ancas fletirem de forma coordenada e permite que o tronco fique mais vertical do que durante a aceleração.
5. Mantém os pés e o peito orientados para a frente enquanto os passos ficam naturalmente mais curtos e o contacto com o solo se torna mais prolongado.
6. Quando a velocidade estiver suficientemente reduzida, aproxima os apoios e termina sobre os dois pés, com joelhos desbloqueados e tronco controlado.
7. Permanece atento depois da paragem, recupera uma respiração confortável e sai do corredor apenas quando for seguro.

## Fases do movimento

### Entrada em sprint

Corrida linear com apoios alternados e ação do lado oposto dos braços, mantendo os olhos na trajetória.

### Transição

Início deliberado da travagem antes do limite, com o tronco a tornar-se mais vertical e os passos a adaptar-se à redução da velocidade.

### Travagem

Vários contactos sucessivos recebem e distribuem a carga enquanto tornozelos, joelhos e ancas fletirem de forma coordenada.

### Estabilização

A velocidade aproxima-se de zero e a pessoa termina orientada para a frente, com apoio bipodal estável.

## Respiração

Respira de forma natural, regular e contínua durante a corrida e a travagem; não prendas voluntariamente a respiração. Permite uma expiração espontânea durante a desaceleração, sem impor contagens, sincronizações rígidas ou retenções. Se a respiração se tornar inesperadamente difícil, vier acompanhada de tonturas ou não recuperar de forma confortável após a paragem, interrompe.

## Sensações esperadas

1. Aumento natural da respiração associado a uma ação rápida.
2. Trabalho dos membros inferiores, sobretudo ao receber e travar o movimento.
3. Contactos progressivos com o solo durante a redução da velocidade.
4. Necessidade de organização do tronco e da bacia para terminar estável.

## Sensações inesperadas ou de alerta

1. Dor aguda ou sensação súbita de lesão.
2. Tonturas, desmaio iminente, mal-estar ou desorientação.
3. Falta de ar inesperada ou desconforto no peito.
4. Instabilidade que impeça manter a direção frontal.
5. Sensação de que os passos já não conseguem reduzir a velocidade antes do fim da zona livre.

## Indicações técnicas principais

1. Olhos no corredor livre.
2. Trava cedo, antes de faltar espaço.
3. Distribui a travagem por vários passos.
4. Flete tornozelos, joelhos e ancas sem colapsar.
5. Mantém peito e pés orientados para a frente.
6. Termina sobre os dois pés e mantém o controlo.

## Erros comuns e correções

### Erro 1: Começar a travar demasiado tarde.

- Como reconhecer: Chegas perto do fim da zona ainda com velocidade elevada ou precisas de um passo brusco para não ultrapassar o limite.
- Como corrigir: Não repitas de imediato. O supervisor deve rever a velocidade de entrada e disponibilizar mais espaço; na execução, inicia a transição enquanto ainda tens corredor livre.

### Erro 2: Tentar parar num único passo.

- Como reconhecer: Um apoio recebe quase toda a travagem, o corpo oscila ou o outro pé cai no chão como recuperação.
- Como corrigir: Mantém a trajetória reta e distribui a redução da velocidade por contactos sucessivos antes de juntares os pés.

### Erro 3: Rodar ou cortar para conseguir parar.

- Como reconhecer: O peito ou os pés desviam-se do corredor e a pessoa termina de lado.
- Como corrigir: Mantém a orientação frontal; se faltar espaço, usa a zona de saída em linha reta em vez de mudar de direção.

### Erro 4: Travar com joelhos rígidos ou com flexão apenas na cintura.

- Como reconhecer: Os contactos parecem duros, os joelhos quase não cedem ou o tronco dobra-se muito à frente sem flexão coordenada das pernas.
- Como corrigir: Permite flexão coordenada no tornozelo, joelho e anca, com o tronco controlado e progressivamente mais vertical.

### Erro 5: Terminar sem apoio bipodal estável.

- Como reconhecer: Ficas num só pé, saltas, agarras um objeto ou precisas de passos laterais para recuperar.
- Como corrigir: Continua a desacelerar em frente até a velocidade permitir colocar os dois pés no chão com controlo; o supervisor deve rever o espaço antes de nova tentativa.

### Erro 6: Prender a respiração durante a travagem.

- Como reconhecer: A face e o pescoço ficam tensos ou surge uma grande expiração apenas depois de parar.
- Como corrigir: Mantém a respiração a fluir naturalmente e deixa o ar sair sem contagem rígida durante a desaceleração.

## Formas de simplificar ou ensaiar

1. Na primeira exposição, observa uma demonstração presencial e identifica verbalmente as zonas de corrida, travagem e saída antes de qualquer execução.
2. O supervisor pode avaliar separadamente corrida linear, desaceleração e posição final antes de integrar o exercício técnico; essas tarefas preparatórias não são o sprint com paragem controlada.
3. Se a pessoa ainda não consegue manter direção frontal, distribuir a travagem ou terminar bipodalmente, o exercício não é iniciado; a seleção de uma tarefa antecedente cabe ao profissional.
4. Não uses uma parede, parceiro, objeto ou viragem como ajuda para parar.

## Supervisão

A supervisão é recomendada pelo registo canónico e é indispensável na primeira exposição de um principiante. O profissional deve verificar prontidão, demonstrar a tarefa, definir a velocidade de entrada, observar de lado e fora do corredor, controlar o acesso à trajetória e confirmar que a pessoa domina a estratégia de saída. Também é necessária supervisão quando houver progressão para maior velocidade ou impacto. Ler e compreender estas instruções não substitui essa observação presencial.

## Como terminar

O exercício termina apenas quando estás parado em apoio bipodal estável, orientado para a frente e com controlo do tronco. Depois, confirma que o corredor está livre, recupera uma respiração confortável e sai lateralmente da zona de chegada; não regressas a correr pelo mesmo corredor.

## Nota de segurança

Este é um exercício técnico de risco operacional elevado devido às forças de reação do solo, ao carregamento rápido dos tecidos e à possibilidade de perda de controlo em velocidade. Não o pratiques sozinho na primeira exposição. Interrompe se não conseguires iniciar a travagem cedo, manter a direção ou estabilizar antes do fim de todo o espaço livre.

## Quando parar ou reduzir

1. Dor aguda.
2. Mal-estar, tonturas, desorientação ou sensação de desmaio.
3. Falta de ar inesperada ou desconforto no peito.
4. Perda súbita de coordenação.
5. Incapacidade de controlar a travagem, os contactos ou a posição final.
6. Entrada de pessoa, animal ou objeto no corredor.
7. Alteração do piso, da iluminação ou das condições ambientais que comprometa a aderência ou a visibilidade.

## Segurança do equipamento

Sem equipamento obrigatório. Mantém o corpo livre de cargas e não uses objetos como travão ou apoio. Calçado, se usado, deve estar bem ajustado e ser compatível com a superfície; esta verificação não transforma o calçado em equipamento obrigatório do exercício.

## Segurança do espaço

Executa apenas numa pista de atletismo, pavilhão desportivo ou campo que ofereça um corredor linear livre, piso firme, regular e antiderrapante, boa visibilidade, zona de travagem e zona de saída. Não executes com trânsito ativo, cruzamento público não controlado, piso escorregadio ou instável, obstáculos, iluminação insuficiente ou pessoas dentro da trajetória.

## Limitações

1. A maior parte da evidência direta estudou atletas ou adultos recreativamente treinados, não principiantes absolutos.
2. Não existe nas fontes consultadas uma distância de travagem segura que possa ser generalizada; a distância depende da velocidade, da pessoa, da superfície e do contexto.
3. As fontes não validam prática autónoma na primeira exposição.
4. Não são fornecidas dose, velocidade, intensidade, progressão, diagnóstico, tratamento ou promessa de resultado.
5. A relação condicional com o aquecimento continua dependente de lógica de produto e não é resolvida por este conteúdo.
6. Implementação realizada: não
7. Limite documentado: Distância individual de travagem e velocidade de entrada: pertencem à prescrição e à decisão do profissional no contexto.
8. Limite documentado: Adequação individual para populações que requerem adaptação ou revisão: exige avaliação fora deste conteúdo.
9. Limite documentado: Relação condicional de utilização no aquecimento: permanece por resolver na lógica de produto.

## Teste de compreensão

### 1. Podes praticar este exercício técnico sozinho no primeiro dia depois de leres as instruções?

Resposta esperada: Não. A primeira exposição requer supervisão presencial de um profissional qualificado.

### 2. Qual é a direção do movimento durante a corrida e a travagem?

Resposta esperada: Em linha reta e orientado para a frente.

### 3. Quando deves iniciar a travagem?

Resposta esperada: Antes de faltar espaço, dentro da zona definida pelo supervisor.

### 4. Deves tentar parar num único passo?

Resposta esperada: Não. A velocidade é reduzida por vários contactos sucessivos.

### 5. Como devem participar tornozelos, joelhos e ancas na travagem?

Resposta esperada: Com flexão coordenada, sem bloquear os joelhos nem dobrar apenas a cintura.

### 6. Como reconheces a posição final correta?

Resposta esperada: Apoio nos dois pés, orientação frontal, joelhos desbloqueados e tronco estável.

### 7. O que fazes se perceberes que não vais parar no local previsto?

Resposta esperada: Continuo em frente pela zona de saída livre e desacelero por mais passos, sem virar, cair ou procurar um obstáculo.

### 8. Podes usar uma parede ou outra pessoa para ajudar a parar?

Resposta esperada: Não.

### 9. Como deves respirar?

Resposta esperada: De forma natural, regular e contínua, sem prender a respiração nem impor contagens.

### 10. Que características deve ter a superfície?

Resposta esperada: Firme, regular e antiderrapante.

### 11. Indica dois sinais que obrigam a interromper.

Resposta esperada: Por exemplo, dor aguda, mal-estar, tonturas, perda de coordenação, falta de ar inesperada ou incapacidade de travar com controlo.

### 12. Quem define a velocidade de entrada e confirma o espaço na primeira exposição?

Resposta esperada: O profissional que supervisiona.

## Fontes e limites da evidência

### Fonte 1: National Strength and Conditioning Association. Acceleration and Deceleration Mechanics.

- Autor ou entidade: SP-B2-S11 — National Strength and Conditioning Association. Acceleration and Deceleration Mechanics. — organização profissional; orientação técnica — https://www.nsca.com/education/articles/kinetic-select/acceleration-and-deceleration-mechanics/ — Sustenta a distinção entre aceleração e desaceleração, a postura mais vertical na travagem, a flexão coordenada dos membros inferiores, os passos mais curtos e o aumento progressivo do tempo de contacto. — É orientação profissional e não um ensaio em principiantes absolutos.
- Tipo: organização profissional; orientação técnica
- Localizador: https://www.nsca.com/education/articles/kinetic-select/acceleration-and-deceleration-mechanics/
- Usada para: SP-B2-S11 — National Strength and Conditioning Association. Acceleration and Deceleration Mechanics. — organização profissional; orientação técnica — https://www.nsca.com/education/articles/kinetic-select/acceleration-and-deceleration-mechanics/ — Sustenta a distinção entre aceleração e desaceleração, a postura mais vertical na travagem, a flexão coordenada dos membros inferiores, os passos mais curtos e o aumento progressivo do tempo de contacto. — É orientação profissional e não um ensaio em principiantes absolutos.
- Limite: SP-B2-S11 — National Strength and Conditioning Association. Acceleration and Deceleration Mechanics. — organização profissional; orientação técnica — https://www.nsca.com/education/articles/kinetic-select/acceleration-and-deceleration-mechanics/ — Sustenta a distinção entre aceleração e desaceleração, a postura mais vertical na travagem, a flexão coordenada dos membros inferiores, os passos mais curtos e o aumento progressivo do tempo de contacto. — É orientação profissional e não um ensaio em principiantes absolutos.

### Fonte 2: Harper DJ, Morin JB, Carling C, Kiely J. Measuring maximal horizontal deceleration ability using radar technology: reliability and sensitivity of kinematic and kinetic variables. Sports Biomechanics.

- Autor ou entidade: B1-S21 — Harper DJ, Morin JB, Carling C, Kiely J. Measuring maximal horizontal deceleration ability using radar technology: reliability and sensitivity of kinematic and kinetic variables. Sports Biomechanics. — estudo biomecânico primário — https://doi.org/10.1080/14763141.2020.1792968 — Sustenta a existência de uma fase mensurável de travagem horizontal e a relevância de tempo e distância até parar; o protocolo incluiu demonstração, familiarização e supervisão. — A amostra era composta por atletas universitários familiarizados com desacelerações, não por principiantes absolutos; o protocolo de teste não é transferido como prescrição.
- Tipo: estudo biomecânico primário
- Localizador: https://doi.org/10.1080/14763141.2020.1792968
- Usada para: B1-S21 — Harper DJ, Morin JB, Carling C, Kiely J. Measuring maximal horizontal deceleration ability using radar technology: reliability and sensitivity of kinematic and kinetic variables. Sports Biomechanics. — estudo biomecânico primário — https://doi.org/10.1080/14763141.2020.1792968 — Sustenta a existência de uma fase mensurável de travagem horizontal e a relevância de tempo e distância até parar; o protocolo incluiu demonstração, familiarização e supervisão. — A amostra era composta por atletas universitários familiarizados com desacelerações, não por principiantes absolutos; o protocolo de teste não é transferido como prescrição.
- Limite: B1-S21 — Harper DJ, Morin JB, Carling C, Kiely J. Measuring maximal horizontal deceleration ability using radar technology: reliability and sensitivity of kinematic and kinetic variables. Sports Biomechanics. — estudo biomecânico primário — https://doi.org/10.1080/14763141.2020.1792968 — Sustenta a existência de uma fase mensurável de travagem horizontal e a relevância de tempo e distância até parar; o protocolo incluiu demonstração, familiarização e supervisão. — A amostra era composta por atletas universitários familiarizados com desacelerações, não por principiantes absolutos; o protocolo de teste não é transferido como prescrição.

### Fonte 3: McBurnie AJ et al. Deceleration Training in Team Sports: Another Potential Training Load? Sports Medicine.

- Autor ou entidade: SP-B2-S21 — McBurnie AJ et al. Deceleration Training in Team Sports: Another Potential Training Load? Sports Medicine. — revisão científica — https://pmc.ncbi.nlm.nih.gov/articles/PMC8761154/ — Enquadra a desaceleração como exigência mecânica distinta, com ação muscular de travagem e carregamento relevante. — É evidência de família e de contexto desportivo, não valida uma técnica ou dose universal para principiantes.
- Tipo: revisão científica
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC8761154/
- Usada para: SP-B2-S21 — McBurnie AJ et al. Deceleration Training in Team Sports: Another Potential Training Load? Sports Medicine. — revisão científica — https://pmc.ncbi.nlm.nih.gov/articles/PMC8761154/ — Enquadra a desaceleração como exigência mecânica distinta, com ação muscular de travagem e carregamento relevante. — É evidência de família e de contexto desportivo, não valida uma técnica ou dose universal para principiantes.
- Limite: SP-B2-S21 — McBurnie AJ et al. Deceleration Training in Team Sports: Another Potential Training Load? Sports Medicine. — revisão científica — https://pmc.ncbi.nlm.nih.gov/articles/PMC8761154/ — Enquadra a desaceleração como exigência mecânica distinta, com ação muscular de travagem e carregamento relevante. — É evidência de família e de contexto desportivo, não valida uma técnica ou dose universal para principiantes.

### Fonte 4: Philipp NM, Johnson QR, Cabarkapa D, Fry AC. Acute effects of lower limb wearable resistance on horizontal deceleration and change of direction biomechanics. PLOS ONE.

- Autor ou entidade: EX18-S04 — Philipp NM, Johnson QR, Cabarkapa D, Fry AC. Acute effects of lower limb wearable resistance on horizontal deceleration and change of direction biomechanics. PLOS ONE. — estudo biomecânico primário independente — https://doi.org/10.1371/journal.pone.0308536 — Documenta parâmetros biomecânicos da desaceleração, múltiplos passos de travagem e familiarização supervisionada; reforça que a mecânica depende das condições da tarefa. — Participaram adultos recreativamente treinados com experiência desportiva; os resultados com resistência vestível não autorizam acrescentar equipamento a este exercício.
- Tipo: estudo biomecânico primário independente
- Localizador: https://doi.org/10.1371/journal.pone.0308536
- Usada para: EX18-S04 — Philipp NM, Johnson QR, Cabarkapa D, Fry AC. Acute effects of lower limb wearable resistance on horizontal deceleration and change of direction biomechanics. PLOS ONE. — estudo biomecânico primário independente — https://doi.org/10.1371/journal.pone.0308536 — Documenta parâmetros biomecânicos da desaceleração, múltiplos passos de travagem e familiarização supervisionada; reforça que a mecânica depende das condições da tarefa. — Participaram adultos recreativamente treinados com experiência desportiva; os resultados com resistência vestível não autorizam acrescentar equipamento a este exercício.
- Limite: EX18-S04 — Philipp NM, Johnson QR, Cabarkapa D, Fry AC. Acute effects of lower limb wearable resistance on horizontal deceleration and change of direction biomechanics. PLOS ONE. — estudo biomecânico primário independente — https://doi.org/10.1371/journal.pone.0308536 — Documenta parâmetros biomecânicos da desaceleração, múltiplos passos de travagem e familiarização supervisionada; reforça que a mecânica depende das condições da tarefa. — Participaram adultos recreativamente treinados com experiência desportiva; os resultados com resistência vestível não autorizam acrescentar equipamento a este exercício.

### Fonte 5: American Heart Association. Getting Active to Control High Blood Pressure.

- Autor ou entidade: EX18-S05 — American Heart Association. Getting Active to Control High Blood Pressure. — orientação oficial de saúde — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Sustenta respirar regularmente durante a atividade e evitar a retenção voluntária da respiração. — Não é orientação específica para sprint ou para este exercício técnico; por isso não se impõe um padrão respiratório rígido.
- Tipo: orientação oficial de saúde
- Localizador: https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure
- Usada para: EX18-S05 — American Heart Association. Getting Active to Control High Blood Pressure. — orientação oficial de saúde — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Sustenta respirar regularmente durante a atividade e evitar a retenção voluntária da respiração. — Não é orientação específica para sprint ou para este exercício técnico; por isso não se impõe um padrão respiratório rígido.
- Limite: EX18-S05 — American Heart Association. Getting Active to Control High Blood Pressure. — orientação oficial de saúde — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Sustenta respirar regularmente durante a atividade e evitar a retenção voluntária da respiração. — Não é orientação específica para sprint ou para este exercício técnico; por isso não se impõe um padrão respiratório rígido.

### Fonte 6: England Athletics. Leadership in Running Fitness.

- Autor ou entidade: EX18-S06 — England Athletics. Leadership in Running Fitness. — federação nacional; enquadramento profissional — https://www.englandathletics.org/coaches-and-officials/coaching-qualifications/leadership-in-running-fitness/ — Sustenta a importância de avaliação de risco, demonstração, instruções claras e supervisão na condução segura de atividades de corrida. — É um enquadramento de formação de líderes, não uma validação experimental do sprint com paragem controlada.
- Tipo: federação nacional; enquadramento profissional
- Localizador: https://www.englandathletics.org/coaches-and-officials/coaching-qualifications/leadership-in-running-fitness/
- Usada para: EX18-S06 — England Athletics. Leadership in Running Fitness. — federação nacional; enquadramento profissional — https://www.englandathletics.org/coaches-and-officials/coaching-qualifications/leadership-in-running-fitness/ — Sustenta a importância de avaliação de risco, demonstração, instruções claras e supervisão na condução segura de atividades de corrida. — É um enquadramento de formação de líderes, não uma validação experimental do sprint com paragem controlada.
- Limite: EX18-S06 — England Athletics. Leadership in Running Fitness. — federação nacional; enquadramento profissional — https://www.englandathletics.org/coaches-and-officials/coaching-qualifications/leadership-in-running-fitness/ — Sustenta a importância de avaliação de risco, demonstração, instruções claras e supervisão na condução segura de atividades de corrida. — É um enquadramento de formação de líderes, não uma validação experimental do sprint com paragem controlada.
