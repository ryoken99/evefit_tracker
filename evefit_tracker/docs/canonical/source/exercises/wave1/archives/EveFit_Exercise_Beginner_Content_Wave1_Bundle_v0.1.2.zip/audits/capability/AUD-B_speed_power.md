# AUD-B — Auditoria independente de `speed_power`

**Data:** 2026-07-24  
**Auditor:** AUD-B — Velocidade e Potência  
**Papel:** auditor independente; não autor do conteúdo  
**Resultado global:** `passed_with_revisions`  
**Blockers:** 0  
**Implementação realizada:** não

## Âmbito

Foram auditados todos e apenas os nove exercícios cujo JSON declara `capability_primary == "speed_power"`:

1. `two_point_sprint_start` — EX-12;
2. `plyometric_push_up` — EX-13;
3. `standing_medicine_ball_chest_pass` — EX-14;
4. `standing_broad_jump` — EX-15;
5. `countermovement_jump` — EX-16;
6. `bilateral_pogo_jump` — EX-17;
7. `sprint_to_controlled_stop` — EX-18;
8. `linear_sprint` — EX-19;
9. `sled_resisted_sprint` — EX-20.

Para cada exercício foram comparados o JSON público, o Markdown público e o relatório de investigação. Os invariantes foram confirmados exclusivamente contra o respetivo pacote em `_beginner_content_workspace/agent_inputs/EX-12` a `EX-20`. Não foram lidos relatórios de outros auditores.

## Método

- Seleção fechada por valor literal de `capability_primary`.
- Validação de JSON, Unicode NFC, presença e ordem relativa das chaves obrigatórias, mínimos contratuais, forma dos erros comuns e 12 perguntas de compreensão.
- Comparação exata de `exercise_id`, nome, tipo de entidade, estado canónico, capacidade, família, `variant_of` e `base_exercise_id` com o registo canónico.
- Comparação de mecânica, posição, trajetória, suporte, equipamento, ambiente, superfície, espaço, supervisão, risco, elegibilidade, aterragem/travagem e relações aprovadas.
- Revisão editorial de clareza para principiante, especificidade da posição e dos passos, respiração, sensações, erros observáveis, correções e estratégia de saída.
- Pesquisa interna por dose, carga, intensidade, duração, distância, cadência, promessa, diagnóstico, tratamento, autorização universal e afirmação de implementação.
- Comparação das fontes entre JSON, Markdown e relatório, sem validação web externa.

## Estados por exercício

| Exercício | Estado | Síntese |
|---|---|---|
| `two_point_sprint_start` | `passed` | Identidade de drill e limite antes do sprint contínuo claros; posição, primeiros apoios, travagem, respiração, risco alto, cinco campos adicionais, equipamento, espaço e duas relações preservados. |
| `plyometric_push_up` | `passed_with_revisions` | Execução, receção bilateral, saída, supervisão e fronteira com variantes estão fortes; há deriva de metadados de fontes e uma chave JSON não contratual. |
| `standing_medicine_ball_chest_pass` | `passed` | Risco moderado corretamente preservado; bola obrigatória, parceiro e alvo opcionais, trajetória balística, não receção nuclear, controlo do implemento e respiração coerentes. Os cinco campos de risco alto não se aplicam. |
| `standing_broad_jump` | `passed` | Projeção horizontal isolada, receção bipodal, travagem, corredor frontal, supervisão e ausência de alvo de distância estão claramente preservados. |
| `countermovement_jump` | `passed_with_revisions` | Mecânica, distinção do `squat jump`, receção e relações estão corretas; há uma formulação prescritiva de intensidade e um tipo JSON isolado. |
| `bilateral_pogo_jump` | `passed_with_revisions` | Identidade reativa, contacto, aterragem final, risco alto e saída estão claros; há deriva de esquema em fases e uma chave JSON não contratual. |
| `sprint_to_controlled_stop` | `passed_with_revisions` | Travagem por vários apoios, fim bipodal frontal, zona de saída e estratégia de falha estão bem descritos; faltam metadados bibliográficos no JSON e existe uma chave não contratual. |
| `linear_sprint` | `passed_with_revisions` | Mecânica cíclica, aceleração, travagem, marcadores opcionais e risco alto estão preservados; os passos/fases usam chaves divergentes e o Markdown não apresenta a rastreabilidade das fontes. |
| `sled_resisted_sprint` | `passed_with_revisions` | Variante, trenó obrigatório, alternativa arnês/cinto, linha de tração, travagem do corpo e trenó e explicação formal da variante estão corretos; duas estruturas JSON divergem da família. |

## Findings

### F-01 — Metadados de fontes incompletos entre formatos

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** `plyometric_push_up`, `sprint_to_controlled_stop`, `linear_sprint`
- **Campo:** `sources_consulted`; secções de fontes do Markdown e do relatório
- **Evidência:** no JSON, as 9 fontes de `plyometric_push_up`, as 6 de `sprint_to_controlled_stop` e as 9 de `linear_sprint` têm `title`, `authors_or_body` e `year` vazios ou ausentes, embora os relatórios identifiquem as mesmas fontes. Todos os 24 URLs constam dos respetivos relatórios. O Markdown de `plyometric_push_up` omite `EX13-S06`; o Markdown de `linear_sprint` não contém secção de fontes nem qualquer um dos 9 URLs.
- **Revisão exigida:** preencher metadados bibliográficos identificáveis no JSON a partir do relatório já existente e sincronizar a lista pública de fontes do Markdown. Não acrescentar fontes nem alterar conclusões técnicas.

### F-02 — Forma JSON incoerente nos passos, fases e secções de detalhe

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** `bilateral_pogo_jump`, `linear_sprint`, `sled_resisted_sprint`
- **Campo:** `execution_steps_pt_pt`, `movement_phases_pt_pt`, `exercise_detail_sections`
- **Evidência:** `linear_sprint.execution_steps_pt_pt` usa `step_number`, enquanto a forma dominante usa `step`; as suas fases usam `phase_id` + `name_pt_pt`. `bilateral_pogo_jump` usa `phase` em vez de `phase_pt_pt`. `sled_resisted_sprint.execution_steps_pt_pt` é uma lista de strings, não de objetos numerados, e `exercise_detail_sections` é um objeto, enquanto nos outros oito exercícios é uma lista de secções.
- **Revisão exigida:** normalizar estas estruturas para uma única forma familiar documentada, preservando integralmente o texto, a ordem e o significado.

### F-03 — Chaves de implementação fora do contrato

- **Severidade:** baixa
- **Blocker:** não
- **Exercícios:** `plyometric_push_up`, `bilateral_pogo_jump`, `sprint_to_controlled_stop`
- **Campo:** chaves de topo do JSON
- **Evidência:** `plyometric_push_up` e `sprint_to_controlled_stop` acrescentam `implementation_status_pt_pt`; `bilateral_pogo_jump` acrescenta a chave com espaço `Implementação realizada`. Estas chaves não pertencem às chaves obrigatórias, aos cinco campos de risco alto nem ao campo adicional de variante. O valor confirma “não”, mas cria deriva de esquema.
- **Revisão exigida:** remover as chaves JSON não contratuais; manter “Implementação realizada: não” apenas no relatório/Markdown se o processo exigir essa declaração.

### F-04 — Simplificação formula uma intensidade relativa

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `countermovement_jump`
- **Campo:** `beginner_simplifications_pt_pt[2]`; Markdown, “Simplificações para aprendizagem”
- **Evidência:** “Usar uma intenção de salto baixa definida pelo supervisor” introduz uma intensidade relativa escolhida para a pessoa, apesar de o contrato proibir intensidade prescrita e de o próprio conteúdo afirmar que não escolhe intensidade.
- **Revisão exigida:** substituir por um ensaio técnico não prescritivo e observável, ou remeter qualquer escolha individual de intensidade para fora deste conteúdo sem instruir “baixa”.

### F-05 — Campo textual de equipamento com tipo isolado

- **Severidade:** baixa
- **Blocker:** não
- **Exercício:** `countermovement_jump`
- **Campo:** `equipment_setup_pt_pt`
- **Evidência:** é o único objeto entre os nove exercícios e contém novamente `required_equipment`, `optional_equipment` e `no_equipment_supported`, além de `instruction_pt_pt`. Nos restantes exercícios, o campo é texto ou lista de texto. O conteúdo material está correto — sem equipamento — mas a forma não é coerente com a finalidade textual do campo.
- **Revisão exigida:** reduzir o valor à instrução PT-PT ou adotar a forma familiar que vier a ser formalmente definida, sem alterar o invariante de ausência de equipamento.

## Confirmações canónicas

- Identidade, família, tipo, `variant_of`, `base_exercise_id`, capacidade e estado canónico: 9/9 preservados.
- Risco: 8 exercícios `high` e `standing_medicine_ball_chest_pass` `moderate`, sem reduções.
- Cinco campos adicionais de risco alto: 40/40 presentes e substantivos nos oito exercícios aplicáveis.
- Variante formal: `sled_resisted_sprint` preserva `variant_of == linear_sprint`, `base_exercise_id == linear_sprint` e os 8 subcampos exigidos.
- Equipamento: bola medicinal obrigatória em EX-14; trenó obrigatório e arnês ou cinto como alternativa em EX-20; marcadores apenas opcionais em EX-19; nenhum equipamento obrigatório nos restantes.
- Ambiente: superfícies firmes, regulares e antiderrapantes; zonas de aterragem, lançamento, corrida e travagem coerentes; trânsito e cruzamento público excluídos.
- Supervisão: `recommended` preservado nos 9; primeira exposição reforçada nos exercícios de risco alto sem transformar `spotter_required: false`.
- Estrutura mínima: 9/9 com pelo menos 5 passos, 4 cues, 4 erros completos e 12 perguntas; todos os erros têm comportamento observável e correção.
- Respiração: 9/9 sem retenções ou contagens impostas; orientação específica apenas quando apresentada com limites.
- Dose e promessas: nenhuma dose fixa, série, repetição, distância, duração, carga, cadência ou promessa de resultado. A exceção de formulação relativa está registada em F-04.
- Relações: apenas relações aprovadas; relações condicionais permanecem condicionais e não há redução de risco ou revisão.
- Relatórios de investigação: os 62 URLs declarados nos JSON aparecem nos respetivos relatórios; as limitações de transferência para principiantes estão documentadas.

## Padrões transversais

1. A segurança substantiva é consistentemente conservadora: primeira exposição observada, pré-requisitos, zona livre, sinais de interrupção e saída controlada aparecem de forma clara.
2. A receção/travagem é mais forte nos exercícios de salto e sprint do que o mínimo contratual: há critérios observáveis, erros e saída perante falha.
3. A principal fraqueza não é biomecânica; é de normalização do JSON e sincronização bibliográfica entre formatos.
4. A expressão “aprovado com limites” é coerente com a evidência, mas não deve esconder os desvios de esquema e de fronteira com prescrição enumerados acima.

## Contagens finais

| Métrica | Contagem |
|---|---:|
| Exercícios auditados | 9 |
| `passed` | 3 |
| `passed_with_revisions` | 6 |
| `failed` | 0 |
| Findings | 5 |
| Findings de severidade alta | 0 |
| Findings de severidade média | 3 |
| Findings de severidade baixa | 2 |
| Blockers | 0 |
| Exercícios de risco alto | 8 |
| Campos adicionais de risco alto verificados | 40 |
| URLs JSON confirmados nos relatórios | 62/62 |

## Independência e zero implementação

Esta auditoria foi efetuada por AUD-B, que não foi autor dos conteúdos. Não foram consultados relatórios de outros auditores. Não foram editados JSON, Markdown, relatórios de investigação, pacotes canónicos ou qualquer outro conteúdo. Não foi produzido código, não foi feita publicação e não foi realizada implementação. O único artefacto criado é este relatório de auditoria.
