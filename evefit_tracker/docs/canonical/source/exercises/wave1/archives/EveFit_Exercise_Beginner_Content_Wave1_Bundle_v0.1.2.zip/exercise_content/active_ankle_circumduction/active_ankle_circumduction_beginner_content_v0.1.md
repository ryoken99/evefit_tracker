# Circundução ativa do tornozelo

Conteúdo para principiantes em português europeu.

## Descrição curta

Exploração multiplanar fechada do tornozelo e complexo subtalar, sem carga externa e sem impulso.

## O que é

Sentada numa cadeira estável, conduzes o pé por uma trajetória circular ativa a partir do tornozelo, enquanto manténs a coxa e o joelho relativamente imóveis.

## O que vais fazer

Vais libertar um pé do chão e desenhar no ar uma trajetória circular contínua com esse pé. O círculo resulta da passagem controlada por várias direções do tornozelo; não é um balanço de toda a perna.

## Porque existe este movimento

Este movimento existe para explorar ativamente várias direções articulares do tornozelo numa trajetória contínua. A descrição não garante qualquer resultado individual.

## Antes de começares

1. Confirma que compreendes a ação, que consegues controlar voluntariamente o pé dentro de uma amplitude tolerada e que tens uma cadeira estável sem rodas sobre um piso firme, nivelado e antiderrapante. Mantém o espaço imediato sem obstáculos.

## Preparar o equipamento

1. Coloca uma cadeira estável sem rodas no local escolhido. Verifica que os quatro apoios da cadeira assentam no chão e que a cadeira não desliza nem oscila. Não substituas a cadeira por um banco instável, uma bola ou um assento com rodas.

## Preparar o espaço

1. Usa um espaço estacionário mínimo, com piso firme, nivelado e antiderrapante sob a cadeira. Deixa a zona à frente e ao lado do pé livre sem objetos. Não executes numa plataforma instável, num veículo em movimento ou sobre piso escorregadio.

## Verificação do corpo

1. Antes de iniciares, verifica se te sentes estável na cadeira, sem tontura ou mal-estar, e se o tornozelo permite começar um movimento pequeno sem dor aguda, bloqueio ou perda súbita de controlo. Se algum destes sinais estiver presente, não prossigas.

## Posição inicial

Senta-te na cadeira com o tronco confortável e estável. Mantém o pé do lado oposto apoiado no chão e a coxa da perna-alvo apoiada no assento. Eleva apenas o pé-alvo o suficiente para ficar sem carga e sem tocar no chão.

## Confirmar a posição inicial

1. A cadeira é estável, não tem rodas e não desliza.
2. O piso é firme, nivelado e antiderrapante.
3. O pé do lado oposto permanece apoiado e a base sentada está estável.
4. A coxa da perna-alvo está apoiada e o joelho aponta numa direção confortável.
5. O pé-alvo está livre do chão e há espaço para o mover.
6. Não há dor aguda, bloqueio, tontura, mal-estar ou perda de controlo antes de começares.

## Passos de execução

1. Fixa suavemente a posição da coxa e do joelho, sem criar tensão desnecessária no resto do corpo.
2. Conduz a parte da frente do pé para cima, iniciando a trajetória a partir do tornozelo.
3. Continua a deslocar o pé para um dos lados, mantendo o joelho relativamente imóvel.
4. Aponta o pé para baixo apenas até onde a passagem se mantém controlada e confortável.
5. Leva o pé para o lado oposto, sem balançar a perna nem usar impulso.
6. Fecha o círculo regressando ao ponto de partida com uma trajetória contínua, mesmo que o círculo seja pequeno ou não pareça perfeitamente redondo.
7. Se explorares o sentido contrário, mantém os mesmos critérios: movimento lento, joelho relativamente imóvel e amplitude tolerada.

## Fases do movimento

### Preparação

Estabiliza a posição sentada e liberta o pé-alvo do apoio.

### Início da trajetória

Conduz o pé para cima e para um lado a partir do tornozelo.

### Continuação

Passa de forma contínua pela direção descendente e pelo lado oposto, sem impulso.

### Fecho

Regressa ao ponto inicial sem deixar que a coxa ou o joelho desenhem o círculo.

## Respiração

Respira de forma natural e contínua. Não prendas a respiração para aumentar a amplitude nem imponhas uma contagem respiratória ao movimento.

## Sensações esperadas

1. Movimento distribuído à volta do tornozelo e do pé.
2. Esforço ligeiro de controlo nos músculos que orientam o pé.
3. Sensação suave de alongamento em algumas partes da trajetória.
4. Um círculo menor ou menos regular numa zona mais limitada, desde que permaneça controlado e tolerado.

## Sensações inesperadas ou de alerta

1. Dor aguda.
2. Sensação de bloqueio articular.
3. Pinçamento que obriga a forçar ou desviar a trajetória.
4. Perda súbita de controlo do pé ou da perna.
5. Tontura ou mal-estar.

## Indicações técnicas principais

1. Senta-te numa cadeira que não deslize.
2. Mantém a coxa apoiada e o joelho relativamente imóvel.
3. Desenha o círculo com o pé, conduzido pelo tornozelo.
4. Move-te devagar e sem impulso.
5. Usa apenas a amplitude que consegues controlar sem dor aguda ou bloqueio.
6. Respira naturalmente durante toda a trajetória.

## Erros comuns e correções

### Erro 1: Desenhar o círculo com toda a perna.

- Como reconhecer: O joelho desloca-se visivelmente de um lado para o outro ou a coxa roda no assento.
- Como corrigir: Mantém a coxa apoiada, reduz o tamanho do círculo e volta a conduzir o movimento pelo tornozelo.

### Erro 2: Usar balanço ou impulso.

- Como reconhecer: O pé acelera, salta partes da trajetória ou continua a mover-se sem controlo deliberado.
- Como corrigir: Abranda e trata cada parte do círculo como uma passagem controlada.

### Erro 3: Forçar o fim da amplitude.

- Como reconhecer: Surge dor aguda, pinçamento, bloqueio ou necessidade de torcer o joelho para avançar.
- Como corrigir: Interrompe perante sinais de paragem; se não houver um sinal de paragem, regressa a uma amplitude menor e tolerada.

### Erro 4: Tentar produzir um círculo grande ou perfeitamente redondo a qualquer custo.

- Como reconhecer: A trajetória perde suavidade ou outras partes da perna começam a compensar.
- Como corrigir: Aceita uma trajetória pequena ou ligeiramente irregular e dá prioridade ao controlo.

### Erro 5: Deixar o pé tocar no chão durante a trajetória.

- Como reconhecer: A ponta do pé ou o calcanhar roça no piso e altera o círculo.
- Como corrigir: Ajusta a posição sentada para criar espaço sob o pé, mantendo a cadeira e a coxa estáveis.

### Erro 6: Prender a respiração.

- Como reconhecer: A respiração fica suspensa nas zonas difíceis do círculo.
- Como corrigir: Reduz a amplitude e deixa a respiração continuar naturalmente.

## Formas de simplificar ou ensaiar

1. Imagina que o dedo grande do pé é um lápis que desenha o contorno de uma moeda no ar.
2. Começa por reconhecer separadamente as direções para cima, para o lado, para baixo e para o lado oposto; depois liga-as numa trajetória contínua.
3. Escolhe um círculo menor sempre que isso ajude a manter a coxa e o joelho relativamente imóveis.
4. Usa uma referência visual fixa à frente do joelho para perceber se a perna está a compensar.

## Supervisão

A supervisão não é um requisito de base e não é necessário um observador. Procura orientação de um profissional qualificado se não conseguires manter o suporte previsto, se tiveres medo de cair, se surgirem sintomas durante a amplitude ou se não conseguires distinguir o movimento do tornozelo da compensação da perna. Cirurgia recente, retorno à função, sintomas persistentes ou instabilidade conhecida também exigem revisão individual antes de usar este conteúdo.

## Como terminar

Diminui o tamanho da trajetória, leva o pé a uma posição confortável e pousa-o no chão de forma controlada. Mantém-te sentada até confirmares que não há tontura, mal-estar ou perda de controlo antes de te levantares.

## Nota de segurança

A trajetória deve permanecer controlada e dentro de uma amplitude tolerada. Não forces uma zona de dor aguda, bloqueio ou pinçamento. A cadeira, o apoio e a superfície têm de continuar estáveis durante toda a execução.

## Quando parar ou reduzir

1. Dor aguda. Bloqueio articular. Perda súbita de controlo. Tontura ou mal-estar.
2. A coxa ou o joelho começam a conduzir o círculo. A trajetória deixa de ser controlada. É necessário usar impulso para passar uma zona. Surge pinçamento sem dor aguda: reduz a amplitude; se não desaparecer, termina o movimento.

## Segurança do equipamento

Usa apenas uma cadeira estável sem rodas. Não uses um assento que oscile, deslize ou se desloque quando te sentas ou quando elevas o pé.

## Segurança do espaço

Mantém a cadeira sobre piso firme, nivelado e antiderrapante, com a zona do pé livre sem obstáculos. Não uses piso escorregadio, plataforma instável ou veículo em movimento.

## Limitações

1. Não foi encontrada literatura primária que teste isoladamente esta exata circundução sentada como instrução para principiantes.
2. A literatura biomecânica sustenta a natureza acoplada do complexo do tornozelo, mas não determina uma trajetória circular ideal nem prova um resultado individual.
3. O conteúdo não substitui avaliação individual quando existem sintomas persistentes, instabilidade conhecida, cirurgia recente ou retorno à função.
4. Não foram definidos volume, frequência, duração, intensidade, progressão ou qualquer outro parâmetro de dose.
5. Não foi aprovada multimédia e não foi realizada implementação.

## Teste de compreensão

### 1. Que tipo de cadeira deves usar?

Resposta esperada: Uma cadeira estável, sem rodas e que não deslize.

### 2. Como deve ser o piso sob a cadeira?

Resposta esperada: Firme, nivelado e antiderrapante.

### 3. O pé-alvo fica apoiado no chão durante o círculo?

Resposta esperada: Não. Fica livre do chão e sem carga.

### 4. Que parte do corpo deve conduzir a trajetória?

Resposta esperada: O pé, a partir do tornozelo.

### 5. O que deve acontecer à coxa e ao joelho?

Resposta esperada: A coxa fica apoiada e o joelho permanece relativamente imóvel.

### 6. É necessário que o círculo seja grande e perfeitamente redondo?

Resposta esperada: Não. O controlo e a amplitude tolerada são mais importantes.

### 7. Deves usar balanço para passar uma zona difícil?

Resposta esperada: Não. A trajetória deve ser lenta, deliberada e sem impulso.

### 8. Como deves respirar?

Resposta esperada: De forma natural e contínua, sem prender a respiração.

### 9. O que fazes se o joelho começar a desenhar o círculo?

Resposta esperada: Reduzo a amplitude, estabilizo a coxa e volto a conduzir o movimento pelo tornozelo.

### 10. Que sinais obrigam a terminar o movimento?

Resposta esperada: Dor aguda, bloqueio articular, perda súbita de controlo, tontura ou mal-estar.

### 11. Quando pode ser útil orientação profissional?

Resposta esperada: Quando não consigo manter o suporte, tenho medo de cair, surgem sintomas, confundo o movimento com compensação, ou existe retorno à função, cirurgia recente, sintomas persistentes ou instabilidade conhecida.

### 12. Como terminas o exercício?

Resposta esperada: Diminuo a trajetória, levo o pé a uma posição confortável e pouso-o de forma controlada.

## Fontes e limites da evidência

### Fonte 1: Controlled Articular Rotations: Shifting Mobility into High Gear

- Autor ou entidade: American Council on Exercise
- Tipo: orientação profissional
- Localizador: https://www.acefitness.org/continuing-education/certified/october-2024/8725/controlled-articular-rotations-shifting-mobility-into-high-gear/
- Usada para: Movimento articular lento, deliberado, ativo, controlado, sem impulso e dentro de amplitude sem dor; limites do âmbito do profissional de exercício.
- Limite: Não é um ensaio de eficácia e descreve a família geral de rotações articulares controladas, não este exercício sentado de forma isolada.

### Fonte 2: Foot and Ankle Conditioning Program

- Autor ou entidade: American Academy of Orthopaedic Surgeons, OrthoInfo
- Tipo: orientação ortopédica oficial revista por pares
- Localizador: https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/
- Usada para: Posição sentada com o pé livre, condução pelo pé e tornozelo, movimento pequeno e alerta para não ignorar dor.
- Limite: A tarefa descrita é o alfabeto do tornozelo e integra um programa clínico; não foram importados volume, frequência, eficácia ou elegibilidade clínica.

### Fonte 3: Ankle range of movement exercises

- Autor ou entidade: Royal Berkshire NHS Foundation Trust, Physiotherapy Department
- Tipo: orientação clínica oficial
- Localizador: https://www.royalberkshire.nhs.uk/media/iz3hdgmm/ankle-range-of-movement-exercises_dec25.pdf
- Usada para: Circundução em posição sentada, movimento lento, exploração dos dois sentidos e manutenção do joelho imóvel nas ações associadas.
- Limite: O folheto dirige-se a pessoas após lesão e não testa a eficácia isolada da circundução; não foram importadas indicações clínicas nem dose.

### Fonte 4: Mobility of the subtalar joint in the intact ankle complex

- Autor ou entidade: Leardini, Stagni e O'Connor; Journal of Biomechanics
- Tipo: literatura primária biomecânica
- Localizador: https://pubmed.ncbi.nlm.nih.gov/11470119/
- Usada para: Suporte para descrever o complexo subtalar como movimento acoplado e para evitar interpretar o círculo como rotação isolada de uma única articulação.
- Limite: Estudo in vitro em sete espécimes, com movimento passivo e momentos externos; não fornece instruções para principiantes, critérios de respiração ou prova de eficácia.
