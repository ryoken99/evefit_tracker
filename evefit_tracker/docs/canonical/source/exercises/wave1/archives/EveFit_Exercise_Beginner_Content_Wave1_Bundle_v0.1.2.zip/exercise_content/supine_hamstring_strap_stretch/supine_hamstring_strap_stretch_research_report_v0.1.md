# Relatório de investigação — `supine_hamstring_strap_stretch`

## Âmbito

Investigação documental limitada à execução da variante formal com correia ou toalha no pé, incluindo preparação do equipamento, respiração, sensações, segurança, erros e supervisão. Foram preservados a identidade canónica, o nível de risco, o grupo alternativo de equipamento, o tapete opcional, a superfície estável e antiderrapante, a ausência de observador obrigatório e as relações aprovadas.

Não foram transpostos parâmetros quantitativos ou temporais, programas de progressão, resultados garantidos, interpretações clínicas individuais ou alterações ontológicas.

## Conclusão editorial

O conteúdo pode ser apresentado a principiantes com limites explícitos. A sequência técnica nuclear tem apoio direto da UCSF: correia ou toalha segura no pé, subida lenta assistida, joelho a aproximar-se da extensão e regresso lento. O HSS confirma independentemente o uso de uma correia no pé e associa a execução a tração suave, ausência de dor e capacidade de respirar.

A segurança foi formulada de modo conservador. A orientação geral da Mayo Clinic distingue tensão de dor, recomenda movimento suave sem balanços e respiração normal. Um estudo primário de Muanjai e colaboradores não encontrou vantagem aguda em levar o alongamento até à dor comparativamente ao ponto de desconforto; por isso, a dor não é usada como alvo. Um estudo biomecânico primário de Bueno-Gracia e colaboradores mostrou que a dorsiflexão durante a elevação da perna estendida altera a tensão e o deslocamento do nervo ciático sem produzir a mesma alteração no bicípite femoral; por isso, o conteúdo não manda puxar o pé para trás e trata formigueiro e sensação elétrica como sinais para libertar a tração.

## Fontes e contribuição

| Fonte | Natureza | Contribuição usada | Limite |
|---|---|---|---|
| American Academy of Orthopaedic Surgeons, [Knee Conditioning Program](https://orthoinfo.aaos.org/en/recovery/knee-conditioning-program/) (`D1-EXT-08`) | Guia profissional oficial já presente no pacote | Entrada gradual, sensação posterior e cuidado para não aplicar tração na articulação do joelho | A correia é descrita na coxa, não no pé; apoio apenas de família |
| Page P., [Current concepts in muscle stretching for exercise and rehabilitation](https://pmc.ncbi.nlm.nih.gov/articles/PMC3273886/) (`D2-S05`) | Revisão profissional já presente no pacote | Enquadramento do alongamento estático e execução controlada | Não valida todos os detalhes desta variante |
| UCSF Orthopaedic Institute, [Lower Body Stretches — Supine Hamstring Stretch with Strap](https://sportsrehab.ucsf.edu/sites/g/files/tkssra10961/files/doc/Lower_Body_Stretches_Nov2025.pdf) | Material técnico institucional | Correia ou toalha no pé, elevação lenta assistida, aproximação do joelho à extensão e regresso lento | Não detalha respiração, sinais neurais, pressão do material ou supervisão |
| Hospital for Special Surgery, [Supine Hamstring Stretch](https://www.hss.edu/health-library/move-better/stretches-before-bed) | Orientação profissional institucional | Correia no pé, tração suave, respiração durante a posição e não ultrapassar a dor | Contexto geral; não estabelece elegibilidade individual |
| Mayo Clinic, [Stretching: Focus on flexibility](https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20047931) | Orientação profissional institucional | Movimento suave sem balanços, respiração normal, tensão em vez de dor e adaptação perante fatores relevantes | Não é específica para esta variante nem fixa a posição da correia |
| Muanjai P. et al., [The acute benefits and risks of passive stretching to the point of pain](https://pubmed.ncbi.nlm.nih.gov/28391391/), DOI `10.1007/s00421-017-3608-y` | Estudo primário | A dor não mostrou vantagem aguda sobre o ponto de desconforto; apoia linguagem de tensão controlável | Amostra e protocolo específicos; não demonstra segurança universal nem superioridade desta variante |
| Bueno-Gracia E. et al., [Differential movement of the sciatic nerve and hamstrings during the straight leg raise with ankle dorsiflexion](https://pubmed.ncbi.nlm.nih.gov/31374476/), DOI `10.1016/j.msksp.2019.07.011` | Estudo biomecânico primário em cadáveres | A posição do tornozelo pode mudar a mecânica neural; apoia não forçar o pé e interromper perante sintomas neurais | Não avalia execução por principiantes e não permite atribuir causa individual a uma sensação |

## Síntese por tema

### Execução com correia

A evidência técnica direta converge numa sequência simples: corpo deitado, material seguro no pé, elevação lenta com assistência das mãos, joelho a aproximar-se da extensão e descida controlada. O registo canónico acrescenta a exigência de manter bacia e tronco apoiados e de aliviar a tração antes da saída.

### Equipamento

A correia de alongamento e a toalha permanecem alternativas dentro do mesmo grupo. Pelo menos uma é necessária para esta variante; o tapete continua opcional. Os riscos canónicos de rutura, deslizamento e pressão dolorosa foram traduzidos em verificações observáveis: material íntegro e seco, colocação estável, teste com pouca tensão e reposicionamento apenas depois de baixar a perna.

### Respiração

HSS e Mayo convergem na capacidade de respirar durante o alongamento e na respiração normal. Não foi encontrada base para impor contagens, pausas ou sincronização rígida; o conteúdo usa respiração natural e contínua e considera a retenção involuntária um sinal para reduzir a tração.

### Sensações

A sensação esperada foi limitada a tensão suave, gradual, difusa e controlável atrás da coxa, com eventual sensação ligeira nos gémeos. Dor, pressão dolorosa localizada, dormência, formigueiro, ardor, sensação elétrica e fraqueza permanecem fora do perfil esperado.

### Erros

Os erros documentados decorrem da técnica institucional e dos riscos canónicos: puxão brusco, procura de altura com levantamento da bacia, bloqueio forçado do joelho, colocação instável da correia, ombros elevados com respiração presa e continuação perante dor ou sintomas neurais.

### Supervisão

Foi preservado `supervision_requirement: none` e `spotter_required: false`. A execução não requer observador por defeito quando a pessoa compreende o movimento, controla a entrada e a saída e cumpre os pré-requisitos. Orientação qualificada é indicada quando a posição não é compreendida, quando o equipamento ou o corpo não permanecem estáveis, ou quando historial, sintomas, retorno após lesão ou cirurgia, hipermobilidade ou outra condição alteram a elegibilidade.

## Justificação da variante formal

O exercício-base usa autoassistência direta pelas mãos. Nesta variante, a força das mãos chega ao pé através de uma correia ou toalha. A alteração muda:

- a forma de aplicar força;
- a forma de o corpo receber força;
- a alavanca da assistência;
- o requisito material;
- os riscos de pressão, deslizamento e excesso de tração.

Permanecem a posição em decúbito dorsal, a ação unilateral de flexão da anca com o joelho próximo da extensão, o apoio do tronco e da bacia e o controlo da amplitude pela própria pessoa. Esta combinação justifica uma variante separada sem criar uma nova família e sem copiar a assistência manual direta do exercício-base.

## Limitações e inferências

- Não existe nas fontes consultadas uma norma única para a zona exata do pé; foi preservada a formulação canónica de zona estável, confortável e sem deslizamento.
- A indicação para não forçar o pé para trás é uma inferência prudente a partir de biomecânica cadavérica e do risco canónico de sintomas neurais.
- A investigação sobre alongamento até à dor não replica a variante com correia no pé e apenas limita a linguagem de intensidade.
- As orientações institucionais não estabelecem uma amplitude universal.
- A ausência de supervisão por defeito não elimina a necessidade de orientação quando a elegibilidade muda.
- Nenhuma fonte sustenta uma promessa individual ou uma autorização universal para executar.

## Verificação do contrato

- Identidade, risco, equipamento, superfície, supervisão e relações preservados.
- `formal_variant_explanation` preenchido com os oito campos exigidos.
- Execução documentada com oito passos.
- Seis indicações principais.
- Seis erros comuns com reconhecimento e correção.
- Doze perguntas de compreensão.
- Português europeu e codificação UTF-8.
- Sem parâmetros quantitativos ou temporais, progressão programada, promessa de resultado, interpretação clínica individual ou implementação de código.

**Implementação realizada: não**
