# Avanço de dorsiflexão do tornozelo em meio-ajoelhado

Conteúdo para principiantes em português europeu.

## Descrição curta

Em meio-ajoelhado, avança e recua o joelho da frente sobre o pé totalmente apoiado, sem levantar o calcanhar.

## O que é

É uma transição repetível de dorsiflexão do tornozelo em carga parcial. Um joelho fica apoiado atrás e o pé da frente permanece inteiro no chão enquanto o joelho avança e regressa. Não é o teste joelho-à-parede e não serve, neste conteúdo, para medir uma distância.

## O que vais fazer

Vais assumir uma posição de meio-ajoelhado, estabilizar o pé da frente, deslocar suavemente o joelho para a frente sobre esse pé e voltar à posição inicial com controlo.

## Porque existe este movimento

Este movimento existe para praticar a transição para dorsiflexão do tornozelo com o pé apoiado, sem transformar a ação numa avaliação ou numa promessa de resultado.

## Antes de começares

1. Confirma que compreendes a ação de avançar e recuar o joelho sem perder o apoio do pé.
2. Escolhe uma zona livre de obstáculos, com piso firme, nivelado e antiderrapante.
3. Verifica se consegues apoiar o joelho de trás de forma tolerável; um tapete de exercício é opcional.
4. Não inicies se não conseguires controlar a posição de meio-ajoelhado ou se já estiveres com dor aguda, bloqueio articular, tontura ou mal-estar.
5. Se estás em retorno à função, após cirurgia recente, ou tens sintomas persistentes ou instabilidade conhecida, segue a orientação do profissional que acompanha o teu caso.

## Preparar o equipamento

1. Nenhum equipamento portátil é obrigatório.
2. Podes colocar um tapete de exercício estável sob o joelho de trás para tornar o contacto mais tolerável.
3. Se usares tapete, confirma que fica plano, não desliza e não altera o apoio completo do pé da frente.

## Preparar o espaço

1. Usa uma superfície firme, nivelada e antiderrapante.
2. Reserva uma pequena área desimpedida para a posição de meio-ajoelhado e para o ligeiro avanço do corpo.
3. Evita superfícies escorregadias, instáveis ou que impeçam o contacto completo do pé da frente.
4. Garante que a zona sob o joelho de trás é tolerável e não contém objetos duros ou pontiagudos.

## Verificação do corpo

1. Consegues colocar o pé da frente inteiro no chão, incluindo calcanhar e bases do primeiro e quinto dedos?
2. Consegues apoiar o joelho e a parte inferior da perna de trás sem dor aguda?
3. Consegues manter o equilíbrio e deslocar ligeiramente o corpo para a frente e para trás sem perda súbita de controlo?
4. Consegues avançar o joelho numa amplitude pequena sem o pé colapsar ou o calcanhar levantar?

## Posição inicial

Fica em meio-ajoelhado: um joelho e a parte inferior dessa perna apoiados atrás, e o outro pé à frente, plano no chão. Mantém o tronco equilibrado sobre a base de apoio e orienta o pé da frente para uma direção confortável, sem o deixar rodar durante o movimento.

## Confirmar a posição inicial

1. Pé da frente totalmente apoiado.
2. Calcanhar da frente em contacto com o chão.
3. Bases do primeiro e quinto dedos da frente apoiadas.
4. Joelho de trás e parte inferior da perna apoiados numa superfície tolerável.
5. Área à volta livre de obstáculos.
6. Equilíbrio estável antes de iniciar o avanço.

## Passos de execução

1. Parte da posição de meio-ajoelhado e distribui o apoio pelo calcanhar e pela parte anterior do pé da frente.
2. Confirma que o joelho da frente está orientado sobre o pé, sem cair para dentro, e mantém a bacia controlada.
3. Deixa a respiração decorrer de forma natural e contínua antes de iniciares o deslocamento.
4. Desloca suavemente o joelho da frente e uma pequena parte do corpo para a frente, mantendo o pé inteiro em contacto com o chão.
5. Permite que o tornozelo dobre à medida que o joelho avança; não empurres o joelho à força nem rode o pé para ganhar amplitude.
6. Termina o avanço antes de o calcanhar levantar, o pé colapsar, o joelho perder o alinhamento ou surgir um sinal de aviso.
7. Inverte o movimento e regressa à posição inicial de meio-ajoelhado com controlo, mantendo os contactos de apoio.
8. Reorganiza a posição e o equilíbrio antes de uma nova passagem; quando terminares, recua o corpo e sai do meio-ajoelhado de forma estável.

## Fases do movimento

### Preparação

Estabiliza o pé da frente, o joelho de trás, a bacia e o equilíbrio.

### Avanço

Leva o joelho da frente para a frente sobre o pé enquanto o tornozelo entra em dorsiflexão.

### Limite controlado

Reconhece o ponto anterior à perda do calcanhar, do apoio do pé, do alinhamento ou da tolerância.

### Regresso

Desloca o joelho e o corpo para trás até à posição inicial, sem soltar os apoios.

### Reorganização

Recupera uma posição estável antes de voltar a mover ou de terminar.

## Respiração

Respira de forma natural e contínua durante o avanço e o regresso. Não prendas a respiração e não associes o movimento a contagens ou retenções. Não foi identificada evidência específica que exija uma fase respiratória própria para este exercício.

## Sensações esperadas

1. Tensão suave na parte posterior do tornozelo ou da perna da frente.
2. Pressão distribuída pelo pé da frente, que permanece apoiado.
3. Contacto tolerável do joelho de trás com a superfície.
4. Pequeno deslocamento do peso para a frente e para trás sem impacto.

## Sensações inesperadas ou de alerta

1. Dor aguda no tornozelo, pé ou joelho.
2. Sensação de bloqueio articular ou de que o movimento fica preso.
3. Picada ou compressão anterior forte que aumenta ao avançar.
4. Formigueiro, dormência ou alteração súbita de sensibilidade.
5. Sensação de instabilidade ou perda súbita de controlo.
6. Tontura ou mal-estar.

## Indicações técnicas principais

1. Mantém o pé da frente inteiro no chão.
2. Conserva o calcanhar e as bases do primeiro e quinto dedos apoiados.
3. Leva o joelho para a frente sobre o pé sem o deixar cair para dentro.
4. Avança apenas enquanto manténs apoio, alinhamento e tolerância.
5. Mantém a bacia controlada e evita rodar o corpo para ganhar distância.
6. Regressa devagar à posição inicial, sem perder os contactos.

## Erros comuns e correções

### Erro 1: Levantar o calcanhar da frente.

- Como reconhecer: Surge um espaço entre o calcanhar e o chão ou o peso passa quase todo para a ponta do pé.
- Como corrigir: Recua até o calcanhar voltar a apoiar e usa uma amplitude menor no avanço seguinte.

### Erro 2: Deixar o arco do pé colapsar e o joelho cair para dentro.

- Como reconhecer: A parte interna do pé perde forma e o joelho desloca-se claramente para dentro da linha do pé.
- Como corrigir: Mantém calcanhar e bases do primeiro e quinto dedos apoiados e orienta o joelho sobre o pé.

### Erro 3: Rodar o pé ou a bacia para aparentar mais amplitude.

- Como reconhecer: Os dedos mudam de direção, o calcanhar roda ou a bacia gira durante o avanço.
- Como corrigir: Regressa à posição inicial, reorganiza o alinhamento e reduz o avanço.

### Erro 4: Forçar o joelho para além de uma amplitude controlada.

- Como reconhecer: O movimento torna-se brusco, surge dor ou bloqueio, ou perdes algum contacto de apoio.
- Como corrigir: Pára antes do sinal de perda de controlo e trabalha apenas dentro da amplitude tolerada.

### Erro 5: Transformar o exercício numa medição joelho-à-parede.

- Como reconhecer: A atenção passa para tocar num alvo ou medir a distância do pé, em vez de controlar o avanço e o regresso.
- Como corrigir: Retira o alvo e concentra-te na transição repetível com o pé totalmente apoiado.

### Erro 6: Prender a respiração.

- Como reconhecer: Ficas rígido, fechas a garganta ou só libertas o ar no fim do movimento.
- Como corrigir: Reduz a amplitude e mantém uma respiração natural e contínua.

## Formas de simplificar ou ensaiar

1. Usa uma amplitude menor, terminando o avanço bem antes de qualquer perda do calcanhar ou do alinhamento.
2. Ajusta a distância entre o pé da frente e o joelho de trás até encontrares uma base de meio-ajoelhado estável.
3. Coloca o tapete de exercício opcional sob o joelho de trás se o contacto direto com o chão for desconfortável.
4. Ensaiar primeiro um deslocamento muito pequeno para a frente e para trás pode ajudar a reconhecer os contactos que devem permanecer estáveis.

## Supervisão

A classificação canónica não exige supervisor nem assistente de segurança. Procura supervisão profissional se não conseguires manter os apoios, tiveres medo de cair, surgirem sintomas durante a amplitude ou não conseguires distinguir o movimento do tornozelo de compensações do pé, joelho ou bacia. Pessoas em retorno à função, após cirurgia recente, ou com sintomas persistentes ou instabilidade conhecida devem obter revisão adequada ao seu contexto.

## Como terminar

Regressa primeiro à posição inicial de meio-ajoelhado. Leva o peso para trás, apoia as mãos no próprio corpo se necessário para te organizares, junta os apoios de forma controlada e levanta-te apenas quando estiveres estável. Se aparecer um sinal de interrupção, não forces outra passagem.

## Nota de segurança

Risco operacional moderado. Mantém o pé da frente totalmente apoiado, usa uma superfície firme e antiderrapante e limita o avanço à amplitude em que controlas o calcanhar, o arco do pé, o joelho e a bacia. Reduz ou interrompe perante dor aguda, bloqueio articular, perda súbita de controlo, tontura ou mal-estar. Este conteúdo não diagnostica, não trata e não substitui orientação clínica individual.

## Quando parar ou reduzir

1. O calcanhar levanta, o pé colapsa ou o joelho perde o alinhamento. — Reduz a amplitude e regressa à última posição controlada.
2. Surge dor aguda ou uma compressão forte que aumenta. — Interrompe o movimento.
3. Surge bloqueio articular. — Interrompe e não forces a passagem.
4. Há perda súbita de controlo ou instabilidade. — Regressa a uma posição estável e termina.
5. Surge tontura ou mal-estar. — Termina o exercício e adota uma posição segura.

## Segurança do equipamento

Não é necessário equipamento portátil. Se usares o tapete opcional, coloca-o apenas sob o joelho de trás, plano e sem dobras; confirma que não desliza e que o pé da frente continua totalmente apoiado numa superfície firme.

## Segurança do espaço

Executa apenas numa área de meio-ajoelhado desimpedida, com piso firme, nivelado, antiderrapante e tolerável para o joelho de trás. Não uses uma superfície instável, escorregadia ou que impeça o apoio completo do pé.

## Limitações

1. A evidência é sobretudo de família mecânica, avaliação em carga e reabilitação específica de lesão. Não estabelece benefício individual, dose, valor-alvo de amplitude nem adequação universal. A respiração natural e contínua é uma orientação conservadora do contrato, não um padrão específico validado. Implementação realizada: não.
2. Limite documentado: Não foi encontrada investigação primária sobre a identidade pública exata, sem alvo, sem medição e sem assistência externa.
3. Limite documentado: Não foi encontrado um padrão respiratório específico validado para este exercício.
4. Limite documentado: A adequação perante cirurgia recente, sintomas persistentes, instabilidade conhecida ou retorno à função depende de revisão contextual.

## Teste de compreensão

### 1. Qual é a posição de base deste exercício?

Resposta esperada: Meio-ajoelhado, com um joelho e a parte inferior da perna apoiados atrás e o outro pé plano à frente.

### 2. Que partes do pé da frente devem permanecer apoiadas?

Resposta esperada: O calcanhar e as bases do primeiro e quinto dedos, mantendo o pé inteiro no chão.

### 3. Em que direção se move o joelho da frente?

Resposta esperada: Para a frente sobre o pé, sem cair para dentro.

### 4. O que deves fazer se o calcanhar começar a levantar?

Resposta esperada: Recusar essa amplitude, recuar até recuperar o apoio e usar um avanço menor.

### 5. Este exercício serve para medir a distância do pé à parede?

Resposta esperada: Não. Isso transformaria a ação num teste joelho-à-parede, que é uma entidade de avaliação diferente.

### 6. Como deve decorrer a respiração?

Resposta esperada: De forma natural e contínua, sem prender o ar nem usar contagens.

### 7. Que sensação pode ser esperada?

Resposta esperada: Uma tensão suave atrás do tornozelo ou da perna da frente e pressão distribuída pelo pé.

### 8. Indica dois sinais para interromper o exercício.

Resposta esperada: Por exemplo, dor aguda, bloqueio articular, perda súbita de controlo, tontura ou mal-estar.

### 9. Que superfície deves escolher?

Resposta esperada: Uma superfície firme, nivelada, antiderrapante e tolerável para o joelho de trás.

### 10. É obrigatório usar equipamento?

Resposta esperada: Não. O tapete de exercício sob o joelho de trás é apenas opcional.

### 11. Como reconheces uma compensação do pé ou da bacia?

Resposta esperada: O arco colapsa, os dedos ou o calcanhar rodam, o joelho cai para dentro ou a bacia gira para ganhar amplitude.

### 12. Quando faz sentido procurar supervisão profissional?

Resposta esperada: Quando não consegues manter os apoios, tens medo de cair, surgem sintomas ou não distingues o movimento alvo das compensações; também em contextos clínicos que exigem revisão.

## Fontes e limites da evidência

### Fonte 1: Kingston and Richmond NHS Foundation Trust. What to expect after an ankle fracture. 2024.

- Autor ou entidade: C1-S21 — Kingston and Richmond NHS Foundation Trust. What to expect after an ankle fracture. 2024. — https://www.kingstonandrichmond.nhs.uk/patients-and-families/patient-leaflets/what-expect-after-ankle-fracture — orientação clínica profissional oficial — Sustenta o movimento do joelho para a frente com o pé apoiado, a progressão por conforto e a necessidade de não agravar dor. — É material pós-fratura; não foi usada a dose nem foi generalizada autorização clínica.
- Tipo: orientação clínica profissional oficial
- Localizador: https://www.kingstonandrichmond.nhs.uk/patients-and-families/patient-leaflets/what-expect-after-ankle-fracture
- Usada para: C1-S21 — Kingston and Richmond NHS Foundation Trust. What to expect after an ankle fracture. 2024. — https://www.kingstonandrichmond.nhs.uk/patients-and-families/patient-leaflets/what-expect-after-ankle-fracture — orientação clínica profissional oficial — Sustenta o movimento do joelho para a frente com o pé apoiado, a progressão por conforto e a necessidade de não agravar dor. — É material pós-fratura; não foi usada a dose nem foi generalizada autorização clínica.
- Limite: C1-S21 — Kingston and Richmond NHS Foundation Trust. What to expect after an ankle fracture. 2024. — https://www.kingstonandrichmond.nhs.uk/patients-and-families/patient-leaflets/what-expect-after-ankle-fracture — orientação clínica profissional oficial — Sustenta o movimento do joelho para a frente com o pé apoiado, a progressão por conforto e a necessidade de não agravar dor. — É material pós-fratura; não foi usada a dose nem foi generalizada autorização clínica.

### Fonte 2: Martin RL, et al. Ankle Stability and Movement Coordination Impairments: Lateral Ankle Ligament Sprains Revision 2021. J Orthop Sports Phys Ther. 2021;51(4):CPG1-CPG80.

- Autor ou entidade: C2-S21 — Martin RL, et al. Ankle Stability and Movement Coordination Impairments: Lateral Ankle Ligament Sprains Revision 2021. J Orthop Sports Phys Ther. 2021;51(4):CPG1-CPG80. — https://www.orthopt.org/uploads/content_files/files/jospt.2021.0302.pdf — guideline de prática clínica — Sustenta amplitude protegida, exercício estruturado e adaptação à gravidade, limitações e necessidades da pessoa. — É específica de entorse lateral do tornozelo e dirigida a clínicos; não valida isoladamente este exercício para todas as pessoas.
- Tipo: guideline de prática clínica
- Localizador: https://www.orthopt.org/uploads/content_files/files/jospt.2021.0302.pdf
- Usada para: C2-S21 — Martin RL, et al. Ankle Stability and Movement Coordination Impairments: Lateral Ankle Ligament Sprains Revision 2021. J Orthop Sports Phys Ther. 2021;51(4):CPG1-CPG80. — https://www.orthopt.org/uploads/content_files/files/jospt.2021.0302.pdf — guideline de prática clínica — Sustenta amplitude protegida, exercício estruturado e adaptação à gravidade, limitações e necessidades da pessoa. — É específica de entorse lateral do tornozelo e dirigida a clínicos; não valida isoladamente este exercício para todas as pessoas.
- Limite: C2-S21 — Martin RL, et al. Ankle Stability and Movement Coordination Impairments: Lateral Ankle Ligament Sprains Revision 2021. J Orthop Sports Phys Ther. 2021;51(4):CPG1-CPG80. — https://www.orthopt.org/uploads/content_files/files/jospt.2021.0302.pdf — guideline de prática clínica — Sustenta amplitude protegida, exercício estruturado e adaptação à gravidade, limitações e necessidades da pessoa. — É específica de entorse lateral do tornozelo e dirigida a clínicos; não valida isoladamente este exercício para todas as pessoas.

### Fonte 3: Alamer A, et al. Effect of Ankle Joint Mobilization with Movement on Range of Motion, Balance and Gait Function: A Systematic Review. 2021.

- Autor ou entidade: C2-S22 — Alamer A, et al. Effect of Ankle Joint Mobilization with Movement on Range of Motion, Balance and Gait Function: A Systematic Review. 2021. — https://pubmed.ncbi.nlm.nih.gov/34512072/ — revisão sistemática — Delimita a fronteira entre movimento ativo simples e mobilização com movimento assistida por técnica manual ou externa. — A mobilização com movimento é dependente da técnica e das populações estudadas; não justifica acrescentar banda ou manipulação à identidade base.
- Tipo: revisão sistemática
- Localizador: https://pubmed.ncbi.nlm.nih.gov/34512072/
- Usada para: C2-S22 — Alamer A, et al. Effect of Ankle Joint Mobilization with Movement on Range of Motion, Balance and Gait Function: A Systematic Review. 2021. — https://pubmed.ncbi.nlm.nih.gov/34512072/ — revisão sistemática — Delimita a fronteira entre movimento ativo simples e mobilização com movimento assistida por técnica manual ou externa. — A mobilização com movimento é dependente da técnica e das populações estudadas; não justifica acrescentar banda ou manipulação à identidade base.
- Limite: C2-S22 — Alamer A, et al. Effect of Ankle Joint Mobilization with Movement on Range of Motion, Balance and Gait Function: A Systematic Review. 2021. — https://pubmed.ncbi.nlm.nih.gov/34512072/ — revisão sistemática — Delimita a fronteira entre movimento ativo simples e mobilização com movimento assistida por técnica manual ou externa. — A mobilização com movimento é dependente da técnica e das populações estudadas; não justifica acrescentar banda ou manipulação à identidade base.

### Fonte 4: Chisholm MD, Birmingham TB, Brown J, MacDermid J, Chesworth BM. Reliability and validity of a weight-bearing measure of ankle dorsiflexion range of motion. Physiother Can. 2012;64(4):347-355.

- Autor ou entidade: EX21-R1 — Chisholm MD, Birmingham TB, Brown J, MacDermid J, Chesworth BM. Reliability and validity of a weight-bearing measure of ankle dorsiflexion range of motion. Physiother Can. 2012;64(4):347-355. — https://pmc.ncbi.nlm.nih.gov/articles/PMC3484905/ — estudo primário de fiabilidade e validade — Confirma a natureza em carga da dorsiflexão em avanço e ajuda a separar uma medição clínica do exercício sem medição. — Estuda um teste e não uma intervenção; não sustenta dose, eficácia ou metas de amplitude para este conteúdo.
- Tipo: estudo primário de fiabilidade e validade
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC3484905/
- Usada para: EX21-R1 — Chisholm MD, Birmingham TB, Brown J, MacDermid J, Chesworth BM. Reliability and validity of a weight-bearing measure of ankle dorsiflexion range of motion. Physiother Can. 2012;64(4):347-355. — https://pmc.ncbi.nlm.nih.gov/articles/PMC3484905/ — estudo primário de fiabilidade e validade — Confirma a natureza em carga da dorsiflexão em avanço e ajuda a separar uma medição clínica do exercício sem medição. — Estuda um teste e não uma intervenção; não sustenta dose, eficácia ou metas de amplitude para este conteúdo.
- Limite: EX21-R1 — Chisholm MD, Birmingham TB, Brown J, MacDermid J, Chesworth BM. Reliability and validity of a weight-bearing measure of ankle dorsiflexion range of motion. Physiother Can. 2012;64(4):347-355. — https://pmc.ncbi.nlm.nih.gov/articles/PMC3484905/ — estudo primário de fiabilidade e validade — Confirma a natureza em carga da dorsiflexão em avanço e ajuda a separar uma medição clínica do exercício sem medição. — Estuda um teste e não uma intervenção; não sustenta dose, eficácia ou metas de amplitude para este conteúdo.

### Fonte 5: Plisky PJ, et al. The Dorsiflexion Range of Motion Screen: A Validation Study. Int J Sports Phys Ther. 2021;16(2):306-311.

- Autor ou entidade: EX21-R2 — Plisky PJ, et al. The Dorsiflexion Range of Motion Screen: A Validation Study. Int J Sports Phys Ther. 2021;16(2):306-311. — https://ijspt.scholasticahq.com/article/21253-the-dorsiflexion-range-of-motion-screen-a-validation-study — estudo primário de validação — Sustenta que posições em cadeia fechada e em meio-ajoelhado são usadas para observar dorsiflexão e reforça a distinção entre screen, medida e exercício. — Avalia um screen em adultos jovens sem lesão atual; não demonstra o efeito do exercício.
- Tipo: estudo primário de validação
- Localizador: https://ijspt.scholasticahq.com/article/21253-the-dorsiflexion-range-of-motion-screen-a-validation-study
- Usada para: EX21-R2 — Plisky PJ, et al. The Dorsiflexion Range of Motion Screen: A Validation Study. Int J Sports Phys Ther. 2021;16(2):306-311. — https://ijspt.scholasticahq.com/article/21253-the-dorsiflexion-range-of-motion-screen-a-validation-study — estudo primário de validação — Sustenta que posições em cadeia fechada e em meio-ajoelhado são usadas para observar dorsiflexão e reforça a distinção entre screen, medida e exercício. — Avalia um screen em adultos jovens sem lesão atual; não demonstra o efeito do exercício.
- Limite: EX21-R2 — Plisky PJ, et al. The Dorsiflexion Range of Motion Screen: A Validation Study. Int J Sports Phys Ther. 2021;16(2):306-311. — https://ijspt.scholasticahq.com/article/21253-the-dorsiflexion-range-of-motion-screen-a-validation-study — estudo primário de validação — Sustenta que posições em cadeia fechada e em meio-ajoelhado são usadas para observar dorsiflexão e reforça a distinção entre screen, medida e exercício. — Avalia um screen em adultos jovens sem lesão atual; não demonstra o efeito do exercício.

### Fonte 6: Massachusetts General Hospital Physical Therapy Services. Physical Therapy Guidelines for Lateral Ankle Sprain.

- Autor ou entidade: EX21-R3 — Massachusetts General Hospital Physical Therapy Services. Physical Therapy Guidelines for Lateral Ankle Sprain. — https://www.massgeneral.org/assets/mgh/pdf/orthopaedics/foot-ankle/pt-guidelines-for-ankle-sprain.pdf — protocolo clínico profissional oficial — Sustenta começar o movimento em amplitude sem dor, progredir a carga conforme tolerada e adaptar às diferenças individuais. — É um protocolo para entorse lateral; não foi transferida qualquer cronologia, dose ou promessa de recuperação.
- Tipo: protocolo clínico profissional oficial
- Localizador: https://www.massgeneral.org/assets/mgh/pdf/orthopaedics/foot-ankle/pt-guidelines-for-ankle-sprain.pdf
- Usada para: EX21-R3 — Massachusetts General Hospital Physical Therapy Services. Physical Therapy Guidelines for Lateral Ankle Sprain. — https://www.massgeneral.org/assets/mgh/pdf/orthopaedics/foot-ankle/pt-guidelines-for-ankle-sprain.pdf — protocolo clínico profissional oficial — Sustenta começar o movimento em amplitude sem dor, progredir a carga conforme tolerada e adaptar às diferenças individuais. — É um protocolo para entorse lateral; não foi transferida qualquer cronologia, dose ou promessa de recuperação.
- Limite: EX21-R3 — Massachusetts General Hospital Physical Therapy Services. Physical Therapy Guidelines for Lateral Ankle Sprain. — https://www.massgeneral.org/assets/mgh/pdf/orthopaedics/foot-ankle/pt-guidelines-for-ankle-sprain.pdf — protocolo clínico profissional oficial — Sustenta começar o movimento em amplitude sem dor, progredir a carga conforme tolerada e adaptar às diferenças individuais. — É um protocolo para entorse lateral; não foi transferida qualquer cronologia, dose ou promessa de recuperação.
