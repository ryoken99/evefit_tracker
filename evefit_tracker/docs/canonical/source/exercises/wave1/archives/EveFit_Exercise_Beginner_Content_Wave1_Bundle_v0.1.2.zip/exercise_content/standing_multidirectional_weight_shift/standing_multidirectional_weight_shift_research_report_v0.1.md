# Relatório de investigação — Transferência de peso multidirecional em pé

**Agente:** EX-40  
**Exercise ID:** `standing_multidirectional_weight_shift`  
**Data da pesquisa:** 24 de julho de 2026  
**Âmbito:** execução sem passo, apoio, respiração, risco de queda, erros e supervisão  
**Implementação realizada: não**

## Resultado

O conteúdo para principiantes pode ser aprovado com limites. A identidade está bem sustentada como deslocação do centro de massa dentro de uma base bipodal fixa: os pés mantêm-se no solo e o corpo regressa ao centro sem dar um passo. A instrução mais direta encontrada é lateral; a formulação multidirecional resulta da conjugação prudente dessa orientação profissional com literatura primária sobre limites de estabilidade anteroposteriores e mediolaterais.

Não foi encontrada uma cadência respiratória específica para esta tarefa. Por isso, a orientação limita-se a respiração natural e contínua, ombros relaxados e ausência de retenção, sem contagens.

## Perguntas de investigação

1. Como explicar uma transferência de peso em pé sem a confundir com um passo?
2. Que contacto dos pés, organização corporal e regresso ao centro são defensáveis?
3. Como enquadrar apoio opcional, superfície e espaço?
4. Que sinais indicam aproximação excessiva ao limite de estabilidade?
5. Que erros são observáveis por um principiante?
6. Quando deve a supervisão ser reforçada?
7. Existe uma orientação respiratória específica sustentada?

## Método e critérios

Foram mantidos sem alteração a identidade canónica, o risco operacional baixo, o apoio estável opcional, a superfície firme/plana/antiderrapante, a supervisão recomendada e as três relações aprovadas. A pesquisa externa privilegiou:

- orientação oficial ou profissional com instruções observáveis;

- guideline profissional para risco de queda;

- literatura primária sobre limites de estabilidade e transferência de peso;

- fontes independentes entre si;

- linguagem que não introduz dose, prescrição, promessa, diagnóstico ou autorização universal.

## Evidência por fonte

| Código | Fonte | Tipo | Contributo utilizado | Limite |
|---|---|---|---|---|
| E1-SRC-014 | Kirk-Sanchez et al.; APTA Geriatrics, 2025 | Guideline clínica profissional | Raciocínio individual e supervisão/revisão em presença de risco de queda | Incide em adultos com 65 ou mais anos; não determina elegibilidade individual neste documento |
| E2-S08 | UNC Center for Aging and Health, 2024 | Manual profissional | Enquadramento individualizado e profissional de tarefas de equilíbrio do programa Otago | É um programa completo; não permite atribuir os seus resultados a um exercício isolado |
| WEB-EX40-01 | Leicestershire Partnership NHS Trust, 2022 | Manual profissional de fisioterapia | Transferência lateral com pés à largura da anca, mãos em apoio conforme orientação e ambos os pés no solo; níveis de contacto junto de superfície estável | A instrução direta é lateral e integra um serviço de quedas |
| WEB-EX40-02 | NHS, 2023 | Orientação oficial ao público | Parede ou cadeira estável por perto e execução lenta/controlada em tarefas de equilíbrio | Não descreve esta transferência multidirecional específica |
| WEB-EX40-03 | Tomita et al., 2021 | Estudo primário observacional | Limites de estabilidade em oito direções e base de apoio funcional inferior à área geométrica dos pés; diferenças direcionais | Amostra de adultos mais velhos e jovens em medição laboratorial |
| WEB-EX40-04 | Gouglidis et al., 2011 | Estudo primário experimental | Distinção entre treino anteroposterior e mediolateral; participação coordenada dos segmentos durante inclinação e oscilação | Mulheres mais velhas, tarefa visualmente guiada e dose experimental não transferida para o conteúdo |
| WEB-EX40-05 | Cambridge University Hospitals, 2024 | Orientação profissional de fisioterapia | Respirar durante a atividade, relaxar ombros e evitar retenção do ar | Orientação respiratória geral, não específica desta tarefa |

## Síntese técnica

### Identidade e execução sem passo

A transferência lateral descrita pelo Leicestershire Partnership NHS Trust mantém ambos os pés no chão enquanto o corpo se desloca de um lado para o outro. Isto sustenta diretamente as pistas «pés imóveis» e «pressão a mudar entre os pés».

Os estudos de limites de estabilidade operacionalizam deslocações em várias direções mantendo a postura em pé. Esta literatura sustenta a existência de limites direcionais, mas não define uma amplitude pública universal. Por isso, o limite foi descrito de forma observável: terminar a deslocação antes de ser necessário dar um passo, agarrar o apoio subitamente ou perder o controlo do regresso.

### Organização corporal

Gouglidis et al. observaram alterações na rotação dos segmentos durante treino de deslocação anteroposterior ou mediolateral. O conteúdo traduz este ponto sem impor um modelo rígido: o corpo desloca-se de forma coordenada, o tronco mantém-se alongado e evita-se dobrar ou rodar apenas os ombros. Não se prescreve uma estratégia exclusiva de tornozelo ou anca.

### Apoio, superfície e ambiente

As fontes NHS recomendam uma parede, superfície ou cadeira estável quando pode haver perda de equilíbrio. O registo canónico permite apoio estável opcional, sem o tornar requisito para todas as pessoas. O conteúdo preserva essa condição e acrescenta apenas verificações operacionais: sem rodas, sem deslizamento, ao alcance e sem necessidade de dar um passo para o encontrar.

A superfície permanece firme, plana e antiderrapante, com área desimpedida. Foram mantidas as exclusões canónicas de superfície instável/escorregadia, veículo em movimento e altura desprotegida.

### Respiração

Não foi encontrada uma relação validada entre uma fase concreta desta transferência e inspiração ou expiração. A orientação de Cambridge University Hospitals apoia respiração contínua durante atividade, ombros relaxados e ausência de retenção. O conteúdo não inclui contagens, retenções nem sincronização obrigatória.

### Risco de queda e supervisão

O risco operacional canónico permanece baixo, mas a exigência de equilíbrio é moderada e pode aumentar com grande amplitude, piso inadequado ou risco individual de queda. A supervisão permanece recomendada e é reforçada apenas nos gatilhos já aprovados: risco elevado de queda, contexto clinicamente restringido e incapacidade de sair da tarefa de forma independente. Queda recente e condições neurológicas ou vestibulares são remetidas para revisão profissional, sem diagnóstico ou autorização.

## Erros observáveis derivados

1. Levantar, rodar ou arrastar um pé — viola a base bipodal fixa.
2. Ultrapassar o limite controlável — reconhecido por passo, apoio súbito ou falha no regresso.
3. Dobrar ou rodar apenas o tronco — a pressão nos pés quase não acompanha o movimento.
4. Mudar de direção sem regressar ao centro — reduz o controlo da transição.
5. Usar impulso ou travagem abrupta — incompatível com execução controlada.
6. Pendurar-se num apoio móvel — aumenta o risco associado a apoio não seguro.

## Preservação canónica

| Elemento | Resultado |
|---|---|
| Identidade | Preservada: centro de massa desloca-se dentro da base bipodal fixa |
| Pés | Ambos permanecem em contacto; não há passo |
| Risco | Mantido em `low`; modificadores não reduzidos |
| Equipamento | Nenhum obrigatório; apoio estável opcional |
| Superfície | Firme, plana e antiderrapante |
| Supervisão | `recommended` |
| Relações | Mantidas sem criação, remoção ou alteração |
| Multimédia | Sem aprovação |
| Prescrição | Não incluída |

As relações preservadas são:

- `main_training → motor_control_coordination → base_of_support_control → improve_weight_shift_control` — compatível, `alternative_primary`;

- `recovery → motor_control_coordination → base_of_support_control → maintain_gentle_weight_shift` — condicional, `complementary`;

- `warmup → motor_control_coordination → base_of_support_control → rehearse_weight_shifts` — compatível, `complementary`.

## Fontes

1. Kirk-Sanchez N, McDonough C, Avin K, Blackwood J, Hanke T; APTA Geriatrics. [Physical Therapy Management of Fall Risk in Community-Dwelling Older Adults](https://www.apta.org/patient-care/evidence-based-practice-resources/cpgs/physical-therapy-management-of-fall-risk-in-community-dwelling-older-adults). 2025.

2. UNC Center for Aging and Health. [Tools to Implement the Otago Exercise Program](https://www.med.unc.edu/aging/cgwep/wp-content/uploads/sites/865/2024/04/Otago-Guide-for-PT_April-2024-update.pdf). 2024.

3. Leicestershire Partnership NHS Trust. [Community Falls Team — Strength and Balance Exercises](https://www.leicspart.nhs.uk/wp-content/uploads/2022/07/467A-Falls-service-strength-and-balance-exercises-Ashby-bklet.pdf). 2022.

4. NHS. [Balance exercises](https://www.nhs.uk/live-well/exercise/balance-exercises/). Revista em 7 de novembro de 2023.

5. Tomita H, Kuno S, Kawaguchi D, Nojima O. [Limits of Stability and Functional Base of Support While Standing in Community-Dwelling Older Adults](https://pubmed.ncbi.nlm.nih.gov/32028861/). *Journal of Motor Behavior*. 2021;53(1):83–91. DOI: 10.1080/00222895.2020.1723484.

6. Gouglidis V, Nikodelis T, Hatzitaki V, Amiridis IG. [Changes in the Limits of Stability Induced by Weight-Shifting Training in Elderly Women](https://pubmed.ncbi.nlm.nih.gov/21240818/). *Experimental Aging Research*. 2011;37(1):46–62. DOI: 10.1080/0361073X.2010.507431.

7. Cambridge University Hospitals NHS Foundation Trust. [Breathing pattern disorders and physiotherapy](https://www.cuh.nhs.uk/patient-information/breathing-pattern-disorders-and-physiotherapy/). Aprovada em 5 de junho de 2024.

## Limitações e decisão

- A instrução profissional direta é mais forte para a transferência lateral do que para frente/trás.

- A literatura primária consultada concentra-se em adultos mais velhos e tarefas laboratoriais; foi usada para enquadrar mecanismos, não para prometer resultados.

- Não existe base consultada para uma amplitude, cadência ou dose universal.

- A respiração foi documentada por princípio geral de movimento, não por investigação específica deste exercício.

- A elegibilidade e o grau final de supervisão dependem da pessoa e do contexto.

**Confiança global:** moderada.  
**Campos por resolver:** nenhum dentro do âmbito documental.  
**Decisão:** `beginner_content_approved_with_limits`.
