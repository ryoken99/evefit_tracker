# Salto à corda a dois pés

Conteúdo para principiantes em português europeu.

## Descrição curta

Saltos bilaterais repetidos, sincronizados com a passagem cíclica de uma corda por baixo dos pés.

## O que é

Neste exercício, a corda roda continuamente à volta do corpo e passa por baixo dos pés enquanto ambos os pés saem do chão e regressam ao mesmo tempo. O apoio bilateral distingue-o das variantes com pés alternados; rotações múltiplas por salto não fazem parte desta identidade.

## O que vais fazer

De pé, seguras uma pega em cada mão, rodas a corda sobretudo pelos punhos e sincronizas cada passagem com um salto baixo dos dois pés e uma receção bilateral controlada.

## Porque existe este movimento

A finalidade técnica imediata é coordenar mãos, corda, impulsão, fase aérea e receção num padrão bilateral rítmico. A forma de usar este exercício numa sessão, incluindo duração, cadência, intensidade e pausas, pertence à prescrição e não é definida aqui.

## Antes de começares

1. Confirma que consegues manter apoio estável nos dois pés e realizar um pequeno salto bilateral com receção controlada.
2. Se estás a regressar após lesão ou cirurgia, ou tens sintomas cardiorrespiratórios relevantes, procura avaliação adequada antes de usares uma tarefa de impacto repetido.
3. Não comeces se houver dor nova, tonturas, confusão, desconforto no peito ou falta de ar fora do habitual.
4. Observa primeiro o percurso completo da corda e certifica-te de que não há pessoas, objetos ou teto baixo dentro desse percurso.

## Preparar o equipamento

1. Usa uma corda de saltar funcional, ajustada e sem danos.
2. Verifica se as pegas estão firmes e se a corda não apresenta zonas gastas, cortes, nós ou partes soltas.
3. Para uma verificação prática do comprimento, pisa o centro da corda com os pés juntos e confirma que as pegas chegam aproximadamente à zona inferior das axilas, sem alterar a corda com nós.
4. Segura uma pega em cada mão e confirma que a corda roda livremente antes de a fazer passar por cima da cabeça.

## Preparar o espaço

1. Escolhe uma zona plana, firme, regular, tolerante ao impacto e sem obstáculos.
2. Garante espaço livre por cima, aos lados, à frente e atrás para todo o arco da corda.
3. Afasta-te de superfícies escorregadias, irregulares ou obstruídas e de locais com pouca visibilidade.
4. No exterior, considera calor, frio, qualidade do ar e trânsito; muda de local se algum destes fatores comprometer a segurança.

## Verificação do corpo

1. Consegues ficar de pé com ambos os pés apoiados e o tronco estável?
2. Consegues sair ligeiramente do chão com os dois pés e voltar a apoiá-los em conjunto, sem perder o controlo?
3. Os tornozelos, joelhos e ancas toleram um pequeno salto e a receção sem dor nova?
4. Estás alerta, sem tonturas, confusão, desconforto no peito ou falta de ar atípica?
5. Se a resposta a qualquer verificação essencial for não, não avances para a execução completa.

## Posição inicial

Fica de pé com os pés próximos e paralelos, a corda pousada atrás dos calcanhares, uma pega em cada mão. Mantém o tronco alto, a cabeça orientada para a frente, os joelhos ligeiramente desbloqueados, os cotovelos junto ao corpo e os punhos aproximadamente à altura da cintura.

## Confirmar a posição inicial

1. Corda atrás dos pés e sem estar enrolada.
2. Pés próximos, paralelos e com apoio estável.
3. Joelhos ligeiramente desbloqueados, sem agachamento profundo.
4. Tronco alto e olhar em frente.
5. Cotovelos perto do corpo e mãos ligeiramente afastadas das ancas.
6. Espaço da corda totalmente livre.

## Passos de execução

1. Parte com a corda atrás dos calcanhares e estabiliza o corpo sobre os dois pés.
2. Inicia a rotação levando a corda para cima e para a frente, mantendo os cotovelos perto do tronco.
3. Segue a aproximação da corda ao chão à tua frente e prepara uma pequena impulsão bilateral.
4. Quando a corda se aproxima dos pés, sai ligeiramente do chão com ambos os pés ao mesmo tempo.
5. Deixa a corda passar por baixo durante a fase aérea, mantendo as mãos junto da linha das ancas.
6. Recebe o chão com os dois pés em conjunto e com flexão pequena e natural nos tornozelos, joelhos e ancas.
7. Mantém a rotação e repete o mesmo ciclo apenas enquanto a passagem da corda e as receções continuarem controladas.

## Fases do movimento

### Preparação e rotação

A corda parte atrás do corpo e avança por cima da cabeça, conduzida sobretudo pelos punhos, com cotovelos próximos do tronco.

### Impulsão bilateral

Os dois pés empurram o chão ao mesmo tempo para criar apenas o espaço necessário à passagem da corda.

### Passagem e fase aérea

A corda passa por baixo dos pés enquanto ambos estão fora do chão.

### Receção e novo ciclo

Os dois pés contactam o chão em conjunto; tornozelos, joelhos e ancas cedem de forma pequena e controlada antes da passagem seguinte.

## Respiração

Respira de forma natural, regular e contínua ao longo da rotação, do salto e da receção. Não prendas a respiração e não imponhas contagens respiratórias ao movimento. Se a respiração ficar atipicamente difícil, irregular ou não recuperar quando paras, interrompe e segue a orientação de segurança.

## Sensações esperadas

1. Aumento gradual da respiração e da pulsação compatível com uma tarefa cíclica.
2. Trabalho repetido nos pés, tornozelos e pernas.
3. Contactos ligeiros e repetidos com o chão.
4. Necessidade de atenção ao ritmo conjunto das mãos, da corda e dos pés.

## Sensações inesperadas ou de alerta

1. Desconforto, pressão ou dor no peito.
2. Falta de ar atípica ou desproporcionada.
3. Tonturas, sensação de desmaio, confusão ou perda de orientação.
4. Dor nova ou crescente nos pés, tornozelos, joelhos, ancas ou costas.
5. Perda marcada de equilíbrio, controlo ou coordenação.
6. Impactos progressivamente duros ou incapacidade de receber o chão com controlo.

## Indicações técnicas principais

1. Roda a corda sobretudo pelos punhos.
2. Mantém os cotovelos perto do corpo.
3. Salta apenas o necessário para a passagem.
4. Sai e recebe com os dois pés ao mesmo tempo.
5. Amortece de forma pequena e silenciosa.
6. Respira continuamente, sem prender o ar.

## Erros comuns e correções

### Erro 1: Rodar a corda com círculos grandes dos ombros.

- Como reconhecer: Os braços afastam-se do tronco, as mãos sobem e o percurso da corda fica largo ou irregular.
- Como corrigir: Aproxima os cotovelos do corpo, baixa as mãos para junto da cintura e conduz a rotação sobretudo com os punhos.

### Erro 2: Saltar mais alto do que a passagem da corda exige.

- Como reconhecer: Os joelhos sobem muito, o corpo demora a regressar ao chão e a receção torna-se pesada.
- Como corrigir: Reduz a altura do salto e pensa em criar apenas um pequeno espaço entre os pés e o chão.

### Erro 3: Receber o chão com pernas rígidas.

- Como reconhecer: O contacto é ruidoso, o tronco abana e quase não há cedência nos tornozelos, joelhos e ancas.
- Como corrigir: Deixa essas articulações fletirem ligeiramente na receção e mantém o corpo alinhado sobre os pés.

### Erro 4: Perder o apoio bilateral simultâneo.

- Como reconhecer: Um pé sai ou toca no chão antes do outro, transformando o padrão numa alternância.
- Como corrigir: Pára a corda, volta a colocar os pés próximos e reinicia com impulsão e receção dos dois pés em conjunto.

### Erro 5: Continuar depois de a corda prender repetidamente.

- Como reconhecer: A corda toca nos pés em ciclos sucessivos, o corpo inclina-se ou surgem passos para recuperar o equilíbrio.
- Como corrigir: Deixa a corda parar, verifica o comprimento e a posição das mãos, recupera uma base estável e só depois reorganiza o movimento.

### Erro 6: Olhar constantemente para os pés.

- Como reconhecer: A cabeça e o tronco inclinam-se para a frente e a postura torna-se instável.
- Como corrigir: Mantém o olhar à frente e usa o som e o ritmo da corda para antecipar a passagem.

## Formas de simplificar ou ensaiar

1. Ensaiar separadamente a posição das mãos e a rotação da corda sem saltar; é uma preparação técnica e não substitui o exercício completo.
2. Ensaiar pequenos saltos bilaterais sem corda para confirmar impulsão e receção em conjunto; é uma verificação de prontidão, não uma variante equivalente.
3. Interromper entre tentativas sempre que a corda prender, em vez de tentar recuperar com passos desorganizados.
4. Pedir uma demonstração e feedback a um profissional qualificado se não for possível coordenar a passagem mantendo receções controladas.

## Supervisão

Não existe requisito canónico de supervisão nem de observador. Ainda assim, supervisão profissional é prudente perante instabilidade marcada, dificuldade persistente em coordenar a corda, equipamento ou ambiente desconhecido, limitações de equilíbrio, sedentarismo prévio relevante ou necessidade de adaptação. Pessoas a regressar após lesão ou cirurgia e pessoas com sintomas cardiorrespiratórios relevantes devem procurar revisão adequada antes da execução.

## Como terminar

Para terminar, deixa de impulsionar, abranda a rotação pelos punhos e permite que a corda pouse à frente sem dar passos sobre ela. Fica com os dois pés apoiados, recupera o equilíbrio e continua a respirar naturalmente. Se paraste por um sinal de alarme, não retomes apenas porque a corda já está imóvel.

## Nota de segurança

O risco operacional base é moderado: existem fase aérea, impacto e receções repetidas, além de possibilidade de tropeço ou contacto com a corda. A execução depende de capacidade para manter apoio bilateral controlado, corda funcional, espaço livre e superfície firme, regular e tolerante ao impacto. Fadiga, visibilidade reduzida, ambiente adverso, falha da pega e corda danificada podem aumentar o risco.

## Quando parar ou reduzir

1. Interrompe perante desconforto no peito ou falta de ar atípica.
2. Interrompe perante tonturas, sensação de desmaio, confusão ou desorientação.
3. Interrompe perante dor nova, perda de controlo ou instabilidade marcada.
4. Reduz a exigência técnica ou termina quando as receções deixam de ser controladas ou a corda prende repetidamente.
5. Não retomes no mesmo momento se um sinal de alarme persistir; procura ajuda adequada conforme a gravidade.

## Segurança do equipamento

A corda de saltar é obrigatória; o exercício não tem alternativa sem equipamento. Confirma antes da utilização que a corda e as pegas estão íntegras e que as pegas não se soltam. Não uses uma corda com cortes, desgaste acentuado, nós ou rotação bloqueada. Uma corda demasiado longa pode enrolar-se ou alterar o percurso; uma demasiado curta pode prender nos pés ou forçar posições desadequadas. Se surgir falha da pega, comportamento imprevisível da corda ou enrolamento, pára e retira o equipamento de uso até estar seguro.

## Segurança do espaço

Mantém livre todo o arco superior, lateral, frontal e posterior da corda. Usa apenas uma superfície firme, plana, regular, desimpedida e tolerante ao impacto. Não executes sobre piso escorregadio, instável, obstruído ou junto a circulação de pessoas ou veículos. Garante visibilidade suficiente para detetar o piso, a corda e obstáculos. No exterior, calor, frio, qualidade do ar e trânsito são modificadores de risco; muda de local ou não inicies se comprometerem o controlo.

## Limitações

1. O conteúdo explica execução e segurança gerais; não avalia a elegibilidade de uma pessoa concreta.
2. A evidência biomecânica direta disponível usa amostras pequenas e não representa todas as idades, sexos, níveis de experiência ou condições clínicas.
3. Não são definidos dose, intensidade, velocidade, cadência, duração, descanso ou progressão.
4. A descrição de receção controlada reduz erros observáveis, mas não permite prometer ausência de lesão.
5. As relações condicionais permanecem dependentes de elegibilidade e, quando indicado, de lógica futura de produto.
6. O conteúdo não aprova imagem ou vídeo e não substitui demonstração ou feedback profissional quando a técnica não é compreendida.

## Teste de compreensão

### 1. O que distingue este exercício de uma variante com pés alternados?

Resposta esperada: Os dois pés saem do chão e regressam em conjunto em cada passagem da corda.

### 2. Onde deve estar a corda antes de iniciar a rotação?

Resposta esperada: Atrás dos calcanhares, sem estar enrolada.

### 3. Que parte dos membros superiores deve conduzir sobretudo a rotação?

Resposta esperada: Os punhos, com os cotovelos próximos do corpo.

### 4. Qual deve ser a altura do salto?

Resposta esperada: Apenas a necessária para a corda passar por baixo dos pés.

### 5. Como devem contactar o chão os pés?

Resposta esperada: Ao mesmo tempo, numa receção bilateral controlada.

### 6. O que deves fazer se a corda prender repetidamente?

Resposta esperada: Deixar a corda parar, recuperar uma base estável e rever comprimento e posição das mãos antes de reorganizar o movimento.

### 7. Que tipo de superfície é necessário?

Resposta esperada: Uma superfície firme, plana, regular, desimpedida e tolerante ao impacto.

### 8. Que espaço deve ficar livre?

Resposta esperada: Todo o arco da corda, por cima, aos lados, à frente e atrás.

### 9. Como deves respirar durante o exercício?

Resposta esperada: De forma natural, regular e contínua, sem prender a respiração.

### 10. Indica dois sinais que exigem interrupção.

Resposta esperada: Por exemplo: desconforto no peito, falta de ar atípica, tonturas, confusão, dor nova ou perda de controlo.

### 11. A supervisão é sempre obrigatória?

Resposta esperada: Não; não existe requisito canónico geral, mas é prudente perante instabilidade marcada, dificuldade persistente ou equipamento e ambiente desconhecidos.

### 12. Este conteúdo define séries, duração, cadência ou intensidade?

Resposta esperada: Não. Esses elementos pertencem à prescrição e ficam fora da identidade do exercício.

## Fontes e limites da evidência

### Fonte 1: Lin Y. et al. (2022), The Influence of Different Rope Jumping Methods on Adolescents’ Lower Limb Biomechanics during the Ground-Contact Phase.

- Autor ou entidade: A1-S24 — Lin Y. et al. (2022), The Influence of Different Rope Jumping Methods on Adolescents’ Lower Limb Biomechanics during the Ground-Contact Phase. — estudo biomecânico primário, revisto por pares — https://pmc.ncbi.nlm.nih.gov/articles/PMC9139829/ — Identidade do salto bilateral, fases do ciclo, contacto repetido, estratégia de receção e limites de impacto. — Amostra pequena de rapazes adolescentes experientes; não demonstra técnica ideal para todas as populações.
- Tipo: estudo biomecânico primário, revisto por pares
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC9139829/
- Usada para: Identidade do salto bilateral, fases do ciclo, contacto repetido, estratégia de receção e limites de impacto.
- Limite: A1-S24 — Lin Y. et al. (2022), The Influence of Different Rope Jumping Methods on Adolescents’ Lower Limb Biomechanics during the Ground-Contact Phase. — estudo biomecânico primário, revisto por pares — https://pmc.ncbi.nlm.nih.gov/articles/PMC9139829/ — Identidade do salto bilateral, fases do ciclo, contacto repetido, estratégia de receção e limites de impacto. — Amostra pequena de rapazes adolescentes experientes; não demonstra técnica ideal para todas as populações.

### Fonte 2: Mullerpatan R. et al. (2021), Lower extremity joint loading during Bounce rope skip in comparison to run and walk.

- Autor ou entidade: A1-S25 — Mullerpatan R. et al. (2021), Lower extremity joint loading during Bounce rope skip in comparison to run and walk. — estudo biomecânico primário, revisto por pares — https://pmc.ncbi.nlm.nih.gov/articles/PMC9760008/ — Confirmação de fase de receção, carga articular e impacto intermédio entre marcha e corrida no protocolo estudado. — Comparação laboratorial de uma tarefa específica; não define risco individual nem instruções universais.
- Tipo: estudo biomecânico primário, revisto por pares
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC9760008/
- Usada para: Confirmação de fase de receção, carga articular e impacto intermédio entre marcha e corrida no protocolo estudado.
- Limite: A1-S25 — Mullerpatan R. et al. (2021), Lower extremity joint loading during Bounce rope skip in comparison to run and walk. — estudo biomecânico primário, revisto por pares — https://pmc.ncbi.nlm.nih.gov/articles/PMC9760008/ — Confirmação de fase de receção, carga articular e impacto intermédio entre marcha e corrida no protocolo estudado. — Comparação laboratorial de uma tarefa específica; não define risco individual nem instruções universais.

### Fonte 3: Rope skipping cardiorespiratory demand (PMID 7421480).

- Autor ou entidade: A2-S33 — Rope skipping cardiorespiratory demand (PMID 7421480). — artigo científico indexado — https://pubmed.ncbi.nlm.nih.gov/7421480/ — Confirma a exigência cardiorrespiratória da atividade. — Estudo antigo, sem taxonomia atual de variantes e sem suporte direto para dose ou elegibilidade.
- Tipo: artigo científico indexado
- Localizador: https://pubmed.ncbi.nlm.nih.gov/7421480/
- Usada para: Confirma a exigência cardiorrespiratória da atividade.
- Limite: A2-S33 — Rope skipping cardiorespiratory demand (PMID 7421480). — artigo científico indexado — https://pubmed.ncbi.nlm.nih.gov/7421480/ — Confirma a exigência cardiorrespiratória da atividade. — Estudo antigo, sem taxonomia atual de variantes e sem suporte direto para dose ou elegibilidade.

### Fonte 4: England Boxing, Boxing Coaching Handbook Part 1, secção Skipping.

- Autor ou entidade: EX09-S1 — England Boxing, Boxing Coaching Handbook Part 1, secção Skipping. — manual oficial de federação desportiva — https://www.englandboxing.org/wp-content/uploads/2022/03/EB_Boxing-Coaching-Handbook-Part-1_v8-002.pdf — Comprimento da corda, pegas seguras, postura, posição dos cotovelos e mãos, rotação pelos punhos e salto baixo. — Manual dirigido ao contexto do boxe; as indicações de dose do manual foram deliberadamente excluídas.
- Tipo: manual oficial de federação desportiva
- Localizador: https://www.englandboxing.org/wp-content/uploads/2022/03/EB_Boxing-Coaching-Handbook-Part-1_v8-002.pdf
- Usada para: Comprimento da corda, pegas seguras, postura, posição dos cotovelos e mãos, rotação pelos punhos e salto baixo.
- Limite: EX09-S1 — England Boxing, Boxing Coaching Handbook Part 1, secção Skipping. — manual oficial de federação desportiva — https://www.englandboxing.org/wp-content/uploads/2022/03/EB_Boxing-Coaching-Handbook-Part-1_v8-002.pdf — Comprimento da corda, pegas seguras, postura, posição dos cotovelos e mãos, rotação pelos punhos e salto baixo. — Manual dirigido ao contexto do boxe; as indicações de dose do manual foram deliberadamente excluídas.

### Fonte 5: American College of Sports Medicine, ACSM Certified Personal Trainer Exam Content Outline.

- Autor ou entidade: EX09-S2 — American College of Sports Medicine, ACSM Certified Personal Trainer Exam Content Outline. — documento profissional oficial — https://acsm.org/wp-content/uploads/2024/12/ACSM-Certified-Personal-Trainer-Exam-Content-Outline.pdf — Monitorização de técnica e resposta, critérios de interrupção, adaptação, segurança de equipamento, superfície e supervisão. — Documento transversal de competências profissionais, não específico de salto à corda.
- Tipo: documento profissional oficial
- Localizador: https://acsm.org/wp-content/uploads/2024/12/ACSM-Certified-Personal-Trainer-Exam-Content-Outline.pdf
- Usada para: Monitorização de técnica e resposta, critérios de interrupção, adaptação, segurança de equipamento, superfície e supervisão.
- Limite: EX09-S2 — American College of Sports Medicine, ACSM Certified Personal Trainer Exam Content Outline. — documento profissional oficial — https://acsm.org/wp-content/uploads/2024/12/ACSM-Certified-Personal-Trainer-Exam-Content-Outline.pdf — Monitorização de técnica e resposta, critérios de interrupção, adaptação, segurança de equipamento, superfície e supervisão. — Documento transversal de competências profissionais, não específico de salto à corda.

### Fonte 6: American Heart Association, Getting Active to Control High Blood Pressure.

- Autor ou entidade: EX09-S3 — American Heart Association, Getting Active to Control High Blood Pressure. — orientação profissional oficial — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Respiração regular durante exercício e evitação de retenção respiratória. — Orientação geral e enquadrada em saúde cardiovascular; não é uma norma técnica específica da corda.
- Tipo: orientação profissional oficial
- Localizador: https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure
- Usada para: Respiração regular durante exercício e evitação de retenção respiratória.
- Limite: EX09-S3 — American Heart Association, Getting Active to Control High Blood Pressure. — orientação profissional oficial — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Respiração regular durante exercício e evitação de retenção respiratória. — Orientação geral e enquadrada em saúde cardiovascular; não é uma norma técnica específica da corda.
