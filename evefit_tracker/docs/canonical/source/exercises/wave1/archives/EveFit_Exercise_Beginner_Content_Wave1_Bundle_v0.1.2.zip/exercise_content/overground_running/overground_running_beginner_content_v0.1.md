# Corrida terrestre

Conteúdo para principiantes em português europeu.

## Descrição curta

Corrida no solo com passadas alternadas, deslocamento global e uma fase aérea que se repete entre apoios.

## O que é

Forma de locomoção terrestre cíclica em que a pessoa avança através de passadas alternadas, cada pé recebe o corpo à vez e existe repetidamente um breve momento em que nenhum pé está apoiado. Distingue-se da caminhada pela fase aérea e não exige, por definição, a ação explosiva de um sprint.

## O que vais fazer

Deslocar-te para a frente, alternando apoio, propulsão, fase aérea e receção. Os braços acompanham as pernas de forma do lado oposto, sem procurar velocidade máxima.

## Porque existe este movimento

O propósito técnico imediato é executar locomoção terrestre cíclica com fase aérea. Ritmo, velocidade, distância, duração e organização em intervalos pertencem à prescrição e não à identidade.

## Antes de começares

1. Escolhe um percurso contínuo, firme, regular, visível e sem obstáculos.
2. Exclui locais com tráfego descontrolado ou superfície insegura.
3. Observa as condições de calor, frio, qualidade do ar e visibilidade.
4. Prepara o corpo de forma gradual com movimentos já conhecidos para tornozelos, joelhos, ancas, ombros e marcha, sem usar uma dose fixa.
5. Confirma que consegues manter apoios alternados sem instabilidade marcada.
6. Não comeces se já tens dor nova, desconforto no peito, falta de ar atípica, tonturas, confusão ou sensação de doença.
7. Se estás a regressar após lesão ou cirurgia, tens sintomas cardiorrespiratórios relevantes ou dúvidas sobre a tua adequação, procura revisão de um profissional habilitado antes de decidir executar.

## Preparar o equipamento

1. Não existe equipamento obrigatório. O equipamento pessoal, se for usado, depende da superfície e das condições, não deve ficar solto nem limitar o movimento ou a perceção do ambiente. Nenhum acessório torna seguro um piso inadequado.

## Preparar o espaço

1. Usa um percurso terrestre firme, regular, visível, passável e sem obstáculos. Pode ser uma pista interior, um caminho exterior ou um pavilhão desportivo, desde que não exista tráfego descontrolado nem superfície insegura.

## Verificação do corpo

1. Consegues ficar de pé e alternar o apoio dos pés sem instabilidade marcada.
2. Não existe dor nova nem perda de controlo antes de começares.
3. Não existe desconforto no peito, falta de ar atípica, tontura ou confusão.
4. As condições ambientais não acrescentam um risco que não consigas controlar.

## Posição inicial

Fica de pé no início do percurso, orientado na direção livre. Mantém o tronco alto sem rigidez, a cabeça alinhada, o olhar dirigido para o trajeto, os ombros descontraídos, as mãos soltas e os cotovelos fletidos de forma natural junto ao corpo.

## Confirmar a posição inicial

1. Percurso livre e visível à frente.
2. Postura alta, sem dobrar o tronco pela cintura.
3. Cabeça alinhada e olhar no trajeto.
4. Ombros, mãos e mandíbula descontraídos.
5. Equilíbrio estável antes do primeiro passo.

## Passos de execução

1. Confirma novamente que a linha à tua frente continua livre, firme e sem tráfego descontrolado.
2. Inicia o deslocamento para a frente com uma passada natural, mantendo o tronco organizado e o olhar no percurso.
3. Alterna as pernas e deixa o braço oposto acompanhar cada perna, com movimento sobretudo para a frente e para trás.
4. Recebe cada apoio de forma controlada, com o joelho disponível para fletir e sem lançar o pé excessivamente à frente do corpo.
5. Passa do apoio para a fase aérea e prepara a receção do outro pé, sem tentar aumentar artificialmente a amplitude da passada.
6. Repete o ciclo de apoio, propulsão, fase aérea e receção, mantendo uma passada que continues a controlar.
7. Respira de forma natural e contínua, pelo nariz, pela boca ou por ambos conforme a necessidade, sem prender nem contar a respiração.
8. Se perderes controlo, se a técnica se degradar ou surgir um sinal de alarme, reduz o deslocamento de forma suave, passa à marcha e termina num local estável.

## Fases do movimento

### Apoio e receção

Um pé contacta o solo e recebe o corpo.

### Passagem sobre o apoio

O corpo continua a deslocar-se para a frente enquanto a outra perna recupera.

### Propulsão

O pé apoiado contribui para enviar o corpo para a frente.

### Fase aérea

Nenhum pé está momentaneamente em contacto com o solo.

### Preparação do apoio seguinte

A perna oposta organiza uma nova receção controlada.

## Respiração

Mantém a respiração natural e contínua, pelo nariz, pela boca ou por ambos conforme a necessidade. Não existe uma contagem obrigatória, uma sincronização fixa com as passadas nem retenção. O aumento da ventilação pode ser esperado; falta de ar atípica é um sinal para terminar.

## Sensações esperadas

1. Respiração e pulsação mais percetíveis.
2. Aquecimento corporal.
3. Trabalho repetido das pernas e participação dos braços.
4. Alternância entre receção do peso, propulsão e um breve descarregamento na fase aérea.
5. Contactos com o solo mais evidentes do que na caminhada.

## Sensações inesperadas ou de alerta

1. Desconforto no peito ou falta de ar atípica.
2. Tonturas, confusão, desmaio iminente ou fraqueza súbita.
3. Perda de controlo, instabilidade marcada ou tropeções repetidos.
4. Dor nova, aguda ou crescente.
5. Dificuldade respiratória, tosse ou mal-estar associados a fumo ou má qualidade do ar.

## Indicações técnicas principais

1. Olha para o percurso.
2. Mantém o tronco alto e descontraído.
3. Recebe cada apoio de forma controlada.
4. Mantém a passada repetível.
5. Deixa os braços avançarem e recuarem junto ao corpo.
6. Não prendas a respiração.

## Erros comuns e correções

### Erro 1: Transformar a corrida num sprint explosivo.

- Como reconhecer: Aceleras de forma abrupta, os apoios deixam de ser repetíveis e o controlo diminui.
- Como corrigir: Recupera uma passada controlável; se isso não acontecer, passa à marcha e termina.

### Erro 2: Alongar excessivamente a passada.

- Como reconhecer: O pé chega muito à frente do corpo, a perna parece rígida na receção ou sentes travagem e impacto pesado.
- Como corrigir: Deixa o pé regressar mais perto do corpo e usa uma passada naturalmente mais curta, sem impor um tipo de apoio do pé.

### Erro 3: Dobrar o tronco pela cintura ou olhar apenas para o chão.

- Como reconhecer: A cabeça avança, o peito fecha e deixas de observar o percurso.
- Como corrigir: Reorganiza o tronco de forma alta, alinha a cabeça e volta a olhar para a linha à frente.

### Erro 4: Cerrar as mãos ou cruzar demasiado os braços à frente.

- Como reconhecer: Sentes tensão nos ombros e as mãos passam repetidamente pelo centro do tronco.
- Como corrigir: Solta as mãos e deixa os braços moverem-se sobretudo para a frente e para trás.

### Erro 5: Prender ou forçar a respiração.

- Como reconhecer: Fazes pausas involuntárias, endureces o tronco ou tentas cumprir uma contagem que perturba o movimento.
- Como corrigir: Volta a respirar de forma natural e contínua, sem contagens nem retenções.

### Erro 6: Ignorar o percurso ou as condições ambientais.

- Como reconhecer: Aproximas-te de obstáculos, piso irregular, tráfego, pouca visibilidade, calor intenso ou fumo.
- Como corrigir: Interrompe e escolhe uma rota ou condição segura antes de retomares.

## Formas de simplificar ou ensaiar

1. Usa uma passada naturalmente mais curta, sem perseguir uma cadência-alvo.
2. Escolhe a zona mais previsível, plana e desimpedida do percurso compatível.
3. Mantém o olhar mais à frente no trajeto em vez de fixar os pés.
4. Se não conseguires conservar controlo em corrida, passa à marcha para sair do movimento em segurança; isto é uma estratégia de saída, não uma progressão programada.
5. Pede observação a um profissional qualificado se não conseguires reconhecer ou corrigir a postura e os apoios.

## Supervisão

A supervisão não é obrigatória por defeito e não é necessário um observador de segurança. É prudente procurar supervisão qualificada perante instabilidade marcada ou num ambiente pouco familiar. Pessoas com limitações de equilíbrio, pessoas previamente sedentárias e adultos mais velhos podem necessitar de adaptação. O regresso após lesão ou cirurgia e a presença de sintomas cardiorrespiratórios relevantes requerem revisão apropriada antes da decisão de executar.

## Como terminar

Deixa de procurar propulsão, reduz suavemente a velocidade de deslocamento, passa à marcha e imobiliza-te apenas quando estiveres num ponto firme e livre. Mantém-te atento ao ambiente e verifica se recuperas o controlo sem sinais de alarme.

## Nota de segurança

A corrida terrestre tem risco operacional moderado devido ao impacto repetido e ao ambiente. Fadiga, visibilidade reduzida, calor ou frio, má qualidade do ar e tráfego podem aumentar o risco. O exercício exige capacidade para manter apoios alternados e um local ativo adequado. A identidade não autoriza automaticamente qualquer ritmo, volume ou intensidade.

## Quando parar ou reduzir

1. Desconforto no peito ou falta de ar atípica.
2. Tonturas ou confusão.
3. Perda de controlo ou dor nova.

## Segurança do equipamento

Não existe equipamento obrigatório. Se usares roupa, calçado ou acessórios pessoais, confirma que estão seguros e são compatíveis com a superfície e o ambiente. Não uses auscultadores ou outros objetos de forma que impeça perceber tráfego, pessoas, animais ou alertas.

## Segurança do espaço

Usa apenas um percurso passável, firme, regular, visível e sem obstáculos. Não corras em tráfego descontrolado nem numa superfície insegura. No exterior, verifica as condições meteorológicas e a qualidade do ar; perante calor que provoque fraqueza ou sensação de desmaio, ou perante fumo, termina e procura um local seguro.

## Limitações

1. O conteúdo não substitui avaliação individual, análise de corrida ou supervisão quando existam gatilhos.
2. Não existe um padrão-ouro universal de técnica; não se impõe tipo de apoio do pé, cadência ou inclinação quantificada.
3. A respiração é descrita de forma natural e contínua porque não foi identificada base suficiente para impor contagens ou sincronização.
4. As recomendações ambientais são gerais e dependem das condições e alertas locais.
5. Não se prescrevem dose, ritmo, intensidade, distância, duração, frequência ou progressão.
6. Não se promete prevenção de lesão, desempenho ou outro resultado.

## Teste de compreensão

### 1. O que distingue esta corrida da caminhada?

Resposta esperada: A presença repetida de uma fase aérea sem apoio dos pés.

### 2. Que percurso é adequado?

Resposta esperada: Um percurso firme, regular, visível, contínuo e sem obstáculos ou tráfego descontrolado.

### 3. É obrigatório usar equipamento?

Resposta esperada: Não.

### 4. Para onde deve estar dirigido o olhar?

Resposta esperada: Para o percurso à frente.

### 5. Como se coordenam braços e pernas?

Resposta esperada: Cada braço acompanha a perna oposta, sobretudo para a frente e para trás.

### 6. É obrigatório apoiar primeiro o calcanhar ou a parte da frente do pé?

Resposta esperada: Não; este conteúdo não impõe um tipo universal de apoio.

### 7. Como deve ser a respiração?

Resposta esperada: Natural e contínua, sem contagens nem retenções.

### 8. É necessário correr à velocidade máxima?

Resposta esperada: Não; transformar o exercício num sprint altera a exigência.

### 9. Que sinais obrigam a terminar?

Resposta esperada: Desconforto no peito ou falta de ar atípica, tonturas ou confusão, perda de controlo ou dor nova.

### 10. Como se termina de forma controlada?

Resposta esperada: Reduzindo suavemente o deslocamento, passando à marcha e parando num local estável.

### 11. Quando pode ser útil supervisão?

Resposta esperada: Perante instabilidade marcada ou num ambiente pouco familiar.

### 12. Este conteúdo prescreve distância, duração, ritmo ou resultados?

Resposta esperada: Não.

## Fontes e limites da evidência

### Fonte 1: Exercising Your Way to Lowering Your Blood Pressure

- Autor ou entidade: American College of Sports Medicine
- Tipo: A1-S01 — Exercising Your Way to Lowering Your Blood Pressure — American College of Sports Medicine — https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf — Fonte existente para reconhecer a corrida como modalidade aeróbia. — Evidência de família; não sustenta técnica fina nem dose individual.
- Localizador: https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf
- Usada para: A1-S01 — Exercising Your Way to Lowering Your Blood Pressure — American College of Sports Medicine — https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf — Fonte existente para reconhecer a corrida como modalidade aeróbia. — Evidência de família; não sustenta técnica fina nem dose individual.
- Limite: A1-S01 — Exercising Your Way to Lowering Your Blood Pressure — American College of Sports Medicine — https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf — Fonte existente para reconhecer a corrida como modalidade aeróbia. — Evidência de família; não sustenta técnica fina nem dose individual.

### Fonte 2: Recommendations for Adults

- Autor ou entidade: American Heart Association
- Tipo: A1-S03 — Recommendations for Adults — American Heart Association — https://www.heart.org/en/healthy-living/exercise-and-physical-activity/fitness-basics/aha-recs-for-physical-activity-in-adults — Fonte existente para reconhecer a corrida como atividade aeróbia. — Não define a identidade mecânica nem autoriza uma prescrição.
- Localizador: https://www.heart.org/en/healthy-living/exercise-and-physical-activity/fitness-basics/aha-recs-for-physical-activity-in-adults
- Usada para: A1-S03 — Recommendations for Adults — American Heart Association — https://www.heart.org/en/healthy-living/exercise-and-physical-activity/fitness-basics/aha-recs-for-physical-activity-in-adults — Fonte existente para reconhecer a corrida como atividade aeróbia. — Não define a identidade mecânica nem autoriza uma prescrição.
- Limite: A1-S03 — Recommendations for Adults — American Heart Association — https://www.heart.org/en/healthy-living/exercise-and-physical-activity/fitness-basics/aha-recs-for-physical-activity-in-adults — Fonte existente para reconhecer a corrida como atividade aeróbia. — Não define a identidade mecânica nem autoriza uma prescrição.

### Fonte 3: Investing in a Personal Trainer

- Autor ou entidade: American College of Sports Medicine
- Tipo: A2-S04 — Investing in a Personal Trainer — American College of Sports Medicine — https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf — Fonte existente de família e de enquadramento profissional. — Lista exemplificativa, não taxonomia mecânica.
- Localizador: https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf
- Usada para: A2-S04 — Investing in a Personal Trainer — American College of Sports Medicine — https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf — Fonte existente de família e de enquadramento profissional. — Lista exemplificativa, não taxonomia mecânica.
- Limite: A2-S04 — Investing in a Personal Trainer — American College of Sports Medicine — https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf — Fonte existente de família e de enquadramento profissional. — Lista exemplificativa, não taxonomia mecânica.

### Fonte 4: Healthy Habits for Distance Running

- Autor ou entidade: American College of Sports Medicine
- Tipo: EX02-S01 — Healthy Habits for Distance Running — American College of Sports Medicine — https://acsm.org/distance-running-form-tips/ — Postura, passada não excessivamente longa, apoio próximo do corpo, movimento dos braços e limites da reformulação técnica. — O próprio artigo indica que não existe um padrão-ouro aplicável a todos os corredores.
- Localizador: https://acsm.org/distance-running-form-tips/
- Usada para: EX02-S01 — Healthy Habits for Distance Running — American College of Sports Medicine — https://acsm.org/distance-running-form-tips/ — Postura, passada não excessivamente longa, apoio próximo do corpo, movimento dos braços e limites da reformulação técnica. — O próprio artigo indica que não existe um padrão-ouro aplicável a todos os corredores.
- Limite: EX02-S01 — Healthy Habits for Distance Running — American College of Sports Medicine — https://acsm.org/distance-running-form-tips/ — Postura, passada não excessivamente longa, apoio próximo do corpo, movimento dos braços e limites da reformulação técnica. — O próprio artigo indica que não existe um padrão-ouro aplicável a todos os corredores.

### Fonte 5: Running Technique

- Autor ou entidade: England Athletics / gr8runners
- Tipo: EX02-S02 — Running Technique — England Athletics / gr8runners — https://clubspark.englandathletics.org/gr8runners/News/7003bc8b-71ae-46f6-b478-9670684b3ba4 — Postura alta, olhar à frente, relaxamento, coordenação do lado oposto e movimento dos braços. — A indicação de apoio preferencial no antepé não foi transposta como regra universal.
- Localizador: https://clubspark.englandathletics.org/gr8runners/News/7003bc8b-71ae-46f6-b478-9670684b3ba4
- Usada para: EX02-S02 — Running Technique — England Athletics / gr8runners — https://clubspark.englandathletics.org/gr8runners/News/7003bc8b-71ae-46f6-b478-9670684b3ba4 — Postura alta, olhar à frente, relaxamento, coordenação do lado oposto e movimento dos braços. — A indicação de apoio preferencial no antepé não foi transposta como regra universal.
- Limite: EX02-S02 — Running Technique — England Athletics / gr8runners — https://clubspark.englandathletics.org/gr8runners/News/7003bc8b-71ae-46f6-b478-9670684b3ba4 — Postura alta, olhar à frente, relaxamento, coordenação do lado oposto e movimento dos braços. — A indicação de apoio preferencial no antepé não foi transposta como regra universal.

### Fonte 6: How to warm up before exercising

- Autor ou entidade: NHS
- Tipo: EX02-S03 — How to warm up before exercising — NHS — https://www.nhs.uk/live-well/exercise/how-to-warm-up-before-exercising/ — Necessidade de preparação gradual e orientação para parar perante dor ou mal-estar. — As doses concretas da rotina publicada foram excluídas por estarem fora do âmbito.
- Localizador: https://www.nhs.uk/live-well/exercise/how-to-warm-up-before-exercising/
- Usada para: EX02-S03 — How to warm up before exercising — NHS — https://www.nhs.uk/live-well/exercise/how-to-warm-up-before-exercising/ — Necessidade de preparação gradual e orientação para parar perante dor ou mal-estar. — As doses concretas da rotina publicada foram excluídas por estarem fora do âmbito.
- Limite: EX02-S03 — How to warm up before exercising — NHS — https://www.nhs.uk/live-well/exercise/how-to-warm-up-before-exercising/ — Necessidade de preparação gradual e orientação para parar perante dor ou mal-estar. — As doses concretas da rotina publicada foram excluídas por estarem fora do âmbito.

### Fonte 7: Physical activity guidelines for adults aged 19 to 64

- Autor ou entidade: NHS
- Tipo: EX02-S04 — Physical activity guidelines for adults aged 19 to 64 — NHS — https://www.nhs.uk/live-well/exercise/physical-activity-guidelines-for-adults-aged-19-to-64/ — Reconhecimento da corrida como atividade que pode ter exigência elevada e necessidade de adequação ao estado da pessoa. — As metas semanais e os limiares de intensidade não foram usados.
- Localizador: https://www.nhs.uk/live-well/exercise/physical-activity-guidelines-for-adults-aged-19-to-64/
- Usada para: EX02-S04 — Physical activity guidelines for adults aged 19 to 64 — NHS — https://www.nhs.uk/live-well/exercise/physical-activity-guidelines-for-adults-aged-19-to-64/ — Reconhecimento da corrida como atividade que pode ter exigência elevada e necessidade de adequação ao estado da pessoa. — As metas semanais e os limiares de intensidade não foram usados.
- Limite: EX02-S04 — Physical activity guidelines for adults aged 19 to 64 — NHS — https://www.nhs.uk/live-well/exercise/physical-activity-guidelines-for-adults-aged-19-to-64/ — Reconhecimento da corrida como atividade que pode ter exigência elevada e necessidade de adequação ao estado da pessoa. — As metas semanais e os limiares de intensidade não foram usados.

### Fonte 8: Heat and Athletes

- Autor ou entidade: Centers for Disease Control and Prevention
- Tipo: EX02-S05 — Heat and Athletes — Centers for Disease Control and Prevention — https://www.cdc.gov/heat-health/risk-factors/heat-and-athletes.html — Calor como modificador ambiental e fraqueza ou sensação de desmaio como motivos para terminar. — Orientação ambiental geral, não avaliação individual.
- Localizador: https://www.cdc.gov/heat-health/risk-factors/heat-and-athletes.html
- Usada para: EX02-S05 — Heat and Athletes — Centers for Disease Control and Prevention — https://www.cdc.gov/heat-health/risk-factors/heat-and-athletes.html — Calor como modificador ambiental e fraqueza ou sensação de desmaio como motivos para terminar. — Orientação ambiental geral, não avaliação individual.
- Limite: EX02-S05 — Heat and Athletes — Centers for Disease Control and Prevention — https://www.cdc.gov/heat-health/risk-factors/heat-and-athletes.html — Calor como modificador ambiental e fraqueza ou sensação de desmaio como motivos para terminar. — Orientação ambiental geral, não avaliação individual.

### Fonte 9: When Smoke is in the Air

- Autor ou entidade: AirNow / U.S. Environmental Protection Agency
- Tipo: EX02-S06 — When Smoke is in the Air — AirNow / U.S. Environmental Protection Agency — https://www.airnow.gov/wildfires/when-smoke-is-in-the-air/ — Fumo e má qualidade do ar como razões para limitar ou evitar corrida exterior. — A orientação depende das condições locais e não substitui alertas oficiais da região.
- Localizador: https://www.airnow.gov/wildfires/when-smoke-is-in-the-air/
- Usada para: EX02-S06 — When Smoke is in the Air — AirNow / U.S. Environmental Protection Agency — https://www.airnow.gov/wildfires/when-smoke-is-in-the-air/ — Fumo e má qualidade do ar como razões para limitar ou evitar corrida exterior. — A orientação depende das condições locais e não substitui alertas oficiais da região.
- Limite: EX02-S06 — When Smoke is in the Air — AirNow / U.S. Environmental Protection Agency — https://www.airnow.gov/wildfires/when-smoke-is-in-the-air/ — Fumo e má qualidade do ar como razões para limitar ou evitar corrida exterior. — A orientação depende das condições locais e não substitui alertas oficiais da região.

### Fonte 10: Running and jogging — preventing injury

- Autor ou entidade: Better Health Channel, Department of Health, State Government of Victoria
- Tipo: EX02-S07 — Running and jogging — preventing injury — Better Health Channel, Department of Health, State Government of Victoria — https://www.betterhealth.vic.gov.au/health/healthyliving/running-and-jogging-preventing-injury — Superfície, obstáculos, visibilidade, perceção do ambiente, aquecimento e interrupção perante dor. — A recomendação de calçado específico não altera o registo canónico, que não exige equipamento.
- Localizador: https://www.betterhealth.vic.gov.au/health/healthyliving/running-and-jogging-preventing-injury
- Usada para: EX02-S07 — Running and jogging — preventing injury — Better Health Channel, Department of Health, State Government of Victoria — https://www.betterhealth.vic.gov.au/health/healthyliving/running-and-jogging-preventing-injury — Superfície, obstáculos, visibilidade, perceção do ambiente, aquecimento e interrupção perante dor. — A recomendação de calçado específico não altera o registo canónico, que não exige equipamento.
- Limite: EX02-S07 — Running and jogging — preventing injury — Better Health Channel, Department of Health, State Government of Victoria — https://www.betterhealth.vic.gov.au/health/healthyliving/running-and-jogging-preventing-injury — Superfície, obstáculos, visibilidade, perceção do ambiente, aquecimento e interrupção perante dor. — A recomendação de calçado específico não altera o registo canónico, que não exige equipamento.
