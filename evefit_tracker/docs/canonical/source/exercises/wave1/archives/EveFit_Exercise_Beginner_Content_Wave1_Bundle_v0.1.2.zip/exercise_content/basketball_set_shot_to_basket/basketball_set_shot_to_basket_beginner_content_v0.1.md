# Lançamento parado de basquetebol ao cesto

Conteúdo para principiantes em português europeu.

## Descrição curta

Lançamento ao cesto iniciado numa posição estabelecida, sem drible, receção imediatamente anterior ou salto obrigatório.

## O que é

Ficas parado, de frente para o cesto e com a bola controlada, e projetas a bola num arco ascendente através de uma extensão coordenada das pernas, do braço de lançamento e do punho. O exercício termina com os pés controlados e o braço a completar o seguimento do gesto.

## O que vais fazer

Vais estabelecer uma base estável, preparar as mãos na bola, escolher um ponto do cesto como alvo, elevar a bola com o corpo coordenado, libertá-la com o punho relaxado e esperar em segurança antes de recuperar o ressalto.

## Porque existe este movimento

A ação isola o componente técnico do lançamento para permitir observar equilíbrio, alinhamento, coordenação entre a parte inferior e superior do corpo, direção da bola e seguimento. O acerto é um resultado observável, não uma promessa.

## Antes de começares

1. Confirma que tens uma bola de basquetebol e um cesto estável e destinado à prática.
2. Confirma que consegues interromper a ação a qualquer momento.
3. Observa toda a zona entre ti, o cesto e a provável área de ressalto; começa apenas quando estiver livre.
4. Combina a utilização do cesto com outras pessoas e não lances enquanto alguém atravessa ou recupera uma bola na mesma zona.
5. Escolhe uma posição a partir da qual consigas manter a forma sem transformar a distância numa característica fixa do exercício.
6. Se for a primeira exposição técnica ou se o equipamento não for familiar, pede a observação de um treinador, professor ou adulto responsável.

## Preparar o equipamento

1. Usa uma bola de basquetebol com superfície íntegra, aderência uniforme e pressão dentro da indicação do fabricante.
2. Não uses uma bola rasgada, deformada, escorregadia ou com pressão que impeça o controlo normal.
3. Verifica visualmente se o cesto, a tabela, o aro, a rede, o suporte e o acolchoamento disponível parecem estáveis, íntegros e sem peças soltas ou arestas acessíveis.
4. Não subas, não te pendures e não tentes reparar o cesto; se houver instabilidade ou dano, não o uses e informa o responsável pelo espaço.

## Preparar o espaço

1. Usa uma superfície firme, nivelada e antiderrapante, em campo de basquetebol ou noutra zona segura com cesto.
2. Mantém espaço livre por cima, dos lados, entre a posição de lançamento e o cesto e na zona de ressalto.
3. Afasta objetos frágeis e não uses uma área com trânsito ativo.
4. Interrompe se o piso ficar molhado, se a iluminação deixar de permitir ver o alvo e as pessoas, ou se a zona ficar congestionada.

## Verificação do corpo

1. Confirma que estás desperto, orientado e capaz de controlar a bola e de parar a ação.
2. Antes de elevar a bola, verifica se consegues ficar de pé com apoio nos dois pés e fletir ligeiramente as pernas sem perder o equilíbrio.
3. Não inicies se já sentires dor aguda ou tontura.
4. Em retorno funcional, ou se uma limitação exigir adaptação, procura revisão apropriada antes de usares estas instruções genéricas.

## Posição inicial

Fica de pé, orientado para o cesto, com os dois pés apoiados e confortavelmente afastados. O pé do lado da mão de lançamento pode ficar ligeiramente à frente, sem torcer o corpo nem perder equilíbrio. Mantém os joelhos suavemente fletidos, o tronco controlado e a bola segura à frente do corpo.

## Confirmar a posição inicial

1. A zona de lançamento e de ressalto está livre.
2. Os dois pés estão estáveis numa superfície firme e não escorregadia.
3. O corpo está orientado para o cesto e os ombros estão confortavelmente alinhados com o alvo.
4. A bola está controlada, com os dedos confortavelmente afastados.
5. A mão de lançamento está por baixo ou por trás da bola e a mão-guia está ao lado.
6. Consegues ver um ponto estável do aro ou da tabela como alvo.

## Passos de execução

1. Estabelece a base antes de iniciar: distribui o apoio pelos dois pés, mantém os joelhos suavemente fletidos e fixa o olhar num ponto do cesto.
2. Organiza as mãos: coloca a mão de lançamento por baixo ou ligeiramente atrás da bola, com os dedos afastados; mantém a mão-guia ao lado, apenas para estabilizar.
3. Eleva a bola de forma simples e controlada pelo lado de lançamento, levando o cotovelo para debaixo da bola sem forçar uma posição rígida.
4. Empurra o chão e estende tornozelos, joelhos e anca enquanto o braço se estende para cima e para a frente. Não é obrigatório saltar.
5. Liberta a bola num ponto alto e confortável. Deixa o punho fletir de modo relaxado para produzir rotação para trás; a mão-guia afasta-se sem empurrar.
6. Mantém os olhos no alvo e termina com o braço de lançamento estendido, o punho relaxado e os dedos orientados para baixo.
7. Recupera uma posição estável após a libertação. Observa o ressalto e só te deslocas para a bola quando a trajetória e a zona estiverem livres.

## Fases do movimento

### Preparação

Base bipodal estável, alvo escolhido, bola controlada e mãos organizadas.

### Elevação coordenada

Extensão da parte inferior do corpo transfere força para o tronco e para o braço, enquanto a bola sobe.

### Libertação

Braço estende, punho termina relaxado e a mão-guia deixa de contactar sem empurrar.

### Seguimento e recuperação

Olhar permanece no alvo, braço completa o gesto e o corpo regressa a uma posição estável antes de procurar o ressalto.

## Respiração

Não foi identificado um protocolo respiratório específico para este lançamento nas fontes técnicas consultadas. Respira de forma natural e contínua; podes expirar suavemente durante a extensão e a libertação se isso for confortável. Não prendas a respiração e não uses contagens obrigatórias.

## Sensações esperadas

1. Apoio estável nos dois pés.
2. Esforço breve e coordenado nas pernas, no ombro, no braço e no punho.
3. Contacto controlado da bola nos dedos e saída suave da mão de lançamento.
4. Alongamento confortável do braço no seguimento, sem dor.

## Sensações inesperadas ou de alerta

1. Dor aguda ou crescente.
2. Tontura, sensação de desmaio ou desorientação.
3. Perda de equilíbrio que impeça terminar de forma controlada.
4. Dormência, formigueiro ou perda súbita de controlo da bola.
5. Impacto ou colisão provável com uma pessoa, outra bola ou equipamento.

## Indicações técnicas principais

1. Base primeiro, lançamento depois.
2. Olhos num ponto do cesto.
3. Mão de lançamento por baixo; mão-guia ao lado.
4. Pernas empurram, braço acompanha.
5. Punho relaxado e dedos para baixo.
6. Espera por uma zona de ressalto livre.

## Erros comuns e correções

### Erro 1: Iniciar com os pés ainda em movimento ou sem equilíbrio.

- Como reconhecer: O peso muda durante a preparação, um pé desliza ou o corpo cai para um lado após a libertação.
- Como corrigir: Para, volta a estabelecer apoio nos dois pés e só inicia quando conseguires manter a base.

### Erro 2: A mão-guia empurrar a bola.

- Como reconhecer: A bola sai para o lado, ganha rotação lateral marcada ou a mão-guia atravessa a frente do corpo.
- Como corrigir: Mantém a mão-guia ao lado para estabilizar e deixa-a separar-se quando a mão de lançamento conclui o gesto.

### Erro 3: Apertar a bola e executar um golpe rígido de punho.

- Como reconhecer: Os dedos fecham com tensão, a saída parece brusca e o seguimento termina curto.
- Como corrigir: Afasta os dedos confortavelmente, reduz a tensão da pega e deixa o punho terminar de forma relaxada.

### Erro 4: Usar quase só os braços para empurrar a bola.

- Como reconhecer: As pernas ficam imóveis, os ombros fazem esforço exagerado ou a trajetória sai demasiado plana.
- Como corrigir: Inicia a força a partir do apoio no chão e coordena a extensão das pernas com a subida do braço.

### Erro 5: Desalinhar a bola e o cotovelo ou cruzar a bola pela frente da cara.

- Como reconhecer: A bola muda de lado durante a elevação e a direção varia mesmo com o mesmo alvo.
- Como corrigir: Eleva a bola pelo lado de lançamento e procura ter o cotovelo por baixo da bola numa posição confortável.

### Erro 6: Entrar apressadamente na zona de ressalto.

- Como reconhecer: Começas a correr antes de confirmar onde estão a bola e as outras pessoas.
- Como corrigir: Termina o gesto, observa a trajetória e desloca-te apenas quando a zona estiver livre.

## Formas de simplificar ou ensaiar

1. Pratica primeiro a posição das mãos e o seguimento sem libertar a bola.
2. Usa uma posição de lançamento que permita chegar ao alvo sem deformar o gesto; a distância continua a ser uma escolha de prescrição, não parte da identidade.
3. Se houver equipamento regulamentar adaptado e supervisão, uma bola de tamanho adequado ou um alvo mais acessível pode facilitar a aprendizagem, sem substituir o requisito de bola de basquetebol e cesto na execução canónica.
4. Concentra a atenção num único indicação técnica de cada vez, por exemplo «base estável» ou «mão-guia ao lado».

## Supervisão

A supervisão é recomendada, embora não seja necessário um assistente de segurança. Um treinador, professor ou adulto responsável é especialmente útil na primeira exposição técnica, com equipamento não familiar, para organizar turnos numa zona partilhada e para adaptar a comunicação a jovens ou pessoas com deficiência. A pessoa que supervisiona deve observar a área de ressalto, a estabilidade do cesto e a técnica sem prometer resultados nem substituir revisão clínica quando esta for pertinente.

## Como terminar

Conclui o seguimento, recupera uma base estável e deixa a bola terminar a trajetória. Recolhe-a apenas quando não houver outra bola ou pessoa na zona. No fim, guarda a bola fora da área de circulação e comunica qualquer dano observado no cesto ou no piso.

## Nota de segurança

Risco operacional base baixo. Usa um cesto estável, mantém a área de ressalto livre e interrompe se surgir dor aguda, tontura, perda de controlo ou colisão provável.

## Quando parar ou reduzir

1. Uma bola ou pessoa entra na zona de execução.
2. Surge dor aguda.
3. Surge tontura.
4. A fadiga começa a alterar de forma clara o equilíbrio, o controlo da bola ou a atenção ao espaço.
5. O piso fica escorregadio, a iluminação é insuficiente ou o cesto parece instável.

## Segurança do equipamento

O equipamento obrigatório mantém-se: uma bola de basquetebol e um cesto de basquetebol; o alvo é obrigatório. A bola deve permitir aderência e controlo e respeitar a indicação de pressão do fabricante. Não uses bola danificada nem cesto instável. Não tentes reparar, ajustar, subir ou pendurar-te no aro ou no suporte.

## Segurança do espaço

Compatível com interior e exterior numa superfície firme, nivelada e antiderrapante. Requer espaço estacionário moderado, folga por cima e dos lados, percurso sem obstáculos e área de ressalto livre. Não é adequado em piso escorregadio, trânsito ativo, iluminação deficiente, zona congestionada ou junto de objetos frágeis.

## Limitações

1. Conteúdo documental genérico para principiantes; não constitui prescrição individual, diagnóstico, tratamento ou autorização universal para executar.
2. Não fixa distância, volume, intensidade, ritmo, frequência, carga, descanso ou progressão.
3. As fontes técnicas permitem variação individual; alinhamentos são referências observáveis, não posições rígidas universais.
4. Não foi identificado um protocolo respiratório específico de FIBA ou USA Basketball para este lançamento; foi usada respiração natural e contínua sem retenção.
5. A relação de aquecimento permanece condicional e dependente do motor de elegibilidade.
6. Implementação realizada: não

## Teste de compreensão

### 1. O lançamento começa com drible ou receção imediata?

Resposta esperada: Não. Começa parado, com a base estabelecida e a bola controlada.

### 2. É obrigatório saltar?

Resposta esperada: Não. Pode existir uma pequena extensão vertical, mas não há salto obrigatório.

### 3. Onde fica a mão de lançamento?

Resposta esperada: Por baixo ou ligeiramente atrás da bola, com os dedos confortavelmente afastados.

### 4. Qual é a função da mão-guia?

Resposta esperada: Estabilizar a bola ao lado e separar-se sem empurrar na libertação.

### 5. De onde deve começar a transferência de força?

Resposta esperada: Do apoio no chão e da extensão coordenada das pernas, seguindo para o tronco, braço e punho.

### 6. Onde deve permanecer o olhar durante o gesto?

Resposta esperada: Num ponto estável do cesto ou da tabela escolhido como alvo.

### 7. Como termina o braço de lançamento?

Resposta esperada: Estendido, com o punho relaxado e os dedos orientados para baixo.

### 8. Como deves respirar?

Resposta esperada: De forma natural e contínua, sem prender a respiração; uma expiração suave durante a libertação é opcional.

### 9. Quando podes avançar para recuperar a bola?

Resposta esperada: Depois de observar a trajetória e confirmar que a zona de ressalto está livre.

### 10. Que equipamento é obrigatório?

Resposta esperada: Uma bola de basquetebol e um cesto de basquetebol estável.

### 11. Que sinais exigem interrupção imediata?

Resposta esperada: Dor aguda, tontura, colisão provável, entrada de pessoa ou bola na zona, ou equipamento instável.

### 12. A distância e o número de lançamentos fazem parte da identidade do exercício?

Resposta esperada: Não. São escolhas de prescrição e não são fixadas neste conteúdo.

## Fontes e limites da evidência

### Fonte 1: FIBA WABC Coaches Manual Level 1

- Autor ou entidade: FIBA / World Association of Basketball Coaches
- Tipo: manual oficial de formação de treinadores
- Localizador: https://assets.fiba.basketball/image/upload/documents-corporate-wabc-coaching-level-manuals-level-1-eng.pdf
- Usada para: F1S03 — FIBA WABC Coaches Manual Level 1 — FIBA / World Association of Basketball Coaches — manual oficial de formação de treinadores — https://assets.fiba.basketball/image/upload/documents-corporate-wabc-coaching-level-manuals-level-1-eng.pdf — 2026-07-24 — Base equilibrada; força iniciada nas pernas; mão de lançamento por baixo ou atrás da bola; mão não dominante ao lado; cotovelo sob a bola; olhar sob a bola para o alvo; libertação alta, flexão relaxada do punho, rotação para trás e mão-guia sem empurrar; ensino inicial sem excesso de instruções. — Manual técnico de família; reconhece variação individual e não sustenta dose, distância fixa ou resultado.
- Limite: Manual técnico de família; reconhece variação individual e não sustenta dose, distância fixa ou resultado.

### Fonte 2: USA Basketball Youth Development Guidebook

- Autor ou entidade: USA Basketball
- Tipo: guia oficial de desenvolvimento juvenil
- Localizador: https://cdn1.sportngin.com/attachments/document/0095/3630/200.30_16.3.24_USA_BASKETBALL_YOUTH_DEVELOPMENT_GUIDEBOOK.pdf
- Usada para: F2-S05 — USA Basketball Youth Development Guidebook — USA Basketball — guia oficial de desenvolvimento juvenil — https://cdn1.sportngin.com/attachments/document/0095/3630/200.30_16.3.24_USA_BASKETBALL_YOUTH_DEVELOPMENT_GUIDEBOOK.pdf — 2026-07-24 — Base confortável aproximadamente à largura dos ombros, pé do lado de lançamento ligeiramente avançado, foco visual, posição das mãos, uso coordenado das pernas, execução sem salto, libertação e seguimento. — Conteúdo orientado para jovens; as progressões e distâncias exemplificativas não foram transferidas para o conteúdo canónico.
- Limite: Conteúdo orientado para jovens; as progressões e distâncias exemplificativas não foram transferidas para o conteúdo canónico.

### Fonte 3: Jr. NBA & Jr. WNBA League Briefing Pack

- Autor ou entidade: Basketball England
- Tipo: manual oficial de federação nacional
- Localizador: https://basketballengland.co.uk/files/jr-nba-amp-jr-wnba-league-briefing-pack-040326105827.pdf
- Usada para: F1S04 — Jr. NBA & Jr. WNBA League Briefing Pack — Basketball England — manual oficial de federação nacional — https://basketballengland.co.uk/files/jr-nba-amp-jr-wnba-league-briefing-pack-040326105827.pdf — 2026-07-24 — Ênfase na forma correta, aprendizagem inicial perto do alvo quando prescrita, atenção do treinador e encorajamento sem sobrecarregar o principiante. — Conteúdo juvenil e planos com dose; apenas princípios técnicos e pedagógicos foram usados.
- Limite: Conteúdo juvenil e planos com dose; apenas princípios técnicos e pedagógicos foram usados.

### Fonte 4: Official Basketball Rules 2024 — Basketball Equipment

- Autor ou entidade: FIBA
- Tipo: regulamento oficial de equipamento
- Localizador: https://assets.fiba.basketball/image/upload/documents-corporate-fiba-official-rules-2024-official-basketball-rules-and-basketball-equipment.pdf
- Usada para: EX42-WEB-01 — Official Basketball Rules 2024 — Basketball Equipment — FIBA — regulamento oficial de equipamento — https://assets.fiba.basketball/image/upload/documents-corporate-fiba-official-rules-2024-official-basketball-rules-and-basketball-equipment.pdf — 2026-07-24 — Aderência uniforme da bola, marcação de pressão recomendada, construção do aro e da rede sem arestas ou riscos de aprisionamento, suporte e acolchoamento orientados para segurança. — Especificação para equipamento de competição; usada apenas para fundamentar verificações visuais e respeito pelas indicações do fabricante, sem certificar equipamento doméstico.
- Limite: Especificação para equipamento de competição; usada apenas para fundamentar verificações visuais e respeito pelas indicações do fabricante, sem certificar equipamento doméstico.
