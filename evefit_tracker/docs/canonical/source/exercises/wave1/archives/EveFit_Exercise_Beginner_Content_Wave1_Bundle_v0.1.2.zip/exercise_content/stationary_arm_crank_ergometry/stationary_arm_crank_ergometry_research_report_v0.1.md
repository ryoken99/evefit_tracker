# Relatório de investigação — `stationary_arm_crank_ergometry`

**Agente:** EX-03  
**Data de consulta:** 23 de julho de 2026  
**Âmbito:** execução, preparação, respiração, segurança, erros e supervisão  
**Idioma do conteúdo produzido:** português europeu  
**Estado proposto:** `beginner_content_approved_with_limits`

## 1. Objeto e fronteiras

Este relatório sustenta apenas conteúdo documental para principiantes sobre a execução da ergometria estacionária de manivela para braços.

Foram preservados sem alteração:

- `exercise_id`: `stationary_arm_crank_ergometry`;
- identidade e definição canónicas;
- `operational_risk_tier`: `low`;
- equipamento obrigatório: `stationary_arm_crank_ergometer`;
- supervisão: `recommended`;
- três relações canónicas fornecidas no pacote;
- estado dos meios visuais, sem qualquer aprovação.

Não foram investigadas nem adicionadas doses, prescrições, resultados prometidos, diagnósticos, tratamentos, critérios universais de elegibilidade, novas variantes ou novas relações.

## 2. Método

Foi usado o pacote canónico do exercício como autoridade para identidade, risco, equipamento, ambiente, elegibilidade e relações. A investigação externa procurou apenas:

1. instruções de ajuste e posição em manuais oficiais de ergómetros de braços;
2. descrição profissional do padrão de movimento e limites de sobreutilização;
3. orientação institucional sobre respiração confortável;
4. confirmação institucional dos sinais gerais de alerta já presentes no pacote.

Sempre que uma instrução dependia do modelo, foi convertida numa regra geral prudente e acompanhada da indicação para seguir o manual específico. Não foram transpostos programas, cargas, velocidades, cadências, tempos ou progressões encontrados nas fontes.

## 3. Fontes externas consultadas

### WEB-EX03-01 — NuStep, *UE8 User Manual*

**URL:** https://www.nustep.com/wp-content/uploads/2022/05/20099_UE8-User-Manual-English-Rev-A.pdf  
**Tipo:** manual oficial do fabricante  
**Independência:** fabricante distinto dos restantes  
**Contributo:**

- posicionar o assento para conservar ligeira flexão do cotovelo no ponto mais distante;
- bloquear o assento depois do ajuste;
- evitar alcance excessivo;
- confirmar postura e pega confortável nas posições sentada, de pé ou em cadeira de rodas;
- manter cabos fora da passagem e espaço livre em redor do equipamento.

**Limite:** as alavancas, medidas de espaço e comandos pertencem ao UE8 e não foram generalizados.

### WEB-EX03-02 — SCIFIT, *PRO1 Users’ Operations Manual*

**URL:** https://kb.cybexintl.com/Owners_Manuals/PRO/SCIFIT_P3858_PRO1_Legacy_Operations_Manual.pdf  
**Tipo:** manual oficial do fabricante  
**Independência:** segundo fabricante, independente da NuStep  
**Contributo:**

- ajustar assento ou posição para evitar bloquear os cotovelos;
- procurar uma altura de manivelas que permita postura controlada;
- usar apoio seguro na posição de pé;
- reconhecer que pode existir ligeira rotação do tronco em certas configurações;
- recorrer a orientação profissional para ajustes em contextos de reabilitação;
- interromper perante sensação de desmaio.

**Limite:** é um manual de modelo legado. Instruções sobre programas, níveis, ritmo e duração ficaram fora do conteúdo por serem prescrição ou funcionamento específico.

### WEB-EX03-03 — Monark Sports & Medical, *Monark 881E*

**URL:** https://monarksportsmed.com/en/shop/monark-881e/  
**Tipo:** documentação oficial do fabricante  
**Contributo:**

- confirma a natureza fixa do ergómetro;
- confirma a possibilidade de ajustar as manivelas horizontal e verticalmente;
- documenta uso sentado e variação de configuração do aparelho.

**Limite:** página de produto, não manual de técnica completo.

### WEB-EX03-04 — SCIRE Professional, *Arm Cycle Ergometry (ACE) Training*

**URL:** https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/cardiorespiratory-fitness-and-endurance/arm-cycle-ergometry-ace-training/  
**Tipo:** síntese profissional de evidência  
**Contributo:**

- define a ergometria de braços como movimento rítmico que faz rodar um sistema de eixo e manivelas;
- sustenta a necessidade de ajustar a altura a pessoas e apoios diferentes;
- assinala a possibilidade de sobreutilização dos membros superiores;
- enquadra a utilização sentada.

**Limite:** foco em pessoas com lesão medular. Não foi usada para inferir elegibilidade geral, resultados individuais ou dose.

### WEB-EX03-05 — Cambridge University Hospitals NHS Foundation Trust, *Breathing exercises in the treatment of hyperventilation*

**URL:** https://www.cuh.nhs.uk/patient-information/breathing-exercises-in-the-treatment-of-hyperventilation/  
**Tipo:** orientação profissional hospitalar  
**Contributo:**

- sustenta respiração a um ritmo confortável;
- sustenta manter ombros e parte superior do peito relaxados;
- reconhece que a frequência respiratória aumenta naturalmente com o exercício.

**Limite:** não é uma instrução específica de ergometria. Foi usada apenas para linguagem respiratória geral; não foram transpostas contagens nem pausas.

### WEB-EX03-06 — Centers for Disease Control and Prevention, *About Heart Attack Symptoms, Risk, and Recovery*

**URL:** https://www.cdc.gov/heart-disease/about/heart-attack.html  
**Tipo:** orientação oficial de saúde pública  
**Contributo:**

- confirma desconforto no peito, falta de ar e sensação de cabeça leve como sinais gerais que não devem ser ignorados.

**Limite:** não é fonte de diagnóstico nem de elegibilidade para exercício. Os sinais de interrupção usados na ficha continuam a ser os do pacote canónico.

## 4. Fontes pré-existentes no pacote

Estas fontes foram recebidas no pacote e mantidas como enquadramento. Não foram usadas para importar dose ou prescrição.

### A1-S22 — SCIRE, *Wheelchair Propulsion Training*

**URL:** https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/wheelchair-propulsion-training/  
**Uso:** contexto de propulsão manual e equipamento adaptado.  
**Limite:** não descreve diretamente a técnica do ergómetro estacionário de braços.

### A1-S23 — CSEP, *Physical Activity Guidelines for Adults with Spinal Cord Injury*

**URL:** https://csepguidelines.ca/guidelines/physical-activity-guidelines-for-adults-with-spinal-cord-injury/  
**Uso:** enquadramento de modalidades aeróbias adaptadas.  
**Limite:** população específica; nenhuma dose nem autorização individual foi transposta.

### A2-S22 — *Arm-crank exercise review*

**URL:** https://pubmed.ncbi.nlm.nih.gov/32675708/  
**Uso:** enquadramento da família de ergometria de braços.  
**Limite:** respostas e parâmetros dependem da população; não valida dose, resultado individual ou elegibilidade automática.

## 5. Decisões editoriais e respetivo fundamento

### 5.1 Alcance

**Decisão:** instruir o principiante a manter ligeira flexão do cotovelo no ponto mais distante e a não compensar com afastamento do tronco.

**Fundamento:** convergência dos manuais NuStep e SCIFIT. Esta regra também concretiza o risco canónico `incorrect_adjustment`.

### 5.2 Altura do eixo

**Decisão:** descrever o eixo como estando numa posição confortável, em geral próxima da altura dos ombros, remetendo o ajuste exato para o manual.

**Fundamento:** os manuais e a literatura técnica usam referências próximas do ombro, mas a geometria varia entre máquinas, assentos, cadeiras de rodas e utilizadores. Evitou-se transformar uma referência geral numa regra universal rígida.

### 5.3 Tronco

**Decisão:** permitir a possibilidade de pequena rotação natural, proibindo balanço, impulso e torção exagerada.

**Fundamento:** o registo canónico exige controlo do tronco e identifica a rotação descontrolada como erro. O manual SCIFIT admite ligeira rotação em certas configurações. A formulação preserva ambos sem alterar a identidade.

### 5.4 Ligação das manivelas

**Decisão:** explicar que os braços alternam ou se movem em conjunto conforme a configuração já estabelecida no aparelho.

**Fundamento:** o pacote define `alternating: equipment_dependent` e `symmetrical_or_alternating_by_crank_setting`. Não foi recomendada qualquer reconfiguração.

### 5.5 Respiração

**Decisão:** recomendar respiração natural e contínua, sem retenção nem contagens.

**Fundamento:** o contrato determina esta opção quando não existe sustentação específica para sincronização respiratória. A fonte hospitalar apoia respiração confortável e ombros relaxados.

### 5.6 Finalização

**Decisão:** manter ambas as mãos nas pegas até à paragem completa e só depois sair.

**Fundamento:** deriva do conteúdo público canónico e é coerente com o controlo de partes móveis. Não foi adicionada uma técnica de travagem nem uma cadência de desaceleração.

### 5.7 Supervisão

**Decisão:** preservar `recommended` e destacar equipamento desconhecido, instabilidade marcada, regresso após lesão ou cirurgia e sintomas cardiorrespiratórios relevantes.

**Fundamento:** são condições já fornecidas no pacote. Os manuais reforçam a utilidade de orientação profissional para ajuste e uso em reabilitação.

### 5.8 Estado do conteúdo

**Decisão:** `beginner_content_approved_with_limits`.

**Fundamento:** existe convergência suficiente para instruções gerais, mas os ajustes, o raio, a ligação das manivelas e os mecanismos de bloqueio variam por modelo. O conteúdo tem de permanecer subordinado ao manual do equipamento.

## 6. Conflitos e respetiva resolução

### Controlo do tronco versus ligeira rotação

- O pacote alerta contra rotação descontrolada e balanço.
- O manual SCIFIT descreve ligeira rotação do tronco em extensão como possível ou desejável em certas configurações.

**Resolução:** não exigir tronco absolutamente imóvel. A ficha admite pequena rotação natural, mas rejeita balanço, impulso ou torção exagerada.

### Referência de altura do eixo

- Fontes técnicas frequentemente aproximam o eixo da altura do ombro.
- Fabricantes permitem múltiplas posições e objetivos de ajuste.

**Resolução:** usar “em geral próxima da altura dos ombros” como ponto de partida, não como medida fixa; o manual e a configuração individual determinam o ajuste final.

### Instruções específicas de modelo

- Os manuais apresentam alavancas, posições, raios e comandos diferentes.

**Resolução:** generalizar apenas princípios convergentes — estabilidade, bloqueio, alcance sem bloqueio do cotovelo, controlo postural e espaço livre — e excluir comandos próprios de cada máquina.

Não foi identificado conflito que exigisse alterar ID, identidade, risco, equipamento, ambiente, relações ou supervisão canónicos.

## 7. Limites da investigação

- A maioria das fontes específicas provém de fabricantes ou de contextos de reabilitação.
- Não existe uma única configuração universal de assento, altura, raio ou ligação das manivelas.
- A orientação respiratória é geral e não específica deste exercício.
- Os sinais de alerta são gerais e não constituem diagnóstico.
- A investigação não avalia dose, eficácia, programas, resultados, elegibilidade clínica individual ou comparação entre prescrições.
- Não foi feita aprovação de imagem ou vídeo.
- Nenhuma fonte externa foi tratada como autoridade para modificar a ontologia canónica.

## 8. Verificações de conformidade do conteúdo

- Identidade preservada: sim.
- Risco preservado: sim.
- Equipamento preservado: sim.
- Relações preservadas: sim.
- Sem dose ou progressão programada: sim.
- Sem promessa de resultado: sim.
- Sem diagnóstico ou tratamento: sim.
- Sem autorização universal: sim.
- Execução com pelo menos cinco passos: sim.
- Pelo menos quatro pistas principais: sim.
- Pelo menos quatro erros no formato exigido: sim.
- Doze perguntas de compreensão: sim.
- Fontes técnicas/profissionais independentes: sim.

## 9. Declaração de zero implementação

Este trabalho produziu exclusivamente documentação pública, um registo JSON documental e o presente relatório de investigação. Não foi criado, alterado, executado ou publicado código de produto; não foram feitas alterações a bases de dados, esquemas, relações, meios visuais, interfaces, configurações, serviços ou pipelines. A implementação realizada é zero.
