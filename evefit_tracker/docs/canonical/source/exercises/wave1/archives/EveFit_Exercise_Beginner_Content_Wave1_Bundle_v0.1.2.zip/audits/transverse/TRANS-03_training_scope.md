# TRANS-03 — Auditoria transversal de escopo de treino

**Resultado global:** `revisão obrigatória`  
**Blockers:** 1  
**Implementação realizada:** não

## Âmbito e método

Foram revistos, em modo exclusivamente de leitura:

- os 49 JSON `*_beginner_content_v0.1.json`;
- os 49 Markdown públicos `*_beginner_content_v0.1.md`;
- as sete auditorias de capacidade `AUD-A` a `AUD-G`.

Não foram consultados outputs de outros especialistas transversais. Os relatórios de investigação presentes nas pastas dos exercícios não foram usados como fonte primária desta revisão.

A pesquisa transversal combinou:

1. inventário mecânico de estados, capacidades e campos;
2. comparação semântica entre cada JSON e o respetivo Markdown;
3. pesquisa de números e unidades de dose, séries, repetições, duração, distância, carga, intensidade, frequência, cadência, descanso e progressão;
4. leitura de `execution_steps_pt_pt`, `movement_phases_pt_pt`, `beginner_simplifications_pt_pt`, `supervision_guidance_pt_pt`, campos de prontidão, segurança, limitações e explicações de relações;
5. distinção entre descrição de um ciclo técnico, dose autorregulada, adaptação individual, tarefa antecedente, nova variante e decisão de elegibilidade;
6. cruzamento com findings das auditorias de capacidade apenas quando incidiam no escopo de treino.

Critério de decisão:

- descrever uma ação cíclica uma vez não foi contado como dose;
- reduzir amplitude para recuperar controlo não foi contado como progressão;
- um sinal de paragem por segurança não foi contado como prescrição;
- foi contado como problema quando o texto manda repetir/continuar segundo um limiar, define pausas entre tentativas, escolhe intensidade/parâmetros para a pessoa, organiza uma sequência de progressão ou substitui um elemento nuclear da identidade dentro de “simplificações”.

## Findings

### TRANS-03-001 — `paced_breathing` reduz a identidade e encaminha para outro exercício

- **Severidade:** alta
- **Blocker:** sim
- **Exercício:** `paced_breathing`
- **Campo:** `beginner_definition_pt_pt`, `what_you_will_do_pt_pt`, `execution_steps_pt_pt`, `beginner_simplifications_pt_pt`; secções Markdown correspondentes
- **Evidência:** a auditoria de capacidade AUD-G confirma que a identidade admite ritmo regular autoescolhido **ou** sinal externo. O conteúdo publicado ensina apenas a via com sinal externo. A simplificação diz: “Se o guia não puder ser ajustado ao conforto, limita-te a observar a respiração espontânea e não executes a tarefa ritmada.” Essa substituição é `respiratory_sensation_observation`, outro exercício canónico, não uma simplificação da respiração ritmada. A redação transforma disponibilidade/ajuste do sinal numa regra de elegibilidade e elimina a modalidade sem equipamento.
- **Revisão exigida:** repor as duas modalidades canónicas na definição, preparação, execução e saída. Ensinar uma única transição inspiração–expiração em cada via, sem contagem, frequência ou duração. Retirar a observação espontânea do campo de simplificações ou identificá-la apenas como tarefa separada, nunca como execução equivalente.

### TRANS-03-002 — Parâmetros individuais e intensidade relativa entram no conteúdo genérico

- **Severidade:** alta
- **Blocker:** não
- **Exercícios:** `countermovement_jump`, `basketball_set_shot_to_basket`, `boxing_jab_cross_to_focus_mitts`, `treadmill_walking`, `volleyball_forearm_pass_to_target`, `paced_breathing`, `standing_multidirectional_weight_shift`
- **Campo:** `beginner_simplifications_pt_pt`; campos de setup/supervisão correspondentes; Markdown público
- **Evidência:** o conjunto inclui “intenção de salto baixa definida pelo supervisor” (`countermovement_jump`), posição/distância que permita chegar ao alvo e bola/alvo “mais acessível” (`basketball_set_shot_to_basket`), “apenas o contacto necessário” (`boxing_jab_cross_to_focus_mitts`), configuração da passadeira que permita conservar os passos (`treadmill_walking`), lançamento “suave” e em arco “confortável” (`volleyball_forearm_pass_to_target`), sinal ajustado ao conforto (`paced_breathing`) e “alteração individual da base” segundo orientação aplicável (`standing_multidirectional_weight_shift`). São decisões de intensidade, distância, equipamento, cadência, contacto ou geometria individual, apesar de os próprios conteúdos declararem que a prescrição/adaptação individual fica fora do documento.
- **Revisão exigida:** manter no conteúdo apenas critérios técnicos e de segurança observáveis. Quando um parâmetro tiver de ser escolhido individualmente, indicar que a decisão ocorre fora deste conteúdo, sem escolher “baixo”, “suave”, “necessário”, uma distância, uma configuração, uma base ou um equipamento alternativo. Se o parâmetro definir uma execução distinta, formalizá-la antes como variante.

### TRANS-03-003 — Loops condicionais funcionam como dose autorregulada escondida

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** `bilateral_pogo_jump`, `front_to_back_leg_swing`, `lateral_leg_swing`, `paced_breathing`, `standing_multidirectional_weight_shift`, `two_foot_rope_skipping`
- **Campo:** `execution_steps_pt_pt`, `movement_phases_pt_pt`; Markdown “Execução”
- **Evidência:** aparecem instruções como “Repete apenas enquanto os contactos permanecem…” (`bilateral_pogo_jump`), “Continua a alternar frente e trás…” (`front_to_back_leg_swing`), “Continua a alternar as duas direções apenas enquanto…” (`lateral_leg_swing`), “Manter a alternância apenas enquanto…” (`paced_breathing`), “Continue apenas enquanto cada deslocação e cada regresso…” (`standing_multidirectional_weight_shift`) e “repete o mesmo ciclo apenas enquanto…” (`two_foot_rope_skipping`). O limiar técnico é útil como sinal de saída, mas a ordem para continuar até esse limiar cria repetições abertas e autorreguladas.
- **Revisão exigida:** descrever um ciclo completo ou uma transição representativa e separar a regra de segurança (“se repetires numa prescrição externa, termina quando…”) da instrução de execução. Não mandar continuar ou repetir dentro do conteúdo sem uma dose autorizada.

### TRANS-03-004 — Pausas e resets por tentativa prescrevem estrutura de descanso

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** `football_directional_first_touch`, `tandem_walk`, `volleyball_forearm_pass_to_target`
- **Campo:** `beginner_simplifications_pt_pt`; Markdown “Simplificações”
- **Evidência:** `football_directional_first_touch` manda fazer “uma pausa completa entre tentativas”; `tandem_walk` manda pausar “depois de cada colocação calcanhar–ponta”; `volleyball_forearm_pass_to_target` permite interromper a alimentação “após cada contacto para permitir reposicionamento completo”. Embora sem segundos definidos, estas instruções determinam a relação trabalho–pausa ou fragmentam uma execução contínua, contrariando as declarações de ausência de descanso/dose.
- **Revisão exigida:** converter estas frases em instruções de segurança acionadas por perda de organização, sem impor pausa a cada tentativa/contacto/apoio. Se o reset após cada ação for nuclear à versão inicial, formalizar essa versão em vez de a esconder como simplificação.

### TRANS-03-005 — “Simplificações” contêm tarefas antecedentes e variantes não canónicas

- **Severidade:** alta
- **Blocker:** não
- **Exercícios:** `basketball_set_shot_to_basket`, `bilateral_pogo_jump`, `countermovement_jump`, `doorway_pectoral_stretch`, `half_kneeling_ankle_dorsiflexion_rock`, `linear_sprint`, `plyometric_push_up`, `seated_single_leg_hamstring_stretch`, `sled_resisted_sprint`, `sprint_to_controlled_stop`, `standing_broad_jump`, `standing_gastrocnemius_wall_stretch`, `standing_medicine_ball_chest_pass`, `standing_soleus_wall_stretch`, `two_foot_rope_skipping`, `two_point_sprint_start`, `volleyball_forearm_pass_to_target`
- **Campo:** `beginner_simplifications_pt_pt`; Markdown “Simplificações”
- **Evidência:** foram identificados 24 itens, em 17 exercícios, que removem um elemento nuclear ou ensinam uma tarefa diferente: lançamento sem libertar a bola; pogo sem sequência reativa ou sem fase aérea; salto com contramovimento sem os pés saírem do chão; sprint com trenó sem trenó; flexão pliométrica substituída por prancha/flexão convencional; salto em comprimento apenas com receção; passe de bola medicinal sem libertação; corda sem saltar ou saltos sem corda; voleibol sem bola. Vários itens reconhecem corretamente que são “preparação”, “pré-requisito” ou que “não contam” como execução, mas continuam publicados sob o rótulo de simplificação do exercício.
- **Revisão exigida:** reservar `beginner_simplifications_pt_pt` para alterações que preservem todos os elementos nucleares. Mover os 24 itens para um campo claramente não executável de `rehearsal/prerequisite`, com fronteira explícita e sem os contabilizar como exercício. Qualquer tarefa destinada a ser executada e registada deve ter identidade/variante própria antes da publicação.

### TRANS-03-006 — Checks operacionais são apresentados simultaneamente como não elegibilidade e decisão de participação

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** `countermovement_jump`, `diaphragmatic_breathing`, `lateral_leg_swing`, `overground_walking`, `respiratory_sensation_observation`, `standing_multidirectional_weight_shift`, `supine_self_assisted_hamstring_stretch`, `tandem_stance`, `tandem_walk`, `two_foot_rope_skipping`, `two_point_sprint_start`
- **Campo:** `before_you_start_pt_pt`, `body_readiness_check_pt_pt`, `supervision_guidance_pt_pt`, `safety_note_pt_pt`, `limitations_pt_pt`; Markdown correspondente
- **Evidência:** estes 11 conteúdos combinam uma declaração do tipo “não determina/avalia elegibilidade individual” com regras imperativas de não iniciar, não executar sem supervisão ou obter adaptação/revisão antes de participar. Exemplos: `tandem_stance` diz que o conteúdo não determina elegibilidade, mas decide “não execute sem supervisão” para categorias amplas; `two_point_sprint_start` remete revisão “antes de decidir a participação”; `countermovement_jump` afirma que não decide elegibilidade, mas impede prática autónoma no primeiro dia e atribui ao supervisor a intensidade. Os red flags imediatos são apropriados; a confusão está em não separar segurança operacional, encaminhamento e decisão de elegibilidade.
- **Revisão exigida:** usar três rótulos distintos: (a) condição operacional que deve ser corrigida antes de começar; (b) sinal que exige parar/obter assistência; (c) fator que remete a elegibilidade para profissional ou motor autorizado. O conteúdo pode dizer quando não fornece autorização, mas não deve tomar decisões individuais enquanto declara não as tomar.

## Padrões transversais

### Confirmados como conformes

- Não foi encontrada qualquer série, repetição, duração, frequência, distância, carga ou intensidade **numérica fixa**.
- Não foi encontrada promessa direta de eficácia, prevenção, tratamento ou resultado individual.
- As expressões de aumento/redução usadas para travagem, saída, controlo de amplitude ou resposta a sinais de alarme não foram tratadas como progressão de treino.
- Os avisos contra retenção respiratória e as instruções de respiração natural não constituem dose respiratória.
- JSON e Markdown são, na maioria dos casos, semanticamente paralelos; os findings acima normalmente aparecem nos dois formatos, logo não são simples erros de renderização.

### Padrões que exigem revisão

- A frase “não é dose/prescrição/progressão” é frequentemente seguida por uma instrução operacional que produz exatamente uma decisão de volume, pausa, intensidade ou adaptação.
- `beginner_simplifications_pt_pt` está sobrecarregado com quatro funções diferentes: cue técnico, redução de dificuldade, ensaio de componente e tarefa antecedente.
- “Apenas enquanto”, “até conseguires”, “primeiro… depois” e “antes de aumentar” são os principais marcadores de dose autorregulada ou progressão disfarçada.
- Remeter uma escolha para o supervisor não deixa de ser recomendação individual quando o conteúdo já determina a direção da escolha, como “intenção baixa”.
- A linguagem de elegibilidade deve ser separada de red flags e de requisitos ambientais; caso contrário, a explicação educativa funciona como um mini-screening não autorizado.

## Contagens

| Métrica | Resultado |
|---|---:|
| Exercícios revistos | 49 |
| Artefactos de publicação revistos | 98 |
| Auditorias de capacidade revistas | 7 |
| Findings TRANS-03 | 6 |
| Findings de severidade alta | 3 |
| Findings de severidade média | 3 |
| Findings de severidade baixa | 0 |
| Blockers | 1 |
| Exercícios com pelo menos um finding | 30 |
| Exercícios sem finding de escopo de treino | 19 |
| Loops de dose autorregulada identificados | 6 exercícios |
| Estruturas de pausa/reset identificadas | 3 exercícios |
| Exercícios com parâmetros individuais no texto genérico | 7 |
| Itens de componente/tarefa antecedente em “simplificações” | 24 itens / 17 exercícios |
| Conteúdos com fronteira explicação/elegibilidade ambígua | 11 exercícios |
| Doses numéricas fixas | 0 |
| Promessas diretas de eficácia | 0 |

Exercícios afetados por capacidade:

| `capability_primary` | Afetados | Total da capacidade |
|---|---:|---:|
| `breathing_regulation` | 3 | 4 |
| `cardio_conditioning` | 3 | 11 |
| `flexibility` | 7 | 9 |
| `mobility` | 1 | 5 |
| `motor_control_coordination` | 3 | 6 |
| `speed_power` | 9 | 9 |
| `technique_skill` | 4 | 5 |

## Estados afetados

Os 49 registos têm `record_status == approved` e `content_status == beginner_content_approved_with_limits`.

No escopo TRANS-03:

- `revisão obrigatória / blocked`: 1 — `paced_breathing`;
- `aprovado com revisões de treino`: 29;
- `sem finding TRANS-03`: 19.

Os findings não alteram estados canónicos, risco, relações ou elegibilidade. Indicam apenas que o estado público atual não deve ser interpretado como aprovação sem as revisões acima.

## Independência e zero implementação

TRANS-03 não foi autor dos conteúdos. A revisão foi conduzida de forma independente, sem leitura de outputs de outros especialistas transversais e sem coordenação de conclusões com autores.

Foi realizada **zero implementação**. Nenhum JSON, Markdown de exercício, relatório de investigação, pacote canónico, relação, regra, código, configuração, multimédia ou estado foi editado. O único ficheiro criado por TRANS-03 é este relatório.
