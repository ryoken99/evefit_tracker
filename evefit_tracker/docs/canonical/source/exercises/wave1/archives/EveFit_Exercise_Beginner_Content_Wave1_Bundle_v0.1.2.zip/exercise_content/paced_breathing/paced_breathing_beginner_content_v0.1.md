# Respiração ritmada

Conteúdo para principiantes em português europeu.

## Descrição curta

Alinhar voluntariamente a inspiração e a expiração com um ritmo regular e confortável escolhido por ti; um sinal externo pode ajudar, mas não é obrigatório.

## O que é

É uma alternância voluntária entre inspiração e expiração num ritmo regular, confortável e ajustável pela própria pessoa. Podes usar a sensação do teu ciclo respiratório ou, opcionalmente, um sinal visual, sonoro ou tátil. O sinal não define uma frequência universal, uma proporção temporal, uma profundidade ou uma retenção.

## O que vais fazer

Escolhes um ritmo respiratório regular que continue confortável, deixas o ar entrar e sair suavemente e regressas à respiração espontânea se precisares de forçar, acelerar ou aprofundar o ciclo.

## Porque existe este movimento

Praticar a consistência temporal entre as fases do ciclo respiratório. As relações canónicas admitem ativação, aquecimento, treino principal, retorno à calma, recuperação e prevenção, com os respetivos limites de elegibilidade; não garantem efeitos nem definem dose ou resultado individual.

## Antes de começares

1. Confirma que consegues iniciar, ajustar e parar a tarefa por tua iniciativa.
2. Começa apenas se a respiração estiver estável e confortável.
3. Escolhe uma posição apoiada e sem risco de queda.
4. Afasta obstáculos e garante ar de boa qualidade.
5. Decide se vais acompanhar a sensação do próprio ciclo ou um sinal externo opcional.
6. Perante restrição clínica, doença cardiovascular ou respiratória relevante, história de desmaio ou sintomas novos, procura orientação profissional antes de executar.

## Preparar o equipamento

1. Não existe equipamento obrigatório.
2. Se escolheres um guia visual, sonoro ou tátil, coloca-o de forma estável e confirma que o podes ajustar ou interromper imediatamente.
3. Mantém cabos e dispositivos fora da zona de passagem e dos apoios.

## Preparar o espaço

1. Usa um local seguro, com superfície firme, posição estável, espaço livre de obstáculos e ar de boa qualidade. Garante iluminação ou nível sonoro adequados à modalidade do sinal. Não pratiques num veículo em movimento, dentro de água, numa altura desprotegida, numa superfície instável ou durante uma tarefa que exija atenção externa contínua.

## Verificação do corpo

1. Respiração espontânea confortável e sem agravamento recente.
2. Ausência de dor torácica, tontura, sensação de desmaio ou confusão.
3. Ausência de falta de ar atípica ou crescente.
4. Ombros relaxados e postura apoiada.
5. Sinal percetível sem esforço sensorial excessivo.
6. Capacidade de parar imediatamente.

## Posição inicial

Senta-te, fica de pé ou deita-te numa posição estável, sem compressão incómoda do tronco. Mantém a cabeça e o tronco confortavelmente alinhados, os ombros soltos e o apoio bem estabelecido.

## Confirmar a posição inicial

1. Base de apoio firme e estável.
2. Cabeça e tronco numa posição confortável.
3. Ombros sem elevação deliberada.
4. Roupa e objetos sem apertar o tórax ou o abdómen.
5. Sinal claramente percetível.
6. Comando para parar ou ajustar ao alcance.
7. Ambiente sem risco de queda, colisão ou distração perigosa.

## Passos de execução

1. Repara na respiração espontânea e usa-a como referência de conforto, sem a tornar deliberadamente mais funda.
2. Escolhe um ritmo regular que consigas manter sem pressa nem sensação de falta de ar.
3. Deixa o ar entrar suavemente e permite o movimento natural do tórax e do abdómen.
4. Deixa o ar sair suavemente, sem empurrar nem esvaziar os pulmões à força.
5. Passa de uma fase à outra sem acrescentar pausas ou retenções.
6. Se usares um sinal externo, trata-o apenas como ajuda e ajusta-o ou abandona-o sempre que deixe de ser confortável.
7. Conclui um ciclo controlado; qualquer continuidade pertence a uma decisão externa e não a uma dose prescrita por esta ficha.
8. Para terminar, regressa à respiração espontânea e confirma que continua confortável.

## Fases do movimento

### Preparação

Estabelecer apoio, observar a respiração espontânea e escolher um ritmo confortável.

### Inspiração

Deixar o ar entrar suavemente sem aumentar deliberadamente a profundidade.

### Mudança

Mudar a direção respiratória sem pausa imposta.

### Expiração

Deixar o ar sair suavemente sem esforço forçado.

### Saída

Abandonar o ritmo escolhido ou o sinal opcional e regressar à respiração espontânea.

## Respiração

A inspiração e a expiração são a própria ação. Mantém um ritmo escolhido por ti, regular, suave e confortável. Um sinal externo é opcional. Não imponhas contagens, proporções, profundidade, via respiratória ou retenções. Se surgirem tonturas, formigueiro, aperto, falta de ar ou necessidade de respirar excessivamente, para e regressa à respiração espontânea; não respires para um saco.

## Sensações esperadas

1. Movimento suave do tórax e do abdómen.
2. Fluxo de ar sem esforço marcado.
3. Atenção leve às mudanças do sinal.
4. Capacidade de interromper ou ajustar o ciclo a qualquer momento.
5. Esforço semelhante ao de uma respiração confortável.

## Sensações inesperadas ou de alerta

1. Tontura, sensação de cabeça leve ou instabilidade.
2. Formigueiro ou dormência.
3. Sensação de desmaio ou desmaio.
4. Dor, pressão ou aperto no peito.
5. Falta de ar atípica ou crescente.
6. Confusão ou perda de controlo.
7. Respiração progressivamente ofegante, demasiado rápida ou demasiado funda.
8. Sintoma novo que não desapareça ao parar.

## Indicações técnicas principais

1. Segue a mudança do sinal, não forces o ar.
2. Mantém a amplitude confortável.
3. Deixa os ombros soltos.
4. Muda de fase sem prender a respiração.
5. Ajusta o guia à tua respiração; não sacrifiques o conforto para o acompanhar.
6. Se surgir desconforto, abandona o ritmo e respira espontaneamente.

## Erros comuns e correções

### Erro 1: Forçar uma frequência universal.

- Como reconhecer: Precisas de apressar ou atrasar muito a respiração para acompanhar um ritmo escolhido por outra pessoa ou aplicação.
- Como corrigir: Ajusta o sinal a um ritmo regular que permaneça confortável ou interrompe-o.

### Erro 2: Respirar demasiado fundo para preencher cada fase.

- Como reconhecer: Aumentas deliberadamente o volume de ar, elevas o peito ou tentas encher e esvaziar ao máximo.
- Como corrigir: Reduz a amplitude e deixa o ar entrar e sair suavemente.

### Erro 3: Acrescentar retenções.

- Como reconhecer: Paras o fluxo no fim da inspiração ou da expiração à espera da próxima indicação.
- Como corrigir: Usa um sinal que alterne diretamente entre as fases e muda de direção sem pausa forçada.

### Erro 4: Transformar o sinal num objetivo de desempenho.

- Como reconhecer: Continuas apesar de desconforto, tensão ou perda de controlo só para não falhar o ritmo.
- Como corrigir: Trata o sinal como um guia ajustável e abandona-o quando deixar de servir o conforto e o controlo.

### Erro 5: Levantar os ombros e tensionar a parte superior do peito.

- Como reconhecer: Os ombros sobem a cada inspiração, o pescoço fica rígido ou o peito trabalha de forma exagerada.
- Como corrigir: Solta os ombros, reduz a amplitude e recupera uma posição apoiada.

### Erro 6: Escolher um sinal difícil de perceber.

- Como reconhecer: Tens de fixar excessivamente o olhar, aumentar demasiado o som ou antecipar as mudanças.
- Como corrigir: Troca por uma modalidade acessível e claramente percetível ou pede ajuda para configurar o guia.

## Formas de simplificar ou ensaiar

1. Usa uma posição sentada bem apoiada e concentra-te apenas numa transição suave entre entrada e saída do ar.
2. Se um sinal externo criar pressão, desliga-o e mantém apenas um ritmo regular escolhido por ti.

## Supervisão

Não é exigida supervisão por defeito para uma pessoa elegível que compreenda a tarefa e consiga ajustar ou parar sozinha. Procura um profissional qualificado perante restrição clínica, incapacidade para interromper ou ajustar de forma independente, necessidade sensorial que impeça perceber o sinal com segurança, doença cardiovascular ou respiratória relevante, história de desmaio, regresso à função ou sintomas novos e sem explicação. Crianças, pessoas idosas, grávidas ou no pós-parto e pessoas previamente sedentárias podem precisar de adaptação individual.

## Como terminar

Desliga ou ignora o sinal, mantém a posição estável e deixa a respiração regressar ao padrão espontâneo. Não faças uma inspiração profunda final, não prendas o ar e não te levantes depressa se estiveres instável. Confirma que permaneces confortável antes de retomares outra atividade.

## Nota de segurança

O risco operacional de base é baixo, mas pode aumentar com fadiga, esforço intenso recente, padrão desconhecido, doença, sintomas ou ambiente inadequado. Interrompe perante sinais de aviso. Perante dor torácica, dificuldade respiratória intensa, desmaio, confusão súbita ou sintomas persistentes ou em agravamento, procura avaliação médica urgente. Não uses a tarefa para interpretar dióxido de carbono, variabilidade da frequência cardíaca ou mecanismos autonómicos, nem como substituto de avaliação clínica.

## Quando parar ou reduzir

1. Confusão ou perda de controlo.
2. Falta de ar atípica ou crescente.
3. Dor torácica.
4. Formigueiro ou outros sinais de hiperventilação.
5. Tontura, sensação de desmaio ou desmaio.

## Segurança do equipamento

Apoia o dispositivo numa superfície estável. Mantém cabos e suportes fora das zonas de passagem. Usa brilho, volume ou vibração percetíveis sem desconforto. Confirma que consegues parar ou ajustar o sinal de imediato. Não bloqueies avisos relevantes do ambiente. Não uses equipamento danificado ou suporte instável.

## Segurança do espaço

Usa uma zona segura, estável e livre de obstáculos. Evita fumo, vapores irritantes e má qualidade do ar. Não pratiques dentro de água, em altura desprotegida ou num veículo em movimento. Não combines a tarefa com condução, máquinas ou atividade que exija atenção externa contínua. No exterior, escolhe uma área abrigada onde o sinal permaneça percetível e a posição seja segura.

## Limitações

1. Conteúdo documental sem avaliação individual, dose, aprovação multimédia, diagnóstico ou tratamento. Implementação realizada: não.

## Teste de compreensão

### 1. Qual é o objetivo técnico da respiração ritmada?

Resposta esperada: Alinhar inspiração e expiração com um ritmo regular, mantendo controlo e conforto.

### 2. Que tipos de sinal podem orientar a tarefa?

Resposta esperada: Um sinal visual, sonoro ou háptico.

### 3. Existe uma frequência universal que todas as pessoas tenham de seguir?

Resposta esperada: Não; o sinal deve ser regular, ajustável e confortável.

### 4. A inspiração e a expiração têm de durar o mesmo?

Resposta esperada: Não existe uma razão temporal obrigatória.

### 5. Deves prender a respiração entre fases?

Resposta esperada: Não; a tarefa não inclui retenções.

### 6. Deves respirar o mais fundo possível?

Resposta esperada: Não; a amplitude deve permanecer confortável e sem esforço.

### 7. O que fazes se tiveres de te apressar para acompanhar o sinal?

Resposta esperada: Ajustas o sinal ou deixas de o seguir e regressas à respiração espontânea.

### 8. Como podes reconhecer sobre-respiração?

Resposta esperada: A respiração fica demasiado rápida ou funda e podem surgir tontura, cabeça leve, formigueiro ou falta de ar.

### 9. Que sinais exigem interrupção?

Resposta esperada: Tontura, formigueiro, dor torácica, falta de ar atípica ou crescente, confusão, sensação de desmaio ou desmaio.

### 10. Que características deve ter a posição inicial?

Resposta esperada: Deve ser estável, apoiada, confortável e permitir parar de imediato.

### 11. Quando deves procurar orientação profissional?

Resposta esperada: Perante restrição clínica, doença relevante, história de desmaio, sintomas novos ou incapacidade para ajustar e parar de forma independente.

### 12. Como terminas a tarefa?

Resposta esperada: Desligas ou ignoras o sinal e deixas a respiração regressar ao padrão espontâneo confortável.

## Fontes e limites da evidência

### Fonte 1: Controlled breathing and autonomic rhythms: Influence of auditory versus visual indicações técnicas

- Autor ou entidade: Controlled breathing and autonomic rhythms: Influence of auditory versus visual indicações técnicas — estudo primário — https://doi.org/10.1016/j.autneu.2021.102896 — Sustenta que sinais visuais e sonoros podem orientar a respiração e que a facilidade percebida varia com a modalidade. — A cadência experimental não foi transferida para o conteúdo.
- Tipo: estudo primário
- Localizador: https://doi.org/10.1016/j.autneu.2021.102896
- Usada para: Controlled breathing and autonomic rhythms: Influence of auditory versus visual indicações técnicas — estudo primário — https://doi.org/10.1016/j.autneu.2021.102896 — Sustenta que sinais visuais e sonoros podem orientar a respiração e que a facilidade percebida varia com a modalidade. — A cadência experimental não foi transferida para o conteúdo.
- Limite: Controlled breathing and autonomic rhythms: Influence of auditory versus visual indicações técnicas — estudo primário — https://doi.org/10.1016/j.autneu.2021.102896 — Sustenta que sinais visuais e sonoros podem orientar a respiração e que a facilidade percebida varia com a modalidade. — A cadência experimental não foi transferida para o conteúdo.

### Fonte 2: Inclusion of a Rest Period in Diaphragmatic Breathing Increases High Frequency Heart Rate Variability

- Autor ou entidade: Inclusion of a Rest Period in Diaphragmatic Breathing Increases High Frequency Heart Rate Variability — estudo primário — https://pmc.ncbi.nlm.nih.gov/articles/PMC5319881/ — Descreve operacionalmente um guia visual que muda de forma e um sinal sonoro de orientação. — As retenções, razões temporais, objetivos fisiológicos e dose do estudo foram excluídos.
- Tipo: estudo primário
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC5319881/
- Usada para: Inclusion of a Rest Period in Diaphragmatic Breathing Increases High Frequency Heart Rate Variability — estudo primário — https://pmc.ncbi.nlm.nih.gov/articles/PMC5319881/ — Descreve operacionalmente um guia visual que muda de forma e um sinal sonoro de orientação. — As retenções, razões temporais, objetivos fisiológicos e dose do estudo foram excluídos.
- Limite: Inclusion of a Rest Period in Diaphragmatic Breathing Increases High Frequency Heart Rate Variability — estudo primário — https://pmc.ncbi.nlm.nih.gov/articles/PMC5319881/ — Descreve operacionalmente um guia visual que muda de forma e um sinal sonoro de orientação. — As retenções, razões temporais, objetivos fisiológicos e dose do estudo foram excluídos.

### Fonte 3: Breathing exercises in the treatment of hyperventilation

- Autor ou entidade: Breathing exercises in the treatment of hyperventilation — orientação clínica profissional oficial — https://www.cuh.nhs.uk/patient-information/breathing-exercises-in-the-treatment-of-hyperventilation/ — Apoia ombros relaxados, expiração suave, ritmo confortável e procura de orientação se houver dor. — A finalidade terapêutica e as contagens do folheto não foram importadas.
- Tipo: orientação clínica profissional oficial
- Localizador: https://www.cuh.nhs.uk/patient-information/breathing-exercises-in-the-treatment-of-hyperventilation/
- Usada para: Breathing exercises in the treatment of hyperventilation — orientação clínica profissional oficial — https://www.cuh.nhs.uk/patient-information/breathing-exercises-in-the-treatment-of-hyperventilation/ — Apoia ombros relaxados, expiração suave, ritmo confortável e procura de orientação se houver dor. — A finalidade terapêutica e as contagens do folheto não foram importadas.
- Limite: Breathing exercises in the treatment of hyperventilation — orientação clínica profissional oficial — https://www.cuh.nhs.uk/patient-information/breathing-exercises-in-the-treatment-of-hyperventilation/ — Apoia ombros relaxados, expiração suave, ritmo confortável e procura de orientação se houver dor. — A finalidade terapêutica e as contagens do folheto não foram importadas.

### Fonte 4: Hyperventilation

- Autor ou entidade: Hyperventilation — fonte clínica profissional oficial — https://www.hopkinsmedicine.org/health/conditions-and-diseases/hyperventilation — Apoia a explicação de sobre-respiração, perda excessiva de dióxido de carbono e sinais de aviso. — Usada apenas para segurança e não para diagnóstico.
- Tipo: fonte clínica profissional oficial
- Localizador: https://www.hopkinsmedicine.org/health/conditions-and-diseases/hyperventilation
- Usada para: Hyperventilation — fonte clínica profissional oficial — https://www.hopkinsmedicine.org/health/conditions-and-diseases/hyperventilation — Apoia a explicação de sobre-respiração, perda excessiva de dióxido de carbono e sinais de aviso. — Usada apenas para segurança e não para diagnóstico.
- Limite: Hyperventilation — fonte clínica profissional oficial — https://www.hopkinsmedicine.org/health/conditions-and-diseases/hyperventilation — Apoia a explicação de sobre-respiração, perda excessiva de dióxido de carbono e sinais de aviso. — Usada apenas para segurança e não para diagnóstico.

### Fonte 5: A Practical Guide to Resonance Frequency Assessment for Heart Rate Variability Biofeedback

- Autor ou entidade: A Practical Guide to Resonance Frequency Assessment for Heart Rate Variability Biofeedback — guia científico-profissional — https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.570400/full — Separa respiração ritmada de avaliação de ressonância e documenta sobre-respiração. — Procedimentos de avaliação, métricas, frequências e objetivos clínicos foram excluídos.
- Tipo: guia científico-profissional
- Localizador: https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.570400/full
- Usada para: A Practical Guide to Resonance Frequency Assessment for Heart Rate Variability Biofeedback — guia científico-profissional — https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.570400/full — Separa respiração ritmada de avaliação de ressonância e documenta sobre-respiração. — Procedimentos de avaliação, métricas, frequências e objetivos clínicos foram excluídos.
- Limite: A Practical Guide to Resonance Frequency Assessment for Heart Rate Variability Biofeedback — guia científico-profissional — https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.570400/full — Separa respiração ritmada de avaliação de ressonância e documenta sobre-respiração. — Procedimentos de avaliação, métricas, frequências e objetivos clínicos foram excluídos.

### Fonte 6: How Breath-Control Can Change Your Life: A Systematic Review on Psycho-Physiological Correlates of Slow Breathing

- Autor ou entidade: How Breath-Control Can Change Your Life: A Systematic Review on Psycho-Physiological Correlates of Slow Breathing — revisão sistemática — https://pmc.ncbi.nlm.nih.gov/articles/PMC6137615/ — Fornece evidência de família e evidencia heterogeneidade de técnicas. — Não sustenta frequência, razão temporal ou efeito universal.
- Tipo: revisão sistemática
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC6137615/
- Usada para: How Breath-Control Can Change Your Life: A Systematic Review on Psycho-Physiological Correlates of Slow Breathing — revisão sistemática — https://pmc.ncbi.nlm.nih.gov/articles/PMC6137615/ — Fornece evidência de família e evidencia heterogeneidade de técnicas. — Não sustenta frequência, razão temporal ou efeito universal.
- Limite: How Breath-Control Can Change Your Life: A Systematic Review on Psycho-Physiological Correlates of Slow Breathing — revisão sistemática — https://pmc.ncbi.nlm.nih.gov/articles/PMC6137615/ — Fornece evidência de família e evidencia heterogeneidade de técnicas. — Não sustenta frequência, razão temporal ou efeito universal.
