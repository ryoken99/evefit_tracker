# Relatório de investigação — `seated_supported_thoracic_extension`

**Agente:** EX-24  
**Objeto exclusivo:** `seated_supported_thoracic_extension`  
**Data da pesquisa:** 24 de julho de 2026  
**Implementação realizada: não.**

## Resultado

O conteúdo para principiante pode ser aprovado com limites. A identidade canónica está bem sustentada como extensão torácica sentada sobre um fulcro, distinta da versão supina. A técnica pública deve manter cadeira estável sem rodas, ambos os pés apoiados, fulcro firme na região torácica, cabeça sustentada sem tração, pequeno arco posterior controlado e limitação explícita da extensão lombar e cervical compensatória.

O risco operacional permanece `moderate`. Não foram alterados equipamento, superfície, supervisão canónica, relações aprovadas, estado dos meios visuais ou capacidades de prescrição.

## Perguntas de investigação

A pesquisa procurou responder a:

1. Como organizar cadeira, pés, fulcro e apoio da cabeça?
2. Que região deve mover-se e que compensações devem ser evitadas?
3. Que orientação respiratória é defensável sem impor uma contagem?
4. Como delimitar uma amplitude adequada para conteúdo geral?
5. Que erros, sinais de interrupção e gatilhos de supervisão devem ser explicados?
6. Que elementos são diretamente sustentados e quais são inferências conservadoras do registo canónico?

## Fontes e contributo

| Código | Fonte | Tipo | Contributo usado | Limite |
|---|---|---|---|---|
| `C1-S13` / `C2-S09` | Heneghan et al., 2020, [DOI](https://doi.org/10.1136/bmjsem-2019-000713), [PubMed](https://pubmed.ncbi.nlm.nih.gov/32341799/) | Revisão sistemática e síntese narrativa | Reconhece famílias de mobilidade, controlo motor, capacidade de trabalho e força para a coluna torácica; sustenta a separação entre ação técnica e prescrição. | Evidência global baixa e heterogénea; não permite alegar eficácia universal do exercício concreto. |
| `C2-S07` | Cornell University Physical Therapy, [Thoracic Extension Mobilization Seated with Towel Roll](https://www.cornell.edu/video/thoracic-extension-mobilization-seat-towel-roll) | Recurso clínico universitário | Confirma o nome, a ação sentada e o uso de rolo de toalha como fulcro. | Recurso demonstrativo, não comparativo; o texto integral do vídeo não estava acessível nesta sessão. |
| `EX24-S01` | Cambridge University Hospitals NHS Foundation Trust, [Thoracic spine exercises](https://www.cuh.nhs.uk/patient-information/thoracic-spine-exercises/) | Orientação clínica oficial | Indica cadeira com encosto alto, pés firmes, inclinação suave para trás e extensão da região acima do encosto. Recomenda orientação profissional se os exercícios forem dolorosos. | Usa diretamente o encosto como fulcro e não detalha todas as compensações nem a respiração. |
| `EX24-S02` | Tyneside Integrated Musculoskeletal Service, [Managing Thoracic Back Pain](https://www.tims.nhs.uk/wp-content/uploads/2024/08/TIMS-Managing-Thoracic-Back-Pain-July-2024.pdf) | Folheto clínico oficial | Indica sentar numa cadeira com encosto, sustentar o pescoço com as mãos, arquear sobre o topo do encosto e procurar extensão torácica em vez de extensão cervical. Noutro movimento torácico do mesmo folheto, recomenda respirar regularmente. | Documento clínico contextual; as doses nele presentes foram deliberadamente excluídas. |
| `EX24-S03` | Ha et al., 2017, [Selective Activation of Thoracic Extensor Muscles during 3 Different Trunk Extensor Strengthening Exercise](https://doi.org/10.29273/jkema.2017.1.1.31) | Literatura primária: estudo comparativo de medidas repetidas com EMG | Em adultos jovens saudáveis, a extensão torácica ativa sentada apresentou maior razão de ativação dos extensores torácicos relativamente ao extensor lombar do que duas extensões em decúbito ventral. Reforça a importância de evitar uma estratégia dominada pela região lombar. | Exercício estudado diferente: braços e apêndice xifoide apoiados numa mesa, sem fulcro torácico igual ao canónico. Amostra pequena e saudável; não houve medição cinemática nem seguimento. |
| `EX24-S04` | American College of Sports Medicine, [Exercising Your Way to Lowering Your Blood Pressure](https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf) | Orientação profissional oficial | Sustenta a recomendação geral de respirar regularmente durante a atividade e evitar reter a respiração. | Não é específica para mobilidade torácica nem define uma fase respiratória deste gesto. |

As fontes clínicas de Cambridge, Tyneside e Cornell são independentes entre si. O estudo de Ha et al. acrescenta literatura primária, mas o seu exercício não é tecnicamente idêntico. A revisão de Heneghan et al. serve para enquadrar a família e tornar explícita a incerteza.

## Síntese técnica

### Execução e apoio

A configuração mais coerente para principiante é:

- cadeira estável, sem rodas;
- piso firme, nivelado e antiderrapante;
- ambos os pés apoiados;
- bacia estável no assento;
- rolo de toalha firme ou rolo de espuma colocado horizontalmente na região torácica;
- cabeça sustentada pelas duas mãos, sem tração;
- pequeno arco posterior da parte superior do tronco sobre o fulcro;
- retorno controlado à posição sentada neutra.

O fulcro não deve ficar no pescoço ou na região lombar. A pressão inicial leve contra o apoio é um teste operacional simples da estabilidade do conjunto, não um teste clínico.

### Respiração

Não foi encontrada evidência específica suficiente para impor uma sincronização respiratória universal nesta variante. A formulação defensável é respiração natural, regular e contínua, sem retenção. Pode mencionar-se uma correspondência opcional entre expiração e inclinação para trás, desde que não seja apresentada como requisito.

### Amplitude

As fontes clínicas usam linguagem de inclinação suave e foco regional; não fornecem um limiar angular transferível. Por isso, a amplitude deve ser descrita sem números: um pequeno arco que preserve conforto, contacto dos pés e da bacia, posição estável do fulcro, suporte da cabeça e controlo lombar. A amplitude termina quando algum destes critérios deixa de ser cumprido ou surge um sinal de alerta.

### Erros principais

Foram selecionados erros diretamente ligados à identidade e aos fatores de risco:

1. fulcro na região lombar;
2. cadeira, piso ou fulcro instável;
3. extensão lombar predominante e abertura excessiva das costelas;
4. tração da cabeça ou extensão cervical predominante;
5. amplitude forçada ou queda sem controlo;
6. perda de contacto dos pés ou deslizamento da bacia;
7. retenção respiratória.

### Segurança e supervisão

Mantêm-se os sinais canónicos de interrupção: dor aguda, bloqueio articular, perda súbita de controlo, tontura ou mal-estar. O conteúdo público canónico já referia sintomas irradiados, que foram mantidos como alerta. Instabilidade da cadeira ou do fulcro exige interrupção imediata da tentativa e correção do ambiente.

A supervisão canónica continua `none`: não é exigido parceiro nem observador por identidade. A recomendação condicional de supervisão aplica-se quando existe medo de queda, incapacidade de manter o suporte, sintomas durante a amplitude ou dificuldade em distinguir o movimento torácico das compensações lombar e cervical. Populações que requerem adaptação ou revisão foram preservadas sem criar diagnóstico nem autorização universal.

## Decisões editoriais

- Português europeu, claro para uma pessoa sem experiência.
- Sete passos de execução, sete pistas principais e sete erros estruturados.
- Doze perguntas de verificação de compreensão.
- Sem repetições, séries, duração, frequência, carga, intensidade, ritmo ou progressão programada.
- Sem promessa de resultado, diagnóstico, tratamento ou autorização universal.
- Sem alteração de identidade, risco, equipamento, superfície, relações ou meios visuais.
- A relação material foi preservada: `stable_chair_without_wheels` + (`firm_rolled_towel` ou `foam_roller`).
- A relação ambiental foi preservada: piso firme, nivelado e antiderrapante, espaço atrás da cadeira e ausência de perigo ou desnível.

## Limitações e confiança

**Confiança global:** moderada.

- **Identidade e equipamento:** alta, por concordância entre o registo canónico e recursos clínicos específicos.
- **Execução:** moderada a alta, devido à convergência das fontes clínicas oficiais.
- **Respiração:** moderada, porque a recomendação é geral e não específica da variante.
- **Compensação lombar:** moderada, apoiada por literatura primária indireta e coerência biomecânica.
- **Eficácia individual:** não estabelecida.

O conteúdo é, por isso, `beginner_content_approved_with_limits`. A aprovação é documental e não equivale a implementação, prescrição individual ou aprovação dos meios visuais.
