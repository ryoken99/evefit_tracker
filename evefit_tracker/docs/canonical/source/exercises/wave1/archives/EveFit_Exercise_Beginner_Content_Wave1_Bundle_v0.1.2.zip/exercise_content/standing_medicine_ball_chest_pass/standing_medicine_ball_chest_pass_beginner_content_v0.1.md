# Passe de peito com bola medicinal em pé

Conteúdo para principiantes em português europeu.

## Descrição curta

Passe balístico bilateral, feito em pé, no qual a bola medicinal é projetada para a frente a partir do peito.

## O que é

Em apoio nos dois pés, seguras uma bola medicinal junto ao centro do peito e projetas a bola para a frente com os dois braços. Os membros inferiores e o tronco podem contribuir através de um pequeno contramovimento, mas os pés mantêm-se apoiados e o corpo termina equilibrado.

## O que vais fazer

Vais preparar uma zona de lançamento controlada, adotar uma base bipodal estável, levar a bola ao peito, transferir força do corpo para os braços e libertá-la para a frente. Depois da libertação, travas o movimento do corpo antes de recuperares a bola.

## Porque existe este movimento

Este movimento existe para praticar a transferência rápida de força do corpo para uma libertação anterior bilateral. É uma tarefa balística: a bola torna-se um projétil e deixa de poder ser travada pelas mãos depois de libertada.

## Antes de começares

1. Confirma que compreendes como iniciar e interromper a tarefa e que consegues seguir o sinal de um supervisor ou parceiro.
2. Faz uma preparação geral e ensaia a posição e o gesto antes da primeira libertação.
3. Define previamente onde a bola vai terminar: numa zona de queda isolada, num alvo resistente e apropriado, ou nas mãos de um parceiro preparado.
4. Mantém todas as pessoas fora da trajetória e da zona de ressalto ou queda.
5. Não inicies se sentires dor aguda, mal-estar, tonturas, perda súbita de coordenação ou incapacidade para controlar a posição inicial.

## Preparar o equipamento

1. Usa uma bola medicinal íntegra, sem rasgos, fugas, zonas soltas ou superfície escorregadia.
2. A bola deve permitir que a segures com as duas mãos, a mantenhas estável ao peito e preserves controlo, precisão e amplitude durante o gesto.
3. Confirma se a bola foi concebida para ressaltar antes de a lançares contra uma parede; nem todas as bolas medicinais têm o mesmo comportamento.
4. Se usares uma parede ou outro alvo, confirma que é sólido, estável e adequado a impactos da bola escolhida.
5. Não substituas a bola medicinal por um objeto improvisado.

## Preparar o espaço

1. Escolhe uma superfície firme, regular e antiderrapante, com visibilidade suficiente.
2. Cria uma zona de lançamento controlada, sem trânsito, atravessamentos, objetos frágeis ou obstáculos.
3. Deixa livre toda a trajetória prevista e também a possível zona de ressalto, rolamento ou queda.
4. Se o exercício for feito no exterior, considera vento, piso molhado, calor, frio e pessoas que possam entrar na zona.
5. Combina um sinal claro de prontidão e um sinal de paragem sempre que exista parceiro ou supervisor.

## Verificação do corpo

1. Consegues manter os dois pés apoiados e permanecer equilibrado com a bola ao peito.
2. Consegues segurar a bola de forma simétrica, sem a deixar escorregar.
3. Consegues fletir ligeiramente ancas e joelhos sem perder o alinhamento confortável do tronco.
4. Consegues estender os braços para a frente sem dor aguda nem compensação evidente.
5. Consegues parar o corpo após um ensaio sem dar um passo para recuperar o equilíbrio.

## Posição inicial

Fica de pé, virado para a zona de receção, com os dois pés totalmente apoiados numa base confortável e estável. Mantém joelhos desbloqueados, tronco organizado e olhar dirigido para a trajetória. Segura a bola com as duas mãos, junto ao centro do peito, com cotovelos fletidos e punhos alinhados.

## Confirmar a posição inicial

1. Zona de lançamento e zona de queda ou ressalto livres.
2. Parceiro ou supervisor pronto, quando aplicável.
3. Dois pés apoiados e peso distribuído de forma controlada.
4. Bola segura com as duas mãos ao centro do peito.
5. Punhos alinhados, cotovelos fletidos e ombros numa posição confortável.
6. Tronco estável e olhar para a direção do passe.

## Passos de execução

1. Confirma novamente que ninguém entrou na trajetória e, se houver parceiro, espera pelo sinal explícito de que está pronto.
2. Organiza a base nos dois pés e mantém a bola firme junto ao centro do peito, sem a apoiar no rosto nem deixar os punhos dobrarem.
3. Faz um pequeno contramovimento confortável das ancas e dos joelhos, mantendo os pés no chão e o tronco controlado.
4. Transfere força dos pés e do tronco para a frente e acelera a bola com uma ação simultânea dos dois braços.
5. Estende os cotovelos e aproxima os braços à frente do peito, mantendo as mãos a atuar de forma simétrica.
6. Liberta a bola para a zona definida numa trajetória anterior controlada; não a dirijas para baixo nem para uma pessoa que não esteja preparada.
7. Conclui o seguimento dos braços e trava o corpo sobre os dois pés, sem perseguir a bola nem cair para a frente.
8. Recupera a bola apenas depois de ela parar e de a zona estar segura, ou recebe-a do parceiro somente após novo contacto visual e sinal de prontidão.

## Fases do movimento

### Preparação

Base bipodal estável, bola ao centro do peito, trajetória confirmada e respiração livre.

### Contramovimento

Pequena flexão coordenada de ancas e joelhos, sem passo nem perda do controlo do tronco.

### Propulsão e libertação

Transferência proximal-distal e extensão simultânea dos braços até a bola deixar as mãos para a frente.

### Travagem

O corpo absorve o movimento residual e termina equilibrado; a bola segue separada do executante.

### Recuperação

A bola só é recolhida quando a trajetória e a zona de receção voltam a estar controladas.

## Respiração

Respira de forma natural durante a preparação. Expira enquanto aceleras e libertas a bola. Volta a inspirar sem pressa depois de estabilizares. Evita prender a respiração; interrompe se surgir tontura, desorientação ou mal-estar.

## Sensações esperadas

1. Esforço breve no peito, ombros e parte posterior dos braços.
2. Participação do tronco e dos membros inferiores na transferência de força.
3. Sensação de aceleração rápida da bola seguida de uma travagem controlada do corpo.
4. Pressão firme, mas controlável, da bola nas mãos antes da libertação.

## Sensações inesperadas ou de alerta

1. Dor aguda ou sensação de lesão no ombro, cotovelo, punho, costas ou noutra região.
2. Tonturas, desorientação, falta de ar invulgar ou mal-estar.
3. Perda súbita de força, coordenação ou equilíbrio.
4. Incapacidade para segurar a bola, controlar a trajetória ou travar o corpo.
5. Impacto inesperado da bola no corpo ou contacto com outra pessoa ou objeto.

## Indicações técnicas principais

1. Zona livre antes de lançar.
2. Bola ao centro do peito.
3. Dois pés firmes no chão.
4. Corpo para braços, tudo em sequência.
5. Empurra e liberta para a frente.
6. Expira na libertação.
7. Termina equilibrado.

## Erros comuns e correções

### Erro 1: Lançar sem confirmar a zona de receção.

- Como reconhecer: Há pessoas, objetos frágeis ou circulação na trajetória, ou o parceiro ainda não sinalizou que está pronto.
- Como corrigir: Interrompe, isola a zona e só reinicia depois de a trajetória e o destino da bola estarem definidos e livres.

### Erro 2: Usar uma bola incompatível com o controlo técnico.

- Como reconhecer: A bola escorrega, altera a amplitude, torna o gesto lento ou faz perder precisão e simetria.
- Como corrigir: Troca por uma bola medicinal que consigas segurar e projetar sem degradar a técnica; um profissional pode ajudar a verificar a adequação.

### Erro 3: Perder a base ou dar um passo involuntário na libertação.

- Como reconhecer: Um pé sai do lugar, o tronco cai para a frente ou precisas de perseguir a bola para não perder o equilíbrio.
- Como corrigir: Reorganiza os dois apoios, reduz o contramovimento e ensaia a travagem antes de voltar a libertar a bola.

### Erro 4: Dobrar ou colapsar os punhos.

- Como reconhecer: As mãos deixam de ficar alinhadas com os antebraços e a bola sai de forma instável.
- Como corrigir: Mantém a bola centrada nas duas mãos e os punhos alinhados durante a aceleração e a libertação.

### Erro 5: Projetar a bola para baixo ou demasiado para cima.

- Como reconhecer: A trajetória não é anterior e a bola atinge o chão cedo, sobe sem necessidade ou foge da zona prevista.
- Como corrigir: Aponta a ação das mãos para a zona definida à frente do peito e termina com os braços orientados para esse destino.

### Erro 6: Rodar o tronco ou empurrar mais com um braço.

- Como reconhecer: Um ombro avança antes do outro ou a bola desvia-se lateralmente apesar de o alvo estar centrado.
- Como corrigir: Centra a bola, mantém o peito orientado para a frente e inicia a extensão dos dois braços ao mesmo tempo.

## Formas de simplificar ou ensaiar

1. Faz primeiro um ensaio da posição, contramovimento e travagem sem libertar a bola; isto é uma preparação técnica, não substitui o exercício.
2. Usa uma zona de queda ampla e isolada e recolhe a bola apenas quando ela parar, evitando uma receção de ressalto.
3. Mantém os pés no lugar e usa apenas um contramovimento pequeno que consigas travar.
4. Pede demonstração e observação direta na primeira exposição.
5. Se não consegues preservar controlo, precisão e equilíbrio, interrompe a tentativa em vez de compensar.

## Supervisão

A supervisão é recomendada, sobretudo na primeira exposição técnica. Usa supervisão direta quando estiveres a aprender, quando a zona tiver outras pessoas próximas ou quando houver mudança de bola, alvo ou velocidade pretendida. O supervisor deve conseguir observar a pessoa e toda a trajetória, dar um sinal de paragem e impedir a entrada de terceiros. Jovens, pessoas idosas, pessoas previamente sedentárias e pessoas com deficiência podem necessitar de adaptação do contexto e de instrução individual. Gravidez ou pós-parto, doença crónica relevante ou retorno funcional justificam revisão por profissional qualificado antes de integrar esta tarefa.

## Como terminar

Termina o passe sobre os dois pés e confirma que recuperaste o equilíbrio. Deixa a bola parar ou ser controlada pelo parceiro; não corras para uma trajetória ainda ativa. Recolhe a bola com a zona livre e transporta-a com as duas mãos. No final, coloca a bola num local estável onde não possa rolar nem criar risco de tropeção. Interrompe a zona de lançamento e informa o parceiro ou supervisor de que a tarefa terminou.

## Nota de segurança

Risco operacional moderado. A bola torna-se um projétil no momento da libertação; controla a zona completa, usa equipamento compatível e mantém supervisão recomendada. Um parceiro ou alvo pode ser usado, mas não é obrigatório. Se houver parceiro, o passe só acontece após sinal de prontidão e deve chegar de forma controlável; se houver alvo, este tem de ser resistente e adequado ao comportamento da bola.

## Quando parar ou reduzir

1. Dor aguda.
2. Mal-estar, tonturas ou desorientação.
3. Perda súbita de coordenação ou equilíbrio.
4. Incapacidade para controlar a travagem do corpo.
5. Incapacidade para segurar, dirigir ou recuperar a bola em segurança.
6. Entrada de uma pessoa ou obstáculo na trajetória.
7. Dano, fuga, deformação ou superfície escorregadia na bola.
8. Para perante este sinal de alerta: Dor aguda ou sensação de lesão no ombro, cotovelo, punho, costas ou noutra região.
9. Para perante este sinal de alerta: Tonturas, desorientação, falta de ar invulgar ou mal-estar.
10. Para perante este sinal de alerta: Perda súbita de força, coordenação ou equilíbrio.
11. Para perante este sinal de alerta: Incapacidade para segurar a bola, controlar a trajetória ou travar o corpo.
12. Para perante este sinal de alerta: Impacto inesperado da bola no corpo ou contacto com outra pessoa ou objeto.
13. O parceiro interrompe imediatamente o envio; ninguém persegue a bola e a recolha só acontece depois de a pessoa e a trajetória estarem estáveis.

## Segurança do equipamento

Inspeciona a bola antes de a usar e retira-a de serviço se estiver danificada. Escolhe uma bola que preserve controlo, precisão, amplitude e velocidade técnica; não há aqui uma carga prescrita. Confirma com o fabricante se a bola pode ressaltar ou embater no alvo escolhido. Mantém a bola seca e limpa o suficiente para uma preensão segura. Guarda-a de forma estável para que não role para uma zona de passagem.

## Segurança do espaço

Usa uma zona de lançamento controlada, com trajetória e área de queda ou ressalto desimpedidas. Evita superfícies frágeis, escorregadias ou irregulares. Não executes junto de trânsito, atravessamentos públicos, janelas, espelhos ou equipamento vulnerável. Garante luz suficiente para ver a bola, o parceiro e toda a trajetória. No exterior, interrompe se vento, precipitação, temperatura ou circulação de pessoas tornarem a trajetória imprevisível.

## Limitações

1. O conteúdo descreve técnica introdutória e gestão operacional, sem dose, carga, distância, velocidade concreta, progressão programada, promessa de resultado, diagnóstico ou autorização universal. Não transforma a receção da bola, o uso de parceiro ou o uso de alvo em requisitos. A adequação individual depende do contexto e pode exigir revisão profissional. Implementação realizada: não
2. Limite documentado: Não existe uma norma técnica universal identificada para a largura exata da base, posição fina dos cotovelos, ângulo de libertação ou formato de alvo.
3. Limite documentado: A resposta de ressalto varia entre modelos de bola e deve ser confirmada nas instruções do fabricante.
4. Limite documentado: A literatura consultada não define uma única estratégia de receção segura aplicável a todas as bolas, alvos e populações; por isso, a receção não integra a execução nuclear.
5. Limite documentado: A seleção individual da bola e do contexto de supervisão permanece fora do âmbito documental.

## Teste de compreensão

### 1. O que deves confirmar imediatamente antes de lançar?

Resposta esperada: Que a trajetória e a zona de queda ou ressalto estão livres e que o parceiro está pronto, quando existe.

### 2. Onde começa a bola?

Resposta esperada: Junto ao centro do peito, segura com as duas mãos.

### 3. Os pés devem sair do lugar durante esta versão?

Resposta esperada: Não; permanecem apoiados e o corpo termina equilibrado.

### 4. Que direção principal deve seguir a bola?

Resposta esperada: Para a frente, em direção à zona de receção definida.

### 5. Quando deves expirar?

Resposta esperada: Durante a aceleração e a libertação da bola.

### 6. É seguro prender a respiração durante toda a tentativa?

Resposta esperada: Não; a respiração deve permanecer natural e sem retenção prolongada.

### 7. O parceiro é obrigatório?

Resposta esperada: Não; pode usar-se uma zona de queda isolada ou um alvo adequado, mantendo sempre a trajetória controlada.

### 8. Como reconheces que a bola não é compatível com a técnica?

Resposta esperada: Quando escorrega ou compromete controlo, precisão, amplitude, simetria ou equilíbrio.

### 9. Deves correr imediatamente atrás de um passe desviado?

Resposta esperada: Não; deves manter-te fora da trajetória e recuperar a bola apenas quando a zona estiver segura.

### 10. O que fazes se alguém entrar na zona de lançamento?

Resposta esperada: Interrompes imediatamente e só recomeças quando toda a zona estiver livre.

### 11. Indica dois sinais que exigem interrupção.

Resposta esperada: Por exemplo, dor aguda, mal-estar, tonturas, perda de coordenação, perda de equilíbrio ou incapacidade para controlar a bola.

### 12. Quando é especialmente recomendada supervisão direta?

Resposta esperada: Na primeira aprendizagem e quando mudam a bola, o alvo, o espaço ou a velocidade pretendida.

## Fontes e limites da evidência

### Fonte 1: Developing Powerful Athletes Part 2: Practical Applications

- Autor ou entidade: Turner et al.; National Strength and Conditioning Association
- Tipo: artigo técnico profissional com suporte científico
- Localizador: https://www.nsca.com/contentassets/e4dd144726594fd3ba2cc4af571d6079/developing_powerful_athletes_part_2__practical.3.pdf
- Usada para: B1-S08 — Developing Powerful Athletes Part 2: Practical Applications — Turner et al.; National Strength and Conditioning Association — artigo técnico profissional com suporte científico — https://www.nsca.com/contentassets/e4dd144726594fd3ba2cc4af571d6079/developing_powerful_athletes_part_2__practical.3.pdf — Sustenta a classificação dos lançamentos de bola medicinal como balísticos e a contribuição dos membros inferiores quando existe contramovimento. — Não fornece um protocolo completo, específico e padronizado para esta versão canónica.
- Limite: B1-S08 — Developing Powerful Athletes Part 2: Practical Applications — Turner et al.; National Strength and Conditioning Association — artigo técnico profissional com suporte científico — https://www.nsca.com/contentassets/e4dd144726594fd3ba2cc4af571d6079/developing_powerful_athletes_part_2__practical.3.pdf — Sustenta a classificação dos lançamentos de bola medicinal como balísticos e a contribuição dos membros inferiores quando existe contramovimento. — Não fornece um protocolo completo, específico e padronizado para esta versão canónica.

### Fonte 2: Basics of Strength and Conditioning Manual

- Autor ou entidade: National Strength and Conditioning Association
- Tipo: manual profissional oficial
- Localizador: https://www.nsca.com/contentassets/48a12160221541acbdc048498d77192d/basics_of_strength_and_conditioning_manual.pdf
- Usada para: EX14-S01 — Basics of Strength and Conditioning Manual — National Strength and Conditioning Association — manual profissional oficial — https://www.nsca.com/contentassets/48a12160221541acbdc048498d77192d/basics_of_strength_and_conditioning_manual.pdf — Informa respiração, ensino técnico, supervisão, espaço desimpedido, piso e adequação das instalações a bolas medicinais. — As orientações são gerais para treino de força e condicionamento e não validam todos os detalhes desta execução.
- Limite: EX14-S01 — Basics of Strength and Conditioning Manual — National Strength and Conditioning Association — manual profissional oficial — https://www.nsca.com/contentassets/48a12160221541acbdc048498d77192d/basics_of_strength_and_conditioning_manual.pdf — Informa respiração, ensino técnico, supervisão, espaço desimpedido, piso e adequação das instalações a bolas medicinais. — As orientações são gerais para treino de força e condicionamento e não validam todos os detalhes desta execução.

### Fonte 3: Strength Training With Medicine Balls

- Autor ou entidade: Vincent, Traywick e Washburn; University of Arkansas System Division of Agriculture, Research & Extension
- Tipo: guia profissional universitário oficial
- Localizador: https://www.uaex.uada.edu/publications/pdf/FSFCS37.pdf
- Usada para: EX14-S02 — Strength Training With Medicine Balls — Vincent, Traywick e Washburn; University of Arkansas System Division of Agriculture, Research & Extension — guia profissional universitário oficial — https://www.uaex.uada.edu/publications/pdf/FSFCS37.pdf — Sustenta a posição da bola ao peito, a ação bilateral para a frente, a necessidade de passe controlável ao parceiro e a escolha de bola que não comprometa controlo, precisão ou amplitude. — A demonstração publicada inclui um passo e eventual receção; esses elementos não foram transpostos para a identidade canónica sem passo nem receção obrigatória.
- Limite: EX14-S02 — Strength Training With Medicine Balls — Vincent, Traywick e Washburn; University of Arkansas System Division of Agriculture, Research & Extension — guia profissional universitário oficial — https://www.uaex.uada.edu/publications/pdf/FSFCS37.pdf — Sustenta a posição da bola ao peito, a ação bilateral para a frente, a necessidade de passe controlável ao parceiro e a escolha de bola que não comprometa controlo, precisão ou amplitude. — A demonstração publicada inclui um passo e eventual receção; esses elementos não foram transpostos para a identidade canónica sem passo nem receção obrigatória.

### Fonte 4: Effects of Upper-Body Plyometric Training on Physical Fitness in Healthy Youth and Young Adult Participants: A Systematic Review

- Autor ou entidade: Garcia-Carrillo et al.
- Tipo: revisão sistemática científica
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC10575843/
- Usada para: SP-B2-S20 — Effects of Upper-Body Plyometric Training on Physical Fitness in Healthy Youth and Young Adult Participants: A Systematic Review — Garcia-Carrillo et al. — revisão sistemática científica — https://pmc.ncbi.nlm.nih.gov/articles/PMC10575843/ — Apoia a família de treino pliométrico do membro superior e documenta o uso de lançamentos com bola medicinal na literatura. — A heterogeneidade dos estudos não permite deduzir uma técnica única, dose ou resultado individual.
- Limite: SP-B2-S20 — Effects of Upper-Body Plyometric Training on Physical Fitness in Healthy Youth and Young Adult Participants: A Systematic Review — Garcia-Carrillo et al. — revisão sistemática científica — https://pmc.ncbi.nlm.nih.gov/articles/PMC10575843/ — Apoia a família de treino pliométrico do membro superior e documenta o uso de lançamentos com bola medicinal na literatura. — A heterogeneidade dos estudos não permite deduzir uma técnica única, dose ou resultado individual.

### Fonte 5: Diurnal Variations in Upper and Lower Body Power in Adolescent Volleyball Players: Exploring Time-of-Day Effects on Performance

- Autor ou entidade: Trajković et al.
- Tipo: estudo primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/39728860/
- Usada para: EX14-S03 — Diurnal Variations in Upper and Lower Body Power in Adolescent Volleyball Players: Exploring Time-of-Day Effects on Performance — Trajković et al. — estudo primário — https://pubmed.ncbi.nlm.nih.gov/39728860/ — Confirma o uso observável de um lançamento de bola medicinal em pé como tarefa distinta em investigação. — É um estudo de avaliação em jovens atletas e não uma fonte de instrução para principiantes nem de segurança operacional.
- Limite: EX14-S03 — Diurnal Variations in Upper and Lower Body Power in Adolescent Volleyball Players: Exploring Time-of-Day Effects on Performance — Trajković et al. — estudo primário — https://pubmed.ncbi.nlm.nih.gov/39728860/ — Confirma o uso observável de um lançamento de bola medicinal em pé como tarefa distinta em investigação. — É um estudo de avaliação em jovens atletas e não uma fonte de instrução para principiantes nem de segurança operacional.
