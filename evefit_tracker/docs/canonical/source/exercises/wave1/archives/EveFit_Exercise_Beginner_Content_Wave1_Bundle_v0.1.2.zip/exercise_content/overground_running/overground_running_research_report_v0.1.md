# Relatório de investigação — `overground_running`

**Agente:** EX-02  
**Data da investigação:** 23 de julho de 2026  
**Idioma de saída:** português europeu  
**Âmbito:** execução, preparação, respiração, segurança, erros e supervisão

## Resultado

Foi produzido conteúdo documental para principiantes com o estado `beginner_content_approved_with_limits`. O conteúdo mantém a identidade canónica de corrida terrestre, o risco operacional moderado, a ausência de equipamento obrigatório, a supervisão `none` por defeito e as relações aprovadas sem qualquer alteração.

A aprovação inclui limites porque as fontes não sustentam uma única técnica ideal para todas as pessoas, nem uma regra universal de apoio do pé, cadência ou padrão respiratório.

## Registo canónico preservado

| Campo | Valor preservado |
|---|---|
| `exercise_id` | `overground_running` |
| Nome | Corrida terrestre |
| Entidade | `canonical_exercise` |
| Família | `running_family` |
| Exercício-base | `none` |
| Variante de | `none` |
| Capacidade principal | `cardio_conditioning` |
| Risco operacional | `moderate` |
| Equipamento obrigatório | nenhum |
| Supervisão | `none` |
| Relações | inalteradas |

## Questões investigadas

1. Que elementos de postura e coordenação são suficientemente consensuais para um principiante?
2. Como descrever receção e passada sem impor uma reformulação universal da corrida?
3. Que preparação geral pode ser indicada sem dose?
4. Que orientação respiratória é defensável sem contagem nem retenção?
5. Que condições de superfície, visibilidade, calor, qualidade do ar e tráfego devem ser verificadas?
6. Que sinais justificam terminar e que situações justificam supervisão ou revisão?

## Fontes existentes no pacote

| Código | Fonte | URL | Utilização | Limite |
|---|---|---|---|---|
| A1-S01 | ACSM, *Exercising Your Way to Lowering Your Blood Pressure* | https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf | Reconhece a corrida como modalidade aeróbia. | Evidência de família, não técnica fina. |
| A1-S03 | American Heart Association, *Recommendations for Adults* | https://www.heart.org/en/healthy-living/exercise-and-physical-activity/fitness-basics/aha-recs-for-physical-activity-in-adults | Reconhece a corrida como atividade aeróbia. | Não define identidade mecânica nem autoriza dose. |
| A2-S04 | ACSM, *Investing in a Personal Trainer* | https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf | Enquadramento profissional e de família. | Lista exemplificativa, não taxonomia. |

## Fontes técnicas e profissionais adicionais

| Código | Organização e fonte | URL | Evidência utilizada |
|---|---|---|---|
| EX02-S01 | American College of Sports Medicine, *Healthy Habits for Distance Running* | https://acsm.org/distance-running-form-tips/ | Declara que não existe um padrão-ouro de reformulação aplicável a todos; sustenta passada não excessivamente longa, apoio mais próximo do centro do corpo, postura sem flexão excessiva pela cintura, movimento linear dos braços e interrupção perante degradação por fadiga. |
| EX02-S02 | England Athletics / gr8runners, *Running Technique* | https://clubspark.englandathletics.org/gr8runners/News/7003bc8b-71ae-46f6-b478-9670684b3ba4 | Sustenta postura alta, olhar à frente, ombros e mãos descontraídos, coordenação contralateral e movimento dos braços sobretudo para a frente e para trás. |
| EX02-S03 | NHS, *How to warm up before exercising* | https://www.nhs.uk/live-well/exercise/how-to-warm-up-before-exercising/ | Sustenta preparação antes do exercício e interrupção perante dor ou mal-estar. As quantidades da rotina não foram transpostas. |
| EX02-S04 | NHS, *Physical activity guidelines for adults aged 19 to 64* | https://www.nhs.uk/live-well/exercise/physical-activity-guidelines-for-adults-aged-19-to-64/ | Confirma que a corrida pode representar atividade exigente e que a adequação depende do estado da pessoa. Metas semanais e limiares de intensidade foram excluídos. |
| EX02-S05 | Centers for Disease Control and Prevention, *Heat and Athletes* | https://www.cdc.gov/heat-health/risk-factors/heat-and-athletes.html | Sustenta o calor como modificador de risco e a terminação da atividade perante fraqueza ou sensação de desmaio. |
| EX02-S06 | AirNow / U.S. Environmental Protection Agency, *When Smoke is in the Air* | https://www.airnow.gov/wildfires/when-smoke-is-in-the-air/ | Sustenta evitar corrida exterior quando existe fumo e verificar a qualidade do ar. |
| EX02-S07 | Better Health Channel, Department of Health, State Government of Victoria, *Running and jogging — preventing injury* | https://www.betterhealth.vic.gov.au/health/healthyliving/running-and-jogging-preventing-injury | Sustenta percurso iluminado, superfície regular e livre, atenção ao ambiente, preparação e interrupção perante dor. |

As decisões principais foram trianguladas entre fontes independentes: federação/estrutura de atletismo, organização profissional de medicina do desporto e organismos governamentais de saúde e ambiente.

## Decisões editoriais

### Execução

- A descrição mantém os elementos identitários: passadas alternadas, deslocamento global, apoios alternados e fase aérea repetida.
- Foram adotadas indicações simples: postura alta sem rigidez, olhar no percurso, ombros e mãos descontraídos, braços em coordenação contralateral e receção controlada.
- “Apoio mais perto do corpo” foi formulado como correção de passada excessivamente longa, sem ângulo, medida ou alvo de cadência.
- Não foi imposta velocidade. A expressão “sem procurar velocidade máxima” distingue a corrida do sprint sem criar uma prescrição.

### Preparação

- O conteúdo manda verificar percurso, superfície, obstáculos, tráfego, visibilidade, calor, frio e qualidade do ar.
- Foi incluída preparação gradual com movimentos conhecidos, sem duração, contagem, séries ou sequência fixa.
- A prontidão corporal limita-se aos pré-requisitos e sinais já presentes no registo canónico.

### Respiração

- Foi adotada respiração natural e contínua, pelo nariz, pela boca ou por ambos conforme a necessidade.
- Não foram introduzidas contagens, retenções ou sincronização obrigatória com as passadas.
- O aumento da ventilação é descrito como sensação possível; falta de ar atípica continua a ser sinal para terminar.

### Segurança e saída

- A estratégia de saída consiste em reduzir suavemente o deslocamento, passar à marcha e parar num ponto firme e livre.
- Foram preservados os sinais canónicos: desconforto no peito ou falta de ar atípica; tonturas ou confusão; perda de controlo ou dor nova.
- Fraqueza súbita e sensação de desmaio surgem apenas como operacionalização do modificador ambiental de calor, sustentada pelo CDC.
- Fumo e má qualidade do ar foram integrados sem criar limiares próprios; devem prevalecer os alertas locais.

### Supervisão

- A supervisão permanece não obrigatória por defeito.
- A recomendação de supervisão qualificada é limitada aos gatilhos canónicos de instabilidade marcada ou ambiente pouco familiar.
- O texto distingue supervisão de revisão: regresso após lesão ou cirurgia e sintomas cardiorrespiratórios relevantes pedem revisão apropriada, sem diagnóstico nem autorização clínica.

## Conflitos e respetiva resolução

### Tipo de apoio do pé

A página alojada pela England Athletics sugere apoio no antepé “se possível”. A fonte da ACSM afirma explicitamente que não existe um padrão-ouro para reformular todos os corredores. Não foi, por isso, imposta receção no antepé, calcanhar ou mediopé. O conteúdo limita-se a evitar passada excessivamente longa e a procurar apoio controlado.

### Cadência e comprimento da passada

A ACSM discute alterações mensuradas de cadência e comprimento da passada em contextos de reformulação. Esses valores são prescrição e podem depender da pessoa. Foram excluídos todos os números e alvos; permaneceu apenas a indicação qualitativa de não lançar o pé excessivamente à frente.

### Calçado

O Better Health Channel recomenda calçado de corrida específico. O registo canónico determina `required_equipment: []`, `optional_equipment: []` e `no_equipment_supported: true`. Não foi acrescentado qualquer requisito ou equipamento opcional. O texto limita-se à segurança do equipamento pessoal “se for usado”.

### Aquecimento

O NHS publica uma rotina com tempos e contagens. O contrato proíbe dose. Foi preservado apenas o princípio de preparação gradual, sem duração, repetições ou sequência prescrita.

### Intensidade e teste da fala

Algumas fontes classificam a corrida como vigorosa ou sugerem um ritmo conversacional. A intensidade é uma variável de prescrição, não de identidade. O conteúdo não usa teste da fala, zona, ritmo ou intensidade-alvo.

### Respiração

A fonte de técnica alojada pela England Athletics favorece respiração profunda abdominal, mas não foi identificada base suficiente para impor esse padrão a todos os principiantes. Aplicou-se a regra conservadora do contrato: respiração natural e contínua, sem retenção.

## Erros cobertos

1. Transformar a corrida num sprint explosivo.
2. Alongar excessivamente a passada.
3. Dobrar o tronco pela cintura ou olhar apenas para o chão.
4. Cerrar as mãos ou cruzar demasiado os braços.
5. Prender ou forçar a respiração.
6. Ignorar percurso e condições ambientais.

Cada erro inclui forma de reconhecimento e correção operacional.

## Limites da investigação

- As fontes técnicas estão maioritariamente em inglês; a redação em português europeu é uma tradução editorial sem citação literal extensa.
- A evidência sobre técnica de corrida é heterogénea e não sustenta uma forma única para todas as pessoas.
- O conteúdo não avalia morfologia, historial, sintomas, capacidade, superfície concreta ou contexto local de cada utilizador.
- Não se afirma que qualquer indicação previna lesão ou melhore desempenho.
- Não foram definidos critérios clínicos, diagnóstico, tratamento ou retorno após lesão.
- As orientações de calor e qualidade do ar são gerais e não substituem alertas oficiais locais.
- A revisão documental não aprova imagem ou vídeo.

## Verificações contratuais

- Português europeu e codificação UTF-8: aplicado.
- Normalização Unicode NFC: prevista para validação automática final.
- Passos de execução: 8, mínimo exigido 5.
- Indicações principais: 6, mínimo exigido 4.
- Erros comuns: 6, mínimo exigido 4.
- Forma dos erros: `error_pt_pt`, `how_to_recognise_pt_pt`, `correction_pt_pt`.
- Perguntas de compreensão: 12.
- Dose fixa, séries, distância, duração, carga, ritmo, frequência e progressão programada: ausentes.
- Promessa, diagnóstico, tratamento e autorização universal: ausentes.
- Identidade, risco, equipamento, supervisão e relações: inalterados.

## Declaração de zero implementação

Este trabalho é exclusivamente documental. Foram realizadas **zero implementações** de código, base de dados, configuração de produto, regras de elegibilidade, relações, multimédia, publicação ou prescrição. Nenhuma relação foi criada, removida ou alterada; nenhum meio foi aprovado; nenhuma decisão clínica foi automatizada.
