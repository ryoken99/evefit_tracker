# Alongamento dos gémeos à parede com joelho estendido

Conteúdo para principiantes em português europeu.

## Descrição curta

Alongamento sustentado da parte posterior da perna, em passada, com o joelho de trás estendido, o calcanhar no chão e as mãos numa parede estável.

## O que é

É uma posição de pé em que uma perna fica atrás e recebe uma dorsiflexão controlada do tornozelo enquanto o calcanhar permanece apoiado e o joelho estendido. A parede serve de apoio estável para as mãos.

## O que vais fazer

Ficar de frente para uma parede, colocar os pés em passada, apoiar as mãos e deslocar o corpo para a frente sem levantar o calcanhar nem fletir o joelho da perna de trás.

## Porque existe este movimento

A ação permite praticar uma posição sustentada de alongamento da parte posterior da perna com o gastrocnémio colocado em tensão pela combinação de dorsiflexão do tornozelo e extensão do joelho.

## Antes de começares

1. Confirma que a parede é rígida, estável e não tem objetos soltos na zona onde vais apoiar as mãos.
2. Escolhe um piso plano, estável, seco e antiderrapante.
3. Mantém a zona à volta dos pés livre e afasta-te de trânsito ou passagens ativas.
4. Confirma que consegues entrar na passada, apoiar ambos os pés e interromper a ação sem ajuda.
5. Não comeces se já existir dor aguda, dormência, formigueiro, fraqueza súbita, instabilidade ou mal-estar.

## Preparar o equipamento

1. Não é necessário equipamento portátil. A parede é uma característica obrigatória do local: deve suportar o contacto das mãos sem se mover, ceder ou deslizar.

## Preparar o espaço

1. Usa um espaço pequeno mas desimpedido, com parede estável e piso firme e antiderrapante. Confirma que há espaço para colocar um pé atrás e para regressar à posição vertical sem encontrar obstáculos.

## Verificação do corpo

1. Consegues ficar de pé com ambos os pés totalmente apoiados e as mãos na parede.
2. Consegues fazer uma passada confortável sem perder o equilíbrio.
3. Consegues manter o joelho da perna de trás estendido sem o forçar para trás.
4. Consegues deslocar ligeiramente o corpo para a frente sem dor e sem levantar o calcanhar posterior.

## Posição inicial

Fica de frente para a parede. Apoia as mãos à frente do tronco e coloca um pé à frente e o outro atrás, numa passada confortável. Mantém ambos os pés no chão, o pé de trás orientado de forma natural para a frente e o tronco organizado.

## Confirmar a posição inicial

1. Mãos apoiadas numa parede estável.
2. Pé da frente à frente do corpo e pé a alongar atrás.
3. Ambos os pés em contacto firme com o piso.
4. Calcanhar posterior totalmente apoiado.
5. Joelho posterior estendido, sem pressão agressiva para trás.
6. Pé posterior sem rotação excessiva para fora.
7. Tronco comprido, sem arquear a zona lombar.
8. Espaço livre para sair da posição.

## Passos de execução

1. Coloca as mãos na parede e distribui o apoio pelos dois pés antes de começares a deslocar o corpo.
2. Ajusta a passada para que o pé da frente possa acompanhar o avanço e o calcanhar do pé de trás continue totalmente no chão.
3. Estende o joelho da perna de trás sem o empurrar com força para além da posição neutra.
4. Mantém o pé posterior orientado de forma confortável para a frente e evita que rode excessivamente para fora.
5. Desloca o corpo e a bacia gradualmente em direção à parede, permitindo que o joelho da frente fleta.
6. Pára o avanço numa amplitude controlável, com tensão suave na barriga da perna de trás, calcanhar apoiado, joelho posterior estendido e respiração livre.
7. Para sair, afasta o corpo da parede de forma controlada, reduz a passada e volta a colocar os pés lado a lado.

## Fases do movimento

### Preparação

Verifica a parede e o piso, apoia as mãos e organiza a passada com ambos os pés no chão.

### Entrada

Mantém o joelho e o calcanhar posteriores na posição definida enquanto deslocas o corpo gradualmente para a frente.

### Posição sustentada

Mantém uma tensão suave e controlável na parte posterior da perna, sem balanços, sem forçar e sem prender a respiração.

### Saída

Recua o corpo, reduz a passada e regressa à posição de pé com controlo.

## Respiração

Respira de forma natural, confortável e contínua durante a entrada, a posição sustentada e a saída. Não prendas a respiração e não uses a respiração para forçar mais amplitude.

## Sensações esperadas

1. Tensão suave e difusa na barriga da perna que está atrás.
2. Sensação controlável de alongamento na parte posterior da perna, podendo aproximar-se da zona do calcanhar.
3. Pressão ligeira e estável das mãos na parede e dos pés no chão.

## Sensações inesperadas ou de alerta

1. Dor aguda, localizada ou crescente no tornozelo, calcanhar, barriga da perna ou joelho.
2. Dormência, formigueiro ou outra alteração súbita da sensibilidade.
3. Fraqueza súbita, sensação de falha da perna ou incapacidade de controlar a saída.
4. Tontura, mal-estar ou sensação de instabilidade.
5. Sensação de escorregamento do pé ou de movimento do apoio.

## Indicações técnicas principais

1. Parede firme e piso que não escorrega.
2. Calcanhar de trás no chão.
3. Joelho de trás estendido, sem o forçar.
4. Pé de trás orientado, sem rodar excessivamente para fora.
5. Avança o corpo como uma unidade, sem arquear a zona lombar.
6. Respira livremente e sai com controlo.

## Erros comuns e correções

### Erro 1: Levantar o calcanhar posterior.

- Como reconhecer: Sentes a pressão passar para a parte da frente do pé ou vês um espaço entre o calcanhar e o piso.
- Como corrigir: Recua ligeiramente o corpo ou aproxima um pouco o pé posterior até conseguires manter todo o calcanhar apoiado.

### Erro 2: Fletir o joelho da perna de trás.

- Como reconhecer: O joelho posterior deixa de estar estendido à medida que o corpo avança.
- Como corrigir: Reduz o avanço, volta a estender o joelho sem o forçar e só depois procura uma amplitude confortável.

### Erro 3: Rodar excessivamente o pé posterior para fora.

- Como reconhecer: Os dedos do pé de trás afastam-se muito da direção da parede ou o apoio deixa de parecer uniforme.
- Como corrigir: Reposiciona o pé para uma orientação natural mais voltada para a frente, mantendo o calcanhar e a planta do pé no chão.

### Erro 4: Arquear a zona lombar em vez de deslocar o corpo.

- Como reconhecer: A bacia fica atrás, o peito avança isoladamente e sentes compressão nas costas em vez de tensão suave na barriga da perna.
- Como corrigir: Mantém o tronco comprido e desloca a bacia e o tronco em conjunto na direção da parede.

### Erro 5: Entrar com balanços ou pressão excessiva.

- Como reconhecer: O corpo oscila repetidamente contra o fim da amplitude ou a sensação passa de tensão suave para dor.
- Como corrigir: Interrompe os balanços, recua e volta a entrar gradualmente apenas até uma tensão controlável.

### Erro 6: Usar uma parede ou um piso inseguros.

- Como reconhecer: O apoio move-se, cede ou está húmido, e os pés deslizam ou parecem instáveis.
- Como corrigir: Pára, escolhe uma parede rígida e muda para um piso plano, seco e antiderrapante antes de recomeçar.

## Formas de simplificar ou ensaiar

1. Usa uma passada mais curta para reduzir a amplitude, mantendo a mesma relação entre parede, mãos, pés, calcanhar e joelho.
2. Avança menos o corpo e confirma primeiro que consegues preservar o calcanhar apoiado.
3. Coloca as mãos numa zona confortável da parede para aumentar a sensação de estabilidade.
4. Pratica apenas a organização inicial e a saída controlada antes de acrescentar o avanço do corpo.

## Supervisão

Em condições habituais, com parede e piso verificados e capacidade para compreender e interromper a ação, não é exigido acompanhante nem supervisão. Procura orientação de um profissional qualificado se estiveres a regressar após lesão ou cirurgia, se uma doença crónica relevante, gravidez ou pós-parto, deficiência, hipermobilidade ou dificuldade de equilíbrio alterar a tua capacidade de executar e sair da posição com controlo. A presença de sintomas de aviso impede a continuação autónoma.

## Como terminar

Reduz primeiro o avanço do corpo, mantendo as mãos na parede e os dois pés apoiados. Depois encurta a passada, junta os pés e retira as mãos apenas quando estiveres estável.

## Nota de segurança

Usa apenas uma amplitude que permita manter o joelho posterior estendido, o calcanhar apoiado e o controlo do tronco. Reduz ou interrompe perante dor, alteração da sensibilidade, fraqueza, instabilidade, mal-estar ou perda de aderência.

## Quando parar ou reduzir

1. Reduz a amplitude se o calcanhar começar a levantar, o joelho posterior começar a fletir ou o tronco perder o alinhamento.
2. Interrompe perante dor aguda ou crescente.
3. Interrompe perante dormência, formigueiro ou fraqueza súbita.
4. Interrompe perante perda de controlo, instabilidade ou mal-estar.
5. Interrompe se a parede ceder ou se algum pé escorregar.

## Segurança do equipamento

Não há equipamento portátil. Antes do contacto, confirma que a parede é fixa, resistente, seca e livre de objetos soltos; não uses portas móveis, divisórias instáveis ou superfícies que possam deslizar.

## Segurança do espaço

O piso deve ser plano, firme, seco e antiderrapante. Mantém a área dos pés e a via de saída livres e não executes junto de trânsito ativo, degraus, tapetes soltos ou obstáculos.

## Limitações

1. Implementação realizada: não. Este conteúdo documenta a execução geral e não determina adequação individual. A investigação biomecânica citada não autoriza inferências sobre resultados pessoais, prevenção de lesões ou resposta clínica. Não foi aprovada qualquer imagem ou vídeo.

## Teste de compreensão

### 1. Que tipo de apoio deve ser usado pelas mãos?

Resposta esperada: Uma parede rígida, estável e seca, que não se mova nem ceda.

### 2. Como devem ficar os pés no início?

Resposta esperada: Em passada, com um pé à frente e o pé da perna a alongar atrás.

### 3. Qual é a perna que recebe o alongamento principal?

Resposta esperada: A perna que está atrás.

### 4. O que acontece ao joelho da perna de trás?

Resposta esperada: Permanece estendido, sem ser forçado agressivamente para trás.

### 5. O que deve acontecer ao calcanhar posterior?

Resposta esperada: Deve permanecer totalmente apoiado no chão.

### 6. Como entra o corpo na posição?

Resposta esperada: Desloca-se gradualmente em direção à parede, com controlo e sem arquear a zona lombar.

### 7. Como deve ser a respiração?

Resposta esperada: Natural, confortável e contínua, sem prender a respiração.

### 8. Que sensação é esperada?

Resposta esperada: Tensão suave e controlável na barriga da perna de trás.

### 9. O que fazer se surgir dor aguda ou crescente?

Resposta esperada: Interromper e sair da posição com controlo.

### 10. O que fazer perante dormência, formigueiro, fraqueza súbita ou instabilidade?

Resposta esperada: Interromper a ação; estes são sinais de aviso.

### 11. Que alteração muda esta identidade para a versão com predominância do sóleo?

Resposta esperada: Fletir o joelho da perna de trás.

### 12. Como se termina o exercício?

Resposta esperada: Recua-se o corpo, reduz-se a passada, juntam-se os pés e só depois se retiram as mãos quando existe estabilidade.

## Fontes e limites da evidência

### Fonte 1: Foot and Ankle Conditioning Program

- Autor ou entidade: D1-EXT-11/D2-S16 — Foot and Ankle Conditioning Program — American Academy of Orthopaedic Surgeons — guia profissional oficial — https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/ — Passada de frente para a parede, perna posterior estendida, calcanhar apoiado, avanço do corpo e erro de arquear as costas. — O enquadramento é de condicionamento e recuperação; foram usados apenas os elementos técnicos e de segurança coerentes com a identidade canónica.
- Tipo: guia profissional oficial
- Localizador: https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/
- Usada para: Passada de frente para a parede, perna posterior estendida, calcanhar apoiado, avanço do corpo e erro de arquear as costas.
- Limite: D1-EXT-11/D2-S16 — Foot and Ankle Conditioning Program — American Academy of Orthopaedic Surgeons — guia profissional oficial — https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/ — Passada de frente para a parede, perna posterior estendida, calcanhar apoiado, avanço do corpo e erro de arquear as costas. — O enquadramento é de condicionamento e recuperação; foram usados apenas os elementos técnicos e de segurança coerentes com a identidade canónica.

### Fonte 2: How to stretch after exercising

- Autor ou entidade: EX28-EXT-01 — How to stretch after exercising — National Health Service — orientação oficial de saúde — https://www.nhs.uk/live-well/exercise/how-to-stretch-after-exercising/ — Perna posterior estendida, calcanhar no chão e uso da parede como apoio. — A página apresenta orientação geral e não resolve elegibilidade individual.
- Tipo: orientação oficial de saúde
- Localizador: https://www.nhs.uk/live-well/exercise/how-to-stretch-after-exercising/
- Usada para: Perna posterior estendida, calcanhar no chão e uso da parede como apoio.
- Limite: EX28-EXT-01 — How to stretch after exercising — National Health Service — orientação oficial de saúde — https://www.nhs.uk/live-well/exercise/how-to-stretch-after-exercising/ — Perna posterior estendida, calcanhar no chão e uso da parede como apoio. — A página apresenta orientação geral e não resolve elegibilidade individual.

### Fonte 3: The influence of knee position on ankle dorsiflexion - a biometric study

- Autor ou entidade: EX28-PRI-01 — The influence of knee position on ankle dorsiflexion - a biometric study — Baumbach SF, Brumann M, Binder J, Mutschler W, Regauer M, Polzer H — estudo biomecânico primário — 2014 — 10.1186/1471-2474-15-246 — https://link.springer.com/article/10.1186/1471-2474-15-246 — Sustenta que a posição do joelho altera materialmente a influência do gastrocnémio na dorsiflexão e descreve medição em passada com apoio na parede. — A amostra foi pequena, adulta e assintomática; o estudo avaliou mecânica e não instrução pública nem resultados individuais.
- Tipo: estudo biomecânico primário
- Localizador: https://link.springer.com/article/10.1186/1471-2474-15-246
- Usada para: Sustenta que a posição do joelho altera materialmente a influência do gastrocnémio na dorsiflexão e descreve medição em passada com apoio na parede.
- Limite: EX28-PRI-01 — The influence of knee position on ankle dorsiflexion - a biometric study — Baumbach SF, Brumann M, Binder J, Mutschler W, Regauer M, Polzer H — estudo biomecânico primário — 2014 — 10.1186/1471-2474-15-246 — https://link.springer.com/article/10.1186/1471-2474-15-246 — Sustenta que a posição do joelho altera materialmente a influência do gastrocnémio na dorsiflexão e descreve medição em passada com apoio na parede. — A amostra foi pequena, adulta e assintomática; o estudo avaliou mecânica e não instrução pública nem resultados individuais.

### Fonte 4: Subtalar joint position during gastrocnemius stretching and ankle dorsiflexion range of motion

- Autor ou entidade: EX28-PRI-02 — Subtalar joint position during gastrocnemius stretching and ankle dorsiflexion range of motion — Johanson M, Baer J, Hovermale H, Phouthavong P — estudo primário — 2008 — 10.4085/1062-6050-43.2.172 — https://pubmed.ncbi.nlm.nih.gov/18345342/ — Informa a cautela em não impor um ângulo rígido do pé e reforça o controlo da orientação do retropé durante o alongamento do gastrocnémio. — A amostra incluiu voluntários saudáveis e o estudo não estabelece uma única orientação pública ideal do pé.
- Tipo: estudo primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/18345342/
- Usada para: Informa a cautela em não impor um ângulo rígido do pé e reforça o controlo da orientação do retropé durante o alongamento do gastrocnémio.
- Limite: EX28-PRI-02 — Subtalar joint position during gastrocnemius stretching and ankle dorsiflexion range of motion — Johanson M, Baer J, Hovermale H, Phouthavong P — estudo primário — 2008 — 10.4085/1062-6050-43.2.172 — https://pubmed.ncbi.nlm.nih.gov/18345342/ — Informa a cautela em não impor um ângulo rígido do pé e reforça o controlo da orientação do retropé durante o alongamento do gastrocnémio. — A amostra incluiu voluntários saudáveis e o estudo não estabelece uma única orientação pública ideal do pé.

### Fonte 5: Six tips for safe stretches

- Autor ou entidade: EX28-PRO-02 — Six tips for safe stretches — Harvard Health Publishing — orientação médica revista — https://www.health.harvard.edu/healthy-aging-and-longevity/six-tips-for-safe-stretches — Respiração confortável sem retenção, atenção ao alinhamento e distinção entre tensão suave e dor. — É orientação geral sobre alongamentos e não uma fonte específica deste exercício.
- Tipo: orientação médica revista
- Localizador: https://www.health.harvard.edu/healthy-aging-and-longevity/six-tips-for-safe-stretches
- Usada para: Respiração confortável sem retenção, atenção ao alinhamento e distinção entre tensão suave e dor.
- Limite: EX28-PRO-02 — Six tips for safe stretches — Harvard Health Publishing — orientação médica revista — https://www.health.harvard.edu/healthy-aging-and-longevity/six-tips-for-safe-stretches — Respiração confortável sem retenção, atenção ao alinhamento e distinção entre tensão suave e dor. — É orientação geral sobre alongamentos e não uma fonte específica deste exercício.
