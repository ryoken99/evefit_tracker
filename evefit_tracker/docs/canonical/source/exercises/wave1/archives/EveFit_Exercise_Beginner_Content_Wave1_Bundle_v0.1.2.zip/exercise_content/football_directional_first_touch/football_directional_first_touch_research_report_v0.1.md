# Relatório de investigação — Primeiro toque direcional no futebol

**Exercise ID:** `football_directional_first_touch`  
**Agente:** EX-44  
**Data de consulta:** 24 de julho de 2026  
Implementação realizada: não

## Decisão

O conteúdo para principiante é aprovado com limites (`beginner_content_approved_with_limits`). A confiança é alta para técnica, preparação e comunicação; moderada para segurança e supervisão; limitada para respiração específica.

A investigação preserva integralmente:

- a identidade fixa de receber com o pé e redirecionar no primeiro contacto para uma direção escolhida antecipadamente;
- risco operacional baixo;
- bola obrigatória, marcadores de chão opcionais e calçado adequado;
- parceiro e alvo obrigatórios;
- espaço moderado, corredor livre, superfície firme e nivelada ou relva curta;
- supervisão recomendada;
- as três relações aprovadas, incluindo a condição não resolvida do uso em aquecimento.

Não foram criadas variantes, relações, aprovações de media, prescrições ou alterações de risco.

## Perguntas de investigação

1. Como preparar o corpo, o alvo, a bola e o parceiro?
2. Que ação técnica define o primeiro contacto direcional?
3. Que pistas distinguem amortecer e orientar de parar ou pontapear a bola?
4. Que erros são observáveis por um principiante ou supervisor?
5. Que condições de equipamento, espaço e supervisão apoiam uma prática de baixo risco?
6. Existe orientação respiratória oficial específica?

## Síntese da evidência

### Preparação e orientação corporal

O FIFA Training Centre refere que a orientação corporal do recetor comunica onde pretende receber, influencia o controlo próximo e deve refletir a direção de movimento desejada. Também recomenda estar pronto sobre os pés, verificar o espaço e ajustar rapidamente a posição quando o passe não é exato.

A The FA recomenda planear a ação antes de ganhar posse: ver o espaço, pensar no que acontece a seguir, posicionar o corpo e mover-se para encontrar a trajetória da bola. A England Football Learning reforça que grande parte da receção ocorre antes do contacto e destaca comunicação clara entre dois jogadores.

Aplicação documental:

- alvo e direção confirmados antes do passe;
- corpo ligeiramente aberto para ver parceiro, bola e alvo;
- sinal de prontidão combinado;
- pequenos ajustes com pés descruzados.

### Primeiro contacto

O FIFA Training Centre sustenta um primeiro toque para fora dos pés, para o espaço ou direção seguinte, com controlo suficiente para manter a bola alcançável. As fontes não impõem uma única superfície do pé para todos os contextos; por isso, o conteúdo usa a formulação prudente «superfície ampla e controlável do pé recetor».

Aplicação documental:

- apresentar o pé à trajetória;
- acompanhar ligeiramente a chegada para absorver velocidade;
- orientar a superfície para o alvo no mesmo contacto;
- avaliar o resultado pela bola controlada e alcançável.

### Parceiro, alvo e comunicação

A FIFA e a The FA descrevem comunicação verbal, gestual e através da orientação corporal. Isto sustenta combinar um sinal de prontidão, uma origem de passe e uma zona-alvo antes da tentativa. A velocidade e a trajetória do passe não são transformadas em dose: o texto limita-se a exigir uma alimentação controlada e previsível compatível com a identidade aprovada.

### Segurança e supervisão

O FIFA Training Centre recomenda criar um espaço seguro nas tarefas de futebol de base. O guia de gestão de risco da FA estabelece a identificação de perigos na atividade e no equipamento e a obrigação organizacional de proporcionar condições tão seguras quanto possível.

O conteúdo concretiza estes princípios sem alterar a classificação canónica:

- corredor e trajetória de saída livres;
- bolas soltas e equipamento fora da linha de receção;
- piso firme, nivelado e não escorregadio;
- iluminação e espaço lateral adequados;
- calçado compatível com a superfície;
- interrupção perante dor aguda, invasão do corredor, colisão ou perda repetida do apoio;
- supervisão na primeira exposição e após mudança relevante do passe.

### Respiração

Não foi encontrada nas fontes federativas consultadas uma técnica respiratória específica para o primeiro toque direcional. Foi aplicada a regra conservadora do contrato: respiração natural e contínua, sem contagens nem retenção. Não é apresentada como técnica de rendimento.

## Matriz de fontes

| Código | Fonte primária/oficial | Contributo | Limite |
|---|---|---|---|
| F1S01 | [FIFA — Receiving between the lines](https://www.fifatrainingcentre.com/en/practice/talent-coach-programme/build-and-progress/passing-circuit-receiving-between-the-lines.php) | Passe e receção contextual | A sessão não define sozinha a identidade |
| F1S02 | [FIFA — Receiving on the half-turn](https://www.fifatrainingcentre.com/en/practice/talent-coach-programme/build-and-progress/passing-circuit-midfielders-receiving-on-the-half-turn.php) | Orientação corporal | Não prova decisão numa versão fixa |
| F2-S06 | [FIFA — Passing and receiving](https://www.fifatrainingcentre.com/en/practice/elite-sessions/in-possession/john-peacock-passing-and-receiving.php) | Postura aberta, espaço, peso do passe e toque de saída | Inclui pressão e tarefas de equipa |
| F2-S26 | [PMC — The Role of Variability in Motor Learning](https://pmc.ncbi.nlm.nih.gov/articles/PMC6091866/) | Fronteira entre prática fixa e variabilidade | Não valida uma manipulação específica |
| EX44-R1 | [FIFA — Directing the ball with the first touch](https://www.fifatrainingcentre.com/en/practice/elite-sessions/in-possession/directing-the-ball-with-the-first-touch.php) | Orientação, ajuste dos pés e primeiro contacto | Inclui finalização e oposição |
| EX44-R2 | [The FA — Top tips for receiving the ball](https://www.thefa.com/bootroom/resources/coaching/top-tips-for-receiving-the-ball) | Planeamento prévio, forma corporal e encontro da trajetória | Orientação geral, não protocolo individual |
| EX44-R3 | [England Football Learning — Coaching receiving](https://learn.englandfootball.com/articles-and-resources/coaching/resources/2022/how-to-coach-receiving-skills-in-football) | Preparação, leitura e ligação com parceiro | Não prescreve uma mecânica única |
| EX44-R4 | [FIFA — Small team exercises](https://www.fifatrainingcentre.com/en/practice/grassroots/4-to-8/small-team-exercises.php) | Comunicação e espaço seguro | Tarefas de grupo, não avaliação local |
| EX44-R5 | [The FA / Gloucestershire FA — Risk management](https://www.thefa.com/-/media/cfa/gloucestershirefa/files/leagues-and-clubs/club-management/ngis---a-guide-to-risk-management-for-grassroots-football.ashx?la=en) | Identificação e controlo de perigos | Guia geral, não classifica este exercício |

## Erros técnicos sustentados

1. **Decidir depois do contacto:** contradiz a versão fixa e tende a produzir uma paragem antes da redireção.
2. **Não ajustar os pés:** obriga a alcançar a bola e reduz a estabilidade.
3. **Cruzar o apoio:** limita espaço para o pé recetor e pode bloquear a trajetória.
4. **Contacto rígido:** envia a bola para fora da zona alcançável.
5. **Parar totalmente:** elimina a redireção no primeiro toque.
6. **Olhar apenas para o pé:** perde informação do parceiro e do alvo antes da receção.

## Limites e exclusões

- Sem dose, séries, repetições, duração, distância, carga, ritmo, frequência ou progressão programada.
- Sem diagnóstico, tratamento, autorização clínica ou promessa de resultado.
- Sem oposição, escolha entre respostas, direção variável ou receção aérea.
- Sem alteração de identidade, risco, equipamento, espaço, supervisão ou relações.
- A recomendação de supervisão não substitui avaliação clínica quando aplicável.
- O uso em aquecimento permanece dependente da prescrição da sessão e não foi resolvido.
- A evidência é técnica e de família; não prova segurança universal, transferência ou resultado individual.
