# Flexão de braços pliométrica

Conteúdo para principiantes em português europeu.

## Descrição curta

Flexão pliométrica em que ambas as mãos deixam o solo e regressam a uma receção simultânea e controlada.

## O que é

É uma ação pliométrica avançada do membro superior. Parte-se de uma prancha alta, baixa-se o corpo como uma unidade, empurra-se o chão com rapidez suficiente para as duas mãos perderem contacto e recebe-se novamente o peso pelas mãos. A fase aérea e a receção distinguem este exercício de uma flexão apenas rápida. A explicação destina-se a compreensão; não autoriza a execução autónoma na primeira exposição.

## O que vais fazer

Vais organizar uma prancha alta estável, efetuar uma descida controlada, inverter rapidamente a ação, projetar a parte superior do corpo até as mãos saírem do chão e amortecer a receção com as duas mãos. Os pés permanecem em contacto com o solo.

## Porque existe este movimento

O propósito técnico imediato é coordenar a absorção, a inversão rápida e a nova projeção de força através dos membros superiores. Não é uma promessa de resultado nem uma indicação de que o exercício seja adequado a todas as pessoas.

## Antes de começares

1. Não executes esta ação sozinho na primeira exposição; pede observação direta a um profissional de exercício qualificado.
2. Confirma que compreendes como interromper a tarefa e como baixar os joelhos depois de recuperares apoio seguro nas mãos.
3. Demonstra primeiro uma prancha alta e uma flexão convencional com controlo do tronco, dos ombros e dos cotovelos.
4. Não avances se houver dor aguda, mal-estar, perda de coordenação ou incapacidade de controlar uma receção pelas mãos.
5. Pessoas grávidas ou no pós-parto, com doença crónica relevante ou em retorno funcional necessitam de revisão adequada ao seu contexto antes desta tarefa.

## Preparar o equipamento

1. Não é necessário equipamento. Não acrescentes caixas, bolas, pegas, bandas, cargas, palmas ou superfícies instáveis: alteram a tarefa, podem aumentar o risco e não pertencem a esta entrada.

## Preparar o espaço

1. Escolhe uma superfície firme, plana, seca e antiderrapante.
2. Liberta o chão à frente e ao lado das mãos e garante espaço superior suficiente.
3. Assegura boa iluminação e afasta pessoas, animais, cabos e objetos.
4. Não uses zonas de passagem, espaços com circulação ativa ou locais onde alguém possa cruzar a área.

## Verificação do corpo

1. Consegues manter cabeça, tronco e bacia alinhados numa prancha alta sem colapso lombar.
2. Consegues realizar a descida e a subida de uma flexão convencional sem dor e sem perder o apoio das mãos.
3. Consegues travar o corpo com os cotovelos ligeiramente fletidos sem o peito cair no chão.
4. Os punhos, cotovelos e ombros toleram o apoio no chão sem dor aguda, formigueiro ou sensação de instabilidade.
5. Estás suficientemente coordenado para ouvir uma indicação de paragem e terminar de imediato.
6. Um profissional qualificado está presente na primeira exposição e consegue ver as mãos, os ombros e o alinhamento do tronco.

## Posição inicial

Assume uma prancha alta em decúbito ventral, com as duas mãos apoiadas de forma simétrica, ligeiramente mais afastadas do que os ombros, dedos abertos e orientados confortavelmente para a frente. Mantém os pés no solo, os braços estendidos sem rigidez excessiva, a cabeça em continuidade com o tronco e o corpo organizado numa linha estável da cabeça aos calcanhares.

## Confirmar a posição inicial

1. Mãos inteiras apoiadas, secas e colocadas simetricamente.
2. Pés firmes no solo e sem possibilidade de escorregar.
3. Cabeça e pescoço alinhados, com olhar dirigido para o chão.
4. Costelas e bacia controladas, sem arqueamento lombar marcado.
5. Ombros estáveis e cotovelos orientados numa diagonal confortável, sem abrir totalmente para os lados.
6. Área de receção livre e superfície confirmada pelo supervisor.

## Passos de execução

1. Estabelece a prancha alta e distribui o apoio pelas duas mãos, mantendo o corpo como uma unidade.
2. Inspira naturalmente enquanto fletes os cotovelos e baixas o corpo sob controlo, sem deixar a bacia cair nem o peito tocar no chão.
3. Inverte rapidamente a descida e empurra o chão com ambas as mãos ao mesmo tempo.
4. Expira durante a projeção e permite que as duas mãos percam contacto com o solo em simultâneo.
5. Durante a breve fase aérea, mantém as mãos abertas e preparadas para regressar aproximadamente aos mesmos pontos de apoio.
6. Recebe o chão com as duas mãos ao mesmo tempo e com os cotovelos ligeiramente fletidos.
7. Amortece o contacto deixando os cotovelos fletirem de forma controlada, mantendo a cabeça, o tronco e a bacia alinhados.
8. Recupera uma prancha alta estável e retoma uma respiração natural; termina se a receção ou o alinhamento não estiverem controlados.

## Fases do movimento

### Preparação

Prancha alta estável, mãos e pés no solo e área de receção confirmada.

### Carga e descida

Flexão controlada dos cotovelos e descida do corpo como uma unidade.

### Inversão e projeção

Mudança rápida para a extensão dos cotovelos e projeção simultânea através das duas mãos.

### Fase aérea

Ambas as mãos estão sem contacto; os pés mantêm o apoio.

### Receção e travagem

As mãos regressam simultaneamente e os cotovelos fletidos absorvem a carga mantendo a prancha.

### Estabilização ou nova projeção

A pessoa recupera controlo antes de terminar ou, apenas em contexto supervisionado e tecnicamente competente, ligar a receção a nova projeção.

## Respiração

Mantém a respiração contínua: deixa entrar o ar durante a descida controlada, expira durante o empurrão e a projeção e retoma imediatamente uma respiração natural na receção. Não prendas a respiração e não imponhas contagens.

## Sensações esperadas

1. Pressão firme e breve nas palmas durante o apoio e a receção.
2. Trabalho muscular no peito, parte anterior dos ombros e parte posterior dos braços.
3. Ativação do tronco para manter a prancha.
4. Contacto rápido das mãos com necessidade de amortecer pelos cotovelos.

## Sensações inesperadas ou de alerta

1. Dor aguda no punho, cotovelo, ombro, peito, pescoço ou costas.
2. Formigueiro, dormência ou perda súbita de força numa mão ou num braço.
3. Sensação de ombro ou punho a ceder, deslocar ou bloquear.
4. Tonturas, mal-estar ou falta de ar invulgar.
5. Incapacidade de colocar as duas mãos em simultâneo ou de travar o corpo.
6. Impacto crescente acompanhado de perda de alinhamento ou coordenação.

## Indicações técnicas principais

1. Corpo alinhado antes de descer.
2. Empurra o chão com as duas mãos ao mesmo tempo.
3. Mãos abertas e prontas para regressar.
4. Recebe com as duas palmas e cotovelos ligeiramente fletidos.
5. Amortece sem deixar a bacia cair.
6. Expira na projeção; não prendas a respiração.
7. Sem palmas, caixas ou deslocações das mãos.
8. Se perderes controlo, recupera o apoio e baixa os joelhos.

## Erros comuns e correções

### Erro 1: Executar apenas uma flexão rápida sem as mãos deixarem o chão.

- Como reconhecer: As palmas mantêm contacto contínuo com a superfície.
- Como corrigir: Não lhe chames flexão pliométrica. Mantém essa ação como padrão antecedente e só tenta a identidade completa sob supervisão quando existir capacidade para uma fase aérea controlada.

### Erro 2: Deixar a bacia cair ou arquear a zona lombar na projeção.

- Como reconhecer: O abdómen aproxima-se do chão antes do peito, ou o corpo deixa de se mover como uma unidade.
- Como corrigir: Interrompe a tentativa, recupera a prancha pelos joelhos e volta a demonstrar controlo do tronco no padrão antecedente.

### Erro 3: Receber primeiro com uma mão.

- Como reconhecer: O som, a pressão ou a posição mostram um contacto claramente antecipado de um lado.
- Como corrigir: Termina a ação e pede ao supervisor para rever simetria, posição das mãos e preparação para a receção antes de nova exposição.

### Erro 4: Aterrar com os cotovelos rígidos.

- Como reconhecer: O contacto é brusco e quase não existe flexão dos cotovelos para absorver a carga.
- Como corrigir: Regressa a um padrão antecedente e demonstra primeiro uma travagem com cotovelos ligeiramente fletidos; não repitas a fase aérea sem controlo.

### Erro 5: Abrir demasiado os cotovelos.

- Como reconhecer: Os braços formam quase uma linha perpendicular ao tronco durante a descida ou receção.
- Como corrigir: Usa uma diagonal confortável dos braços e mantém os ombros organizados; o supervisor deve confirmar a posição antes da tentativa.

### Erro 6: Tentar bater palmas ou deslocar as mãos.

- Como reconhecer: As mãos afastam-se da zona de receção ou deixam de estar prontas para o chão.
- Como corrigir: Mantém as mãos abertas sobre os pontos de apoio originais. Palmas e deslocações são variantes não aprovadas nesta entrada.

### Erro 7: Prender a respiração.

- Como reconhecer: Há bloqueio respiratório e tensão desnecessária no rosto ou pescoço.
- Como corrigir: Deixa entrar o ar na descida, expira na projeção e volta à respiração natural na receção.

### Erro 8: Continuar depois de a receção perder qualidade.

- Como reconhecer: As mãos deixam de chegar juntas, o impacto aumenta ou a prancha colapsa.
- Como corrigir: Para, recupera apoio estável, baixa os joelhos e termina. A qualidade da receção é um critério de interrupção.

## Formas de simplificar ou ensaiar

1. Observa primeiro uma demonstração lateral e frontal feita por um profissional qualificado.
2. Usa marcas visuais no chão apenas para recordar a posição simétrica das mãos; as marcas não são equipamento de apoio.
3. Aprende separadamente a prancha alta, a flexão convencional e a saída segura para os joelhos. Estas ações são pré-requisitos, não equivalentes à flexão pliométrica.
4. Exclui palmas, caixas, profundidade, carga externa, bandas e superfícies instáveis.
5. Se ainda não existe uma flexão convencional controlada ou capacidade de travagem, fica pela observação e avaliação do padrão antecedente; não realizes a fase aérea.

## Supervisão

A supervisão é recomendada e é necessária na primeira exposição técnica. O profissional deve confirmar o padrão antecedente, o estado da superfície, a posição das mãos, a simetria da projeção, a flexão dos cotovelos na receção e os critérios de paragem. Deve permanecer próximo, com visão desimpedida e capacidade de comunicar imediatamente, mas não tentar agarrar a pessoa em pleno voo. Não é exigido um assistente de segurança manual.

## Como terminar

Depois de uma receção controlada, estabiliza a prancha alta, coloca os joelhos no chão um de cada vez e desloca a bacia para trás ou baixa o tronco sob controlo. Levanta-te apenas quando estiveres estável. Se a receção falhar, recupera primeiro apoio com as mãos e só depois baixa os joelhos.

## Nota de segurança

Exercício de risco operacional elevado, com carga rápida nos membros superiores e receção pelas mãos. Exige competência prévia na flexão, controlo do tronco e capacidade de travagem. Interrompe perante dor aguda, mal-estar, perda súbita de coordenação ou incapacidade de controlar a receção. Esta informação não substitui avaliação individual nem autorização clínica.

## Quando parar ou reduzir

1. Dor aguda ou crescente no punho, cotovelo, ombro, peito, pescoço ou costas.
2. Mal-estar, tonturas ou falta de ar invulgar.
3. Perda súbita de coordenação, força ou sensibilidade.
4. Uma mão aterra repetidamente antes da outra.
5. Incapacidade de fletir os cotovelos para travar a receção.
6. Colapso dos ombros, do peito ou da bacia.
7. Mãos ou pés a escorregar.
8. Falha em compreender ou cumprir uma indicação de paragem.

## Segurança do equipamento

Sem equipamento obrigatório. Não improvises pegas, plataformas, almofadas espessas ou objetos para elevar as mãos ou os pés. Confirma que pele, mãos e superfície estão secas; remove objetos soltos da zona de contacto.

## Segurança do espaço

Usa apenas piso firme, uniforme, seco e antiderrapante, com iluminação suficiente e área livre. Evita superfícies escorregadias, instáveis, excessivamente macias, desniveladas ou expostas a trânsito, pessoas a passar, calor ou frio que prejudiquem a aderência e o controlo.

## Limitações

1. A evidência direta de execução e forças provém sobretudo de adultos jovens, ativos e frequentemente do sexo masculino.
2. Não foram encontrados dados robustos que estabeleçam uma técnica respiratória exclusiva da flexão pliométrica; a indicação usa a mecânica da flexão convencional e o registo canónico.
3. Não se pode inferir elegibilidade individual, ausência de lesão ou segurança universal a partir destas fontes.
4. Este conteúdo exclui palmas, caixas, profundidade, apoio de joelhos, carga, bandas e superfícies instáveis como execuções da identidade aqui documentada.
5. Não inclui dose, progressão programada, tratamento, diagnóstico ou autorização clínica.
6. A primeira exposição não deve ser autónoma.

## Teste de compreensão

### 1. O que distingue esta ação de uma flexão apenas rápida?

Resposta esperada: As duas mãos perdem contacto com o solo e regressam a uma receção controlada.

### 2. Os pés saem do chão nesta identidade?

Resposta esperada: Não. Os pés permanecem apoiados.

### 3. Podes executar sozinho na primeira exposição depois de leres este guia?

Resposta esperada: Não. A primeira exposição requer supervisão direta de um profissional qualificado.

### 4. Que padrão deves demonstrar antes da fase aérea?

Resposta esperada: Uma prancha alta e uma flexão convencional controladas, sem dor e com o tronco alinhado.

### 5. Como devem chegar as mãos ao chão?

Resposta esperada: Ao mesmo tempo, aproximadamente nos pontos de partida, com as palmas abertas.

### 6. Como ajudam os cotovelos a controlar a receção?

Resposta esperada: Chegam ligeiramente fletidos e continuam a fletir de forma controlada para amortecer.

### 7. Deves bater palmas durante a fase aérea?

Resposta esperada: Não. As mãos ficam abertas e preparadas para a receção.

### 8. Como respiras durante a ação?

Resposta esperada: Deixo entrar o ar na descida, expiro na projeção e retomo a respiração natural na receção, sem prender.

### 9. Que tipo de superfície é necessária?

Resposta esperada: Firme, plana, seca, uniforme e antiderrapante.

### 10. O que fazes se uma mão chegar antes da outra?

Resposta esperada: Termino, recupero apoio seguro, baixo os joelhos e peço revisão técnica ao supervisor.

### 11. Indica dois sinais que obrigam a parar.

Resposta esperada: Por exemplo, dor aguda e incapacidade de controlar a receção; também contam mal-estar, perda de coordenação ou escorregamento.

### 12. Qual é a saída segura depois de recuperares o apoio?

Resposta esperada: Estabilizo a prancha, baixo os joelhos um de cada vez e termino sob controlo.

## Fontes e limites da evidência

### Fonte 1: National Strength and Conditioning Association. Plyometric Exercises. Kinetic Select, 2019.

- Autor ou entidade: B1-S04 — National Strength and Conditioning Association. Plyometric Exercises. Kinetic Select, 2019. — https://www.nsca.com/education/articles/kinetic-select/plyometric-exercises/ — organização profissional — Definição do ciclo alongamento-encurtamento, transição rápida e necessidade de dominar o movimento. — A página aborda sobretudo pliometria do membro inferior e não fornece uma técnica específica completa para esta flexão.
- Tipo: organização profissional
- Localizador: https://www.nsca.com/education/articles/kinetic-select/plyometric-exercises/
- Usada para: B1-S04 — National Strength and Conditioning Association. Plyometric Exercises. Kinetic Select, 2019. — https://www.nsca.com/education/articles/kinetic-select/plyometric-exercises/ — organização profissional — Definição do ciclo alongamento-encurtamento, transição rápida e necessidade de dominar o movimento. — A página aborda sobretudo pliometria do membro inferior e não fornece uma técnica específica completa para esta flexão.
- Limite: A página aborda sobretudo pliometria do membro inferior e não fornece uma técnica específica completa para esta flexão.

### Fonte 2: Davies G, Riemann BL, Manske R. Current Concepts of Plyometric Exercise. International Journal of Sports Physical Therapy. 2015;10(6):760-786.

- Autor ou entidade: SP-B2-S19 — Davies G, Riemann BL, Manske R. Current Concepts of Plyometric Exercise. International Journal of Sports Physical Therapy. 2015;10(6):760-786. — https://pmc.ncbi.nlm.nih.gov/articles/PMC4637913/ — revisão científica — Enquadramento das fases pliométricas, exigências de travagem, progressão técnica e segurança. — Revisão ampla; não valida por si só cada instrução específica desta variante.
- Tipo: revisão científica
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC4637913/
- Usada para: SP-B2-S19 — Davies G, Riemann BL, Manske R. Current Concepts of Plyometric Exercise. International Journal of Sports Physical Therapy. 2015;10(6):760-786. — https://pmc.ncbi.nlm.nih.gov/articles/PMC4637913/ — revisão científica — Enquadramento das fases pliométricas, exigências de travagem, progressão técnica e segurança. — Revisão ampla; não valida por si só cada instrução específica desta variante.
- Limite: Revisão ampla; não valida por si só cada instrução específica desta variante.

### Fonte 3: García-Carrillo E et al. Effects of Upper-Body Plyometric Training on Physical Fitness in Healthy Youth and Young Adult Participants: A Systematic Review. Sports. 2023;11(10):195.

- Autor ou entidade: SP-B2-S20 — García-Carrillo E et al. Effects of Upper-Body Plyometric Training on Physical Fitness in Healthy Youth and Young Adult Participants: A Systematic Review. Sports. 2023;11(10):195. — https://pmc.ncbi.nlm.nih.gov/articles/PMC10575843/ — revisão sistemática — Enquadramento da flexão pliométrica dentro da pliometria do membro superior e dos limites da evidência disponível. — Os estudos incluídos são heterogéneos e não estabelecem uma autorização universal nem uma técnica clínica individual.
- Tipo: revisão sistemática
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC10575843/
- Usada para: SP-B2-S20 — García-Carrillo E et al. Effects of Upper-Body Plyometric Training on Physical Fitness in Healthy Youth and Young Adult Participants: A Systematic Review. Sports. 2023;11(10):195. — https://pmc.ncbi.nlm.nih.gov/articles/PMC10575843/ — revisão sistemática — Enquadramento da flexão pliométrica dentro da pliometria do membro superior e dos limites da evidência disponível. — Os estudos incluídos são heterogéneos e não estabelecem uma autorização universal nem uma técnica clínica individual.
- Limite: Os estudos incluídos são heterogéneos e não estabelecem uma autorização universal nem uma técnica clínica individual.

### Fonte 4: Koch J, Riemann BL, Davies GJ. Ground Reaction Force Patterns in Plyometric Push-Ups. Journal of Strength and Conditioning Research. 2012;26(8):2220-2227.

- Autor ou entidade: EX13-S01 — Koch J, Riemann BL, Davies GJ. Ground Reaction Force Patterns in Plyometric Push-Ups. Journal of Strength and Conditioning Research. 2012;26(8):2220-2227. — https://pubmed.ncbi.nlm.nih.gov/21986698/ — estudo biomecânico primário — Confirma que variações pliométricas de flexão produzem forças de reação do solo mensuráveis na projeção e na receção e que a intensidade depende da variante. — Amostra pequena e ativa; comparou flexão com palma e flexões de queda de caixa, não esta entrada canónica isolada.
- Tipo: estudo biomecânico primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/21986698/
- Usada para: EX13-S01 — Koch J, Riemann BL, Davies GJ. Ground Reaction Force Patterns in Plyometric Push-Ups. Journal of Strength and Conditioning Research. 2012;26(8):2220-2227. — https://pubmed.ncbi.nlm.nih.gov/21986698/ — estudo biomecânico primário — Confirma que variações pliométricas de flexão produzem forças de reação do solo mensuráveis na projeção e na receção e que a intensidade depende da variante. — Amostra pequena e ativa; comparou flexão com palma e flexões de queda de caixa, não esta entrada canónica isolada.
- Limite: Amostra pequena e ativa; comparou flexão com palma e flexões de queda de caixa, não esta entrada canónica isolada.

### Fonte 5: Moore LH, Tankovich MJ, Riemann BL, Davies GJ. Kinematic Analysis of Four Plyometric Push-Up Variations. International Journal of Exercise Science. 2012;5(4):334-343.

- Autor ou entidade: EX13-S02 — Moore LH, Tankovich MJ, Riemann BL, Davies GJ. Kinematic Analysis of Four Plyometric Push-Up Variations. International Journal of Exercise Science. 2012;5(4):334-343. — https://pmc.ncbi.nlm.nih.gov/articles/PMC4738879/ — estudo biomecânico primário — Suporta a descrição de projeção, fase aérea e receção e mostra que variantes modificam cinemática e forças. — Participantes recreativamente ativos do sexo masculino e comparação de variantes específicas; generalização limitada para principiantes.
- Tipo: estudo biomecânico primário
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC4738879/
- Usada para: EX13-S02 — Moore LH, Tankovich MJ, Riemann BL, Davies GJ. Kinematic Analysis of Four Plyometric Push-Up Variations. International Journal of Exercise Science. 2012;5(4):334-343. — https://pmc.ncbi.nlm.nih.gov/articles/PMC4738879/ — estudo biomecânico primário — Suporta a descrição de projeção, fase aérea e receção e mostra que variantes modificam cinemática e forças. — Participantes recreativamente ativos do sexo masculino e comparação de variantes específicas; generalização limitada para principiantes.
- Limite: Participantes recreativamente ativos do sexo masculino e comparação de variantes específicas; generalização limitada para principiantes.

### Fonte 6: Cain M. Five Exercises to Help Your Clients Develop Power. American Council on Exercise, 2018.

- Autor ou entidade: EX13-S03 — Cain M. Five Exercises to Help Your Clients Develop Power. American Council on Exercise, 2018. — https://www.acefitness.org/resources/pros/expert-articles/6941/five-exercises-to-help-your-clients-develop-power/ — fonte técnica de organização profissional — Técnica específica: posição de flexão, descida, projeção até as mãos saírem e receção suave com cotovelos ligeiramente fletidos; salienta prévia estabilidade, mobilidade, força e técnica. — Artigo técnico, não ensaio clínico; a sugestão de variantes do artigo não foi transportada para esta identidade.
- Tipo: fonte técnica de organização profissional
- Localizador: https://www.acefitness.org/resources/pros/expert-articles/6941/five-exercises-to-help-your-clients-develop-power/
- Usada para: EX13-S03 — Cain M. Five Exercises to Help Your Clients Develop Power. American Council on Exercise, 2018. — https://www.acefitness.org/resources/pros/expert-articles/6941/five-exercises-to-help-your-clients-develop-power/ — fonte técnica de organização profissional — Técnica específica: posição de flexão, descida, projeção até as mãos saírem e receção suave com cotovelos ligeiramente fletidos; salienta prévia estabilidade, mobilidade, força e técnica. — Artigo técnico, não ensaio clínico; a sugestão de variantes do artigo não foi transportada para esta identidade.
- Limite: Artigo técnico, não ensaio clínico; a sugestão de variantes do artigo não foi transportada para esta identidade.

### Fonte 7: National Strength and Conditioning Association. Strength and Conditioning Professional Standards and Guidelines. Strength and Conditioning Journal. 2017;39(6):1-24.

- Autor ou entidade: EX13-S04 — National Strength and Conditioning Association. Strength and Conditioning Professional Standards and Guidelines. Strength and Conditioning Journal. 2017;39(6):1-24. — https://www.nsca.com/globalassets/education/nsca_strength_and_conditioning_professional_standards_and_guidelines.pdf — norma profissional — Sustenta supervisão adequada, proximidade, visibilidade, instrução de técnica pliométrica e ambiente seguro, sobretudo para principiantes e movimentos complexos. — Norma geral de prática profissional; não é um protocolo específico para esta flexão.
- Tipo: norma profissional
- Localizador: https://www.nsca.com/globalassets/education/nsca_strength_and_conditioning_professional_standards_and_guidelines.pdf
- Usada para: EX13-S04 — National Strength and Conditioning Association. Strength and Conditioning Professional Standards and Guidelines. Strength and Conditioning Journal. 2017;39(6):1-24. — https://www.nsca.com/globalassets/education/nsca_strength_and_conditioning_professional_standards_and_guidelines.pdf — norma profissional — Sustenta supervisão adequada, proximidade, visibilidade, instrução de técnica pliométrica e ambiente seguro, sobretudo para principiantes e movimentos complexos. — Norma geral de prática profissional; não é um protocolo específico para esta flexão.
- Limite: Norma geral de prática profissional; não é um protocolo específico para esta flexão.

### Fonte 8: Polovinets O, Wolf A, Wollstein R. Force Transmission Through the Wrist During Performance of Push-Ups on a Hyperextended and a Neutral Wrist. Journal of Hand Therapy. 2018;31(3):322-330.

- Autor ou entidade: EX13-S05 — Polovinets O, Wolf A, Wollstein R. Force Transmission Through the Wrist During Performance of Push-Ups on a Hyperextended and a Neutral Wrist. Journal of Hand Therapy. 2018;31(3):322-330. — https://pubmed.ncbi.nlm.nih.gov/28684196/ — estudo biomecânico primário — Mostra que a distribuição de forças no punho muda com a sua posição e que pode existir assimetria entre membros; reforça a vigilância de dor e receção simétrica. — Estudou flexões convencionais, não receções pliométricas; não justifica alterar o equipamento ou prescrever uma posição individual do punho.
- Tipo: estudo biomecânico primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/28684196/
- Usada para: EX13-S05 — Polovinets O, Wolf A, Wollstein R. Force Transmission Through the Wrist During Performance of Push-Ups on a Hyperextended and a Neutral Wrist. Journal of Hand Therapy. 2018;31(3):322-330. — https://pubmed.ncbi.nlm.nih.gov/28684196/ — estudo biomecânico primário — Mostra que a distribuição de forças no punho muda com a sua posição e que pode existir assimetria entre membros; reforça a vigilância de dor e receção simétrica. — Estudou flexões convencionais, não receções pliométricas; não justifica alterar o equipamento ou prescrever uma posição individual do punho.
- Limite: Estudou flexões convencionais, não receções pliométricas; não justifica alterar o equipamento ou prescrever uma posição individual do punho.

### Fonte 9: American Council on Exercise. Summer HIIT Workout, 2014.

- Autor ou entidade: EX13-S06 — American Council on Exercise. Summer HIIT Workout, 2014. — https://www.acefitness.org/resources/everyone/blog/4915/summer-hiit-workout/ — fonte técnica de organização profissional — Apoio técnico para inspirar na descida e expirar no empurrão de uma flexão, aplicado aqui sem contagens nem retenção. — A orientação respiratória refere-se à flexão convencional; a aplicação à fase aérea é uma extrapolação prudente, coerente com o registo canónico.
- Tipo: fonte técnica de organização profissional
- Localizador: https://www.acefitness.org/resources/everyone/blog/4915/summer-hiit-workout/
- Usada para: EX13-S06 — American Council on Exercise. Summer HIIT Workout, 2014. — https://www.acefitness.org/resources/everyone/blog/4915/summer-hiit-workout/ — fonte técnica de organização profissional — Apoio técnico para inspirar na descida e expirar no empurrão de uma flexão, aplicado aqui sem contagens nem retenção. — A orientação respiratória refere-se à flexão convencional; a aplicação à fase aérea é uma extrapolação prudente, coerente com o registo canónico.
- Limite: A orientação respiratória refere-se à flexão convencional; a aplicação à fase aérea é uma extrapolação prudente, coerente com o registo canónico.
