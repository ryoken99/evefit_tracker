# Extensão torácica sentada sobre apoio

Conteúdo para principiantes em português europeu.

## Descrição curta

Sentado numa cadeira estável, inclinas suavemente a parte superior do tronco para trás sobre um apoio colocado na região torácica, mantendo a região lombar e a cabeça controladas.

## O que é

É um pequeno movimento de extensão da região média e superior das costas sobre um rolo que fica estável entre o tronco e um encosto compatível. A pessoa permanece sentada, com pés e bacia apoiados e cabeça sustentada pelas mãos.

## O que vais fazer

Vais sentar-te numa cadeira sem rodas, colocar um rolo de toalha firme ou um rolo de espuma entre a região torácica e o encosto, apoiar a cabeça com as mãos, inclinar a parte superior do tronco para trás sobre o ponto de apoio e regressar à posição sentada neutra com controlo.

## Porque existe este movimento

A ação existe para explorar a extensão da coluna torácica com um apoio externo localizado. O objetivo documental imediato é mover a região torácica sem transformar o gesto num arco predominante da região lombar ou numa inclinação forçada do pescoço; não é feita qualquer promessa de resultado individual.

## Antes de começares

1. Confirma que tens uma cadeira estável, sem rodas, com encosto capaz de manter um rolo horizontal sem o deixar escapar.
2. Usa um rolo de toalha firme ou um rolo de espuma sem arestas, colocado no piso de forma segura antes da montagem.
3. Na primeira montagem, pede demonstração a uma pessoa qualificada para identificar a zona média ou superior das costas, afastada do pescoço e da região lombar.
4. Confirma que o rolo fica imóvel sob pressão ligeira e que não existe espaço perigoso atrás da cadeira.
5. Não executes autonomamente se não conseguires identificar a zona demonstrada ou manter todos os apoios.

## Preparar o equipamento

1. Usa uma cadeira imóvel, sem rodas, com encosto largo e firme que mantenha o rolo no lugar.
2. Escolhe um único rolo compatível, sem arestas e que não escorregue.
3. Depois de uma demonstração inicial, coloca o rolo horizontalmente na zona média ou superior das costas que foi identificada, claramente abaixo do pescoço e acima da região lombar.
4. Faz pressão ligeira antes de te inclinares; se o rolo subir, descer, rodar ou escapar, não executes.
5. Não coloques o rolo no pescoço, na cabeça ou na região lombar.

## Preparar o espaço

1. Usa uma área pequena mas desimpedida, com piso firme, nivelado e antiderrapante sob toda a cadeira.
2. Mantém livre a trajetória atrás da cadeira e afasta a cadeira de degraus, desníveis e objetos contra os quais possas embater.
3. Assegura espaço suficiente para os cotovelos e para o pequeno arco posterior do tronco.
4. Não uses assentos instáveis ou com rodas, nem um ponto de apoio afiado, deformado ou escorregadio.

## Verificação do corpo

1. Consegues sentar-te com ambos os pés firmemente apoiados e sem sensação de queda?
2. Consegues apoiar a cabeça com as mãos sem puxar o pescoço?
3. Consegues manter a bacia estável enquanto moves sobretudo a região média e superior das costas?
4. Ao testar apenas o início do gesto, não surgem dor aguda, bloqueio, tontura, mal-estar, sintomas irradiados ou perda de controlo?
5. Se tens cirurgia recente, sintomas persistentes, instabilidade conhecida ou estás em retorno à função, a adequação deve ser revista por um profissional qualificado antes de usares este conteúdo.

## Posição inicial

Senta-te com a bacia apoiada e ambos os pés firmes. Mantém o rolo horizontal e imóvel na zona torácica demonstrada. Sustenta a cabeça com as mãos sem a puxar e mantém a região lombar confortável. Se não conseguires confirmar estes critérios, não inicies.

## Confirmar a posição inicial

1. Cadeira imóvel e sem rodas.
2. Piso firme, nivelado e antiderrapante.
3. Ambos os pés totalmente apoiados.
4. ponto de apoio estável na região torácica, não na região lombar nem no pescoço.
5. Bacia estável no assento.
6. Cabeça sustentada pelas mãos, sem tração.
7. Espaço atrás da cadeira livre de obstáculos e desníveis.

## Passos de execução

1. Senta-te com ambos os pés firmes e confirma que a cadeira e o ponto de apoio não se deslocam quando encostas suavemente as costas.
2. Posiciona o ponto de apoio na horizontal sobre a região média ou superior das costas, abaixo do pescoço e acima da região lombar.
3. Coloca as mãos atrás da cabeça para a sustentar, aproxima ligeiramente os cotovelos e mantém o pescoço comprido, sem puxar a cabeça.
4. Mantém a bacia assente, os pés no chão e as costelas controladas; inicia um pequeno arco para trás a partir da região torácica que está sobre o ponto de apoio.
5. Inclina a parte superior do tronco suavemente sobre o apoio apenas até à amplitude que continua confortável, estável e controlada.
6. Mantém a cabeça apoiada pelas mãos e a respiração natural e contínua; evita deixar o queixo subir, abrir excessivamente as costelas ou arquear sobretudo a região lombar.
7. Regressa à posição sentada neutra de forma controlada, mantendo os pés, a bacia e o ponto de apoio estáveis até terminares o arco.

## Fases do movimento

### Preparação

Organiza os três contactos de suporte — pés, cadeira e ponto de apoio torácico — e sustenta a cabeça sem tração.

### Extensão apoiada

A parte superior do tronco descreve um pequeno arco posterior sobre o ponto de apoio; a amplitude termina antes de aparecer compensação lombar, desconforto ou perda de apoio.

### Regresso

O tronco volta à posição sentada neutra com controlo, sem impulso e sem deixar a cabeça cair para a frente.

## Respiração

Respira de forma natural, regular e contínua durante todo o movimento. Não sincronizes deliberadamente a respiração com uma fase, não imponhas contagens e não prendas o ar.

## Sensações esperadas

1. Pressão localizada e tolerável do ponto de apoio na região média ou superior das costas.
2. Sensação suave de abertura na parte anterior do tronco.
3. Movimento ou esforço leve na região torácica ao inclinar e regressar.
4. Sensação de controlo dos pés, da bacia e da região lombar.

## Sensações inesperadas ou de alerta

1. Dor aguda ou crescente.
2. Sensação de bloqueio articular.
3. Dor, formigueiro ou outra sensação que irradia para o peito, braços ou pernas.
4. Tontura, mal-estar ou alteração incomum da respiração.
5. Perda súbita de controlo, deslizamento da cadeira ou deslocação do ponto de apoio.
6. Dor predominante no pescoço ou na região lombar.

## Indicações técnicas principais

1. Pés firmes, cadeira imóvel.
2. ponto de apoio na região torácica, não na lombar.
3. Sustenta a cabeça; não puxes o pescoço.
4. Move a parte superior das costas sobre o apoio.
5. Costelas controladas e bacia estável.
6. Vai apenas até onde manténs conforto e controlo.
7. Respira sem prender.

## Erros comuns e correções

### Erro 1: Colocar o ponto de apoio demasiado baixo, sobre a região lombar.

- Como reconhecer: A pressão do rolo é sentida abaixo da caixa torácica e o arco aparece sobretudo na zona inferior das costas.
- Como corrigir: Regressa à posição neutra e reposiciona o ponto de apoio mais acima, na região média ou superior das costas.

### Erro 2: Usar uma cadeira, um piso ou um ponto de apoio instável.

- Como reconhecer: A cadeira oscila ou desliza, ou o ponto de apoio roda e muda de posição quando encostas o tronco.
- Como corrigir: Interrompe e estabiliza o conjunto num piso firme, nivelado e antiderrapante; usa uma cadeira sem rodas e um ponto de apoio firme.

### Erro 3: Arquear sobretudo a região lombar e projetar as costelas para a frente.

- Como reconhecer: A bacia inclina-se, o abdómen avança e quase não há movimento à volta do ponto de apoio torácico.
- Como corrigir: Reduz o arco, mantém a bacia assente e orienta o movimento para a região das costas que está em contacto com o ponto de apoio.

### Erro 4: Puxar a cabeça com as mãos ou inclinar excessivamente o pescoço.

- Como reconhecer: O queixo sobe, aparece pressão das mãos na cabeça ou sentes o movimento sobretudo no pescoço.
- Como corrigir: Usa as mãos apenas como suporte, mantém o pescoço comprido e reduz a amplitude.

### Erro 5: Forçar a amplitude ou deixar o tronco cair para trás.

- Como reconhecer: O movimento acelera, surge um fim de amplitude brusco ou torna-se difícil regressar sem impulso.
- Como corrigir: Usa um arco menor e mantém a mesma velocidade controlada na inclinação e no regresso.

### Erro 6: Deixar os pés perderem contacto ou a bacia deslizar.

- Como reconhecer: Os calcanhares levantam, o peso muda de lado ou o corpo escorrega no assento.
- Como corrigir: Regressa à posição inicial, reafirma ambos os pés no chão e mantém a bacia apoiada.

### Erro 7: Prender a respiração.

- Como reconhecer: Notas tensão facial, esforço desnecessário ou ausência de fluxo respiratório durante o arco.
- Como corrigir: Reduz a amplitude e retoma uma respiração natural e contínua antes de continuares.

## Formas de simplificar ou ensaiar

1. Escolhe o rolo de toalha firme quando este permitir um contacto mais baixo e previsível do que o rolo de espuma.
2. Começa por um arco pequeno, suficiente para aprender a localizar o movimento na região torácica sem perder os contactos de apoio.
3. Reposiciona o ponto de apoio antes de cada tentativa se este se deslocar; não compenses procurando o apoio com a região lombar.
4. Pede observação a um profissional qualificado se não conseguires distinguir movimento torácico de compensação lombar ou cervical.

## Supervisão

A primeira montagem exige demonstração e supervisão qualificada para identificar a zona torácica, testar cadeira, encosto e rolo e distinguir o pequeno arco torácico de compensação no pescoço ou na região lombar. Só é autónomo depois de estes critérios serem compreendidos e reproduzidos sem deslocação do apoio.

## Como terminar

Regressa primeiro à posição sentada neutra, sem impulso. Confirma que ambos os pés e a bacia estão estáveis. Baixa os braços e deixa de sustentar a cabeça apenas quando o tronco estiver vertical e controlado. Retira ou desloca o ponto de apoio apenas depois de estares estável. Se interrompeste por um sinal de alerta, não reinicies automaticamente; procura orientação adequada ao contexto.

## Nota de segurança

Exercício de risco operacional moderado. Usa apenas uma cadeira estável sem rodas e um rolo de toalha firme ou rolo de espuma num piso firme, nivelado e antiderrapante. Mantém o ponto de apoio na região torácica, não forces a amplitude e evita puxar o pescoço ou arquear sobretudo a região lombar. Pára perante dor aguda, bloqueio, perda súbita de controlo, tontura, mal-estar ou sintomas irradiados.

## Quando parar ou reduzir

1. Pressão tolerável mas controlo técnico a diminuir. — Reduz a amplitude e regressa à posição neutra.
2. Dor aguda, bloqueio articular, sintomas irradiados, tontura ou mal-estar. — Pára o movimento de forma controlada e procura orientação adequada ao contexto.
3. Perda súbita de controlo ou deslocação da cadeira ou do ponto de apoio. — Interrompe, estabiliza-te e não retomes até o equipamento e o ambiente estarem novamente seguros.
4. Dor predominante no pescoço ou na região lombar. — Regressa à posição neutra, revê o posicionamento do ponto de apoio e a amplitude; pede supervisão se não conseguires corrigir.

## Segurança do equipamento

A cadeira tem de ser estável e não pode ter rodas. O ponto de apoio tem de ser um rolo de toalha firme ou um rolo de espuma estável. O encosto deve impedir que o ponto de apoio caia ou deslize durante o arco. Não uses um ponto de apoio afiado, excessivamente rígido, danificado ou instável. Testa o conjunto com pressão leve antes de deslocares o tronco para trás.

## Segurança do espaço

O piso sob a cadeira tem de ser firme, nivelado e antiderrapante. A área atrás da cadeira deve permitir a extensão controlada e permanecer livre de obstáculos. Não coloques a cadeira junto de um degrau, desnível ou outro perigo. Mantém espaço lateral suficiente para as mãos e os cotovelos sem contacto com paredes ou objetos. Interrompe se a cadeira começar a deslocar-se na superfície.

## Limitações

1. A evidência disponível sustenta sobretudo a família de exercícios e a execução clínica; não demonstra eficácia universal desta variante.
2. O estudo primário consultado analisou uma extensão torácica sentada diferente, sem o mesmo ponto de apoio, e não mediu a cinemática da coluna.
3. Não foram definidos dose, progressão, amplitude individual nem critérios clínicos personalizados.
4. A adequação para cirurgia recente, sintomas persistentes, instabilidade conhecida ou retorno à função exige revisão individual.
5. A aprovação é documental; os meios visuais continuam por aprovar.
6. Implementação realizada: não.

## Teste de compreensão

### 1. Que tipo de cadeira deves usar?

Resposta esperada: Uma cadeira estável e sem rodas.

### 2. Que opções de ponto de apoio são compatíveis?

Resposta esperada: Um rolo de toalha firme ou um rolo de espuma.

### 3. Onde deve ficar o ponto de apoio?

Resposta esperada: Na horizontal, na região média ou superior das costas, abaixo do pescoço e acima da região lombar.

### 4. Onde não deves colocar o ponto de apoio?

Resposta esperada: No pescoço, na cabeça ou na região lombar.

### 5. O que devem fazer os pés durante o movimento?

Resposta esperada: Permanecer firmemente apoiados no chão.

### 6. Para que servem as mãos atrás da cabeça?

Resposta esperada: Para sustentar a cabeça, sem puxar o pescoço.

### 7. Que região deve produzir principalmente o arco para trás?

Resposta esperada: A região torácica, à volta do ponto de apoio.

### 8. Como sabes que a amplitude é excessiva?

Resposta esperada: Quando perdes o conforto, o controlo, os apoios ou começas a compensar com a região lombar ou o pescoço.

### 9. Como deves respirar?

Resposta esperada: De forma natural, regular e contínua, sem prender nem forçar a respiração.

### 10. Que características deve ter o piso?

Resposta esperada: Deve ser firme, nivelado e antiderrapante.

### 11. Que sinais exigem que pares?

Resposta esperada: Dor aguda, bloqueio, perda súbita de controlo, tontura, mal-estar ou sintomas irradiados.

### 12. Quando é aconselhável pedir supervisão?

Resposta esperada: Quando há medo de queda, dificuldade em manter os apoios, sintomas durante a amplitude ou dificuldade em distinguir o movimento torácico das compensações.

## Fontes e limites da evidência

### Fonte 1: Heneghan NR, Lokhaug SM, Tyros I, Longvastøl S, Rushton A. Clinical reasoning framework for thoracic spine exercise prescription in sport: a systematic review and narrative synthesis. BMJ Open Sport & Exercise Medicine. 2020;6:e000713.

- Autor ou entidade: C1-S13 — Heneghan NR, Lokhaug SM, Tyros I, Longvastøl S, Rushton A. Clinical reasoning framework for thoracic spine exercise prescription in sport: a systematic review and narrative synthesis. BMJ Open Sport & Exercise Medicine. 2020;6:e000713. — https://doi.org/10.1136/bmjsem-2019-000713 — revisão sistemática e síntese narrativa — Enquadramento da extensão torácica como família de mobilidade e separação entre técnica e eficácia. — A evidência global foi classificada pelos autores como baixa e não valida a eficácia universal deste exercício concreto.
- Tipo: revisão sistemática e síntese narrativa
- Localizador: https://doi.org/10.1136/bmjsem-2019-000713
- Usada para: Enquadramento da extensão torácica como família de mobilidade e separação entre técnica e eficácia.
- Limite: A evidência global foi classificada pelos autores como baixa e não valida a eficácia universal deste exercício concreto.

### Fonte 2: Cornell University Physical Therapy. Thoracic Extension Mobilization Seated with Towel Roll.

- Autor ou entidade: C2-S07 — Cornell University Physical Therapy. Thoracic Extension Mobilization Seated with Towel Roll. — https://www.cornell.edu/video/thoracic-extension-mobilization-seat-towel-roll — recurso clínico universitário em vídeo — Confirmação da ação sentada de extensão torácica e da relação com cadeira e rolo de toalha. — Recurso demonstrativo, sem comparação de eficácia; o texto integral do vídeo não estava acessível nesta sessão.
- Tipo: recurso clínico universitário em vídeo
- Localizador: https://www.cornell.edu/video/thoracic-extension-mobilization-seat-towel-roll
- Usada para: Confirmação da ação sentada de extensão torácica e da relação com cadeira e rolo de toalha.
- Limite: Recurso demonstrativo, sem comparação de eficácia; o texto integral do vídeo não estava acessível nesta sessão.

### Fonte 3: Heneghan NR, Lokhaug SM, Tyros I, Longvastøl S, Rushton A. Clinical reasoning framework for thoracic spine exercise prescription in sport. 2020.

- Autor ou entidade: C2-S09 — Heneghan NR, Lokhaug SM, Tyros I, Longvastøl S, Rushton A. Clinical reasoning framework for thoracic spine exercise prescription in sport. 2020. — https://pubmed.ncbi.nlm.nih.gov/32341799/ — registo PubMed de revisão sistemática — Confirmação bibliográfica e dos limites da evidência por família. — Não fornece uma técnica única nem uma dose aplicável a todas as pessoas.
- Tipo: registo PubMed de revisão sistemática
- Localizador: https://pubmed.ncbi.nlm.nih.gov/32341799/
- Usada para: Confirmação bibliográfica e dos limites da evidência por família.
- Limite: Não fornece uma técnica única nem uma dose aplicável a todas as pessoas.

### Fonte 4: Cambridge University Hospitals NHS Foundation Trust. Thoracic spine exercises. Physiotherapy (Outpatient), versão 4, aprovada em 16 de julho de 2024.

- Autor ou entidade: EX24-S01 — Cambridge University Hospitals NHS Foundation Trust. Thoracic spine exercises. Physiotherapy (Outpatient), versão 4, aprovada em 16 de julho de 2024. — https://www.cuh.nhs.uk/patient-information/thoracic-spine-exercises/ — orientação clínica oficial — Pés firmes, cadeira com encosto, inclinação suave sobre o encosto e recomendação de procurar orientação se o exercício for doloroso. — A descrição usa o encosto como ponto de apoio e não pormenoriza todas as compensações ou a respiração.
- Tipo: orientação clínica oficial
- Localizador: https://www.cuh.nhs.uk/patient-information/thoracic-spine-exercises/
- Usada para: Pés firmes, cadeira com encosto, inclinação suave sobre o encosto e recomendação de procurar orientação se o exercício for doloroso.
- Limite: A descrição usa o encosto como ponto de apoio e não pormenoriza todas as compensações ou a respiração.

### Fonte 5: Tyneside Integrated Musculoskeletal Service. Managing Thoracic Back Pain. Informação de fisioterapia.

- Autor ou entidade: EX24-S02 — Tyneside Integrated Musculoskeletal Service. Managing Thoracic Back Pain. Informação de fisioterapia. — https://www.tims.nhs.uk/wp-content/uploads/2024/08/TIMS-Managing-Thoracic-Back-Pain-July-2024.pdf — folheto clínico oficial — Suporte do pescoço com as mãos, extensão sobre o topo do encosto e foco na região torácica em vez do pescoço; respiração regular em movimentos torácicos. — O documento é dirigido a um contexto clínico específico e inclui prescrições que não foram transpostas.
- Tipo: folheto clínico oficial
- Localizador: https://www.tims.nhs.uk/wp-content/uploads/2024/08/TIMS-Managing-Thoracic-Back-Pain-July-2024.pdf
- Usada para: Suporte do pescoço com as mãos, extensão sobre o topo do encosto e foco na região torácica em vez do pescoço; respiração regular em movimentos torácicos.
- Limite: O documento é dirigido a um contexto clínico específico e inclui prescrições que não foram transpostas.

### Fonte 6: Ha S-M, Jung S-H, Kim J-H, Gwak G-T. Selective Activation of Thoracic Extensor Muscles during 3 Different Trunk Extensor Strengthening Exercise. Journal of Musculoskeletal Science and Technology. 2017;1(1):31-35.

- Autor ou entidade: EX24-S03 — Ha S-M, Jung S-H, Kim J-H, Gwak G-T. Selective Activation of Thoracic Extensor Muscles during 3 Different Trunk Extensor Strengthening Exercise. Journal of Musculoskeletal Science and Technology. 2017;1(1):31-35. — https://doi.org/10.29273/jkema.2017.1.1.31 — estudo primário comparativo com eletromiografia — Apoio para distinguir extensão torácica sentada de compensação extensora lombar e para valorizar o suporte e o controlo segmentar. — A variante estudada usou apoio dos braços numa mesa, incluiu apenas adultos jovens saudáveis e não mediu cinemática; não prova eficácia ou segurança da variante com ponto de apoio.
- Tipo: estudo primário comparativo com eletromiografia
- Localizador: https://doi.org/10.29273/jkema.2017.1.1.31
- Usada para: Apoio para distinguir extensão torácica sentada de compensação extensora lombar e para valorizar o suporte e o controlo segmentar.
- Limite: A variante estudada usou apoio dos braços numa mesa, incluiu apenas adultos jovens saudáveis e não mediu cinemática; não prova eficácia ou segurança da variante com ponto de apoio.

### Fonte 7: American College of Sports Medicine. Exercising Your Way to Lowering Your Blood Pressure.

- Autor ou entidade: EX24-S04 — American College of Sports Medicine. Exercising Your Way to Lowering Your Blood Pressure. — https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf — orientação profissional oficial — Fundamentação geral para manter respiração regular durante a atividade e evitar a retenção. — Orientação geral de exercício, não específica para extensão torácica sentada.
- Tipo: orientação profissional oficial
- Localizador: https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf
- Usada para: Fundamentação geral para manter respiração regular durante a atividade e evitar a retenção.
- Limite: Orientação geral de exercício, não específica para extensão torácica sentada.
