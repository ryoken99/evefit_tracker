# Deslizamento do calcanhar em decúbito dorsal

Conteúdo para principiantes em português europeu.

## Descrição curta

Deitado de costas, deslizas um calcanhar pela superfície em direção à pelve e voltas a estender a perna, sem levantar o pé.

## O que é

É uma transição apoiada do membro inferior: a anca e o joelho dobram enquanto o calcanhar desliza, e depois estendem quando o calcanhar regressa. O tronco permanece apoiado e não há deslocamento global do corpo.

## O que vais fazer

Vais começar deitado de costas, com a perna-alvo estendida. Mantendo o calcanhar em contacto com a superfície, vais aproximá-lo da pelve com controlo e fazê-lo regressar pelo mesmo trajeto até a perna ficar novamente estendida.

## Porque existe este movimento

Este movimento existe para praticar uma transição apoiada entre amplitudes da anca e do joelho. Não é uma elevação da perna e não inclui puxar o membro com as mãos.

## Antes de começares

1. Confirma que compreendes a ação, que consegues controlar voluntariamente a perna numa amplitude tolerada e que tens apoio suficiente para ficar deitado de costas. Se tens cirurgia recente, estás em retorno à função, tens sintomas persistentes ou instabilidade conhecida, segue a orientação do profissional que acompanha o teu caso antes de usar este conteúdo.

## Preparar o equipamento

1. Não é obrigatório equipamento portátil. Podes usar um tapete de exercício e, se necessário, um deslizador de baixa fricção sob o calcanhar, desde que o pé não ganhe velocidade nem escape ao teu controlo. Não uses as mãos, uma faixa ou outra pessoa para puxar a perna, porque isso alteraria a forma aqui descrita.

## Preparar o espaço

1. Escolhe uma superfície firme, nivelada e confortável para ficar deitado, que permita ao calcanhar deslizar de forma controlada. Mantém a pequena área à volta do corpo desimpedida. O local pode ser interior ou exterior se cumprir estas condições; não uses uma superfície irregular, aquática ou tão escorregadia que o calcanhar fuja.

## Verificação do corpo

1. Antes de iniciares, verifica se consegues deitar-te e levantar-te da superfície com segurança, manter o tronco apoiado, mover a anca e o joelho sem dor aguda nem bloqueio e controlar o calcanhar. Se já sentes tontura, mal-estar ou perda de controlo, não inicies.

## Posição inicial

Deita-te de costas numa superfície firme e nivelada. Mantém a perna-alvo estendida e apoiada pelo calcanhar; deixa a outra perna confortavelmente apoiada na superfície. Mantém a cabeça e o tronco confortáveis, a pelve voltada para cima e os braços relaxados ao lado do corpo.

## Confirmar a posição inicial

1. Estou deitado de costas numa superfície firme e nivelada.
2. Tenho espaço livre à volta do corpo e do pé que vai deslizar.
3. A perna-alvo começa estendida e o calcanhar toca na superfície.
4. A outra perna e o tronco estão apoiados.
5. A pelve está estável e voltada para cima.
6. Consigo respirar de forma natural e sem prender a respiração.

## Passos de execução

1. Mantém o tronco, a pelve e a outra perna apoiados, sem fazer força desnecessária com os ombros ou as mãos.
2. Inicia o movimento arrastando suavemente o calcanhar da perna-alvo pela superfície em direção à pelve.
3. Deixa a anca e o joelho dobrarem em conjunto enquanto o pé continua apoiado; não levantes o calcanhar.
4. Mantém o joelho orientado para cima, alinhado com o pé, e evita que a pelve rode ou que o tronco se torça.
5. Termina a aproximação quando atingires uma amplitude tolerada que ainda consigas controlar, antes de aparecer dor aguda, bloqueio ou compensação.
6. Inverte o trajeto e desliza o calcanhar para longe da pelve, estendendo gradualmente o joelho e a anca.
7. Conclui com a perna novamente estendida e apoiada, sem deixar o calcanhar disparar nem bater na superfície.

## Fases do movimento

### Tronco e pelve apoiados; perna-alvo estendida; calcanhar em contacto.

Tronco e pelve apoiados; perna-alvo estendida; calcanhar em contacto.

### O calcanhar desliza em direção à pelve enquanto a anca e o joelho dobram.

O calcanhar desliza em direção à pelve enquanto a anca e o joelho dobram.

### A aproximação termina dentro da amplitude tolerada, sem forçar nem alterar o alinhamento.

A aproximação termina dentro da amplitude tolerada, sem forçar nem alterar o alinhamento.

### O calcanhar percorre o trajeto inverso enquanto a anca e o joelho estendem.

O calcanhar percorre o trajeto inverso enquanto a anca e o joelho estendem.

### A perna volta a ficar estendida e apoiada, com o corpo no mesmo local.

A perna volta a ficar estendida e apoiada, com o corpo no mesmo local.

## Respiração

Respira de forma natural, tranquila e contínua durante todo o movimento. Não existe base suficiente para impor uma fase respiratória única a esta identidade; não prendas a respiração nem uses contagens ou retenções.

## Sensações esperadas

1. Movimento suave na anca e no joelho da perna que desliza.
2. Contacto contínuo do calcanhar com a superfície.
3. Tensão ligeira e tolerável à medida que o joelho dobra, sem necessidade de forçar.
4. Tronco e pelve estáveis enquanto guias a perna.

## Sensações inesperadas ou de alerta

1. Dor aguda.
2. Sensação de bloqueio articular.
3. Perda súbita de controlo da perna ou do calcanhar.
4. Tontura ou mal-estar.
5. Sintomas que obrigam a torcer o tronco, rodar a pelve ou abandonar o apoio previsto.

## Indicações técnicas principais

1. Calcanhar sempre apoiado.
2. Desliza em direção à pelve com controlo.
3. Joelho orientado para cima e alinhado com o pé.
4. Pelve quieta e tronco apoiado.
5. Vai apenas até onde manténs controlo e tolerância.
6. Respira naturalmente, sem prender.

## Erros comuns e correções

### Erro 1: Levantar o calcanhar ou o pé da superfície.

- Como reconhecer: Vês espaço entre o calcanhar e o apoio ou sentes que a perna está a ser elevada.
- Como corrigir: Mantém uma pressão leve do calcanhar sobre a superfície e encurta a amplitude se o contacto se perder.

### Erro 2: Deixar a pelve rodar ou o tronco torcer.

- Como reconhecer: Uma anca levanta, a cintura muda de apoio ou os ombros deixam de apontar para cima.
- Como corrigir: Reduz a amplitude e mantém os dois lados da pelve apoiados enquanto o calcanhar se move.

### Erro 3: Deixar o joelho cair para dentro ou afastar-se excessivamente para fora.

- Como reconhecer: O joelho deixa de acompanhar a direção do pé e já não aponta aproximadamente para cima.
- Como corrigir: Guia o joelho na mesma linha do pé e termina antes do ponto em que o alinhamento se perde.

### Erro 4: Deixar o calcanhar escorregar depressa ou sem travagem.

- Como reconhecer: O pé ganha velocidade, salta no trajeto ou bate no fim.
- Como corrigir: Usa uma superfície com fricção compatível e conduz tanto a aproximação como o regresso de forma suave.

### Erro 5: Forçar a amplitude.

- Como reconhecer: Aparecem dor aguda, bloqueio, perda de alinhamento ou necessidade de puxar a perna com as mãos.
- Como corrigir: Interrompe antes desse ponto e mantém apenas a amplitude que consegues controlar e tolerar.

### Erro 6: Prender a respiração.

- Como reconhecer: Ficas com a garganta fechada, fazes pressão ou deixas de respirar durante o deslizamento.
- Como corrigir: Abranda ou pausa numa posição apoiada e retoma apenas com respiração natural e contínua.

## Formas de simplificar ou ensaiar

1. Usa uma amplitude menor, mantendo a identidade do deslizamento apoiado.
2. Coloca as mãos sobre os lados da pelve apenas para sentir se ela roda, sem puxar a perna.
3. Se houver fricção excessiva, usa o deslizador opcional de baixa fricção sob o calcanhar, confirmando primeiro que consegues travá-lo.
4. Pede a um profissional para demonstrar e observar a primeira execução se tens dificuldade em distinguir o movimento-alvo de uma compensação.

## Supervisão

O exercício tem risco operacional base baixo, não exige observador nem supervisão por regra. Procura supervisão quando não consegues manter o apoio previsto, tens medo de cair ao posicionar-te, sentes sintomas durante a amplitude ou não distingues o movimento do calcanhar da rotação da pelve. Cirurgia recente, retorno à função, sintomas persistentes ou instabilidade conhecida exigem revisão própria; as instruções pós-operatórias das fontes não são autorização geral.

## Como terminar

Para terminar, desliza o calcanhar até a perna ficar novamente estendida e apoiada, deixa a musculatura relaxar e confirma que te sentes estável. Levanta-te da superfície apenas quando não houver tontura, mal-estar ou perda de controlo e usando a forma que já consegues executar com segurança.

## Nota de segurança

Mantém o calcanhar sob controlo numa superfície compatível e não forces a amplitude. Interrompe perante dor aguda, bloqueio articular, perda súbita de controlo, tontura ou mal-estar. Este conteúdo descreve técnica geral e não substitui instruções clínicas individuais.

## Quando parar ou reduzir

1. Dor aguda. — Interrompe o movimento.
2. Bloqueio articular. — Interrompe sem tentar vencer o bloqueio.
3. Perda súbita de controlo. — Termina o movimento numa posição apoiada e segura.
4. Tontura ou mal-estar. — Pára e mantém-te apoiado; procura ajuda adequada se não resolver.
5. Rotação da pelve, torção do tronco ou perda do contacto do calcanhar. — Reduz a amplitude; se não recuperares o controlo, termina.

## Segurança do equipamento

Não há equipamento obrigatório. Um tapete de exercício é opcional e deve ficar plano e estável. Um deslizador de baixa fricção é opcional e só deve ser usado se permitir controlar e travar o calcanhar; remove-o se aumentar o risco de escorregar. Não acrescentes assistência manual, carga ou acessórios que alterem a relação entre o calcanhar e a superfície.

## Segurança do espaço

Usa uma superfície firme, nivelada e segura para decúbito dorsal, com fricção suficiente para controlar o calcanhar e espaço desimpedido. Evita superfícies irregulares, apoios que cedam, zonas com obstáculos e qualquer superfície que provoque deslizamento descontrolado.

## Limitações

1. Conteúdo documental geral para principiantes; não define dose, não prescreve amplitude individual, não promete resultados, não diagnostica nem trata. Grande parte da orientação oficial disponível provém de contextos pós-operatórios ou de variantes orientadas ao tronco, que foram usados apenas nos elementos compatíveis com a identidade canónica. As três relações aprovadas, o risco operacional baixo, os requisitos de superfície, o equipamento opcional e os gatilhos de supervisão foram preservados sem alteração. Implementação realizada: não
2. Não foi identificada evidência direta suficiente para impor inspiração ou expiração numa fase específica deste exercício.
3. As fontes não sustentam um limite universal de amplitude; mantém-se o critério de tolerância e controlo.

## Teste de compreensão

### 1. Em que posição começa o exercício?

Resposta esperada: Em que posição começa o exercício?

### 2. Como começa a perna-alvo?

Resposta esperada: Como começa a perna-alvo?

### 3. O que deve acontecer ao calcanhar durante o movimento?

Resposta esperada: O que deve acontecer ao calcanhar durante o movimento?

### 4. Para onde desliza primeiro o calcanhar?

Resposta esperada: Para onde desliza primeiro o calcanhar?

### 5. Como deve ficar o joelho durante a aproximação?

Resposta esperada: Como deve ficar o joelho durante a aproximação?

### 6. O que fazes se a pelve começar a rodar?

Resposta esperada: O que fazes se a pelve começar a rodar?

### 7. Qual é a orientação respiratória?

Resposta esperada: Qual é a orientação respiratória?

### 8. Até onde aproximas o calcanhar?

Resposta esperada: Até onde aproximas o calcanhar?

### 9. Que sinal obriga a interromper?

Resposta esperada: Que sinal obriga a interromper?

### 10. Que superfície é adequada?

Resposta esperada: Que superfície é adequada?

### 11. É obrigatório usar equipamento?

Resposta esperada: É obrigatório usar equipamento?

### 12. Quando faz sentido pedir supervisão?

Resposta esperada: Quando faz sentido pedir supervisão?

## Fontes e limites da evidência

### Fonte 1: Early knee exercises

- Autor ou entidade: Cambridge University Hospitals NHS Foundation Trust
- Tipo: guia oficial de fisioterapia hospitalar
- Localizador: https://www.cuh.nhs.uk/patient-information/early-knee-exercises/
- Usada para: Posição deitado de costas, flexão do joelho com o calcanhar junto da cama, conforto e procura de orientação quando o exercício é doloroso.
- Limite: C2-S25 — Early knee exercises — Cambridge University Hospitals NHS Foundation Trust — guia oficial de fisioterapia hospitalar — https://www.cuh.nhs.uk/patient-information/early-knee-exercises/ — Posição deitado de costas, flexão do joelho com o calcanhar junto da cama, conforto e procura de orientação quando o exercício é doloroso. — Contexto clínico inicial do joelho; não foi transposta qualquer dose nem progressão.

### Fonte 2: Total Hip Replacement Exercise Guide

- Autor ou entidade: American Academy of Orthopaedic Surgeons
- Tipo: guia profissional oficial revisto por pares
- Localizador: https://orthoinfo.aaos.org/en/recovery/total-hip-replacement-exercise-guide/
- Usada para: Deslizamento do pé em direção às nádegas, calcanhar em contacto, extensão no regresso e prevenção do colapso do joelho para dentro.
- Limite: C2-S28 — Total Hip Replacement Exercise Guide — American Academy of Orthopaedic Surgeons — guia profissional oficial revisto por pares — https://orthoinfo.aaos.org/en/recovery/total-hip-replacement-exercise-guide/ — Deslizamento do pé em direção às nádegas, calcanhar em contacto, extensão no regresso e prevenção do colapso do joelho para dentro. — Contexto pós-operatório; instruções de dose, retenção e resultados não foram generalizadas.

### Fonte 3: Lower Back Strengthening Exercises

- Autor ou entidade: University Hospitals Plymouth NHS Trust
- Tipo: folheto oficial de fisioterapia hospitalar
- Localizador: https://www.plymouthhospitals.nhs.uk/display-pil/pil-lower-back-strengthening-exercises-4042/
- Usada para: Contacto do calcanhar, estabilidade da pelve e coluna neutra, e manutenção de um padrão respiratório relaxado.
- Limite: EX23-S01 — Lower Back Strengthening Exercises — University Hospitals Plymouth NHS Trust — folheto oficial de fisioterapia hospitalar — https://www.plymouthhospitals.nhs.uk/display-pil/pil-lower-back-strengthening-exercises-4042/ — Contacto do calcanhar, estabilidade da pelve e coluna neutra, e manutenção de um padrão respiratório relaxado. — Descreve uma variante que começa com o joelho dobrado e desliza o calcanhar para longe, com objetivo do tronco; só foram transferidos princípios compatíveis, não a identidade da variante.

### Fonte 4: Rehabilitation exercise assessment using inertial sensors: a cross-sectional analytical study

- Autor ou entidade: Giggins, Sweeney e Caulfield; Journal of NeuroEngineering and Rehabilitation
- Tipo: literatura primária, estudo analítico transversal
- Localizador: https://doi.org/10.1186/1743-0003-11-158
- Usada para: Confirma o uso do heel slide em decúbito dorsal e a relevância de alinhamento, velocidade e qualidade; os participantes receberam instrução padronizada, demonstração e ensaio observado.
- Limite: EX23-S02 — Rehabilitation exercise assessment using inertial sensors: a cross-sectional analytical study — Giggins, Sweeney e Caulfield; Journal of NeuroEngineering and Rehabilitation — literatura primária, estudo analítico transversal — https://doi.org/10.1186/1743-0003-11-158 — Confirma o uso do heel slide em decúbito dorsal e a relevância de alinhamento, velocidade e qualidade; os participantes receberam instrução padronizada, demonstração e ensaio observado. — Estudo de classificação de desempenho em contexto clínico controlado; não estabelece uma prescrição nem valida todos os erros possíveis em casa.

### Fonte 5: Time and Repetitions Needed to Train Patients with Knee Pain on a Home Exercise Program: Are Learning Styles Important?

- Autor ou entidade: Satış e Erdem; Cureus
- Tipo: literatura primária, estudo de aprendizagem de exercício
- Localizador: https://doi.org/10.7759/cureus.6988
- Usada para: Sustenta que a aprendizagem do heel slide foi estudada após explicação e demonstração por fisioterapeuta e que a compreensão técnica deve ser verificada.
- Limite: EX23-S03 — Time and Repetitions Needed to Train Patients with Knee Pain on a Home Exercise Program: Are Learning Styles Important? — Satış e Erdem; Cureus — literatura primária, estudo de aprendizagem de exercício — https://doi.org/10.7759/cureus.6988 — Sustenta que a aprendizagem do heel slide foi estudada após explicação e demonstração por fisioterapeuta e que a compreensão técnica deve ser verificada. — Amostra clínica com dor mecânica do joelho; não demonstra segurança universal nem elimina gatilhos de supervisão.
