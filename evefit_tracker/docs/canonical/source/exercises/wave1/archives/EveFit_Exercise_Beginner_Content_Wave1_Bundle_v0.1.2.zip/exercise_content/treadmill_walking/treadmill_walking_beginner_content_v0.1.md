# Caminhada em passadeira

Conteúdo para principiantes em português europeu.

## Descrição curta

Caminhada com passos alternados sobre o tapete móvel de uma passadeira motorizada, mantendo o corpo centrado e os comandos acessíveis.

## O que é

Nesta variante, caminhas sobre uma superfície que se move sob os teus pés. O padrão continua a ser o de caminhada, mas ficas aproximadamente no mesmo lugar em relação à máquina e tens de controlar a tua posição, a entrada, a paragem e a saída.

## O que vais fazer

Vais preparar a máquina, prender a chave de segurança, iniciar a partir das plataformas laterais fixas, entrar no tapete com controlo, manter passos alternados no centro e terminar antes de saíres.

## Porque existe este movimento

Esta variante permite executar o padrão cíclico da caminhada numa superfície motorizada controlada externamente, em espaço interior e sem deslocamento líquido.

## Antes de começares

1. Lê e segue o manual do modelo de passadeira que vais utilizar; os comandos e a chave de segurança variam entre máquinas.
2. Confirma que a passadeira está funcional, estável e sem sinais visíveis de dano, tapete desalinhado, deslizamento ou ruído anormal.
3. Localiza o botão de paragem e a chave de segurança antes de ligar o tapete.
4. Garante que a área de desmontagem, sobretudo atrás da passadeira, está livre.
5. Mantém atacadores, roupa, cabelo e objetos soltos afastados das partes móveis.

## Preparar o equipamento

1. Usa apenas uma passadeira motorizada verificada e instalada segundo o manual do fabricante.
2. Confirma que o tapete está centrado, que as plataformas laterais estão livres e que os apoios e comandos estão acessíveis.
3. Verifica se o cabo e a ficha não apresentam danos visíveis e se a alimentação corresponde às instruções do fabricante.
4. Coloca a chave de segurança no ponto indicado pela máquina e prende o clipe à roupa de modo a que o cordão não fique solto nem preso noutro objeto.
5. Se falta a chave, se o mecanismo não funciona ou se existe uma anomalia, não uses a passadeira e sinaliza a necessidade de assistência.

## Preparar o espaço

1. Utiliza a passadeira num espaço interior, seco e bem iluminado.
2. Mantém o piso em redor desimpedido e a zona atrás da máquina livre para uma saída de emergência.
3. Afasta crianças, animais e outras pessoas do tapete e das partes móveis durante a utilização.
4. Evita distrações que reduzam a visibilidade da posição dos pés ou o acesso aos comandos.

## Verificação do corpo

1. Confirma que consegues ficar de pé e alternar o apoio entre os pés com controlo.
2. Antes de iniciares, verifica se não sentes desconforto no peito, falta de ar atípica, tonturas, confusão, dor nova ou instabilidade marcada.
3. Se a máquina ou o ambiente forem novos para ti, pede orientação presencial antes de começares.
4. Se tens limitações de equilíbrio ou estás a regressar após lesão ou cirurgia, a adaptação e a revisão adequadas devem ser definidas fora deste conteúdo.

## Posição inicial

Com o tapete totalmente parado, sobe para a estrutura da passadeira, vira-te para a consola e coloca um pé em cada plataforma lateral fixa, ficando sobre o tapete sem o pisar. Mantém o tronco alto, os comandos ao alcance e uma mão perto do apoio enquanto confirmas a chave de segurança.

## Confirmar a posição inicial

1. O tapete está parado.
2. Os pés estão nas plataformas laterais fixas.
3. O corpo está virado para a consola.
4. A chave de segurança está colocada na máquina e presa à roupa.
5. O botão de paragem e os apoios estão ao alcance.
6. A zona atrás da passadeira está livre.

## Passos de execução

1. Sobe para a passadeira apenas com o tapete parado e coloca os pés nas plataformas laterais fixas.
2. Prende a chave de segurança à roupa e confirma onde estão os comandos de iniciar, reduzir e parar.
3. Mantém-te virado para a consola, com uma mão disponível para o apoio, e inicia o tapete pelo comando próprio do modelo.
4. Quando o movimento do tapete estiver previsível e controlável, coloca um pé e depois o outro no centro da superfície móvel, usando o apoio na transição se necessário.
5. Faz passos alternados, pousando cada pé sob o corpo e acompanhando o movimento do tapete sem te deixares levar para trás.
6. Mantém a cabeça orientada para a frente, o tronco alto e o corpo aproximadamente centrado entre a consola e a extremidade posterior.
7. Deixa os braços acompanhar naturalmente os passos quando estiveres estável; usa os apoios apenas para a adaptação ou estabilidade prevista.
8. Respira de forma natural e contínua, sem prender a respiração, enquanto manténs o controlo dos passos e da posição.
9. Para terminar, usa os comandos para reduzir o movimento, continua a acompanhar o tapete e espera pela paragem completa antes de sair.

## Fases do movimento

### Preparação fora do tapete móvel

Ficas nas plataformas laterais, confirmas comandos, apoio e chave de segurança.

### Entrada controlada

Depois de o movimento estar previsível, transferes um pé e depois o outro para o centro do tapete.

### Caminhada cíclica

Alternas os apoios dos pés e ajustas continuamente os passos para permanecer centrado na máquina.

### Paragem e saída

Reduzes o movimento pelos comandos, aguardas que o tapete pare e só depois desmontas.

## Respiração

Mantém uma respiração natural, regular e contínua ao longo da caminhada. Não prendas a respiração nem imponhas contagens. Se a respiração se tornar atípica, difícil de controlar ou vier acompanhada de desconforto, termina com segurança.

## Sensações esperadas

1. Contacto alternado dos pés com o tapete móvel.
2. Trabalho cíclico das pernas e participação postural do tronco.
3. Necessidade ligeira de ajustar o comprimento dos passos para permanecer centrado.
4. Respiração e batimento cardíaco que podem aumentar de acordo com a utilização definida fora deste registo.

## Sensações inesperadas ou de alerta

1. Desconforto no peito ou falta de ar atípica.
2. Tonturas, confusão, sensação de desmaio ou perda de orientação.
3. Dor nova ou agravada.
4. Perda de controlo dos passos, tropeção ou recuo persistente no tapete.
5. Sensação de que o tapete desliza, acelera inesperadamente ou não responde aos comandos.

## Indicações técnicas principais

1. Chave presa à roupa; comandos ao alcance.
2. Olha em frente e mantém-te centrado.
3. Passos alternados sob o corpo.
4. Respira sem prender.
5. Só sais com o tapete parado.

## Erros comuns e correções

### Erro 1: Começar com os pés sobre o tapete móvel.

- Como reconhecer: Os dois pés estão na faixa central quando o motor é iniciado.
- Como corrigir: Antes de iniciares, coloca um pé em cada plataforma lateral fixa e entra no tapete apenas quando o movimento estiver previsível.

### Erro 2: Não prender a chave de segurança à roupa.

- Como reconhecer: A chave está apenas na consola ou o clipe fica pendurado sem ligação à pessoa.
- Como corrigir: Prende o clipe à roupa antes de iniciares e mantém o cordão livre de objetos.

### Erro 3: Deixar o corpo recuar no tapete.

- Como reconhecer: Os pés aproximam-se repetidamente da extremidade posterior e os comandos ficam difíceis de alcançar.
- Como corrigir: Aciona a redução ou paragem, recupera uma posição centrada com apoio se necessário e não continues se o controlo não regressar.

### Erro 4: Olhar continuamente para os pés.

- Como reconhecer: A cabeça permanece inclinada e a orientação em relação à consola e ao espaço diminui.
- Como corrigir: Mantém o olhar predominantemente em frente e usa verificações breves da posição apenas quando necessário.

### Erro 5: Apoiar continuamente o peso do corpo nos corrimãos.

- Como reconhecer: Os braços sustentam o corpo e o padrão dos passos muda por dependência dos apoios.
- Como corrigir: Usa os apoios para a transição ou estabilidade prevista; se não consegues caminhar sem suportar continuamente o peso, termina e procura adaptação ou supervisão.

### Erro 6: Sair antes de o tapete parar.

- Como reconhecer: Um pé tenta alcançar o chão ou a estrutura enquanto a faixa central ainda se move.
- Como corrigir: Mantém-te na máquina, usa os comandos, espera pela paragem completa e só depois desmonta com apoio.

## Formas de simplificar ou ensaiar

1. Pede a um profissional que te mostre os comandos, a chave de segurança e a sequência de entrada e saída.
2. Mantém uma mão próxima do apoio durante a entrada e a paragem.
3. Usa apenas uma configuração que te permita conservar passos controlados e acesso imediato aos comandos; a escolha concreta pertence à prescrição.
4. Se não consegues permanecer centrado sem depender continuamente dos apoios, não prossigas sem adaptação ou supervisão.

## Supervisão

A supervisão é recomendada, sobretudo quando a pessoa não conhece a máquina, apresenta instabilidade marcada, tem limitações de equilíbrio ou necessita de adaptação. O supervisor deve conseguir alcançar os comandos e orientar uma saída segura sem entrar na zona móvel.

## Como terminar

Mantém os passos enquanto usas os comandos para reduzir o movimento do tapete. Usa o botão de paragem do modelo e aguarda a imobilização completa. Depois de parado, passa os pés para as plataformas laterais fixas. Retira a chave de segurança conforme o manual e desce da passadeira com apoio, sem saltar. Se a máquina não responder normalmente, usa o sistema de paragem de emergência e não voltes a utilizá-la até ser verificada.

## Nota de segurança

A superfície móvel eleva o risco de queda. Mantém a chave de segurança presa à roupa, os comandos acessíveis e a zona de saída desimpedida. A chave inicia a paragem quando é removida, mas não substitui uma posição controlada, os apoios nem a leitura do manual do modelo.

## Quando parar ou reduzir

1. Desconforto no peito ou falta de ar atípica.
2. Tonturas ou confusão.
3. Perda de controlo ou dor nova.
4. Instabilidade marcada, tropeção ou incapacidade de permanecer centrado.
5. Resposta inesperada do tapete, deslizamento, ruído anormal ou falha dos comandos.

## Segurança do equipamento

Não uses uma passadeira danificada, instável, não verificada ou sem paragem de emergência acessível. Confirma a função e a colocação da chave de segurança de acordo com o manual específico. Mantém mãos, cabelo, roupa, atacadores e objetos afastados do tapete e de outras partes móveis. Não tentes ajustar, alcançar por baixo ou reparar a máquina durante a utilização. Se o tapete estiver desalinhado, escorregar, fizer ruído anormal ou não responder, para e solicita assistência qualificada.

## Segurança do espaço

Utiliza a máquina apenas num local interior adequado e numa superfície estável. Mantém livre a área indicada pelo fabricante, incluindo a zona atrás da passadeira. Não permitas pessoas, crianças ou animais junto da superfície móvel. Garante iluminação suficiente para ver o tapete, os apoios e os comandos. Não uses a máquina quando água, objetos ou obstáculos comprometerem a zona de entrada e saída.

## Limitações

1. Os comandos, a desaceleração e o mecanismo da chave variam entre modelos; prevalece sempre o manual da máquina utilizada.
2. Este conteúdo não define dose, velocidade, inclinação, duração, distância, intensidade, progressão nem elegibilidade individual.
3. Não substitui avaliação clínica, formação presencial, supervisão necessária ou assistência técnica.
4. A evidência biomecânica descreve diferenças de grupo e não permite prever a resposta de uma pessoa específica.

## Teste de compreensão

### 1. Onde devem estar os pés antes de iniciar o tapete?

Resposta esperada: Um pé em cada plataforma lateral fixa, com o tapete parado.

### 2. O que deves fazer com a chave de segurança?

Resposta esperada: Colocá-la no ponto indicado da máquina e prender o clipe à roupa antes de iniciar.

### 3. Quando podes passar das plataformas laterais para o tapete?

Resposta esperada: Quando o movimento estiver previsível e controlável, usando apoio se necessário.

### 4. Onde deves manter o corpo durante a caminhada?

Resposta esperada: Aproximadamente centrado no tapete, com os comandos acessíveis.

### 5. Como deves respirar?

Resposta esperada: De forma natural, regular e contínua, sem prender a respiração.

### 6. Os apoios devem sustentar continuamente o peso do corpo?

Resposta esperada: Não; servem para transições ou estabilidade prevista. Dependência contínua pede adaptação ou supervisão.

### 7. O que fazes se começares a recuar para a extremidade posterior?

Resposta esperada: Reduzo ou paro o tapete, recupero uma posição controlada com apoio e não continuo sem controlo.

### 8. Quando podes descer da passadeira?

Resposta esperada: Apenas depois de o tapete estar completamente parado.

### 9. Que sinais corporais obrigam a terminar com segurança?

Resposta esperada: Desconforto no peito, falta de ar atípica, tonturas, confusão, dor nova ou perda de controlo.

### 10. O que fazes se o tapete deslizar, fizer ruído anormal ou não responder?

Resposta esperada: Paro a utilização e peço verificação ou assistência qualificada.

### 11. Porque é esta uma variante separada da caminhada no solo?

Resposta esperada: Porque a superfície se move, não há deslocamento global e surgem comandos, chave e riscos próprios.

### 12. Este conteúdo define velocidade, inclinação ou duração?

Resposta esperada: Não; essas decisões pertencem à prescrição, fora deste registo.

## Fontes e limites da evidência

### Fonte 1: Exercising Your Way to Lowering Your Blood Pressure

- Autor ou entidade: A1-S01 — Exercising Your Way to Lowering Your Blood Pressure — American College of Sports Medicine — orientação profissional — https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf — Sustenta a caminhada como modalidade aeróbia ao nível da família; não sustenta técnica fina nem dose neste registo.
- Tipo: orientação profissional
- Localizador: https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf
- Usada para: A1-S01 — Exercising Your Way to Lowering Your Blood Pressure — American College of Sports Medicine — orientação profissional — https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf — Sustenta a caminhada como modalidade aeróbia ao nível da família; não sustenta técnica fina nem dose neste registo.
- Limite: A1-S01 — Exercising Your Way to Lowering Your Blood Pressure — American College of Sports Medicine — orientação profissional — https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf — Sustenta a caminhada como modalidade aeróbia ao nível da família; não sustenta técnica fina nem dose neste registo.

### Fonte 2: ACSM Preparticipation Screening Guidelines

- Autor ou entidade: A1-S31 — ACSM Preparticipation Screening Guidelines — American College of Sports Medicine / Exercise is Medicine — guideline profissional — https://www.exerciseismedicine.org/assets/page_documents/ACSM%20Preparticipation%20Screening%20Guidelines.pdf — Sustenta prudência perante sintomas e separação entre conteúdo geral e elegibilidade individual.
- Tipo: guideline profissional
- Localizador: https://www.exerciseismedicine.org/assets/page_documents/ACSM%20Preparticipation%20Screening%20Guidelines.pdf
- Usada para: A1-S31 — ACSM Preparticipation Screening Guidelines — American College of Sports Medicine / Exercise is Medicine — guideline profissional — https://www.exerciseismedicine.org/assets/page_documents/ACSM%20Preparticipation%20Screening%20Guidelines.pdf — Sustenta prudência perante sintomas e separação entre conteúdo geral e elegibilidade individual.
- Limite: A1-S31 — ACSM Preparticipation Screening Guidelines — American College of Sports Medicine / Exercise is Medicine — guideline profissional — https://www.exerciseismedicine.org/assets/page_documents/ACSM%20Preparticipation%20Screening%20Guidelines.pdf — Sustenta prudência perante sintomas e separação entre conteúdo geral e elegibilidade individual.

### Fonte 3: Investing in a Personal Trainer

- Autor ou entidade: A2-S04 — Investing in a Personal Trainer — American College of Sports Medicine — orientação profissional — https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf — Sustenta a caminhada como exemplo de atividade aeróbia e o papel de orientação profissional.
- Tipo: orientação profissional
- Localizador: https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf
- Usada para: A2-S04 — Investing in a Personal Trainer — American College of Sports Medicine — orientação profissional — https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf — Sustenta a caminhada como exemplo de atividade aeróbia e o papel de orientação profissional.
- Limite: A2-S04 — Investing in a Personal Trainer — American College of Sports Medicine — orientação profissional — https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf — Sustenta a caminhada como exemplo de atividade aeróbia e o papel de orientação profissional.

### Fonte 4: Life Fitness T3.0/T3.5 Treadmill Operation Manual, 7965201 Rev A

- Autor ou entidade: EX11-S01 — Life Fitness T3.0/T3.5 Treadmill Operation Manual, 7965201 Rev A — Life Fitness — documentação oficial de equipamento — https://kb.cybexintl.com/Owners_Manuals/Treadmill/Life_Fitness_T3.0_T3.5_Operation_Manual_7965201_English.pdf — Sustenta plataformas laterais no arranque, área posterior livre, uso dos apoios quando necessário, roupa afastada das partes móveis e sinais para interromper.
- Tipo: documentação oficial de equipamento
- Localizador: https://kb.cybexintl.com/Owners_Manuals/Treadmill/Life_Fitness_T3.0_T3.5_Operation_Manual_7965201_English.pdf
- Usada para: EX11-S01 — Life Fitness T3.0/T3.5 Treadmill Operation Manual, 7965201 Rev A — Life Fitness — documentação oficial de equipamento — https://kb.cybexintl.com/Owners_Manuals/Treadmill/Life_Fitness_T3.0_T3.5_Operation_Manual_7965201_English.pdf — Sustenta plataformas laterais no arranque, área posterior livre, uso dos apoios quando necessário, roupa afastada das partes móveis e sinais para interromper.
- Limite: EX11-S01 — Life Fitness T3.0/T3.5 Treadmill Operation Manual, 7965201 Rev A — Life Fitness — documentação oficial de equipamento — https://kb.cybexintl.com/Owners_Manuals/Treadmill/Life_Fitness_T3.0_T3.5_Operation_Manual_7965201_English.pdf — Sustenta plataformas laterais no arranque, área posterior livre, uso dos apoios quando necessário, roupa afastada das partes móveis e sinais para interromper.

### Fonte 5: TM50-23 Owner's Manual and Assembly Guide, MAN-TM50-23 REV04

- Autor ou entidade: EX11-S02 — TM50-23 Owner's Manual and Assembly Guide, MAN-TM50-23 REV04 — TRUE Fitness — documentação oficial de equipamento — https://shop.truefitness.com/wp-content/uploads/sites/2/2024/12/MAN-TM50-23-REV04-Owners-Manual-and-Assembly-Guide.pdf — Fonte independente para chave e clipe de segurança, montagem com tapete parado, plataformas laterais, controlo na entrada e saída e inspeção de anomalias.
- Tipo: documentação oficial de equipamento
- Localizador: https://shop.truefitness.com/wp-content/uploads/sites/2/2024/12/MAN-TM50-23-REV04-Owners-Manual-and-Assembly-Guide.pdf
- Usada para: EX11-S02 — TM50-23 Owner's Manual and Assembly Guide, MAN-TM50-23 REV04 — TRUE Fitness — documentação oficial de equipamento — https://shop.truefitness.com/wp-content/uploads/sites/2/2024/12/MAN-TM50-23-REV04-Owners-Manual-and-Assembly-Guide.pdf — Fonte independente para chave e clipe de segurança, montagem com tapete parado, plataformas laterais, controlo na entrada e saída e inspeção de anomalias.
- Limite: EX11-S02 — TM50-23 Owner's Manual and Assembly Guide, MAN-TM50-23 REV04 — TRUE Fitness — documentação oficial de equipamento — https://shop.truefitness.com/wp-content/uploads/sites/2/2024/12/MAN-TM50-23-REV04-Owners-Manual-and-Assembly-Guide.pdf — Fonte independente para chave e clipe de segurança, montagem com tapete parado, plataformas laterais, controlo na entrada e saída e inspeção de anomalias.

### Fonte 6: Getting Active to Control High Blood Pressure

- Autor ou entidade: EX11-S03 — Getting Active to Control High Blood Pressure — American Heart Association — orientação profissional — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Sustenta respiração regular durante a atividade e evitar retenção da respiração; não é usada para prescrever intensidade.
- Tipo: orientação profissional
- Localizador: https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure
- Usada para: EX11-S03 — Getting Active to Control High Blood Pressure — American Heart Association — orientação profissional — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Sustenta respiração regular durante a atividade e evitar retenção da respiração; não é usada para prescrever intensidade.
- Limite: EX11-S03 — Getting Active to Control High Blood Pressure — American Heart Association — orientação profissional — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Sustenta respiração regular durante a atividade e evitar retenção da respiração; não é usada para prescrever intensidade.

### Fonte 7: Biomechanics of overground vs. treadmill walking in healthy individuals

- Autor ou entidade: EX11-S04 — Biomechanics of overground vs. treadmill walking in healthy individuals — Seung-Jean Lee e Joseph Hidler — estudo científico primário — https://pubmed.ncbi.nlm.nih.gov/18048582/ — Sustenta que a marcha em passadeira e no solo são comparáveis em muitos aspetos, mas apresentam diferenças biomecânicas que justificam não as tratar como execuções idênticas.
- Tipo: estudo científico primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/18048582/
- Usada para: EX11-S04 — Biomechanics of overground vs. treadmill walking in healthy individuals — Seung-Jean Lee e Joseph Hidler — estudo científico primário — https://pubmed.ncbi.nlm.nih.gov/18048582/ — Sustenta que a marcha em passadeira e no solo são comparáveis em muitos aspetos, mas apresentam diferenças biomecânicas que justificam não as tratar como execuções idênticas.
- Limite: EX11-S04 — Biomechanics of overground vs. treadmill walking in healthy individuals — Seung-Jean Lee e Joseph Hidler — estudo científico primário — https://pubmed.ncbi.nlm.nih.gov/18048582/ — Sustenta que a marcha em passadeira e no solo são comparáveis em muitos aspetos, mas apresentam diferenças biomecânicas que justificam não as tratar como execuções idênticas.
