# Relatório de investigação — marcha no lugar sincronizada com pulso externo

**Agente:** EX-35  
**Exercise ID:** `march_in_place_to_external_beat`  
**Data da consulta externa:** 24 de julho de 2026  
**Âmbito:** execução para principiantes, sincronização com pulso auditivo, preparação, respiração, segurança, erros e supervisão  
**Implementação realizada:** não

## Resultado

O conteúdo para principiantes pode ser aprovado com limites. A identidade técnica está suficientemente definida: alternar a elevação e o apoio dos pés no mesmo local, fazendo coincidir cada contacto com um pulso externo audível. A evidência direta existe, mas concentra-se em populações clínicas; por isso, sustenta a organização da tarefa e não uma promessa, um parâmetro temporal ou uma transferência automática para a população geral.

O risco operacional mantém-se **moderado**. A fonte auditiva continua constitutiva, o apoio estável continua opcional e a supervisão continua recomendada. Não foi criada, removida ou alterada qualquer relação.

## Perguntas de investigação

1. Que componente do passo deve ser sincronizado com o pulso?
2. Que preparação auditiva e ambiental é necessária?
3. Que instruções de marcha no lugar são adequadas a principiantes?
4. Como lidar com perda de sincronização sem incentivar sobreaceleração?
5. Que orientação respiratória é defensável?
6. Que sinais justificam interrupção?
7. Quando é necessária maior supervisão ou revisão?
8. Que limites impedem converter investigação clínica em prescrição geral?

## Fontes consultadas e extração

### 1. Chang et al., 2019 — estudo primário direto

**Referência:** Chang HY, Lee YY, Wu RM, Yang YR, Luh JJ. *Effects of rhythmic auditory cueing on stepping in place in patients with Parkinson's disease*. Medicine. 2019;98(45):e17874.  
**Ligação:** [PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC6855520/)  
**Desenho:** estudo aleatorizado cruzado numa população clínica.

**Contributo:**

- estuda diretamente passo no lugar com pista auditiva;

- confirma que o passo estacionário pode ser organizado como tarefa rítmica externamente marcada;

- sustenta a formulação de sincronizar o contacto do pé com o sinal;

- documenta limitações de amostra e gravidade clínica que impedem generalização ampla.

**Limite aplicado:** não foram importados resultados, parâmetros temporais, dose nem alegações de benefício.

### 2. Thaut et al., 1996 — estudo primário independente

**Referência:** Thaut MH, McIntosh GC, Rice RR, Miller RA, Rathbun J, Brault JM. *Rhythmic auditory stimulation in gait training for Parkinson's disease patients*. Movement Disorders. 1996;11(2):193-200.  
**Ligação:** [PubMed](https://pubmed.ncbi.nlm.nih.gov/8684391/)  
**Desenho:** ensaio clínico comparativo.

**Contributo:**

- usa estimulação auditiva rítmica como referência externa para a marcha;

- fornece suporte de família para acoplamento temporal entre ação motora cíclica e pulso auditivo;

- mostra que a pista externa pode organizar o tempo dos contactos.

**Limite aplicado:** o estudo aborda marcha numa população clínica e não define o valor temporal apropriado para este exercício nem conteúdo universal para principiantes.

### 3. Harrison et al., 2023 — revisão sistemática

**Referência:** Harrison EC et al. *Auditory cues and gait variability in Parkinson disease: a systematic review*. PMID 36695189.  
**Ligação:** [PubMed](https://pubmed.ncbi.nlm.nih.gov/36695189/)

**Contributo:**

- contextualiza a variabilidade de resposta a pistas auditivas;

- reforça que o sinal não deve ser tratado como universalmente benéfico ou adequado.

**Limite aplicado:** revisão clínica específica; não fundamenta promessas nem generalização entre populações.

### 4. American Parkinson Disease Association — fonte profissional

**Referência:** *Freezing of Gait and Parkinson's Disease*.  
**Ligação:** [APDA](https://www.apdaparkinson.org/what-is-parkinsons/symptoms/freezing-of-gait/)

**Contributo:**

- reconhece pistas externas como estratégia clínica;

- apoia a necessidade de separar uma explicação geral de uma utilização clínica individual.

**Limite aplicado:** não foi usada como autorização universal nem como substituto de revisão profissional.

### 5. NHS — equilíbrio e apoio estável

**Referência:** NHS. *Balance exercises*. Revisto em 7 de novembro de 2023.  
**Ligação:** [NHS](https://www.nhs.uk/live-well/exercise/balance-exercises/)

**Contributo:**

- aconselha roupa confortável;

- recomenda considerar uma parede ou cadeira estável quando existe possibilidade de perda de equilíbrio;

- apresenta movimentos de equilíbrio com execução controlada.

**Limite aplicado:** é orientação geral de equilíbrio, não investigação específica sobre sincronização auditiva.

### 6. Leicestershire Partnership NHS Trust — marcha no lugar

**Referência:** *Balance Class Exercises: Marching on the Spot*.  
**Ligação:** [PDF](https://www.leicspart.nhs.uk/wp-content/uploads/2020/06/Balance-Class-Exercises.pdf)

**Contributo:**

- descreve posição direita, pés afastados de forma confortável e peso distribuído;

- mantém a marcha no lugar;

- admite cadeira ou superfície estável quando é necessário apoio.

**Limite aplicado:** a folha inclui dose e formas de aumentar dificuldade que ficaram excluídas deste conteúdo.

## Síntese por tema

### Sincronização e controlo motor

O evento temporal mais observável e coerente com a identidade é o contacto do pé com o chão. A instrução principal é, por isso, “um contacto de pé por batida”. A pessoa ouve primeiro o sinal, inicia a alternância e mantém-se no mesmo local.

Quando deixa de coincidir com o pulso, não deve tentar recuperar por aceleração brusca. A saída mais conservadora é assentar ambos os pés, recuperar a estabilidade, voltar a ouvir o sinal e só então reiniciar. Esta formulação responde ao risco canónico de sobreaceleração sem atribuir qualquer valor temporal.

### Preparação e equipamento

A fonte auditiva pode ser:

- dispositivo de reprodução áudio;

- aplicação de marcação auditiva;

- metrónomo.

Não existe suporte sem uma destas alternativas, porque o pulso externo define esta identidade. O apoio estável permanece opcional. O alvo físico permanece não obrigatório; a referência auditiva é temporal e não cria uma nova condição de alvo.

O sinal deve ser regular, estável e claramente percetível. O dispositivo e eventuais cabos ficam fora da área dos pés. Qualquer ajuste ocorre apenas depois de parar e estabilizar.

### Ambiente e superfície

Foram preservados:

- pequena área estacionária livre;

- piso firme, nivelado e antiderrapante;

- ausência de obstáculos;

- ruído de fundo suficientemente baixo;

- proibição de veículo em movimento e altura desprotegida;

- exclusão de superfícies desorganizadas, escorregadias ou instáveis.

### Técnica

A sequência documental adotada é:

1. ouvir o pulso;
2. distribuir o peso;
3. transferir o peso para um pé;
4. elevar o pé oposto apenas o suficiente para o libertar;
5. apoiar em coincidência com a batida;
6. alternar sem avançar;
7. manter tronco controlado e olhar em frente;
8. sair voluntariamente com ambos os pés apoiados.

O balanço alternado dos braços é opcional e não pode dificultar o equilíbrio.

### Respiração

Não foi identificada uma razão específica para impor um padrão respiratório ligado ao pulso. A orientação mais conservadora é respirar de forma natural e contínua, sem retenção e sem forçar inspiração ou expiração a coincidir com a batida. Trata-se de orientação geral de segurança, não de um protocolo respiratório específico estudado nesta tarefa.

### Erros prioritários

Foram selecionados erros diretamente ligados à identidade e ao risco:

- avançar ou recuar;

- perseguir o pulso com passos apressados;

- bater ou arrastar os pés;

- continuar quando o sinal deixou de ser percetível;

- reter ou forçar a respiração para acompanhar o pulso.

Cada erro foi acompanhado por um sinal observável e uma correção que começa por recuperar controlo.

### Segurança e supervisão

Mantêm-se como sinais de interrupção:

- dor aguda;

- mal-estar;

- tontura;

- perda de controlo;

- necessidade repetida de apoio não planeado.

Foram ainda explicitados tropeço, sensação de queda, perda de audibilidade e incapacidade de interromper voluntariamente, todos coerentes com os fatores de risco e pré-requisitos canónicos.

A supervisão continua recomendada, sobretudo na aprendizagem inicial. É necessária revisão ou acompanhamento adequado quando existe risco elevado de queda, quedas recentes, limitações auditivas relevantes, condições neurológicas ou vestibulares, utilização clínica de cueing ou incapacidade de sair da tarefa de forma independente. O spotter não se torna obrigatório por defeito.

## Relações preservadas

| Relation ID | Estado | Papel |
|---|---|---|
| `march_in_place_to_external_beat__activation__motor_control_coordination__rhythm_synchronization__prime_external_cue_synchronization` | `conditional` | `complementary` |
| `march_in_place_to_external_beat__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` | `conditional` | `alternative_primary` |
| `march_in_place_to_external_beat__main_training__motor_control_coordination__rhythm_synchronization__synchronize_with_external_rhythm` | `compatible` | `alternative_primary` |
| `march_in_place_to_external_beat__warmup__cardio_conditioning__repetitive_rhythmic_movement__establish_movement_rhythm` | `conditional` | `complementary` |
| `march_in_place_to_external_beat__warmup__motor_control_coordination__rhythm_synchronization__rehearse_external_rhythm` | `conditional` | `complementary` |

Não foi inferida qualquer combinação adicional. Os limites condicionais, o risco mínimo moderado, o equipamento, o ambiente, a elegibilidade e a supervisão não foram reduzidos.

## Decisões editoriais

- **Estado:** `beginner_content_approved_with_limits`.

- **Confiança:** moderada.

- **Identidade:** preservada sem alteração.

- **Risco:** moderado, sem redução.

- **Equipamento:** grupo alternativo auditivo preservado; apoio estável opcional.

- **Alvo:** nenhum alvo físico obrigatório; pulso auditivo mantido como referência temporal constitutiva.

- **Superfície:** firme, nivelada e antiderrapante.

- **Relações:** cinco relações preservadas, sem novas relações.

- **Prescrição:** excluída.

- **Promessa ou diagnóstico:** excluídos.

- **Implementação de código ou publicação:** não realizada.

## Limitações

- A evidência direta é sobretudo clínica.

- Os estudos não autorizam transferir resultados para principiantes em geral.

- Não foi fixado qualquer valor temporal do pulso.

- Não foram definidos repetições, séries, duração, distância, carga, intensidade, frequência ou progressão.

- A orientação respiratória é conservadora e não específica de um ensaio sobre esta tarefa.

- Contextos clínicos exigem revisão apropriada e não são cobertos por este documento geral.

## Verificação do contrato

- Português europeu: sim.

- UTF-8 e normalização NFC: a validar mecanicamente.

- Passos de execução: oito.

- Indicações principais: sete.

- Erros comuns com reconhecimento e correção: cinco.

- Perguntas de compreensão: doze.

- Dose ou prescrição: não incluída.

- Cadência definida: não.

- Promessa de resultado: não.

- Diagnóstico ou tratamento: não.

- Código ou publicação: não.

- Campos por resolver: nenhum.

- Implementação realizada: não.
