# Relatório de investigação — Alongamento borboleta dos adutores

**Exercise ID:** `seated_butterfly_adductor_stretch`  
**Agente:** EX-26  
**Data de consulta:** 24 de julho de 2026  
**Implementação realizada: não**

## Âmbito

Foi investigada a execução da posição sentada, a organização da bacia e do tronco, a respiração, a sensação de alongamento, os sinais de aviso, os erros frequentes, a saída autónoma e as circunstâncias que podem justificar supervisão.

A identidade canónica foi preservada: posição bilateral sentada, plantas dos pés juntas, abertura controlada das ancas, risco operacional baixo, sem equipamento obrigatório, tapete de exercício opcional, superfície estável e antiderrapante, sem parceiro, observador ou supervisão obrigatórios. As duas relações aprovadas foram mantidas sem alterações.

## Fontes e contributos

| ID | Fonte | Tipo | Contributo utilizado | Limites |
|---|---|---|---|---|
| EX26-S1 | American Academy of Orthopaedic Surgeons, [Flexibility Exercises for Young Athletes](https://www.orthoinfo.org/staying-healthy/flexibility-exercises-for-young-athletes/) | Orientação profissional revista por médicos | Plantas dos pés juntas, joelhos abertos, controlo do tronco, execução cuidadosa e sem ressalto | Dirigida a jovens atletas; a pressão sugerida sobre os joelhos foi excluída |
| EX26-S2 | National Academy of Sports Medicine, [Static Butterfly Stretch](https://www.nasm.org/resource-center/exercise-library/static-butterfly-stretch) | Orientação técnica profissional | Posição sentada, coluna neutra, sensação na face interna das coxas, respiração livre, saída gradual, erros e adaptações | Algumas afirmações excedem o âmbito documental e não foram adotadas |
| EX26-S3 | Mayo Clinic, [Stretching: Focus on flexibility](https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20047931) | Orientação clínica institucional | Movimento lento, ausência de ressalto, respeito pela dor e respiração livre | Fonte geral, não específica da posição borboleta |
| EX26-S4 | Ogawa, Saeki e Ichihashi, [The effect of hip flexion angle on muscle elongation of the hip adductor muscles during stretching](https://pubmed.ncbi.nlm.nih.gov/32019680/) | Estudo biomecânico primário com elastografia | Suporte para elongação de componentes dos adutores em abdução da anca e para linguagem anatómica prudente | Amostra de homens saudáveis e posições laboratoriais; não testa integralmente esta apresentação sentada |
| EX26-S5 | Fjerstad et al., [Comparison of Two Static Stretching Procedures on Hip Adductor Flexibility and Strength](https://pubmed.ncbi.nlm.nih.gov/30338021/) | Estudo primário cruzado e aleatorizado | Confirma que procedimentos estáticos ativos e passivos dos adutores foram estudados e que a amplitude é uma variável controlada | Participantes saudáveis e fisicamente ativos; não fornece uma regra universal para principiantes |

As fontes são independentes em autoria e natureza: duas organizações profissionais, uma instituição clínica e dois grupos de investigação primária.

## Síntese técnica

### Identidade e posição

A convergência entre AAOS e NASM sustenta uma posição sentada com plantas dos pés juntas e joelhos abertos para os lados. O registo canónico exige tronco controlado e não torna obrigatória a inclinação anterior. Por isso, o conteúdo mantém o tronco vertical como opção plenamente válida.

### Entrada e saída

A entrada é gradual: sentar, fletir os joelhos, aproximar as plantas dos pés, permitir abertura bilateral e estabilizar o tronco. A saída inverte esta organização: reduzir a abertura, aproximar os joelhos e libertar os pés. Esta sequência preserva a exigência canónica de saída autónoma.

### Respiração

NASM e Mayo Clinic convergem em respiração livre durante um alongamento estático. A instrução final é natural e contínua, sem contagens. A necessidade de bloquear a respiração é tratada como indicação para reduzir a abertura ou sair.

### Sensação esperada

NASM situa a sensação na face interna das coxas e na região da anca. Ogawa et al. oferecem suporte biomecânico para elongação do adutor longo e de uma porção do adutor magno em posições de abdução. Como o estudo não replica integralmente a forma sentada, o conteúdo usa “tensão suave e difusa na face interna das coxas” e evita atribuir a sensação a um único músculo.

### Segurança e erros

AAOS desaconselha ressalto e recomenda execução cuidadosa. NASM identifica como erros a pressão agressiva dos joelhos, o arredondamento lombar, a força excessiva e o bloqueio respiratório. O conteúdo adota estes limites e acrescenta os sinais canónicos de interrupção: dor aguda ou crescente, dor inguinal, alteração da sensibilidade, fraqueza súbita, instabilidade, perda de controlo ou mal-estar.

### Supervisão

O exercício mantém `supervision_requirement: none` e `spotter_required: false`. A supervisão qualificada surge apenas quando a pessoa não controla a entrada ou saída, depende de força externa, regressa após lesão ou cirurgia, ou quando o historial ou estado atual altera a elegibilidade.

## Decisões perante divergências

1. A AAOS descreve pressão dos antebraços sobre os joelhos. Esta ação não foi adotada porque a identidade canónica declara que a pressão manual é assistência adicional, não obrigatória, e o perfil de risco identifica pressão excessiva no joelho.
2. A inclinação anterior aparece em fontes profissionais, mas não é necessária para reconhecer o exercício. Foi documentada apenas como opção condicionada ao controlo do tronco.
3. Foram excluídas afirmações de benefício futuro presentes em páginas profissionais. O conteúdo limita-se ao propósito técnico imediato e às sensações durante a execução.
4. Os estudos primários apoiam a mecânica da família dos adutores, mas as suas amostras não representam todas as pessoas principiantes. Essa limitação foi mantida explícita.

## Resultado da revisão

- Identidade canónica: preservada.
- Risco operacional baixo: preservado.
- Equipamento e superfície: preservados.
- Relações aprovadas: preservadas.
- Passos de execução: seis.
- Pistas principais: seis.
- Erros com reconhecimento e correção: seis.
- Perguntas de compreensão: doze.
- Respiração: natural e contínua.
- Campos por resolver: nenhum.
- Confiança global: moderada-alta.

## Conclusão

O conteúdo é adequado para aprovação com limites. Existe concordância suficiente para uma explicação clara a principiantes, e a literatura primária apoia a mecânica dos adutores. Permanecem limites de generalização para pessoas com sintomas, hipermobilidade relevante, regresso após lesão ou cirurgia, gravidez, pós-parto ou outras condições que alterem a tolerância.
