# EveFit Exercise Beginner Content Wave1 v0.1.2 — Master

Pacote documental de conteúdo público para principiantes. Não implementado e não publicado.

## Resumo

- Exercícios: 49
- Passos de execução: 380
- Indicações técnicas: 305
- Erros comuns: 297
- Perguntas de compreensão: 588
- Ocorrências de fontes: 337

## Exercícios

| N.º | Exercício | Capacidade | Estado do conteúdo |
|---:|---|---|---|
| 1 | Caminhada terrestre | cardio_conditioning | beginner_content_approved_with_limits |
| 2 | Corrida terrestre | cardio_conditioning | beginner_content_approved_with_limits |
| 3 | Ergometria estacionária de manivela para braços | cardio_conditioning | beginner_content_approved_with_limits |
| 4 | Marcha no lugar | cardio_conditioning | beginner_content_approved_with_limits |
| 5 | Movimento elíptico de corpo inteiro | cardio_conditioning | beginner_content_approved_with_limits |
| 6 | Pedalada em bicicleta estacionária vertical | cardio_conditioning | beginner_content_approved_with_limits |
| 7 | Propulsão manual de cadeira de rodas no solo | cardio_conditioning | beginner_content_approved_with_limits |
| 8 | Remo em ergómetro estático | cardio_conditioning | beginner_content_approved_with_limits |
| 9 | Salto à corda a dois pés | cardio_conditioning | beginner_content_approved_with_limits |
| 10 | Subida contínua de escadas | cardio_conditioning | beginner_content_approved_with_limits |
| 11 | Caminhada em passadeira | cardio_conditioning | beginner_content_approved_with_limits |
| 12 | Arranque de sprint de dois apoios | speed_power | beginner_content_approved_with_limits |
| 13 | Flexão de braços pliométrica | speed_power | beginner_content_approved_with_limits |
| 14 | Passe de peito com bola medicinal em pé | speed_power | beginner_content_approved_with_limits |
| 15 | Salto horizontal bipodal parado | speed_power | beginner_content_approved_with_limits |
| 16 | Salto vertical com contramovimento | speed_power | beginner_content_approved_with_limits |
| 17 | Saltos reativos curtos bipodais | speed_power | beginner_content_approved_with_limits |
| 18 | Sprint com paragem controlada | speed_power | beginner_content_approved_with_limits |
| 19 | Sprint linear | speed_power | beginner_content_approved_with_limits |
| 20 | Sprint resistido com trenó | speed_power | beginner_content_approved_with_limits |
| 21 | Avanço de dorsiflexão do tornozelo em meio-ajoelhado | mobility | beginner_content_approved_with_limits |
| 22 | Circundução ativa do tornozelo | mobility | beginner_content_approved_with_limits |
| 23 | Deslizamento do calcanhar em decúbito dorsal | mobility | beginner_content_approved_with_limits |
| 24 | Extensão torácica sentada sobre apoio | mobility | beginner_content_approved_with_limits |
| 25 | Flexão dorsal e plantar ativa do tornozelo | mobility | beginner_content_approved_with_limits |
| 26 | Alongamento borboleta dos adutores | flexibility | beginner_content_approved_with_limits |
| 27 | Alongamento do sóleo à parede com joelho fletido | flexibility | beginner_content_approved_with_limits |
| 28 | Alongamento dos gémeos à parede com joelho estendido | flexibility | beginner_content_approved_with_limits |
| 29 | Alongamento dos isquiotibiais em decúbito dorsal com as mãos | flexibility | beginner_content_approved_with_limits |
| 30 | Alongamento peitoral no vão da porta | flexibility | beginner_content_approved_with_limits |
| 31 | Alongamento unilateral dos isquiotibiais sentado | flexibility | beginner_content_approved_with_limits |
| 32 | Balanço da perna à frente e atrás | flexibility | beginner_content_approved_with_limits |
| 33 | Balanço lateral da perna | flexibility | beginner_content_approved_with_limits |
| 34 | Alongamento dos isquiotibiais em decúbito dorsal com correia | flexibility | beginner_content_approved_with_limits |
| 35 | Marcha no lugar sincronizada com pulso externo | motor_control_coordination | beginner_content_approved_with_limits |
| 36 | Marcha tandem | motor_control_coordination | beginner_content_approved_with_limits |
| 37 | Postura tandem | motor_control_coordination | beginner_content_approved_with_limits |
| 38 | Postura unipodal | motor_control_coordination | beginner_content_approved_with_limits |
| 39 | Sequência de passos em quatro quadrantes no sentido horário | motor_control_coordination | beginner_content_approved_with_limits |
| 40 | Transferência de peso multidirecional em pé | motor_control_coordination | beginner_content_approved_with_limits |
| 41 | Ciclo de tiro com arco para alvo | technique_skill | beginner_content_approved_with_limits |
| 42 | Lançamento parado de basquetebol ao cesto | technique_skill | beginner_content_approved_with_limits |
| 43 | Passe de antebraços de voleibol para alvo | technique_skill | beginner_content_approved_with_limits |
| 44 | Primeiro toque direcional no futebol | technique_skill | beginner_content_approved_with_limits |
| 45 | Sequência jab-direto para manoplas | technique_skill | beginner_content_approved_with_limits |
| 46 | Observação das sensações respiratórias | breathing_regulation | beginner_content_approved_with_limits |
| 47 | Respiração com expansão costal lateral | breathing_regulation | beginner_content_approved_with_limits |
| 48 | Respiração diafragmática | breathing_regulation | beginner_content_approved_with_limits |
| 49 | Respiração ritmada | breathing_regulation | beginner_content_approved_with_limits |
