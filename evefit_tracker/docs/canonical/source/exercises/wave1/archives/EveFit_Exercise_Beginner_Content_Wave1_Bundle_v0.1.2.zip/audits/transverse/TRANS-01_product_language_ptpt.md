# TRANS-01 — Auditoria transversal de produto e linguagem PT-PT

**Data:** 2026-07-24  
**Papel:** especialista transversal de produto e linguagem PT-PT  
**Resultado global:** revisão obrigatória; dois exercícios bloqueados  
**Implementação realizada:** zero

## Âmbito

Foram revistos os 49 exercícios de
`EveFit_Exercise_Beginner_Content_Wave1_v0.1/exercise_content`, abrangendo os 49
Markdown públicos e os 49 JSON de conteúdo para principiantes. Os relatórios de
investigação não foram tratados como conteúdo público nesta revisão.

Foram consultadas, apenas para triangulação, as sete auditorias de capability
`AUD-A` a `AUD-G`. Não foram lidos outputs de outros especialistas transversais.

## Método

1. Inventário fechado dos 49 pares Markdown/JSON.
2. Pesquisa integral, sem distinção entre maiúsculas e minúsculas, de anglicismos,
   formas não localizadas, voz formal/informal, promessas, linguagem de
   implementação e valores de esquema.
3. Comparação entre os campos PT-PT do JSON e a respetiva apresentação pública,
   com atenção especial a definições, preparação, execução, segurança, limites e
   teste de compreensão.
4. Leitura contextual de cada ocorrência candidata para excluir títulos
   bibliográficos, URLs e identificadores quando estes não eram apresentados como
   prosa para o utilizador.
5. Triangulação dos problemas de clareza e completude com os findings das sete
   auditorias de capability.

Critério de estado:

- `revisão_obrigatória`: o conteúdo é recuperável por correção editorial ou de
  apresentação, sem blocker neste domínio;
- `bloqueado`: existe omissão ou contradição pública que altera uma opção nuclear
  ou um requisito de utilização.

## Findings

### TRANS-01-001 — Metadados e linguagem de controlo interno expostos no Markdown público

- **Severidade:** alta
- **Blocker:** não
- **Exercícios:** todos os 49
- **Campo:** cabeçalho e secções de identidade, relações, risco, estado e
  implementação dos Markdown
- **Evidência:** 49/49 Markdown mostram um ID interno logo no bloco inicial; 37/49
  mostram “Implementação realizada” ou uma secção equivalente; pelo menos 26/49
  apresentam ainda valores de esquema ou secções de governação, como
  `canonical_exercise`, `technique_drill`, `beginner_content_approved_with_limits`,
  `speed_power`, nomes de famílias em `snake_case`, `none` e “Relações canónicas
  preservadas”. Exemplos particularmente nítidos:
  `archery_shot_cycle_to_target_beginner_content_v0.1.md:3-7`,
  `manual_wheelchair_propulsion_overground_beginner_content_v0.1.md:3-10`,
  `paced_breathing_beginner_content_v0.1.md:3-13` e
  `supine_heel_slide_beginner_content_v0.1.md:3-9`.
- **Impacto de produto:** a ficha mistura instrução para principiante com dados de
  QA, governação e implementação. Isto aumenta a carga cognitiva, torna visível
  vocabulário sem significado para o utilizador e faz o Markdown parecer um
  relatório interno, não uma experiência final.
- **Revisão exigida:** definir uma camada pública que apresente apenas nome,
  descrição, requisitos compreensíveis, execução, segurança, limites e
  autoavaliação. Manter IDs, enums, estado canónico, relações, confiança,
  `unresolved_fields` e implementação no JSON ou numa vista interna; quando risco e
  supervisão forem relevantes para o utilizador, traduzi-los para frases completas,
  sem expor tokens de esquema.

### TRANS-01-002 — Anglicismos e termos não localizados em prosa pública

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** 22 —
  `active_ankle_dorsiflexion_plantarflexion`,
  `archery_shot_cycle_to_target`, `basketball_set_shot_to_basket`,
  `boxing_jab_cross_to_focus_mitts`,
  `clockwise_four_quadrant_step_sequence`, `continuous_stair_ascent`,
  `countermovement_jump`, `half_kneeling_ankle_dorsiflexion_rock`,
  `lateral_costal_breathing`, `linear_sprint`,
  `manual_wheelchair_propulsion_overground`,
  `march_in_place_to_external_beat`, `paced_breathing`,
  `plyometric_push_up`, `respiratory_sensation_observation`,
  `sprint_to_controlled_stop`, `standing_medicine_ball_chest_pass`,
  `standing_soleus_wall_stretch`, `static_rowing_ergometer`,
  `tandem_stance`, `two_point_sprint_start` e
  `volleyball_forearm_pass_to_target`
- **Campo:** títulos de secção, tipo, pistas, simplificações, supervisão e limites
- **Evidência:** só nos Markdown públicos, sem contar repetições no JSON, surgem 17
  ocorrências de `cue/cues`, 15 de `spotter`, quatro de `checklist` e 13 de
  `drill`; a união abrange 22 exercícios. Exemplos:
  `basketball_set_shot_to_basket_beginner_content_v0.1.md:65,97,101,118`,
  `continuous_stair_ascent_beginner_content_v0.1.md:48,131`,
  `two_point_sprint_start_beginner_content_v0.1.md:4,13,120` e
  `respiratory_sensation_observation_beginner_content_v0.1.md:4,88,207`.
  No voleibol, “Os média permanecem por aprovar”
  (`volleyball_forearm_pass_to_target_beginner_content_v0.1.md:128`) é uma
  formulação administrativa e pouco natural para um principiante. AUD-F também
  registou `cue`, `spotter` e “Os média” como terminologia pública parcialmente não
  localizada.
- **Revisão exigida:** usar de forma consistente “indicação/pista técnica”,
  “assistente de segurança” ou “observador”, “lista de verificação”, “exercício
  técnico” e “conteúdos multimédia”. Manter termos especializados de modalidade,
  como `jab`, `sprint` ou `tandem`, apenas quando necessários e explicá-los na
  primeira ocorrência em linguagem simples. Não traduzir IDs nem títulos originais
  de fontes.

### TRANS-01-003 — Pessoa gramatical e género editorial inconsistentes

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** nove —
  `active_ankle_circumduction`,
  `active_ankle_dorsiflexion_plantarflexion`,
  `clockwise_four_quadrant_step_sequence`, `countermovement_jump`,
  `march_in_place_to_external_beat`, `single_leg_stance`,
  `standing_multidirectional_weight_shift`, `tandem_stance` e `tandem_walk`
- **Campo:** definição, preparação, execução, correções e teste de compreensão
- **Evidência:** seis fichas usam predominantemente a forma formal/terceira pessoa
  — “Percorra”, “Confirme”, “Caminhe”, “Fique”, “Respire” — enquanto o resto do
  corpus usa maioritariamente a segunda pessoa singular informal — “confirma”,
  “fica”, “respira”, “faz”. Em algumas dessas seis fichas, o próprio teste muda de
  registo: “Regressa [...] junta [...] estabiliza” em
  `clockwise_four_quadrant_step_sequence_beginner_content_v0.1.md:245`,
  “Decide [...] confirma” em
  `march_in_place_to_external_beat_beginner_content_v0.1.md:388` e “Usa [...]
  regressa” em `single_leg_stance_beginner_content_v0.1.md:284`. O
  `countermovement_jump` muda de construção dentro da mesma frase: “Partes de pé,
  baixas [...] e inverte-se” no JSON, linha 12, e Markdown, linha 14. As duas fichas
  de mobilidade do tornozelo abrem ainda com “Sentada”, assumindo género feminino,
  ao contrário da formulação neutra dominante.
- **Revisão exigida:** adotar uma norma editorial única para o produto; a forma
  informal de segunda pessoa singular é a escolha de menor alteração porque já
  domina o corpus. Rever definições, imperativos, perguntas e respostas na mesma
  passagem. Preferir construções neutras como “Senta-te numa cadeira estável” a
  adjetivos de género aplicados ao utilizador.

### TRANS-01-004 — Termos técnicos e instruções vagas impedem observação inequívoca

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** nove —
  `active_ankle_circumduction`,
  `active_ankle_dorsiflexion_plantarflexion`, `countermovement_jump`,
  `diaphragmatic_breathing`, `football_directional_first_touch`,
  `seated_supported_thoracic_extension`,
  `stationary_arm_crank_ergometry`, `supine_hamstring_strap_stretch` e
  `upright_stationary_cycling`
- **Campo:** definição, posição inicial, execução, equipamento e segurança
- **Evidência:** há jargão sem glosa suficiente — “multiplanar”, “complexo
  subtalar”, “contralateral”, “plano sagital”, “excursão diafragmática” e “fulcro”
  — e qualificadores que não dão um teste observável, como “tronco organizado”,
  “suporte previsto”, “superfície ampla e controlável”, “zona estável do pé”,
  “devidamente estabilizada” e “Monta com cuidado”. A frase “Passa diretamente para
  a inspiração seguinte quando o corpo a iniciar” é ainda sintaticamente pouco
  imediata (`diaphragmatic_breathing_beginner_content_v0.1.md:54`; JSON, linha 62).
  Os casos de maior impacto foram também corroborados por AUD-A-002/003,
  AUD-C-MOB-003, AUD-D-F-03, AUD-F-F-001 e AUD-G-F-002.
- **Revisão exigida:** na primeira ocorrência, substituir ou explicar cada termo
  técnico com uma descrição corporal simples. Converter qualificadores vagos em
  verificações observáveis antes da ação. Em particular: definir como reconhecer o
  apoio/fulcro correto; dar um exemplo não universal da superfície do pé; obter uma
  instrução validada para a zona da correia; explicar a estabilização do assento e a
  montagem na bicicleta; substituir “organizado” pelo alinhamento ou contacto
  efetivamente pretendido; e reformular a transição respiratória para “quando
  sentires o início natural da inspiração seguinte”.

### TRANS-01-005 — Teste público ausente ou sem chave de respostas

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** 14 —
  `basketball_set_shot_to_basket`, `boxing_jab_cross_to_focus_mitts`,
  `countermovement_jump`, `diaphragmatic_breathing`,
  `full_body_elliptical`, `half_kneeling_ankle_dorsiflexion_rock`,
  `lateral_leg_swing`, `standing_gastrocnemius_wall_stretch`,
  `standing_soleus_wall_stretch`, `treadmill_walking`,
  `two_foot_rope_skipping`, `two_point_sprint_start`,
  `upright_stationary_cycling` e `volleyball_forearm_pass_to_target`
- **Campo:** `beginner_comprehension_test`; secção Markdown de compreensão
- **Evidência:** 13 Markdown apresentam as 12 perguntas, mas omitem todas as
  respostas que existem no respetivo JSON. O Markdown de
  `half_kneeling_ankle_dorsiflexion_rock` não contém sequer uma secção de
  compreensão, embora o JSON tenha 12 itens. A omissão seletiva foi também
  identificada, em subconjuntos, por AUD-A-004, AUD-F-F-004 e AUD-G-F-004.
- **Revisão exigida:** definir uma única convenção pública. Para autoaprendizagem,
  publicar cada resposta imediatamente após a pergunta ou uma chave no fim,
  reutilizando o texto validado no JSON. Acrescentar a secção integral ao exercício
  meio-ajoelhado. Se o produto pretender ocultar respostas até interação, essa regra
  deve ser da interface e não uma perda de conteúdo no Markdown.

### TRANS-01-006 — Uma via nuclear de `paced_breathing` está ausente do conteúdo público

- **Severidade:** alta
- **Blocker:** sim
- **Exercício:** `paced_breathing`
- **Campo:** `short_description_pt_pt`, `beginner_definition_pt_pt`,
  `what_you_will_do_pt_pt`, `execution_steps_pt_pt` e secções Markdown
  correspondentes
- **Evidência:** JSON e Markdown ensinam apenas escolher e seguir um sinal externo.
  A auditoria AUD-G-F-001 confirmou que a identidade permite duas vias — ritmo
  regular autoescolhido ou sinal externo opcional — e que a omissão torna opaca a
  execução sem equipamento. As ocorrências públicas estão em
  `paced_breathing_beginner_content_v0.1.md:18,22,28,82-89`.
- **Revisão exigida:** documentar as duas vias em linguagem paralela e adaptar
  preparação, execução e saída a ambas, sem introduzir contagem, cadência ou dose.

### TRANS-01-007 — Linguagem imperativa contradiz a opcionalidade em `standing_multidirectional_weight_shift`

- **Severidade:** alta
- **Blocker:** sim
- **Exercício:** `standing_multidirectional_weight_shift`
- **Campo:** `before_you_start_pt_pt`, `safety_note_pt_pt` e Markdown correspondente
- **Evidência:** “Use roupa [...] e calçado adequado” cria um requisito material
  inexistente, e “Use apoio estável ao alcance” transforma em obrigação um apoio que
  a mesma ficha apresenta como opcional. As duas contradições constam do JSON e do
  Markdown, incluindo a linha 167 deste último. Foram independentemente confirmadas
  por AUD-E-MCC-001 e AUD-E-MCC-002.
- **Revisão exigida:** remover o requisito pessoal não autorizado e condicionar o
  apoio: “Se estiver previsto ou for necessário, confirma antes de começar que o
  apoio é estável e está ao alcance”. Garantir a mesma modalidade verbal em
  preparação, segurança, equipamento e teste.

## Padrões e decisões editoriais

### Padrões que exigem revisão

1. O JSON funciona simultaneamente como fonte de conteúdo e registo de governação;
   o Markdown reproduz essa mistura sem uma política clara de exposição.
2. A arquitetura das fichas é semelhante, mas os nomes das secções oscilam entre
   “pistas”, `cues`, “indicações”, “checklist”, “teste” e “verificação”.
3. A modalidade verbal pode alterar o significado do produto: uma opção passa a
   requisito quando “se usares” se torna “usa”.
4. Expressões recorrentes como “organizado”, “adequado ao contexto” e “profissional
   qualificado” precisam de um comportamento, critério ou papel verificável quando
   condicionam a execução.
5. A secção de compreensão não tem contrato editorial público uniforme.

### Padrões conformes

- Não foi encontrado um padrão sistemático de variantes lexicais PT-BR; o corpus
  usa, em geral, vocabulário europeu como “anca”, “gémeos”, “passadeira”, “travões”,
  “aterragem” e “ficheiro/conteúdo” quando aplicável.
- Não foram encontradas promessas de resultado não qualificadas. As frases de
  finalidade são geralmente enquadradas como prática técnica, e as fichas negam
  explicitamente garantias, diagnóstico e tratamento.
- A maioria das instruções usa corretamente a segunda pessoa singular informal e
  vocabulário corporal acessível; o problema é de consistência, não de
  incompreensibilidade global.
- Termos próprios de modalidades, como `jab`, são frequentemente acompanhados por
  descrição funcional; a revisão pedida não pretende apagar terminologia técnica
  necessária.

## Contagens

| Métrica | Resultado |
|---|---:|
| Exercícios auditados | 49 |
| Markdown públicos auditados | 49 |
| JSON auditados | 49 |
| Auditorias de capability consultadas | 7 |
| Findings | 7 |
| Findings de severidade alta | 3 |
| Findings de severidade média | 4 |
| Findings blocker | 2 |
| Exercícios bloqueados | 2 |
| Exercícios em revisão obrigatória não bloqueante | 47 |
| Markdown com ID interno visível | 49 |
| Markdown com estado de implementação visível | 37 |
| Markdown com enums/relações internas visíveis, mínimo confirmado | 26 |
| Exercícios com anglicismos editoriais do conjunto pesquisado | 22 |
| Exercícios com inconsistência de voz/género | 9 |
| Exercícios com teste público ausente ou sem respostas | 14 |
| Promessas de resultado não qualificadas | 0 |
| Padrão sistemático de variantes PT-BR | 0 |

As contagens lexicais de TRANS-01-002 referem-se ao Markdown público e excluem as
repetições equivalentes no JSON para evitar dupla contagem. “Enums/relações internas”
é uma contagem conservadora baseada nos padrões explicitamente enumerados, não uma
estimativa de todos os metadados visíveis.

## Estado por exercício afetado

Todos os exercícios são afetados por TRANS-01-001. A tabela acrescenta os findings
locais e distingue os dois blockers.

| Exercício | Estado TRANS-01 | Findings |
|---|---|---|
| `active_ankle_circumduction` | `revisão_obrigatória` | 001, 003, 004 |
| `active_ankle_dorsiflexion_plantarflexion` | `revisão_obrigatória` | 001, 002, 003, 004 |
| `archery_shot_cycle_to_target` | `revisão_obrigatória` | 001, 002 |
| `basketball_set_shot_to_basket` | `revisão_obrigatória` | 001, 002, 005 |
| `bilateral_pogo_jump` | `revisão_obrigatória` | 001 |
| `boxing_jab_cross_to_focus_mitts` | `revisão_obrigatória` | 001, 002, 005 |
| `clockwise_four_quadrant_step_sequence` | `revisão_obrigatória` | 001, 002, 003 |
| `continuous_stair_ascent` | `revisão_obrigatória` | 001, 002 |
| `countermovement_jump` | `revisão_obrigatória` | 001, 002, 003, 004, 005 |
| `diaphragmatic_breathing` | `revisão_obrigatória` | 001, 004, 005 |
| `doorway_pectoral_stretch` | `revisão_obrigatória` | 001 |
| `football_directional_first_touch` | `revisão_obrigatória` | 001, 004 |
| `front_to_back_leg_swing` | `revisão_obrigatória` | 001 |
| `full_body_elliptical` | `revisão_obrigatória` | 001, 005 |
| `half_kneeling_ankle_dorsiflexion_rock` | `revisão_obrigatória` | 001, 002, 005 |
| `lateral_costal_breathing` | `revisão_obrigatória` | 001, 002 |
| `lateral_leg_swing` | `revisão_obrigatória` | 001, 005 |
| `linear_sprint` | `revisão_obrigatória` | 001, 002 |
| `manual_wheelchair_propulsion_overground` | `revisão_obrigatória` | 001, 002 |
| `march_in_place_to_external_beat` | `revisão_obrigatória` | 001, 002, 003 |
| `marching_in_place` | `revisão_obrigatória` | 001 |
| `overground_running` | `revisão_obrigatória` | 001 |
| `overground_walking` | `revisão_obrigatória` | 001 |
| `paced_breathing` | `bloqueado` | 001, 002, 006 |
| `plyometric_push_up` | `revisão_obrigatória` | 001, 002 |
| `respiratory_sensation_observation` | `revisão_obrigatória` | 001, 002 |
| `seated_butterfly_adductor_stretch` | `revisão_obrigatória` | 001 |
| `seated_single_leg_hamstring_stretch` | `revisão_obrigatória` | 001 |
| `seated_supported_thoracic_extension` | `revisão_obrigatória` | 001, 004 |
| `single_leg_stance` | `revisão_obrigatória` | 001, 003 |
| `sled_resisted_sprint` | `revisão_obrigatória` | 001 |
| `sprint_to_controlled_stop` | `revisão_obrigatória` | 001, 002 |
| `standing_broad_jump` | `revisão_obrigatória` | 001 |
| `standing_gastrocnemius_wall_stretch` | `revisão_obrigatória` | 001, 005 |
| `standing_medicine_ball_chest_pass` | `revisão_obrigatória` | 001, 002 |
| `standing_multidirectional_weight_shift` | `bloqueado` | 001, 003, 007 |
| `standing_soleus_wall_stretch` | `revisão_obrigatória` | 001, 002, 005 |
| `static_rowing_ergometer` | `revisão_obrigatória` | 001, 002 |
| `stationary_arm_crank_ergometry` | `revisão_obrigatória` | 001, 004 |
| `supine_hamstring_strap_stretch` | `revisão_obrigatória` | 001, 004 |
| `supine_heel_slide` | `revisão_obrigatória` | 001 |
| `supine_self_assisted_hamstring_stretch` | `revisão_obrigatória` | 001 |
| `tandem_stance` | `revisão_obrigatória` | 001, 002, 003 |
| `tandem_walk` | `revisão_obrigatória` | 001, 003 |
| `treadmill_walking` | `revisão_obrigatória` | 001, 005 |
| `two_foot_rope_skipping` | `revisão_obrigatória` | 001, 005 |
| `two_point_sprint_start` | `revisão_obrigatória` | 001, 002, 005 |
| `upright_stationary_cycling` | `revisão_obrigatória` | 001, 004, 005 |
| `volleyball_forearm_pass_to_target` | `revisão_obrigatória` | 001, 002, 005 |

## Independência e zero implementação

TRANS-01 não foi autor de qualquer conteúdo auditado. A análise foi feita
independentemente sobre os 49 pares Markdown/JSON e usou apenas as sete auditorias
de capability autorizadas para triangulação. Não foram consultados outputs de
outros especialistas transversais.

Foi realizada **zero implementação**: nenhum JSON, Markdown de exercício, relatório
de investigação, registo canónico, relação, regra, código, configuração,
multimédia ou conteúdo de produto foi alterado. O único artefacto criado por
TRANS-01 foi este relatório.
