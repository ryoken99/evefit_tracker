# Relatório de pesquisa — `supine_self_assisted_hamstring_stretch`

**Agente:** EX-29  
**Data da pesquisa:** 2026-07-24  
**Idioma do conteúdo:** português europeu  
**Resultado:** conteúdo para principiantes aprovado com limites  
**Implementação realizada: não**

## Âmbito e decisão

Foi investigada apenas a execução documental do exercício canónico: deitado de costas, uma coxa elevada e sustentada pelas próprias mãos, seguida de extensão controlada do joelho. A pesquisa cobriu apoio manual, posição, respiração, segurança, sensação de alongamento, erros previsíveis e supervisão.

Não foram alterados a identidade, o risco operacional baixo, o equipamento, a superfície, a supervisão base ou as relações aprovadas. Não foi criada dose, prescrição, promessa, diagnóstico, tratamento, código, publicação ou aprovação multimédia.

A cobertura é defensável para instrução geral de principiantes porque a técnica exata tem apoio profissional direto e independente. O estado inclui limites porque a literatura primária encontrada sustenta sobretudo a família mecânica, a amplitude de extensão do joelho e aspetos biomecânicos próximos, não esta instrução manual exata em todas as populações.

## Elementos canónicos preservados

| Elemento | Decisão preservada |
|---|---|
| Identidade | Autoassistência pelas próprias mãos atrás da coxa; não parceiro, teste ou elevação balística |
| Mecânica | Flexão unilateral da anca com extensão controlada do joelho |
| Equipamento | Nenhum obrigatório; tapete de exercício opcional |
| Superfície | Estável e antiderrapante |
| Relação corpo-superfície | Tronco e perna contralateral apoiados |
| Risco | Baixo, sem redução por contexto |
| Supervisão | Nenhuma como requisito base |
| Relações | As duas relações aprovadas foram reproduzidas sem reclassificação |

## Pesquisa e síntese

### Execução e apoio manual

A AAOS descreve uma versão diretamente correspondente: posição deitada, pernas inicialmente fletidas, elevação de uma perna, mãos atrás da coxa abaixo do joelho e extensão da perna. A mesma fonte adverte para não colocar as mãos na articulação do joelho e puxar. A Cleveland Clinic confirma independentemente a posição deitada e o apoio das mãos atrás da coxa.

Decisão editorial: instruir ambas as mãos na parte posterior da coxa, acima da dobra do joelho; deixar claro que as mãos recebem o peso da perna e permitem aliviar imediatamente a força; proibir pressão direta sobre a articulação.

### Apoio da bacia e controlo

O registo canónico exige estabilização da bacia e da coluna lombar. A literatura primária de família usa posições supinas controladas e extensão do joelho como movimento ou medida relevante, mas não autoriza afirmar que uma posição pélvica específica produz um resultado superior nesta identidade.

Decisão editorial: manter bacia e costas apoiadas e tratar levantamento ou rotação da bacia como compensação observável. Corrigir reduzindo a amplitude, sem criar um alinhamento rígido ou diagnóstico postural.

### Respiração

A Mayo Clinic recomenda respirar durante o alongamento e manter o movimento suave e lento. Não foi encontrada necessidade específica de contagem, retenção ou padrão respiratório próprio para esta técnica.

Decisão editorial: respiração natural e contínua, sem retenção, contagem ou expiração forçada.

### Sensação esperada e limite

A AAOS localiza a sensação na parte posterior da coxa e atrás do joelho; a Mayo Clinic descreve uma tração ligeira e considera a dor sinal de amplitude excessiva. Como o registo canónico identifica pressão posterior no joelho e sintomas neurais como fatores de risco, foi adotada uma fronteira mais conservadora: tração suave e distribuída na parte posterior da coxa é esperada; pressão localizada atrás do joelho, dor, dormência, formigueiro, parestesia, sensação elétrica ou fraqueza súbita não são metas.

Reid e McNair estudaram a relação entre amplitude de extensão do joelho, força passiva, rigidez e tolerância ao alongamento. Isto sustenta que o limite percebido não deve ser convertido numa meta universal. Borrelli et al. observaram, em cadáveres, alterações de pressão intraneural do nervo ciático com posições combinadas da anca e do joelho; o estudo fornece apenas contexto biomecânico e não permite diagnóstico ou limiar de segurança individual.

### Erros

Foram documentados erros diretamente observáveis e corrigíveis:

- puxar pela articulação ou dobra do joelho;
- levantar ou rodar a bacia;
- forçar uma extensão rígida;
- usar balanço ou ressalto;
- prender a respiração e enrijecer pescoço ou ombros;
- interpretar formigueiro ou sensação elétrica como alongamento normal.

Cada erro inclui sinal de reconhecimento e correção sem dose.

### Supervisão

O requisito canónico de supervisão é `none`, e a pessoa controla a força com as próprias mãos. A AAOS enquadra o seu guia num programa de reabilitação sob supervisão médica; esse enquadramento não foi generalizado para todas as pessoas. Foi preservada a orientação canónica de procurar revisão quando historial, sintomas ou retorno após lesão/cirurgia alteram a elegibilidade.

Decisão editorial: sem supervisão base; orientação profissional quando faltam controlo, capacidade de saída ou distinção sensorial, ou quando fatores individuais relevantes exigem adaptação. Assistência humana é explicitamente excluída porque introduz força externa e muda a execução.

## Fontes existentes consideradas

| Código | Uso neste trabalho | Limite aplicado |
|---|---|---|
| `D1-EXT-03` | Evidência herdada da família de alongamento e amplitude | Não prova dose, efeito individual ou superioridade desta técnica |
| `D1-EXT-08` | Fonte profissional direta para execução e erro de puxar pelo joelho | Contexto de condicionamento do joelho; prescrição não importada |
| `D2-S05` | Taxonomia e princípios gerais de alongamento | Revisão de família, não instrução exata |
| `D2-S22` | Delimitação entre autoassistência e assistência humana | Não usada para introduzir parceiro ou força externa |

## Fontes externas consultadas

1. **American Academy of Orthopaedic Surgeons.** [Knee Conditioning Program — Supine Hamstring Stretch](https://www.orthoinfo.org/recovery/knee-conditioning-program/). Guia profissional oficial. Acesso em 2026-07-24.
2. **Mayo Clinic Staff.** [A guide to basic stretches](https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20546848). Guia clínico profissional. Acesso em 2026-07-24.
3. **Cleveland Clinic.** [Stretching: 9 Exercises and 8 Benefits](https://health.clevelandclinic.org/stretching). Conteúdo profissional revisto por especialista. Acesso em 2026-07-24.
4. **Decoster LC, Scanlon RL, Horn KD, Cleland J.** [Standing and Supine Hamstring Stretching Are Equally Effective](https://pubmed.ncbi.nlm.nih.gov/15592605/). *Journal of Athletic Training*. 2004;39(4):330-334. Ensaio aleatorizado. A variante supina estudada usou uma parede, pelo que o suporte é de família, não da técnica manual exata.
5. **Reid DA, McNair PJ.** [Passive force, angle, and stiffness changes after stretching of hamstring muscles](https://pubmed.ncbi.nlm.nih.gov/15514511/). *Medicine & Science in Sports & Exercise*. 2004;36(11):1944-1948. Ensaio controlado aleatorizado. Suporte para amplitude, força passiva e tolerância ao alongamento, sem generalização de protocolo.
6. **Borrelli J Jr, Kantor J, Ungacta F, Ricci W.** [Intraneural sciatic nerve pressures relative to the position of the hip and knee: a human cadaveric study](https://pubmed.ncbi.nlm.nih.gov/10898197/). *Journal of Orthopaedic Trauma*. 2000. Estudo biomecânico cadavérico; apenas contexto para cautela com sintomas neurais.

## Relações preservadas

1. `supine_self_assisted_hamstring_stretch__cooldown__flexibility__assisted_lengthening__release_perceived_tension`
   - estado: `conditional`
   - papel: `principal_candidate`
   - limite preservado: não demonstra recuperação futura; a posição deve permanecer confortável e reversível.

2. `supine_self_assisted_hamstring_stretch__main_training__flexibility__assisted_lengthening__increase_passive_range_of_motion`
   - estado: `compatible`
   - papel: `alternative_primary`
   - limite preservado: sem dose fixa; sintomas neurais exigem interrupção; não é teste clínico.

## Verificações de contrato

| Requisito | Resultado |
|---|---|
| Português europeu, UTF-8 NFC | Cumprido |
| Passos de execução | Oito |
| Pistas principais | Seis |
| Erros com reconhecimento e correção | Seis |
| Perguntas de compreensão | Doze |
| Duas ou mais fontes independentes | Cumprido |
| Literatura primária independente | Três estudos |
| Respiração documentada | Natural e contínua, sem retenção |
| Dose ou prescrição | Ausente |
| Promessa, diagnóstico ou tratamento | Ausentes |
| Alteração de identidade, risco, equipamento ou relações | Ausente |

## Limitações e confiança

Confiança global moderada: alta para a organização manual básica e moderada para linguagem de segurança e respiração. A generalização populacional é limitada. As fontes profissionais dão instrução direta, mas parte da investigação primária usa variantes ou populações diferentes. O conteúdo não substitui avaliação individual, não define elegibilidade clínica e não autoriza equipamento, parceiro ou força externa.
