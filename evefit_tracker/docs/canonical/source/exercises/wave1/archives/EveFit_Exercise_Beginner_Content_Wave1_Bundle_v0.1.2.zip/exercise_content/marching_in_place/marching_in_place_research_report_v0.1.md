# Relatório de investigação — Marcha no lugar

**Exercise ID:** `marching_in_place`  
**Agente:** EX-04  
**Data de fecho da pesquisa:** 2026-07-23  
**Âmbito:** execução, preparação, respiração, segurança, erros e supervisão  
**Fora do âmbito:** dose, prescrição, promessa de resultado, diagnóstico, tratamento, código, publicação, alteração de identidade, risco, equipamento ou relações
Implementação realizada: não

## Resultado

A cobertura é defensável para conteúdo dirigido a principiantes. Foram encontradas instruções diretas e convergentes para a marcha no lugar em vários prestadores clínicos independentes: posição de pé, alternância das pernas, regresso controlado do pé ao chão, amplitude confortável e recurso a uma superfície estável quando necessário. Uma fonte nacional do NHS acrescenta a coordenação dos braços com os passos e a manutenção das mãos descontraídas.

A segurança está sustentada por instruções clínicas gerais de exercício e pelo registo canónico fornecido. A respiração natural e contínua, sem retenção, tem apoio profissional geral, mas não foi encontrada uma recomendação respiratória primária dedicada especificamente à marcha no lugar. Por esse motivo, a confiança respiratória é moderada e o conteúdo não impõe qualquer padrão contado.

## Identidade e limites preservados

Não foram alterados:

- `exercise_id`: `marching_in_place`;
- nome: Marcha no lugar;
- tipo: exercício canónico;
- família: `stationary_rhythmic_locomotion_family`;
- capacidade principal: `cardio_conditioning`;
- risco operacional base: baixo;
- equipamento obrigatório: nenhum;
- necessidade de parceiro, spotter ou supervisão por defeito: nenhuma;
- superfície firme e regular e zona livre de obstáculos;
- quatro relações canónicas aprovadas ou condicionais.

A marcha no lugar permanece definida como elevação alternada dos pés sem deslocamento global e sem fase aérea nuclear. A descrição não converte velocidade, amplitude, duração ou contexto numa nova identidade.

## Método

A pesquisa foi limitada a fontes oficiais, profissionais ou clínicas. Foram priorizadas páginas e folhetos de organizações de saúde que descrevem diretamente a execução da marcha no lugar. As fontes gerais existentes foram mantidas para o enquadramento da família, mas não usadas para inventar técnica específica.

Critérios de transporte para o conteúdo:

- usar apenas instruções coincidentes com a identidade canónica;
- preferir linguagem de controlo e conforto quando as fontes variam na amplitude;
- separar apoio de segurança de equipamento obrigatório;
- não transportar dose, progressões programadas ou intensidade;
- não transformar sinais de alerta em diagnóstico;
- não reduzir o risco nem presumir elegibilidade.

## Fontes consultadas

### Fontes existentes no registo

1. **American Heart Association — Recommendations for Adults**  
   URL: https://www.heart.org/en/healthy-living/exercise-and-physical-activity/fitness-basics/aha-recs-for-physical-activity-in-adults  
   Utilidade: enquadramento geral de atividade aeróbia.  
   Limite: não fornece técnica específica para marcha no lugar; nenhuma dose foi transportada.

2. **YMCA — Foundations of Group Exercise**  
   URL: https://contentcdn.eacefitness.com/continuingeducation/courses/support_items/CERT-YMCA-FGE/YMCA_Group_Cert_Workbook.pdf  
   Utilidade: reconhece a marcha como bloco simples de exercício de grupo.  
   Limite: suporte ao nível da família e não de elegibilidade individual.

3. **U.S. Department of Health and Human Services — Physical Activity Guidelines for Americans, 2nd edition**  
   URL: https://health.gov/sites/default/files/2019-09/Physical_Activity_Guidelines_2nd_edition.pdf  
   Utilidade: enquadramento geral da atividade aeróbia e da adaptação.  
   Limite: não descreve a execução específica; recomendações de volume foram excluídas.

### Pesquisa técnica e de segurança

4. **NHS — How to warm up before exercising**  
   URL: https://www.nhs.uk/live-well/exercise/how-to-warm-up-before-exercising/  
   Acesso: 2026-07-23  
   Sustenta: marcha no lugar, coordenação dos braços com os passos, cotovelos dobrados e mãos descontraídas.  
   Limite: o contexto da página é aquecimento; a dose apresentada na fonte foi excluída.

5. **North Tees and Hartlepool NHS Foundation Trust — Standing Exercises**  
   URL: https://www.nth.nhs.uk/resources/standing-exercises/  
   Acesso: 2026-07-23  
   Sustenta: posição de pé, elevação alternada dos joelhos, regresso ao chão e superfície de apoio.  
   Limite: as progressões e a dose da página foram excluídas.

6. **University Hospitals Sussex NHS Foundation Trust — Standing Exercises**  
   URL: https://www.uhsussex.nhs.uk/resources/standing-exercises/  
   Acesso: 2026-07-23  
   Sustenta: apoio estável, joelho elevado até uma amplitude confortável, descida controlada e alternância das pernas.  
   Limite: material clínico geral; não estabelece técnica universal para todas as pessoas.

7. **Oxford University Hospitals NHS Foundation Trust — OTAGO Strength and Balance**  
   URL: https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf  
   Acesso: 2026-07-23  
   Sustenta: respiração normal durante o exercício, atenção à dor persistente e uso da marcha como preparação.  
   Limite: pertence a um programa específico; a dose foi excluída.

8. **Calderdale and Huddersfield NHS Foundation Trust — Home Exercise Programme Advanced**  
   URL: https://plr.cht.nhs.uk/download/909/Home%20Exercise%20Programme%20Advanced%20A4  
   Acesso: 2026-07-23  
   Sustenta: interrupção perante dor, falta de ar, tontura, mal-estar ou desconforto durante exercício.  
   Limite: apoio geral de segurança; não foi usado para diagnóstico ou tratamento.

## Síntese da execução

Os elementos com melhor suporte convergente são:

- posição de pé e postura direita;
- transferência alternada do apoio;
- elevação de um pé de cada vez;
- amplitude limitada pelo conforto e pelo controlo;
- regresso controlado do pé ao chão;
- alternância contínua sem deslocamento global;
- superfície estável ao alcance quando há incerteza ligeira de equilíbrio;
- braços em oposição às pernas apenas se a estabilidade estiver preservada;
- mãos e ombros descontraídos.

O requisito de manter pelo menos um pé no chão decorre diretamente da identidade canónica, que exclui uma fase aérea nuclear e distingue a marcha da corrida no lugar.

## Preparação e ambiente

O registo canónico exige uma pequena zona livre, superfície firme e regular e ausência de obstáculos. As fontes clínicas apoiam o uso de uma superfície firme para apoio quando necessário. A preparação pública acrescenta verificações simples e observáveis: piso seco e não escorregadio, boa iluminação, roupa sem interferência com os passos e espaço para os braços.

Não foi introduzido equipamento obrigatório. A superfície de apoio é descrita como adaptação de segurança, não como requisito da identidade.

## Respiração

A orientação adotada é respirar naturalmente e de forma contínua, sem retenção. Não se impõem contagens, sincronização com passos ou técnicas respiratórias especiais.

Esta formulação combina:

- a regra contratual de usar respiração natural e contínua quando não existe orientação específica;
- suporte profissional geral do programa OTAGO para respirar normalmente durante o exercício;
- ausência de evidência direta que justifique um padrão respiratório exclusivo para a marcha no lugar.

## Segurança e supervisão

O risco operacional base permanece baixo. Os principais riscos canónicos são obstáculos e irregularidades da superfície; fadiga e visibilidade reduzida podem aumentar o risco.

Sinais de interrupção preservados e explicados em linguagem pública:

- desconforto no peito ou falta de ar atípica;
- tontura, sensação de desmaio ou confusão;
- dor nova;
- perda de controlo ou instabilidade crescente.

A supervisão não é necessária por defeito. É indicada como consideração quando existe instabilidade marcada, incapacidade de alternar o apoio com controlo ou ambiente desconhecido. Um apoio fixo pode ajudar perante incerteza ligeira, mas não substitui supervisão quando há risco de queda.

## Erros documentados

Foram escolhidos erros observáveis e corrigíveis sem prescrição:

1. criar fase aérea e transformar a marcha em corrida ou salto;
2. elevar o joelho para além da amplitude controlável;
3. pousar o pé com impacto ou fora da zona de apoio;
4. deslocar-se pela divisão;
5. prender a respiração e acumular tensão nos ombros e mãos.

Cada erro inclui um sinal de reconhecimento e uma correção direta.

## Relações canónicas

As quatro relações foram preservadas:

- treino principal → condicionamento cardiorrespiratório → movimento rítmico repetitivo → desenvolver resistência aeróbia: compatível, alternativa principal;
- treino principal → condicionamento cardiorrespiratório → movimento rítmico repetitivo → aumentar resistência ao movimento repetitivo: compatível, alternativa principal;
- recuperação → condicionamento cardiorrespiratório → movimento rítmico repetitivo → retomar movimento rítmico suave após esforço: condicional, candidato principal;
- aquecimento → condicionamento cardiorrespiratório → movimento rítmico repetitivo → estabelecer ritmo de movimento: condicional, complementar.

Nenhuma relação nova foi criada. Os limites originais foram mantidos, incluindo a dependência de elegibilidade, conforto e técnica controlada, bem como a separação entre identidade e prescrição.

## Confiança e lacunas

| Área | Confiança | Fundamentação |
|---|---|---|
| Execução | Alta | Convergência entre fontes clínicas independentes e identidade canónica. |
| Preparação e apoio | Alta | Fontes clínicas diretas e requisitos ambientais canónicos. |
| Respiração | Moderada | Orientação profissional geral, mas não específica da marcha no lugar. |
| Segurança | Alta | Sinais canónicos e apoio de folhetos clínicos de exercício. |
| Supervisão | Moderada-alta | Coerência entre risco canónico, gatilhos de supervisão e uso profissional de apoio estável. |

Lacunas aceites:

- não foi encontrada uma norma biomecânica primária dedicada exclusivamente à marcha no lugar para principiantes;
- as fontes variam na altura sugerida para o joelho;
- não há base para impor um padrão respiratório específico;
- elegibilidade individual não pode ser determinada por este conteúdo.

Estas lacunas são resolvidas de forma conservadora: amplitude confortável e controlável, respiração natural e contínua, apoio estável quando necessário e encaminhamento para orientação adequada perante sintomas ou instabilidade marcada.

## Conclusão

O conteúdo pode ser classificado como `beginner_content_approved_with_limits`. Existe cobertura suficiente para uma instrução clara, específica e segura, desde que se mantenham os limites declarados e se excluam dose, prescrição, progressão individual, promessa de resultado, diagnóstico e tratamento.
