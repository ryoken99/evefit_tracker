# Balanço da perna à frente e atrás

Conteúdo para principiantes em português europeu.

## Descrição curta

Oscilação ativa e controlada de uma perna à frente e atrás, em apoio de pé.

## O que é

De pé sobre uma perna, moves a perna livre para a frente e para trás a partir da anca. Manténs o tronco e a pelve orientados e travas ativamente a perna antes de cada mudança de direção.

## O que vais fazer

Vais transferir o peso para a perna de apoio, libertar a outra perna e guiá-la num arco sagital controlado, alternando flexão e extensão da anca sem ressalto passivo.

## Porque existe este movimento

Este movimento permite praticar a entrada e a saída controladas da amplitude dinâmica das cadeias anterior e posterior da anca. A finalidade imediata é o controlo do arco e da mudança de direção, não alcançar uma amplitude máxima.

## Antes de começares

1. Escolhe uma superfície estável e antiderrapante.
2. Confirma que o espaço à frente e atrás da perna livre está desimpedido e sem trânsito de pessoas.
3. Se precisares de ajuda para o equilíbrio, coloca-te ao alcance de um apoio fixo ou independente que não deslize nem tombe.
4. Retira objetos baixos, cabos, tapetes soltos e outros obstáculos da trajetória.
5. Não inicies se não conseguires manter o apoio unipodal ou usar um apoio estável, compreender a ação e interrompê-la voluntariamente.

## Preparar o equipamento

1. Apoio estável independente.
2. O exercício pode ser realizado sem equipamento portátil. Se usares apoio, verifica primeiro que está imóvel, não tem rodas e suporta uma pressão ligeira da mão sem deslocar-se. Coloca o apoio ao lado da perna de sustentação, sem bloquear a trajetória da perna livre.

## Preparar o espaço

1. sim
2. sim
3. não
4. Espaço estacionário suficiente para executares o movimento com controlo.
5. Superfície firme, estável e antiderrapante.
6. Não utilizes piso escorregadio ou instável.
7. sim
8. Mantém livre a trajetória à frente e atrás da perna.
9. Não executes com trânsito ou pessoas a atravessar, obstáculos na trajetória ou piso escorregadio.
10. Reserva espaço livre à frente e atrás, incluindo margem para uma oscilação que pare antes de qualquer objeto. Mantém a zona bem iluminada e sem pessoas a atravessar a trajetória. No exterior, evita piso irregular, húmido, solto ou escorregadio e condições de frio que alterem a tolerância ao movimento.

## Verificação do corpo

1. Consegues ficar de pé com o peso sobre uma perna ou com a mão num apoio estável sem te desequilibrares?
2. Consegues levantar ligeiramente a outra perna e voltar a pousá-la de forma deliberada?
3. Consegues manter o tronco orientado enquanto fazes um arco curto com a perna livre?
4. Consegues parar a perna voluntariamente antes de ela atingir um obstáculo?
5. Se alguma resposta for negativa, não avances para o balanço livre; usa apoio adequado ou procura orientação qualificada.

## Posição inicial

Fica de pé, alto e orientado para a frente, com o peso centrado sobre uma perna. Mantém o pé de apoio totalmente assente numa superfície antiderrapante. Deixa o joelho de apoio destrancado. Se necessário, pousa uma mão num apoio estável. Liberta a outra perna sem inclinar o tronco.

## Confirmar a posição inicial

1. Pé de apoio estável e sem deslizar.
2. Peso centrado sobre a perna de apoio.
3. Joelho de apoio confortável, sem bloqueio rígido.
4. Tronco alto e orientado para a frente.
5. Pelve orientada, sem rodar para abrir a trajetória.
6. Mão pousada num apoio estável quando o equilíbrio o exigir.
7. Espaço livre confirmado à frente e atrás.

## Passos de execução

1. Transfere o peso para a perna de apoio e estabiliza o pé, a anca de apoio e o tronco.
2. Move a perna livre ligeiramente para a frente a partir da anca, usando um arco que consigas travar com facilidade.
3. Desacelera ativamente a perna antes do limite disponível, sem a deixar saltar nem procurar amplitude adicional por impulso.
4. Guia a mesma perna para trás a partir da anca, mantendo o peito alto e a zona lombar sem arqueamento marcado.
5. Desacelera a perna antes de a pelve inclinar ou a lombar compensar e muda novamente de direção com controlo.
6. Continua a alternar frente e trás num movimento fluido, ativo e autocontrolado. Mantém apenas a amplitude em que o pé de apoio, o tronco e a pelve permanecem organizados.
7. Reduz o arco, imobiliza a perna livre sob o teu controlo e pousa o pé junto ao pé de apoio.

## Fases do movimento

### Apoio e libertação

O peso fica sobre uma perna e a outra fica livre para se mover.

### Balanço e travagem à frente

A anca conduz a perna para a frente e os músculos desaceleram-na antes da mudança de direção.

### Balanço e travagem atrás

A anca conduz a perna para trás enquanto o tronco e a pelve permanecem orientados; a perna é travada antes de regressar.

### Saída controlada

O arco diminui e o pé regressa ao chão sem perda de equilíbrio.

## Respiração

Respira de forma natural, contínua e regular durante todo o movimento. — Não existe uma fase respiratória obrigatória para o balanço. Deixa a inspiração e a expiração acompanhar o ritmo confortável do movimento. — Não prendas a respiração nem imponhas contagens ou retenções.

## Sensações esperadas

1. Trabalho de equilíbrio no pé, na anca e no tronco do lado de apoio.
2. Ação muscular na frente e atrás da anca da perna livre.
3. Sensação ligeira e transitória de alongamento atrás da coxa quando a perna avança ou à frente da anca quando recua.
4. Esforço de travagem nas mudanças de direção, sem impacto.

## Sensações inesperadas ou de alerta

1. Dor aguda ou dor que aumenta durante o movimento.
2. Dormência, formigueiro, alteração de sensibilidade ou fraqueza súbita.
3. Tontura, mal-estar ou falta de ar fora do habitual.
4. Sensação de que a perna foge ao controlo ou de que o pé de apoio vai deslizar.
5. Puxão abrupto, estalido acompanhado de dor ou incapacidade de pousar o pé com controlo.

## Indicações técnicas principais

1. Confirma espaço livre à frente e atrás.
2. Usa apoio de mão se o equilíbrio o exigir.
3. Mantém o peito alto e a pelve orientada.
4. Move a perna a partir da anca.
5. Trava cada mudança de direção; não procures amplitude por impulso.
6. Respira livremente, sem prender a respiração.

## Erros comuns e correções

### Erro 1: Deixar o impulso aumentar o arco.

- Como reconhecer: A perna acelera de ciclo para ciclo, a mudança de direção fica brusca ou já não consegues pará-la no ponto escolhido.
- Como corrigir: Reduz o arco e recupera uma travagem deliberada em cada extremidade.

### Erro 2: Inclinar o peito para trás quando a perna avança.

- Como reconhecer: Os ombros recuam para criar altura aparente na perna.
- Como corrigir: Mantém o tronco alto e aceita uma amplitude frontal menor.

### Erro 3: Inclinar o peito para a frente quando a perna recua.

- Como reconhecer: O tronco funciona como contrapeso e deixa de permanecer orientado.
- Como corrigir: Reduz o arco posterior e move a perna a partir da anca sem deixar o peito cair.

### Erro 4: Arquear a zona lombar para levar a perna mais atrás.

- Como reconhecer: A pelve inclina-se para a frente e a extensão parece vir das costas em vez da anca.
- Como corrigir: Mantém as costelas sobre a pelve e termina o arco posterior antes da compensação lombar.

### Erro 5: Rodar a pelve ou desviar a perna para o lado.

- Como reconhecer: A ponta do pé e a bacia abrem para fora e a trajetória deixa de ser à frente e atrás.
- Como corrigir: Orienta a pelve para a frente e encurta o arco até a perna permanecer no plano sagital.

### Erro 6: Usar um apoio instável ou não verificar o espaço.

- Como reconhecer: O apoio mexe, roda ou desliza, ou a perna aproxima-se de objetos e pessoas.
- Como corrigir: Pára, escolhe um apoio firme e volta a libertar toda a trajetória antes de retomar.

## Formas de simplificar ou ensaiar

1. Usa uma mão num apoio estável para reduzir a exigência de equilíbrio sem alterar a identidade do exercício.
2. Mantém um arco curto em que a travagem seja evidente e o tronco permaneça orientado.
3. Pousa o pé entre tentativas se precisares de reorganizar o apoio; não transformes a instabilidade numa oscilação descontrolada.
4. Se não consegues manter o plano à frente e atrás, volta à posição inicial e reinicia com menor amplitude.

## Supervisão

A identidade canónica não exige parceiro, observador nem supervisão. Um principiante pode usar apoio estável de mão. — Existe historial de lesão ou cirurgia, doença crónica relevante ou retorno funcional. Há sintomas ou limitações que alteram a capacidade de apoiar, travar ou interromper o movimento. Pretende-se amplitude extrema, assistência humana ou uma primeira exposição que seja complexa para a pessoa. A pessoa não consegue executar com segurança mesmo usando um apoio estável.

## Como terminar

Para terminar, diminui progressivamente o arco enquanto manténs a travagem ativa. Imobiliza a perna livre, pousa o pé ao lado do pé de apoio e só depois larga o suporte ou muda de posição.

## Nota de segurança

Risco operacional moderado: o principal perigo é perder o equilíbrio, ganhar impulso excessivo ou colidir com o espaço envolvente. Usa uma superfície estável e antiderrapante, garante uma trajetória livre e interrompe perante perda de controlo, dor aguda ou incapacidade de travar a perna.

## Quando parar ou reduzir

1. Dor aguda ou crescente.
2. Dormência, parestesia ou fraqueza súbita.
3. Incapacidade de travar a perna dentro do espaço disponível.
4. Perda de controlo, instabilidade ou mal-estar.
5. Alteração do padrão que não se resolve ao reduzir o arco.

## Segurança do equipamento

Nenhum equipamento portátil é obrigatório. — O apoio estável é opcional e serve apenas para a mão; não deve puxar, empurrar ou acelerar a perna. — Não usar cadeiras com rodas, móveis leves, portas soltas ou objetos que possam tombar. Não colocar o apoio na trajetória da perna livre. Não adicionar carga externa, elásticos ou assistência humana a este conteúdo de principiante.

## Segurança do espaço

Usa uma superfície estável, nivelada e antiderrapante. — Mantém livre toda a trajetória sagital da perna, com margem adicional para travar. — Superfícies escorregadias ou instáveis. Percursos obstruídos. Zonas de trânsito ativo. Frio ou outras condições ambientais que reduzam a tolerância ou o controlo.

## Limitações

1. Implementação realizada: não
2. Conteúdo documental para principiante; não constitui prescrição individual, diagnóstico, tratamento ou autorização universal.
3. Não define dose, velocidade, cadência, frequência, intensidade, progressão programada ou amplitude individual.
4. A evidência apoia sobretudo a família do alongamento dinâmico e uma mecânica próxima; não prova resultados individuais.
5. O estudo primário direto incluiu uma amostra pequena de adultos mais velhos e condições laboratoriais, pelo que a generalização é limitada.
6. O apoio opcional, o risco moderado, a ausência de parceiro ou observador obrigatório e as três relações aprovadas foram preservados sem alteração.

## Teste de compreensão

### 1. Em que direção deve mover-se a perna livre?

Resposta esperada: À frente e atrás, num arco sagital.

### 2. Onde fica o peso principal durante o balanço?

Resposta esperada: Sobre a perna de apoio, com o pé estável no chão.

### 3. Quando deves usar a mão num apoio?

Resposta esperada: Quando o equilíbrio o exigir, usando uma superfície firme que não deslize nem tombe.

### 4. Que verificação ambiental é indispensável antes de começar?

Resposta esperada: Confirmar superfície antiderrapante e espaço livre à frente e atrás, sem obstáculos nem trânsito.

### 5. Como escolhes a amplitude inicial?

Resposta esperada: Escolho um arco que consiga travar facilmente sem mover o tronco ou rodar a pelve.

### 6. Como sabes que a amplitude ou o impulso são excessivos?

Resposta esperada: Deixo de conseguir travar no ponto escolhido, inclino o tronco, rodo a pelve ou arqueio a lombar.

### 7. O que deve acontecer em cada mudança de direção?

Resposta esperada: A perna deve desacelerar e ser travada ativamente, sem ressalto.

### 8. Como deve ficar o peito quando a perna avança e recua?

Resposta esperada: Alto e orientado, sem cair para a frente nem recuar.

### 9. Como deves respirar?

Resposta esperada: De forma natural, contínua e regular, sem prender a respiração.

### 10. Que sensações podem ser esperadas?

Resposta esperada: Trabalho de equilíbrio e de travagem, com possível alongamento ligeiro e transitório à frente da anca ou atrás da coxa, sem dor.

### 11. Que sinais obrigam a reduzir ou terminar?

Resposta esperada: Dor aguda ou crescente, dormência, parestesia, fraqueza súbita, mal-estar, instabilidade ou incapacidade de travar a perna.

### 12. Como terminas o exercício com controlo?

Resposta esperada: Reduzo o arco, imobilizo a perna, pouso o pé junto ao pé de apoio e só depois largo o suporte.

## Fontes e limites da evidência

### Fonte 1: Behm DG et al. Acute effects of muscle stretching on physical performance, range of motion, and injury incidence in healthy active individuals. 2016.

- Autor ou entidade: D1-EXT-04/D2-S07 — Behm DG et al. Acute effects of muscle stretching on physical performance, range of motion, and injury incidence in healthy active individuals. 2016. — revisão sistemática — https://pubmed.ncbi.nlm.nih.gov/26642915/ — Delimitação prudente do alongamento dinâmico e proibição de promessas universais de desempenho ou prevenção. — Evidência de família; não é instrução direta para este exercício.
- Tipo: revisão sistemática
- Localizador: https://pubmed.ncbi.nlm.nih.gov/26642915/
- Usada para: Delimitação prudente do alongamento dinâmico e proibição de promessas universais de desempenho ou prevenção.
- Limite: D1-EXT-04/D2-S07 — Behm DG et al. Acute effects of muscle stretching on physical performance, range of motion, and injury incidence in healthy active individuals. 2016. — revisão sistemática — https://pubmed.ncbi.nlm.nih.gov/26642915/ — Delimitação prudente do alongamento dinâmico e proibição de promessas universais de desempenho ou prevenção. — Evidência de família; não é instrução direta para este exercício.

### Fonte 2: Opplert J, Babault N. Acute Effects of Dynamic Stretching on Muscle Flexibility and Performance. 2018.

- Autor ou entidade: D2-S08 — Opplert J, Babault N. Acute Effects of Dynamic Stretching on Muscle Flexibility and Performance. 2018. — revisão — https://pubmed.ncbi.nlm.nih.gov/29063454/ — Enquadramento do movimento dinâmico controlado e do uso em preparação. — Não define sozinho a técnica específica do balanço.
- Tipo: revisão
- Localizador: https://pubmed.ncbi.nlm.nih.gov/29063454/
- Usada para: Enquadramento do movimento dinâmico controlado e do uso em preparação.
- Limite: D2-S08 — Opplert J, Babault N. Acute Effects of Dynamic Stretching on Muscle Flexibility and Performance. 2018. — revisão — https://pubmed.ncbi.nlm.nih.gov/29063454/ — Enquadramento do movimento dinâmico controlado e do uso em preparação. — Não define sozinho a técnica específica do balanço.

### Fonte 3: Matsuo S et al. Acute Effects of Dynamic and Ballistic Stretching on Flexibility. 2025.

- Autor ou entidade: D1-EXT-24 — Matsuo S et al. Acute Effects of Dynamic and Ballistic Stretching on Flexibility. 2025. — revisão sistemática e meta-análise — https://pubmed.ncbi.nlm.nih.gov/40469856/ — Distinção entre movimento dinâmico controlado e movimento balístico com velocidade elevada e ressalto. — A síntese reúne vários exercícios e não valida uma dose ou resultado individual.
- Tipo: revisão sistemática e meta-análise
- Localizador: https://pubmed.ncbi.nlm.nih.gov/40469856/
- Usada para: Distinção entre movimento dinâmico controlado e movimento balístico com velocidade elevada e ressalto.
- Limite: D1-EXT-24 — Matsuo S et al. Acute Effects of Dynamic and Ballistic Stretching on Flexibility. 2025. — revisão sistemática e meta-análise — https://pubmed.ncbi.nlm.nih.gov/40469856/ — Distinção entre movimento dinâmico controlado e movimento balístico com velocidade elevada e ressalto. — A síntese reúne vários exercícios e não valida uma dose ou resultado individual.

### Fonte 4: American Academy of Orthopaedic Surgeons. Hockey Injury Prevention.

- Autor ou entidade: D2-S27 — American Academy of Orthopaedic Surgeons. Hockey Injury Prevention. — orientação profissional oficial — https://www.orthoinfo.org/staying-healthy/hockey-injury-prevention/ — Confirma os balanços de perna como exemplo de alongamento dinâmico em preparação. — Contexto desportivo; não prova prevenção nem fornece técnica detalhada.
- Tipo: orientação profissional oficial
- Localizador: https://www.orthoinfo.org/staying-healthy/hockey-injury-prevention/
- Usada para: Confirma os balanços de perna como exemplo de alongamento dinâmico em preparação.
- Limite: D2-S27 — American Academy of Orthopaedic Surgeons. Hockey Injury Prevention. — orientação profissional oficial — https://www.orthoinfo.org/staying-healthy/hockey-injury-prevention/ — Confirma os balanços de perna como exemplo de alongamento dinâmico em preparação. — Contexto desportivo; não prova prevenção nem fornece técnica detalhada.

### Fonte 5: U.S. Marine Corps Training and Education Command. Sagittal Leg Swing. 2017.

- Autor ou entidade: EX32-R01 — U.S. Marine Corps Training and Education Command. Sagittal Leg Swing. 2017. — instrução técnica oficial — https://www.dvidshub.net/video/551823/sagittal-leg-swing — Apoio de mão em parede ou superfície estável, trajetória à frente e atrás e erro de inclinar o peito. — Demonstração breve para população militar; foi adaptada a linguagem de principiante sem adotar amplitude máxima.
- Tipo: instrução técnica oficial
- Localizador: https://www.dvidshub.net/video/551823/sagittal-leg-swing
- Usada para: Apoio de mão em parede ou superfície estável, trajetória à frente e atrás e erro de inclinar o peito.
- Limite: EX32-R01 — U.S. Marine Corps Training and Education Command. Sagittal Leg Swing. 2017. — instrução técnica oficial — https://www.dvidshub.net/video/551823/sagittal-leg-swing — Apoio de mão em parede ou superfície estável, trajetória à frente e atrás e erro de inclinar o peito. — Demonstração breve para população militar; foi adaptada a linguagem de principiante sem adotar amplitude máxima.

### Fonte 6: The University of Kansas Health System. Dynamic Stretching Exercises.

- Autor ou entidade: EX32-R02 — The University of Kansas Health System. Dynamic Stretching Exercises. — orientação profissional hospitalar — https://www.kansashealthsystem.com/news-room/blog/0001/01/dynamic-stretching-exercises — Arcos inicialmente pequenos, aumento apenas conforme tolerado, controlo e conforto. — Orientação geral, sem análise biomecânica específica.
- Tipo: orientação profissional hospitalar
- Localizador: https://www.kansashealthsystem.com/news-room/blog/0001/01/dynamic-stretching-exercises
- Usada para: Arcos inicialmente pequenos, aumento apenas conforme tolerado, controlo e conforto.
- Limite: EX32-R02 — The University of Kansas Health System. Dynamic Stretching Exercises. — orientação profissional hospitalar — https://www.kansashealthsystem.com/news-room/blog/0001/01/dynamic-stretching-exercises — Arcos inicialmente pequenos, aumento apenas conforme tolerado, controlo e conforto. — Orientação geral, sem análise biomecânica específica.

### Fonte 7: Zhou WS, Lin JH, Chen SC, Chien KY. Effects of Dynamic Stretching with Different Loads on Hip Joint Range of Motion in the Elderly. 2019.

- Autor ou entidade: EX32-R03 — Zhou WS, Lin JH, Chen SC, Chien KY. Effects of Dynamic Stretching with Different Loads on Hip Joint Range of Motion in the Elderly. 2019. — estudo primário aleatorizado de medidas repetidas — https://www.jssm.org/researchjssm-18-52.xml.xml — Documenta apoio centrado numa perna, mão no encosto de uma cadeira para equilíbrio e oscilação dinâmica de flexão e extensão da anca. — Amostra pequena de adultos mais velhos e protocolo laboratorial; os resultados não foram convertidos em dose, promessa ou autorização universal. As condições com carga não foram transpostas para o conteúdo.
- Tipo: estudo primário aleatorizado de medidas repetidas
- Localizador: https://www.jssm.org/researchjssm-18-52.xml.xml
- Usada para: Documenta apoio centrado numa perna, mão no encosto de uma cadeira para equilíbrio e oscilação dinâmica de flexão e extensão da anca.
- Limite: EX32-R03 — Zhou WS, Lin JH, Chen SC, Chien KY. Effects of Dynamic Stretching with Different Loads on Hip Joint Range of Motion in the Elderly. 2019. — estudo primário aleatorizado de medidas repetidas — https://www.jssm.org/researchjssm-18-52.xml.xml — Documenta apoio centrado numa perna, mão no encosto de uma cadeira para equilíbrio e oscilação dinâmica de flexão e extensão da anca. — Amostra pequena de adultos mais velhos e protocolo laboratorial; os resultados não foram convertidos em dose, promessa ou autorização universal. As condições com carga não foram transpostas para o conteúdo.

### Fonte 8: National Institute on Aging. Three Types of Exercise Can Improve Your Health and Physical Ability.

- Autor ou entidade: EX32-R04 — National Institute on Aging. Three Types of Exercise Can Improve Your Health and Physical Ability. — orientação oficial de saúde pública — https://www.nia.nih.gov/health/exercise-and-physical-activity/three-types-exercise-can-improve-your-health-and-physical — Sustenta a disponibilidade de cadeira robusta, parede ou pessoa próxima em tarefas de equilíbrio. — Orientação geral para equilíbrio, não específica para o balanço da perna.
- Tipo: orientação oficial de saúde pública
- Localizador: https://www.nia.nih.gov/health/exercise-and-physical-activity/three-types-exercise-can-improve-your-health-and-physical
- Usada para: Sustenta a disponibilidade de cadeira robusta, parede ou pessoa próxima em tarefas de equilíbrio.
- Limite: EX32-R04 — National Institute on Aging. Three Types of Exercise Can Improve Your Health and Physical Ability. — orientação oficial de saúde pública — https://www.nia.nih.gov/health/exercise-and-physical-activity/three-types-exercise-can-improve-your-health-and-physical — Sustenta a disponibilidade de cadeira robusta, parede ou pessoa próxima em tarefas de equilíbrio. — Orientação geral para equilíbrio, não específica para o balanço da perna.

### Fonte 9: American Heart Association. Getting Active to Control High Blood Pressure. Revisto em 2025.

- Autor ou entidade: EX32-R05 — American Heart Association. Getting Active to Control High Blood Pressure. Revisto em 2025. — orientação profissional oficial — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Respiração regular durante aquecimento, exercício e retorno à calma, sem retenção. — A indicação respiratória é geral e não estabelece sincronização específica para este movimento.
- Tipo: orientação profissional oficial
- Localizador: https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure
- Usada para: Respiração regular durante aquecimento, exercício e retorno à calma, sem retenção.
- Limite: EX32-R05 — American Heart Association. Getting Active to Control High Blood Pressure. Revisto em 2025. — orientação profissional oficial — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Respiração regular durante aquecimento, exercício e retorno à calma, sem retenção. — A indicação respiratória é geral e não estabelece sincronização específica para este movimento.
