# Subida contínua de escadas

Conteúdo para principiantes em português europeu.

## Descrição curta

Subida repetida de degraus fixos, com alternância dos apoios e ganho real de altura.

## O que é

É uma locomoção ascendente numa escada real: um pé apoia-se num degrau, o corpo sobe e o outro pé avança para o degrau seguinte. A ação repete-se de forma alternada até chegar a um patamar seguro.

## O que vais fazer

Vais subir degraus fixos consecutivos, transferindo o peso de uma perna para a outra e mantendo o corpo controlado. A descida, as escadas móveis e as máquinas de escadas não fazem parte deste exercício.

## Porque existe este movimento

Este exercício representa a tarefa locomotora específica de ganhar altura através de degraus reais. Pode integrar contextos aprovados de locomoção cíclica ou de movimento rítmico repetitivo, mas o conteúdo não define dose, intensidade, ritmo nem resultado individual.

## Antes de começares

1. Confirma que consegues manter-te de pé e transferir o apoio alternadamente sem perda marcada de equilíbrio.
2. Observa toda a escada e identifica um patamar de chegada livre e seguro.
3. Não comeces se os degraus estiverem molhados, escorregadios, danificados, irregulares, mal iluminados ou obstruídos.
4. Mantém as mãos livres; não leves objetos que tapem a visão dos degraus ou impeçam o uso do corrimão.
5. Se regressas após lesão ou cirurgia, tens sintomas cardiorrespiratórios relevantes, instabilidade marcada ou dúvidas sobre a tua capacidade de usar a escada, procura avaliação e supervisão adequadas antes de tentar.

## Preparar o equipamento

1. Não é necessário equipamento.
2. O corrimão é uma característica opcional do local, não equipamento obrigatório do exercício.
3. Se pretendes usar o corrimão, confirma antes de começares que está firme, contínuo e ao teu alcance; não uses um corrimão solto.

## Preparar o espaço

1. Usa apenas degraus fixos, uniformes, íntegros e com boa aderência.
2. Garante iluminação suficiente para distinguir cada degrau e a respetiva borda.
3. Retira objetos do percurso e mantém livres a entrada, a escada e o patamar de saída.
4. Em escadas exteriores, verifica se há água, gelo, folhas, areia ou outros fatores que reduzam a aderência.
5. Não uses escadas móveis, muito íngremes, curvas, danificadas ou com dimensões irregulares para esta execução de principiante.

## Verificação do corpo

1. Consegues ficar estável junto ao primeiro degrau sem te agarrares de forma desesperada?
2. Consegues elevar alternadamente cada pé o suficiente para ultrapassar a borda do degrau?
3. Consegues ver claramente os degraus seguintes e o patamar de chegada?
4. Estás sem desconforto no peito, falta de ar atípica, tonturas, confusão, dor nova ou perda de controlo?
5. Se alguma resposta for não, não inicies sem corrigir o ambiente ou obter a ajuda apropriada.

## Posição inicial

Fica de pé junto ao primeiro degrau, orientado para cima, com os pés estáveis, o tronco naturalmente direito e o olhar dirigido para os degraus imediatamente à frente. Se fores usar um corrimão seguro, coloca uma mão nele sem puxar o corpo pelo braço.

## Confirmar a posição inicial

1. Escada fixa, uniforme, seca, iluminada e sem obstáculos.
2. Patamar de chegada visível e desimpedido.
3. Pés estáveis junto ao primeiro degrau.
4. Corpo orientado para cima e visão livre dos degraus.
5. Mãos livres; corrimão firme verificado quando for usado.
6. Ausência de sinais de interrupção antes do início.

## Passos de execução

1. Olha para o primeiro degrau e para os degraus imediatamente seguintes, confirmando a zona onde cada pé vai pousar.
2. Eleva um pé o suficiente para não tocar na borda e coloca-o de forma completa, centrada e estável na área útil do primeiro degrau.
3. Transfere o peso para esse pé e estende de forma controlada a anca, o joelho e o tornozelo para elevar o corpo.
4. Liberta o pé que ficou atrás, eleva-o para ultrapassar a borda e coloca-o de forma estável no degrau seguinte.
5. Continua a alternar os apoios, usando um degrau consecutivo por passo e mantendo o tronco controlado sobre a base de apoio.
6. Mantém o olhar nos degraus próximos, sem usar o telemóvel, virar a cabeça para trás ou deixar que objetos tapem o percurso.
7. Respira de forma natural e contínua; evita prender a respiração e deixa a expiração acompanhar o esforço de subida se isso for confortável.
8. Ao chegar ao topo, coloca ambos os pés no patamar, recupera uma posição estável e só depois termina ou muda de direção.

## Fases do movimento

### Preparação

Verifica a escada, o patamar de saída, a visibilidade e o apoio opcional do corrimão.

### Colocação do pé

O pé avança, ultrapassa a borda e pousa de forma completa e estável no degrau.

### Propulsão

O peso passa para o pé apoiado e o corpo desloca-se para a frente e para cima.

### Transferência alternada

O pé de trás deixa o apoio e avança para o degrau seguinte, mantendo a alternância.

### Continuidade

As fases de colocação, propulsão e transferência repetem-se sem perder o controlo.

### Saída

A execução termina com ambos os pés estabilizados num patamar seguro.

## Respiração

Mantém uma respiração natural e contínua durante toda a subida. Não prendas a respiração. Se for confortável, deixa a expiração acompanhar a fase em que elevas o corpo; não é obrigatório sincronizar cada respiração com um número de degraus. Se a respiração se tornar atípica, desproporcionada ou difícil de controlar, interrompe em posição estável e pede ajuda.

## Sensações esperadas

1. A respiração e o batimento cardíaco podem tornar-se mais percetíveis.
2. Pode surgir trabalho muscular nas pernas, sobretudo ao elevar o corpo.
3. É possível sentir transferência alternada do peso e necessidade de controlar o equilíbrio em cada apoio.
4. Estas sensações devem continuar compatíveis com controlo do corpo, visão clara dos degraus e respiração contínua.

## Sensações inesperadas ou de alerta

1. Desconforto no peito.
2. Falta de ar atípica ou que não permite recuperar controlo.
3. Tonturas, sensação de desmaio ou confusão.
4. Dor nova ou agravamento súbito de dor.
5. Tropeção, falha repetida na colocação do pé ou perda de controlo.
6. Qualquer sensação que impeça ver, apoiar ou avançar com segurança.

## Indicações técnicas principais

1. Vê o próximo degrau antes de mover o pé.
2. Eleva o pé para limpar a borda.
3. Assenta o pé de forma completa e estável.
4. Sobe o corpo com controlo, sem te lançares.
5. Alterna os apoios e mantém a respiração contínua.
6. Chega ao patamar antes de parar ou virar.

## Erros comuns e correções

### Erro 1: Começar sem verificar a escada e o patamar de chegada.

- Como reconhecer: Existem zonas molhadas, degraus danificados, pouca luz, objetos no percurso ou uma saída ocupada.
- Como corrigir: Não comeces até a escada estar seca, íntegra, iluminada e livre desde a entrada até ao patamar.

### Erro 2: Pousar apenas a ponta do pé ou demasiado perto da borda.

- Como reconhecer: O calcanhar fica muito fora do degrau, o pé desliza ou sentes que o apoio é pequeno e incerto.
- Como corrigir: Eleva melhor o pé e coloca-o mais dentro da área útil, de forma completa e centrada. Se o degrau não permitir apoio seguro, não uses essa escada.

### Erro 3: Apressar a alternância ou saltar degraus.

- Como reconhecer: O pé seguinte move-se antes de o apoio atual estar estável, a colocação torna-se ruidosa ou falhas a borda.
- Como corrigir: Recupera controlo sobre o pé apoiado e usa degraus consecutivos, sem perseguir velocidade.

### Erro 4: Olhar para o telemóvel, para trás ou para longe da zona de apoio.

- Como reconhecer: Deixas de ver claramente os degraus seguintes ou ajustas o pé tarde.
- Como corrigir: Mantém a visão livre e dirige o olhar para os degraus próximos e para o patamar.

### Erro 5: Usar o corrimão para puxar o corpo com força ou confiar num corrimão não verificado.

- Como reconhecer: O braço faz a maior parte do movimento, o tronco roda para o lado ou o corrimão mexe.
- Como corrigir: Usa apenas um corrimão firme como apoio de equilíbrio adequado à adaptação; mantém o impulso principal nas pernas e não continues com um corrimão solto.

### Erro 6: Parar, virar ou tentar descer antes de alcançar o patamar.

- Como reconhecer: Ficas atravessado na escada, viras os pés num degrau ou perdes a orientação de subida.
- Como corrigir: Mantém a orientação para cima e termina com ambos os pés num patamar livre. Trata a descida como uma tarefa separada.

## Formas de simplificar ou ensaiar

1. Escolhe uma escada familiar, reta, bem iluminada, com degraus uniformes e patamar amplo.
2. Mantém uma mão livre e usa um corrimão firme quando essa adaptação aumentar a estabilidade.
3. Elimina distrações e garante que ninguém entra no percurso durante a execução.
4. Se não consegues manter a alternância e o controlo, não improvises uma técnica diferente; pede supervisão e uma adaptação apropriada.

## Supervisão

A supervisão é recomendada, sobretudo na primeira aprendizagem, numa escada desconhecida ou quando existe insegurança. É particularmente importante perante instabilidade marcada, limitação de equilíbrio, regresso após lesão ou cirurgia, sedentarismo prévio relevante ou sintomas cardiorrespiratórios que exijam revisão. Quem supervisiona deve confirmar o percurso, a colocação do pé, o controlo da transferência de peso, o uso seguro do corrimão e a chegada ao patamar. A pessoa que supervisiona não deve bloquear a escada nem puxar o praticante; deve manter-se numa posição que permita prestar ajuda sem criar outro obstáculo. Não é exigido um assistente de segurança para todas as pessoas, mas a elegibilidade e o contexto podem aumentar a necessidade de supervisão.

## Como terminar

Continua orientado para cima até alcançar um patamar seguro. Coloca ambos os pés no patamar e confirma que estás estável antes de parares, virares ou largares o corrimão. Deixa a respiração regressar naturalmente, sem a prender. A descida não integra esta identidade; planeia-a como uma tarefa separada e segura.

## Nota de segurança

O risco operacional é moderado porque um passo em falso pode causar queda de altura. A segurança depende de degraus fixos e uniformes, boa aderência, iluminação, percurso livre, colocação controlada do pé e saída segura. Não uses escadas móveis, danificadas, escorregadias ou irregulares.

## Quando parar ou reduzir

1. Desconforto no peito ou falta de ar atípica.
2. Tonturas, sensação de desmaio ou confusão.
3. Perda de controlo, tropeção ou falha repetida na colocação do pé.
4. Dor nova ou agravamento súbito de dor.
5. Alteração do ambiente, como derrame, obstáculo, pouca luz ou circulação inesperada.
6. Perante estes sinais, não forces a continuação: estabiliza-te, usa um corrimão firme se estiver ao alcance e pede ajuda apropriada.

## Segurança do equipamento

Não há equipamento obrigatório. O corrimão, quando usado, deve estar firme, contínuo e acessível. Não substituas o corrimão por móveis, paredes instáveis ou objetos transportados. Não transportes cargas nem objetos que ocupem as duas mãos, tapem os degraus ou alterem o equilíbrio.

## Segurança do espaço

Degraus fixos, uniformes, íntegros e antiderrapantes. Boa iluminação, com bordas dos degraus distinguíveis. Entrada, degraus e patamar sem obstáculos. Ausência de água, gelo, folhas, areia, cabos ou revestimentos soltos. Sem escadas móveis, muito íngremes, curvas, abertas ou irregulares para a execução inicial. Circulação de outras pessoas controlada para evitar choques ou ultrapassagens.

## Limitações

1. Não define dose, intensidade, cadência, velocidade, duração, distância, carga, descanso ou progressão.
2. Não autoriza automaticamente qualquer pessoa a executar e não substitui avaliação profissional quando há sintomas, instabilidade ou regresso após lesão ou cirurgia.
3. A investigação sobre técnica de subida inclui estudos laboratoriais e populações específicas; não existe uma única sequência pedagógica universal validada para todos os principiantes.
4. O corrimão é opcional na identidade, embora possa ser necessário como adaptação individual ou medida ambiental.
5. A descida, os degraus móveis, a escada rotativa, o stepper e o trepador vertical ficam fora do âmbito.
6. As relações canónicas, o risco moderado, o equipamento e o ambiente foram preservados sem alteração.

## Teste de compreensão

### 1. Qual é a característica que distingue esta subida de uma máquina de escadas?

Resposta esperada: Há degraus fixos e ganho real de altura do corpo.

### 2. Que condições deves confirmar antes de começares?

Resposta esperada: Degraus fixos, uniformes, secos, íntegros, bem iluminados, sem obstáculos e com patamar de saída seguro.

### 3. Onde deves pousar o pé em cada degrau?

Resposta esperada: De forma completa, centrada e estável na área útil do degrau.

### 4. O que deves fazer para não prender a ponta do pé na borda?

Resposta esperada: Elevar o pé o suficiente antes de o avançar.

### 5. Como se organizam os apoios durante a subida contínua?

Resposta esperada: Alternam-se de um degrau consecutivo para o seguinte.

### 6. É necessário prender a respiração para fazer força?

Resposta esperada: Não. A respiração deve permanecer natural e contínua.

### 7. O corrimão é equipamento obrigatório?

Resposta esperada: Não. É uma característica opcional do local e pode ser usada como adaptação, desde que esteja firme.

### 8. Porque não deves levar objetos que ocupem as duas mãos?

Resposta esperada: Podem tapar os degraus, alterar o equilíbrio e impedir o uso do corrimão.

### 9. Onde termina a execução?

Resposta esperada: Num patamar seguro, com ambos os pés estáveis.

### 10. A descida faz parte deste exercício?

Resposta esperada: Não. É uma tarefa separada.

### 11. Que sinais exigem interrupção?

Resposta esperada: Desconforto no peito, falta de ar atípica, tonturas ou confusão, perda de controlo, tropeção ou dor nova.

### 12. Quando é especialmente importante ter supervisão?

Resposta esperada: Perante instabilidade marcada, ambiente desconhecido, dificuldade em alternar os apoios, regresso após lesão ou cirurgia ou sintomas relevantes.

## Fontes e limites da evidência

### Fonte 1: Exercising Your Way to Lowering Your Blood Pressure

- Autor ou entidade: A1-S01 — American College of Sports Medicine — Exercising Your Way to Lowering Your Blood Pressure — organização profissional — https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf — Enquadramento da subida de escadas como atividade aeróbia; não usada para técnica fina.
- Tipo: organização profissional
- Localizador: https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf
- Usada para: Enquadramento da subida de escadas como atividade aeróbia; não usada para técnica fina.
- Limite: A1-S01 — American College of Sports Medicine — Exercising Your Way to Lowering Your Blood Pressure — organização profissional — https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf — Enquadramento da subida de escadas como atividade aeróbia; não usada para técnica fina.

### Fonte 2: The effects of low impact aerobic dance and stair climbing on physical fitness in untrained females

- Autor ou entidade: A2-S41 — McCord, Nichols e Patterson — The effects of low impact aerobic dance and stair climbing on physical fitness in untrained females — artigo científico indexado — https://pubmed.ncbi.nlm.nih.gov/8289616/ — Confirma a subida de escadas como modalidade de condicionamento; não resolve pormenores de execução.
- Tipo: artigo científico indexado
- Localizador: https://pubmed.ncbi.nlm.nih.gov/8289616/
- Usada para: Confirma a subida de escadas como modalidade de condicionamento; não resolve pormenores de execução.
- Limite: A2-S41 — McCord, Nichols e Patterson — The effects of low impact aerobic dance and stair climbing on physical fitness in untrained females — artigo científico indexado — https://pubmed.ncbi.nlm.nih.gov/8289616/ — Confirma a subida de escadas como modalidade de condicionamento; não resolve pormenores de execução.

### Fonte 3: Reducing the risk of falls on stairs

- Autor ou entidade: EX10-S01 — Health and Safety Executive — Reducing the risk of falls on stairs — orientação oficial de segurança — https://www.hse.gov.uk/healthservices/slips/reducing-risks-stairs.htm — Iluminação, corrimãos, aderência, marcação das bordas, ausência de obstáculos, calçado sensato e avaliação perante limitações de mobilidade ou equilíbrio.
- Tipo: orientação oficial de segurança
- Localizador: https://www.hse.gov.uk/healthservices/slips/reducing-risks-stairs.htm
- Usada para: Iluminação, corrimãos, aderência, marcação das bordas, ausência de obstáculos, calçado sensato e avaliação perante limitações de mobilidade ou equilíbrio.
- Limite: EX10-S01 — Health and Safety Executive — Reducing the risk of falls on stairs — orientação oficial de segurança — https://www.hse.gov.uk/healthservices/slips/reducing-risks-stairs.htm — Iluminação, corrimãos, aderência, marcação das bordas, ausência de obstáculos, calçado sensato e avaliação perante limitações de mobilidade ou equilíbrio.

### Fonte 4: Breathing techniques to ease breathlessness

- Autor ou entidade: EX10-S02 — Cambridge University Hospitals NHS Foundation Trust — Breathing techniques to ease breathlessness — orientação profissional hospitalar — https://www.cuh.nhs.uk/patient-information/breathing-techniques-to-ease-breathlessness/ — Evitar retenção da respiração, não apressar e permitir que a expiração acompanhe o esforço.
- Tipo: orientação profissional hospitalar
- Localizador: https://www.cuh.nhs.uk/patient-information/breathing-techniques-to-ease-breathlessness/
- Usada para: Evitar retenção da respiração, não apressar e permitir que a expiração acompanhe o esforço.
- Limite: EX10-S02 — Cambridge University Hospitals NHS Foundation Trust — Breathing techniques to ease breathlessness — orientação profissional hospitalar — https://www.cuh.nhs.uk/patient-information/breathing-techniques-to-ease-breathlessness/ — Evitar retenção da respiração, não apressar e permitir que a expiração acompanhe o esforço.

### Fonte 5: Home safety tips for older adults

- Autor ou entidade: EX10-S03 — National Institute on Aging — Home safety tips for older adults — orientação oficial de saúde pública — https://www.nia.nih.gov/sites/default/files/2024-04/home-safety-tips-adults-nia.pdf — Boa iluminação em escadas, corrimãos e redução de perigos de queda.
- Tipo: orientação oficial de saúde pública
- Localizador: https://www.nia.nih.gov/sites/default/files/2024-04/home-safety-tips-adults-nia.pdf
- Usada para: Boa iluminação em escadas, corrimãos e redução de perigos de queda.
- Limite: EX10-S03 — National Institute on Aging — Home safety tips for older adults — orientação oficial de saúde pública — https://www.nia.nih.gov/sites/default/files/2024-04/home-safety-tips-adults-nia.pdf — Boa iluminação em escadas, corrimãos e redução de perigos de queda.

### Fonte 6: Biomechanical analyses of stair-climbing while dual-tasking

- Autor ou entidade: EX10-S04 — Vallabhajosula, Tan, Mukherjee, Davidson e Stergiou — Biomechanical analyses of stair-climbing while dual-tasking — investigação biomecânica primária — https://pubmed.ncbi.nlm.nih.gov/25773590/ — Mecânica da subida, alternância dos apoios e cautela com tarefas simultâneas.
- Tipo: investigação biomecânica primária
- Localizador: https://pubmed.ncbi.nlm.nih.gov/25773590/
- Usada para: Mecânica da subida, alternância dos apoios e cautela com tarefas simultâneas.
- Limite: EX10-S04 — Vallabhajosula, Tan, Mukherjee, Davidson e Stergiou — Biomechanical analyses of stair-climbing while dual-tasking — investigação biomecânica primária — https://pubmed.ncbi.nlm.nih.gov/25773590/ — Mecânica da subida, alternância dos apoios e cautela com tarefas simultâneas.

### Fonte 7: Underlying mechanisms of fall risk on stairs with inconsistent going size

- Autor ou entidade: EX10-S05 — Francksen e colaboradores — Underlying mechanisms of fall risk on stairs with inconsistent going size — investigação primária de segurança — https://pubmed.ncbi.nlm.nih.gov/35151119/ — Risco associado a dimensões inconsistentes, menor folga do pé e menor comprimento de contacto no degrau.
- Tipo: investigação primária de segurança
- Localizador: https://pubmed.ncbi.nlm.nih.gov/35151119/
- Usada para: Risco associado a dimensões inconsistentes, menor folga do pé e menor comprimento de contacto no degrau.
- Limite: EX10-S05 — Francksen e colaboradores — Underlying mechanisms of fall risk on stairs with inconsistent going size — investigação primária de segurança — https://pubmed.ncbi.nlm.nih.gov/35151119/ — Risco associado a dimensões inconsistentes, menor folga do pé e menor comprimento de contacto no degrau.
