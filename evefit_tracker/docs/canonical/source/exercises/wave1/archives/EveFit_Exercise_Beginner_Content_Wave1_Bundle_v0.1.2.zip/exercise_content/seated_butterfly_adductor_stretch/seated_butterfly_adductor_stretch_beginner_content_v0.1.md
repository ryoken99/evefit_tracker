# Alongamento borboleta dos adutores

Conteúdo para principiantes em português europeu.

## Descrição curta

Posição sentada com as plantas dos pés juntas e abertura bilateral controlada das ancas.

## O que é

Senta-te numa superfície estável, junta as plantas dos pés e deixa os joelhos abrir para os lados apenas até uma posição confortável e controlável. Mantém o tronco organizado e sai da posição de forma gradual.

## O que vais fazer

Vais aproximar as plantas dos pés, permitir que as ancas se abram dos dois lados e manter uma tensão suave na face interna das coxas sem empurrar os joelhos.

## Porque existe este movimento

Este movimento permite praticar uma posição sustentada de abertura bilateral das ancas e reconhecer uma amplitude que consegues controlar autonomamente.

## Antes de começares

1. Confirma que consegues sentar-te, ajustar as pernas e voltar a fechá-las sem ajuda. Se estiveres a regressar após lesão ou cirurgia, se tiveres hipermobilidade relevante, ou se a posição provocar sintomas, pede orientação a um profissional qualificado antes de avançar.

## Preparar o equipamento

1. Não é necessário equipamento portátil. Um tapete de exercício é opcional, desde que fique plano, seco e não deslize.

## Preparar o espaço

1. Escolhe uma superfície estável e antiderrapante, no interior ou no exterior, com espaço livre para abrir as pernas e sair da posição. Evita superfícies instáveis ou escorregadias, trânsito ativo e apoios inseguros.

## Verificação do corpo

1. Consegues sentar-te de forma estável e manter controlo do tronco.
2. Consegues fletir os joelhos e aproximar os pés sem dor aguda ou crescente.
3. Consegues abrir e voltar a fechar os joelhos sem impulso nem ajuda de outra pessoa.
4. Não sentes dormência, formigueiro, fraqueza súbita, instabilidade ou mal-estar.
5. Se o frio alterar o teu conforto, começa com uma abertura menor e reavalia a sensação.

## Posição inicial

Senta-te com a bacia apoiada numa superfície estável. Flete os joelhos, aproxima as plantas dos pés uma da outra e segura suavemente os tornozelos ou os pés. Mantém o peso equilibrado sobre a bacia, o tronco controlado e os joelhos livres para abrir para os lados.

## Confirmar a posição inicial

1. Bacia apoiada e estável.
2. Plantas dos pés em contacto.
3. Joelhos fletidos e abertos para os lados sem pressão externa.
4. Pés colocados a uma distância confortável da bacia.
5. Coluna confortavelmente alongada, sem colapso lombar.
6. Ombros soltos e respiração livre.

## Passos de execução

1. Senta-te de forma estável e aproxima as plantas dos pés sem puxões.
2. Segura suavemente os tornozelos ou os pés e deixa os joelhos abrir para os lados sob o seu próprio peso.
3. Ajusta a distância dos pés à bacia até conseguires manter a posição sem dor articular nem necessidade de forçar.
4. Organiza a bacia e o tronco, mantendo a coluna confortavelmente alongada e os ombros relaxados.
5. Permanece apenas na amplitude em que sentes uma tensão suave na face interna das coxas e continuas a respirar livremente.
6. Para sair, reduz a abertura e aproxima gradualmente os joelhos; depois separa os pés e coloca as pernas numa posição confortável.

## Fases do movimento

### Entrada

Apoia a bacia, flete os joelhos e aproxima as plantas dos pés com controlo.

### Organização

Permite a abertura bilateral das ancas, ajusta a posição dos pés e estabiliza o tronco.

### Posição sustentada

Mantém uma amplitude confortável, sem ressalto nem pressão sobre os joelhos, com respiração natural.

### Saída

Fecha os joelhos gradualmente e liberta a posição dos pés.

## Respiração

Respira de forma natural e contínua. Não prendas a respiração. Se precisares de bloquear a respiração para tolerar a posição, reduz a abertura ou sai.

## Sensações esperadas

1. Tensão suave e difusa na face interna das coxas.
2. Sensação de abertura confortável na região das ancas.
3. Contacto estável da bacia com a superfície.
4. Respiração livre e tronco controlável.

## Sensações inesperadas ou de alerta

1. Dor aguda ou crescente na virilha, anca ou joelho.
2. Sensação de aperto ou beliscão dentro da articulação da anca.
3. Dormência, formigueiro ou alteração súbita da sensibilidade.
4. Fraqueza súbita, instabilidade, perda de controlo ou mal-estar.
5. Necessidade de prender a respiração para permanecer na posição.

## Indicações técnicas principais

1. Bacia estável na superfície.
2. Plantas dos pés juntas, sem puxar.
3. Joelhos livres: não os empurres.
4. Coluna confortavelmente alongada.
5. Tensão suave na face interna das coxas.
6. Respira livremente e sai com controlo.

## Erros comuns e correções

### Erro 1: Empurrar os joelhos em direção ao chão.

- Como reconhecer: Usas as mãos, os antebraços ou outra pessoa para aumentar a abertura, ou sentes pressão no joelho.
- Como corrigir: Retira a pressão e deixa os joelhos descer apenas sob o seu próprio peso.

### Erro 2: Fazer ressalto para ganhar amplitude.

- Como reconhecer: Os joelhos ou o tronco sobem e descem repetidamente.
- Como corrigir: Fica imóvel numa abertura menor que consigas controlar.

### Erro 3: Arredondar excessivamente a região lombar.

- Como reconhecer: A bacia roda para trás e o peito colapsa sobre os pés.
- Como corrigir: Afasta um pouco os pés da bacia e reorganiza o tronco numa posição confortável.

### Erro 4: Puxar os pés demasiado perto da bacia.

- Como reconhecer: A posição cria pressão na virilha, na anca ou no joelho, ou obriga a perder o controlo do tronco.
- Como corrigir: Desliza os pés para mais longe até recuperar conforto e controlo.

### Erro 5: Prender a respiração.

- Como reconhecer: A respiração fica bloqueada ou os ombros e o pescoço ficam rígidos.
- Como corrigir: Reduz a abertura e retoma uma respiração natural e contínua.

### Erro 6: Ignorar sinais de aviso.

- Como reconhecer: Continuas apesar de dor aguda ou crescente, formigueiro, fraqueza, instabilidade ou mal-estar.
- Como corrigir: Interrompe a posição de forma controlada e procura orientação adequada se os sinais persistirem.

## Formas de simplificar ou ensaiar

1. Mantém os pés mais afastados da bacia para reduzir a abertura exigida.
2. Mantém o tronco vertical; inclinar para a frente não é necessário.
3. Coloca as mãos atrás do corpo se isso ajudar a manter o tronco controlado, sem transferir pressão para os joelhos.
4. Escolhe uma abertura menor que permita fechar os joelhos autonomamente.

## Supervisão

Não é necessário observador nem supervisão na utilização geral de baixo risco quando a pessoa controla a entrada, a posição e a saída sem sintomas. Procura supervisão qualificada se não conseguires controlar a amplitude, se dependeres de força externa, se estiveres a regressar após lesão ou cirurgia, ou se o teu historial, gravidez, pós-parto, hipermobilidade ou outra condição relevante alterar a tolerância à posição.

## Como terminar

Volta a aproximar os joelhos de forma gradual. Se precisares, guia a parte externa das coxas com as mãos sem puxões. Separa as plantas dos pés, coloca os pés no chão ou estende as pernas confortavelmente e confirma que te sentes estável antes de te levantares.

## Nota de segurança

O risco operacional base é baixo, mas a posição deve permanecer autolimitada. Não empurres os joelhos, não uses ressalto e não forces a amplitude. Interrompe perante dor inguinal aguda, dor articular, alteração da sensibilidade, fraqueza súbita, instabilidade ou mal-estar.

## Quando parar ou reduzir

1. Reduz a abertura se a tensão deixar de ser suave ou se perderes o controlo do tronco.
2. Sai da posição perante dor aguda ou crescente, sobretudo na virilha, anca ou joelho.
3. Sai perante dormência, formigueiro, fraqueza súbita, instabilidade ou mal-estar.
4. Interrompe se não conseguires fechar os joelhos de forma gradual e autónoma.

## Segurança do equipamento

Sem equipamento obrigatório. Se usares um tapete de exercício, confirma que está plano, seco, íntegro e imóvel. Não uses objetos para empurrar ou prender os joelhos.

## Segurança do espaço

Usa uma superfície estável e antiderrapante, com espaço livre à volta. Evita superfícies instáveis ou escorregadias, apoios inseguros e locais com trânsito ativo. O frio pode alterar a tolerância; reduz a abertura se o conforto mudar.

## Limitações

1. Conteúdo educativo para a identidade canónica e para utilização geral de baixo risco. A resposta individual pode variar, sobretudo após lesão ou cirurgia, com hipermobilidade, gravidez, pós-parto, doença crónica relevante ou retorno funcional. Implementação realizada: não

## Teste de compreensão

### 1. Que partes dos pés ficam em contacto?

Resposta esperada: As plantas dos pés ficam juntas.

### 2. Deves empurrar os joelhos para o chão?

Resposta esperada: Não. Os joelhos devem abrir sem pressão externa.

### 3. Onde é esperado sentir uma tensão suave?

Resposta esperada: Na face interna das coxas e na região das ancas.

### 4. A dor aguda na virilha é uma sensação esperada?

Resposta esperada: Não. É um sinal para sair da posição.

### 5. Como deve estar a respiração?

Resposta esperada: Natural, livre e contínua, sem bloqueio.

### 6. O que podes alterar se a posição for demasiado intensa?

Resposta esperada: Reduzir a abertura e afastar os pés da bacia.

### 7. É necessário inclinar o tronco para a frente?

Resposta esperada: Não. O tronco pode ficar vertical e controlado.

### 8. Que tipo de superfície deves escolher?

Resposta esperada: Uma superfície estável e antiderrapante.

### 9. É aceitável fazer ressalto com os joelhos?

Resposta esperada: Não. A posição deve permanecer controlada e sem ressalto.

### 10. Como sais da posição?

Resposta esperada: Aproximas gradualmente os joelhos e depois separas os pés.

### 11. Que sinais neurológicos exigem interrupção?

Resposta esperada: Dormência, formigueiro ou fraqueza súbita.

### 12. Quando pode ser indicada orientação profissional?

Resposta esperada: Quando não há controlo autónomo, existem sintomas, ou o historial, uma lesão, cirurgia, hipermobilidade, gravidez, pós-parto ou outra condição relevante altera a tolerância.

## Fontes e limites da evidência

### Fonte 1: Flexibility Exercises for Young Athletes

- Autor ou entidade: EX26-S1 — Flexibility Exercises for Young Athletes — American Academy of Orthopaedic Surgeons, OrthoInfo — orientação profissional revista por médicos — https://www.orthoinfo.org/staying-healthy/flexibility-exercises-for-young-athletes/ — Configuração com plantas dos pés juntas, abertura dos joelhos, controlo do tronco, movimento cuidadoso e ausência de ressalto. — A sugestão de pressionar os joelhos não foi adotada por contrariar os limites canónicos e a abordagem autolimitada.
- Tipo: orientação profissional revista por médicos
- Localizador: https://www.orthoinfo.org/staying-healthy/flexibility-exercises-for-young-athletes/
- Usada para: EX26-S1 — Flexibility Exercises for Young Athletes — American Academy of Orthopaedic Surgeons, OrthoInfo — orientação profissional revista por médicos — https://www.orthoinfo.org/staying-healthy/flexibility-exercises-for-young-athletes/ — Configuração com plantas dos pés juntas, abertura dos joelhos, controlo do tronco, movimento cuidadoso e ausência de ressalto. — A sugestão de pressionar os joelhos não foi adotada por contrariar os limites canónicos e a abordagem autolimitada.
- Limite: EX26-S1 — Flexibility Exercises for Young Athletes — American Academy of Orthopaedic Surgeons, OrthoInfo — orientação profissional revista por médicos — https://www.orthoinfo.org/staying-healthy/flexibility-exercises-for-young-athletes/ — Configuração com plantas dos pés juntas, abertura dos joelhos, controlo do tronco, movimento cuidadoso e ausência de ressalto. — A sugestão de pressionar os joelhos não foi adotada por contrariar os limites canónicos e a abordagem autolimitada.

### Fonte 2: Static Butterfly Stretch

- Autor ou entidade: EX26-S2 — Static Butterfly Stretch — National Academy of Sports Medicine — orientação técnica profissional — https://www.nasm.org/resource-center/exercise-library/static-butterfly-stretch — Posição sentada, coluna neutra, plantas dos pés juntas, sensação na face interna das coxas, respiração livre, saída gradual, erros e adaptações para principiantes. — Foram excluídas afirmações de benefício futuro e qualquer parâmetro quantitativo.
- Tipo: orientação técnica profissional
- Localizador: https://www.nasm.org/resource-center/exercise-library/static-butterfly-stretch
- Usada para: EX26-S2 — Static Butterfly Stretch — National Academy of Sports Medicine — orientação técnica profissional — https://www.nasm.org/resource-center/exercise-library/static-butterfly-stretch — Posição sentada, coluna neutra, plantas dos pés juntas, sensação na face interna das coxas, respiração livre, saída gradual, erros e adaptações para principiantes. — Foram excluídas afirmações de benefício futuro e qualquer parâmetro quantitativo.
- Limite: EX26-S2 — Static Butterfly Stretch — National Academy of Sports Medicine — orientação técnica profissional — https://www.nasm.org/resource-center/exercise-library/static-butterfly-stretch — Posição sentada, coluna neutra, plantas dos pés juntas, sensação na face interna das coxas, respiração livre, saída gradual, erros e adaptações para principiantes. — Foram excluídas afirmações de benefício futuro e qualquer parâmetro quantitativo.

### Fonte 3: Stretching: Focus on flexibility

- Autor ou entidade: EX26-S3 — Stretching: Focus on flexibility — Mayo Clinic — orientação clínica institucional — https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20047931 — Princípios gerais de execução lenta, sem ressalto, sem dor e com respiração livre. — Fonte geral de alongamento, não específica desta identidade.
- Tipo: orientação clínica institucional
- Localizador: https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20047931
- Usada para: EX26-S3 — Stretching: Focus on flexibility — Mayo Clinic — orientação clínica institucional — https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20047931 — Princípios gerais de execução lenta, sem ressalto, sem dor e com respiração livre. — Fonte geral de alongamento, não específica desta identidade.
- Limite: EX26-S3 — Stretching: Focus on flexibility — Mayo Clinic — orientação clínica institucional — https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20047931 — Princípios gerais de execução lenta, sem ressalto, sem dor e com respiração livre. — Fonte geral de alongamento, não específica desta identidade.

### Fonte 4: The effect of hip flexion angle on muscle elongation of the hip adductor muscles during stretching

- Autor ou entidade: EX26-S4 — The effect of hip flexion angle on muscle elongation of the hip adductor muscles during stretching — Ogawa, Saeki e Ichihashi — estudo biomecânico primário com elastografia — https://pubmed.ncbi.nlm.nih.gov/32019680/ — Suporte biomecânico para elongação de componentes dos adutores em posições de abdução da anca e para linguagem anatómica prudente. — Amostra restrita a homens saudáveis e posições laboratoriais; não valida todas as instruções desta forma sentada.
- Tipo: estudo biomecânico primário com elastografia
- Localizador: https://pubmed.ncbi.nlm.nih.gov/32019680/
- Usada para: EX26-S4 — The effect of hip flexion angle on muscle elongation of the hip adductor muscles during stretching — Ogawa, Saeki e Ichihashi — estudo biomecânico primário com elastografia — https://pubmed.ncbi.nlm.nih.gov/32019680/ — Suporte biomecânico para elongação de componentes dos adutores em posições de abdução da anca e para linguagem anatómica prudente. — Amostra restrita a homens saudáveis e posições laboratoriais; não valida todas as instruções desta forma sentada.
- Limite: EX26-S4 — The effect of hip flexion angle on muscle elongation of the hip adductor muscles during stretching — Ogawa, Saeki e Ichihashi — estudo biomecânico primário com elastografia — https://pubmed.ncbi.nlm.nih.gov/32019680/ — Suporte biomecânico para elongação de componentes dos adutores em posições de abdução da anca e para linguagem anatómica prudente. — Amostra restrita a homens saudáveis e posições laboratoriais; não valida todas as instruções desta forma sentada.

### Fonte 5: Comparison of Two Static Stretching Procedures on Hip Adductor Flexibility and Strength

- Autor ou entidade: EX26-S5 — Comparison of Two Static Stretching Procedures on Hip Adductor Flexibility and Strength — Fjerstad, Hammer, Hammer, Connolly, Lomond e O'Connor — estudo primário cruzado e aleatorizado — https://pubmed.ncbi.nlm.nih.gov/30338021/ — Confirmação de que procedimentos estáticos ativos e passivos dos adutores foram estudados e de que a amplitude deve ser tratada como variável controlada. — Participantes saudáveis e fisicamente ativos; os resultados não autorizam uma regra universal nem parâmetros quantitativos neste conteúdo.
- Tipo: estudo primário cruzado e aleatorizado
- Localizador: https://pubmed.ncbi.nlm.nih.gov/30338021/
- Usada para: EX26-S5 — Comparison of Two Static Stretching Procedures on Hip Adductor Flexibility and Strength — Fjerstad, Hammer, Hammer, Connolly, Lomond e O'Connor — estudo primário cruzado e aleatorizado — https://pubmed.ncbi.nlm.nih.gov/30338021/ — Confirmação de que procedimentos estáticos ativos e passivos dos adutores foram estudados e de que a amplitude deve ser tratada como variável controlada. — Participantes saudáveis e fisicamente ativos; os resultados não autorizam uma regra universal nem parâmetros quantitativos neste conteúdo.
- Limite: EX26-S5 — Comparison of Two Static Stretching Procedures on Hip Adductor Flexibility and Strength — Fjerstad, Hammer, Hammer, Connolly, Lomond e O'Connor — estudo primário cruzado e aleatorizado — https://pubmed.ncbi.nlm.nih.gov/30338021/ — Confirmação de que procedimentos estáticos ativos e passivos dos adutores foram estudados e de que a amplitude deve ser tratada como variável controlada. — Participantes saudáveis e fisicamente ativos; os resultados não autorizam uma regra universal nem parâmetros quantitativos neste conteúdo.
