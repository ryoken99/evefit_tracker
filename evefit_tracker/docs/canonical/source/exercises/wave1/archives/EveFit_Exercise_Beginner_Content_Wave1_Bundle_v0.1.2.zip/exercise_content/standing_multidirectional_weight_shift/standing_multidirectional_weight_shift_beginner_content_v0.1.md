# Transferência de peso multidirecional em pé

Conteúdo para principiantes em português europeu.

## Descrição curta

Deslocar o peso para a frente, para trás e para os lados sem levantar os pés.

## O que é

É uma transferência controlada do peso do corpo dentro da base criada pelos dois pés. Ambos os pés permanecem em contacto com o solo, o corpo regressa ao centro antes de mudar de direção e não se dá qualquer passo.

## O que vais fazer

Em pé, vais deslocar suavemente o corpo para a frente, para trás, para a esquerda e para a direita. Depois de cada deslocação, vais regressar à posição central sem mover os pés.

## Porque existe este movimento

A tarefa existe para praticar o controlo da posição do corpo sobre uma base bipodal fixa. A amplitude, o ritmo e a forma de utilização pertencem à prescrição e não são definidos neste conteúdo.

## Antes de começares

1. Escolhe uma área desimpedida, com piso firme, plano e antiderrapante.
2. Se a tua avaliação ou contexto indicar necessidade de apoio, coloca uma parede ou bancada fixa ao alcance; o apoio não é obrigatório para todas as pessoas.
3. Confirma apenas que a roupa e o calçado que já usas não limitam o movimento nem reduzem a aderência; a ficha não impõe equipamento pessoal específico.
4. Não comeces se não conseguires compreender, iniciar e interromper voluntariamente a tarefa.

## Preparar o equipamento

1. Não existe equipamento obrigatório.
2. Quando um apoio tiver sido indicado para ti, confirma que é fixo, não tem rodas e não desliza.
3. Coloca o apoio opcional suficientemente perto para um contacto ligeiro, sem alterar a base dos pés.

## Preparar o espaço

1. Usa uma superfície firme, plana e antiderrapante, com a zona à frente, atrás e aos lados livre de objetos. Não executes num veículo em movimento, junto de uma altura desprotegida, num piso instável ou escorregadio, nem num local apertado que impeça uma saída controlada.

## Verificação do corpo

1. Consegues permanecer em pé com os dois pés apoiados e parar a tarefa por decisão própria.
2. Consegues encontrar uma posição central estável antes de iniciar.
3. Não apresentas dor aguda, tontura, mal-estar ou perda de controlo antes de começares.
4. Se antecipar que poderá precisar de apoio, este está estável e ao alcance.

## Posição inicial

Fica de pé numa base confortável, com ambos os pés totalmente apoiados e os joelhos desbloqueados. Mantém o tronco alongado e o olhar em frente. Usa contacto ligeiro num apoio estável apenas quando isso tiver sido indicado no teu contexto.

## Confirmar a posição inicial

1. Os dois pés estão em contacto com o solo e não precisam de mudar de lugar.
2. O piso está firme, plano, antiderrapante e livre.
3. Há espaço livre à frente, atrás e aos lados.
4. O apoio opcional está estável e ao alcance.
5. A posição central parece controlada e permite parar voluntariamente.

## Passos de execução

1. Encontra o centro: mantém os dois pés imóveis e repara na pressão sob cada pé.
2. Desloca suavemente o corpo para a frente, como uma unidade, sem levantar, rodar ou arrastar os pés.
3. Pára antes do ponto em que terias de dar um passo ou agarrar o apoio de forma repentina e regressa ao centro com controlo.
4. Desloca suavemente o corpo para trás, mantendo ambos os pés em contacto, e volta ao centro.
5. Transfere o peso para a esquerda sem inclinar apenas os ombros, sem levantar o pé direito e sem mudar a posição dos pés; depois regressa ao centro.
6. Transfere o peso para a direita da mesma forma e volta ao centro antes de qualquer nova direção.
7. Conclui o ciclo descrito e regressa a uma posição estável; a ficha não define número de repetições nem duração.

## Fases do movimento

### Centro

Posição bipodal controlada, com ambos os pés no mesmo lugar.

### Deslocação

Redistribuição gradual da pressão entre os pés ou entre a parte anterior e posterior da base, sem passo.

### Limite controlado

Fim da deslocação antes de ser necessário mover um pé, agarrar o apoio de repente ou perder o alinhamento.

### Regresso

Retorno suave à posição central antes de mudar de direção.

## Respiração

Respira de forma natural e contínua durante a deslocação e o regresso. Não prendas a respiração nem imponha uma contagem; relaxa os ombros e deixa o ar circular sem esforço.

## Sensações esperadas

1. Mudança gradual da pressão sob os pés conforme a direção.
2. Trabalho ligeiro de controlo nos tornozelos, ancas, pernas e tronco.
3. Sensação de aproximação ao limite de equilíbrio que desaparece ao regressar ao centro.
4. Contacto contínuo dos dois pés com o solo.

## Sensações inesperadas ou de alerta

1. Dor aguda.
2. Tontura ou sensação de desmaio.
3. Mal-estar.
4. Necessidade repetida de agarrar o apoio sem o ter planeado.
5. Perda de controlo ou necessidade de dar um passo para evitar uma queda.

## Indicações técnicas principais

1. Mantém os dois pés no mesmo lugar e em contacto com o solo.
2. Leva o corpo contigo; não desloques apenas os ombros.
3. Fica dentro do limite que permite regressar sem dar um passo.
4. Volta ao centro antes de mudares de direção.
5. Move-te suavemente e mantém o olhar em frente.
6. Respira normalmente, sem prender o ar.

## Erros comuns e correções

### Erro 1: Levantar, rodar ou arrastar um pé.

- Como reconhecer: A sola perde contacto, a ponta ou o calcanhar muda de orientação, ou o pé termina noutro lugar.
- Como corrigir: Regressa ao centro, diminui a deslocação e mantém os dois pés apoiados e imóveis.

### Erro 2: Deslocar-se para além do limite controlável.

- Como reconhecer: Precisas de dar um passo, agarras o apoio de repente ou não consegues regressar suavemente.
- Como corrigir: Pára mais cedo na direção seguinte e usa o apoio estável ao alcance se necessário.

### Erro 3: Dobrar ou rodar apenas o tronco em vez de deslocar o corpo.

- Como reconhecer: Os ombros afastam-se muito da bacia ou o tronco torce enquanto a pressão nos pés quase não muda.
- Como corrigir: Mantém o tronco alongado, reduz a amplitude e deixa tornozelos e ancas acompanharem a deslocação.

### Erro 4: Mudar diretamente de uma direção para outra.

- Como reconhecer: O corpo atravessa o centro sem recuperar uma posição estável e a mudança torna-se brusca.
- Como corrigir: Regressa primeiro ao centro, confirma o controlo e só depois escolhe a direção seguinte.

### Erro 5: Usar impulso ou travar de repente.

- Como reconhecer: A cabeça e o tronco balançam, o apoio recebe um puxão ou o regresso não é gradual.
- Como corrigir: Torne o movimento menor e mais suave, mantendo capacidade de parar a qualquer momento.

### Erro 6: Pendurar-se no apoio opcional.

- Como reconhecer: Os braços sustentam grande parte do peso ou o apoio começa a mover-se.
- Como corrigir: Interrompe, confirma a estabilidade do apoio e usa apenas o contacto necessário para manter controlo.

## Formas de simplificar ou ensaiar

1. Faz deslocações menores, mantendo claramente a capacidade de regressar ao centro.
2. Explore uma direção de cada vez em vez de ligar várias direções.
3. Usa contacto confortável com um apoio estável e já testado.
4. Mantém uma base bipodal confortável; a alteração individual da base deve respeitar a orientação aplicável ao teu contexto.
5. Pede supervisão quando não tiveres a certeza de conseguir parar ou regressar ao centro sem ajuda.

## Supervisão

A supervisão é recomendada. Deve ser reforçada quando existe risco elevado de queda, queda recente, um contexto clinicamente restringido ou incapacidade de sair da tarefa de forma independente. Pessoas com condições neurológicas ou vestibulares, em regresso à função, ou com quedas recentes devem obter revisão profissional para decidir adaptação, apoio e grau de supervisão; este conteúdo não faz essa avaliação.

## Como terminar

Regressa à posição central, confirma que o peso está novamente distribuído de forma confortável entre os dois pés e pára em controlo. Usa o apoio estável se precisares. Se surgir um sinal de interrupção, termina a tarefa e adota uma posição segura sem continuar as transferências.

## Nota de segurança

Usa apoio estável ao alcance e reduz a deslocação se sentires que te aproximas do ponto em que terias de dar um passo. Interrompe perante perda de controlo, tontura, mal-estar, dor aguda ou necessidade repetida de apoio não planeado.

## Quando parar ou reduzir

1. Necessidade de dar um passo ou agarrar o apoio. — Reduz a deslocação; se o controlo não regressar, termina.
2. Necessidade repetida de apoio não planeado. — Termina a tarefa e procura supervisão adequada antes de nova tentativa.
3. Perda de controlo. — Interrompe e usa o apoio ou outra saída segura disponível.
4. Dor aguda, tontura ou mal-estar. — Pára e não continues enquanto o sinal estiver presente.

## Segurança do equipamento

O apoio é opcional, mas, quando usado, tem de ser estável, estar ao alcance e não deslizar. Não uses uma cadeira com rodas, um móvel leve, um objeto solto ou qualquer apoio que se desloque quando tocado. Não te afastes do apoio se isso exigir um passo para o alcançar.

## Segurança do espaço

Mantém a área livre de tapetes soltos, cabos, objetos, animais e outras pessoas que possam interferir. Evita piso molhado, inclinado, instável ou escorregadio, pouca visibilidade, alturas desprotegidas e veículos em movimento.

## Limitações

1. A fonte profissional mais diretamente comparável descreve sobretudo a transferência lateral; as instruções para a frente e para trás preservam a mesma identidade canónica, mas são uma síntese biomecânica conservadora.
2. Os estudos primários consultados foram realizados sobretudo com adultos mais velhos e em tarefas instrumentadas; não autorizam generalização automática a todas as populações.
3. A orientação respiratória é geral para movimento e não uma cadência específica validada para este exercício.
4. O conteúdo não determina elegibilidade individual, amplitude, ritmo, dose, progressão nem grau final de supervisão.
5. Implementação realizada: não

## Teste de compreensão

### 1. O que deve acontecer aos pés durante toda a tarefa?

Resposta esperada: Devem permanecer no mesmo lugar e em contacto com o solo.

### 2. Que direções fazem parte desta transferência?

Resposta esperada: Frente, trás, esquerda e direita, com regresso ao centro.

### 3. O que deves fazer antes de mudares de direção?

Resposta esperada: Regressar ao centro e recuperar controlo.

### 4. Como reconhece que se deslocou demasiado?

Resposta esperada: Precisas de dar um passo, agarrar o apoio de repente ou não consegue regressar suavemente.

### 5. O apoio é obrigatório?

Resposta esperada: Não; é opcional, mas deve ser estável e estar ao alcance quando necessário.

### 6. Que tipo de piso deves escolher?

Resposta esperada: Firme, plano, antiderrapante e desimpedido.

### 7. Deves prender a respiração ao deslocar o peso?

Resposta esperada: Não; deves respirar de forma natural e contínua.

### 8. Mover apenas os ombros é uma execução correta?

Resposta esperada: Não; o corpo deve deslocar-se de forma coordenada, com o tronco alongado.

### 9. O que deves fazer se o apoio começar a deslizar?

Resposta esperada: Interromper e usar apenas um apoio cuja estabilidade tenha sido confirmada.

### 10. Que sinais exigem interrupção?

Resposta esperada: Dor aguda, tontura, mal-estar, perda de controlo ou necessidade repetida de apoio não planeado.

### 11. Quando deve ser reforçada a supervisão?

Resposta esperada: Perante risco elevado de queda, queda recente, contexto clinicamente restringido ou incapacidade de sair da tarefa sem ajuda.

### 12. Este conteúdo define repetições, duração ou amplitude individual?

Resposta esperada: Não; esses elementos pertencem à prescrição e à elegibilidade individual.

## Fontes e limites da evidência

### Fonte 1: Physical Therapy Management of Fall Risk in Community-Dwelling Older Adults: An Evidence-Based Clinical Practice Guideline

- Autor ou entidade: E1-SRC-014 — Physical Therapy Management of Fall Risk in Community-Dwelling Older Adults: An Evidence-Based Clinical Practice Guideline — Kirk-Sanchez N, McDonough C, Avin K, Blackwood J, Hanke T; APTA Geriatrics — guideline clínica profissional — 2025 — https://www.apta.org/patient-care/evidence-based-practice-resources/cpgs/physical-therapy-management-of-fall-risk-in-community-dwelling-older-adults — Sustenta a necessidade de raciocínio individual, revisão e supervisão quando o risco de queda é relevante.
- Tipo: guideline clínica profissional
- Localizador: https://www.apta.org/patient-care/evidence-based-practice-resources/cpgs/physical-therapy-management-of-fall-risk-in-community-dwelling-older-adults
- Usada para: E1-SRC-014 — Physical Therapy Management of Fall Risk in Community-Dwelling Older Adults: An Evidence-Based Clinical Practice Guideline — Kirk-Sanchez N, McDonough C, Avin K, Blackwood J, Hanke T; APTA Geriatrics — guideline clínica profissional — 2025 — https://www.apta.org/patient-care/evidence-based-practice-resources/cpgs/physical-therapy-management-of-fall-risk-in-community-dwelling-older-adults — Sustenta a necessidade de raciocínio individual, revisão e supervisão quando o risco de queda é relevante.
- Limite: E1-SRC-014 — Physical Therapy Management of Fall Risk in Community-Dwelling Older Adults: An Evidence-Based Clinical Practice Guideline — Kirk-Sanchez N, McDonough C, Avin K, Blackwood J, Hanke T; APTA Geriatrics — guideline clínica profissional — 2025 — https://www.apta.org/patient-care/evidence-based-practice-resources/cpgs/physical-therapy-management-of-fall-risk-in-community-dwelling-older-adults — Sustenta a necessidade de raciocínio individual, revisão e supervisão quando o risco de queda é relevante.

### Fonte 2: Tools to Implement the Otago Exercise Program

- Autor ou entidade: E2-S08 — Tools to Implement the Otago Exercise Program — UNC Center for Aging and Health — manual profissional — 2024 — https://www.med.unc.edu/aging/cgwep/wp-content/uploads/sites/865/2024/04/Otago-Guide-for-PT_April-2024-update.pdf — Sustenta o enquadramento profissional, individualizado e supervisionado de tarefas de equilíbrio em populações com risco de queda.
- Tipo: manual profissional
- Localizador: https://www.med.unc.edu/aging/cgwep/wp-content/uploads/sites/865/2024/04/Otago-Guide-for-PT_April-2024-update.pdf
- Usada para: E2-S08 — Tools to Implement the Otago Exercise Program — UNC Center for Aging and Health — manual profissional — 2024 — https://www.med.unc.edu/aging/cgwep/wp-content/uploads/sites/865/2024/04/Otago-Guide-for-PT_April-2024-update.pdf — Sustenta o enquadramento profissional, individualizado e supervisionado de tarefas de equilíbrio em populações com risco de queda.
- Limite: E2-S08 — Tools to Implement the Otago Exercise Program — UNC Center for Aging and Health — manual profissional — 2024 — https://www.med.unc.edu/aging/cgwep/wp-content/uploads/sites/865/2024/04/Otago-Guide-for-PT_April-2024-update.pdf — Sustenta o enquadramento profissional, individualizado e supervisionado de tarefas de equilíbrio em populações com risco de queda.

### Fonte 3: Community Falls Team — Strength and Balance Exercises

- Autor ou entidade: WEB-EX40-01 — Community Falls Team — Strength and Balance Exercises — Leicestershire Partnership NHS Trust — manual profissional de fisioterapia — 2022 — https://www.leicspart.nhs.uk/wp-content/uploads/2022/07/467A-Falls-service-strength-and-balance-exercises-Ashby-bklet.pdf — Fonte direta para a transferência lateral com pés à largura da anca, ambos os pés no solo e apoio graduado junto de superfície estável.
- Tipo: manual profissional de fisioterapia
- Localizador: https://www.leicspart.nhs.uk/wp-content/uploads/2022/07/467A-Falls-service-strength-and-balance-exercises-Ashby-bklet.pdf
- Usada para: WEB-EX40-01 — Community Falls Team — Strength and Balance Exercises — Leicestershire Partnership NHS Trust — manual profissional de fisioterapia — 2022 — https://www.leicspart.nhs.uk/wp-content/uploads/2022/07/467A-Falls-service-strength-and-balance-exercises-Ashby-bklet.pdf — Fonte direta para a transferência lateral com pés à largura da anca, ambos os pés no solo e apoio graduado junto de superfície estável.
- Limite: WEB-EX40-01 — Community Falls Team — Strength and Balance Exercises — Leicestershire Partnership NHS Trust — manual profissional de fisioterapia — 2022 — https://www.leicspart.nhs.uk/wp-content/uploads/2022/07/467A-Falls-service-strength-and-balance-exercises-Ashby-bklet.pdf — Fonte direta para a transferência lateral com pés à largura da anca, ambos os pés no solo e apoio graduado junto de superfície estável.

### Fonte 4: Balance exercises

- Autor ou entidade: WEB-EX40-02 — Balance exercises — NHS — orientação oficial ao público — 2023 — https://www.nhs.uk/live-well/exercise/balance-exercises/ — Sustenta a disponibilidade de parede ou cadeira estável e a execução lenta e controlada em tarefas de equilíbrio.
- Tipo: orientação oficial ao público
- Localizador: https://www.nhs.uk/live-well/exercise/balance-exercises/
- Usada para: WEB-EX40-02 — Balance exercises — NHS — orientação oficial ao público — 2023 — https://www.nhs.uk/live-well/exercise/balance-exercises/ — Sustenta a disponibilidade de parede ou cadeira estável e a execução lenta e controlada em tarefas de equilíbrio.
- Limite: WEB-EX40-02 — Balance exercises — NHS — orientação oficial ao público — 2023 — https://www.nhs.uk/live-well/exercise/balance-exercises/ — Sustenta a disponibilidade de parede ou cadeira estável e a execução lenta e controlada em tarefas de equilíbrio.

### Fonte 5: Limits of Stability and Functional Base of Support While Standing in Community-Dwelling Older Adults

- Autor ou entidade: WEB-EX40-03 — Limits of Stability and Functional Base of Support While Standing in Community-Dwelling Older Adults — Tomita H, Kuno S, Kawaguchi D, Nojima O — estudo primário observacional — 2021 — https://pubmed.ncbi.nlm.nih.gov/32028861/ — 10.1080/00222895.2020.1723484 — Sustenta que os limites funcionais em pé são direcionais, individuais e menores do que a área geométrica total dos pés.
- Tipo: estudo primário observacional
- Localizador: https://pubmed.ncbi.nlm.nih.gov/32028861/
- Usada para: WEB-EX40-03 — Limits of Stability and Functional Base of Support While Standing in Community-Dwelling Older Adults — Tomita H, Kuno S, Kawaguchi D, Nojima O — estudo primário observacional — 2021 — https://pubmed.ncbi.nlm.nih.gov/32028861/ — 10.1080/00222895.2020.1723484 — Sustenta que os limites funcionais em pé são direcionais, individuais e menores do que a área geométrica total dos pés.
- Limite: WEB-EX40-03 — Limits of Stability and Functional Base of Support While Standing in Community-Dwelling Older Adults — Tomita H, Kuno S, Kawaguchi D, Nojima O — estudo primário observacional — 2021 — https://pubmed.ncbi.nlm.nih.gov/32028861/ — 10.1080/00222895.2020.1723484 — Sustenta que os limites funcionais em pé são direcionais, individuais e menores do que a área geométrica total dos pés.

### Fonte 6: Changes in the Limits of Stability Induced by Weight-Shifting Training in Elderly Women

- Autor ou entidade: WEB-EX40-04 — Changes in the Limits of Stability Induced by Weight-Shifting Training in Elderly Women — Gouglidis V, Nikodelis T, Hatzitaki V, Amiridis IG — estudo primário experimental — 2011 — https://pubmed.ncbi.nlm.nih.gov/21240818/ — 10.1080/0361073X.2010.507431 — Sustenta a distinção entre deslocações anteroposteriores e mediolaterais e o envolvimento coordenado dos segmentos durante a inclinação.
- Tipo: estudo primário experimental
- Localizador: https://pubmed.ncbi.nlm.nih.gov/21240818/
- Usada para: WEB-EX40-04 — Changes in the Limits of Stability Induced by Weight-Shifting Training in Elderly Women — Gouglidis V, Nikodelis T, Hatzitaki V, Amiridis IG — estudo primário experimental — 2011 — https://pubmed.ncbi.nlm.nih.gov/21240818/ — 10.1080/0361073X.2010.507431 — Sustenta a distinção entre deslocações anteroposteriores e mediolaterais e o envolvimento coordenado dos segmentos durante a inclinação.
- Limite: WEB-EX40-04 — Changes in the Limits of Stability Induced by Weight-Shifting Training in Elderly Women — Gouglidis V, Nikodelis T, Hatzitaki V, Amiridis IG — estudo primário experimental — 2011 — https://pubmed.ncbi.nlm.nih.gov/21240818/ — 10.1080/0361073X.2010.507431 — Sustenta a distinção entre deslocações anteroposteriores e mediolaterais e o envolvimento coordenado dos segmentos durante a inclinação.

### Fonte 7: Breathing pattern disorders and physiotherapy

- Autor ou entidade: WEB-EX40-05 — Breathing pattern disorders and physiotherapy — Cambridge University Hospitals NHS Foundation Trust — orientação profissional de fisioterapia — 2024 — https://www.cuh.nhs.uk/patient-information/breathing-pattern-disorders-and-physiotherapy/ — Sustenta respiração contínua, ombros relaxados e ausência de retenção durante atividade; não fornece cadência específica para esta transferência.
- Tipo: orientação profissional de fisioterapia
- Localizador: https://www.cuh.nhs.uk/patient-information/breathing-pattern-disorders-and-physiotherapy/
- Usada para: WEB-EX40-05 — Breathing pattern disorders and physiotherapy — Cambridge University Hospitals NHS Foundation Trust — orientação profissional de fisioterapia — 2024 — https://www.cuh.nhs.uk/patient-information/breathing-pattern-disorders-and-physiotherapy/ — Sustenta respiração contínua, ombros relaxados e ausência de retenção durante atividade; não fornece cadência específica para esta transferência.
- Limite: WEB-EX40-05 — Breathing pattern disorders and physiotherapy — Cambridge University Hospitals NHS Foundation Trust — orientação profissional de fisioterapia — 2024 — https://www.cuh.nhs.uk/patient-information/breathing-pattern-disorders-and-physiotherapy/ — Sustenta respiração contínua, ombros relaxados e ausência de retenção durante atividade; não fornece cadência específica para esta transferência.
