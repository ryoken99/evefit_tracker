# Sequência jab-direto para manoplas

Conteúdo para principiantes em português europeu.

## Descrição curta

Combinação fechada de jab e direto traseiro contra duas manoplas sustentadas por um parceiro.

## O que é

Em guarda de boxe, executas um jab com a mão da frente e, logo depois, um direto com a mão de trás. Cada golpe contacta a manopla apresentada para esse alvo e cada mão regressa à guarda. É um exercício técnico cooperativo, não é sparring.

## O que vais fazer

Ficas diante de um parceiro treinado para segurar manoplas. Ao sinal combinado, contactas primeiro a manopla do jab e depois a manopla do direto traseiro, mantendo os pés apoiados, o olhar no alvo e o controlo do contacto. Terminas novamente em guarda.

## Porque existe este movimento

O exercício existe para praticar a ordem jab-direto, a ligação entre os segmentos do corpo, a precisão sobre alvos externos e o regresso à guarda, sem oposição livre.

## Antes de começares

1. Confirma que estão presentes duas manoplas, luvas de boxe e ligaduras para as mãos.
2. Pede a um treinador ou supervisor competente que confirme a colocação das ligaduras, o ajuste das luvas e a preparação do parceiro.
3. Combina com o parceiro o sinal de início, a ordem jab-direto e uma palavra de paragem imediatamente reconhecível.
4. Confirma que este exercício permanece uma resposta fechada às manoplas e que nenhum dos participantes irá transformá-lo em sparring.
5. Escolhe um contacto controlado que permita manter punhos alinhados, guarda e equilíbrio; a força não é o objetivo técnico.

## Preparar o equipamento

1. O praticante usa ligaduras bem colocadas e luvas de boxe ajustadas; não executar com as mãos desprotegidas.
2. O parceiro coloca uma manopla em cada mão e confirma que correias, costuras, enchimento e superfícies de contacto estão intactos.
3. O parceiro assume uma guarda estável diante do praticante, com as palmas das manoplas viradas para o praticante.
4. As manoplas do jab e do direto são apresentadas sucessivamente perto da mesma linha central e à altura-alvo indicada pelo treinador, sem ficarem excessivamente afastadas.
5. O parceiro mantém cada alvo estável e não lança a manopla contra a luva nem a desloca para a frente ao encontro do golpe.
6. O parceiro apresenta as palmas das manoplas viradas para o praticante, com punhos e cotovelos controlados.

## Preparar o espaço

1. Usa um espaço de prática livre e controlado, num ginásio de boxe, área de desportos de combate ou pavilhão.
2. Garante espaço lateral para os dois participantes, sem pessoas, sacos, bancos, cabos ou outros obstáculos ao alcance.
3. O piso deve ser firme, nivelado, seco e antiderrapante.
4. Não executar numa superfície escorregadia, numa zona partilhada sem controlo ou com circulação imprevisível.
5. No exterior, aplica os mesmos requisitos e interrompe se calor, humidade ou estado do piso comprometerem atenção, aderência ou controlo.

## Verificação do corpo

1. Consegues fechar as mãos dentro das luvas sem dor, dormência, formigueiro ou compressão excessiva.
2. Consegues colocar-te em guarda, olhar em frente e rodar suavemente o tronco e o pé traseiro sem desconforto.
3. Consegues manter uma base estável com ambos os pés em contacto com o piso.
4. Sentes-te atento e capaz de reconhecer os sinais do parceiro e do supervisor.
5. Se houver dor na mão ou no punho, perda de equilíbrio ou qualquer sinal de alerta indicado abaixo, não inicies e informa o supervisor.

## Posição inicial

Fica em pé, em guarda de boxe, diante do parceiro: pés desencontrados numa base confortável e estável, joelhos desbloqueados, queixo ligeiramente recolhido, olhar nas manoplas e mãos junto à guarda. O parceiro fica também numa base estável e apresenta os alvos dentro do alcance técnico, sem obrigar o praticante a inclinar-se ou a esticar-se em excesso.

## Confirmar a posição inicial

1. Luvas e ligaduras colocadas e confortáveis.
2. Duas manoplas intactas e bem presas ao parceiro.
3. Pés desencontrados, base estável e joelhos desbloqueados.
4. Mãos em guarda, cotovelos próximos do tronco e queixo recolhido.
5. Distância confirmada para os golpes chegarem ao alvo sem queda do tronco para a frente.
6. Sinal de início, ordem dos alvos e palavra de paragem compreendidos.
7. Supervisor presente e espaço livre.

## Passos de execução

1. Espera pelo sinal combinado e identifica a primeira manopla, destinada ao jab, sem abandonar a guarda.
2. Projeta a mão da frente em linha reta para a primeira manopla, com ombro e anca a acompanharem ligeiramente o gesto; mantém a mão traseira junto à guarda.
3. Contacta o centro da manopla com os nós dos dedos protegidos pela luva e com o punho alinhado com o antebraço, sem empurrar nem perseguir o alvo.
4. Retrai de imediato a mão do jab pela mesma linha até à guarda, mantendo o olhar nas manoplas e a base estável.
5. Inicia o direto traseiro a partir do apoio no pé de trás: roda o pé, a anca e o ombro traseiros em conjunto, sem cruzar os pés nem inclinar o corpo para além da base.
6. Estende a mão traseira em linha reta para a segunda manopla enquanto a mão da frente protege a guarda; mantém o punho alinhado no contacto.
7. Retrai a mão traseira pela mesma linha e desfaz apenas a rotação necessária para recuperar a posição de guarda.
8. Confirma o final: mãos em guarda, queixo recolhido, olhar no parceiro, pés apoiados e equilíbrio recuperado.

## Fases do movimento

### Preparação

Guarda estável, distância confirmada e alvos apresentados pelo parceiro.

### Jab

Mão da frente sai em linha reta, contacta a primeira manopla e regressa à guarda.

### Direto traseiro

Pé, anca e ombro traseiros rodam para conduzir a mão de trás à segunda manopla, mantendo a mão da frente em guarda.

### Recuperação

A mão traseira regressa e a pessoa termina equilibrada e novamente em guarda.

## Respiração

Mantém a respiração fluida. Faz uma expiração curta e confortável em cada contacto — uma no jab e outra no direto — e deixa o ar entrar naturalmente entre as ações. Não prendas a respiração e não uses contagens ou retenções.

## Sensações esperadas

1. Contacto breve e controlado da luva no centro de cada manopla.
2. Rotação curta e coordenada do pé, anca e tronco no direto traseiro.
3. Sensação de que cada mão regressa à guarda sem puxar o corpo para fora da base.
4. Expiração curta associada a cada golpe, sem tensão prolongada.

## Sensações inesperadas ou de alerta

1. Dor aguda ou crescente na mão, dedos, punho, cotovelo ou ombro.
2. Punho a dobrar no contacto, impacto sobre os dedos ou sensação de que a luva roda na mão.
3. Dormência, formigueiro, perda de sensibilidade ou pressão excessiva das ligaduras ou luvas.
4. Tonturas, visão alterada, falta de ar invulgar ou dificuldade em responder ao parceiro.
5. Perda de equilíbrio, tropeção ou necessidade de avançar para alcançar as manoplas.
6. Impacto inesperado no parceiro fora das manoplas.

## Indicações técnicas principais

1. Jab, direto, guarda.
2. Uma mão golpeia; a outra protege.
3. Punho alinhado no centro da manopla.
4. Roda a partir do pé traseiro sem sair da base.
5. Expira curto em cada contacto.
6. Termina equilibrado e em guarda.

## Erros comuns e correções

### Erro 1: Deixar a mão traseira descer durante o jab.

- Como reconhecer: A luva traseira afasta-se da face ou o cotovelo abre antes de o jab regressar.
- Como corrigir: Mantém a mão traseira junto à guarda e só inicia o direto depois de a mão do jab começar a regressar.

### Erro 2: Executar o direto apenas com o braço.

- Como reconhecer: O pé e a anca traseiros não rodam e o ombro tenta empurrar sozinho a luva.
- Como corrigir: Liga o gesto em sequência curta: apoio do pé traseiro, rotação da anca e do ombro, extensão da mão.

### Erro 3: Rodar em excesso e perder a base.

- Como reconhecer: O golpe atravessa a linha central, o tronco cai para a frente ou um pé perde o apoio.
- Como corrigir: Encurta a rotação e o alcance até conseguires regressar à guarda com ambos os pés estáveis.

### Erro 4: Dobrar o punho ou contactar fora do centro da manopla.

- Como reconhecer: A luva chega inclinada, resvala pela borda ou surge pressão localizada na mão ou no punho.
- Como corrigir: Reduz o contacto, aponta os nós dos dedos ao centro e mantém punho e antebraço na mesma linha.

### Erro 5: O parceiro afastar demasiado as duas manoplas.

- Como reconhecer: O praticante precisa de lançar os golpes para lados diferentes ou perde a linha reta da combinação.
- Como corrigir: Apresenta os alvos sucessivamente perto da mesma linha central e na distância confirmada pelo supervisor.

### Erro 6: O parceiro lançar a manopla contra a luva.

- Como reconhecer: A manopla avança visivelmente e aumenta o choque no momento de contacto.
- Como corrigir: Mantém o alvo estável, sem o mover ao encontro do golpe, e deixa que a luva percorra a sua linha técnica.

## Formas de simplificar ou ensaiar

1. Antes do contacto, confirma a ordem verbal «jab-direto-guarda» e traça a sequência no ar sob supervisão.
2. Durante o exercício, o parceiro pode apresentar cada manopla de forma claramente sucessiva, mantendo ambas perto da linha central.
3. Pode existir uma pausa visível entre o regresso do jab e o início do direto, desde que a ordem e os dois contactos sejam preservados.
4. Mantém o parceiro parado e a resposta totalmente previsível; não acrescentes deslocamentos, defesas, contra-ataques ou oposição livre.
5. Usa apenas o contacto necessário para obter um alvo nítido e conservar alinhamento, guarda e equilíbrio.

## Supervisão

A supervisão é obrigatória. Um treinador ou supervisor competente em boxe deve confirmar a técnica do praticante, a competência do parceiro, a posição das manoplas, a distância e o controlo do contacto. A primeira exposição, um parceiro novo, qualquer aumento do contacto ou erros repetidos de alvo exigem intervenção imediata. Este exercício não autoriza sparring.

## Como terminar

Após o último direto, regressa à guarda e espera pelo sinal do parceiro ou supervisor. O parceiro baixa as manoplas apenas quando a sequência terminou. Ambos saem da distância de contacto antes de relaxar a guarda. Verifica se mãos, punhos, luvas e manoplas permanecem confortáveis e intactos. Comunica ao supervisor qualquer dor, impacto inesperado, erro de alvo ou perda de equilíbrio.

## Nota de segurança

Risco operacional moderado. Usa sempre luvas, ligaduras, duas manoplas intactas, parceiro treinado e supervisão. Mantém o contacto controlado e dirigido apenas às manoplas. Interrompe se o alvo estiver mal colocado, se houver perda de guarda ou equilíbrio, ou se a sequência começar a transformar-se em contacto livre.

## Quando parar ou reduzir

1. Dor na mão ou no punho.
2. Erro repetido no posicionamento das manoplas.
3. Perda de guarda ou equilíbrio.
4. Punho a dobrar, luva a resvalar ou impacto fora do centro da manopla.
5. Dormência, formigueiro, tonturas, visão alterada ou falta de ar invulgar.
6. Fadiga que impeça reconhecer o alvo, controlar o contacto ou regressar à guarda.

## Segurança do equipamento

Não executar sem luvas de boxe e ligaduras. Refaz ligaduras que estejam demasiado apertadas, soltas ou desconfortáveis, com confirmação do supervisor. Substitui luvas com ajuste deficiente, enchimento deslocado, costuras abertas ou fechos inseguros. Não uses manoplas com correias, costuras, revestimento ou enchimento danificados. O parceiro deve introduzir completamente as mãos nas manoplas e mantê-las seguras durante toda a sequência.

## Segurança do espaço

Mantém uma área lateral livre para ambos os participantes. Usa apenas piso firme, nivelado, seco e antiderrapante. Interrompe se alguém entrar na área de contacto. Não executar numa zona de circulação, perto de obstáculos ou num espaço partilhado sem controlo. No exterior, verifica continuamente o piso, o calor e outras condições que possam reduzir a aderência ou a atenção.

## Limitações

1. Conteúdo documental para principiantes; não prescreve volume, velocidade, intensidade, duração, frequência ou progressão. Não prova transferência para combate, não substitui instrução presencial e não concede autorização universal para executar. Não altera identidade, risco, equipamento, espaço, supervisão, multimédia ou relações aprovadas. Implementação realizada: não.

## Teste de compreensão

### 1. Qual é a ordem dos golpes?

Resposta esperada: Primeiro jab com a mão da frente, depois direto com a mão de trás.

### 2. Onde deve terminar cada mão depois de golpear?

Resposta esperada: Novamente na guarda.

### 3. Que equipamento pessoal é obrigatório?

Resposta esperada: Luvas de boxe e ligaduras para as mãos.

### 4. É possível executar este exercício sem parceiro?

Resposta esperada: Não; o parceiro treinado para segurar as duas manoplas é obrigatório.

### 5. O parceiro deve avançar a manopla contra a luva?

Resposta esperada: Não; deve apresentar um alvo estável e não o mover ao encontro do golpe.

### 6. As duas manoplas devem ficar muito afastadas?

Resposta esperada: Não; devem ser apresentadas sucessivamente perto de uma linha central realista.

### 7. Que mão protege durante o jab?

Resposta esperada: A mão traseira permanece junto à guarda.

### 8. De onde começa a ação do direto traseiro?

Resposta esperada: Do apoio e rotação coordenada do pé, anca e ombro traseiros.

### 9. Como deve estar o punho no contacto?

Resposta esperada: Alinhado com o antebraço e dirigido ao centro da manopla.

### 10. Como se coordena a respiração?

Resposta esperada: Com uma expiração curta e confortável em cada golpe, mantendo a respiração fluida e sem retenção.

### 11. Que sinal obriga a interromper?

Resposta esperada: Por exemplo, dor na mão ou punho, alvo repetidamente mal colocado, perda de guarda ou perda de equilíbrio.

### 12. Este exercício pode transformar-se em sparring?

Resposta esperada: Não; é uma sequência fechada e cooperativa dirigida apenas às manoplas.

## Fontes e limites da evidência

### Fonte 1: Coaching Handbook Part 1

- Autor ou entidade: England Boxing
- Tipo: F1S18 — Coaching Handbook Part 1 — England Boxing — https://www.englandboxing.org/wp-content/uploads/2022/03/EB_Boxing-Coaching-Handbook-Part-1_v8-002.pdf — Proteção das mãos; golpes retos; combinações; padwork. — Sustenta luvas e ligaduras no contacto com manoplas, guarda e recuperação, rotação e base, combinações simples, alvos realistas e proibição de mover a manopla ao encontro do golpe.
- Localizador: https://www.englandboxing.org/wp-content/uploads/2022/03/EB_Boxing-Coaching-Handbook-Part-1_v8-002.pdf
- Usada para: F1S18 — Coaching Handbook Part 1 — England Boxing — https://www.englandboxing.org/wp-content/uploads/2022/03/EB_Boxing-Coaching-Handbook-Part-1_v8-002.pdf — Proteção das mãos; golpes retos; combinações; padwork. — Sustenta luvas e ligaduras no contacto com manoplas, guarda e recuperação, rotação e base, combinações simples, alvos realistas e proibição de mover a manopla ao encontro do golpe.
- Limite: F1S18 — Coaching Handbook Part 1 — England Boxing — https://www.englandboxing.org/wp-content/uploads/2022/03/EB_Boxing-Coaching-Handbook-Part-1_v8-002.pdf — Proteção das mãos; golpes retos; combinações; padwork. — Sustenta luvas e ligaduras no contacto com manoplas, guarda e recuperação, rotação e base, combinações simples, alvos realistas e proibição de mover a manopla ao encontro do golpe.

### Fonte 2: Instruction Beginners Reference Manual

- Autor ou entidade: Boxing Canada
- Tipo: F2-S20 — Instruction Beginners Reference Manual — Boxing Canada — https://boxingcanada.org/wp-content/uploads/2025/01/Instruction-Beginners-Reference-Manual-EN.pdf — Jab; direto traseiro; combinação one-two; utilização eficaz de manoplas. — Sustenta linha, guarda, retração, rotação coordenada, equilíbrio, prioridade da técnica sobre a força, uso de luvas e necessidade de um parceiro experiente nas manoplas.
- Localizador: https://boxingcanada.org/wp-content/uploads/2025/01/Instruction-Beginners-Reference-Manual-EN.pdf
- Usada para: F2-S20 — Instruction Beginners Reference Manual — Boxing Canada — https://boxingcanada.org/wp-content/uploads/2025/01/Instruction-Beginners-Reference-Manual-EN.pdf — Jab; direto traseiro; combinação one-two; utilização eficaz de manoplas. — Sustenta linha, guarda, retração, rotação coordenada, equilíbrio, prioridade da técnica sobre a força, uso de luvas e necessidade de um parceiro experiente nas manoplas.
- Limite: F2-S20 — Instruction Beginners Reference Manual — Boxing Canada — https://boxingcanada.org/wp-content/uploads/2025/01/Instruction-Beginners-Reference-Manual-EN.pdf — Jab; direto traseiro; combinação one-two; utilização eficaz de manoplas. — Sustenta linha, guarda, retração, rotação coordenada, equilíbrio, prioridade da técnica sobre a força, uso de luvas e necessidade de um parceiro experiente nas manoplas.

### Fonte 3: Grassroots Task Force Training Manual v.01

- Autor ou entidade: USA Boxing
- Tipo: EX45-S01 — Grassroots Task Force Training Manual v.01 — USA Boxing — https://d36m266ykvepgv.cloudfront.net/uploads/media/lYivrDbNV6/o/usab-gtf-trainingmanual-v-01-1.pdf — Breathing; ready position; left jab; straight right. — Sustenta expiração curta no golpe, respiração fluida, guarda, base e ligação do jab ao direto.
- Localizador: https://d36m266ykvepgv.cloudfront.net/uploads/media/lYivrDbNV6/o/usab-gtf-trainingmanual-v-01-1.pdf
- Usada para: EX45-S01 — Grassroots Task Force Training Manual v.01 — USA Boxing — https://d36m266ykvepgv.cloudfront.net/uploads/media/lYivrDbNV6/o/usab-gtf-trainingmanual-v-01-1.pdf — Breathing; ready position; left jab; straight right. — Sustenta expiração curta no golpe, respiração fluida, guarda, base e ligação do jab ao direto.
- Limite: EX45-S01 — Grassroots Task Force Training Manual v.01 — USA Boxing — https://d36m266ykvepgv.cloudfront.net/uploads/media/lYivrDbNV6/o/usab-gtf-trainingmanual-v-01-1.pdf — Breathing; ready position; left jab; straight right. — Sustenta expiração curta no golpe, respiração fluida, guarda, base e ligação do jab ao direto.

### Fonte 4: AIBA Coaches Manual

- Autor ou entidade: AIBA
- Tipo: EX45-S02 — AIBA Coaches Manual — AIBA — https://www.iba.sport/wp-content/uploads/2019/01/AIBA-Coach-Regulations-Manual_WEB_2019_01-1.pdf — Golpes retos; combinações de golpes; progressão de ensino. — Sustenta a aprendizagem dos golpes antes da combinação, a sequência jab-direto, a retração à guarda e a atenção à rotação da anca e dos ombros.
- Localizador: https://www.iba.sport/wp-content/uploads/2019/01/AIBA-Coach-Regulations-Manual_WEB_2019_01-1.pdf
- Usada para: EX45-S02 — AIBA Coaches Manual — AIBA — https://www.iba.sport/wp-content/uploads/2019/01/AIBA-Coach-Regulations-Manual_WEB_2019_01-1.pdf — Golpes retos; combinações de golpes; progressão de ensino. — Sustenta a aprendizagem dos golpes antes da combinação, a sequência jab-direto, a retração à guarda e a atenção à rotação da anca e dos ombros.
- Limite: EX45-S02 — AIBA Coaches Manual — AIBA — https://www.iba.sport/wp-content/uploads/2019/01/AIBA-Coach-Regulations-Manual_WEB_2019_01-1.pdf — Golpes retos; combinações de golpes; progressão de ensino. — Sustenta a aprendizagem dos golpes antes da combinação, a sequência jab-direto, a retração à guarda e a atenção à rotação da anca e dos ombros.
