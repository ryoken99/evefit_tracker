# Postura tandem

Conteúdo para principiantes em português europeu.

## Descrição curta

Manter-se de pé com um pé diretamente à frente do outro, numa linha calcanhar-ponta, sem deslocar os apoios.

## O que é

A postura tandem é uma posição bipodal estática: o calcanhar do pé da frente fica junto à ponta do pé de trás, os dois pés permanecem apoiados e o corpo controla pequenas oscilações sobre uma base muito estreita.

## O que vais fazer

Vais entrar numa posição em pé com os pés alinhados um à frente do outro, estabilizar o corpo sem dar passos e sair da posição de forma controlada.

## Porque existe este movimento

Esta tarefa existe para praticar o controlo postural numa base de apoio comprida e muito estreita. É uma postura estática, não uma caminhada, e não garante por si só qualquer resultado noutras tarefas.

## Antes de começares

1. Confirma que compreendes a posição e que consegues iniciar e interromper a tarefa voluntariamente.
2. Escolhe uma área livre, bem iluminada e sem circulação de pessoas, animais ou objetos.
3. Verifica se o piso é firme, plano, estável e antiderrapante.
4. Se optares por apoio, coloca ao lado uma bancada, corrimão ou cadeira firme que não deslize nem tombe.
5. Não inicies se já sentires dor aguda, tontura, mal-estar ou falta de controlo em pé.
6. Se tiveres risco elevado de queda, quedas recentes, dificuldade em sair da posição sem ajuda ou uma restrição clínica relevante, faz a tarefa apenas com supervisão adequada.

## Preparar o equipamento

1. Nenhum equipamento é obrigatório.
2. Podes usar um apoio estável ao alcance, como uma bancada fixa, um corrimão seguro ou uma cadeira firme que não deslize nem tombe.
3. Testa o apoio antes de entrar na posição. Um objeto leve, com rodas, dobrável, solto ou instável não é um apoio seguro.

## Preparar o espaço

1. Usa um piso firme, plano, estável e antiderrapante.
2. Mantém a pequena área em redor livre de tapetes soltos, cabos, objetos, animais e outras causas de tropeção.
3. Garante iluminação suficiente para ver o piso e fixa o olhar num ponto estável à frente.
4. Não executes num veículo em movimento, junto a uma altura desprotegida, nem sobre uma superfície escorregadia, instável ou desorganizada.

## Verificação do corpo

1. Confirma que consegues ficar de pé com apoio próximo e interromper voluntariamente a tarefa.
2. Não inicies perante tontura, alteração súbita da visão, dor aguda ou sensação de desmaio.
3. Usa a direção inicial que permita entrar e sair sem cruzar obstáculos; a ficha não impõe um lado universal.

## Posição inicial

Fica de pé, direito e ao lado do apoio opcional. Começa com uma base confortável, olhos abertos e olhar em frente. Com controlo, coloca um pé diretamente à frente do outro até o calcanhar do pé da frente ficar junto à ponta do pé posterior e os dois pés formarem uma linha.

## Confirmar a posição inicial

1. Os dois pés estão totalmente em contacto com o piso.
2. O pé da frente está diretamente à frente do pé de trás.
3. O calcanhar da frente está junto à ponta do pé posterior.
4. Não existe espaço lateral intencional entre as linhas dos pés.
5. A bacia e o tronco estão orientados em frente, sem torção forçada.
6. Os olhos estão abertos e o apoio opcional está ao alcance.

## Passos de execução

1. Posiciona-te ao lado do apoio opcional e confirma que o piso e a área estão seguros.
2. Parte de uma posição em pé estável e fixa o olhar num ponto parado à tua frente.
3. Se necessário, usa um contacto leve e planeado no apoio enquanto colocas um pé diretamente à frente do outro.
4. Aproxima o calcanhar do pé da frente da ponta do pé posterior, formando uma linha calcanhar-ponta, sem criar distância lateral.
5. Mantém ambos os pés pousados e o tronco vertical; não forces uma distribuição exatamente igual do peso entre os pés.
6. Deixa tornozelos e ancas fazerem pequenas correções, mantendo os pés no lugar e respirando naturalmente.
7. Se precisares repetidamente de agarrar o apoio, mover os pés ou deres um passo involuntário, termina a tentativa em vez de insistir.
8. Para sair, usa o apoio se necessário e desloca um pé para o lado até recuperar uma base confortável e estável.

## Fases do movimento

### Preparação

Verificar piso, espaço, apoio opcional, olhar e capacidade de interromper.

### Entrada

Levar um pé para a frente e estabelecer o alinhamento completo calcanhar-ponta.

### Controlo estático

Conservar ambos os apoios no lugar enquanto o corpo faz pequenas correções posturais.

### Saída

Alargar a base com um passo controlado e confirmar que o equilíbrio foi recuperado.

## Respiração

Respira de forma natural e contínua. Não prendas a respiração. A postura é estática e não exige sincronizar inspiração ou expiração com uma fase específica.

## Sensações esperadas

1. Pequenas oscilações do corpo, sobretudo para os lados.
2. Correções discretas nos tornozelos e nas ancas.
3. Pressão de apoio presente nos dois pés, sem necessidade de ser exatamente igual.
4. Atenção acrescida ao olhar, ao alinhamento dos pés e ao contacto com o chão.

## Sensações inesperadas ou de alerta

1. Dor aguda ou dor que surge de forma súbita.
2. Tontura, sensação de desmaio, visão alterada ou mal-estar.
3. Perda de controlo que obriga a dar um passo ou a agarrar o apoio de forma brusca.
4. Incapacidade de sair da posição sem ajuda.
5. Qualquer sensação nova que torne inseguro continuar.

## Indicações técnicas principais

1. Calcanhar da frente junto à ponta do pé de trás.
2. Pés na mesma linha e totalmente apoiados.
3. Olhos abertos e olhar estável em frente.
4. Tronco alto, sem rodar a bacia.
5. Pequenas correções, sem deslocar os pés.
6. Respiração natural e contínua.

## Erros comuns e correções

### Erro 1: Deixar espaço lateral entre os pés.

- Como reconhecer: Vê-se uma faixa de piso entre a linha do pé da frente e a linha do pé de trás.
- Como corrigir: Recomeça a partir de uma base segura e alinha o calcanhar da frente diretamente com a ponta do pé posterior. Se não conseguires fazê-lo com controlo, não transformes a tarefa em semi-tandem.

### Erro 2: Rodar os pés ou a bacia para fugir ao alinhamento.

- Como reconhecer: As pontas dos pés apontam claramente para lados diferentes ou o tronco fica torcido.
- Como corrigir: Volta a orientar pés, bacia e tronco em frente, apenas dentro de uma posição confortável e controlada.

### Erro 3: Olhar continuamente para os pés ou fechar os olhos.

- Como reconhecer: A cabeça desce, o olhar deixa o ponto fixo ou as pálpebras fecham.
- Como corrigir: Confirma primeiro a colocação dos pés e depois mantém os olhos abertos, com o olhar num ponto estável à frente.

### Erro 4: Mover os pés para prolongar a postura.

- Como reconhecer: Um pé desliza, roda ou dá um passo depois de a posição ter sido estabelecida.
- Como corrigir: Considera a tentativa terminada, recupera uma base larga e volta a organizar-se apenas quando estiveres estável.

### Erro 5: Agarrar de surpresa um apoio instável.

- Como reconhecer: O objeto mexe, desliza ou tomba quando recebe peso, ou a mão procura apoio fora do alcance.
- Como corrigir: Usa apenas um apoio previamente testado, firme e ao alcance; se houver uma preensão brusca, termina e recupera a estabilidade.

### Erro 6: Prender a respiração e enrijecer todo o corpo.

- Como reconhecer: A respiração para, os ombros sobem e as pequenas correções tornam-se rígidas.
- Como corrigir: Retoma uma respiração natural e permite correções pequenas nos tornozelos e nas ancas, sem relaxar a atenção.

## Formas de simplificar ou ensaiar

1. Usa contacto leve e planeado numa bancada, corrimão ou cadeira firme ao entrar, permanecer e sair da posição.
2. Pede a uma pessoa capaz de supervisionar que permaneça próxima e pronta a ajudar, sem puxar nem empurrar.
3. Mantém o alinhamento tandem completo; afastar os pés lateralmente corresponde a outra postura e não é uma simplificação desta identidade.
4. Não uses uma superfície instável como forma de facilitar ou alterar a tarefa.

## Supervisão

A supervisão é recomendada. Não executes sem supervisão quando houver risco elevado de queda, quedas recentes, incapacidade de sair da posição de forma independente, necessidade repetida de apoio não planeado ou uma restrição clínica relevante. A pessoa que supervisiona deve ficar próxima, fora da linha dos pés e pronta a ajudar sem provocar desequilíbrio. Não é exigido um assistente de segurança em todos os casos.

## Como terminar

Termina de forma voluntária antes de o controlo se perder, ou imediatamente perante um sinal de interrupção. Usa o apoio opcional se necessário, dá um passo controlado para o lado, fica com os pés numa base confortável e só abandona o local quando estiveres estável.

## Nota de segurança

Risco operacional moderado devido à base muito estreita e à possibilidade de queda. Tem um apoio firme ao alcance e não executes sem supervisão quando o risco de queda for elevado. Não insistas após perda de controlo.

## Quando parar ou reduzir

1. Dor aguda.
2. Mal-estar.
3. Tontura ou sensação de desmaio.
4. Necessidade repetida de apoio não planeado.
5. Movimento involuntário dos pés ou passo para evitar uma queda.
6. Perda de controlo.
7. Incapacidade de sair da tarefa de forma independente.

## Segurança do equipamento

O apoio é opcional, mas, quando usado, deve ser estável, estar ao alcance e resistir ao contacto sem deslizar ou tombar. Não uses cadeiras com rodas, objetos leves, móveis dobráveis não bloqueados ou superfícies soltas.

## Segurança do espaço

Executa apenas numa área livre e bem iluminada, sobre piso firme, plano, estável e antiderrapante. Evita tapetes soltos, cabos, objetos, animais, piso molhado, terreno irregular, superfícies instáveis, veículos em movimento e alturas desprotegidas.

## Limitações

1. O conteúdo é educativo e não determina elegibilidade individual.
2. Não inclui dose, duração, progressão programada, diagnóstico, tratamento ou promessa de resultado.
3. As fontes de avaliação e do programa Otago foram usadas apenas para técnica e segurança pertinentes; os respetivos protocolos não foram reproduzidos.
4. Os estudos primários incluem amostras e contextos específicos, pelo que não autorizam generalização automática a todas as populações.
5. A relação entre apoio, desempenho e risco deve ser interpretada por profissional quando existirem quedas recentes, condições neurológicas ou vestibulares, regresso à função ou incapacidade de sair da posição.
6. Identidade, risco moderado, apoio opcional, requisitos de superfície e relações canónicas foram preservados.
7. Implementação realizada: não

## Teste de compreensão

### 1. Onde fica o pé da frente na postura tandem?

Resposta esperada: Diretamente à frente do outro, com o calcanhar junto à ponta do pé posterior.

### 2. Os pés podem ficar afastados lateralmente?

Resposta esperada: Não, porque esse afastamento deixa de corresponder à postura tandem completa.

### 3. É necessário caminhar?

Resposta esperada: Não.

### 4. Que piso deve ser escolhido?

Resposta esperada: Um piso firme, plano, estável e antiderrapante.

### 5. O apoio é obrigatório?

Resposta esperada: Não; é opcional, mas deve ser firme e estar ao alcance quando for usado.

### 6. Como deve ser usado o apoio opcional?

Resposta esperada: Com contacto planeado e leve, num objeto testado que não deslize nem tombe.

### 7. Para onde deves olhar?

Resposta esperada: Para um ponto estável à frente, com os olhos abertos.

### 8. Como deves respirar?

Resposta esperada: De forma natural e contínua, sem prender a respiração.

### 9. O peso tem de estar exatamente dividido entre os dois pés?

Resposta esperada: Não.

### 10. O que fazer se um pé deslizar ou for preciso dar um passo?

Resposta esperada: Terminar a tentativa e recuperar uma base confortável e estável.

### 11. Quando é especialmente importante ter supervisão?

Resposta esperada: Quando existe risco elevado de queda, quedas recentes, incapacidade de sair sozinho, apoio não planeado repetido ou restrição clínica relevante.

### 12. Como se sai da posição?

Resposta esperada: Usando o apoio se necessário e dando um passo controlado para o lado até recuperar uma base confortável.

## Fontes e limites da evidência

### Fonte 1: The 4-Stage Balance Test

- Autor ou entidade: CDC-STEADI-4STAGE — instrumento oficial — Centers for Disease Control and Prevention, STEADI — The 4-Stage Balance Test — 2017 — https://www.cdc.gov/steadi/media/pdfs/STEADI-Assessment-4Stage-508.pdf — Confirma a posição tandem com o calcanhar a tocar a ponta, os olhos abertos, os pés imóveis e a necessidade de assistência pronta perante perda de equilíbrio. — É um protocolo de avaliação e inclui temporização; o presente conteúdo usa apenas a definição posicional e as salvaguardas, não a dose nem a interpretação do teste.
- Tipo: instrumento oficial
- Localizador: https://www.cdc.gov/steadi/media/pdfs/STEADI-Assessment-4Stage-508.pdf
- Usada para: CDC-STEADI-4STAGE — instrumento oficial — Centers for Disease Control and Prevention, STEADI — The 4-Stage Balance Test — 2017 — https://www.cdc.gov/steadi/media/pdfs/STEADI-Assessment-4Stage-508.pdf — Confirma a posição tandem com o calcanhar a tocar a ponta, os olhos abertos, os pés imóveis e a necessidade de assistência pronta perante perda de equilíbrio. — É um protocolo de avaliação e inclui temporização; o presente conteúdo usa apenas a definição posicional e as salvaguardas, não a dose nem a interpretação do teste.
- Limite: CDC-STEADI-4STAGE — instrumento oficial — Centers for Disease Control and Prevention, STEADI — The 4-Stage Balance Test — 2017 — https://www.cdc.gov/steadi/media/pdfs/STEADI-Assessment-4Stage-508.pdf — Confirma a posição tandem com o calcanhar a tocar a ponta, os olhos abertos, os pés imóveis e a necessidade de assistência pronta perante perda de equilíbrio. — É um protocolo de avaliação e inclui temporização; o presente conteúdo usa apenas a definição posicional e as salvaguardas, não a dose nem a interpretação do teste.

### Fonte 2: Tools to Implement the Otago Exercise Program

- Autor ou entidade: UNC-OTAGO-2024 — manual profissional — UNC Center for Aging and Health — Tools to Implement the Otago Exercise Program — 2024 — https://www.med.unc.edu/aging/cgwep/wp-content/uploads/sites/865/2024/04/Otago-Guide-for-PT_April-2024-update.pdf — Sustenta postura alta, olhar em frente, pés em linha, um pé diretamente à frente do outro, contacto leve com cadeira ou bancada e respiração durante o exercício. — O manual dirige-se a um programa profissional para pessoas idosas e contém dose e progressões que não foram transpostas.
- Tipo: manual profissional
- Localizador: https://www.med.unc.edu/aging/cgwep/wp-content/uploads/sites/865/2024/04/Otago-Guide-for-PT_April-2024-update.pdf
- Usada para: UNC-OTAGO-2024 — manual profissional — UNC Center for Aging and Health — Tools to Implement the Otago Exercise Program — 2024 — https://www.med.unc.edu/aging/cgwep/wp-content/uploads/sites/865/2024/04/Otago-Guide-for-PT_April-2024-update.pdf — Sustenta postura alta, olhar em frente, pés em linha, um pé diretamente à frente do outro, contacto leve com cadeira ou bancada e respiração durante o exercício. — O manual dirige-se a um programa profissional para pessoas idosas e contém dose e progressões que não foram transpostas.
- Limite: UNC-OTAGO-2024 — manual profissional — UNC Center for Aging and Health — Tools to Implement the Otago Exercise Program — 2024 — https://www.med.unc.edu/aging/cgwep/wp-content/uploads/sites/865/2024/04/Otago-Guide-for-PT_April-2024-update.pdf — Sustenta postura alta, olhar em frente, pés em linha, um pé diretamente à frente do outro, contacto leve com cadeira ou bancada e respiração durante o exercício. — O manual dirige-se a um programa profissional para pessoas idosas e contém dose e progressões que não foram transpostas.

### Fonte 3: Interpreting the Need for Initial Support to Perform Tandem Stance Tests of Balance

- Autor ou entidade: HILE-2012 — literatura primária, análise observacional — Hile ES, Brach JS, Perera S, Wert DM, VanSwearingen JM, Studenski SA — Interpreting the Need for Initial Support to Perform Tandem Stance Tests of Balance — 2012 — 10.2522/ptj.20110283 — https://academic.oup.com/ptj/article/92/10/1316/2735160 — Mostra que a necessidade de apoio inicial para estabilizar deve ser registada e tem significado na interpretação do desempenho; apoia a entrada assistida e a supervisão. — Estudo transversal secundário em adultos mais velhos; não fundamenta resultados universais nem uma prescrição.
- Tipo: literatura primária, análise observacional
- Localizador: https://academic.oup.com/ptj/article/92/10/1316/2735160
- Usada para: HILE-2012 — literatura primária, análise observacional — Hile ES, Brach JS, Perera S, Wert DM, VanSwearingen JM, Studenski SA — Interpreting the Need for Initial Support to Perform Tandem Stance Tests of Balance — 2012 — 10.2522/ptj.20110283 — https://academic.oup.com/ptj/article/92/10/1316/2735160 — Mostra que a necessidade de apoio inicial para estabilizar deve ser registada e tem significado na interpretação do desempenho; apoia a entrada assistida e a supervisão. — Estudo transversal secundário em adultos mais velhos; não fundamenta resultados universais nem uma prescrição.
- Limite: HILE-2012 — literatura primária, análise observacional — Hile ES, Brach JS, Perera S, Wert DM, VanSwearingen JM, Studenski SA — Interpreting the Need for Initial Support to Perform Tandem Stance Tests of Balance — 2012 — 10.2522/ptj.20110283 — https://academic.oup.com/ptj/article/92/10/1316/2735160 — Mostra que a necessidade de apoio inicial para estabilizar deve ser registada e tem significado na interpretação do desempenho; apoia a entrada assistida e a supervisão. — Estudo transversal secundário em adultos mais velhos; não fundamenta resultados universais nem uma prescrição.

### Fonte 4: Postural steadiness and weight distribution during tandem stance in healthy young and elderly adults

- Autor ou entidade: JONSSON-2005 — literatura primária, estudo biomecânico transversal — Jonsson E, Seiger A, Hirschfeld H — Postural steadiness and weight distribution during tandem stance in healthy young and elderly adults — 2005 — 10.1016/j.clinbiomech.2004.09.008 — https://pubmed.ncbi.nlm.nih.gov/15621326/ — Sustenta que a entrada na postura é uma fase exigente e que a distribuição do peso não tem de ser igual, sendo frequente maior carga no membro posterior. — Amostra saudável e contexto laboratorial; não permite indicar uma distribuição individual obrigatória.
- Tipo: literatura primária, estudo biomecânico transversal
- Localizador: https://pubmed.ncbi.nlm.nih.gov/15621326/
- Usada para: JONSSON-2005 — literatura primária, estudo biomecânico transversal — Jonsson E, Seiger A, Hirschfeld H — Postural steadiness and weight distribution during tandem stance in healthy young and elderly adults — 2005 — 10.1016/j.clinbiomech.2004.09.008 — https://pubmed.ncbi.nlm.nih.gov/15621326/ — Sustenta que a entrada na postura é uma fase exigente e que a distribuição do peso não tem de ser igual, sendo frequente maior carga no membro posterior. — Amostra saudável e contexto laboratorial; não permite indicar uma distribuição individual obrigatória.
- Limite: JONSSON-2005 — literatura primária, estudo biomecânico transversal — Jonsson E, Seiger A, Hirschfeld H — Postural steadiness and weight distribution during tandem stance in healthy young and elderly adults — 2005 — 10.1016/j.clinbiomech.2004.09.008 — https://pubmed.ncbi.nlm.nih.gov/15621326/ — Sustenta que a entrada na postura é uma fase exigente e que a distribuição do peso não tem de ser igual, sendo frequente maior carga no membro posterior. — Amostra saudável e contexto laboratorial; não permite indicar uma distribuição individual obrigatória.

### Fonte 5: Direction-Dependent Control of Balance During Walking and Standing

- Autor ou entidade: OCONNOR-KUO-2009 — literatura primária, estudo biomecânico — O'Connor SM, Kuo AD — Direction-Dependent Control of Balance During Walking and Standing — 2009 — 10.1152/jn.00131.2009 — https://pmc.ncbi.nlm.nih.gov/articles/PMC2746770/ — Demonstra que a posição tandem aumenta particularmente a sensibilidade do controlo mediolateral, coerente com a base muito estreita e com pequenas correções laterais. — Estudo experimental de mecanismos de equilíbrio; não fornece instrução clínica individual nem promessa de benefício.
- Tipo: literatura primária, estudo biomecânico
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC2746770/
- Usada para: OCONNOR-KUO-2009 — literatura primária, estudo biomecânico — O'Connor SM, Kuo AD — Direction-Dependent Control of Balance During Walking and Standing — 2009 — 10.1152/jn.00131.2009 — https://pmc.ncbi.nlm.nih.gov/articles/PMC2746770/ — Demonstra que a posição tandem aumenta particularmente a sensibilidade do controlo mediolateral, coerente com a base muito estreita e com pequenas correções laterais. — Estudo experimental de mecanismos de equilíbrio; não fornece instrução clínica individual nem promessa de benefício.
- Limite: OCONNOR-KUO-2009 — literatura primária, estudo biomecânico — O'Connor SM, Kuo AD — Direction-Dependent Control of Balance During Walking and Standing — 2009 — 10.1152/jn.00131.2009 — https://pmc.ncbi.nlm.nih.gov/articles/PMC2746770/ — Demonstra que a posição tandem aumenta particularmente a sensibilidade do controlo mediolateral, coerente com a base muito estreita e com pequenas correções laterais. — Estudo experimental de mecanismos de equilíbrio; não fornece instrução clínica individual nem promessa de benefício.
