# Relatório de investigação — `overground_walking`

**Agente:** EX-01  
**Exercício:** Caminhada terrestre  
**Data de fecho da investigação:** 23 de julho de 2026  
**Âmbito:** execução, preparação, respiração, segurança, erros e supervisão  
**Estado proposto do conteúdo:** `beginner_content_approved_with_limits`

## 1. Resultado

Foi produzido conteúdo introdutório específico e coerente com o registo canónico. A investigação sustenta:

- verificação prévia de um percurso firme, regular, visível e livre;
- posição de pé confortável, atenção dirigida à zona à frente e transferência alternada de peso;
- apoio do pé controlado, sem impor um padrão rígido universal;
- balanço natural dos braços;
- mudança de direção através de passos em vez de um pivô brusco num pé fixo;
- respiração natural e contínua, sem retenções ou contagens obrigatórias;
- interrupção perante os sinais canónicos;
- adaptação da decisão ao tráfego, visibilidade, temperatura e qualidade do ar;
- manutenção da regra canónica de que não existe supervisão obrigatória por definição, com orientação adicional perante os gatilhos já aprovados.

Não foi encontrada base para alterar a identidade, o risco, o equipamento, a supervisão canónica ou qualquer relação aprovada.

## 2. Elementos canónicos preservados

| Campo | Valor preservado |
|---|---|
| `exercise_id` | `overground_walking` |
| Nome | Caminhada terrestre |
| Tipo | `canonical_exercise` |
| Família | `walking_family` |
| Capacidade principal | `cardio_conditioning` |
| `variant_of` | `none` |
| `base_exercise_id` | `none` |
| Risco operacional | `low` |
| Equipamento obrigatório | nenhum |
| Supervisão | `none` |
| Superfície | firme e regular |
| Direção | para a frente |
| Fase aérea | ausente |
| Relações aprovadas | preservadas sem adição, remoção ou alteração |
| Multimédia | não aprovada |

## 3. Método e limites da pesquisa

A pesquisa externa foi limitada aos seis tópicos autorizados. Foram privilegiadas fontes oficiais, governamentais, hospitalares e de organizações profissionais. As fontes preexistentes do pacote foram mantidas como base de família e contexto; foram acrescentadas fontes independentes para execução e segurança.

Não foram pesquisadas nem transportadas recomendações de dose, programas de progressão, resultados prometidos, diagnóstico, tratamento ou autorização universal. Recomendações quantitativas presentes em algumas páginas foram excluídas.

## 4. Fontes preexistentes

### A1-S01 — American College of Sports Medicine

- **Título:** *Exercising Your Way to Lowering Your Blood Pressure*
- **URL:** https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf
- **Tipo:** organização profissional
- **Utilização:** confirma a caminhada como modalidade aeróbia reconhecida.
- **Limite:** fonte de família; não sustenta identidade fina, execução detalhada, dose ou resultado individual.

### A1-S03 — American Heart Association

- **Título:** *Recommendations for Adults*
- **URL:** https://www.heart.org/en/healthy-living/exercise-and-physical-activity/fitness-basics/aha-recs-for-physical-activity-in-adults
- **Tipo:** organização profissional
- **Utilização:** confirma a caminhada como exemplo de atividade física.
- **Limite:** as recomendações quantitativas da página não foram transportadas.

### A2-S04 — American College of Sports Medicine

- **Título:** *Investing in a Personal Trainer*
- **URL:** https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf
- **Tipo:** organização profissional
- **Utilização:** confirma a caminhada entre exemplos típicos de atividade aeróbia.
- **Limite:** lista exemplificativa, não uma taxonomia mecânica.

### A2-S05 — U.S. Department of Health and Human Services

- **Título:** *Physical Activity Guidelines for Americans, 2nd edition*
- **URL:** https://health.gov/sites/default/files/2019-09/Physical_Activity_Guidelines_2nd_edition.pdf
- **Tipo:** orientação governamental
- **Utilização:** contexto geral de atividade física e reconhecimento de opções adequadas à pessoa.
- **Limite:** não foi transportada qualquer recomendação de volume, frequência ou intensidade.

## 5. Fontes externas consultadas e decisões

### EX01-R01 — NHS

- **Título:** *Walking for health*
- **URL:** https://www.nhs.uk/live-well/exercise/walking-for-health/
- **Tipo:** orientação oficial de saúde
- **Informação relevante:** calçado confortável, com apoio adequado e sem provocar bolhas, como preparação pessoal.
- **Decisão:** o conteúdo mantém “sem equipamento obrigatório” e apresenta o calçado apenas como escolha pessoal dependente da pessoa e da superfície.
- **Exclusão:** recomendações de duração, velocidade e progressão.

### EX01-R02 — Leicestershire Partnership NHS Trust

- **Título:** *Advice on gait (walking)*
- **URL:** https://www.leicspart.nhs.uk/wp-content/uploads/2019/02/660-Advice-on-gait.pdf
- **Tipo:** orientação profissional de fisioterapia
- **Informação relevante:** transferência segura de peso, contribuição do balanço dos braços para a estabilidade, comprimento de passo confortável, progressão do apoio do calcanhar para os dedos e mudança de direção sem girar num pé fixo.
- **Decisão:** foram transportados a transferência de peso, o balanço natural dos braços, o apoio controlado e a mudança de direção por passos.
- **Limite:** é material clínico de marcha. A formulação calcanhar-ponta não foi convertida numa regra universal nem numa tentativa de normalizar todas as formas de contacto do pé.

### EX01-R03 — National Highway Traffic Safety Administration

- **Título:** *Pedestrian Safety: Prevent Pedestrian Crashes*
- **URL:** https://www.nhtsa.gov/road-safety/pedestrian-safety
- **Tipo:** orientação governamental de segurança rodoviária
- **Informação relevante:** necessidade de permanecer atento, observar e escutar o ambiente e usar locais de travessia apropriados.
- **Decisão:** reforço da atenção ao trajeto e exclusão de percursos com tráfego não controlado.
- **Limite:** aplica-se à segurança de peões em contexto rodoviário, não à mecânica da caminhada.

### EX01-R04 — American College of Sports Medicine

- **Título:** *Exercising in Hot and Cold Environments*
- **URL:** https://acsm.org/wp-content/uploads/2025/02/Exercising-in-hot-and-cold-environments.pdf
- **Tipo:** orientação de organização profissional
- **Informação relevante:** o calor e o frio alteram o risco; confusão, tontura e desorientação são sinais relevantes; perante stress térmico deve cessar-se o exercício e procurar-se um ambiente seguro.
- **Decisão:** manutenção de calor e frio como modificadores ambientais e reforço dos sinais canónicos de tontura ou confusão.
- **Exclusão:** limiares, horários, duração, intensidade e estratégias quantitativas.

### EX01-R05 — Royal Devon University Healthcare NHS Foundation Trust

- **Título:** *Rehabilitation Following COVID-19*
- **URL:** https://www.royaldevon.nhs.uk/media/vcxdfzst/rehabilitation-following-covid-19.pdf
- **Tipo:** orientação hospitalar de reabilitação
- **Informação relevante:** evitar prender a respiração durante atividades gerais; respirar sem forçar.
- **Decisão:** usada apenas como apoio limitado para a formulação “respiração natural e contínua, sem retenção”.
- **Limite:** população clínica específica. Técnicas terapêuticas, respiração com lábios semicerrados, sincronização com passos e outras instruções clínicas não foram generalizadas.

### EX01-R06 — Oxford University Hospitals NHS Foundation Trust

- **Título:** *OTAGO Strength and Balance*
- **URL:** https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf
- **Tipo:** orientação hospitalar de fisioterapia
- **Informação relevante:** ambiente preparado, calçado de apoio, suporte compatível com necessidades de equilíbrio e interrupção perante dor no peito, tontura ou falta de ar grave.
- **Decisão:** usada apenas para corroborar segurança, sinais de interrupção e necessidade de orientação quando existe instabilidade.
- **Limite:** programa dirigido à prevenção de quedas. Não foi transportada nenhuma sequência, dose, progressão ou exigência universal de apoio.

## 6. Síntese por tópico

### 6.1 Preparação

O pacote canónico exige capacidade para manter o padrão de apoio e um local ativo adequado. A investigação acrescenta linguagem operacional simples: confirmar estabilidade de pé, inspecionar o piso, identificar obstáculos, manter visão do percurso e considerar condições ambientais. O calçado permanece equipamento pessoal opcional, não um requisito identitário.

### 6.2 Execução

A ação foi decomposta em preparação, transferência de peso, avanço de um pé, receção controlada do apoio, alternância, progressão para a frente, mudança de direção e finalização estável. Esta sequência preserva a locomoção bípede cíclica sem fase aérea intencional.

### 6.3 Contacto do pé

A fonte NHS de fisioterapia recomenda uma sequência calcanhar-ponta. No entanto, a sua população e finalidade não permitem tratar essa formulação como lei universal da caminhada. A decisão editorial foi descrever um apoio controlado que progride naturalmente pelo pé e proibir apenas a imposição rígida ou o contacto sem controlo.

### 6.4 Braços e olhar

O balanço dos braços foi descrito como natural e não exagerado. O olhar é dirigido à zona à frente, mantendo consciência do piso próximo; isto evita a alternativa falsa entre olhar apenas para os pés e ignorar o terreno.

### 6.5 Respiração

Não foi encontrada necessidade de uma técnica respiratória específica para a identidade da caminhada terrestre. Aplicou-se a regra contratual: respiração natural e contínua, sem retenções, contagens ou sincronização obrigatória com os passos.

### 6.6 Segurança e interrupção

Foram mantidos exatamente os três grupos canónicos de sinais:

- desconforto no peito ou falta de ar atípica;
- tontura ou confusão;
- perda de controlo ou dor nova.

O texto explica como reconhecer estes sinais sem diagnosticar a causa. A saída operacional é interromper, ficar num local seguro e obter ajuda adequada ao contexto.

### 6.7 Supervisão

O requisito canónico continua a ser `none`. Não foi criada obrigação geral de supervisão. A orientação pública refere apenas os gatilhos já aprovados: instabilidade marcada, ambiente desconhecido, regresso após lesão ou cirurgia, limitações de equilíbrio e sintomas cardiorrespiratórios relevantes.

## 7. Erros documentados

Foram incluídos sete erros observáveis, cada um com forma de reconhecimento e correção:

1. olhar apenas para os pés;
2. forçar um passo demasiado comprido;
3. pousar o pé sem controlo ou arrastá-lo;
4. bloquear ou exagerar o movimento dos braços;
5. rodar sobre um pé fixo;
6. prender a respiração;
7. continuar apesar de sinais de aviso.

Nenhum erro foi convertido em diagnóstico ou numa inferência sobre doença.

## 8. Conflitos e resolução

| Tema | Tensão encontrada | Resolução |
|---|---|---|
| Apoio do pé | A fonte clínica formula uma sequência calcanhar-ponta; a generalização rígida não está sustentada para todas as pessoas. | Apoio controlado e progressão natural, sem padrão universal imposto. |
| Calçado | A fonte NHS recomenda características de calçado; o registo canónico não exige equipamento. | Calçado apresentado apenas como escolha pessoal dependente da pessoa e da superfície. |
| Respiração | Fontes clínicas incluem técnicas terapêuticas e sincronização com passos. | Mantida apenas respiração natural e contínua, sem retenção. |
| Apoios de marcha | Fontes clínicas referem dispositivos e suporte. | Não adicionados equipamentos, apoios ou variantes; apenas recomendação de avaliação quando existe instabilidade. |
| Dose | Várias fontes incluem duração, velocidade, frequência ou progressão. | Todas as doses foram excluídas. |
| Benefícios | Algumas fontes fazem afirmações sobre resultados de saúde. | Nenhuma promessa de resultado foi incluída. |

## 9. Decisões editoriais

- Uso de instruções na segunda pessoa do singular, em português europeu claro.
- Nove passos de execução, acima do mínimo contratual de cinco.
- Seis pistas principais, acima do mínimo de quatro.
- Sete erros completos, acima do mínimo de quatro.
- Doze perguntas de compreensão, conforme o contrato.
- Estado `beginner_content_approved_with_limits`, porque a identidade é sólida mas parte da técnica detalhada deriva de materiais clínicos cuja generalização foi deliberadamente limitada.
- `unresolved_fields: []`, porque os limites estão documentados e não existe um campo material pendente que justifique revisão especialista.

## 10. Limitações finais

- A investigação não valida elegibilidade individual.
- A forma de contacto do pé pode variar e não foi normalizada.
- Não foi avaliado um percurso, clima, qualidade do ar ou condição individual concretos.
- Não foi pesquisada nem documentada dose.
- Não foram feitas promessas de desempenho, saúde, recuperação ou prevenção.
- Não foram emitidos diagnóstico, tratamento ou autorização clínica.
- Não foi aprovado material multimédia.

## 11. Declaração de zero implementação

Este trabalho é exclusivamente documental. Foram criados apenas o conteúdo público em Markdown, o registo JSON correspondente e este relatório de investigação. Não foi escrito ou alterado código de produto, não foi executada publicação, não foi criada interface, não foi aprovada multimédia, não foi adicionada prescrição e não foi implementada qualquer relação, regra de elegibilidade ou lógica de treino.
