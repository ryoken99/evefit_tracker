# Sprint linear — relatório de investigação

## Identificação e âmbito

- **Agente:** EX-19
- **Exercício:** `linear_sprint`
- **Nome:** Sprint linear
- **Entidade:** exercício canónico
- **Família:** `sprint_locomotion`
- **Capacidade principal:** `speed_power`
- **Risco operacional preservado:** alto
- **Equipamento obrigatório preservado:** nenhum
- **Superfície preservada:** firme, regular e antiderrapante
- **Supervisão preservada:** recomendada
- **Relações aprovadas preservadas:** locomoção cíclica para aumento da velocidade locomotora máxima; aceleração explosiva para aumento da aceleração inicial

O trabalho ficou limitado à documentação pública para um principiante absoluto. Não foram alteradas identidade, classificação de risco, equipamento, superfície, relações, multimédia ou estado canónico.

## Perguntas de investigação

1. Como descrever a partida em pé e a aceleração sem confundir o sprint linear com uma saída delimitada ou com blocos?
2. Que organização de tronco, membros inferiores e braços é apoiada por fontes oficiais de atletismo?
3. Como explicar aplicação de força e passada sem recomendar “alcançar” o solo?
4. Que orientação respiratória é defensável para um principiante?
5. Como integrar a desaceleração na execução e não apenas como nota final?
6. Que riscos, erros, sinais de interrupção e condições ambientais devem ser visíveis?
7. Que nível de supervisão é coerente com risco alto e primeira exposição técnica?

## Fontes consultadas

### Fontes existentes

1. **B1-S01 — World Athletics, _The Sprints_.** Revisão técnica da federação internacional.  
   https://worldathletics.org/download/downloadnsa?filename=f411d6b2-f0be-456f-b969-28abad2159ce.pdf&urlslug=the-sprints

2. **B1-S12 — Bezodis, Willwacher e Salo, _The Biomechanics of the Track and Field Sprint Start: A Narrative Review_.** Revisão científica.  
   https://pubmed.ncbi.nlm.nih.gov/31209732/

3. **SP-B2-S16 — Haugen et al., _The Training and Development of Elite Sprint Performance_.** Revisão científica e de prática profissional.  
   https://doi.org/10.1186/s40798-019-0221-0

Estas fontes sustentam a família mecânica, a separação entre saída e corrida cíclica e o enquadramento das fases de aceleração e velocidade. Não foram usadas para importar doses.

### Pesquisa adicional independente

4. **EX19-S01 — Athletics Ireland, _AAi Coach Sprints Manual_.** Manual oficial de treinador de federação nacional.  
   https://www.athleticsireland.ie/wp-content/uploads/2024/10/AAI-Coach_Sprints_Manual.pdf

   Contributo: inclinação e elevação gradual na aceleração; postura alta na velocidade máxima; coordenação de braços; contacto do pé debaixo das ancas em exercícios técnicos; exemplos de erros. O manual contém exemplos de treino com distância, esforço e recuperação, que foram excluídos.

5. **EX19-S02 — National Strength and Conditioning Association, _Acceleration and Deceleration Mechanics_ e _Effective Deceleration Technique for Court and Field Sports_.** Orientação profissional.  
   https://www.nsca.com/education/articles/kinetic-select/acceleration-and-deceleration-mechanics/  
   https://www.nsca.com/education/articles/kinetic-select/effective-deceleration-technique-for-court-and-field-sports/

   Contributo: inclinação global sem flexão isolada da cintura; coordenação de tornozelo, joelho e anca; ação dos braços; absorção de força por flexão coordenada durante a travagem. A aplicação foi limitada à desaceleração linear, sem importar instruções de mudança de direção.

6. **EX19-S03 — Weyand et al. (2000), _Faster top running speeds are achieved with greater ground forces not more rapid leg movements_.** Estudo biomecânico primário. DOI: 10.1152/jappl.2000.89.5.1991.  
   https://doi.org/10.1152/jappl.2000.89.5.1991

   Contributo: em adultos com capacidades de sprint diferentes, velocidades máximas superiores associaram-se a maiores forças médias de apoio ao solo, e não a tempos de balanço mais curtos. Sustenta uma explicação centrada em aplicar força ao solo e não em “mexer as pernas o mais depressa possível”.

7. **EX19-S04 — Morin, Edouard e Samozino (2011), _Technical Ability of Force Application as a Determinant Factor of Sprint Performance_.** Estudo biomecânico primário. DOI: 10.1249/MSS.0b013e318216ea37.  
   https://pubmed.ncbi.nlm.nih.gov/21364480/

   Contributo: a orientação da força total durante a aceleração associou-se ao desempenho no sprint de campo, enquanto a quantidade total de força, isoladamente, não mostrou a mesma relação. Sustenta a formulação “empurra o solo para trás e para baixo”, sem transformar o cue numa promessa.

8. **EX19-S05 — Schache et al. (2012), _Mechanics of the human hamstring muscles during sprinting_.** Estudo biomecânico primário. DOI: 10.1249/MSS.0b013e318236a3d2.  
   https://pubmed.ncbi.nlm.nih.gov/21912301/

   Contributo: cinemática e forças de reação do solo de sete participantes, combinadas com modelação musculoesquelética, mostraram picos de força e deformação dos isquiotibiais no balanço terminal. Sustenta “carga rápida dos tecidos” como fator de risco, sem permitir prever lesão individual.

9. **EX19-S06 — Dorn, Schache e Pandy (2012), _Muscular strategy shift in human running: dependence of running speed on hip and ankle muscle performance_.** Estudo biomecânico primário. DOI: 10.1242/jeb.064527.  
   https://doi.org/10.1242/jeb.064527

   Contributo: dados experimentais e modelação em nove corredores experientes mostram papéis coordenados dos flexores plantares, músculos da anca e isquiotibiais ao longo do apoio e balanço. O protocolo separou também uma zona para desaceleração segura, reforçando a necessidade de planear a travagem. A dimensão usada no laboratório não foi convertida numa regra pública.

10. **McDermott et al. (2003), _Running training and adaptive strategies of locomotor-respiratory coordination_.** Estudo primário sobre coordenação locomotora-respiratória.  
    https://pubmed.ncbi.nlm.nih.gov/12712351/

    Contributo: a coordenação entre respiração e passada é adaptativa e variável. Não fornece uma cadência respiratória universal para a primeira exposição ao sprint.

## Síntese por domínio

| Domínio | Conclusão documental | Base principal |
|---|---|---|
| Execução | Partida em pé estável; inclinação global; elevação gradual; apoios alternados; saída por desaceleração | World Athletics; Athletics Ireland; NSCA |
| Mecânica | Aceleração depende da orientação útil da força; sprint rápido exige forças elevadas e coordenação entre apoio e balanço | Morin et al.; Weyand et al.; Dorn et al. |
| Respiração | Orientação conservadora: natural e contínua, sem retenção voluntária nem contagem imposta | McDermott et al.; limite de evidência |
| Segurança | Risco alto mantido por impacto, contactos repetidos, força e carga tecidular rápida | Schache et al.; registo canónico |
| Travagem | Deve ser planeada, linear e progressiva; flexão coordenada ajuda a absorver força | NSCA; Dorn et al. |
| Erros | Espaço insuficiente, flexão pela cintura, passada artificialmente longa, braços cruzados, elevação abrupta e paragem brusca | Athletics Ireland; NSCA; inferência biomecânica prudente |
| Supervisão | Primeira exposição não autónoma; profissional verifica prontidão, técnica, corredor e travagem | risco alto, exigência técnica e limite de transferência da evidência |

## Decisões editoriais

### 1. Primeira exposição

A clareza textual não foi tratada como autorização. O conteúdo afirma de forma repetida que a primeira exposição exige supervisão presencial por treinador de atletismo ou profissional qualificado. Esta decisão decorre do risco alto, da exigência de aprendizagem e da possibilidade de perda de controlo à velocidade.

### 2. Partida

Foi usada uma partida em pé com base assimétrica, coerente com a identidade canónica e com ausência de equipamento obrigatório. Saída de blocos, saída a três apoios e saída ajoelhada foram excluídas por serem formas delimitadas ou progressões técnicas que não pertencem a esta explicação.

### 3. Apoio do pé

O texto não impõe um contacto exclusivamente no antepé. A investigação e a prática de treino não justificam transformar uma forma única de contacto numa regra universal para todos os principiantes. O cue público privilegia o apoio organizado perto do corpo e evita alcançar deliberadamente o solo.

### 4. Respiração

Não foi imposta uma relação fixa entre passos e ciclos respiratórios. A instrução é respirar naturalmente e de forma contínua, sem retenção voluntária. Isto segue a regra contratual de não inventar contagens e reconhece variabilidade locomotora-respiratória.

### 5. Travagem

A desaceleração foi integrada como fase do exercício. O conteúdo exige um corredor seguido por zona livre e orienta uma redução progressiva, em linha reta, com passos controlados e flexão coordenada dos membros inferiores. Não foi fixada qualquer dimensão, porque a distância necessária varia com a pessoa, a velocidade, a superfície e o contexto.

### 6. Erros e correções

Cada erro inclui comportamento observável e correção simples. As correções não atribuem dose, não prometem resultado e não substituem observação profissional.

## Verificação dos campos de risco alto

- **`prerequisite_skill_pt_pt`:** preenchido com compreensão de interrupção, competência básica de corrida e travagem observável.
- **`supervision_recommendation_pt_pt`:** preenchido; primeira exposição presencial obrigatória.
- **`safe_space_requirement_pt_pt`:** preenchido; corredor linear e zona de travagem validados no local.
- **`landing_or_braking_control_pt_pt`:** preenchido com critérios observáveis de apoio e travagem.
- **`failure_exit_strategy_pt_pt`:** preenchido sem recomendar paragem brusca ou mudança repentina de direção.

## Preservação canónica

- Identidade, nome, entidade, família e capacidade principal preservados.
- `variant_of` e `base_exercise_id` mantidos como `none`.
- Risco operacional alto preservado.
- Sem equipamento obrigatório; apenas marcadores opcionais já permitidos.
- Superfície firme, regular e antiderrapante preservada.
- Corredor linear, zona de travagem e exclusão de tráfego/atravessamentos preservados.
- Relações aprovadas não foram expandidas, reduzidas ou reinterpretadas.
- Não foi aprovada multimédia.

## Limitações

- A evidência direta sobre primeira exposição de principiantes absolutos é escassa.
- Vários estudos biomecânicos têm amostras pequenas e participantes adultos, fisicamente ativos ou experientes.
- A modelação musculoesquelética informa mecanismos, mas não diagnostica risco individual.
- Recursos oficiais e profissionais de treino incluem por vezes metas de desempenho e doses; esses elementos não foram transferidos.
- Não existe uma regra universal, sustentada pelas fontes consultadas, para cadência respiratória ou dimensão da zona de travagem.
- O conteúdo não avalia prontidão individual e não substitui supervisão, avaliação clínica quando necessária ou decisão profissional no local.
- Não foram definidas séries, repetições, distância, duração, velocidade, intensidade, ritmo, frequência, recuperação ou progressão.

## Controlo final

- Português europeu: sim
- Unicode NFC: a validar tecnicamente
- Mínimo de passos de execução: 8
- Mínimo de cues: 6
- Mínimo de erros estruturados: 6
- Perguntas de compreensão: 12
- Cinco campos adicionais de risco alto: completos
- Diagnóstico, tratamento ou promessa: ausentes
- Dose fixa: ausente
- Código ou publicação: ausentes
- Alteração de identidade, risco, equipamento, superfície ou relações: não

**Implementação realizada: não**
