# TRANS-04 — Auditoria transversal de segurança

## Resultado

**Estado global: `failed` / revisão de segurança obrigatória.**

Foram encontrados **8 findings**, dos quais **2 blockers**. Os blockers estão em `stationary_arm_crank_ergometry` e `seated_supported_thoracic_extension`: ambos permitem a um principiante montar uma configuração cujo requisito crítico de estabilidade ou localização não é operacionalmente verificável.

Não foram encontradas instruções para retenção respiratória, hiperventilação deliberada, manobra de Valsalva, continuação através de dor aguda, utilização de equipamento manifestamente danificado, corrida/salto sem zona de saída, tiro com arco sem alvo/barreira/supervisão, boxe sem parceiro/proteção/supervisão, nem omissão integral de parceiro ou alvo nas modalidades que deles dependem.

## Âmbito e método

Foram revistos:

- os **49 exercícios**, em **98 artefactos públicos**: 49 JSON e 49 Markdown `*_beginner_content_v0.1`;
- as **7 auditorias de capacidade** `AUD-A` a `AUD-G`;
- apenas os campos e secções relevantes para instruções perigosas, redução de risco, sinais de paragem, supervisão, parceiro/spotter/alvo, equipamento, superfície, espaço, estratégia de saída e respiração.

Não foram lidos outros relatórios transversais. Cada conclusão abaixo foi confirmada diretamente no JSON e no Markdown aplicáveis; as auditorias de capacidade serviram como evidência secundária, não como substituto da revisão transversal.

Escala:

- **alta**: pode expor diretamente o principiante a queda, impacto, projétil, equipamento móvel ou resposta inadequada a um sinal de alarme;
- **média**: lacuna operacional que aumenta o risco, mas está parcialmente mitigada noutras secções;
- **baixa**: imprecisão com impacto de segurança limitado;
- **blocker: sim**: o conteúdo não deve manter o estado público atual antes da correção.

## Findings

### TRANS-04-001 — Configuração em cadeira de rodas sem critério operacional de estabilização

- **Severidade:** alta
- **Blocker:** sim
- **Exercício:** `stationary_arm_crank_ergometry`
- **Campo:** `before_you_start_pt_pt`, `execution_steps_pt_pt`, `starting_position_pt_pt`, `equipment_safety_pt_pt`; secções Markdown correspondentes
- **Evidência:** o conteúdo autoriza execução “sentado numa cadeira de rodas devidamente estabilizada quando o aparelho o permite” e depois pede apenas confirmação de que a cadeira está “estável”. Não indica travões de estacionamento aplicados e testados, ausência de deslocamento/rotação sob carga, compatibilidade geométrica com o ergómetro, controlo dos apoios dos pés, nem uma saída segura específica. `equipment_safety_pt_pt` cobre os bloqueios do ergómetro, mas não os da cadeira. A auditoria `AUD-A` confirma a mesma lacuna.
- **Risco:** a cadeira pode deslocar-se ou rodar quando a pessoa aplica força nas manivelas, aproximando o corpo das partes móveis ou causando perda de apoio durante a entrada, execução ou saída.
- **Revisão exigida:** remover a opção específica de cadeira de rodas até existir especificação autorizada, ou acrescentar uma verificação inequívoca e dependente do modelo/profissional: travões de estacionamento aplicados e testados, cadeira imóvel sob carga leve em todas as direções relevantes, apoios e roupa fora das partes móveis, alcance compatível sem deslocar o tronco e estratégia de saída confirmada. A primeira configuração nesta modalidade deve ser supervisionada.

### TRANS-04-002 — Fulcro torácico não é localizável com segurança e a respiração acrescenta sincronização sem suporte

- **Severidade:** alta
- **Blocker:** sim
- **Exercício:** `seated_supported_thoracic_extension`
- **Campo:** `equipment_setup_pt_pt`, `starting_position_pt_pt`, `starting_position_checklist_pt_pt`, `breathing_guidance_pt_pt`, `principal_cues_pt_pt`; secções Markdown correspondentes
- **Evidência:** o principiante recebe apenas a zona ampla “região média ou superior das costas, abaixo do pescoço e acima da região lombar” para colocar o fulcro, apesar de o próprio conteúdo advertir contra extensão cervical/lombar e deslocação do rolo. Não existe um critério observável que permita confirmar a região correta antes de carregar o tronco. O conteúdo também torna necessário “um encosto capaz de manter o fulcro no lugar”, requisito não reconciliado no inventário referido por `AUD-C`. Por fim, depois de declarar que não existe fase respiratória obrigatória sustentada, sugere expirar na inclinação e inspirar no regresso; o relatório de capacidade confirma que essa sincronização não tem suporte específico declarado.
- **Risco:** colocação demasiado alta ou baixa pode concentrar pressão e transferir o arco para pescoço/lombar; um encosto incompatível pode deixar o rolo escapar; a sugestão respiratória contraditória pode levar a pessoa a privilegiar a fase respiratória sobre conforto e controlo.
- **Revisão exigida:** não autorizar execução autónoma enquanto a pessoa não conseguir identificar a zona e testar o conjunto através de uma referência leiga, observável e validada. Reconciliar formalmente cadeira/encosto/fulcro, exigir demonstração ou supervisão na primeira montagem e retirar a sincronização respiratória, mantendo apenas respiração natural, contínua e sem retenção.

### TRANS-04-003 — Sinais de paragem incompletos em tarefas de risco alto

- **Severidade:** alta
- **Blocker:** não
- **Exercícios:** `linear_sprint`, `two_point_sprint_start`, `standing_broad_jump`
- **Campo:** `unexpected_or_warning_sensations_pt_pt`, `stop_or_reduce_signs_pt_pt`, `safety_note_pt_pt`; secções Markdown correspondentes
- **Evidência:**
  - `linear_sprint` lista como avisos tontura, visão alterada, falta de ar desproporcionada, sensação de desmaio, tropeção repetida, instabilidade e incapacidade de manter a trajetória; o campo de paragem fica reduzido a dor, mal-estar, perda de coordenação e incapacidade de travar/receber o apoio.
  - `two_point_sprint_start` inclui falta de ar invulgar e perda de orientação nos avisos, mas não os repete nos sinais de paragem.
  - `standing_broad_jump` inclui falta de ar invulgar e cedência/bloqueio/perda súbita de controlo de um membro nos avisos, mas não os torna sinais explícitos de paragem.
- **Risco:** os resumos de segurança e eventuais consumidores do campo estruturado podem não mandar interromper perante sinais já reconhecidos como anormais noutra secção, precisamente em tarefas com velocidade, fase aérea ou impacto.
- **Revisão exigida:** fazer `stop_or_reduce_signs_pt_pt` cobrir integralmente os avisos materiais e indicar uma ação segura: não iniciar se o sinal existir antes da partida; em movimento, deixar de acelerar ou preparar a receção, usar a zona livre, parar progressivamente e não reiniciar sem revisão adequada.

### TRANS-04-004 — Sinais de paragem perdem sintomas ou perda de controlo em tarefas com bola

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** `football_directional_first_touch`, `volleyball_forearm_pass_to_target`, `standing_medicine_ball_chest_pass`
- **Campo:** `unexpected_or_warning_sensations_pt_pt`, `stop_or_reduce_signs_pt_pt`, `safety_note_pt_pt`
- **Evidência:**
  - `football_directional_first_touch` reconhece tonturas, alteração súbita da visão e mal-estar, mas esses sinais desaparecem da lista de paragem.
  - `volleyball_forearm_pass_to_target` reconhece perda de equilíbrio com risco de queda/colisão, mas a lista de paragem fala apenas de contacto na face, dor, entrada de pessoa e risco de colisão/zona.
  - `standing_medicine_ball_chest_pass` reconhece falta de ar invulgar e perda súbita de força, mas a lista de paragem não os nomeia.
- **Risco:** a alimentação ou trajetória da bola pode continuar quando a pessoa já não vê, equilibra, respira ou segura o implemento com controlo.
- **Revisão exigida:** sincronizar avisos e sinais de paragem; ordenar ao parceiro que cesse imediatamente a alimentação, garantir que ninguém persegue a bola e só permitir recolha depois de a trajetória e a pessoa estarem estabilizadas.

### TRANS-04-005 — Primeira exposição de dois sprints de risco alto fica entre “recomendada” e necessária

- **Severidade:** alta
- **Blocker:** não
- **Exercícios:** `two_point_sprint_start`, `sled_resisted_sprint`
- **Campo:** `before_you_start_pt_pt`, `supervision_guidance_pt_pt`, `supervision_recommendation_pt_pt`, `safety_note_pt_pt`
- **Evidência:** `two_point_sprint_start` classifica supervisão como recomendada/prioritária, embora a nota de segurança mande usá-la nas primeiras exposições. `sled_resisted_sprint` manda garantir supervisão na primeira exposição em `before_you_start_pt_pt`, mas os campos próprios e a nota resumem-na como “recomendada”. Em ambos, um consumidor que apresente apenas o campo de supervisão pode reduzir uma condição de início a conselho. Isto contrasta com `linear_sprint`, `sprint_to_controlled_stop`, `plyometric_push_up` e `standing_broad_jump`, que dizem inequivocamente que a primeira exposição não é autónoma.
- **Risco:** partida, primeiros apoios, travagem e, no trenó, ajuste/ligação podem ser tentados sem observação competente apesar do risco alto declarado.
- **Revisão exigida:** declarar de modo idêntico em todos os campos e no Markdown que a primeira exposição exige supervisão presencial qualificada. No trenó, o supervisor deve conhecer o sistema de ligação, validar fechos/linha de tração e controlar a pista e a desaceleração do corpo e do trenó.

### TRANS-04-006 — Montagem na bicicleta vertical é demasiado genérica para um principiante

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `upright_stationary_cycling`
- **Campo:** `execution_steps_pt_pt`, `starting_position_pt_pt`, `ending_the_exercise_pt_pt`
- **Evidência:** a entrada resume-se a “Monta com cuidado, senta-te ao centro do selim e fixa cada pé”, sem dizer que a bicicleta e os pedais devem estar imóveis, qual apoio fixo pode ser usado, nem a sequência entre apoio, transferência, assento e colocação dos pés. A desmontagem é mais específica e já exige paragem completa e pontos fixos de apoio. `AUD-A` confirma esta assimetria.
- **Risco:** queda durante a transferência, pé preso ou contacto com pedal/manivela ainda móvel.
- **Revisão exigida:** acrescentar uma sequência dependente do modelo: máquina e pedais totalmente parados, apoio apenas num ponto fixo indicado pelo fabricante, transferência controlada para o selim, estabilização da bacia e só depois colocação/fixação dos pés. Não inventar um lado universal de montagem.

### TRANS-04-007 — “Zona estável do pé” não permite posicionar a correia de modo reprodutível

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `supine_hamstring_strap_stretch`
- **Campo:** `equipment_setup_pt_pt`, `starting_position_checklist_pt_pt`, `formal_variant_explanation.additional_setup_pt_pt`, `equipment_safety_pt_pt`
- **Evidência:** JSON e Markdown repetem que a correia/toalha deve passar por uma “zona estável do pé”, sem dar um marcador visual verificável. As salvaguardas “não sobre os dedos”, sem pressão dolorosa e teste com tração mínima reduzem o risco, mas não resolvem onde apoiar o material. `AUD-D` confirma que não foi encontrada uma posição universal.
- **Risco:** deslizamento súbito da correia, pressão localizada, perda de controlo da perna ou libertação brusca das mãos.
- **Revisão exigida:** obter validação técnica para uma descrição observável e não universal; até lá, exigir demonstração/revisão na primeira utilização. Manter o teste com tensão mínima e explicitar que qualquer deslizamento obriga a aliviar primeiro a tração e baixar a perna antes de reposicionar.

### TRANS-04-008 — Orientação das manoplas é ambígua no JSON

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `boxing_jab_cross_to_focus_mitts`
- **Campo:** `equipment_setup_pt_pt[2]`
- **Evidência:** o JSON diz que o parceiro apresenta as manoplas “com as palmas das manoplas viradas para ele”; “ele” pode referir-se ao parceiro ou ao praticante. O Markdown resolve corretamente a frase com “viradas para o praticante”. `AUD-F` confirma a divergência.
- **Risco:** orientação errada do alvo pode aumentar resvalamento, desvio do impacto e flexão inadequada do punho, apesar das restantes proteções.
- **Revisão exigida:** substituir no JSON por “palmas das manoplas viradas para o praticante” e manter a exigência de parceiro competente e supervisor de boxe, sem alterar distância ou altura-alvo.

## Estados afetados

Todos os 49 JSON declaram `content_status == beginner_content_approved_with_limits`. TRANS-04 recomenda:

| Estado TRANS-04 | Exercícios |
|---|---|
| `failed` / bloqueado | `stationary_arm_crank_ergometry`, `seated_supported_thoracic_extension` |
| `passed_with_revisions` | `boxing_jab_cross_to_focus_mitts`, `football_directional_first_touch`, `linear_sprint`, `sled_resisted_sprint`, `standing_broad_jump`, `standing_medicine_ball_chest_pass`, `supine_hamstring_strap_stretch`, `two_point_sprint_start`, `upright_stationary_cycling`, `volleyball_forearm_pass_to_target` |
| `passed` nesta dimensão | os restantes 37 exercícios |

Distribuição dos 12 exercícios afetados pelo risco operacional declarado:

- risco alto: 4 — `linear_sprint`, `sled_resisted_sprint`, `standing_broad_jump`, `two_point_sprint_start`;
- risco moderado: 3 — `boxing_jab_cross_to_focus_mitts`, `seated_supported_thoracic_extension`, `standing_medicine_ball_chest_pass`;
- risco baixo: 5 — `football_directional_first_touch`, `stationary_arm_crank_ergometry`, `supine_hamstring_strap_stretch`, `upright_stationary_cycling`, `volleyball_forearm_pass_to_target`.

## Padrões transversais

### Conformes

- Os 49 exercícios têm preparação, sinais de aviso, finalização e alguma forma de interrupção; não existe ausência total de estratégia de saída.
- Superfície, iluminação, obstáculos e circulação são geralmente tratados de forma específica à tarefa.
- Corrida, sprint, salto e trenó incluem zonas de travagem/receção e proíbem paragens ou mudanças de direção bruscas.
- Tiro com arco preserva campo especializado, alvo, barreira de retenção, proteções, comandos e supervisão obrigatória.
- Boxe preserva luvas, ligaduras, duas manoplas, parceiro competente, proibição de sparring e supervisão obrigatória.
- Voleibol e futebol preservam parceiro e alvo; basquetebol preserva cesto/alvo; bola medicinal define parceiro, alvo ou zona isolada como destinos alternativos.
- A orientação respiratória é globalmente conservadora: fluxo natural/contínuo, sem retenções ou contagens impostas; os quatro exercícios respiratórios incluem prevenção de respiração excessiva e regresso ao padrão espontâneo.
- O uso de spotter manual não é indevidamente imposto em saltos ou movimentos balísticos onde agarrar a pessoa em voo poderia criar outro perigo.

### A corrigir

- O campo estruturado de paragem é por vezes uma versão reduzida dos avisos já reconhecidos no mesmo exercício.
- “Supervisão recomendada” é usada em dois exercícios de risco alto mesmo quando outra secção torna a primeira exposição dependente de supervisão.
- Configurações dependentes de equipamento/modelo são seguras quando remetem para o manual apenas depois de darem critérios observáveis; falham quando usam apenas “estável”, “com cuidado” ou “zona estável”.
- Uma instrução respiratória específica não deve ser acrescentada depois de o próprio conteúdo declarar falta de suporte para essa sincronização.
- Paridade JSON/Markdown é relevante para segurança: uma correção presente apenas no Markdown não protege consumidores do JSON.

## Contagens

| Métrica | Resultado |
|---|---:|
| Exercícios auditados | 49 |
| JSON auditados | 49 |
| Markdown auditados | 49 |
| Auditorias de capacidade revistas | 7 |
| Findings | 8 |
| Severidade alta | 4 |
| Severidade média | 4 |
| Severidade baixa | 0 |
| Blockers | 2 |
| Exercícios distintos afetados | 12 |
| `failed` / bloqueados | 2 |
| `passed_with_revisions` | 10 |
| `passed` nesta dimensão | 37 |
| Exercícios com retenção respiratória imposta | 0 |
| Exercícios com hiperventilação deliberada | 0 |
| Omissões integrais de parceiro/alvo obrigatório | 0 |

## Independência e zero implementação

TRANS-04 não foi autor de qualquer conteúdo. A revisão foi independente e limitada aos 49 pares JSON/Markdown e às sete auditorias de capacidade indicadas no âmbito. Não foram consultados outros relatórios transversais.

**Implementação realizada: zero.** Nenhum JSON, Markdown de exercício, relatório de investigação, registo canónico, relação, regra, código, configuração, equipamento, multimédia ou estado de produto foi alterado. O único artefacto criado por TRANS-04 foi este relatório.
