# Relatório de investigação — `bilateral_pogo_jump`

## Âmbito

Investigação documental destinada a sustentar conteúdo de execução para principiantes sobre **Saltos reativos curtos bipodais**, sem alterar a identidade canónica, o risco operacional, o equipamento, a superfície ou a relação aprovada.

Foram procuradas respostas para:

- natureza reativa e execução mecânica;

- respiração;

- impacto, contactos e aterragem final;

- erros observáveis e critérios de interrupção;

- necessidade de supervisão e limites da primeira exposição.

Ficaram fora do âmbito dose, programação, progressão individual, promessa de resultado, diagnóstico, tratamento, autorização clínica, código e publicação.

## Registo canónico preservado

| Campo | Valor preservado |
|---|---|
| `exercise_id` | `bilateral_pogo_jump` |
| Nome | Saltos reativos curtos bipodais |
| Tipo | `canonical_exercise` |
| Família | `reactive_jump` |
| Capacidade principal | `speed_power` |
| Risco operacional | `high` |
| Equipamento obrigatório | nenhum |
| Supervisão | recomendada |
| Superfície | firme, regular e antiderrapante |
| Relação aprovada | `main_training → speed_power → elastic_reactive_action → increase_reactive_strength` |

Não foram criadas variantes nem novas relações.

## Método de pesquisa

Foram priorizados:

1. federação desportiva oficial;
2. associação profissional de força e condicionamento;
3. literatura científica por pares;
4. estudos biomecânicos primários diretamente relacionados com saltos bipodais ou saltos de tornozelo;
5. orientação oficial e estudo primário para a cautela respiratória.

A síntese separa evidência direta do exercício ou mecanismo, orientação ao nível da família pliométrica e inferência editorial conservadora. Nenhuma fonte foi tratada como autorização automática para execução.

## Fontes consultadas

### 1. World Athletics — fonte técnica oficial

**Referência:** Dick F, Alford J, Ballesteros J, Gambetta V, Lopez V. *NSA Round Table No. 5 — Plyometrics*. 1989.  
**Ligação:** [World Athletics](https://worldathletics.org/download/downloadnsa?filename=2d59925f-f1bf-49d8-adc0-e305fd16f9bc.pdf&urlslug=nsa-round-table-no-5-plyometrics)  
**Código existente:** `B1-S05`

**Contributo:** reconhece os saltos bipodais como família pliométrica e contém cautela explícita sobre a utilização em praticantes inexperientes. Apoia a distinção entre exercício reativo e salto isolado e reforça a necessidade de ensino antes de autonomia.

**Limite:** mesa-redonda histórica e profissional, não ensaio controlado nem norma específica para principiantes absolutos.

### 2. Davies, Riemann e Manske — revisão clínica por pares

**Referência:** Davies GJ, Riemann BL, Manske R. *Current Concepts of Plyometric Exercise*. International Journal of Sports Physical Therapy. 2015.  
**Ligação:** [PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC4637913/)  
**Código existente:** `B1-S15`

**Contributo:** descreve o ciclo alongamento–encurtamento, a fase excêntrica, a transição ou “tempo para ressalto” e a fase concêntrica. A transição rápida sustenta a instrução de ligar receção e nova propulsão. O artigo também suporta pré-requisitos, progressão técnica e interrupção quando a fadiga altera a qualidade.

**Limite:** comentário clínico e revisão ao nível da família; não valida uma execução única do pogo bipodal nem uma dose.

### 3. National Strength and Conditioning Association — orientação profissional

**Referência:** National Strength and Conditioning Association. *Basics of Strength and Conditioning Manual*.  
**Ligação:** [NSCA](https://www.nsca.com/contentassets/48a12160221541acbdc048498d77192d/basics_of_strength_and_conditioning_manual.pdf)  
**Código de trabalho:** `EX17-R01`

**Contributo:** salienta a importância da técnica de aterragem independentemente do nível, do alinhamento frontal e da participação coordenada de tornozelo, joelho e anca na absorção. Descreve ainda que uma tarefa nova requer atenção e aprendizagem progressiva antes de maior complexidade.

**Limite:** as instruções abrangem saltos em geral. Aterragem final e contacto reativo não são equivalentes: a primeira procura estabilizar; o segundo liga-se rapidamente à propulsão. Por isso, o conteúdo não transpôs a recomendação de uma aterragem profunda para todos os contactos.

### 4. Kuitunen, Ogiso e Komi — estudo biomecânico primário

**Referência:** Kuitunen S, Ogiso K, Komi PV. *Leg and Joint Stiffness in Human Hopping*. Scandinavian Journal of Medicine & Science in Sports. 2011. DOI: `10.1111/j.1600-0838.2010.01202.x`.  
**Ligação:** [PubMed](https://pubmed.ncbi.nlm.nih.gov/22126723/)  
**Código de trabalho:** `EX17-R02`

**Desenho relevante:** adultos jovens executaram saltos bipodais; foram recolhidas forças de reação do solo, cinemática e eletromiografia.

**Contributo:** em contactos curtos, o controlo da rigidez da perna mostrou sensibilidade à rigidez do tornozelo, enquanto o joelho contribuiu para regular a altura. Isto apoia a identidade “predominantemente pelo tornozelo”, sem excluir a participação do joelho.

**Limite:** amostra pequena e masculina. O estudo descreve mecanismo, não uma instrução universal para principiantes.

### 5. Donoghue, Shimojo e Takagi — estudo biomecânico primário

**Referência:** Donoghue OA, Shimojo H, Takagi H. *Impact Forces of Plyometric Exercises Performed on Land and in Water*. Sports Health. 2011. DOI: `10.1177/1941738111403872`.  
**Ligação:** [PubMed](https://pubmed.ncbi.nlm.nih.gov/23016022/)  
**Código de trabalho:** `EX17-R03`

**Desenho relevante:** estudo cruzado com medição por plataforma de força de vários saltos pliométricos, incluindo saltos de tornozelo.

**Contributo:** confirma que saltos de tornozelo em terra envolvem carga de impacto material. Sustenta a classificação de risco elevado, a verificação da superfície, a necessidade de saída controlada e a proibição editorial de apresentar “pequeno” como sinónimo de “baixo impacto”.

**Limite:** participantes treinados, masculinos, e objetivo centrado na comparação entre terra e água. Não autoriza mudar o exercício para meio aquático; o registo canónico estabelece `aquatic: false` e superfície firme.

### 6. American College of Sports Medicine — orientação respiratória oficial

**Referência:** Zaleski A. *Exercise for the Prevention and Treatment of Hypertension — Implications and Application*. ACSM. 2019.  
**Ligação:** [ACSM](https://acsm.org/exercise-for-the-prevention-and-treatment-of-hypertension/)  
**Código de trabalho:** `EX17-R04`

**Contributo:** a ACSM assinala que prender a respiração durante esforço pode provocar respostas pressóricas muito elevadas, tonturas ou desmaio em contexto de treino resistido. Sustenta uma orientação conservadora de respiração contínua e sem apneia deliberada.

**Limite:** não é orientação específica para saltos reativos. Não há base para impor inspiração ou expiração em determinada fase de cada contacto.

### 7. Linsenbardt, Thomas e Madsen — estudo respiratório primário

**Referência:** Linsenbardt ST, Thomas TK, Madsen RW. *Effect of Breathing Techniques on Blood Pressure Response to Resistance Exercise*. British Journal of Sports Medicine. 1992.  
**Ligação:** [PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC1478931/)  
**Código de trabalho:** `EX17-R05`

**Contributo:** encontrou respostas de pressão arterial mais elevadas com manobra de Valsalva do que com outras estratégias respiratórias durante os exercícios estudados. Apoia evitar retenção deliberada da respiração.

**Limite:** exercícios resistidos, não saltos. A transferência é apenas para cautela geral, não para sincronização respiratória específica.

## Síntese por tema

### Execução reativa

A fonte de Davies et al. e o estudo de Kuitunen et al. convergem na natureza do movimento:

- uma fase de receção ou alongamento antecede a propulsão;

- a transição curta é central à reatividade;

- o tornozelo tem papel dominante nos contactos curtos;

- o joelho continua envolvido e não deve ser bloqueado;

- altura e contacto não podem ser tratados como objetivos independentes da técnica.

**Decisão editorial:** usar “pequena preparação elástica”, “trajetória curta e vertical”, “contacto curto, mas controlado” e “joelhos desbloqueados”. Evitou-se “pernas rígidas”, porque pode ser interpretado como bloqueio articular.

### Respiração

Não foi encontrada evidência que justifique uma fase respiratória obrigatória por salto. A evidência profissional e experimental consultada sustenta apenas a cautela contra apneia deliberada.

**Decisão editorial:** “respiração natural, contínua e ritmada, sem retenção”. Não são usadas contagens, pausas ou manobras respiratórias.

### Contactos e aterragem

Os estudos biomecânicos mostram que um contacto curto pode envolver forças relevantes. A orientação da NSCA apoia alinhamento e absorção coordenada. Porém, a aterragem final e o contacto intermédio têm funções diferentes:

| Momento | Função | Critério |
|---|---|---|
| Contacto intermédio | receber e inverter rapidamente | simultâneo, alinhado, curto e previsível |
| Último contacto | travar e estabilizar | maior absorção confortável e equilíbrio bipodal |

**Decisão editorial:** separar explicitamente “contacto e inversão” de “saída”. O utilizador não é instruído a aprofundar todos os contactos nem a terminar com pernas bloqueadas.

### Erros observáveis

Os erros selecionados derivam da mecânica canónica e dos critérios de aterragem:

- altura excessiva;

- pausa ou afundamento no contacto;

- colapso descontrolado dos calcanhares;

- joelhos para dentro;

- deslocamento fora da vertical;

- chegada assimétrica;

- continuação depois da degradação técnica.

Cada erro tem um sinal visível e uma correção conservadora. Quando a correção não pode ocorrer no próprio contacto sem aumentar o risco, a instrução é terminar.

### Supervisão

Há convergência entre:

- o risco canónico elevado;

- a cautela da World Athletics com inexperiência;

- a necessidade de aprendizagem progressiva descrita pela NSCA;

- os pré-requisitos e critérios de interrupção de Davies et al.

**Decisão editorial:** a primeira exposição não é autónoma. A supervisão deve observar de frente e de lado e manter-se fora da trajetória. Não se recomenda assistência manual dentro da zona de aterragem.

## Campos adicionais de risco elevado

### `prerequisite_skill_pt_pt`

Compreender o comando de paragem e demonstrar apoio bipodal equilibrado, pequena impulsão vertical, receção simultânea, alinhamento e aterragem final estável antes dos contactos reativos sucessivos.

### `supervision_recommendation_pt_pt`

Profissional de exercício ou treinador qualificado na primeira exposição e perante inexperiência, regresso funcional, dificuldade de travagem ou alteração relevante da condição.

### `safe_space_requirement_pt_pt`

Zona pequena mas totalmente desimpedida, firme, plana, regular, seca e antiderrapante, com boa visibilidade e altura livre.

### `landing_or_braking_control_pt_pt`

Contacto intermédio simultâneo, equilibrado e alinhado; último contacto com absorção confortável e estabilização. Assimetria, deriva, ruído crescente ou passos de recuperação indicam falha.

### `failure_exit_strategy_pt_pt`

Deixar de procurar nova propulsão, transformar o contacto seguinte numa aterragem bipodal, fletir as articulações de forma confortável e estabilizar. Não iniciar se esta saída não puder ser prevista e demonstrada.

## Fronteiras de linguagem

O conteúdo evita:

- números fixos de contactos, repetições, séries ou tempo;

- carga, intensidade, ritmo, frequência ou progressão programada;

- promessa de melhoria de desempenho;

- linguagem de prevenção garantida de lesão;

- diagnóstico ou tratamento;

- autorização universal;

- aprovação de multimédia;

- alteração de equipamento, superfície, risco ou relação.

“Interromper” e “pedir revisão” são critérios de segurança documental, não diagnóstico.

## Confiança e limitações

**Confiança global: moderada.**

- **Identidade e mecânica:** alta, pela convergência do registo canónico, revisão da família e estudos biomecânicos.

- **Execução para principiantes:** moderada, porque não foi encontrada uma norma direta para principiantes absolutos.

- **Segurança e supervisão:** moderada, apoiada por fontes profissionais independentes e pela carga medida, mas sem ensaio direto de primeira exposição.

- **Respiração:** moderada para “não prender”; baixa para qualquer sincronização específica, que por isso foi omitida.

Principais limites:

1. os estudos diretos incluem amostras pequenas e treinadas;
2. parte da orientação é da família pliométrica, não deste exercício isolado;
3. a carga individual varia com técnica, pessoa e contexto;
4. a descrição não determina elegibilidade individual;
5. clareza textual não substitui observação técnica no primeiro dia.

## Verificação contratual

| Requisito | Resultado |
|---|---|
| Português europeu, UTF-8 | cumprido |
| Passos de execução | 8 |
| Pistas principais | 7 |
| Erros com reconhecimento e correção | 7 |
| Perguntas de compreensão | 12 |
| Campos adicionais de risco elevado | 5 preenchidos |
| Respiração | natural e contínua, sem retenção |
| Fontes independentes | World Athletics, NSCA, ACSM e literatura científica |
| Literatura primária | Kuitunen et al.; Donoghue et al.; Linsenbardt et al. |
| Dose/prescrição | ausente |
| Promessa/diagnóstico/tratamento | ausentes |
| Prática autónoma no primeiro dia | explicitamente não autorizada |
| Identidade, risco, equipamento, superfície e relação | preservados |
| Código/publicação | não realizados |

**Implementação realizada: não**
