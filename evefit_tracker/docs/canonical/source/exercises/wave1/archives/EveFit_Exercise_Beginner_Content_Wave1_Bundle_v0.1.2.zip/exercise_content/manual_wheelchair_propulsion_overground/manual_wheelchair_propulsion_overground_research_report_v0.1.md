# Relatório de investigação — Propulsão manual de cadeira de rodas no solo

**Agente:** EX-07  
**Exercise ID:** `manual_wheelchair_propulsion_overground`  
**Data de pesquisa:** 2026-07-23  
**Âmbito:** execução, preparação, respiração, segurança, erros e supervisão para principiante absoluto  
Implementação realizada: não

## Resultado

Foi produzido conteúdo documental em português europeu para a identidade canónica existente. A decisão editorial é `beginner_content_approved_with_limits`: a execução básica é defensável, mas o ajuste, o padrão de recuperação, o nível de supervisão e a exposição ambiental dependem da pessoa, da cadeira e do percurso.

Não foram alterados a identidade, o risco, o equipamento obrigatório, as relações aprovadas ou o estado dos média. Não foi incluída dose, prescrição, promessa de resultado, diagnóstico, tratamento, código ou publicação.

## Elementos canónicos preservados

| Campo | Valor preservado |
|---|---|
| `exercise_id` | `manual_wheelchair_propulsion_overground` |
| Nome | Propulsão manual de cadeira de rodas no solo |
| Tipo | `canonical_exercise` |
| Família | `manual_wheelchair_propulsion_family` |
| Exercício-base | `none` |
| Variante de | `none` |
| Capacidade principal | `cardio_conditioning` |
| Equipamento obrigatório | `fitted_manual_wheelchair` |
| Parceiro obrigatório | `false` |
| Spotter obrigatório | `false` |
| Supervisão | `recommended` |
| Risco operacional | `moderate` |
| Relações | três relações aprovadas, preservadas sem adição ou alteração |

## Perguntas de investigação e conclusões

### Como deve ser preparada a cadeira?

A OMS recomenda que a provisão de cadeira inclua avaliação individual, seleção, ajuste, formação e acompanhamento por pessoal formado. Por isso, o conteúdo exige uma cadeira já ajustada e funcional e fecha explicitamente a fronteira: o utilizador não deve alterar eixo, altura ou ângulo do assento, encosto ou apoios com base neste documento.

A verificação prévia limita-se a observar componentes funcionais e a testar os travões de estacionamento com a cadeira parada. Qualquer alcance forçado, instabilidade, desvio, folga ou falha remete para avaliação profissional ou assistência técnica.

### Qual é a técnica básica defensável para avançar?

O Wheelchair Skills Program, o guia clínico do Health Sciences Centre e a guideline do Consortium for Spinal Cord Medicine convergem em:

- observar o percurso com a cabeça levantada;
- iniciar o contacto numa posição confortável ligeiramente atrás do ponto mais alto da roda;
- aplicar força nos dois aros de forma suave e, para seguir em frente, tão simétrica quanto possível;
- evitar acelerações bruscas;
- libertar ou aliviar os aros e recuperar as mãos de forma relaxada;
- manter as mãos disponíveis para direção e travagem.

A guideline clínica recomenda impulsos longos e suaves e uma recuperação natural abaixo do aro. O estudo de Boninger et al. associou o padrão semicircular a menor cadência e maior proporção de tempo na fase de impulso. No entanto, a síntese atual do SCIRE regista variabilidade por pessoa e contexto e não sustenta impor um padrão único. O texto final apresenta a recuperação abaixo do aro como opção frequente em piso plano, condicionada a conforto, controlo e ensino individual.

### Como devem ser tratadas direção, recuo e travagem?

Para seguir em frente, as ações devem ser semelhantes nos dois lados. Para uma curva ampla, pode aumentar-se moderadamente o impulso no lado exterior ou aplicar-se resistência suave no lado interior. Antes de recuar, a pessoa deve observar os dois lados e o espaço atrás e usar movimentos controlados.

A travagem em movimento faz-se através de pressão progressiva nos aros. Os travões da cadeira são tratados como travões de estacionamento: servem para manter a cadeira imóvel depois de parar, não para desacelerar em movimento. Uma paragem brusca pode projetar o corpo para a frente ou precipitar perda de controlo.

### Que orientação respiratória é justificável?

Não foi encontrada uma regra respiratória específica e universal para a propulsão manual básica no solo. Foi adotada a orientação conservadora exigida pelo contrato: respiração natural e contínua, sem contagens e sem retenção. Desconforto no peito, falta de ar atípica, tontura ou confusão são sinais para parar em segurança.

### Que ambiente é apropriado para o conteúdo inicial?

O percurso deve ser acessível, previsível, livre de obstáculos e ter superfície firme, visibilidade suficiente e espaço para virar e parar. Inclinações, desníveis, lancis, pisos soltos ou escorregadios, tráfego e locais onde a cadeira possa fugir excedem o âmbito básico. Esta restrição preserva os modificadores canónicos de risco por superfície, inclinação, tráfego e visibilidade.

### Quando é necessária supervisão?

O registo canónico recomenda supervisão, mas não torna parceiro ou spotter obrigatórios em todas as execuções. A recomendação torna-se especialmente relevante na aprendizagem inicial, com equipamento ou ambiente desconhecido, instabilidade marcada, observação limitada do percurso, dificuldade de travagem ou perda de controlo.

O guia do Health Sciences Centre adverte que competências de cadeira de rodas ensinadas sem formação, ambiente seguro ou apoio clínico podem causar lesão. Para não adicionar equipamento ao registo, o conteúdo não exige cinto de spotter; limita-se a pedir uma pessoa competente próxima o suficiente para intervir e que não agarre inesperadamente a cadeira.

## Fontes existentes auditadas

| Código | Fonte | Resultado da auditoria |
|---|---|---|
| A1-S22 | [SCIRE — Wheelchair Propulsion Training](https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/wheelchair-propulsion-training/) | A página legada não ficou acessível. Foi mantida como fonte contextual existente, mas não usada como suporte exclusivo. |
| A1-S23 | [CSEP — Physical Activity Guidelines for Adults with Spinal Cord Injury](https://csepguidelines.ca/guidelines/physical-activity-guidelines-for-adults-with-spinal-cord-injury/) | Adequada para enquadramento geral de atividade física adaptada; insuficiente para instrução técnica ou elegibilidade individual. |
| A2-S23 | [PubMed PMID 20885199](https://pubmed.ncbi.nlm.nih.gov/20885199/) | O URL corresponde a um estudo sobre ergómetro de braços, e não a técnica de propulsão manual. Não foi usado para sustentar a execução. |

## Fontes adicionais consultadas

### EX07-S01 — OMS, Wheelchair Provision Guidelines

- URL: [https://www.who.int/publications/i/item/9789240074521](https://www.who.int/publications/i/item/9789240074521)
- Tipo: guideline oficial, 2023.
- Contributo: processo individual de avaliação, ajuste, formação e acompanhamento por pessoal formado.
- Aplicação: fronteira de ajuste e necessidade de revisão profissional.
- Limite: guideline de prestação de serviços, não instrução detalhada de propulsão.

### EX07-S02 — OMS, Wheelchair Service Training Package — Basic Level

- URL: [https://www.who.int/publications/i/item/9789241503471](https://www.who.int/publications/i/item/9789241503471)
- Tipo: material oficial de formação, 2012.
- Contributo: verificação, ajuste, treino do utilizador e competências básicas de mobilidade.
- Aplicação: preparação do equipamento e relevância da formação.
- Limite: dirigido a pessoal de serviços de cadeiras de rodas e dependente da avaliação individual.

### EX07-S03 — Consortium for Spinal Cord Medicine/PVA, Preservation of Upper Limb Function

- URL: [https://pva.org/wp-content/uploads/2021/09/cpg_upperlimb.pdf](https://pva.org/wp-content/uploads/2021/09/cpg_upperlimb.pdf)
- Tipo: guideline clínica profissional.
- Contributo: impulsos longos e suaves, redução de contacto brusco, recuperação natural abaixo do aro, postura estável e relevância do ajuste da cadeira.
- Aplicação: passos de impulso e recuperação, erros de força brusca, limite de ajuste.
- Limite: população principal com lesão medular; a recomendação não é autorização universal nem demonstra uma técnica ideal para todas as pessoas.

### EX07-S04 — Wheelchair Skills Program Manual, versão 5.3.1

- URL: [https://wheelchairskillsprogram.ca/wp-content/uploads/WSP-Manual-version-5.3.1-final-.docx](https://wheelchairskillsprogram.ca/wp-content/uploads/WSP-Manual-version-5.3.1-final-.docx)
- Tipo: manual profissional de competências.
- Contributo: avanço, recuperação, observação do percurso, direção, recuo e paragem controlada.
- Aplicação: sequência executável e sinais observáveis para erros.
- Limite: o programa completo pressupõe demonstração, avaliação e adaptação por uma pessoa competente.

### EX07-S05 — Health Sciences Centre, Manual Wheelchair Skills Guide

- URL: [https://hsc.mb.ca/wp-content/uploads/manual-wheelchair-skills-guide.pdf](https://hsc.mb.ca/wp-content/uploads/manual-wheelchair-skills-guide.pdf)
- Tipo: guia clínico profissional, versão online de 2022.
- Contributo: posição das mãos, proteção dos polegares e dedos, impulso simétrico, recuperação, cabeça levantada, curva, recuo, travagem gradual e supervisão.
- Aplicação: passos, cues, erros e medidas de segurança.
- Limite: o próprio guia declara que complementa, mas não substitui, formação e demonstração clínica.

### EX07-S06 — Boninger et al., Propulsion patterns and pushrim biomechanics

- URL: [https://pubmed.ncbi.nlm.nih.gov/11994814/](https://pubmed.ncbi.nlm.nih.gov/11994814/)
- Tipo: estudo biomecânico primário, 2002.
- Contributo: associação entre padrão semicircular, menor cadência e maior proporção da fase de impulso.
- Aplicação: justificação limitada da recuperação abaixo do aro como opção técnica.
- Limite: estudo laboratorial numa população específica; não demonstra superioridade universal nem resultado clínico garantido.

### EX07-S07 — SCIRE, Stroke Pattern in Wheelchair Propulsion

- URL: [https://scireproject.com/evidence/wheeled-mobility-and-seating-equipment/manual-wheelchairs/wheelchair-propulsion/stroke-pattern-in-wheelchair-propulsion/](https://scireproject.com/evidence/wheeled-mobility-and-seating-equipment/manual-wheelchairs/wheelchair-propulsion/stroke-pattern-in-wheelchair-propulsion/)
- Tipo: síntese profissional atual.
- Contributo: variabilidade dos padrões de recuperação; influência da preferência, conforto, tarefa, superfície e ajuste; limites da evidência.
- Aplicação: linguagem não rígida e campo não resolvido para o padrão individual.
- Limite: evidência em grande parte proveniente de estudos pequenos e populações com lesão medular.

## Decisões editoriais defensáveis

| Tema | Decisão |
|---|---|
| Técnica de impulso | Impulso suave, com contacto suficientemente longo e sem aceleração brusca. |
| Recuperação | Relaxada; abaixo do aro como opção, nunca como imposição universal. |
| Punhos e mãos | Evitar posições extremas; polegares para a frente; dedos longe de partes móveis. |
| Direção | Diferença pequena e controlada entre os lados, com olhar no percurso. |
| Recuo | Só após observar o espaço atrás; movimentos controlados. |
| Travagem | Pressão progressiva nos aros; travões de estacionamento apenas com a cadeira imóvel. |
| Respiração | Natural e contínua, sem contagens nem retenção. |
| Ajuste | Cadeira já ajustada; nenhuma instrução de alteração do equipamento. |
| Supervisão | Recomendada e reforçada pelos gatilhos canónicos; sem transformar parceiro ou spotter em requisito universal. |
| Ambiente | Percurso acessível, previsível e com espaço para virar e parar; contextos avançados excluídos. |

## Erros cobertos

O conteúdo documenta, para cada erro, forma de reconhecimento e correção:

1. cadeira mal verificada, mal ajustada ou com falha;
2. travão de estacionamento ainda aplicado;
3. impulsos curtos e bruscos com ombros elevados;
4. arrastar as mãos ou aproximar os dedos de partes móveis;
5. olhar para os aros e reagir tarde ao percurso;
6. travar de repente ou usar o travão de estacionamento em movimento;
7. forçar uma trajetória de recuperação ou postura desconfortável.

## Cobertura do contrato

| Requisito | Cobertura |
|---|---|
| Português europeu e UTF-8 NFC | Verificado |
| JSON válido e chaves na ordem contratada | Verificado |
| Passos de execução | 8 |
| Cues principais | 6 |
| Erros completos | 7, cada um com erro, reconhecimento e correção |
| Perguntas de compreensão | 12 |
| Preparação | Equipamento, ambiente, corpo e posição inicial |
| Respiração | Natural e contínua, sem retenção ou contagem |
| Segurança | Risco, sinais de paragem, equipamento, ambiente e limite de dificuldade |
| Supervisão | Recomendação e gatilhos, sem alterar requisitos canónicos |
| Fontes independentes | OMS, PVA/Consortium, Wheelchair Skills Program, Health Sciences Centre, PubMed e SCIRE |
| Dose e prescrição | Ausentes |
| Alteração de identidade, risco, equipamento ou relações | Ausente |
| Código, publicação ou implementação | Ausentes |

## Limitações e campos não resolvidos

- O conteúdo não avalia função, visão, sensibilidade, estabilidade sentada, adequação da cadeira ou percurso real.
- A técnica para inclinações, superfícies soltas, obstáculos, lancis, degraus, wheelies, quedas e trânsito está fora do âmbito.
- O padrão individual de recuperação requer observação e adaptação profissional.
- O nível individual de supervisão depende da estabilidade, do controlo, da cadeira e do ambiente.
- A orientação respiratória é conservadora porque não foi identificada uma regra específica e universal para esta ação.
- A evidência biomecânica não autoriza promessa de prevenção de lesão, eficiência ou outro resultado individual.

## Conclusão

A cobertura é defensável para um principiante absoluto em percurso acessível e controlável: inclui verificação da cadeira sem a modificar, posição inicial, propulsão para a frente, recuperação, direção, recuo, travagem, respiração, sinais de paragem, erros e supervisão. A documentação fecha explicitamente os contextos avançados e mantém a decisão individual com profissionais competentes quando ajuste, controlo ou risco não são claros.
