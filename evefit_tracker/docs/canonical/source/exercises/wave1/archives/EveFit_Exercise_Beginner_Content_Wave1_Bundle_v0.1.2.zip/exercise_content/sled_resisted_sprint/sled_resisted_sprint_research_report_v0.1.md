# Relatório de investigação — `sled_resisted_sprint`

**Agente:** EX-20  
**Âmbito:** conteúdo documental para principiante  
**Variante formal de:** `linear_sprint`  
**Risco operacional preservado:** alto  
**Implementação realizada: não**

## Decisão de conteúdo

O registo canónico foi preservado sem alterar identidade, risco, equipamento, superfície ou relações. O exercício continua a ser uma variante formal do sprint linear: a ação nuclear de corrida linear permanece, mas a resistência posterior transmitida pelo trenó altera materialmente a relação corpo-carga, a transmissão de força, a montagem e a gestão do fim da corrida.

O conteúdo recebe o estado `beginner_content_approved_with_limits`. A execução é defensável para documentação geral, mas o risco alto, a variabilidade entre trenós e superfícies e a ausência de uma norma única de execução para principiantes justificam limites explícitos e supervisão recomendada.

## Perguntas investigadas

1. Como organizar a partida, a aceleração e os apoios?
2. Como montar e verificar trenó, arnês ou cinto, cinta e conectores?
3. O que muda biomecanicamente com a resistência?
4. O ponto de ligação corporal é relevante?
5. Que orientação respiratória é defensável?
6. Como terminar e travar sem criar um risco adicional?
7. Quais são os erros específicos da variante?
8. Quando é indicada supervisão?
9. Que sinais exigem interrupção?
10. Onde termina a explicação e começa a prescrição?

## Fontes consultadas

### Evidência existente no pacote

| Código | Fonte | Tipo | Utilização |
|---|---|---|---|
| `B1-S13` / `SP-B2-S17` | Aldrich et al., *The Effect of Resisted Sprint Training on Acceleration* — https://pmc.ncbi.nlm.nih.gov/articles/PMC11382779/ | Revisão sistemática e meta-análise | Confirmar a modalidade e separar variáveis de prescrição da identidade |
| `SP-B2-S34` | Alcaraz et al., *Resisted Sled Training for Sprint Performance: A Systematic Review* — https://doi.org/10.1007/s40279-018-0947-8 | Revisão sistemática | Enquadrar trenó, atrito e carga como fatores relevantes, sem extrair dose |

### Literatura primária independente

| Código | Fonte | Tipo | Achado utilizado com prudência |
|---|---|---|---|
| `EX20-S1` | Osterwald, Kelly, Comyns e Ó Catháin (2021), *Resisted Sled Sprint Kinematics: The Acute Effect of Load and Sporting Population* — https://doi.org/10.3390/sports9100137 | Estudo biomecânico primário | A resistência altera agudamente a cinemática do sprint; a técnica deve ser observada e continuar reconhecível |
| `EX20-S2` | Bentley, Atkins, Edmundson, Metcalfe e Sinclair (2016), *Impact of Harness Attachment Point on Kinetics and Kinematics During Sled Towing* — https://doi.org/10.1519/JSC.0000000000001155 | Estudo biomecânico primário | O ponto de ligação influencia a cinética e a cinemática; sustenta tratar o arnês/cinto e a ligação como parte crítica da montagem |
| `EX20-S6` | Martínez-Valencia et al. (2015), *Effects of Sled Towing on Peak Force, the Rate of Force Development and Sprint Performance During the Acceleration Phase* — https://pmc.ncbi.nlm.nih.gov/articles/PMC4519204/ | Estudo primário | Confirma deslocamento resistido por trenó durante a aceleração e alterações na aplicação de força, sem justificar uma carga pública |

### Fontes profissionais e oficiais

| Código | Fonte | Tipo | Utilização |
|---|---|---|---|
| `EX20-S3` | National Strength and Conditioning Association, *Sprinting Mechanics and Technique* — https://www.nsca.com/education/articles/kinetic-select/sprinting-mechanics-and-technique/ | Fonte técnica profissional | Base assimétrica, aceleração, alinhamento, coordenação e desaceleração com flexão de tornozelos, joelhos e ancas |
| `EX20-S4` | Titan Fitness, *Power Speed Sled with Deluxe Harness — Operator's Manual* — https://3642276.app.netsuite.com/core/media/media.nl?_xt=.pdf&c=3642276&h=-BuJhjzSIngvt0111eeuRsOwWuxAgFqs0Fg0ox1F5n6TByrz&id=25646317 | Manual oficial do fabricante | Leitura integral do manual, cuidado no uso e supervisão por pessoa capaz e competente |
| `EX20-S5` | American Heart Association, *Getting Active to Control High Blood Pressure* — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure | Orientação oficial | Respiração regular sem retenção e transição gradual entre exercício e repouso |

As fontes são independentes entre si e incluem literatura primária, uma associação profissional, um fabricante e uma organização oficial de saúde.

## Síntese por tema

### Execução

A fonte técnica da NSCA descreve uma partida estável, produção de força contra o solo, coordenação contralateral e elevação gradual do corpo durante a aceleração. A literatura primária mostra que o trenó pode modificar a inclinação, o contacto com o solo e outros parâmetros da passada. Por isso, o texto evita ângulos rígidos e usa critérios observáveis: corpo alinhado, braços e pernas em oposição, trajetória frontal e ação ainda reconhecível como sprint.

### Trenó, arnês ou cinto

O registo exige `drag_sled` e um sistema corporal por arnês de sprint ou cinto de cintura. O estudo de Bentley et al. demonstra que o ponto de ligação altera a mecânica; o manual do fabricante mostra que estes sistemas têm componentes próprios e requerem utilização cuidadosa. Daqui resultam as instruções para usar apenas equipamento compatível, ajustar sem limitar a respiração, fechar conectores, inspecionar desgaste, manter a cinta fora dos pés e alinhar corpo, cinta e trenó.

Não foi acrescentado equipamento obrigatório ou opcional. Não foi aprovada improvisação.

### Respiração

Não foi encontrada uma técnica respiratória específica e validada para sprint resistido com trenó. A orientação é, portanto, conservadora: respiração natural, regular e contínua, sem contagens nem retenção deliberada. A American Heart Association suporta respiração regular durante a atividade e alerta para retenção respiratória. O texto também trata limitação respiratória pelo arnês ou cinto como sinal para não iniciar ou terminar de forma controlada.

### Travagem

A NSCA descreve a flexão de tornozelos, joelhos e ancas como mecanismo para distribuir a absorção de força durante a desaceleração. A variante acrescenta um problema operacional: o trenó continua atrás e pode aproximar-se se a pessoa parar ou mudar de direção de forma abrupta. A instrução resultante é começar a desacelerar com espaço livre, manter a trajetória, reduzir progressivamente a velocidade e só virar ou tocar na ligação quando corpo e trenó estiverem imóveis.

Esta sequência é uma síntese conservadora de biomecânica geral de travagem e da geometria do sistema de tração; não é uma alegação de que uma fonte testou exatamente esta saída de falha.

### Segurança

Foram preservados os fatores canónicos: forças elevadas de reação do solo, perda de controlo a velocidade e carga rápida dos tecidos. Foram operacionalizados os modificadores já aprovados: fadiga, inexperiência, espaço limitado, superfície, temperatura, iluminação, terceiros, condição do equipamento e ajuste.

Os sinais de interrupção incluem dor aguda, mal-estar, perda súbita de coordenação e incapacidade de travar. Foram acrescentados sinais observáveis diretamente relacionados com a montagem: deslizamento ou abertura da ligação, compressão dolorosa, cinta junto aos pés e trenó a prender, saltar ou desviar.

### Supervisão

A supervisão permanece `recommended`, não `required`. A recomendação é especialmente forte na primeira exposição, quando o equipamento ou o contexto mudam, quando existe fadiga visível e quando a travagem ou o alinhamento são incertos. O manual da Titan afirma que o equipamento deve ser usado com cuidado por pessoas capazes e competentes sob supervisão; isto é coerente com os gatilhos canónicos.

### Erros

Os erros selecionados são observáveis e corrigíveis:

- folga que produz um puxão;
- dobra excessiva pela cintura;
- transformação do sprint numa marcha inclinada;
- cruzamento dos pés ou da linha de tração;
- rotação do tronco e braços a cruzar;
- ligação improvisada ou mal fechada;
- paragem ou mudança de direção abrupta;
- retenção da respiração.

Não se afirma que exista uma única técnica perfeita; as correções protegem a identidade e o controlo operacional.

## Variante formal

| Campo | Explicação |
|---|---|
| Base | `linear_sprint` |
| O que muda | Resistência posterior, deslocamento do trenó, linha de tração e relação corpo-carga |
| O que permanece | Corrida linear, apoios alternados, coordenação contralateral, fase aérea e travagem |
| Equipamento adicional | Trenó de arrasto e arnês de sprint ou cinto de cintura compatível |
| Montagem adicional | Ajuste, fecho de conectores, retirada da folga e alinhamento |
| Riscos adicionais | Puxão, falha ou deslizamento da ligação, contacto com a cinta, desvio ou aproximação do trenó |
| Porque é separada | A carga externa e a transmissão posterior alteram materialmente mecânica, montagem e segurança, sem apagar a identidade nuclear do sprint |

## Fronteira com prescrição

Não foi prescrita carga. Também não foram definidos repetições, séries, distância, duração, intensidade, velocidade, ritmo, cadência, descanso, frequência ou progressão.

A literatura sobre relações carga-velocidade e alterações cinemáticas foi usada apenas para justificar que a resistência altera a técnica e que a sua seleção exige julgamento fora deste conteúdo. Não foram convertidos valores experimentais em instruções públicas.

## Limitações

- Não existe uma norma oficial única que cubra toda a execução do sprint resistido com trenó para principiantes.
- Manuais de modelos diferentes podem definir montagem e compatibilidade diferentes.
- O atrito varia com a superfície, o trenó e as condições ambientais.
- Os estudos biomecânicos foram realizados em populações e condições específicas; não autorizam utilização universal.
- A estratégia de saída em caso de falha é uma síntese conservadora e deve ser revista por especialista no contexto real.
- O conteúdo não substitui revisão clínica ou profissional quando indicada.

## Verificações de conformidade

- Português europeu e UTF-8 NFC: verificado.
- Identidade, risco, equipamento, superfície e relações: preservados.
- Passos de execução: pelo menos cinco.
- Indicações principais: pelo menos quatro.
- Erros comuns com reconhecimento e correção: pelo menos quatro.
- Perguntas de compreensão: doze.
- Cinco campos adicionais de risco alto: preenchidos.
- `formal_variant_explanation`: preenchido sem copiar uma explicação do exercício-base.
- Dose, prescrição, promessa, diagnóstico, tratamento, código e publicação: excluídos.
- Aprovação de multimédia: não realizada.
