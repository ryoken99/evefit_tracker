# Relatório de investigação — `doorway_pectoral_stretch`

## Resultado

O conteúdo para principiantes pode ser aprovado com limites, sem alterar a identidade canónica, o risco operacional moderado, os requisitos de apoio e superfície, a ausência de equipamento portátil ou as relações aprovadas.

A síntese técnica adotada é: posição de pé com passada estável; contacto unilateral distribuído pelo antebraço numa ombreira fixa; cotovelo fletido numa altura confortável; avanço ou rotação gradual do tronco para longe do braço apoiado; ombro controlado; respiração natural e contínua; saída pelo recuo do tronco antes de libertar o braço.

## Questões investigadas

- Como organizar o contacto do antebraço no vão da porta?
- Que movimento do tronco cria o alongamento sem depender de impulso?
- Que alinhamentos reduzem compensações no ombro e na lombar?
- Que sensação é esperada e quais são os sinais de aviso?
- Que orientação respiratória é defensável sem impor contagens ou retenções?
- Em que situações é prudente procurar supervisão ou revisão individual?

## Fontes e contributo

### 1. Higuchi et al., 2021 — literatura científica primária

O estudo descreve o *doorway stretch* com o ombro em abdução e rotação externa, o cotovelo fletido e o antebraço estabilizado. Fornece apoio direto à configuração mecânica do membro superior e à relação entre a posição e o peitoral menor.

Limites: participaram apenas rapazes praticantes de basebol do ensino secundário; a avaliação foi aguda; a figura do protocolo indica estabilização do antebraço por um investigador. O estudo não autoriza generalização para principiantes adultos, execução autónoma, segurança universal, dose ou resultado clínico.

Fonte: Higuchi T, Nakao Y, Tanaka Y, et al. *JSES International*. 2021;5(6):972-977. DOI: 10.1016/j.jseint.2021.07.002. [PubMed](https://pubmed.ncbi.nlm.nih.gov/34766072/)

### 2. Borstad e Ludewig, 2006 — literatura científica primária

O estudo comparou três formas de alongamento do peitoral menor, incluindo um autoalongamento unilateral, com medição eletromagnética da alteração do comprimento muscular. Sustenta a família mecânica de alongamento unilateral assistido por suporte e a plausibilidade anatómica da posição.

Limites: a amostra não apresentava patologia do ombro; o desfecho foi biomecânico e imediato. A investigação não estabelece benefício clínico, segurança individual ou uma forma universal de executar.

Fonte: Borstad JD, Ludewig PM. *Journal of Shoulder and Elbow Surgery*. 2006;15(3):324-330. DOI: 10.1016/j.jse.2005.08.011. [PubMed](https://pubmed.ncbi.nlm.nih.gov/16679233/)

### 3. University Hospitals of Leicester NHS Trust — orientação profissional oficial

O folheto descreve um alongamento do peito em pé no vão, com o cotovelo fletido e avanço e rotação dos ombros e da bacia para longe do braço. Recomenda procurar uma sensação suave e reduzir ou interromper perante formigueiro ou aumento da dormência.

Limites: o material foi produzido para pessoas com síndrome do desfiladeiro torácico. Foram aproveitados apenas os elementos mecânicos e os sinais de aviso que coincidem com o registo canónico; não foi transposta qualquer indicação clínica.

Fonte: *Exercises to help manage your thoracic outlet syndrome*. [University Hospitals of Leicester NHS Trust](https://yourhealth.leicestershospitals.nhs.uk/library/csi/therapies/physiotherapy/4419-exercises-to-help-manage-your-thoracic-outlet-syndrome-tos/file)

### 4. University Hospitals Plymouth NHS Trust — orientação profissional oficial

O folheto descreve o antebraço apoiado na ombreira e uma entrada lenta através do vão, com as pernas a controlar o deslocamento. Indica que os alongamentos devem ser confortáveis e que a pessoa deve aliviar a posição perante dor ou retenção da respiração. Estes elementos sustentam o contacto no vão, a entrada gradual e a orientação de respirar sem bloqueio.

Limites: o documento pertence a um programa de fisioterapia após cirurgia mamária. Não foi usado para autorizar a execução após cirurgia nem para criar uma dose.

Fonte: *Physiotherapy for Breast Surgery*. [University Hospitals Plymouth NHS Trust](https://www.plymouthhospitals.nhs.uk/display-pil/pil-physiotherapy-for-breast-surgery-7032/)

### 5. American Academy of Orthopaedic Surgeons — guia profissional oficial

O programa de condicionamento do ombro recomenda não ignorar dor durante o exercício e contactar um médico ou fisioterapeuta quando existe dor ou dúvida sobre a execução. O guia sustenta a linguagem conservadora de interrupção e encaminhamento, mas não descreve diretamente este alongamento.

Fonte: *Rotator Cuff and Shoulder Conditioning Program*. [OrthoInfo — AAOS](https://www.orthoinfo.org/recovery/rotator-cuff-and-shoulder-conditioning-program/)

## Síntese por tópico

### Execução e contacto

Há convergência suficiente para documentar o antebraço apoiado numa ombreira, o cotovelo fletido, uma base de pé estável e o avanço ou rotação gradual do tronco. O contacto deve distribuir-se pelo antebraço; a pressão direta sobre a ponta do cotovelo não faz parte da identidade e pode criar desconforto local.

### Respiração

A fonte de Plymouth liga a retenção da respiração a uma posição que deve ser aliviada. Por isso, a instrução defensável é respirar naturalmente e sem retenção. Não foram introduzidas contagens, fases respiratórias obrigatórias ou técnicas de respiração.

### Segurança do ombro

O registo canónico identifica desconforto anterior, rotação externa excessiva e deslocamento anterior descontrolado como riscos. O conteúdo traduz estes pontos em verificações observáveis: ombro afastado da orelha, ausência de pressão articular concentrada, entrada gradual e capacidade de inverter o movimento. Dor aguda ou crescente, instabilidade, sintomas neurológicos, fraqueza súbita, perda de controlo e mal-estar determinam interrupção.

### Sensações

A sensação esperada é uma tração suave e distribuída no peito e, possivelmente, na zona anterior do ombro. Picada, aperto profundo, compressão articular, formigueiro, dormência, fraqueza ou sensação de deslocamento não são descritos como alongamento normal.

### Erros

Os erros documentados são: forçar rotação externa, deixar o ombro avançar ou subir, arquear a lombar, concentrar pressão no cotovelo, entrar com impulso e usar apoio ou superfície instáveis. Cada erro foi associado a um sinal reconhecível e a uma correção baseada em recuar, reorganizar ou interromper.

### Supervisão

Preserva-se `supervision_requirement: none` e `spotter_required: false`. A orientação profissional é indicada como revisão de elegibilidade, não como requisito geral: regresso após lesão ou cirurgia, historial de instabilidade ou hipermobilidade, sintomas relevantes, incapacidade de controlar a entrada e a saída, assistência humana ou amplitude extrema.

## Decisões de conteúdo

- **Identidade:** preservada como exercício canónico unilateral de alongamento peitoral com suporte fixo.
- **Risco:** preservado como moderado.
- **Equipamento:** nenhum equipamento portátil; mantém-se a exigência de ombreira ou aresta vertical fixa.
- **Superfície e ambiente:** espaço interior, piso estável e antiderrapante, sem circulação no vão.
- **Relações:** preservadas sem adições: relação compatível em treino principal e relação condicional em aquecimento.
- **Dose:** omitida.
- **Tempo de retenção:** omitido.
- **Prescrição:** omitida.
- **Diagnóstico, tratamento e promessas:** omitidos.
- **Multimédia e código:** não aprovados nem implementados.

## Confiança e limitações

Confiança global **moderada**. A execução nuclear tem apoio convergente em fontes hospitalares e literatura primária. A respiração e a supervisão têm apoio profissional indireto. A evidência direta é limitada por populações específicas, contextos clínicos e avaliações agudas; não sustenta segurança universal nem resultados individuais.

Não ficaram campos de conteúdo por resolver.

**Implementação realizada: não**
