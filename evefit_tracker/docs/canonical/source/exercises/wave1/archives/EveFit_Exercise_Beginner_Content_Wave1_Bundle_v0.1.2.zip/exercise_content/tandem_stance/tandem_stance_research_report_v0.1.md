# Relatório de investigação — Postura tandem

**Exercise ID:** `tandem_stance`  
**Agente:** EX-37  
**Âmbito:** conteúdo documental para principiante  
**Data da pesquisa:** 2026-07-24  
**Implementação realizada: não**

## 1. Resultado

A pesquisa sustenta conteúdo para principiante com limites explícitos:

- postura bipodal estática, com um pé diretamente à frente do outro e o calcanhar anterior junto à ponta do pé posterior;

- dois pés no chão e ausência de passos depois de estabelecida a posição;

- apoio firme opcional, sobretudo útil para entrar, controlar ou sair;

- olhos abertos, olhar em frente e respiração natural sem retenção;

- risco operacional moderado devido à base muito estreita, perda de equilíbrio e queda;

- supervisão recomendada, com necessidade acrescida nos gatilhos canónicos;

- piso firme, plano, estável, antiderrapante e área livre.

Não foi encontrada base para alterar identidade, risco, equipamento, superfície ou relações. Não foi adicionada dose, progressão programada, promessa, diagnóstico ou tratamento.

## 2. Perguntas de investigação

1. Qual é a configuração calcanhar-ponta que distingue a postura tandem?
2. O apoio inicial ou contínuo é compatível com uma execução segura?
3. Que instruções simples de olhar, postura e respiração são defensáveis?
4. Que fatores explicam o risco de perda de equilíbrio?
5. Que erros podem ser reconhecidos por um principiante?
6. Em que situações deve ser enfatizada a supervisão?
7. Que elementos pertencem a protocolos de avaliação ou prescrição e devem ser excluídos?

## 3. Método

Foram consultadas fontes independentes de três níveis:

- um instrumento oficial de saúde pública;

- um manual profissional de exercício e equilíbrio;

- três estudos primários sobre apoio inicial, distribuição de forças e controlo direcional do equilíbrio.

A informação foi usada apenas quando era coerente com o registo canónico. Elementos de temporização, dose, progressão de programa, interpretação diagnóstica e resultados populacionais não foram transferidos para as instruções públicas.

## 4. Fontes e apreciação crítica

### 4.1 CDC STEADI — instrumento oficial

**Referência:** Centers for Disease Control and Prevention. [The 4-Stage Balance Test](https://www.cdc.gov/steadi/media/pdfs/STEADI-Assessment-4Stage-508.pdf). 2017.

**Contributo:**

- define a posição tandem com um pé à frente do outro e calcanhar junto à ponta;

- conserva os olhos abertos;

- permite movimentos dos braços ou do corpo sem mover os pés;

- orienta o profissional a ajudar a pessoa a assumir a posição e a permanecer pronto para assistir se houver perda de equilíbrio.

**Limite:** é um instrumento de avaliação. A respetiva temporização e interpretação de desempenho não pertencem à identidade nem ao conteúdo de execução aqui produzido.

### 4.2 UNC Otago — manual profissional

**Referência:** UNC Center for Aging and Health. [Tools to Implement the Otago Exercise Program](https://www.med.unc.edu/aging/cgwep/wp-content/uploads/sites/865/2024/04/Otago-Guide-for-PT_April-2024-update.pdf). Atualização de 2024.

**Contributo:**

- orienta a pessoa a ficar alta, ao lado de cadeira ou bancada, com olhar em frente;

- coloca um pé diretamente à frente do outro, formando uma linha;

- admite contacto leve com apoio;

- recorda a respiração durante o exercício;

- associa tarefas de equilíbrio a equipamento firme e a acompanhamento profissional.

**Limite:** é um programa dirigido a pessoas idosas e contém dose e progressões. Esses elementos foram excluídos.

### 4.3 Hile et al. — literatura primária sobre apoio inicial

**Referência:** Hile ES, Brach JS, Perera S, Wert DM, VanSwearingen JM, Studenski SA. [Interpreting the Need for Initial Support to Perform Tandem Stance Tests of Balance](https://academic.oup.com/ptj/article/92/10/1316/2735160). *Physical Therapy*. 2012. doi:10.2522/ptj.20110283.

**Desenho:** análise transversal secundária de dados observacionais em adultos mais velhos residentes na comunidade.

**Contributo:**

- mostra que a necessidade de apoio para estabilizar na posição é informação relevante e não deve ser ignorada;

- justifica distinguir contacto planeado de apoio, necessidade repetida de apoio e execução sem apoio;

- reforça a entrada assistida e a presença de ajuda pronta em pessoas com menor controlo.

**Limite:** amostra e desenho não permitem transformar o apoio num indicador diagnóstico universal nem definir uma prescrição.

### 4.4 Jonsson et al. — literatura primária sobre estabilidade e carga

**Referência:** Jonsson E, Seiger A, Hirschfeld H. [Postural steadiness and weight distribution during tandem stance in healthy young and elderly adults](https://pubmed.ncbi.nlm.nih.gov/15621326/). *Clinical Biomechanics*. 2005. doi:10.1016/j.clinbiomech.2004.09.008.

**Desenho:** estudo biomecânico transversal em adultos saudáveis jovens e mais velhos, com forças de reação do solo e atividade muscular.

**Contributo:**

- identifica a entrada na posição como uma fase particularmente exigente;

- mostra que a distribuição do peso pode favorecer o membro posterior;

- desaconselha transformar “peso exatamente igual” numa regra técnica obrigatória.

**Limite:** contexto laboratorial e participantes saudáveis. O estudo não determina como cada pessoa deve distribuir o peso.

### 4.5 O'Connor e Kuo — literatura primária sobre controlo direcional

**Referência:** O'Connor SM, Kuo AD. [Direction-Dependent Control of Balance During Walking and Standing](https://pmc.ncbi.nlm.nih.gov/articles/PMC2746770/). *Journal of Neurophysiology*. 2009. doi:10.1152/jn.00131.2009.

**Desenho:** estudo experimental biomecânico de controlo do equilíbrio em pé e durante a marcha.

**Contributo:**

- mostra que a configuração tandem aumenta especialmente a sensibilidade às perturbações mediolaterais;

- dá suporte mecânico à classificação de base muito estreita e às pequenas correções laterais;

- reforça a necessidade de espaço seguro e apoio acessível.

**Limite:** investiga mecanismos e não fornece autorização clínica, dose ou promessa de benefício.

## 5. Síntese por tema

### 5.1 Posição calcanhar-ponta

O CDC e o manual Otago convergem na colocação de um pé diretamente à frente do outro. O conteúdo usa “calcanhar do pé da frente junto à ponta do pé posterior” para permanecer fiel à definição canónica. A exigência de uma linha sem afastamento lateral distingue tandem de semi-tandem.

### 5.2 Apoio

O apoio permanece opcional, conforme o registo canónico. O CDC descreve assistência para assumir a posição e Hile et al. mostram que a necessidade de apoio inicial é informação funcional relevante. O conteúdo permite contacto leve e planeado num apoio firme, mas trata preensão brusca, apoio instável ou necessidade repetida não planeada como sinais para terminar.

### 5.3 Distribuição do peso

A instrução pública conserva ambos os pés apoiados e evita exigir uma divisão exata. Jonsson et al. observaram distribuição assimétrica com maior carga posterior em participantes saudáveis. A decisão conservadora é não impor percentagens nem privilegiar deliberadamente um pé.

### 5.4 Olhar e respiração

O CDC mantém os olhos abertos; o manual Otago orienta olhar em frente. Isto sustenta um ponto visual estável, sem introduzir variantes de olhos fechados.

O manual Otago recorda que a pessoa deve respirar durante o exercício. Como a postura não tem fases concêntrica e excêntrica operacionais para o utilizador, a orientação limita-se a respiração natural e contínua, sem contagens, retenções ou sincronização obrigatória.

### 5.5 Risco de queda e supervisão

A base tandem reduz fortemente a margem lateral; a literatura biomecânica confirma a elevada exigência mediolateral. O risco moderado existente é, portanto, preservado. O CDC recomenda que quem avalia permaneça pronto a ajudar, e o estudo de Hile et al. reforça a relevância do apoio inicial.

A supervisão mantém-se recomendada. O conteúdo exige que não se execute sem supervisão quando houver risco elevado de queda, quedas recentes, incapacidade de sair de forma independente, necessidade repetida de apoio não planeado ou restrição clínica relevante. Não foi transformada em exigência universal de spotter.

### 5.6 Superfície e espaço

Não foi identificada evidência que justificasse alterar o requisito canónico. Mantêm-se piso firme, plano, estável e antiderrapante, área livre e iluminação suficiente. Continuam excluídas superfícies escorregadias, instáveis ou desorganizadas, veículos em movimento e alturas desprotegidas.

### 5.7 Erros

Os erros públicos foram derivados da identidade, das salvaguardas das fontes e dos mecanismos estudados:

| Erro | Base |
|---|---|
| Espaço lateral entre os pés | Viola a posição tandem completa confirmada por CDC e Otago. |
| Rotação dos pés ou da bacia | Evita o alinhamento frontal e pode mascarar a base pretendida. |
| Olhar para baixo ou fechar os olhos | Contraria olhos abertos e olhar em frente. |
| Mover um pé ou dar um passo | Termina a natureza estática da tarefa. |
| Agarrar apoio instável | Conflita com ajuda pronta e apoio firme. |
| Prender a respiração e enrijecer | Contraria a orientação profissional de continuar a respirar. |

As correções mandam recomeçar a partir de uma base segura ou terminar, sem prolongar a tarefa nem atribuir dose.

## 6. Decisões de conteúdo

| Campo | Decisão | Fundamentação |
|---|---|---|
| Identidade | Preservada | Tandem completo, bipodal, estático, sem deslocamento. |
| Risco | Moderado | Base muito estreita, perda de equilíbrio e queda permanecem fatores principais. |
| Equipamento | Nenhum obrigatório; apoio estável opcional | Coerente com o registo e com CDC, Otago e Hile et al. |
| Superfície | Firme, plana, estável e antiderrapante | Preservação do requisito canónico de segurança. |
| Respiração | Natural e contínua, sem retenção | Orientação profissional disponível, sem padrão específico defensável. |
| Distribuição do peso | Ambos os pés apoiados; sem igualdade forçada | Coerente com Jonsson et al. |
| Supervisão | Recomendada, reforçada nos gatilhos canónicos | Mantém o registo sem exigir spotter universal. |
| Conteúdo | Aprovado com limites | Boa convergência técnica, mas sem elegibilidade individual nem generalização universal. |

## 7. Relações preservadas

| `usage_context_id` | `capability_root_id` | `training_concept_id` | `training_intention_id` | Estado | Papel |
|---|---|---|---|---|---|
| `activation` | `motor_control_coordination` | `base_of_support_control` | `prime_support_control` | `conditional` | `principal_candidate` |
| `main_training` | `motor_control_coordination` | `base_of_support_control` | `improve_static_balance` | `compatible` | `alternative_primary` |
| `prevention` | `motor_control_coordination` | `base_of_support_control` | `increase_reduced_base_tolerance` | `conditional` | `complementary` |

Nenhuma relação foi criada, removida ou reclassificada. Foram mantidos os limites de especificidade da tarefa, ausência de promessa e classificação condicional quando aplicável.

## 8. Limitações e campos não resolvidos

- Não existe validação de elegibilidade individual.

- Não se generalizam resultados de adultos saudáveis ou mais velhos para todas as populações.

- Não se interpreta o desempenho como diagnóstico.

- Não se inclui dose, duração, frequência, intensidade, progressão programada ou protocolo.

- Não se promete prevenção de queda, melhoria clínica ou transferência automática.

- Não foram identificados campos canónicos por resolver.

## 9. Conclusão

Há evidência independente suficiente para explicar a postura tandem a um principiante com linguagem conservadora e segura. As fontes oficiais e profissionais sustentam a configuração, o olhar, o apoio e a assistência; os estudos primários esclarecem o papel do apoio inicial, a distribuição não necessariamente igual do peso e a exigência mediolateral. O conteúdo mantém integralmente a identidade canónica, o risco moderado, o apoio opcional, a superfície exigida e as três relações aprovadas.
