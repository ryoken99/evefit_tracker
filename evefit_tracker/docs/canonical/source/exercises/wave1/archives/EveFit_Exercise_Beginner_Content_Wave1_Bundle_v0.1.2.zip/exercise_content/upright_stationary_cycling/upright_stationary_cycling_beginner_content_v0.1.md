# Pedalada em bicicleta estacionária vertical

Conteúdo para principiantes em português europeu.

## Descrição curta

Pedalada cíclica numa bicicleta fixa, sentado numa configuração vertical e sem deslocamento.

## O que é

Senta-te no selim de uma bicicleta estacionária vertical e faz os pedais rodar de forma alternada e contínua. A bacia permanece apoiada, os pés mantêm contacto seguro com os pedais e o tronco fica controlado.

## O que vais fazer

Vais ajustar a bicicleta ao teu corpo, montar com cuidado, apoiar os pés nos pedais, produzir um ciclo de pedalada suave e terminar apenas depois de os pedais estarem completamente parados.

## Porque existe este movimento

O movimento permite repetir propulsão cíclica contra a resistência de um ergómetro fixo. A identidade não define resistência, cadência, duração, distância ou outro parâmetro de prescrição.

## Antes de começares

1. Confirma que consegues sentar-te, alcançar os pedais e manter os contactos de apoio necessários sem instabilidade marcada.
2. Não comeces se a bicicleta oscilar, estiver danificada, tiver peças soltas ou apresentar um comando de ajuste que não bloqueia.
3. Identifica, no manual ou no painel da máquina, como iniciar, reduzir o movimento e parar; os comandos variam entre modelos.
4. Se o equipamento ou o ambiente forem desconhecidos, pede uma demonstração a um profissional qualificado.
5. Se estás a regressar após lesão ou cirurgia, ou tens sintomas cardiorrespiratórios relevantes, procura revisão adequada antes de usares este conteúdo como guia de execução.

## Preparar o equipamento

1. Mantém a bicicleta numa base nivelada e confirma que não abana.
2. Com os pedais parados, verifica visualmente selim, pedais, correias, guiador e mecanismos de bloqueio.
3. Faz o ajuste inicial do selim com a bicicleta parada. Quando verificares a posição sentado, desmonta antes de voltar a ajustar, salvo indicação diferente no manual do modelo.
4. Ajusta o selim para que o joelho permaneça ligeiramente fletido no ponto de maior extensão da perna, sem bloquear e sem obrigar a bacia a oscilar.
5. Ajusta o alcance do guiador para conseguires manter a coluna numa posição neutra, os ombros afastados das orelhas e os cotovelos ligeiramente fletidos.
6. Centra cada antepé sobre a zona de apoio do pedal. Se existirem correias, prende-as de modo confortável e suficientemente seguro para o pé não escorregar, sem compressão excessiva.
7. Confirma que todos os pinos, manípulos ou alavancas de ajuste ficaram totalmente engatados e fora da trajetória das pernas.

## Preparar o espaço

1. Usa a bicicleta num espaço interior, com apoio nivelado e estável.
2. Mantém livre a zona necessária para montar, desmontar e afastar-te da máquina.
3. Garante visibilidade suficiente para reconhecer pedais, correias e comandos.
4. Afasta objetos, cabos e roupa solta das peças móveis.
5. Não uses uma máquina instável, danificada ou colocada numa base insegura.

## Verificação do corpo

1. Consegues montar e sentar-te sem perder o controlo?
2. Consegues manter a bacia apoiada e alcançar o guiador sem te esticares em excesso?
3. Os joelhos completam a volta sem bloquear e sem obrigar a bacia a balançar?
4. Os pés permanecem apoiados sem escorregar nem ficar comprimidos pelas correias?
5. Não tens dor nova, tonturas, confusão, desconforto no peito ou falta de ar atípica antes de começares?

## Posição inicial

Senta-te ao centro do selim, com a bacia estável. Coloca os antepés na zona central dos pedais e segura-os conforme o sistema disponível. Mantém o tronco numa posição vertical confortável, a coluna neutra, os ombros relaxados e as mãos pousadas levemente no guiador se precisares desse apoio.

## Confirmar a posição inicial

1. Bicicleta estável e ajustes bloqueados.
2. Bacia centrada no selim.
3. Pés seguros e alinhados nos pedais.
4. Joelho ligeiramente fletido na maior extensão, sem bloqueio.
5. Tronco controlado e coluna neutra.
6. Ombros relaxados e cotovelos ligeiramente fletidos.
7. Comando de paragem identificado e zona de desmontagem livre.

## Passos de execução

1. Mantém a bicicleta e os pedais completamente parados. Usa apenas um ponto fixo indicado pelo fabricante, transfere o corpo com controlo para o centro do selim, estabiliza a bacia e só depois coloca ou fixa os pés, sem impor um lado universal.
2. Com a bicicleta parada, confirma uma última vez que o selim e os restantes ajustes estão bloqueados.
3. Organiza a postura: bacia estável, coluna neutra, ombros relaxados e mãos leves no guiador quando usado.
4. Inicia a rotação no sentido indicado pelo fabricante, aplicando força alternada aos pedais até o ciclo ficar contínuo.
5. Mantém os pés em contacto seguro e deixa cada joelho seguir a direção do respetivo pé, sem o forçar para dentro ou para fora.
6. Continua a pedalar com transições suaves, sem bloquear os joelhos, levantar a bacia ou balançar o tronco.
7. Respira de forma natural e contínua, sem prender a respiração, e mantém a face, os ombros e as mãos sem tensão desnecessária.
8. Para terminar, reduz o movimento de forma controlada e usa o comando de paragem conforme o manual da máquina, se necessário.
9. Espera pela imobilização completa dos pedais; só depois solta os pés e desmonta com cuidado.

## Fases do movimento

### Preparação e contacto

A bicicleta está parada, os ajustes estão bloqueados e a pessoa estabelece apoio no selim, nos pedais e, opcionalmente, no guiador.

### Propulsão

Uma perna aplica força ao pedal enquanto a manivela roda e a outra perna acompanha a metade oposta do ciclo.

### Transição alternada

As pernas trocam continuamente de função sem pausa brusca, mantendo o percurso circular das manivelas.

### Desaceleração

A rotação é reduzida sob controlo e, quando aplicável, o sistema de travagem ou paragem do modelo é utilizado segundo o manual.

### Saída

Os pés só são libertados e a pessoa só desmonta quando pedais e volante estão completamente parados.

## Respiração

Respira naturalmente e de forma contínua durante todo o ciclo. Não existe uma fase respiratória obrigatória ligada a cada volta do pedal e não deves prender a respiração. Se a falta de ar for atípica, surgir de forma súbita ou impedir o controlo do movimento, pára.

## Sensações esperadas

1. Trabalho cíclico e alternado das pernas.
2. Pressão de apoio distribuída pelo selim e pelos pedais.
3. Necessidade de estabilizar suavemente a bacia e o tronco.
4. Respiração que se adapta ao esforço sem sensação atípica.

## Sensações inesperadas ou de alerta

1. Dor nova ou crescente no joelho, anca, tornozelo, pé ou costas.
2. Pé a escorregar, a perder contacto ou a ficar excessivamente comprimido.
3. Bacia a oscilar, joelho a bloquear ou perda de controlo da rotação.
4. Tonturas, confusão, sensação de desmaio, desconforto no peito ou falta de ar atípica.

## Indicações técnicas principais

1. Bloqueia os ajustes antes de pedalar.
2. Mantém o joelho ligeiramente fletido na maior extensão.
3. Pés seguros e bacia quieta.
4. Ombros relaxados e mãos leves.
5. Respira continuamente.
6. Pára os pedais antes de desmontar.

## Erros comuns e correções

### Erro 1: Pedalar com o selim demasiado alto, baixo, próximo ou afastado.

- Como reconhecer: O joelho bloqueia ou fica excessivamente dobrado, a bacia balança de um lado para o outro, ou tens de alcançar o pedal com a ponta do pé.
- Como corrigir: Pára, desmonta e reajusta o selim. Volta a verificar se existe uma ligeira flexão do joelho na maior extensão e se a bacia permanece estável.

### Erro 2: Deixar o pé mal centrado ou a correia demasiado solta ou apertada.

- Como reconhecer: O pé desliza, levanta-se do pedal, muda de posição durante a volta ou sente compressão desconfortável.
- Como corrigir: Imobiliza os pedais, recentra o antepé e ajusta a correia para segurar confortavelmente sem apertar em excesso.

### Erro 3: Oscilar o tronco ou descarregar demasiado peso nas mãos.

- Como reconhecer: Os ombros aproximam-se das orelhas, os cotovelos ficam rígidos, as mãos apertam o guiador ou a bacia perde estabilidade.
- Como corrigir: Interrompe o ciclo e revê o alcance do guiador e o ajuste do selim. Retoma apenas quando conseguires manter coluna neutra, ombros relaxados e apoio leve das mãos.

### Erro 4: Ajustar o selim ou outro mecanismo enquanto pedalas.

- Como reconhecer: Uma mão procura o pino ou a alavanca enquanto as manivelas ainda rodam, ou o ajuste não fica completamente engatado.
- Como corrigir: Pára totalmente, desmonta e segue o procedimento específico do fabricante antes de voltar a pedalar.

### Erro 5: Soltar os pés ou desmontar com os pedais ainda em movimento.

- Como reconhecer: O volante ou as manivelas continuam a rodar quando deslocas o corpo para sair.
- Como corrigir: Reduz a rotação de forma controlada, usa o comando de paragem conforme o modelo e espera pela imobilização completa.

## Formas de simplificar ou ensaiar

1. Familiariza-te primeiro com a montagem, os ajustes e a desmontagem enquanto a máquina está completamente parada.
2. Mantém as mãos pousadas levemente no guiador se esse apoio tornar a posição mais previsível.
3. Escolhe uma configuração do guiador que permita uma postura confortável e controlada, sem procurar uma posição baixa.
4. Pede ajuda para identificar os comandos e os bloqueios de ajuste quando o modelo for desconhecido.

## Supervisão

O registo canónico não exige parceiro, observador nem supervisão de rotina. É prudente obter demonstração ou acompanhamento quando existe instabilidade marcada ou quando a pessoa não conhece a máquina ou o ambiente. Pessoas mais velhas, pessoas com limitações de equilíbrio e pessoas anteriormente sedentárias podem precisar de adaptação. O regresso após lesão ou cirurgia e a presença de sintomas cardiorrespiratórios relevantes exigem revisão apropriada.

## Como terminar

Mantém a bacia apoiada e reduz a rotação de forma controlada. Usa o comando de paragem ou travagem apenas conforme as instruções do modelo. Confirma visualmente e pela ausência de movimento sob os pés que os pedais pararam. Liberta as correias ou os pés apenas depois da paragem completa. Desmonta para a zona livre, usando pontos fixos de apoio sem tocar no mecanismo móvel.

## Nota de segurança

O risco operacional base é baixo, mas depende do ajuste correto, do contacto seguro dos pés e do estado da bicicleta. Não uses uma máquina instável ou danificada. Não ajustes mecanismos durante a pedalada e não desmontes antes da paragem completa.

## Quando parar ou reduzir

1. Pára perante desconforto no peito ou falta de ar atípica.
2. Pára perante tonturas, confusão ou sensação de desmaio.
3. Pára perante perda de controlo, pé a escorregar ou dor nova.
4. Se um sinal for intenso, não desaparecer após parar ou parecer urgente, procura assistência adequada.

## Segurança do equipamento

Segue sempre o manual e os avisos do modelo específico. Inspeciona a bicicleta quanto a danos, desgaste e peças soltas antes de a usar. Confirma que pinos, manípulos e alavancas ficam bloqueados após cada ajuste. Mantém os pés seguros nos pedais e as peças móveis livres de objetos. Não uses a bicicleta até uma peça defeituosa ser reparada ou substituída. Em modelos sem roda livre, o volante pode manter os pedais em movimento; usa a paragem indicada pelo fabricante e espera pela imobilização completa.

## Segurança do espaço

Mantém a bicicleta numa superfície nivelada e com base estável. Conserva livre a área de acesso e desmontagem. Usa iluminação suficiente para ver apoios e comandos. Evita uma base instável e qualquer condição que dificulte a montagem ou a saída segura.

## Limitações

1. Os comandos de resistência, travagem, paragem e ajuste variam entre modelos; prevalecem o manual e os avisos da bicicleta usada.
2. A indicação de joelho ligeiramente fletido é uma verificação geral, não substitui um ajuste individual por profissional quando há desconforto ou necessidades específicas.
3. O conteúdo não define dose, intensidade, cadência, duração, distância, progressão nem elegibilidade individual.
4. O conteúdo não diagnostica sintomas nem substitui revisão clínica ou profissional quando esta é indicada.

## Teste de compreensão

### 1. Qual é o equipamento obrigatório para este exercício?

Resposta esperada: Uma bicicleta estacionária vertical estável, ajustável e funcional.

### 2. Como deve estar o joelho no ponto de maior extensão da perna?

Resposta esperada: Ligeiramente fletido, sem bloquear.

### 3. O que indica que o selim pode estar demasiado alto?

Resposta esperada: O joelho bloqueia, a bacia oscila ou é necessário alcançar o pedal.

### 4. Quando podes ajustar o selim ou outro mecanismo?

Resposta esperada: Com a bicicleta totalmente parada e segundo o manual do modelo; por regra, desmontando antes de ajustar.

### 5. Como devem ficar as correias dos pedais?

Resposta esperada: Confortáveis e suficientemente seguras para impedir que o pé escorregue, sem apertar em excesso.

### 6. Que posição de tronco e ombros deves procurar?

Resposta esperada: Coluna neutra, tronco controlado e ombros relaxados.

### 7. É necessário prender a respiração durante a propulsão?

Resposta esperada: Não. A respiração deve ser natural e contínua.

### 8. O que deves fazer se o pé começar a escorregar?

Resposta esperada: Parar, imobilizar os pedais e corrigir a posição ou a correia antes de retomar.

### 9. Quando é seguro libertar os pés e desmontar?

Resposta esperada: Apenas depois de pedais e volante estarem completamente parados.

### 10. Que sinais obrigam a interromper a pedalada?

Resposta esperada: Desconforto no peito ou falta de ar atípica, tonturas ou confusão, perda de controlo ou dor nova.

### 11. Quando é sensato pedir supervisão ou uma demonstração?

Resposta esperada: Quando existe instabilidade marcada ou quando a máquina ou o ambiente são desconhecidos.

### 12. Este conteúdo determina resistência, cadência ou duração?

Resposta esperada: Não. Esses elementos pertencem à prescrição e não são definidos aqui.

## Fontes e limites da evidência

### Fonte 1: Upright bike, recumbent bike, treadmill and ElliptiGO biomechanical comparison

- Autor ou entidade: A1-S19 — Bouillon et al. — Upright bike, recumbent bike, treadmill and ElliptiGO biomechanical comparison — estudo biomecânico indexado — https://pubmed.ncbi.nlm.nih.gov/27104052/ — Fonte existente usada apenas para sustentar a distinção da configuração vertical face a outras modalidades.
- Tipo: estudo biomecânico indexado
- Localizador: https://pubmed.ncbi.nlm.nih.gov/27104052/
- Usada para: A1-S19 — Bouillon et al. — Upright bike, recumbent bike, treadmill and ElliptiGO biomechanical comparison — estudo biomecânico indexado — https://pubmed.ncbi.nlm.nih.gov/27104052/ — Fonte existente usada apenas para sustentar a distinção da configuração vertical face a outras modalidades.
- Limite: A1-S19 — Bouillon et al. — Upright bike, recumbent bike, treadmill and ElliptiGO biomechanical comparison — estudo biomecânico indexado — https://pubmed.ncbi.nlm.nih.gov/27104052/ — Fonte existente usada apenas para sustentar a distinção da configuração vertical face a outras modalidades.

### Fonte 2: Investing in a Personal Trainer

- Autor ou entidade: A2-S04 — American College of Sports Medicine — Investing in a Personal Trainer — fonte profissional — https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf — Fonte existente usada apenas para enquadrar o ciclismo como atividade aeróbia; não sustenta dose.
- Tipo: fonte profissional
- Localizador: https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf
- Usada para: A2-S04 — American College of Sports Medicine — Investing in a Personal Trainer — fonte profissional — https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf — Fonte existente usada apenas para enquadrar o ciclismo como atividade aeróbia; não sustenta dose.
- Limite: A2-S04 — American College of Sports Medicine — Investing in a Personal Trainer — fonte profissional — https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf — Fonte existente usada apenas para enquadrar o ciclismo como atividade aeróbia; não sustenta dose.

### Fonte 3: Concept2 Training

- Autor ou entidade: A2-S11 — Concept2 — Concept2 Training — documentação oficial de fabricante — https://www.concept2.com/training — Fonte existente usada apenas para mecânica geral do ergómetro; não foi extrapolada para comandos específicos.
- Tipo: documentação oficial de fabricante
- Localizador: https://www.concept2.com/training
- Usada para: A2-S11 — Concept2 — Concept2 Training — documentação oficial de fabricante — https://www.concept2.com/training — Fonte existente usada apenas para mecânica geral do ergómetro; não foi extrapolada para comandos específicos.
- Limite: A2-S11 — Concept2 — Concept2 Training — documentação oficial de fabricante — https://www.concept2.com/training — Fonte existente usada apenas para mecânica geral do ergómetro; não foi extrapolada para comandos específicos.

### Fonte 4: How to Set Up an Exercise (or Spin) Bike Properly

- Autor ou entidade: EX06-S01 — Hospital for Special Surgery — How to Set Up an Exercise (or Spin) Bike Properly — orientação profissional de instituição clínica — https://www.hss.edu/health-library/move-better/set-up-exercise-bike — Ajuste individual do selim e guiador, ligeira flexão do joelho, coluna neutra, ombros relaxados e sinais de ajuste inadequado.
- Tipo: orientação profissional de instituição clínica
- Localizador: https://www.hss.edu/health-library/move-better/set-up-exercise-bike
- Usada para: EX06-S01 — Hospital for Special Surgery — How to Set Up an Exercise (or Spin) Bike Properly — orientação profissional de instituição clínica — https://www.hss.edu/health-library/move-better/set-up-exercise-bike — Ajuste individual do selim e guiador, ligeira flexão do joelho, coluna neutra, ombros relaxados e sinais de ajuste inadequado.
- Limite: EX06-S01 — Hospital for Special Surgery — How to Set Up an Exercise (or Spin) Bike Properly — orientação profissional de instituição clínica — https://www.hss.edu/health-library/move-better/set-up-exercise-bike — Ajuste individual do selim e guiador, ligeira flexão do joelho, coluna neutra, ombros relaxados e sinais de ajuste inadequado.

### Fonte 5: 97C, 95C Upright Lifecycle Exercise Bike Owner's Manual

- Autor ou entidade: EX06-S02 — Life Fitness — 97C, 95C Upright Lifecycle Exercise Bike Owner's Manual — manual oficial de fabricante — https://kb.cybexintl.com/Owners_Manuals/Bike/OM_LC_95C-ALLxx-xx_97C-ALLxx-xx_M051-00K67-A131_English.pdf — Bloqueio do selim, proibição de ajustar durante a pedalada, ajuste seguro das correias e inspeção de desgaste.
- Tipo: manual oficial de fabricante
- Localizador: https://kb.cybexintl.com/Owners_Manuals/Bike/OM_LC_95C-ALLxx-xx_97C-ALLxx-xx_M051-00K67-A131_English.pdf
- Usada para: EX06-S02 — Life Fitness — 97C, 95C Upright Lifecycle Exercise Bike Owner's Manual — manual oficial de fabricante — https://kb.cybexintl.com/Owners_Manuals/Bike/OM_LC_95C-ALLxx-xx_97C-ALLxx-xx_M051-00K67-A131_English.pdf — Bloqueio do selim, proibição de ajustar durante a pedalada, ajuste seguro das correias e inspeção de desgaste.
- Limite: EX06-S02 — Life Fitness — 97C, 95C Upright Lifecycle Exercise Bike Owner's Manual — manual oficial de fabricante — https://kb.cybexintl.com/Owners_Manuals/Bike/OM_LC_95C-ALLxx-xx_97C-ALLxx-xx_M051-00K67-A131_English.pdf — Bloqueio do selim, proibição de ajustar durante a pedalada, ajuste seguro das correias e inspeção de desgaste.

### Fonte 6: R Series Upright Bike Assembly Manual

- Autor ou entidade: EX06-S03 — Cybex — R Series Upright Bike Assembly Manual — manual oficial de fabricante — https://kb.cybexintl.com/Assembly_Manuals/Bike/Cybex_R_Series/Upright/Cybex_R_Series_Upright_1008126-0001_English.pdf — Verificação do selim por ligeira flexão do joelho, ausência de bloqueio e oscilação, correias e manutenção.
- Tipo: manual oficial de fabricante
- Localizador: https://kb.cybexintl.com/Assembly_Manuals/Bike/Cybex_R_Series/Upright/Cybex_R_Series_Upright_1008126-0001_English.pdf
- Usada para: EX06-S03 — Cybex — R Series Upright Bike Assembly Manual — manual oficial de fabricante — https://kb.cybexintl.com/Assembly_Manuals/Bike/Cybex_R_Series/Upright/Cybex_R_Series_Upright_1008126-0001_English.pdf — Verificação do selim por ligeira flexão do joelho, ausência de bloqueio e oscilação, correias e manutenção.
- Limite: EX06-S03 — Cybex — R Series Upright Bike Assembly Manual — manual oficial de fabricante — https://kb.cybexintl.com/Assembly_Manuals/Bike/Cybex_R_Series/Upright/Cybex_R_Series_Upright_1008126-0001_English.pdf — Verificação do selim por ligeira flexão do joelho, ausência de bloqueio e oscilação, correias e manutenção.

### Fonte 7: IC3 Indoor Cycling Bike Quick Start Manual

- Autor ou entidade: EX06-S04 — Schwinn / Nautilus — IC3 Indoor Cycling Bike Quick Start Manual — manual oficial de fabricante — https://download.bowflex.com/supportdocs/AM_OM/Schwinn/SCH.IC3.QSM.EN.pdf — Base nivelada, cautela ao montar e desmontar e paragem completa antes de sair, qualificada para modelos com volante fixo.
- Tipo: manual oficial de fabricante
- Localizador: https://download.bowflex.com/supportdocs/AM_OM/Schwinn/SCH.IC3.QSM.EN.pdf
- Usada para: EX06-S04 — Schwinn / Nautilus — IC3 Indoor Cycling Bike Quick Start Manual — manual oficial de fabricante — https://download.bowflex.com/supportdocs/AM_OM/Schwinn/SCH.IC3.QSM.EN.pdf — Base nivelada, cautela ao montar e desmontar e paragem completa antes de sair, qualificada para modelos com volante fixo.
- Limite: EX06-S04 — Schwinn / Nautilus — IC3 Indoor Cycling Bike Quick Start Manual — manual oficial de fabricante — https://download.bowflex.com/supportdocs/AM_OM/Schwinn/SCH.IC3.QSM.EN.pdf — Base nivelada, cautela ao montar e desmontar e paragem completa antes de sair, qualificada para modelos com volante fixo.

### Fonte 8: ACSM Certified Personal Trainer Crosswalk

- Autor ou entidade: EX06-S05 — American College of Sports Medicine — ACSM Certified Personal Trainer Crosswalk — documento profissional oficial — https://acsm.org/wp-content/uploads/2025/01/acsm-cpt-crosswalk.pdf — Monitorização da técnica em bicicletas estacionárias e de respostas anormais, incluindo falta de ar, dor articular e tonturas.
- Tipo: documento profissional oficial
- Localizador: https://acsm.org/wp-content/uploads/2025/01/acsm-cpt-crosswalk.pdf
- Usada para: EX06-S05 — American College of Sports Medicine — ACSM Certified Personal Trainer Crosswalk — documento profissional oficial — https://acsm.org/wp-content/uploads/2025/01/acsm-cpt-crosswalk.pdf — Monitorização da técnica em bicicletas estacionárias e de respostas anormais, incluindo falta de ar, dor articular e tonturas.
- Limite: EX06-S05 — American College of Sports Medicine — ACSM Certified Personal Trainer Crosswalk — documento profissional oficial — https://acsm.org/wp-content/uploads/2025/01/acsm-cpt-crosswalk.pdf — Monitorização da técnica em bicicletas estacionárias e de respostas anormais, incluindo falta de ar, dor articular e tonturas.

### Fonte 9: Warning Signs of a Heart Attack

- Autor ou entidade: EX06-S06 — American Heart Association — Warning Signs of a Heart Attack — orientação profissional oficial — https://www.heart.org/en/health-topics/heart-attack/warning-signs-of-a-heart-attack — Apoio conservador para tratar desconforto no peito e falta de ar como sinais que não devem ser ignorados; não usado para diagnóstico.
- Tipo: orientação profissional oficial
- Localizador: https://www.heart.org/en/health-topics/heart-attack/warning-signs-of-a-heart-attack
- Usada para: EX06-S06 — American Heart Association — Warning Signs of a Heart Attack — orientação profissional oficial — https://www.heart.org/en/health-topics/heart-attack/warning-signs-of-a-heart-attack — Apoio conservador para tratar desconforto no peito e falta de ar como sinais que não devem ser ignorados; não usado para diagnóstico.
- Limite: EX06-S06 — American Heart Association — Warning Signs of a Heart Attack — orientação profissional oficial — https://www.heart.org/en/health-topics/heart-attack/warning-signs-of-a-heart-attack — Apoio conservador para tratar desconforto no peito e falta de ar como sinais que não devem ser ignorados; não usado para diagnóstico.
