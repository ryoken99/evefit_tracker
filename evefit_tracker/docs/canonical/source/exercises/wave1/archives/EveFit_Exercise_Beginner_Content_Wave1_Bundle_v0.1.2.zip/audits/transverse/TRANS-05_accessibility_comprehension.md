# TRANS-05 — Acessibilidade e compreensão por principiante absoluto

## Resultado

**Estado global: `failed_with_revisions_required`.**

O conjunto é estruturalmente completo e, na maioria dos exercícios, permite reconhecer preparação, posição, ordem, respiração, sinais de aviso, supervisão e saída. Contudo, dois exercícios apresentam conflitos ou omissões que impedem aprovação:

- `paced_breathing` elimina da explicação pública a via autoescolhida e apresenta apenas a via com sinal externo;
- `standing_multidirectional_weight_shift` não permite perceber de forma inequívoca se roupa/calçado e apoio estável são opcionais ou obrigatórios.

Além destes blockers, há uma ausência integral do teste no Markdown, 13 testes Markdown sem respostas, lacunas de teste em tarefas com supervisão obrigatória, referências corporais ou materiais pouco observáveis, entrada/estabilização insuficientemente explicada em dois equipamentos e densidade cognitiva excessiva em passos nucleares.

## Âmbito e independência

Foram revistos:

- os 49 JSON `*_beginner_content_v0.1.json`;
- os 49 Markdown `*_beginner_content_v0.1.md`;
- as sete auditorias de capacidade `AUD-A` a `AUD-G`.

Não foram consultados outputs de qualquer outro especialista transversal, relatórios transversais ou conclusões coordenadas. TRANS-05 não foi autor dos conteúdos.

A revisão adotou a perspetiva de uma pessoa sem experiência prévia, sem pressupor conhecimento de anatomia, biomecânica, terminologia desportiva ou mecanismos de máquinas. Verificou-se se essa pessoa consegue:

1. identificar equipamento e apoios;
2. preparar o espaço;
3. reconhecer a posição inicial;
4. seguir uma ação de cada vez e pela ordem correta;
5. reconhecer estabilidade e perda de controlo;
6. respirar sem criar uma segunda tarefa desnecessária;
7. reconhecer erros e aplicar correções;
8. distinguir sensação esperada de sinal de aviso;
9. perceber quando é necessária supervisão;
10. terminar ou abandonar a tarefa em segurança;
11. usar as 12 perguntas como verdadeira verificação de compreensão.

Critério de estado:

- `passed`: nenhuma revisão obrigatória de acessibilidade identificada;
- `passed_with_revisions`: utilizável após revisão local, sem blocker;
- `failed`: pelo menos um blocker de compreensão, equipamento, supervisão ou via de execução.

## Findings

### TRANS-05-001 — A via autoescolhida desaparece da respiração ritmada

- **Severidade:** alta
- **Blocker:** sim
- **Exercício:** `paced_breathing`
- **Campo:** `short_description_pt_pt`, `beginner_definition_pt_pt`, `what_you_will_do_pt_pt`, `equipment_setup_pt_pt`, `execution_steps_pt_pt`, `beginner_comprehension_test`; secções Markdown correspondentes
- **Evidência:** o conteúdo público define a tarefa através da escolha e seguimento de um sinal externo. A modalidade de ritmo regular autoescolhido não é explicada, embora a auditoria de capacidade confirme que faz parte da identidade e que a execução sem equipamento é suportada. O teste agrava a omissão: pergunta pelos tipos de sinal, mas não verifica se a pessoa compreendeu que pode executar sem sinal externo. Um principiante fica sem saber que existe uma via sem dispositivo e como a iniciar, manter e terminar.
- **Revisão exigida:** apresentar logo na definição duas vias equivalentes: ritmo regular autoescolhido ou sinal externo opcional. Separar preparação e passos por via, sem introduzir contagem, frequência ou dose. Incluir no teste uma pergunta que verifique a execução sem equipamento.

### TRANS-05-002 — Regras contraditórias sobre equipamento pessoal e apoio

- **Severidade:** alta
- **Blocker:** sim
- **Exercício:** `standing_multidirectional_weight_shift`
- **Campo:** `before_you_start_pt_pt`, `equipment_setup_pt_pt`, `safety_note_pt_pt`, `equipment_safety_pt_pt`; Markdown correspondente
- **Evidência:** a preparação ordena usar roupa que não limite e calçado adequado ao piso; a nota de segurança ordena ter apoio estável ao alcance. Noutros campos, o apoio é explicitamente opcional, e a auditoria de capacidade confirma ausência de requisitos de equipamento pessoal. Um principiante não consegue decidir se pode começar sem apoio, sem calçado ou sem vestuário específico, nem distinguir recomendação condicional de requisito.
- **Revisão exigida:** usar uma única regra em todos os campos. Tornar roupa e calçado condicionais — “se usares” — e declarar que o apoio é opcional, devendo ser preparado apenas quando previsto como necessário. Repetir literalmente esta distinção no teste.

### TRANS-05-003 — O Markdown omite integralmente o teste de compreensão

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `half_kneeling_ankle_dorsiflexion_rock`
- **Campo:** `beginner_comprehension_test`; Markdown público
- **Evidência:** o JSON contém 12 pares pergunta/resposta. O Markdown termina sem secção de compreensão e sem qualquer uma das 12 perguntas. A pessoa que recebe apenas a versão pública não consegue confirmar apoio integral do pé, direção do joelho, compensações, sinais de paragem, equipamento ou supervisão.
- **Revisão exigida:** publicar no Markdown as 12 perguntas e respostas já existentes no JSON, mantendo ordem e significado.

### TRANS-05-004 — Treze testes Markdown não permitem autocorreção

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** `basketball_set_shot_to_basket`, `boxing_jab_cross_to_focus_mitts`, `countermovement_jump`, `diaphragmatic_breathing`, `full_body_elliptical`, `lateral_leg_swing`, `standing_gastrocnemius_wall_stretch`, `standing_soleus_wall_stretch`, `treadmill_walking`, `two_foot_rope_skipping`, `two_point_sprint_start`, `upright_stationary_cycling`, `volleyball_forearm_pass_to_target`
- **Campo:** `beginner_comprehension_test`; secção Markdown de teste/verificação/perguntas de compreensão
- **Evidência:** cada JSON contém 12 respostas esperadas, mas os 13 Markdown publicam apenas as perguntas. O problema não é a quantidade formal de perguntas: sem gabarito, um principiante pode consolidar uma resposta errada sobre equipamento, estabilidade, respiração, interrupção ou saída. A omissão é seletiva; outros Markdown do mesmo pacote apresentam resposta em linha ou uma chave de respostas.
- **Revisão exigida:** incluir as respostas esperadas já existentes no JSON, em linha ou num gabarito claramente associado. Normalizar a mesma convenção nos 49 Markdown.

### TRANS-05-005 — Os 12 itens não cobrem saídas e supervisão críticas

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** `archery_shot_cycle_to_target`, `boxing_jab_cross_to_focus_mitts`
- **Campo:** `beginner_comprehension_test`
- **Evidência:** no tiro com arco, o teste verifica a interrupção durante a puxada e a necessidade de supervisão, mas não verifica a sequência normal de fim: confirmar ausência de flecha colocada, recuar, aguardar comando de recuperação e só então aproximar-se do alvo. No boxe, os 12 itens não verificam a supervisão obrigatória nem a saída rotineira do par de manoplas, apesar de ambos serem requisitos centrais. Perguntar se existe parceiro não equivale a confirmar supervisão.
- **Revisão exigida:** reservar pelo menos um item para a saída normal em ambas as tarefas e, no boxe, um item inequívoco para supervisão obrigatória. Se o limite continuar a ser 12, substituir perguntas redundantes ou de menor risco, sem remover a verificação de emergência.

### TRANS-05-006 — Referências nucleares não são reconhecíveis sem demonstração

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** `seated_supported_thoracic_extension`, `supine_hamstring_strap_stretch`, `football_directional_first_touch`
- **Campo:** posição inicial, equipamento, passos, pistas principais e teste de compreensão
- **Evidência:**
  - `seated_supported_thoracic_extension` localiza o “fulcro” na “região média ou superior das costas, abaixo do pescoço e acima da região lombar”. Isto repete zonas anatómicas amplas, mas não fornece uma verificação observável para distinguir colocação torácica de colocação cervical ou lombar;
  - `supine_hamstring_strap_stretch` repete “zona estável do pé”, excluindo os dedos, mas não permite reconhecer visual ou tatilmente a zona permitida;
  - `football_directional_first_touch` pede “uma superfície ampla e controlável do pé recetor” sem exemplo introdutório nem critério simples de tornozelo estável.
- **Revisão exigida:** acrescentar uma referência leiga e uma verificação antes do movimento. Quando não for defensável universalizar uma localização, declarar que a colocação ou superfície deve ser demonstrada e confirmada antes da primeira execução. No futebol, dar um exemplo introdutório não universal, como o interior do pé numa direção simples.

### TRANS-05-007 — Entrada e estabilização de equipamento não chegam ao nível operacional

- **Severidade:** alta
- **Blocker:** não
- **Exercícios:** `stationary_arm_crank_ergometry`, `upright_stationary_cycling`
- **Campo:** `before_you_start_pt_pt`, `starting_position_pt_pt`, `execution_steps_pt_pt`, `equipment_safety_pt_pt`, `ending_the_exercise_pt_pt`
- **Evidência:** a manivela de braços autoriza uma cadeira de rodas “devidamente estabilizada”, mas a verificação limita-se a dizer que deve estar “estável”; não explica travões, imobilidade testada, compatibilidade de posicionamento nem saída. Na bicicleta vertical, o passo de entrada é “Monta com cuidado, senta-te ao centro do selim e fixa cada pé”, reunindo transferência, estabilização e fixação sem identificar ponto fixo de apoio nem ordem segura. A desmontagem é mais concreta, revelando assimetria de detalhe.
- **Revisão exigida:** para a manivela, remover a configuração específica ou explicar uma verificação dependente do manual/profissional: travões aplicados e testados, cadeira imóvel, posição compatível e saída disponível. Para a bicicleta, separar: máquina imóvel; apoio apenas num ponto fixo indicado pelo fabricante; entrada controlada; estabilidade no selim; colocação dos pés; confirmação final.

### TRANS-05-008 — Passos nucleares acumulam várias decisões na mesma instrução

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** `archery_shot_cycle_to_target`, `bilateral_pogo_jump`, `boxing_jab_cross_to_focus_mitts`, `manual_wheelchair_propulsion_overground`, `respiratory_sensation_observation`
- **Campo:** `execution_steps_pt_pt`
- **Evidência:** existem 10 instruções com pelo menos 32 palavras nestes cinco exercícios: duas no tiro com arco, uma no pogo, uma no boxe, cinco na cadeira de rodas e uma na observação respiratória. Os casos mais densos são os passos 4 e 5 da cadeira de rodas, com 50 e 46 palavras. O passo 5 combina olhar, propulsão frontal, duas estratégias alternativas de curva e prontidão das mãos; o passo 4 combina largar, recuperar as mãos, escolher uma trajetória e uma exceção dependente da pessoa. Esta densidade obriga a memorizar ação, exceção e correção enquanto a pessoa se move.
- **Revisão exigida:** aplicar “uma ação principal + uma verificação” por passo. Colocar alternativas — curva, recuo, falha, contacto seguinte, foco interno — em subpassos condicionais separados. Manter a ordem física real e não aumentar o número de conceitos apresentados de uma só vez.

### TRANS-05-009 — “Organizado” funciona como pista não observável

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** `active_ankle_dorsiflexion_plantarflexion`, `archery_shot_cycle_to_target`, `basketball_set_shot_to_basket`, `bilateral_pogo_jump`, `countermovement_jump`, `doorway_pectoral_stretch`, `front_to_back_leg_swing`, `half_kneeling_ankle_dorsiflexion_rock`, `linear_sprint`, `overground_running`, `plyometric_push_up`, `seated_butterfly_adductor_stretch`, `seated_single_leg_hamstring_stretch`, `sled_resisted_sprint`, `sprint_to_controlled_stop`, `standing_broad_jump`, `standing_gastrocnemius_wall_stretch`, `standing_medicine_ball_chest_pass`, `standing_soleus_wall_stretch`, `supine_hamstring_strap_stretch`, `tandem_stance`, `two_foot_rope_skipping`, `two_point_sprint_start`, `upright_stationary_cycling`
- **Campo:** posição inicial, passos, pistas, erros ou saída
- **Evidência:** 24/49 exercícios usam “organizado/organizada/organiza” em pelo menos um campo operacional nuclear. Exemplos incluem “tronco organizado”, “posição organizada”, “ação organizada do corpo” e “reorganiza os apoios”. Sem um critério ligado a pés, joelhos, bacia, tronco ou direção, o termo descreve a avaliação do autor, não algo que um principiante consiga ver ou sentir.
- **Revisão exigida:** substituir cada ocorrência nuclear por um critério observável específico, por exemplo: pés mantêm contacto, joelho aponta na direção dos dedos, bacia não roda, tronco não inclina lateralmente, ou corpo está imóvel antes de sair. Remover ocorrências que apenas repetem uma verificação já presente.

### TRANS-05-010 — Jargão, referente e gramática exigem releitura

- **Severidade:** baixa
- **Blocker:** não
- **Exercícios:** `active_ankle_dorsiflexion_plantarflexion`, `supine_self_assisted_hamstring_stretch`, `boxing_jab_cross_to_focus_mitts`, `diaphragmatic_breathing`, `basketball_set_shot_to_basket`, `volleyball_forearm_pass_to_target`
- **Campo:** posição inicial, passos, equipamento, supervisão e prosa Markdown
- **Evidência:** “pé/perna contralateral” é usado sem a equivalência imediata “do lado oposto”; “palmas das manoplas viradas para ele” tem referente ambíguo; “Passa diretamente para a inspiração seguinte quando o corpo a iniciar” exige analisar pronome e tempo verbal; `spotter`, `cue/cues` e “Os média permanecem por aprovar” aparecem em prosa dirigida ao utilizador. IDs canónicos em inglês não justificam anglicismos não explicados nas instruções.
- **Revisão exigida:** usar “do lado oposto” na primeira ocorrência; substituir o pronome por “viradas para o praticante”; escrever “quando sentires o início natural da inspiração seguinte”; usar “assistente de segurança (spotter)” na primeira ocorrência, “pista/indicação técnica” e “conteúdos multimédia”.

### TRANS-05-011 — Sincronização respiratória acrescenta uma segunda tarefa evitável

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `seated_supported_thoracic_extension`
- **Campo:** `breathing_guidance_pt_pt`, passo/fase respiratória e Markdown correspondente
- **Evidência:** o conteúdo pede expiração durante a inclinação para trás e inspiração no regresso. A auditoria de capacidade confirma que o próprio relatório não encontrou suporte específico para esta sincronização e recomenda respiração natural, regular e contínua. Para um principiante que já precisa de localizar o fulcro, manter pés e bacia, apoiar a cabeça sem puxar e limitar o arco, a associação de fases respiratórias acrescenta carga de memória e pode ser interpretada como requisito de execução.
- **Revisão exigida:** manter apenas respiração natural, regular e contínua, sem retenção. Se uma sincronização vier a ser sustentada e mantida, apresentá-la como opção e não como condição de correção.

## Padrões transversais

### Estrutura geralmente acessível

- Os 49 JSON incluem preparação de equipamento e ambiente, posição inicial, passos, respiração, sensações esperadas, sinais de aviso, erros com reconhecimento e correção, supervisão e finalização.
- Todos têm entre 6 e 11 passos e entre 5 e 8 erros comuns completos.
- A maioria separa corretamente sensação tolerável de dor, tontura, confusão, falta de ar atípica, perda de controlo ou sintomas neurológicos.
- As saídas de falha são geralmente específicas: regressar a dois apoios, alargar a base, baixar os joelhos, continuar pela zona de travagem ou voltar à respiração espontânea.
- A supervisão é geralmente expressa como obrigatória, recomendada ou não necessária por definição, com gatilhos adicionais.

### Fragilidades recorrentes

- A presença formal de um campo não garante execução por principiante: “estável”, “organizado”, “controlável” e referências anatómicas amplas precisam de critérios observáveis.
- A paridade JSON/Markdown é fraca no teste de compreensão: há uma omissão integral e 13 omissões de respostas.
- Alguns testes gastam itens com fronteiras ontológicas, dose ou promessas, mas não verificam uma saída ou supervisão crítica.
- Equipamento complexo exige uma sequência de entrada, bloqueio, teste de imobilidade, uso e saída; “com cuidado” ou “devidamente estabilizada” não substituem essa sequência.
- Instruções longas acumulam ações, exceções e contingências. A correção editorial deve reduzir carga de memória, não apenas encurtar frases.
- Orientação respiratória específica deve ser eliminada quando não é necessária à identidade, para não criar uma dupla tarefa.

## Estado por exercício afetado

### `failed`

| Exercício | Findings | Motivo |
|---|---|---|
| `paced_breathing` | TRANS-05-001 | Via autoescolhida e execução sem equipamento ausentes. |
| `standing_multidirectional_weight_shift` | TRANS-05-002 | Regras contraditórias sobre equipamento pessoal e apoio opcional. |

### `passed_with_revisions`

| Exercício | Findings |
|---|---|
| `active_ankle_dorsiflexion_plantarflexion` | TRANS-05-009, TRANS-05-010 |
| `archery_shot_cycle_to_target` | TRANS-05-005, TRANS-05-008, TRANS-05-009 |
| `basketball_set_shot_to_basket` | TRANS-05-004, TRANS-05-009, TRANS-05-010 |
| `bilateral_pogo_jump` | TRANS-05-008, TRANS-05-009 |
| `boxing_jab_cross_to_focus_mitts` | TRANS-05-004, TRANS-05-005, TRANS-05-008, TRANS-05-010 |
| `countermovement_jump` | TRANS-05-004, TRANS-05-009 |
| `diaphragmatic_breathing` | TRANS-05-004, TRANS-05-010 |
| `doorway_pectoral_stretch` | TRANS-05-009 |
| `football_directional_first_touch` | TRANS-05-006 |
| `front_to_back_leg_swing` | TRANS-05-009 |
| `full_body_elliptical` | TRANS-05-004 |
| `half_kneeling_ankle_dorsiflexion_rock` | TRANS-05-003, TRANS-05-009 |
| `lateral_leg_swing` | TRANS-05-004 |
| `linear_sprint` | TRANS-05-009 |
| `manual_wheelchair_propulsion_overground` | TRANS-05-008 |
| `overground_running` | TRANS-05-009 |
| `plyometric_push_up` | TRANS-05-009 |
| `respiratory_sensation_observation` | TRANS-05-008 |
| `seated_butterfly_adductor_stretch` | TRANS-05-009 |
| `seated_single_leg_hamstring_stretch` | TRANS-05-009 |
| `seated_supported_thoracic_extension` | TRANS-05-006, TRANS-05-011 |
| `sled_resisted_sprint` | TRANS-05-009 |
| `sprint_to_controlled_stop` | TRANS-05-009 |
| `standing_broad_jump` | TRANS-05-009 |
| `standing_gastrocnemius_wall_stretch` | TRANS-05-004, TRANS-05-009 |
| `standing_medicine_ball_chest_pass` | TRANS-05-009 |
| `standing_soleus_wall_stretch` | TRANS-05-004, TRANS-05-009 |
| `stationary_arm_crank_ergometry` | TRANS-05-007 |
| `supine_hamstring_strap_stretch` | TRANS-05-006, TRANS-05-009 |
| `supine_self_assisted_hamstring_stretch` | TRANS-05-010 |
| `tandem_stance` | TRANS-05-009 |
| `treadmill_walking` | TRANS-05-004 |
| `two_foot_rope_skipping` | TRANS-05-004, TRANS-05-009 |
| `two_point_sprint_start` | TRANS-05-004, TRANS-05-009 |
| `upright_stationary_cycling` | TRANS-05-004, TRANS-05-007, TRANS-05-009 |
| `volleyball_forearm_pass_to_target` | TRANS-05-004, TRANS-05-010 |

Não foi atribuído estado negativo, nesta dimensão, aos 11 exercícios sem finding TRANS-05: `active_ankle_circumduction`, `clockwise_four_quadrant_step_sequence`, `continuous_stair_ascent`, `lateral_costal_breathing`, `march_in_place_to_external_beat`, `marching_in_place`, `overground_walking`, `single_leg_stance`, `static_rowing_ergometer`, `supine_heel_slide` e `tandem_walk`.

## Contagens

| Métrica | Contagem |
|---|---:|
| Exercícios auditados | 49 |
| Pares JSON/Markdown auditados | 49 |
| Artefactos de conteúdo auditados | 98 |
| Auditorias de capacidade lidas | 7 |
| Perguntas estruturadas nos JSON | 588 |
| Markdown sem qualquer teste | 1 |
| Markdown com 12 perguntas mas sem respostas | 13 |
| Passos com pelo menos 32 palavras no finding de densidade | 10 |
| Exercícios com “organizado/a” em campo operacional nuclear | 24 |
| Findings | 11 |
| Findings de severidade alta | 3 |
| Findings de severidade média | 7 |
| Findings de severidade baixa | 1 |
| Findings blocker | 2 |
| Exercícios `failed` | 2 |
| Exercícios `passed_with_revisions` | 36 |
| Exercícios sem finding TRANS-05 | 11 |

Os dois blockers são explícitos e não estão diluídos na contagem de revisões editoriais. A ausência de respostas nos Markdown não foi contada como 13 findings separados; é um único padrão editorial com 13 afetados. De igual modo, as 24 ocorrências do cue não observável foram agrupadas num finding transversal.

## Declaração de zero implementação

Esta auditoria é exclusivamente diagnóstica. Nenhum JSON, Markdown de exercício, relatório de investigação, pacote canónico, relação, risco, equipamento, regra, código, configuração, multimédia ou conteúdo de produto foi alterado. Não foram implementadas correções, publicações ou aprovações.

**Implementação realizada por TRANS-05: zero.**
