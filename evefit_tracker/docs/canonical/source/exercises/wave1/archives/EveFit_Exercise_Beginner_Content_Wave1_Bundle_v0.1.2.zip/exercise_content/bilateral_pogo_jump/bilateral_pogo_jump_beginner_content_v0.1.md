# Saltos reativos curtos bipodais

Conteúdo para principiantes em português europeu.

## Descrição curta

Saltos verticais pequenos e sucessivos em que os dois pés recebem o solo ao mesmo tempo e cada contacto alimenta a impulsão seguinte, sobretudo pela ação dos tornozelos.

## O que é

É um padrão reativo bipodal de pequena amplitude. Em vez de parar depois de cada salto, ligas uma receção curta e controlada a uma nova impulsão vertical. A rapidez da inversão entre descer e subir distingue este exercício de um salto isolado.

## O que vais fazer

Partirás de pé, sairás do solo com os dois pés, voltarás a contactar o chão com ambos em simultâneo e usarás esse contacto para iniciar o salto seguinte. A sequência mantém-se vertical e termina numa aterragem separada, estável e controlada.

## Porque existe este movimento

O propósito técnico imediato é praticar a ligação rápida entre contacto, absorção e nova propulsão. Esta explicação descreve o padrão; não promete um resultado individual e não define uma dose.

## Antes de começares

1. Não uses esta explicação como autorização para prática autónoma no primeiro dia: a primeira exposição técnica deve ser observada por um profissional de exercício ou treinador qualificado.
2. Confirma que compreendes como interromper a tarefa e que já consegues demonstrar uma aterragem bipodal básica estável sob observação.
3. Não inicies se houver dor aguda, mal-estar, tonturas, falta de ar fora do habitual, perda súbita de coordenação ou incapacidade de controlar uma receção.
4. Se estás grávida ou no pós-parto, tens doença crónica relevante, regressas após lesão ou inatividade clínica, ou tens indicação profissional prévia, pede revisão individual antes de experimentar.
5. Escolhe apenas uma área pequena mas totalmente livre, com altura desimpedida e sem circulação de pessoas, animais ou objetos.

## Preparar o equipamento

1. Não é necessário equipamento. Retira do chão cabos, tapetes soltos, marcadores, pesos e outros objetos. Calçado e vestuário, quando usados, devem estar seguros, bem ajustados e não limitar a observação ou o movimento; nenhum acessório transforma uma superfície inadequada numa superfície segura.

## Preparar o espaço

1. Usa uma superfície firme, plana, regular, seca e antiderrapante, com boa visibilidade, espaço acima da cabeça e zona de aterragem livre. Não uses superfícies escorregadias, instáveis, inclinadas, irregulares ou com trânsito, cruzamento público ou pessoas a passar.

## Verificação do corpo

1. Consegues permanecer de pé com peso distribuído pelos dois pés sem desequilíbrio evidente.
2. Consegues fazer uma pequena flexão de tornozelos, joelhos e ancas e voltar à posição de pé com os pés e joelhos alinhados.
3. Consegues sair ligeiramente do solo e terminar uma aterragem bipodal isolada sem passo extra, dor ou queda do tronco.
4. Consegues respirar de forma natural e contínua enquanto te moves.
5. Se algum destes controlos falhar, não avances para contactos reativos sucessivos; pede avaliação técnica.

## Posição inicial

Fica de pé no centro da área livre, com os pés paralelos e afastados de forma confortável, peso repartido pelos dois lados, joelhos desbloqueados, tronco alto e olhar em frente. Mantém os braços numa posição natural que não desorganize o equilíbrio.

## Confirmar a posição inicial

1. Os dois pés estão totalmente dentro da zona segura.
2. Pés, joelhos e ancas apontam na mesma direção geral.
3. Os joelhos estão desbloqueados, sem agachamento profundo.
4. O tronco está alto e a cabeça não procura o chão.
5. Há espaço livre à frente, atrás, aos lados e por cima.
6. A respiração está livre, sem retenção deliberada.

## Passos de execução

1. Organiza a posição inicial e confirma novamente que a zona de contacto está firme, seca e desimpedida.
2. Faz uma pequena preparação elástica nos tornozelos, com joelhos e ancas apenas desbloqueados, mantendo o tronco alto e o peso igualmente repartido.
3. Empurra o chão com os dois pés ao mesmo tempo e deixa o corpo subir numa trajetória curta e vertical; não procures distância nem altura máxima.
4. Durante a fase aérea, mantém os pés preparados para regressar juntos à mesma zona, sem os cruzar nem puxar os joelhos para cima.
5. Contacta o solo com os dois pés em simultâneo, sobretudo pela parte anterior e média do pé, permitindo uma pequena ação controlada dos tornozelos e sem deixar os calcanhares bater ou colapsar.
6. Mantém pés, joelhos e ancas alinhados enquanto a pequena absorção nos tornozelos e joelhos muda de imediato para nova propulsão.
7. Conclui o ciclo descrito e regressa a uma posição estável; a ficha não define número de repetições nem duração.
8. Para terminar, deixa de procurar a nova impulsão, aceita uma flexão confortável dos tornozelos, joelhos e ancas e estabiliza sobre os dois pés antes de saíres da área.

## Fases do movimento

### Apoio bipodal organizado, articulações desbloqueadas e tronco controlado.

Apoio bipodal organizado, articulações desbloqueadas e tronco controlado.

### Extensão rápida, predominantemente pelo tornozelo, que desloca o corpo verticalmente.

Extensão rápida, predominantemente pelo tornozelo, que desloca o corpo verticalmente.

### Os dois pés deixam o solo e regressam juntos à mesma zona.

Os dois pés deixam o solo e regressam juntos à mesma zona.

### Uma receção curta absorve a carga e liga-se imediatamente à nova propulsão, sem pausa nem colapso.

Uma receção curta absorve a carga e liga-se imediatamente à nova propulsão, sem pausa nem colapso.

### O último contacto deixa de alimentar outro salto e transforma-se numa aterragem bipodal estabilizada.

O último contacto deixa de alimentar outro salto e transforma-se numa aterragem bipodal estabilizada.

## Respiração

Respira de forma natural, contínua e ritmada ao longo da sequência. Não existe uma fase respiratória obrigatória para cada contacto e não deves prender deliberadamente a respiração nem fazer esforço em apneia. Se a respiração se tornar descontrolada ou surgir falta de ar fora do habitual, termina e estabiliza.

## Sensações esperadas

1. Sensação elástica e rápida nos tornozelos e gémeos durante a inversão entre contacto e impulsão.
2. Trabalho distribuído pelos dois membros inferiores.
3. Pequeno movimento vertical repetido e contacto breve com o solo.
4. Aumento transitório da respiração compatível com movimento vigoroso, mas sem necessidade de a prender.

## Sensações inesperadas ou de alerta

1. Dor aguda ou localizada no pé, tornozelo, tendão de Aquiles, perna, joelho, anca ou coluna.
2. Sensação de falha, falseio, estalido acompanhado de dor ou incapacidade de sustentar o apoio.
3. Tonturas, visão alterada, dor no peito, mal-estar ou falta de ar fora do habitual.
4. Formigueiro, dormência, perda súbita de força ou de coordenação.
5. Impactos progressivamente mais duros, assimetria evidente ou incapacidade de travar na aterragem final.

## Indicações técnicas principais

1. Sobe pouco e na vertical.
2. Dois pés saem e chegam juntos.
3. Contacto curto, mas sempre controlado.
4. Tornozelos ativos; joelhos desbloqueados e alinhados.
5. Tronco alto e peso repartido pelos dois lados.
6. Respira sem prender.
7. Termina antes de a técnica se desfazer.

## Erros comuns e correções

### Erro 1: Procurar demasiada altura.

- Como reconhecer: Os joelhos sobem muito, a fase aérea alonga-se e a aterragem fica pesada ou exige agachamento profundo.
- Como corrigir: Volta a pensar num salto pequeno e vertical. Se não consegues reduzir a amplitude sob controlo, termina a sequência.

### Erro 2: Transformar o contacto numa pausa.

- Como reconhecer: O corpo fica tempo excessivo no chão, afunda-se ou precisa de uma preparação nova antes de cada salto.
- Como corrigir: Mantém a amplitude pequena e procura uma inversão fluida. Não tentes acelerar à custa do alinhamento.

### Erro 3: Deixar os calcanhares colapsar ou bater sem controlo.

- Como reconhecer: O contacto torna-se ruidoso, o tornozelo cede e o corpo perde a sensação de mola.
- Como corrigir: Reduz a amplitude e mantém o tornozelo ativo, permitindo apenas a descida que consegues travar. Termina se o controlo não regressar.

### Erro 4: Deixar os joelhos cair para dentro ou os pés rodar.

- Como reconhecer: Visto de frente, os joelhos aproximam-se entre si ou deixam de acompanhar a direção dos pés.
- Como corrigir: Interrompe, reorganiza os pés paralelos e pratica primeiro uma receção bipodal isolada sob observação.

### Erro 5: Deslocar-se para a frente, para trás ou para o lado.

- Como reconhecer: Cada aterragem ocorre numa zona diferente ou é necessário dar um passo para recuperar.
- Como corrigir: Reduz a amplitude, mantém o olhar em frente e aponta a impulsão para cima. Se continuas a derivar, termina.

### Erro 6: Favorecer um dos lados.

- Como reconhecer: Um pé toca primeiro, um membro absorve mais ou o tronco inclina repetidamente para o mesmo lado.
- Como corrigir: Não compenses aumentando o esforço. Para e pede observação técnica antes de repetires.

### Erro 7: Continuar depois de os contactos se degradarem.

- Como reconhecer: Aumentam o ruído, o tempo no chão, a assimetria, a altura involuntária ou a perda de alinhamento.
- Como corrigir: Usa a primeira alteração técnica como sinal de saída e estabiliza a aterragem final.

## Formas de simplificar ou ensaiar

1. Ensaiar apenas a posição inicial e a saída final, sem sequência reativa.
2. Praticar uma aterragem bipodal isolada e estabilizada sob observação profissional antes de ligar contactos.
3. Ensaiar a pequena ação de tornozelo sem fase aérea, elevando e baixando os calcanhares com apoio bipodal.
4. Usar uma demonstração e feedback externo de um profissional, sem acrescentar equipamento, altura, velocidade ou deslocamento.

## Supervisão

A supervisão é recomendada e torna-se particularmente importante na primeira exposição técnica, perante inexperiência, dificuldade em demonstrar uma aterragem bipodal estável, regresso funcional ou qualquer alteração relevante da condição. Um profissional de exercício ou treinador qualificado deve observar de frente e de lado, sem ficar na zona de aterragem, e verificar simultaneidade dos contactos, alinhamento, trajetória vertical, controlo da saída e sinais de fadiga. Explicar claramente o movimento não autoriza prática autónoma no primeiro dia.

## Como terminar

Decide parar enquanto ainda tens controlo. No contacto seguinte, não voltes a impulsionar: deixa os tornozelos, joelhos e ancas fletirem de forma confortável, mantém os joelhos na direção dos pés e estabiliza sobre os dois apoios. Só depois relaxa ou sai da zona. Não tentes travar com pernas completamente rígidas nem com um passo brusco.

## Nota de segurança

É um exercício de risco operacional elevado, com fase aérea, impacto e contactos repetidos. Interrompe perante dor, mal-estar, perda de alinhamento, assimetria, contacto descontrolado ou incapacidade de concluir uma aterragem estável. A descrição não substitui avaliação individual, ensino técnico presencial nem revisão clínica quando aplicável.

## Quando parar ou reduzir

1. Dor aguda ou dor que aumenta durante os contactos.
2. Mal-estar, tonturas, visão alterada, dor no peito ou falta de ar fora do habitual.
3. Perda súbita de coordenação, força, equilíbrio ou orientação.
4. Incapacidade de controlar a travagem ou a receção final.
5. Joelhos a colapsar, um pé a chegar antes do outro ou peso claramente desviado para um lado.
6. Contactos cada vez mais ruidosos, demorados ou altos sem intenção.
7. Deriva para fora da zona segura ou necessidade de passos de recuperação.

## Segurança do equipamento

Sem equipamento obrigatório. Não introduzas caixas, barreiras, pesos, bandas, cordas ou superfícies instáveis: esses elementos podem alterar a tarefa, o risco ou a identidade. Mantém calçado e atacadores seguros se optares por usar calçado e retira qualquer objeto solto da zona.

## Segurança do espaço

Executa apenas numa superfície firme, plana, regular, seca e antiderrapante, com iluminação suficiente e área de aterragem livre. Interrompe se a superfície ficar húmida, escorregadia, instável, danificada ou invadida por terceiros. Evita calor ou frio que prejudiquem o controlo, pouca luz, trânsito, cruzamentos públicos e altura livre insuficiente.

## Limitações

1. Não foi identificada uma norma experimental específica que valide uma técnica única deste exercício para principiantes absolutos. A literatura direta inclui amostras pequenas e treinadas, e as fontes de segurança abrangem a família pliométrica. Por isso, o conteúdo não define dose, não autoriza prática autónoma no primeiro dia, não aprova multimédia, não altera equipamento, superfície, risco, identidade ou relação e não substitui avaliação individual.

## Teste de compreensão

### 1. O que distingue estes saltos de uma sucessão de saltos isolados?

Resposta esperada: Cada receção curta liga-se imediatamente à propulsão seguinte, sem pausa.

### 2. Os saltos devem procurar altura máxima?

Resposta esperada: Não. A trajetória é curta e vertical; aumentar a altura pode degradar o contacto.

### 3. Como devem sair e chegar os pés?

Resposta esperada: Os dois pés saem e contactam o solo em simultâneo, com peso repartido.

### 4. Que alinhamento deve ser observado na receção?

Resposta esperada: Pés, joelhos e ancas mantêm a mesma direção geral, sem os joelhos colapsarem para dentro.

### 5. O que significa contacto curto neste exercício?

Resposta esperada: Uma inversão rápida e controlada entre receção e nova propulsão, não pressa sem controlo.

### 6. Como deves respirar?

Resposta esperada: De forma natural, contínua e ritmada, sem prender deliberadamente a respiração.

### 7. Que superfície é adequada?

Resposta esperada: Uma superfície firme, plana, regular, seca e antiderrapante, numa zona livre.

### 8. O exercício requer equipamento?

Resposta esperada: Não. Não existe equipamento obrigatório e não se devem acrescentar obstáculos, cargas ou superfícies instáveis.

### 9. Qual é um sinal técnico para terminar?

Resposta esperada: Assimetria, perda de alinhamento, deriva, contactos cada vez mais ruidosos ou incapacidade de travar.

### 10. Como terminas a sequência?

Resposta esperada: Deixas de voltar a impulsionar, absorves o último contacto com os dois pés e estabilizas antes de sair.

### 11. Ler esta explicação autoriza prática autónoma no primeiro dia?

Resposta esperada: Não. A primeira exposição técnica deve ser observada por um profissional de exercício ou treinador qualificado.

### 12. O que fazes perante dor aguda, mal-estar ou perda súbita de coordenação?

Resposta esperada: Interrompes imediatamente, estabilizas se for seguro e procuras assistência adequada ao contexto.

## Fontes e limites da evidência

### Fonte 1: NSA Round Table No. 5 — Plyometrics

- Autor ou entidade: World Athletics; Frank Dick, Jim Alford, José Ballesteros, Vern Gambetta e Victor Lopez
- Tipo: mesa-redonda técnica de federação oficial
- Localizador: https://worldathletics.org/download/downloadnsa?filename=2d59925f-f1bf-49d8-adc0-e305fd16f9bc.pdf&urlslug=nsa-round-table-no-5-plyometrics
- Usada para: Reconhece os saltos bipodais como família pliométrica e assinala a necessidade de cautela com praticantes inexperientes.
- Limite: Documento histórico e de consenso técnico; não é um ensaio sobre principiantes absolutos nem valida uma dose.

### Fonte 2: Current Concepts of Plyometric Exercise

- Autor ou entidade: George J. Davies, Bryan L. Riemann e Robert Manske
- Tipo: comentário clínico e revisão científica por pares
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC4637913/
- Usada para: Sustenta as fases do ciclo alongamento–encurtamento, a transição rápida, os pré-requisitos, a progressão técnica e a interrupção quando a fadiga degrada a qualidade.
- Limite: Evidência sobretudo ao nível da família pliométrica e de contextos clínico-desportivos; não demonstra segurança universal para este exercício.

### Fonte 3: Basics of Strength and Conditioning Manual

- Autor ou entidade: National Strength and Conditioning Association
- Tipo: manual técnico-profissional
- Localizador: https://www.nsca.com/contentassets/48a12160221541acbdc048498d77192d/basics_of_strength_and_conditioning_manual.pdf
- Usada para: Orienta alinhamento frontal, receção com ação coordenada de tornozelo, joelho e anca, aterragem controlada e aprendizagem progressiva de novas tarefas.
- Limite: As instruções de aterragem abrangem saltos em geral e exigem adaptação cuidadosa ao contacto reativo curto, sem converter o pogo num salto com agachamento profundo.

### Fonte 4: Leg and Joint Stiffness in Human Hopping

- Autor ou entidade: Sami Kuitunen, Kazuhiko Ogiso e Paavo V. Komi
- Tipo: estudo biomecânico primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/22126723/
- Usada para: Em saltos bipodais com contacto curto, documenta o papel da rigidez do tornozelo e a contribuição do joelho para regular a altura.
- Limite: Amostra pequena de adultos jovens do sexo masculino; descreve mecanismos e não estabelece instruções universais para principiantes.

### Fonte 5: Impact Forces of Plyometric Exercises Performed on Land and in Water

- Autor ou entidade: Orna A. Donoghue, Hirofumi Shimojo e Hideki Takagi
- Tipo: estudo cruzado biomecânico primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/23016022/
- Usada para: Mediu forças de aterragem em saltos de tornozelo e confirma que a tarefa em terra envolve impacto relevante.
- Limite: Participantes eram nadadores universitários do sexo masculino; a comparação com água não autoriza alterar a superfície canónica nem extrapolar valores para principiantes.

### Fonte 6: Exercise for the Prevention and Treatment of Hypertension — Implications and Application

- Autor ou entidade: American College of Sports Medicine; Amanda Zaleski
- Tipo: orientação profissional oficial
- Localizador: https://acsm.org/exercise-for-the-prevention-and-treatment-of-hypertension/
- Usada para: Apoia a orientação conservadora de evitar retenção deliberada da respiração durante esforço e de considerar triagem quando existem condições relevantes.
- Limite: O texto centra-se em hipertensão e treino resistido; não prescreve um padrão respiratório específico para saltos reativos.

### Fonte 7: Effect of Breathing Techniques on Blood Pressure Response to Resistance Exercise

- Autor ou entidade: S. T. Linsenbardt, T. K. Thomas e R. W. Madsen
- Tipo: estudo experimental primário
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC1478931/
- Usada para: Comparou estratégias respiratórias e observou respostas pressóricas superiores com manobra de Valsalva, apoiando a indicação de respirar continuamente sem apneia deliberada.
- Limite: Estudou exercícios resistidos, não saltos; sustenta apenas a cautela respiratória geral.
