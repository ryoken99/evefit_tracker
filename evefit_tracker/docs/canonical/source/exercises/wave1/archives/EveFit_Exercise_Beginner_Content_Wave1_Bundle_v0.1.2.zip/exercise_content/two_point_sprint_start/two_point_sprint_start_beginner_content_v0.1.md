# Arranque de sprint de dois apoios

Conteúdo para principiantes em português europeu.

## Descrição curta

Partida em pé com os pés desencontrados, limitada à projeção inicial e aos primeiros apoios de aceleração.

## O que é

É um exercício técnico de partida: começas em pé, com os dois pés no chão e um pé à frente do outro, projetas o corpo para a frente e organizas apenas os primeiros apoios de aceleração. O exercício termina antes de se transformar num sprint contínuo.

## O que vais fazer

Vais preparar uma posição estável de dois apoios, iniciar o movimento sem um passo de balanço, coordenar braços e pernas em oposição e deixar o tronco subir gradualmente durante os primeiros apoios. Depois, sais da tarefa reduzindo a velocidade de forma progressiva numa zona livre.

## Porque existe este movimento

Este exercício existe para tornar observáveis e praticáveis a posição de partida, a projeção inicial e a transição para os primeiros apoios acelerativos, sem confundir esse trabalho técnico com a execução de um sprint completo.

## Antes de começares

1. Confirma que compreendes o exercício e que consegues interromper a tarefa quando necessário.
2. Faz primeiro uma preparação geral e específica adequada à corrida; não uses este arranque com o corpo ainda sem preparação para movimentos rápidos.
3. Confirma que consegues correr em linha, manter equilíbrio em apoios alternados e abrandar de forma controlada.
4. Escolhe antecipadamente o pé que ficará à frente e o sentido da corrida.
5. Não comeces se houver dor aguda, mal-estar, perda de coordenação ou dúvida sobre a capacidade de travar.

## Preparar o equipamento

1. Não é necessário equipamento. Não introduzas blocos, resistência, obstáculos ou alvos, porque alterariam as condições documentadas para este conteúdo.

## Preparar o espaço

1. Usa um corredor linear com superfície firme, regular e não escorregadia.
2. Mantém livres a zona de partida, o percurso, o espaço por cima e uma zona adicional para abrandar.
3. Exclui trânsito, cruzamentos públicos não controlados, objetos, pessoas ou atividades que possam entrar no percurso.
4. Confirma iluminação e visibilidade suficientes e verifica se calor, frio ou outras condições ambientais comprometem o controlo.

## Verificação do corpo

1. Consegues manter a base desencontrada sem oscilar nem precisar de apoio externo.
2. Consegues inclinar o corpo ligeiramente para a frente sem dobrar apenas a cintura nem perder o equilíbrio.
3. Consegues coordenar braço e perna opostos durante uma saída ensaiada e controlada.
4. Consegues correr em frente e reduzir a velocidade gradualmente sem travagem brusca.
5. Não sentes dor aguda, mal-estar ou perda súbita de coordenação.

## Posição inicial

Fica em pé e orientado para a frente, com os dois pés apoiados e um pé à frente do outro. Mantém uma base estável e relativamente estreita, joelhos e ancas ligeiramente fletidos e o calcanhar de trás livre para se elevar. Inclina o corpo inteiro ligeiramente para a frente, sem colapsar a cintura. Coloca o braço oposto à perna da frente também à frente, com os cotovelos confortavelmente fletidos. Mantém a cabeça alinhada com o tronco e o olhar dirigido para o corredor livre.

## Confirmar a posição inicial

1. Os dois pés estão em contacto com o chão e desencontrados.
2. Nenhum pé cruza a linha de partida nem aponta para fora do corredor.
3. A base permite equilíbrio sem passos de correção.
4. Joelhos e ancas estão ligeiramente fletidos, sem agachamento profundo.
5. O tronco inclina-se como uma unidade e a cabeça acompanha o alinhamento.
6. O braço oposto à perna da frente está preparado à frente.
7. O percurso e a zona de travagem continuam livres.

## Passos de execução

1. Estabiliza a posição de partida e distribui a pressão pelos dois apoios, com maior disponibilidade para empurrar através do pé da frente.
2. Inclina-te ligeiramente para a frente a partir dos tornozelos, mantendo cabeça, tronco e bacia organizados; não deixes o corpo cair sem controlo.
3. Ao iniciar, empurra o chão para trás e projeta o corpo para a frente, sem dar um passo preparatório para trás.
4. Separa os braços em oposição às pernas: o braço que estava à frente desloca-se para trás enquanto o outro avança, sem cruzar à frente do tronco.
5. Traz a perna de trás para o primeiro apoio à frente e coloca o pé debaixo ou próximo da bacia que avança, em vez de procurar o chão muito longe.
6. Continua com apoios alternados e direcionados para trás contra o chão, mantendo o corpo inclinado e estável.
7. Deixa o tronco subir progressivamente com os primeiros apoios; evita ficar artificialmente baixo ou levantar-te de repente.
8. Termina a componente técnica após os primeiros apoios acelerativos e passa imediatamente para uma desaceleração gradual na zona reservada.

## Fases do movimento

### Preparação

Base assimétrica de dois apoios, equilíbrio confirmado, braços em oposição e corredor verificado.

### Projeção inicial

Pressão contra o chão para deslocar o corpo para a frente, com ação coordenada dos braços e sem passo de balanço.

### Primeiros apoios

Apoios alternados próximos da trajetória da bacia, inclinação corporal controlada e elevação gradual do tronco.

### Saída e travagem

Fim do exercício técnico antes da corrida contínua, seguido de redução progressiva da velocidade até parar com equilíbrio.

## Respiração

Expira naturalmente quando inicias a saída e continua a respirar de forma livre e contínua. Não prendas a respiração nem imponhas contagens respiratórias.

## Sensações esperadas

1. Pressão breve e firme dos pés contra o chão durante a projeção.
2. Participação ativa de ancas, coxas, pernas, pés, tronco e braços.
3. Inclinação anterior controlada nos primeiros apoios.
4. Aumento natural da velocidade dos apoios enquanto o tronco sobe gradualmente.
5. Esforço rápido, mas com capacidade para manter direção, coordenação e travagem.

## Sensações inesperadas ou de alerta

1. Dor aguda ou sensação súbita de lesão.
2. Mal-estar, tontura ou falta de ar invulgar.
3. Perda súbita de coordenação, equilíbrio ou orientação.
4. Sensação de que os pés escorregam ou de que a superfície cede.
5. Incapacidade de manter o corredor ou de reduzir a velocidade com controlo.

## Indicações técnicas principais

1. Dois pés no chão, um à frente do outro.
2. Inclina o corpo inteiro; não dobres só a cintura.
3. Empurra o chão para trás e avança.
4. Braço e perna opostos trabalham juntos.
5. Apoia perto da bacia que avança; não alcances o chão.
6. Sobe o tronco gradualmente.
7. Termina cedo e abranda progressivamente.

## Erros comuns e correções

### Erro 1: Dar um passo de balanço para trás ou alterar os pés antes de sair.

- Como reconhecer: Um dos pés muda de posição depois de a postura inicial estar definida.
- Como corrigir: Reorganiza uma base estável e inicia diretamente ao empurrar o chão para trás.

### Erro 2: Dobrar apenas a cintura e deixar a bacia para trás.

- Como reconhecer: O peito baixa, mas tornozelos, bacia e tronco não formam uma inclinação coerente.
- Como corrigir: Reduz a inclinação e desloca o corpo como uma unidade a partir dos tornozelos.

### Erro 3: Levantar o tronco abruptamente no primeiro apoio.

- Como reconhecer: A cabeça e o peito sobem de repente e a projeção passa a ser sobretudo vertical.
- Como corrigir: Mantém a inclinação controlada e deixa o corpo subir ao longo dos primeiros apoios.

### Erro 4: Alongar demasiado o primeiro apoio.

- Como reconhecer: O pé procura o chão muito à frente da bacia e o contacto parece travar o avanço.
- Como corrigir: Traz a perna de trás com rapidez e coloca o pé mais próximo da bacia que avança.

### Erro 5: Usar braços do mesmo lado das pernas ou cruzá-los à frente do peito.

- Como reconhecer: O tronco roda em excesso ou o braço acompanha a perna do mesmo lado.
- Como corrigir: Prepara braço e perna opostos e move os braços sobretudo para a frente e para trás.

### Erro 6: Forçar uma posição baixa durante demasiado tempo.

- Como reconhecer: O tronco fica preso numa inclinação e os apoios perdem fluidez ou equilíbrio.
- Como corrigir: Permite uma subida progressiva e natural do tronco.

### Erro 7: Prender a respiração ou criar tensão desnecessária.

- Como reconhecer: Mandíbula, pescoço ou ombros ficam rígidos e não existe expiração natural na saída.
- Como corrigir: Expira naturalmente ao iniciar e mantém a respiração livre.

### Erro 8: Continuar a acelerar ou parar bruscamente sem espaço.

- Como reconhecer: A pessoa ultrapassa o limite do exercício técnico, encurta os passos de forma abrupta, bloqueia os joelhos ou muda de direção para parar.
- Como corrigir: Termina após os primeiros apoios e usa todo o corredor reservado para reduzir a velocidade gradualmente.

## Formas de simplificar ou ensaiar

1. Ensaiar apenas a posição inicial e regressar à posição de pé, sem iniciar a corrida.
2. Ensaiar a projeção como um primeiro passo controlado, sem procurar velocidade.
3. Percorrer a sequência como marcha coordenada para confirmar braço e perna opostos.
4. Interromper a progressão técnica nos primeiros apoios enquanto ainda existe controlo claro da forma e da travagem.
5. Usar uma demonstração e feedback de um profissional qualificado antes de aumentar a rapidez da ação.

## Supervisão

A primeira exposição exige supervisão presencial qualificada. O supervisor confirma pista, zona de saída, posição inicial, primeiros apoios e desaceleração. Mantém supervisão sempre que estes critérios não possam ser verificados autonomamente.

## Como terminar

O exercício técnico termina depois da projeção inicial e dos primeiros apoios acelerativos, antes de se tornar corrida contínua. Deixa o tronco chegar gradualmente a uma posição mais alta, para de procurar aceleração e reduz a velocidade de forma progressiva, mantendo passos controlados e o olhar no corredor. Só sais do corredor depois de parar em equilíbrio.

## Nota de segurança

Este é um exercício de risco operacional alto devido às forças de contacto, à rapidez de aplicação de força e à possibilidade de perder o controlo à velocidade. Usa supervisão técnica nas primeiras exposições, verifica antecipadamente todo o corredor e a zona de travagem e interrompe se a saída ou a desaceleração deixarem de ser controláveis.

## Quando parar ou reduzir

1. Dor aguda.
2. Mal-estar ou tontura.
3. Perda súbita de coordenação ou equilíbrio.
4. Desvio involuntário do corredor.
5. Escorregamento ou instabilidade da superfície.
6. Incapacidade de controlar os apoios, a travagem ou a paragem.
7. Para perante este sinal de alerta: Dor aguda ou sensação súbita de lesão.
8. Para perante este sinal de alerta: Mal-estar, tontura ou falta de ar invulgar.
9. Para perante este sinal de alerta: Perda súbita de coordenação, equilíbrio ou orientação.
10. Para perante este sinal de alerta: Sensação de que os pés escorregam ou de que a superfície cede.
11. Para perante este sinal de alerta: Incapacidade de manter o corredor ou de reduzir a velocidade com controlo.

## Segurança do equipamento

Não há equipamento obrigatório nem opcional neste registo. Mantém o percurso sem blocos, bandas, trenós, barreiras ou objetos soltos; qualquer equipamento adicional exigiria avaliação própria e não pertence a este conteúdo.

## Segurança do espaço

Executa apenas num corredor linear desimpedido, com superfície firme, regular e não escorregadia, espaço livre por cima e uma zona de desaceleração suficiente para uma paragem gradual. Não uses áreas com trânsito, cruzamentos públicos não controlados, iluminação insuficiente, pessoas a atravessar ou espaço reduzido.

## Limitações

1. A maior parte da evidência é da família do sprint, da aceleração inicial ou de outras configurações de partida.
2. A posição exata varia entre pessoas; não foram impostos ângulos, marcas, velocidade, distância ou qualquer dose.
3. Não foi encontrada orientação respiratória específica e primária para esta partida; aplicou-se a regra conservadora de respiração natural, contínua e sem retenção.
4. O conteúdo não substitui observação técnica presencial, avaliação de elegibilidade ou adaptação a uma pessoa concreta.
5. Não são aprovados multimédia, relações novas, equipamento adicional nem implementação.

## Teste de compreensão

### 1. O que distingue este exercício de um sprint linear completo?

Resposta esperada: Termina após a projeção inicial e os primeiros apoios acelerativos, antes da corrida contínua.

### 2. Quantos pontos de apoio no chão existem na posição inicial?

Resposta esperada: Dois: os dois pés.

### 3. Como devem estar organizados os pés?

Resposta esperada: Desencontrados, com um à frente do outro, ambos orientados para o corredor.

### 4. A inclinação deve acontecer só ao dobrar a cintura?

Resposta esperada: Não; o corpo inclina-se de forma organizada a partir dos tornozelos, com tronco e bacia alinhados.

### 5. Que braço fica preparado à frente?

Resposta esperada: O braço oposto à perna que está à frente.

### 6. Deves dar um passo para trás antes de arrancar?

Resposta esperada: Não; a saída começa diretamente ao empurrar o chão para trás.

### 7. Onde deve procurar apoio o primeiro pé que avança?

Resposta esperada: Debaixo ou próximo da trajetória da bacia, sem alcançar muito à frente.

### 8. Como sobe o tronco nos primeiros apoios?

Resposta esperada: De forma gradual, sem se levantar abruptamente nem ficar artificialmente baixo.

### 9. Como deves respirar?

Resposta esperada: Expirar naturalmente na saída e continuar a respirar livremente, sem retenção ou contagem imposta.

### 10. Que espaço deve existir depois do fim técnico do exercício técnico?

Resposta esperada: Uma zona linear livre para reduzir a velocidade gradualmente.

### 11. O que fazes se perderes a coordenação depois de iniciar?

Resposta esperada: Deixas de acelerar, manténs a direção livre e abrandas gradualmente até parar.

### 12. Quando é especialmente recomendada supervisão técnica?

Resposta esperada: Na primeira exposição, quando falta controlo da posição ou travagem e antes de aumentar rapidez ou impacto.

## Fontes e limites da evidência

### Fonte 1: AAi Coach Sprints Manual

- Autor ou entidade: B1-S02 — AAi Coach Sprints Manual — Athletics Ireland — Manual oficial de federação — https://www.athleticsireland.ie/wp-content/uploads/2024/10/AAI-Coach_Sprints_Manual.pdf — 2026-07-23 — Sustenta a projeção para a frente, a ação coordenada dos braços e pernas, a subida progressiva do corpo, a preparação por aquecimento e a desaceleração gradual. — O manual cobre a família dos sprints e várias partidas; não fornece uma prescrição completa exclusiva para este exercício técnico de dois apoios.
- Tipo: Manual oficial de federação
- Localizador: https://www.athleticsireland.ie/wp-content/uploads/2024/10/AAI-Coach_Sprints_Manual.pdf
- Usada para: Sustenta a projeção para a frente, a ação coordenada dos braços e pernas, a subida progressiva do corpo, a preparação por aquecimento e a desaceleração gradual.
- Limite: B1-S02 — AAi Coach Sprints Manual — Athletics Ireland — Manual oficial de federação — https://www.athleticsireland.ie/wp-content/uploads/2024/10/AAI-Coach_Sprints_Manual.pdf — 2026-07-23 — Sustenta a projeção para a frente, a ação coordenada dos braços e pernas, a subida progressiva do corpo, a preparação por aquecimento e a desaceleração gradual. — O manual cobre a família dos sprints e várias partidas; não fornece uma prescrição completa exclusiva para este exercício técnico de dois apoios.

### Fonte 2: Body position determines propulsive forces in accelerated running

- Autor ou entidade: EX12-S01 — Body position determines propulsive forces in accelerated running — Kugler e Janshen — Estudo biomecânico primário revisto por pares — https://pubmed.ncbi.nlm.nih.gov/19863962/ — 2026-07-23 — Sustenta a relação entre posição corporal, orientação anterior da força e aceleração. — Estudo de aceleração em estudantes de educação física; não é um guia para principiantes nem isola uma partida de dois apoios.
- Tipo: Estudo biomecânico primário revisto por pares
- Localizador: https://pubmed.ncbi.nlm.nih.gov/19863962/
- Usada para: Sustenta a relação entre posição corporal, orientação anterior da força e aceleração.
- Limite: EX12-S01 — Body position determines propulsive forces in accelerated running — Kugler e Janshen — Estudo biomecânico primário revisto por pares — https://pubmed.ncbi.nlm.nih.gov/19863962/ — 2026-07-23 — Sustenta a relação entre posição corporal, orientação anterior da força e aceleração. — Estudo de aceleração em estudantes de educação física; não é um guia para principiantes nem isola uma partida de dois apoios.

### Fonte 3: Sports Essentials Athletics Coaching Guide

- Autor ou entidade: EX12-S02 — Sports Essentials Athletics Coaching Guide — Special Olympics — Guia profissional oficial de treino — https://media.specialolympics.org/resources/sports-essentials/coaching-guides/Sports-Essentials-Athletics-Coaching-Guide-2017-Version.pdf — 2026-07-23 — Reconhece a partida de pé, a coordenação entre joelho e braço opostos e a necessidade de sprintar sob controlo; reforça adaptação e supervisão. — O guia serve uma população e um âmbito amplos; não descreve todos os pormenores biomecânicos deste exercício técnico.
- Tipo: Guia profissional oficial de treino
- Localizador: https://media.specialolympics.org/resources/sports-essentials/coaching-guides/Sports-Essentials-Athletics-Coaching-Guide-2017-Version.pdf
- Usada para: Reconhece a partida de pé, a coordenação entre joelho e braço opostos e a necessidade de sprintar sob controlo; reforça adaptação e supervisão.
- Limite: EX12-S02 — Sports Essentials Athletics Coaching Guide — Special Olympics — Guia profissional oficial de treino — https://media.specialolympics.org/resources/sports-essentials/coaching-guides/Sports-Essentials-Athletics-Coaching-Guide-2017-Version.pdf — 2026-07-23 — Reconhece a partida de pé, a coordenação entre joelho e braço opostos e a necessidade de sprintar sob controlo; reforça adaptação e supervisão. — O guia serve uma população e um âmbito amplos; não descreve todos os pormenores biomecânicos deste exercício técnico.

### Fonte 4: Inter- and intra-limb coordination during initial sprint acceleration

- Autor ou entidade: EX12-S03 — Inter- and intra-limb coordination during initial sprint acceleration — Donaldson e colaboradores — Estudo biomecânico primário revisto por pares — https://pmc.ncbi.nlm.nih.gov/articles/PMC9555766/ — 2026-07-23 — Sustenta que a aceleração inicial envolve coordenação entre membros e mudanças organizadas nos primeiros contactos. — A amostra e o protocolo são de investigação; os resultados não equivalem a instruções universais para principiantes.
- Tipo: Estudo biomecânico primário revisto por pares
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC9555766/
- Usada para: Sustenta que a aceleração inicial envolve coordenação entre membros e mudanças organizadas nos primeiros contactos.
- Limite: EX12-S03 — Inter- and intra-limb coordination during initial sprint acceleration — Donaldson e colaboradores — Estudo biomecânico primário revisto por pares — https://pmc.ncbi.nlm.nih.gov/articles/PMC9555766/ — 2026-07-23 — Sustenta que a aceleração inicial envolve coordenação entre membros e mudanças organizadas nos primeiros contactos. — A amostra e o protocolo são de investigação; os resultados não equivalem a instruções universais para principiantes.

### Fonte 5: Training and Development of Elite Sprint Performance: an Integration of Scientific and Best Practice Literature

- Autor ou entidade: SP-B2-S16 — Training and Development of Elite Sprint Performance: an Integration of Scientific and Best Practice Literature — Haugen e colaboradores — Revisão científica e de prática profissional — https://doi.org/10.1186/s40798-019-0221-0 — 2026-07-23 — Enquadra a aceleração, a mecânica do sprint e a necessidade de qualidade técnica na prática. — É uma revisão centrada no desenvolvimento de desempenho e não uma instrução específica de segurança para principiantes.
- Tipo: Revisão científica e de prática profissional
- Localizador: https://doi.org/10.1186/s40798-019-0221-0
- Usada para: Enquadra a aceleração, a mecânica do sprint e a necessidade de qualidade técnica na prática.
- Limite: SP-B2-S16 — Training and Development of Elite Sprint Performance: an Integration of Scientific and Best Practice Literature — Haugen e colaboradores — Revisão científica e de prática profissional — https://doi.org/10.1186/s40798-019-0221-0 — 2026-07-23 — Enquadra a aceleração, a mecânica do sprint e a necessidade de qualidade técnica na prática. — É uma revisão centrada no desenvolvimento de desempenho e não uma instrução específica de segurança para principiantes.
