# Relatório de investigação — `plyometric_push_up`

**Agente:** EX-13  
**Exercício:** Flexão de braços pliométrica  
**Data da pesquisa:** 2026-07-23  
**Risco canónico preservado:** elevado  
Implementação realizada: não

## Âmbito e decisão

Foram investigadas execução, posição inicial, respiração, segurança, receção, erros e supervisão. Não foram alteradas a identidade, o risco, o equipamento, as relações aprovadas ou o estado dos meios.

Decisão editorial: `beginner_content_approved_with_limits`.

O conteúdo pode explicar o exercício a uma pessoa principiante, mas não constitui autorização para o experimentar autonomamente. A primeira exposição exige supervisão direta e demonstração dos pré-requisitos. Esta restrição resulta da combinação entre:

- risco canónico elevado;
- fase aérea das mãos;
- receção rápida de carga pelos membros superiores;
- possibilidade de receção assimétrica;
- necessidade elevada de coordenação e estabilidade;
- evidência direta limitada em principiantes absolutos.

## Identidade preservada

A definição canónica exige:

1. partida em prancha alta;
2. descida do tronco;
3. inversão rápida da ação;
4. projeção com perda de contacto de ambas as mãos;
5. receção bilateral no solo.

Uma flexão executada depressa mas sem fase aérea não satisfaz esta identidade. Palmas, profundidade a partir de caixas e outras alterações são variantes ou tarefas distintas e foram excluídas.

## Síntese da evidência

### Mecânica pliométrica

A NSCA descreve a pliometria como uma transição rápida de uma ação excêntrica para uma concêntrica no ciclo alongamento-encurtamento. Davies, Riemann e Manske descrevem as fases de carga excêntrica, amortização e ação concêntrica e salientam a necessidade de controlo neuromuscular e progressão técnica.

Aplicação ao conteúdo: a descida é controlada, a inversão é rápida e a identidade requer a fase aérea. A explicação evita transformar “rápido” em sinónimo de “pliométrico”.

### Posição e execução específica

O artigo técnico da American Council on Exercise descreve:

- posição de flexão com pés apoiados;
- mãos ligeiramente mais afastadas do que os ombros;
- descida preparatória;
- empurrão explosivo até as mãos deixarem o chão;
- receção suave com os cotovelos ligeiramente fletidos.

O artigo também limita a aplicação a pessoas que já demonstraram estabilidade, mobilidade, força e técnica adequadas. Esta foi a fonte profissional específica principal para a sequência pública.

### Fase aérea, forças e receção

Koch, Riemann e Davies compararam forças verticais de reação do solo em variações de flexão pliométrica. Moore e colaboradores analisaram cinemática e força em quatro variações. Em conjunto, estes trabalhos confirmam que a projeção e a receção são eventos mecânicos mensuráveis e que alterar a variante modifica as exigências.

Aplicação ao conteúdo:

- as duas mãos devem sair e regressar;
- a receção é tratada como uma competência, não como um pormenor;
- contacto unilateral, cotovelos rígidos ou colapso do tronco são critérios de falha;
- não se transportaram dados de variantes com palma ou caixa para uma prescrição desta entrada.

### Punhos e assimetria

Polovinets, Wolf e Wollstein verificaram que a posição do punho altera a transmissão de força numa flexão convencional e observaram diferenças entre membro dominante e não dominante.

Aplicação prudente: verificar simetria, manter as palmas preparadas para o solo e interromper perante dor, formigueiro, instabilidade ou receção unilateral. O estudo não testou receções pliométricas; por isso não foi usado para recomendar pegas, punho fechado ou uma posição individual do punho.

### Respiração

A fonte técnica da ACE para a flexão convencional orienta inspiração na descida e expiração no empurrão. O registo canónico já determina expiração na projeção e retoma da respiração na receção.

Aplicação ao conteúdo: deixar entrar o ar na descida, expirar na projeção e retomar imediatamente respiração natural na receção, sem contagens nem retenção.

Limite: não foi encontrada evidência primária que compare padrões respiratórios especificamente durante a flexão pliométrica. A orientação é, portanto, uma extrapolação técnica conservadora, não uma alegação de superioridade.

### Supervisão e ambiente

As normas profissionais da NSCA exigem supervisão adequada por pessoal qualificado, proximidade, visibilidade, comunicação clara e um ambiente seguro. Indicam também maior supervisão para principiantes e movimentos complexos e incluem a capacidade de ensinar e avaliar técnica pliométrica.

Aplicação ao conteúdo:

- supervisão direta na primeira exposição;
- profissional suficientemente próximo para observar ambas as mãos e o tronco;
- superfície firme, uniforme e antiderrapante;
- área livre, sem circulação;
- comunicação imediata de paragem;
- não usar um spotter manual para tentar agarrar a pessoa em voo.

Isto preserva o registo canónico: `spotter_required: false` e `supervision_requirement: recommended`.

## Decisões técnicas adotadas

| Tema | Decisão | Fundamento |
|---|---|---|
| Mãos | Ligeiramente mais afastadas do que os ombros, simétricas e abertas | ACE; preparação para receção |
| Tronco | Cabeça, tronco e bacia mantidos como uma unidade | Técnica de flexão e controlo da coluna |
| Cotovelos na receção | Ligeiramente fletidos e capazes de continuar a fletir | ACE; amortecimento |
| Fase aérea | Ambas as mãos deixam o chão simultaneamente | Identidade canónica e estudos biomecânicos |
| Palmas | Excluídas | Variante não aprovada e redução do tempo disponível para preparar a receção |
| Pés | Permanecem no solo | Identidade canónica |
| Respiração | Ar entra na descida, sai na projeção, sem retenção | ACE e registo canónico |
| Primeira exposição | Não autónoma | Risco elevado, complexidade e normas NSCA |
| Saída | Recuperar apoio, baixar os joelhos e terminar | Estratégia operacional não clínica |

## Pré-requisitos e critérios de interrupção

Pré-requisitos documentados:

- compreender a ação e uma indicação de paragem;
- manter prancha alta alinhada;
- executar flexão convencional controlada;
- tolerar apoio nas mãos sem dor aguda;
- demonstrar travagem com cotovelos fletidos;
- ter espaço e superfície verificados;
- dispor de supervisão direta na primeira exposição.

Critérios de interrupção:

- dor aguda;
- mal-estar ou tonturas;
- formigueiro, dormência ou perda súbita de força;
- incapacidade de controlar a travagem;
- contacto claramente unilateral;
- colapso de ombros, peito ou bacia;
- escorregamento;
- falha em cumprir uma indicação de paragem.

## Cinco campos adicionais de risco elevado

### `prerequisite_skill_pt_pt`

Inclui prancha alta, flexão convencional, controlo do tronco, empurrão simétrico, travagem pelos cotovelos e compreensão da saída.

### `supervision_recommendation_pt_pt`

Exige observação direta na primeira exposição e sempre que aumentem velocidade, impacto ou complexidade. O supervisor vê mãos e tronco, comunica imediatamente e interrompe nova tentativa quando a receção degrada.

### `safe_space_requirement_pt_pt`

Zona desimpedida, sem circulação, com piso firme, plano, seco e antiderrapante e espaço livre em redor das mãos.

### `landing_or_braking_control_pt_pt`

Contacto simultâneo das palmas, cotovelos ligeiramente fletidos, tronco alinhado, ombros estáveis e pés no chão. Assimetria, rigidez, escorregamento ou colapso significam falha.

### `failure_exit_strategy_pt_pt`

Manter as mãos abertas para o contacto, recuperar apoio bilateral, baixar os joelhos e terminar. Não tentar salvar a ação com uma palma, rotação ou deslocação brusca.

## Erros priorizados

Foram incluídos oito erros observáveis:

1. ausência de fase aérea;
2. queda da bacia ou extensão lombar;
3. receção unilateral;
4. cotovelos rígidos;
5. cotovelos excessivamente abertos;
6. tentativa de bater palmas;
7. retenção da respiração;
8. continuação após degradação da receção.

Cada erro inclui uma forma de reconhecimento e uma correção não prescritiva.

## Fontes consultadas

1. **B1-S04 — NSCA.** [Plyometric Exercises](https://www.nsca.com/education/articles/kinetic-select/plyometric-exercises/). Fonte profissional para ciclo alongamento-encurtamento e domínio técnico. Limite: foco predominante no membro inferior.
2. **SP-B2-S19 — Davies G, Riemann BL, Manske R.** [Current Concepts of Plyometric Exercise](https://pmc.ncbi.nlm.nih.gov/articles/PMC4637913/). *International Journal of Sports Physical Therapy*. 2015;10(6):760-786. Revisão de família; não valida isoladamente cada cue.
3. **SP-B2-S20 — García-Carrillo E et al.** [Effects of Upper-Body Plyometric Training on Physical Fitness in Healthy Youth and Young Adult Participants: A Systematic Review](https://pmc.ncbi.nlm.nih.gov/articles/PMC10575843/). *Sports*. 2023;11(10):195. Sustenta o enquadramento da pliometria superior; estudos heterogéneos.
4. **EX13-S01 — Koch J, Riemann BL, Davies GJ.** [Ground Reaction Force Patterns in Plyometric Push-Ups](https://pubmed.ncbi.nlm.nih.gov/21986698/). *Journal of Strength and Conditioning Research*. 2012;26(8):2220-2227. Estudo biomecânico primário; variantes diferentes da entrada canónica.
5. **EX13-S02 — Moore LH, Tankovich MJ, Riemann BL, Davies GJ.** [Kinematic Analysis of Four Plyometric Push-Up Variations](https://pmc.ncbi.nlm.nih.gov/articles/PMC4738879/). *International Journal of Exercise Science*. 2012;5(4):334-343. Estudo primário; amostra limitada de homens recreativamente ativos.
6. **EX13-S03 — Cain M, ACE.** [Five Exercises to Help Your Clients Develop Power](https://www.acefitness.org/resources/pros/expert-articles/6941/five-exercises-to-help-your-clients-develop-power/). Fonte profissional específica para posição, projeção e receção; não é ensaio clínico.
7. **EX13-S04 — NSCA.** [Strength and Conditioning Professional Standards and Guidelines](https://www.nsca.com/globalassets/education/nsca_strength_and_conditioning_professional_standards_and_guidelines.pdf). *Strength and Conditioning Journal*. 2017;39(6):1-24. Norma de supervisão e ambiente; não é protocolo específico do exercício.
8. **EX13-S05 — Polovinets O, Wolf A, Wollstein R.** [Force Transmission Through the Wrist During Performance of Push-Ups on a Hyperextended and a Neutral Wrist](https://pubmed.ncbi.nlm.nih.gov/28684196/). *Journal of Hand Therapy*. 2018;31(3):322-330. Estudo biomecânico primário de flexões convencionais, não de receções pliométricas.
9. **EX13-S06 — ACE.** [Summer HIIT Workout](https://www.acefitness.org/resources/everyone/blog/4915/summer-hiit-workout/). Fonte técnica para respiração na flexão convencional; extrapolação limitada para a fase pliométrica.

## Confiança e limitações

**Confiança global:** moderada.

Há convergência entre estudos biomecânicos, revisões e fontes profissionais, mas:

- as amostras diretas são pequenas e pouco representativas de principiantes;
- várias fontes estudam palmas ou quedas de caixa;
- a evidência respiratória específica é indireta;
- não existe base para prometer resultados, diagnosticar, tratar ou autorizar execução universal;
- não foi definida dose, carga, ritmo, frequência ou progressão programada.

Não ficaram campos por resolver dentro do contrato documental.
