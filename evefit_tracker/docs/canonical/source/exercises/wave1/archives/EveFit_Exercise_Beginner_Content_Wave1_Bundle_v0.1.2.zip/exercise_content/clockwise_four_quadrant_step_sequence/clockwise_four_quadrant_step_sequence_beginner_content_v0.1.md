# Sequência de passos em quatro quadrantes no sentido horário

Conteúdo para principiantes em português europeu.

## Descrição curta

Percorre quatro quadrantes planos por uma ordem fixa, levando os dois pés a cada quadrante antes de avançares para o seguinte.

## O que é

Este exercício é um circuito fechado de passo-junta. Começa no quadrante posterior esquerdo, segue para o anterior esquerdo, anterior direito, posterior direito e regressa ao posterior esquerdo. A pessoa mantém a referência da frente da grelha e conclui cada transição com os dois pés no quadrante de destino.

## O que vais fazer

Vais deslocar-te para a frente, para a direita, para trás e para a esquerda, sempre de um quadrante para o seguinte. Em cada transição, um pé entra primeiro e o outro junta-se, sem saltar quadrantes.

## Porque existe este movimento

A tarefa existe para praticar a memória e a execução de uma sequência multidirecional fixa, incluindo transições controladas entre apoios. Não é um teste, não é cronometrada e não inclui pontuação nem obstáculos elevados.

## Antes de começares

1. Define claramente qual é a frente da grelha e identifica os quatro quadrantes a partir da tua perspetiva.
2. Confirma que os quadrantes são apenas visuais e que qualquer marcação está totalmente plana e presa ao piso.
3. Retira objetos, tapetes soltos, cabos e outras fontes de tropeção de toda a área em redor.
4. Usa um piso firme, nivelado, seco e antiderrapante, com iluminação suficiente para ver todas as marcações.
5. Confirma que há espaço livre à frente, atrás e de ambos os lados, incluindo para a fase de passo para trás.
6. Verifica que compreende a ordem e que consegue iniciar e parar voluntariamente, dar passos laterais e para trás com controlo.
7. A supervisão é recomendada. Se tiveres risco elevado de queda, quedas recentes, dificuldade em sair da tarefa sozinho ou um contexto clinicamente condicionado, a elegibilidade e a forma de supervisão devem ser revistas antes de iniciar.

## Preparar o equipamento

1. Não é necessário equipamento.
2. São necessários quatro quadrantes visuais planos no piso. Podem resultar de linhas já existentes ou de marcações adequadas.
3. Podes usar fita de marcação de piso totalmente aderente e sem bordos levantados.
4. Pressiona toda a fita contra o piso e confirma que nenhuma ponta, dobra ou sobreposição forma relevo. Não uses hastes, barras, cordas, cones deitados nem divisórias elevadas.

## Preparar o espaço

1. Reserva uma área de deslocamento multidirecional que permita entrar nos quatro quadrantes sem tocar em paredes, móveis ou outras pessoas.
2. Escolhe uma superfície firme, nivelada, seca e antiderrapante.
3. Garante iluminação uniforme, sem zonas escuras que escondam as marcações ou objetos.
4. Mantém todo o circuito e a margem em redor livres de objetos, cabos, tapetes soltos e líquidos.

## Verificação do corpo

1. Consigo manter-me de pé e transferir o peso de um pé para o outro com controlo?
2. Consigo dar um passo lateral e um passo para trás sem apoio não planeado?
3. Consigo reconhecer os quatro quadrantes e recordar a ordem frente, direita, trás, esquerda?
4. Consigo parar de forma voluntária e ficar estável com os dois pés no mesmo quadrante?
5. Não sinto agora dor aguda, tontura ou mal-estar?
6. Tenho a supervisão adequada ao meu nível de segurança e consigo sair da grelha sem risco?

## Posição inicial

Fica de pé no quadrante posterior esquerdo, com os dois pés totalmente dentro da área marcada. Orienta o tronco para a frente definida da grelha, mantém uma postura confortável e distribui o peso de forma estável pelos dois pés.

## Confirmar a posição inicial

1. Ambos os pés estão no quadrante posterior esquerdo.
2. Sei onde ficam o anterior esquerdo, anterior direito e posterior direito.
3. A frente da grelha continua claramente identificada.
4. Os joelhos estão confortáveis, sem bloqueio forçado.
5. O tronco está estável e o olhar permite antecipar o próximo quadrante.
6. A área à minha volta continua livre e as marcações permanecem planas.

## Passos de execução

1. Antes de moveres os pés, confirma mentalmente a rota: frente, direita, trás e esquerda.
2. Do quadrante posterior esquerdo, avança um pé para o quadrante anterior esquerdo e transfere o peso com controlo.
3. Leva o outro pé para o quadrante anterior esquerdo, ficando novamente com os dois pés no mesmo quadrante.
4. Passa para o quadrante anterior direito com o padrão passo-junta: um pé desloca-se para a direita e o outro reúne-se a ele.
5. Recua para o quadrante posterior direito. Confirma que o destino está livre, coloca um pé para trás e leva o outro a juntar-se, sem cruzar os pés.
6. Desloca-te para a esquerda até ao quadrante posterior esquerdo, novamente com um pé a iniciar e o outro a juntar-se.
7. Termina com os dois pés estáveis no quadrante inicial. Pára de forma deliberada antes de saíres da grelha.

## Fases do movimento

### Identificar a frente, a posição inicial e a ordem completa antes do primeiro passo.

Identificar a frente, a posição inicial e a ordem completa antes do primeiro passo.

### Posterior esquerdo para anterior esquerdo, por passo-junta.

Posterior esquerdo para anterior esquerdo, por passo-junta.

### Anterior esquerdo para anterior direito, por passo-junta lateral.

Anterior esquerdo para anterior direito, por passo-junta lateral.

### Anterior direito para posterior direito, por passo-junta para trás.

Anterior direito para posterior direito, por passo-junta para trás.

### Posterior direito para posterior esquerdo, por passo-junta lateral.

Posterior direito para posterior esquerdo, por passo-junta lateral.

### Estabilizar os dois pés no quadrante inicial e terminar voluntariamente.

Estabilizar os dois pés no quadrante inicial e terminar voluntariamente.

## Respiração

Respira de forma natural e contínua durante toda a sequência. Não prendas a respiração e não associes inspirações ou expirações a passos específicos. Se a atenção à ordem fizer com que sustenhas o ar, pára em apoio estável, retoma a respiração normal e só prossegue quando voltares a ter controlo.

## Sensações esperadas

1. Transferência alternada do peso entre os pés.
2. Breves momentos de apoio num só membro durante cada passo.
3. Trabalho de controlo nos tornozelos, joelhos, ancas e tronco.
4. Necessidade de atenção para recordar o próximo quadrante.
5. Esforço ligeiro de estabilização ao mudar de direção, sem impacto ou salto.

## Sensações inesperadas ou de alerta

1. Dor aguda.
2. Tontura ou mal-estar.
3. Perda de controlo da direção ou do apoio.
4. Necessidade repetida de agarrar apoio de forma não planeada.
5. Desequilíbrio que impeça uma paragem estável.
6. Falta de ar intensa ou inesperada.

## Indicações técnicas principais

1. Frente, direita, trás, esquerda.
2. Um pé entra; o outro junta-se.
3. Os dois pés em cada quadrante.
4. Olha para o destino antes de transferires o peso.
5. Passos controlados, sem saltar nem cruzar os pés.
6. Respiração natural e contínua.

## Erros comuns e correções

### Erro 1: Saltar um quadrante ou trocar a ordem.

- Como reconhecer: A pessoa passa diretamente para um quadrante não adjacente ou deixa de seguir frente, direita, trás, esquerda.
- Como corrigir: Pára com os dois pés estáveis, volta a identificar a frente e diz a rota antes de reiniciares desde o quadrante posterior esquerdo.

### Erro 2: Mover o pé seguinte antes de o outro se juntar.

- Como reconhecer: A sequência transforma-se numa caminhada contínua e os dois pés não chegam a estar juntos em cada quadrante.
- Como corrigir: Conclui cada transição: primeiro um pé entra no destino, depois o outro reúne-se, e só então procura o quadrante seguinte.

### Erro 3: Cruzar os pés na deslocação lateral ou para trás.

- Como reconhecer: Um pé passa à frente ou atrás do outro, estreitando ou entrelaçando a base de apoio.
- Como corrigir: Usa um passo lateral ou posterior direto e leva o segundo pé a juntar-se sem cruzamento.

### Erro 4: Acelerar quando a ordem deixa de estar clara.

- Como reconhecer: Os passos ficam apressados, a colocação dos pés perde precisão ou surge uma correção brusca.
- Como corrigir: Pára de forma estável, recupera a ordem e retoma apenas quando souber qual é o quadrante seguinte.

### Erro 5: Pisar uma marcação levantada ou uma divisória.

- Como reconhecer: A fita tem pontas soltas ou existe qualquer objeto elevado entre quadrantes, criando risco de tropeção.
- Como corrigir: Não inicies ou interrompe a tarefa; retira a divisória e usa apenas referências visuais totalmente planas e fixas.

### Erro 6: Recuar sem confirmar o espaço.

- Como reconhecer: O pé procura o quadrante posterior sem que a pessoa tenha verificado se o destino e a margem estão livres.
- Como corrigir: Antes da transição para trás, identifica o quadrante posterior direito e confirma que não existem objetos ou pessoas no trajeto.

## Formas de simplificar ou ensaiar

1. Usa palavras visuais nos quadrantes ou setas planas para tornar a rota mais fácil de recordar, sem alterar a ordem.
2. Aponta para o quadrante seguinte antes de moveres o pé.
3. Escolhe quadrantes com dimensão suficiente para receber ambos os pés e próximos o bastante para permitir passos controlados, preservando sempre a mesma grelha de quatro áreas.
4. Faz uma pausa estável com os dois pés em cada quadrante; a pausa serve para confirmar a ordem, não para impor um tempo.
5. Se não conseguires completar a sequência com segurança, não substituas o padrão por movimentos improvisados: pára e pede supervisão ou adaptação adequada.

## Supervisão

A supervisão é recomendada porque a tarefa inclui deslocação lateral, mudança de direção e um passo para trás. A pessoa que supervisiona deve permanecer fora do trajeto, conseguir observar os pés e a área em redor e evitar criar um novo obstáculo. — Risco elevado de queda. Quedas recentes. Dificuldade em dar passos para trás ou laterais com controlo. Necessidade repetida de apoio não planeado. Incapacidade de interromper ou sair da tarefa de forma independente. Contexto clinicamente condicionado, neurológico ou vestibular que exija revisão. — Não é exigido um assistente de segurança para todas as pessoas, mas a supervisão recomendada e os gatilhos de revisão não devem ser reduzidos.

## Como terminar

Depois de regressar ao quadrante posterior esquerdo, reúne os dois pés e confirma que estás estável. Pára a sequência de forma intencional. Em seguida, sai para uma zona já verificada como livre, sem passar por cima de marcações levantadas ou de objetos.

## Nota de segurança

Risco operacional moderado. O risco principal é perder o equilíbrio, falhar um passo ou tropeçar, sobretudo na transição para trás. Não uses obstáculos ou divisórias elevadas. Interrompe se perderes o controlo ou deixares de saber qual é o próximo quadrante.

## Quando parar ou reduzir

1. Dor aguda. — Interrompe a sequência e estabiliza-te numa posição segura.
2. Tontura ou mal-estar. — Pára e procura apoio seguro; não continues enquanto o sinal estiver presente.
3. Necessidade repetida de apoio não planeado. — Interrompe e revê a adequação da tarefa e da supervisão.
4. Perda de controlo dos pés, da direção ou da paragem. — Pára no primeiro apoio estável disponível e não prossigas sem recuperar o controlo.
5. Falta de ar intensa ou inesperada. — Interrompe e recupera numa posição segura; procura ajuda adequada se não resolver.

## Segurança do equipamento

As marcações são opcionais, mas os quatro alvos visuais são necessários. Se usares fita, mantém-na totalmente aderente, plana e sem pontas ou dobras. Não uses cordas, ripas, hastes, barras nem outros separadores elevados. Não coloques cadeiras, cones ou objetos dentro do circuito ou da margem de deslocamento. Pára se qualquer marcação se soltar durante a tarefa.

## Segurança do espaço

Piso firme, nivelado, seco e antiderrapante. Percurso e margem em redor sem objetos, cabos, tapetes soltos, líquidos ou outras pessoas. Iluminação suficiente para distinguir todos os quadrantes e os limites do espaço. Folga multidirecional, com atenção específica à área posterior usada no passo para trás. Sem trânsito, desníveis ou superfícies soltas no trajeto.

## Limitações

1. A evidência disponível refere-se sobretudo a programas e famílias de passos em grelha, não à sequência canónica isolada.
2. Não se inferem efeitos, resultados clínicos, dose, velocidade, cadência ou progressão.
3. A orientação respiratória é geral porque não foi encontrada uma relação respiratória específica para esta sequência.
4. A adequação individual e o nível de supervisão dependem da capacidade de executar passos laterais e para trás, parar e sair da tarefa com controlo.
5. Implementação realizada: não.

## Teste de compreensão

### 1. Em que quadrante começa a sequência?

Resposta esperada: No quadrante posterior esquerdo, com os dois pés dentro dele.

### 2. Qual é a ordem das quatro direções?

Resposta esperada: Frente, direita, trás e esquerda.

### 3. Para onde se desloca depois do quadrante anterior esquerdo?

Resposta esperada: Para o quadrante anterior direito.

### 4. O que significa passo-junta nesta tarefa?

Resposta esperada: Um pé entra no quadrante de destino e o outro junta-se antes da transição seguinte.

### 5. Podes saltar um quadrante para recuperar a ordem?

Resposta esperada: Não. Deves parar de forma estável, recuperar a rota e reiniciar corretamente.

### 6. As divisórias entre quadrantes podem ser elevadas?

Resposta esperada: Não. As referências têm de ser visuais, planas e sem risco de tropeção.

### 7. Que características deve ter o piso?

Resposta esperada: Deve ser firme, nivelado, seco e antiderrapante.

### 8. O que deves confirmar antes do passo para trás?

Resposta esperada: Que o quadrante posterior direito e a margem em redor estão livres.

### 9. Como deves respirar?

Resposta esperada: De forma natural e contínua, sem prender a respiração nem usar contagens.

### 10. O que deves fazer se deixares de saber qual é o próximo quadrante?

Resposta esperada: Parar com os dois pés estáveis, recuperar a ordem e só depois retomar.

### 11. Que sinais obrigam a interromper a tarefa?

Resposta esperada: Dor aguda, tontura, mal-estar, perda de controlo ou necessidade repetida de apoio não planeado.

### 12. Como termina corretamente o circuito?

Resposta esperada: Regressa ao quadrante posterior esquerdo, junta os dois pés, estabiliza e para de forma deliberada.

## Fontes e limites da evidência

### Fonte 1: Shigematsu R, Okura T, Nakagaichi M, et al. Square-stepping exercise and fall risk factors in older adults: a single-blind, randomized controlled trial. J Gerontol A Biol Sci Med Sci. 2008;63(1):76-82.

- Autor ou entidade: E1-SRC-020 — Shigematsu R, Okura T, Nakagaichi M, et al. Square-stepping exercise and fall risk factors in older adults: a single-blind, randomized controlled trial. J Gerontol A Biol Sci Med Sci. 2008;63(1):76-82. — literatura primária, ensaio aleatorizado — https://pubmed.ncbi.nlm.nih.gov/18245764/ — Fundamenta a família de exercício em grelha e movimentos multidirecionais, não esta sequência exata.
- Tipo: literatura primária, ensaio aleatorizado
- Localizador: https://pubmed.ncbi.nlm.nih.gov/18245764/
- Usada para: Fundamenta a família de exercício em grelha e movimentos multidirecionais, não esta sequência exata.
- Limite: E1-SRC-020 — Shigematsu R, Okura T, Nakagaichi M, et al. Square-stepping exercise and fall risk factors in older adults: a single-blind, randomized controlled trial. J Gerontol A Biol Sci Med Sci. 2008;63(1):76-82. — literatura primária, ensaio aleatorizado — https://pubmed.ncbi.nlm.nih.gov/18245764/ — Fundamenta a família de exercício em grelha e movimentos multidirecionais, não esta sequência exata.

### Fonte 2: Shigematsu R, Okura T. A novel exercise for improving lower-extremity functional fitness in the elderly. Aging Clin Exp Res. 2006;18(3):242-248.

- Autor ou entidade: SRC-EX39-02 — Shigematsu R, Okura T. A novel exercise for improving lower-extremity functional fitness in the elderly. Aging Clin Exp Res. 2006;18(3):242-248. — literatura primária, estudo controlado não aleatorizado — https://doi.org/10.1007/BF03324655 — Confirma que o Square-Stepping Exercise inclui passos para a frente, para trás, laterais e oblíquos; não valida a ordem canónica específica.
- Tipo: literatura primária, estudo controlado não aleatorizado
- Localizador: https://doi.org/10.1007/BF03324655
- Usada para: Confirma que o Square-Stepping Exercise inclui passos para a frente, para trás, laterais e oblíquos; não valida a ordem canónica específica.
- Limite: SRC-EX39-02 — Shigematsu R, Okura T. A novel exercise for improving lower-extremity functional fitness in the elderly. Aging Clin Exp Res. 2006;18(3):242-248. — literatura primária, estudo controlado não aleatorizado — https://doi.org/10.1007/BF03324655 — Confirma que o Square-Stepping Exercise inclui passos para a frente, para trás, laterais e oblíquos; não valida a ordem canónica específica.

### Fonte 3: NHS. Balance exercises.

- Autor ou entidade: SRC-EX39-03 — NHS. Balance exercises. — orientação profissional oficial — https://www.nhs.uk/live-well/exercise/balance-exercises/ — Apoia deslocação lateral lenta e controlada, o padrão de juntar o segundo pé e a consideração de apoio estável em caso de perda de equilíbrio.
- Tipo: orientação profissional oficial
- Localizador: https://www.nhs.uk/live-well/exercise/balance-exercises/
- Usada para: Apoia deslocação lateral lenta e controlada, o padrão de juntar o segundo pé e a consideração de apoio estável em caso de perda de equilíbrio.
- Limite: SRC-EX39-03 — NHS. Balance exercises. — orientação profissional oficial — https://www.nhs.uk/live-well/exercise/balance-exercises/ — Apoia deslocação lateral lenta e controlada, o padrão de juntar o segundo pé e a consideração de apoio estável em caso de perda de equilíbrio.

### Fonte 4: Oxford University Hospitals NHS Foundation Trust. OTAGO Strength and Balance: Home Exercise Programme.

- Autor ou entidade: SRC-EX39-04 — Oxford University Hospitals NHS Foundation Trust. OTAGO Strength and Balance: Home Exercise Programme. — orientação profissional oficial — https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf — Apoia preparação do espaço, suporte estável conforme necessidade, respiração normal, passos laterais e para trás controlados e sinais de interrupção.
- Tipo: orientação profissional oficial
- Localizador: https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf
- Usada para: Apoia preparação do espaço, suporte estável conforme necessidade, respiração normal, passos laterais e para trás controlados e sinais de interrupção.
- Limite: SRC-EX39-04 — Oxford University Hospitals NHS Foundation Trust. OTAGO Strength and Balance: Home Exercise Programme. — orientação profissional oficial — https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf — Apoia preparação do espaço, suporte estável conforme necessidade, respiração normal, passos laterais e para trás controlados e sinais de interrupção.

### Fonte 5: CDC/NIOSH. Slip, Trip, and Fall Prevention for Healthcare Workers.

- Autor ou entidade: SRC-EX39-05 — CDC/NIOSH. Slip, Trip, and Fall Prevention for Healthcare Workers. — orientação oficial de prevenção de quedas — https://www.cdc.gov/niosh/docs/2011-123/pdfs/2011-123.pdf — Apoia o uso de elementos de piso planos, fixos e sem bordos levantados.
- Tipo: orientação oficial de prevenção de quedas
- Localizador: https://www.cdc.gov/niosh/docs/2011-123/pdfs/2011-123.pdf
- Usada para: Apoia o uso de elementos de piso planos, fixos e sem bordos levantados.
- Limite: SRC-EX39-05 — CDC/NIOSH. Slip, Trip, and Fall Prevention for Healthcare Workers. — orientação oficial de prevenção de quedas — https://www.cdc.gov/niosh/docs/2011-123/pdfs/2011-123.pdf — Apoia o uso de elementos de piso planos, fixos e sem bordos levantados.

### Fonte 6: CDC STEADI. Check for Safety: A Home Fall Prevention lista de verificação for Older Adults.

- Autor ou entidade: SRC-EX39-06 — CDC STEADI. Check for Safety: A Home Fall Prevention lista de verificação for Older Adults. — orientação oficial de prevenção de quedas — https://www.cdc.gov/steadi/pdf/steadi-brochure-checkforsafety-508.pdf — Apoia percurso livre, remoção de objetos, cabos e tapetes soltos e iluminação adequada.
- Tipo: orientação oficial de prevenção de quedas
- Localizador: https://www.cdc.gov/steadi/pdf/steadi-brochure-checkforsafety-508.pdf
- Usada para: Apoia percurso livre, remoção de objetos, cabos e tapetes soltos e iluminação adequada.
- Limite: SRC-EX39-06 — CDC STEADI. Check for Safety: A Home Fall Prevention lista de verificação for Older Adults. — orientação oficial de prevenção de quedas — https://www.cdc.gov/steadi/pdf/steadi-brochure-checkforsafety-508.pdf — Apoia percurso livre, remoção de objetos, cabos e tapetes soltos e iluminação adequada.
