# Relatório de investigação — `supine_heel_slide`

## Estado

- Agente: EX-23
- Exercício: `supine_heel_slide`
- Implementação realizada: não
- Âmbito: documentação de execução para principiante
- Fora do âmbito: prescrição, diagnóstico, tratamento, promessa de resultado, código e publicação

## Identidade preservada

O exercício mantém a definição canónica: em decúbito dorsal, a pessoa desliza um calcanhar pela superfície em direção à pelve, fletindo anca e joelho, e regressa à perna estendida. Mantêm-se:

- exercício canónico, sem exercício-base nem variante;
- transição sagital unilateral apoiada;
- contacto deslizante do calcanhar;
- tronco e pelve apoiados, sem deslocamento global;
- risco operacional base baixo;
- ausência de equipamento obrigatório;
- tapete de exercício e deslizador de baixa fricção apenas opcionais;
- superfície firme e nivelada, compatível com deslizamento controlado;
- ausência de observador e supervisão obrigatórios;
- três relações canónicas já aprovadas, sem criação, remoção ou alteração.

## Perguntas de investigação

Foram pesquisados: execução, posicionamento em decúbito dorsal, respiração, segurança, amplitude, erros técnicos e supervisão. Foram privilegiados guias oficiais de serviços clínicos e associações profissionais, complementados por literatura primária.

## Fontes e contributo

| Fonte | Tipo | Contributo usado | Limite |
|---|---|---|---|
| [Cambridge University Hospitals NHS — Early knee exercises](https://www.cuh.nhs.uk/patient-information/early-knee-exercises/) | Guia oficial de fisioterapia hospitalar | Decúbito dorsal confortável; dobrar o joelho mantendo o calcanhar junto da cama; procurar orientação se o exercício for doloroso | Contexto clínico inicial; não se transferiu dose |
| [AAOS — Total Hip Replacement Exercise Guide](https://orthoinfo.aaos.org/en/recovery/total-hip-replacement-exercise-guide/) | Guia profissional oficial revisto por pares | Deslizar o pé em direção às nádegas; calcanhar apoiado; não deixar o joelho cair para dentro; estender no regresso | Contexto pós-operatório; retenção, dose e alegações de resultado não foram generalizadas |
| [University Hospitals Plymouth NHS Trust — Lower Back Strengthening Exercises](https://www.plymouthhospitals.nhs.uk/display-pil/pil-lower-back-strengthening-exercises-4042/) | Guia oficial de fisioterapia hospitalar | Contacto do calcanhar, pelve e coluna estáveis e padrão respiratório relaxado | É uma variante orientada ao tronco, com direção inicial inversa; só se transferiram princípios compatíveis |
| [Giggins, Sweeney e Caulfield, 2014](https://doi.org/10.1186/1743-0003-11-158) | Literatura primária, estudo analítico transversal | Heel slide em decúbito dorsal; importância de alinhamento, velocidade e qualidade; instrução, demonstração e ensaio observado | Contexto clínico controlado; o estudo classifica desempenho e não estabelece prescrição |
| [Satış e Erdem, 2020](https://doi.org/10.7759/cureus.6988) | Literatura primária, estudo de aprendizagem | Aprendizagem do heel slide após explicação e demonstração por fisioterapeuta; relevância de confirmar compreensão | Amostra clínica com dor mecânica do joelho; não demonstra segurança universal |

As fontes oficiais Cambridge University Hospitals e AAOS são independentes. As duas publicações primárias também provêm de equipas e objetivos de investigação distintos.

## Síntese por domínio

### Execução e posição

Há convergência direta para a posição deitado de costas, o deslizamento do pé em direção à pelve ou nádegas, a flexão coordenada do joelho e o regresso à extensão. O contacto contínuo do calcanhar foi mantido como elemento nuclear e como distinção de uma elevação do membro.

### Alinhamento e erros

A AAOS explicita que o joelho não deve rolar para dentro. A fonte de Plymouth sustenta coluna neutra e pelve estável numa variante de heel slide. A literatura de Giggins et al. trata alinhamento, velocidade e qualidade como dimensões observáveis de execução correta. Isto sustenta os erros públicos:

- levantar o calcanhar;
- rodar a pelve ou torcer o tronco;
- desalinhar o joelho relativamente ao pé;
- deslizar sem controlo;
- forçar a amplitude;
- prender a respiração.

### Respiração

Não foi encontrada base direta e consistente para impor inspiração ou expiração numa fase específica da identidade canónica. A orientação oficial de Plymouth associa respiração relaxada e contínua a uma variante orientada ao tronco. A decisão conservadora é respirar naturalmente, sem retenção, sem contagens e sem sincronização obrigatória.

### Amplitude

As fontes clínicas usam limites dependentes do contexto, incluindo conforto, amplitude máxima pós-operatória ou orientação do fisioterapeuta. Nenhum destes limites é universalizável. O conteúdo usa apenas a amplitude tolerada em que permanecem contacto, alinhamento e controlo, respeitando a fronteira canónica que separa amplitude individual de identidade.

### Segurança

Foram preservados os sinais canónicos: dor aguda, bloqueio articular, perda súbita de controlo, tontura ou mal-estar. A superfície tem de suportar o corpo em decúbito dorsal e permitir deslizamento controlado. O deslizador opcional é rejeitado quando aumenta o risco de fuga do calcanhar.

### Supervisão

O exercício continua sem supervisão obrigatória e sem observador. A demonstração e observação usadas nos estudos apoiam a utilidade de verificar a técnica, mas não justificam supervisão universal. Mantêm-se como gatilhos:

- incapacidade de manter o apoio previsto;
- medo de queda;
- sintomas durante a amplitude;
- dificuldade em distinguir o movimento-alvo da compensação.

Cirurgia recente, retorno à função, sintomas persistentes e instabilidade conhecida continuam sujeitos a revisão própria.

## Decisões editoriais

1. Conteúdo em português europeu, Unicode NFC e vocabulário acessível.
2. Sete passos de execução, seis pistas principais e seis erros estruturados.
3. Teste de compreensão com doze perguntas.
4. Nenhuma dose, carga, duração, ritmo, frequência ou progressão programada.
5. Nenhuma promessa de eficácia, diagnóstico, tratamento ou autorização universal.
6. Nenhuma assistência manual adicionada, por ser incompatível com a distinção canónica.
7. Nenhuma alteração a identidade, risco, equipamento, superfície, supervisão ou relações.

## Confiança e limites

Confiança alta na identidade, posição e mecânica principal; moderada a alta em segurança e supervisão; moderada na respiração por ausência de evidência fase a fase específica.

Grande parte da orientação oficial disponível está inserida em contextos pós-operatórios. A fonte respiratória descreve uma variante orientada ao tronco. Esses materiais foram usados apenas onde convergem com a identidade canónica. A literatura primária consultada apoia posição, observação da qualidade e aprendizagem, mas não valida todos os erros possíveis nem um limite universal de amplitude.

Não permanecem dúvidas materiais sobre a descrição pública básica. Permanecem deliberadamente não estabelecidos um padrão respiratório fase a fase e um limite universal de amplitude.
