# Relatório de investigação — lançamento parado de basquetebol ao cesto

**Agente:** EX-42  
**Exercício:** `basketball_set_shot_to_basket`  
**Data de consulta:** 2026-07-24  
**Implementação realizada: não**

## Âmbito e decisão

Foi investigada a execução técnica para principiantes, a preparação da bola e do cesto, a respiração, a segurança, os erros observáveis e a supervisão. A investigação não altera a identidade, o risco, o equipamento, o alvo, o espaço nem as relações canónicas.

O conteúdo resultante preserva:

- lançamento a partir de base estabelecida;
- ausência de drible, receção imediata e salto obrigatório;
- risco operacional baixo;
- bola e cesto de basquetebol como equipamento obrigatório;
- alvo obrigatório, sem parceiro ou spotter obrigatório;
- supervisão recomendada;
- superfície firme, nivelada e antiderrapante;
- espaço estacionário moderado, folga superior e lateral e área de ressalto livre;
- duas relações compatíveis de treino principal e uma relação condicional de aquecimento.

## Fontes consultadas

### F1S03 — FIBA WABC Coaches Manual Level 1

Fonte oficial primária de formação de treinadores:  
https://assets.fiba.basketball/image/upload/documents-corporate-wabc-coaching-level-manuals-level-1-eng.pdf

Elementos sustentados:

- equilíbrio como fundação do lançamento;
- força iniciada pela extensão das pernas;
- mão de lançamento por baixo ou atrás da bola;
- mão não dominante ao lado;
- cotovelo sob a bola;
- alvo observado por baixo da bola;
- libertação alta, flexão relaxada do punho e rotação para trás;
- mão-guia sem empurrar;
- instrução inicial simples e sem excesso de detalhes.

Limite: o manual reconhece variação entre lançadores; os pontos técnicos foram tratados como referências, não como uma única forma rígida. Exemplos de progressão, alvo adaptado e prática não foram convertidos em dose.

### F2-S05 — USA Basketball Youth Development Guidebook

Fonte oficial primária de uma federação nacional:  
https://cdn1.sportngin.com/attachments/document/0095/3630/200.30_16.3.24_USA_BASKETBALL_YOUTH_DEVELOPMENT_GUIDEBOOK.pdf

Elementos sustentados:

- base confortável aproximadamente à largura dos ombros;
- pé do lado de lançamento ligeiramente avançado;
- foco visual no alvo;
- mão de lançamento sob a bola e mão-guia lateral;
- coordenação das pernas com o braço;
- forma de lançamento sem salto;
- punho, dedos e seguimento.

Limite: o guia é orientado para desenvolvimento juvenil. Distâncias, progressões e rotinas temporizadas presentes na fonte foram excluídas por serem prescrição.

### F1S04 — Basketball England, Jr. NBA & Jr. WNBA League Briefing Pack

Fonte oficial independente de federação nacional:  
https://basketballengland.co.uk/files/jr-nba-amp-jr-wnba-league-briefing-pack-040326105827.pdf

Elementos sustentados:

- prioridade à forma correta no ensino inicial;
- escolha de uma posição próxima do alvo quando isso é prescrito para permitir boa técnica;
- intervenção do treinador para corrigir compreensão e forma;
- comunicação simples para não sobrecarregar o principiante.

Limite: o documento inclui planos, tempos e progressões juvenis; esses elementos não foram importados.

### EX42-WEB-01 — FIBA Official Basketball Rules 2024: Basketball Equipment

Regulamento oficial de equipamento:  
https://assets.fiba.basketball/image/upload/documents-corporate-fiba-official-rules-2024-official-basketball-rules-and-basketball-equipment.pdf

Elementos sustentados:

- superfície da bola com aderência apropriada em toda a esfera;
- marcação da pressão ou intervalo de pressão recomendado;
- acessórios da rede sem arestas nem aberturas que prendam dedos;
- suporte, acolchoamento e construção do cesto orientados para a segurança.

Limite: é uma especificação de competição. Não permite certificar equipamento doméstico por observação. O conteúdo público limita-se a verificar danos visíveis, respeitar a indicação do fabricante e não usar equipamento instável.

## Síntese técnica adotada

O núcleo comum das fontes é uma sequência simples:

1. estabelecer equilíbrio e orientar-se para o alvo;
2. organizar a mão de lançamento por baixo ou atrás da bola e a mão-guia ao lado;
3. elevar a bola com o cotovelo sob a bola;
4. transferir força das pernas para o braço;
5. libertar num ponto alto e confortável, com punho relaxado e rotação para trás;
6. não deixar a mão-guia empurrar;
7. manter foco e seguimento;
8. recuperar equilíbrio antes de procurar o ressalto.

Não foi introduzido um salto, porque a identidade diz expressamente que não é obrigatório. Também não foram fixadas distância ou cadência.

## Respiração

Não foi localizado um protocolo respiratório específico para o lançamento parado nas fontes FIBA, USA Basketball ou Basketball England consultadas. Aplicou-se a regra conservadora do contrato: respiração natural e contínua, sem retenção. Uma expiração suave durante a extensão e a libertação é apresentada como opção confortável, não como contagem ou requisito.

## Segurança e preparação

Os riscos canónicos principais são ressalto da bola e colisão em espaço partilhado. Por isso, o conteúdo enfatiza:

- inspeção visual da bola e do cesto;
- área de ressalto livre;
- turnos claros quando várias pessoas usam o cesto;
- piso seco, firme e antiderrapante;
- folga superior e lateral;
- não recuperar a bola antes de observar a trajetória;
- não subir, pendurar-se ou reparar o cesto;
- interrupção perante pessoa ou bola na zona, dor aguda, tontura ou colisão provável.

Estas medidas operacionalizam o risco baixo sem o diminuir nem criar autorização universal.

## Erros cobertos

Foram incluídos seis erros com reconhecimento e correção:

1. iniciar sem base estabelecida;
2. empurrar com a mão-guia;
3. apertar a bola e bloquear o punho;
4. usar quase só os braços;
5. cruzar a bola ou perder alinhamento;
6. entrar cedo na área de ressalto.

Cada correção é técnica e observável, sem prescrição de dose.

## Supervisão

A supervisão permanece `recommended`, sem spotter obrigatório. A recomendação ganha prioridade em primeira exposição técnica, equipamento não familiar, espaço partilhado, jovens e pessoas que necessitem de comunicação adaptada. A FIBA atribui aos treinadores responsabilidade pela proteção de jovens e pela adaptação do ensino ao indivíduo; isto sustenta supervisão pedagógica e organização do espaço, não vigilância clínica.

## Relações preservadas

| Relação | Estado | Papel | Bucket |
|---|---|---|---|
| `basketball_set_shot_to_basket__main_training__technique_skill__isolated_technical_practice__develop_isolated_technical_component` | `compatible` | `principal_candidate` | `implementation_ready_relations` |
| `basketball_set_shot_to_basket__main_training__technique_skill__target_oriented_precision__improve_target_accuracy` | `compatible` | `alternative_primary` | `implementation_ready_relations` |
| `basketball_set_shot_to_basket__warmup__technique_skill__target_oriented_precision__prepare_target_control` | `conditional` | `principal_candidate` | `implementation_deferred_conditional_relations` |

Não foram criadas relações novas. A relação de aquecimento continua condicional e dependente do motor de elegibilidade.

## Confiança e limites

Confiança global: moderada-alta. A técnica tem apoio concordante de FIBA e USA Basketball; a segurança do equipamento tem apoio regulamentar direto. A respiração fica com confiança moderada devido à ausência de protocolo específico.

O conteúdo:

- não é prescrição individual;
- não inclui dose, carga, distância fixa, intensidade, ritmo, frequência ou progressão programada;
- não promete acerto nem melhoria;
- não diagnostica, trata ou concede autorização universal;
- não aprova media;
- não implementa código nem publica conteúdo.

Campos por resolver: nenhum.
