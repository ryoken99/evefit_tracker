# Balanço lateral da perna

Conteúdo para principiantes em português europeu.

## Descrição curta

Oscilação ativa e controlada de uma perna para os lados, de pé sobre a outra perna.

## O que é

De pé, o peso fica sobre uma perna enquanto a outra se desloca para fora e para dentro pela anca. A pelve mantém-se orientada para a frente e a perna livre é travada antes de cada mudança de direção.

## O que vais fazer

Vais criar espaço à tua volta, organizar um apoio estável, levantar ligeiramente uma perna e fazê-la oscilar lateralmente como um pêndulo controlado. A amplitude termina onde ainda consegues manter o tronco e a pelve estáveis e inverter a direção sem um puxão.

## Porque existe este movimento

Este movimento existe para praticar a entrada e a saída controladas de uma amplitude dinâmica da anca, com alongamento e encurtamento alternados das regiões medial e lateral. Pode integrar os contextos já aprovados de aquecimento, treino principal ou prevenção, sempre dentro dos limites da relação aplicável; não garante um resultado nem previne lesões por si só.

## Antes de começares

1. Confirma que tens espaço lateral livre para toda a trajetória da perna, sem pessoas, móveis, equipamento, animais ou trânsito.
2. Escolhe uma superfície estável e antiderrapante; não uses uma superfície solta, inclinada, escorregadia ou instável.
3. Se o equilíbrio não for seguro sem ajuda, posiciona-te junto de um apoio estável que não deslize nem oscile.
4. Confirma que consegues ficar de pé sobre uma perna ou usar o apoio manual e que consegues parar voluntariamente o movimento.
5. Não inicies se já existir dor aguda, dormência, formigueiro, fraqueza súbita, mal-estar ou uma sensação de instabilidade que impeça o controlo.

## Preparar o equipamento

1. Não é obrigatório equipamento portátil.
2. Um apoio estável autónomo é opcional. Coloca-o à frente, suficientemente perto para pousares uma ou ambas as mãos sem inclinar o tronco.
3. Antes de começares, testa o apoio com uma pressão leve. Não uses cadeiras com rodas, objetos soltos ou mobiliário que possa tombar.
4. O apoio serve apenas para equilíbrio; não o puxes nem uses uma pessoa como apoio improvisado.

## Preparar o espaço

1. Usa um local interior ou exterior com piso firme, regular e antiderrapante.
2. Reserva espaço à frente e, sobretudo, para ambos os lados da perna livre.
3. Retira obstáculos do trajeto e não executes junto de trânsito ativo.
4. Garante iluminação suficiente para veres o chão e o limite do espaço.
5. Se o frio alterar o conforto, a sensibilidade ou a capacidade de controlar a amplitude, não avances para uma oscilação maior.

## Verificação do corpo

1. Consegues transferir o peso para uma perna sem o pé de apoio deslizar?
2. Consegues manter-te direito com a ajuda escolhida, sem agarrar com força excessiva?
3. Consegues levantar ligeiramente a perna livre e voltar a pousá-la de forma deliberada?
4. Consegues fazer um pequeno movimento lateral e pará-lo antes de a pelve rodar?
5. A sensação é de esforço e alongamento toleráveis, sem dor articular, dor aguda ou sintomas neurológicos?

## Posição inicial

Fica de pé, virado para a frente e, se necessário, de frente para um apoio estável. Coloca o peso sobre uma perna, mantém o joelho de apoio desbloqueado e o pé totalmente assente. Alonga o tronco sem o tornar rígido, mantém a pelve orientada para a frente e deixa a outra perna ligeiramente afastada do chão, pronta para se mover pela anca.

## Confirmar a posição inicial

1. Pé de apoio totalmente assente e sem risco de deslizar.
2. Joelho de apoio desbloqueado, sem colapsar para dentro.
3. Tronco alto e ombros aproximadamente nivelados.
4. Pelve orientada para a frente.
5. Perna livre sem tocar no chão ou no pé de apoio.
6. Mão ou mãos pousadas levemente num apoio estável, se necessário.
7. Trajeto lateral completamente livre.

## Passos de execução

1. Transfere o peso para a perna de apoio e confirma que o tronco permanece estável antes de levantar a perna livre.
2. Inicia com uma oscilação lateral pequena da perna livre, movendo-a a partir da anca e mantendo a pelve voltada para a frente.
3. Leva a perna para fora apenas até ao ponto em que ainda consegues manter o tronco alto, o pé de apoio firme e a trajetória sem dor.
4. Desacelera ativamente a perna antes do limite e inverte a direção sem ressalto nem puxão.
5. Deixa a perna regressar para dentro e, se o espaço e o controlo o permitirem, atravessar ligeiramente à frente da perna de apoio sem lhe tocar.
6. Trava novamente antes de a rotação da pelve, a inclinação do tronco ou o impulso substituírem o movimento da anca.
7. Continua a alternar as duas direções apenas enquanto cada mudança de sentido for deliberada e a respiração se mantiver natural.
8. Para terminar, reduz a oscilação, imobiliza a perna junto ao centro e pousa o pé livre de forma controlada.

## Fases do movimento

### Organização do apoio

O peso fica sobre uma perna, com apoio manual opcional, pé firme e trajeto livre.

### Saída lateral

A perna livre afasta-se pela anca enquanto o tronco e a pelve permanecem orientados.

### Travagem exterior

A perna desacelera antes de a amplitude exigir rotação pélvica, inclinação do tronco ou perda de equilíbrio.

### Regresso e passagem interior

A perna regressa para dentro, podendo cruzar ligeiramente a frente do corpo sem colisão e dentro da amplitude controlável.

### Travagem interior e inversão

A perna volta a desacelerar e muda de direção sem ressalto.

### Saída

A oscilação diminui, a perna para e o pé regressa ao chão antes de o apoio manual ser libertado.

## Respiração

Respira de forma natural, regular e contínua durante toda a oscilação. Não existe uma fase respiratória obrigatória para este movimento e não é necessário coordenar a respiração com uma contagem. Evita prender a respiração; se deixares de conseguir respirar confortavelmente, reduz a amplitude ou termina de forma controlada.

## Sensações esperadas

1. Alongamento dinâmico ligeiro a moderado na região interna da anca quando a perna se afasta.
2. Alongamento dinâmico na região lateral da anca e nádega quando a perna regressa para dentro.
3. Trabalho de equilíbrio na anca e na perna de apoio.
4. Ativação do tronco para limitar a inclinação e a rotação.
5. Sensação de aceleração e travagem da perna livre sem impacto.

## Sensações inesperadas ou de alerta

1. Dor aguda, crescente ou localizada na anca, virilha, joelho, tornozelo ou costas.
2. Dormência, formigueiro, alteração súbita da sensibilidade ou fraqueza súbita.
3. Tonturas, visão alterada, falta de ar desproporcionada ou mal-estar.
4. Sensação de que o pé de apoio escorrega ou de que o joelho ou a anca deixam de sustentar o corpo.
5. Puxão brusco, estalido associado a dor ou incapacidade de travar a perna.
6. Colisão ou quase colisão com o apoio, o pé de base ou o ambiente.

## Indicações técnicas principais

1. Pé de apoio firme.
2. Pelve virada para a frente.
3. Move a perna pela anca.
4. Trava antes de mudar de direção.
5. Usa apenas a amplitude que consegues parar.
6. Tronco alto e respiração contínua.

## Erros comuns e correções

### Erro 1: Rodar a pelve para aparentar uma amplitude maior.

- Como reconhecer: O umbigo e a bacia deixam de apontar para a frente, e o movimento parece vir do corpo inteiro.
- Como corrigir: Diminui a amplitude e imagina os dois pontos da frente da bacia voltados para a frente enquanto a perna se move pela anca.

### Erro 2: Usar impulso crescente e deixar a perna fugir.

- Como reconhecer: Cada oscilação fica maior ou mais difícil de parar, e a mudança de direção acontece como um puxão.
- Como corrigir: Volta a uma oscilação menor e desacelera conscientemente antes de cada inversão.

### Erro 3: Inclinar ou balançar excessivamente o tronco.

- Como reconhecer: Os ombros deslocam-se de um lado para o outro para compensar a perna.
- Como corrigir: Usa o apoio manual, reduz a amplitude e mantém a cabeça e o peito empilhados sobre a perna de apoio.

### Erro 4: Não reservar espaço lateral suficiente.

- Como reconhecer: O pé passa perto de móveis, pessoas, equipamento, animais ou do próprio apoio.
- Como corrigir: Interrompe, pousa o pé e muda para um local com todo o trajeto livre antes de reiniciar.

### Erro 5: Prender a respiração para criar rigidez.

- Como reconhecer: A face e os ombros ficam tensos e a expiração só acontece depois de várias oscilações.
- Como corrigir: Reduz a amplitude e deixa o ar entrar e sair livremente, sem contagem nem retenção.

## Formas de simplificar ou ensaiar

1. Usa um apoio estável à frente e pousa ambas as mãos com leveza.
2. Faz uma trajetória pequena que consigas travar com facilidade; não precisas de cruzar a linha média.
3. Pousa o pé livre entre oscilações para recuperar a organização do apoio, sem transformar isso numa exigência de dose.
4. Mantém a ponta do pé livre perto do chão para reduzir as consequências de uma perda de equilíbrio.
5. Se o controlo continuar insuficiente mesmo com apoio, não realizes a oscilação sem orientação adequada.

## Supervisão

A execução-base não exige parceiro, observador nem supervisão. Considera orientação de um profissional qualificado quando seja a primeira exposição e a posição pareça complexa, quando exista historial de lesão ou cirurgia, condição crónica relevante, retorno funcional, gravidez ou pós-parto, deficiência, hipermobilidade, sedentarismo prévio ou idade avançada que altere o equilíbrio ou a elegibilidade. Amplitude extrema, assistência humana e sintomas que alterem a segurança são gatilhos para supervisão ou revisão; não uses outra pessoa como apoio improvisado.

## Como terminar

Reduz deliberadamente a amplitude até a perna ficar perto do centro. Pára a perna antes de pousar o pé livre. Coloca o pé no chão e recupera uma base estável com os dois pés. Só depois liberta o apoio manual e afasta-te do equipamento. Se terminares por perda de controlo, pousa o pé assim que for seguro e não tentes completar outra oscilação.

## Nota de segurança

O risco operacional mantém-se moderado devido ao apoio unipodal, ao impulso da perna livre e à possibilidade de colisão. Interrompe perante dor aguda ou crescente, perda de equilíbrio, mal-estar, alteração súbita de força ou sensibilidade, colisão iminente ou incapacidade de travar a perna dentro do espaço disponível.

## Quando parar ou reduzir

1. A pelve roda, o tronco inclina-se ou o pé de apoio deixa de ficar firme. — Reduz a amplitude; se o controlo não regressar, pousa o pé e termina.
2. A perna ganha velocidade ou amplitude sem conseguires travá-la. — Interrompe a oscilação de forma gradual e volta a uma base com dois pés.
3. Surge dor aguda ou crescente. — Pára e não forces a amplitude.
4. Surge dormência, formigueiro, fraqueza súbita, tontura ou mal-estar. — Termina o exercício e procura avaliação adequada se o sintoma for novo, intenso, persistente ou preocupante.
5. O pé aproxima-se de um obstáculo, pessoa ou apoio. — Pára, pousa o pé e reorganiza o espaço antes de considerar reiniciar.

## Segurança do equipamento

Sem equipamento portátil obrigatório; não acrescentes carga ou elásticos a esta execução-base. Se usares o apoio opcional, confirma que é estável, não tem rodas e não pode tombar ou deslizar. Mantém os dedos afastados de articulações, bordos móveis ou zonas onde possam ficar presos. Não puxes o apoio e não dependas de uma pessoa para travar uma perda de equilíbrio.

## Segurança do espaço

Superfície estável, regular e antiderrapante. Espaço lateral e frontal livre de obstáculos em toda a amplitude. Sem trânsito ativo nem passagem de outras pessoas pelo trajeto. Iluminação suficiente e apoio claramente visível. No exterior, verifica humidade, areia, gravilha, gelo, irregularidades e frio que possam alterar aderência, sensibilidade ou controlo.

## Limitações

1. Não foi identificada literatura primária que valide diretamente toda a execução do balanço lateral da perna descrita neste documento.
2. As fontes científicas estudam protocolos com participantes, músculos, amplitudes e doses próprios; os resultados não são transferidos como promessa.
3. O conteúdo não determina elegibilidade individual, não diagnostica, não trata e não substitui avaliação profissional quando existam sintomas, historial relevante ou limitações de equilíbrio.
4. Não contém dose, carga, duração, frequência, progressão programada nem autorização universal para executar.
5. A relação de prevenção permanece condicional e não implica promessa de prevenção de lesão.
6. Implementação realizada: não

## Teste de compreensão

### 1. Qual é a perna que se move durante o exercício?

Resposta esperada: A perna livre; a outra suporta o peso do corpo.

### 2. Em que direção se desloca a perna livre?

Resposta esperada: Para fora e para dentro, num trajeto lateral controlado.

### 3. De onde deve partir principalmente o movimento?

Resposta esperada: Da articulação da anca.

### 4. O que deve acontecer à pelve durante a oscilação?

Resposta esperada: Deve manter-se orientada para a frente, sem rodar para criar amplitude.

### 5. Como sabes que a amplitude ficou demasiado grande?

Resposta esperada: Quando já não consegues travar a perna ou quando a pelve roda, o tronco inclina ou o equilíbrio se perde.

### 6. É obrigatório usar um apoio manual?

Resposta esperada: Não, mas um apoio estável é opcional e deve ser usado se for necessário para manter o equilíbrio.

### 7. Que tipo de superfície é adequada?

Resposta esperada: Uma superfície estável, regular e antiderrapante.

### 8. Como deve ser feita cada mudança de direção?

Resposta esperada: Desacelerando e travando ativamente antes de inverter, sem ressalto nem puxão.

### 9. Como deves respirar?

Resposta esperada: De forma natural, regular e contínua, sem prender a respiração nem seguir uma contagem obrigatória.

### 10. Indica dois sinais que obrigam a interromper.

Resposta esperada: Por exemplo: dor aguda ou crescente, dormência, formigueiro, fraqueza súbita, mal-estar, perda de equilíbrio, colisão iminente ou incapacidade de travar.

### 11. Como terminas o exercício em segurança?

Resposta esperada: Reduzes a oscilação, paras a perna, pousas o pé e recuperas uma base estável antes de largar o apoio.

### 12. Este exercício garante prevenção de lesões ou um resultado específico?

Resposta esperada: Não. A relação de prevenção é condicional e o exercício não garante resultados.

## Fontes e limites da evidência

### Fonte 1: Pacote canónico EX-33 — lateral_leg_swing

- Autor ou entidade: canonical_input — fonte canónica interna — Pacote canónico EX-33 — lateral_leg_swing — sem URL externa — 2026-07-24 — Identidade, risco moderado, equipamento opcional, superfície, elegibilidade, sinais de interrupção e relações aprovadas. — D1-CAN-01 D1-CAN-03 D1-EXT-04 D1-EXT-24 D2-S07 D2-S08 D2-S27
- Tipo: fonte canónica interna
- Localizador: sem URL externa
- Usada para: canonical_input — fonte canónica interna — Pacote canónico EX-33 — lateral_leg_swing — sem URL externa — 2026-07-24 — Identidade, risco moderado, equipamento opcional, superfície, elegibilidade, sinais de interrupção e relações aprovadas. — D1-CAN-01 D1-CAN-03 D1-EXT-04 D1-EXT-24 D2-S07 D2-S08 D2-S27
- Limite: canonical_input — fonte canónica interna — Pacote canónico EX-33 — lateral_leg_swing — sem URL externa — 2026-07-24 — Identidade, risco moderado, equipamento opcional, superfície, elegibilidade, sinais de interrupção e relações aprovadas. — D1-CAN-01 D1-CAN-03 D1-EXT-04 D1-EXT-24 D2-S07 D2-S08 D2-S27

### Fonte 2: Dynamic Warm-ups for Athletes: Exercises for Sports Performance

- Autor ou entidade: nasm_dynamic_warmups — fonte profissional — Dynamic Warm-ups for Athletes: Exercises for Sports Performance — https://blog.nasm.org/dynamic-warm-ups-for-athletes-injury-prevention-and-sports-performance-benefits — 2026-07-24 — Apoio estável, balanço lateral pendular controlado, tronco alto e estabilidade do tronco.
- Tipo: fonte profissional
- Localizador: https://blog.nasm.org/dynamic-warm-ups-for-athletes-injury-prevention-and-sports-performance-benefits
- Usada para: nasm_dynamic_warmups — fonte profissional — Dynamic Warm-ups for Athletes: Exercises for Sports Performance — https://blog.nasm.org/dynamic-warm-ups-for-athletes-injury-prevention-and-sports-performance-benefits — 2026-07-24 — Apoio estável, balanço lateral pendular controlado, tronco alto e estabilidade do tronco.
- Limite: nasm_dynamic_warmups — fonte profissional — Dynamic Warm-ups for Athletes: Exercises for Sports Performance — https://blog.nasm.org/dynamic-warm-ups-for-athletes-injury-prevention-and-sports-performance-benefits — 2026-07-24 — Apoio estável, balanço lateral pendular controlado, tronco alto e estabilidade do tronco.

### Fonte 3: DYNAMIC WARM UP Forward and Lateral Leg Swings

- Autor ou entidade: special_olympics_leg_swings — fonte oficial desportiva — DYNAMIC WARM UP Forward and Lateral Leg Swings — https://resources.specialolympics.org/sports-essentials/sports-and-coaching/warm-up-and-cool-down-videos/dynamic-warm-up-forward-and-lateral-leg-swings — 2026-07-24 — Confirma o balanço lateral da perna como exercício de aquecimento dinâmico reconhecido; a página não fornece detalhe suficiente para sustentar todos os passos.
- Tipo: fonte oficial desportiva
- Localizador: https://resources.specialolympics.org/sports-essentials/sports-and-coaching/warm-up-and-cool-down-videos/dynamic-warm-up-forward-and-lateral-leg-swings
- Usada para: special_olympics_leg_swings — fonte oficial desportiva — DYNAMIC WARM UP Forward and Lateral Leg Swings — https://resources.specialolympics.org/sports-essentials/sports-and-coaching/warm-up-and-cool-down-videos/dynamic-warm-up-forward-and-lateral-leg-swings — 2026-07-24 — Confirma o balanço lateral da perna como exercício de aquecimento dinâmico reconhecido; a página não fornece detalhe suficiente para sustentar todos os passos.
- Limite: special_olympics_leg_swings — fonte oficial desportiva — DYNAMIC WARM UP Forward and Lateral Leg Swings — https://resources.specialolympics.org/sports-essentials/sports-and-coaching/warm-up-and-cool-down-videos/dynamic-warm-up-forward-and-lateral-leg-swings — 2026-07-24 — Confirma o balanço lateral da perna como exercício de aquecimento dinâmico reconhecido; a página não fornece detalhe suficiente para sustentar todos os passos.

### Fonte 4: Dynamic Stretching Exercises

- Autor ou entidade: kansas_dynamic_stretching — fonte profissional de sistema de saúde — Dynamic Stretching Exercises — https://www.kansashealthsystem.com/news-room/blog/0001/01/dynamic-stretching-exercises — 2026-07-24 — Oscilações pequenas antes de maiores conforme tolerado, controlo, conforto e não forçar demasiado.
- Tipo: fonte profissional de sistema de saúde
- Localizador: https://www.kansashealthsystem.com/news-room/blog/0001/01/dynamic-stretching-exercises
- Usada para: kansas_dynamic_stretching — fonte profissional de sistema de saúde — Dynamic Stretching Exercises — https://www.kansashealthsystem.com/news-room/blog/0001/01/dynamic-stretching-exercises — 2026-07-24 — Oscilações pequenas antes de maiores conforme tolerado, controlo, conforto e não forçar demasiado.
- Limite: kansas_dynamic_stretching — fonte profissional de sistema de saúde — Dynamic Stretching Exercises — https://www.kansashealthsystem.com/news-room/blog/0001/01/dynamic-stretching-exercises — 2026-07-24 — Oscilações pequenas antes de maiores conforme tolerado, controlo, conforto e não forçar demasiado.

### Fonte 5: Stretching and flexibility

- Autor ou entidade: mayo_stretching_breathing — fonte clínica profissional — Stretching and flexibility — https://www.mayoclinic.org/healthy-lifestyle/fitness/basics/stretching-and-flexibility/hlv-20049447 — 2026-07-24 — Respiração livre sem retenção e distinção entre sensação de alongamento e dor; a orientação não é específica do balanço lateral.
- Tipo: fonte clínica profissional
- Localizador: https://www.mayoclinic.org/healthy-lifestyle/fitness/basics/stretching-and-flexibility/hlv-20049447
- Usada para: mayo_stretching_breathing — fonte clínica profissional — Stretching and flexibility — https://www.mayoclinic.org/healthy-lifestyle/fitness/basics/stretching-and-flexibility/hlv-20049447 — 2026-07-24 — Respiração livre sem retenção e distinção entre sensação de alongamento e dor; a orientação não é específica do balanço lateral.
- Limite: mayo_stretching_breathing — fonte clínica profissional — Stretching and flexibility — https://www.mayoclinic.org/healthy-lifestyle/fitness/basics/stretching-and-flexibility/hlv-20049447 — 2026-07-24 — Respiração livre sem retenção e distinção entre sensação de alongamento e dor; a orientação não é específica do balanço lateral.

### Fonte 6: Dynamic Stretching Has Sustained Effects on Range of Motion and Passive Stiffness of the Hamstring Muscles

- Autor ou entidade: iwata_2019 — literatura primária — Dynamic Stretching Has Sustained Effects on Range of Motion and Passive Stiffness of the Hamstring Muscles — https://pmc.ncbi.nlm.nih.gov/articles/PMC6370952/ — 2026-07-24 — Sustenta a classificação geral como alongamento dinâmico ativo e a necessidade de não extrapolar efeitos de protocolos estudados para este exercício específico.
- Tipo: literatura primária
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC6370952/
- Usada para: iwata_2019 — literatura primária — Dynamic Stretching Has Sustained Effects on Range of Motion and Passive Stiffness of the Hamstring Muscles — https://pmc.ncbi.nlm.nih.gov/articles/PMC6370952/ — 2026-07-24 — Sustenta a classificação geral como alongamento dinâmico ativo e a necessidade de não extrapolar efeitos de protocolos estudados para este exercício específico.
- Limite: iwata_2019 — literatura primária — Dynamic Stretching Has Sustained Effects on Range of Motion and Passive Stiffness of the Hamstring Muscles — https://pmc.ncbi.nlm.nih.gov/articles/PMC6370952/ — 2026-07-24 — Sustenta a classificação geral como alongamento dinâmico ativo e a necessidade de não extrapolar efeitos de protocolos estudados para este exercício específico.

### Fonte 7: Effects of Dynamic Stretching with Different Loads on Hip Joint Range of Motion in the Elderly

- Autor ou entidade: zhou_2019 — literatura primária — Effects of Dynamic Stretching with Different Loads on Hip Joint Range of Motion in the Elderly — https://pmc.ncbi.nlm.nih.gov/articles/PMC6370971/ — 2026-07-24 — Informa a distinção entre movimento dinâmico sem carga externa e protocolos com carga; não sustenta prescrição nem resultados para o balanço lateral.
- Tipo: literatura primária
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC6370971/
- Usada para: zhou_2019 — literatura primária — Effects of Dynamic Stretching with Different Loads on Hip Joint Range of Motion in the Elderly — https://pmc.ncbi.nlm.nih.gov/articles/PMC6370971/ — 2026-07-24 — Informa a distinção entre movimento dinâmico sem carga externa e protocolos com carga; não sustenta prescrição nem resultados para o balanço lateral.
- Limite: zhou_2019 — literatura primária — Effects of Dynamic Stretching with Different Loads on Hip Joint Range of Motion in the Elderly — https://pmc.ncbi.nlm.nih.gov/articles/PMC6370971/ — 2026-07-24 — Informa a distinção entre movimento dinâmico sem carga externa e protocolos com carga; não sustenta prescrição nem resultados para o balanço lateral.

### Fonte 8: Acute Effects of Dynamic and Ballistic Stretching on Flexibility

- Autor ou entidade: matsuo_2025 — literatura primária — Acute Effects of Dynamic and Ballistic Stretching on Flexibility — https://pmc.ncbi.nlm.nih.gov/articles/PMC12131144/ — 2026-07-24 — Ajuda a manter a fronteira entre alongamento dinâmico controlado e execução balística com ressalto; não valida dose, segurança individual ou benefício deste exercício. — D1-EXT-24
- Tipo: literatura primária
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC12131144/
- Usada para: matsuo_2025 — literatura primária — Acute Effects of Dynamic and Ballistic Stretching on Flexibility — https://pmc.ncbi.nlm.nih.gov/articles/PMC12131144/ — 2026-07-24 — Ajuda a manter a fronteira entre alongamento dinâmico controlado e execução balística com ressalto; não valida dose, segurança individual ou benefício deste exercício. — D1-EXT-24
- Limite: matsuo_2025 — literatura primária — Acute Effects of Dynamic and Ballistic Stretching on Flexibility — https://pmc.ncbi.nlm.nih.gov/articles/PMC12131144/ — 2026-07-24 — Ajuda a manter a fronteira entre alongamento dinâmico controlado e execução balística com ressalto; não valida dose, segurança individual ou benefício deste exercício. — D1-EXT-24
