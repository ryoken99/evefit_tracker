# AUD-C — Auditoria independente de mobilidade

## Resultado

**Estado global: `passed_with_revisions`**

Não foram encontrados blockers, alterações de identidade, dose prescrita, promessas de resultado, diagnóstico, tratamento, redução de risco, novas relações ou implementação. As revisões exigidas concentram-se no pacote `seated_supported_thoracic_extension` e na coerência estrutural do conjunto JSON.

## Âmbito

Foram auditados todos e apenas os cinco exercícios cujo `capability_primary` é `mobility`:

1. `half_kneeling_ankle_dorsiflexion_rock` — EX-21
2. `active_ankle_circumduction` — EX-22
3. `supine_heel_slide` — EX-23
4. `seated_supported_thoracic_extension` — EX-24
5. `active_ankle_dorsiflexion_plantarflexion` — EX-25

Para cada exercício foram comparados o JSON de conteúdo, o Markdown público e o relatório de investigação, num total de 15 ficheiros. Os invariantes foram confirmados nos cinco pacotes correspondentes em `_beginner_content_workspace/agent_inputs`.

Não foram lidos relatórios de outros auditores.

## Método

- confirmação do âmbito por `capability_primary == mobility`;
- validação sintática dos cinco JSON;
- comparação de IDs, nome, entidade, família, variante/base e estado com o pacote de entrada;
- comparação de posição inicial, contactos, ação motora, trajetória, fases e regresso;
- revisão de clareza para principiante absoluto, passos, respiração, amplitude tolerada, compensações, erros e correções;
- revisão de risco, sinais de redução/interrupção, equipamento, superfície, ambiente e supervisão;
- verificação de ausência de dose, progressão programada, promessa, diagnóstico, tratamento e autorização universal;
- comparação semântica entre JSON, Markdown e relatório;
- validação do contrato comum: ordem das chaves, mínimos, forma dos erros e 12 perguntas de compreensão;
- comparação transversal entre os cinco exercícios.

## Estados por exercício

| Exercício | Estado | Fundamentação |
|---|---|---|
| `half_kneeling_ankle_dorsiflexion_rock` | `passed` | Identidade, meio-ajoelhado, pé totalmente apoiado, avanço/regresso, amplitude tolerada, risco moderado, tapete opcional, ambiente, supervisão e fronteira com o teste joelho-à-parede estão coerentes nos três artefactos e com EX-21. |
| `active_ankle_circumduction` | `passed` | Posição sentada, pé sem carga, trajetória circular pelo tornozelo, controlo de joelho/coxa, cadeira obrigatória, amplitude tolerada e ausência de impulso estão coerentes nos três artefactos e com EX-22. |
| `supine_heel_slide` | `passed` | Decúbito dorsal, contacto deslizante do calcanhar, flexão/extensão coordenada, controlo pélvico, opções de equipamento, fricção e supervisão estão coerentes nos três artefactos e com EX-23. |
| `seated_supported_thoracic_extension` | `passed_with_revisions` | A identidade e o núcleo técnico são preservados, mas há orientação respiratória específica sem suporte declarado, um requisito de encosto não reconciliado com o inventário canónico e insuficiente operacionalização da localização do fulcro para principiante. |
| `active_ankle_dorsiflexion_plantarflexion` | `passed` | Movimento sagital recíproco, posição sentada, pé livre, distinção da circundução, cadeira, ambiente, amplitude, respiração e supervisão estão coerentes nos três artefactos e com EX-25. |

Contagem de estados: `passed` 4; `passed_with_revisions` 1; `failed` 0.

## Findings — EX-24 `seated_supported_thoracic_extension`

### AUD-C-MOB-001

- **Severidade:** média
- **Blocker:** não
- **Campo:** `breathing_guidance_pt_pt`
- **Evidência:** o contrato de EX-24 determina em `contract.constraints.breathing` que orientação específica só deve ser documentada quando sustentada e, caso contrário, deve ser usada respiração natural e contínua sem retenção (`EX-24__seated_supported_thoracic_extension.json:610`). O relatório declara que não encontrou evidência específica suficiente para sincronização respiratória e que a formulação defensável é respiração natural, regular e contínua (`seated_supported_thoracic_extension_research_report_v0.1.md:57`). Apesar disso, o JSON e o Markdown acrescentam “deixa a expiração acompanhar a inclinação para trás e inspira no regresso” (`...beginner_content_v0.1.json:96`; `...beginner_content_v0.1.md:69`).
- **Revisão exigida:** remover a associação faseada entre expiração/inclinação e inspiração/regresso, mantendo apenas respiração natural, regular e contínua sem retenção; ou apresentar suporte técnico específico para essa sincronização e atualizar coerentemente relatório, JSON e Markdown.

### AUD-C-MOB-002

- **Severidade:** média
- **Blocker:** não
- **Campo:** `equipment_setup_pt_pt`, `starting_position_pt_pt`, invariantes de equipamento
- **Evidência:** o pacote canónico fecha o equipamento como `stable_chair_without_wheels` mais um grupo OU entre `firm_rolled_towel` e `foam_roller` (`EX-24__seated_supported_thoracic_extension.json:133-143`) e o contrato proíbe alterações de equipamento. O conteúdo torna adicionalmente obrigatório “um encosto capaz de manter o fulcro no lugar” e coloca o fulcro “entre o encosto” e as costas (`...beginner_content_v0.1.json:23-25,42`; `...beginner_content_v0.1.md:38`). A capacidade específica do encosto não está explicitada no inventário ou nas condições canónicas fornecidas.
- **Revisão exigida:** reconciliar a instrução com a fonte de verdade material. Remover o novo requisito universal de encosto se ele não fizer parte de `stable_chair_without_wheels`, ou documentar formalmente no pacote canónico que esse identificador inclui um encosto compatível antes de o exigir no conteúdo. A mesma decisão deve aparecer no JSON, Markdown e relatório.

### AUD-C-MOB-003

- **Severidade:** média
- **Blocker:** não
- **Campo:** `starting_position_pt_pt`, `equipment_setup_pt_pt`, `principal_cues_pt_pt`, segurança do fulcro
- **Evidência:** o pacote classifica a procura de precisão como `high` e inclui “fulcro mal posicionado” entre os fatores principais de risco (`EX-24__seated_supported_thoracic_extension.json:186,198-202`). Para um principiante absoluto, o conteúdo continua a localizar o fulcro apenas como “região média ou superior das costas, abaixo do pescoço e acima da região lombar” (`...beginner_content_v0.1.json:59,213`; `...beginner_content_v0.1.md:38,54`). A instrução repete nomenclatura anatómica ampla, mas não oferece uma verificação simples e observável que permita reconhecer uma colocação incorreta antes do arco.
- **Revisão exigida:** acrescentar uma referência de localização e uma verificação pré-movimento em linguagem leiga, sustentadas pelas fontes, e indicar explicitamente que a pessoa não deve iniciar sem conseguir distinguir a região torácica da lombar/cervical. Repetir o mesmo critério no JSON, Markdown e teste de compreensão.

## Finding transversal

### AUD-C-MOB-004

- **Severidade:** média
- **Blocker:** não
- **Campo:** coerência estrutural dos JSON
- **Evidência:** os cinco JSON são válidos e têm exatamente as chaves na ordem do contrato, mas campos homónimos apresentam formas incompatíveis entre exercícios. Exemplos: `equipment_setup_pt_pt` é string em EX-22/EX-23/EX-25, objeto em EX-21 e array em EX-24; `supervision_guidance_pt_pt` é objeto apenas em EX-25; `stop_or_reduce_signs_pt_pt` é objeto em EX-22 e array nos restantes; `exercise_detail_sections` é objeto em EX-22 e array nos restantes; `limitations_pt_pt` alterna entre string e array. Em EX-23, as fases usam `phase_id` enquanto as restantes usam `phase_pt_pt`; o teste de compreensão e os itens de fontes também têm formas diferentes. O contrato comum enumera chaves, mas não resolve estas variações de tipo.
- **Revisão exigida:** normalizar cada campo partilhado para uma forma única em todos os cinco JSON, preservando o conteúdo semântico, ou versionar o contrato com uniões de tipo e formas internas explicitamente permitidas. Uniformizar pelo menos fases, supervisão, sinais de interrupção, secções de detalhe, fontes, limitações, campos por resolver e teste de compreensão.

## Padrões observados

### Padrões conformes

- Os cinco exercícios preservam ID, nome, entidade, família, base/variante e `capability_primary`.
- As posições e ações motoras distinguem corretamente circundução, flexão dorsal/plantar, avanço em carga parcial, deslizamento do calcanhar e extensão torácica apoiada.
- Todos apresentam pelo menos cinco passos, quatro pistas e quatro erros com reconhecimento e correção.
- A amplitude é sempre delimitada por tolerância, controlo, contactos e compensações observáveis, sem ângulos ou metas universais.
- Os sinais canónicos de interrupção — dor aguda, bloqueio, perda súbita de controlo, tontura ou mal-estar — são preservados.
- Supervisão basal, spotter, populações de revisão e gatilhos de supervisão não foram reduzidos.
- Equipamento obrigatório/opcional e superfície estão preservados, com a ressalva de AUD-C-MOB-002.
- Não há dose fixa, carga, intensidade, ritmo, frequência ou progressão programada.
- Não há promessa de resultado, diagnóstico, tratamento ou autorização universal.
- Os relatórios distinguem evidência direta, evidência de família e limites clínicos; as versões Markdown são semanticamente consistentes com os JSON, salvo os findings indicados.

### Padrões a corrigir

- O EX-24 acrescenta especificidade respiratória apesar de declarar ausência de suporte específico.
- O EX-24 torna uma característica do encosto num requisito sem a reconciliar com o inventário canónico.
- O EX-24 exige elevada precisão anatómica sem uma verificação suficientemente concreta para principiante absoluto.
- O conjunto não tem formas JSON uniformes para vários campos partilhados.

## Contagens de conformidade

| Verificação | Resultado |
|---|---:|
| Exercícios de mobilidade auditados | 5/5 |
| Artefactos de conteúdo comparados | 15/15 |
| Pacotes de invariantes confirmados | 5/5 |
| JSON sintaticamente válidos | 5/5 |
| Ordem exata das chaves obrigatórias | 5/5 |
| Mínimo de 5 passos | 5/5 |
| Mínimo de 4 pistas | 5/5 |
| Mínimo de 4 erros com forma completa | 5/5 |
| Teste com 12 perguntas | 5/5 |
| Exercícios sem dose ou promessa | 5/5 |
| Findings | 4 |
| Findings blockers | 0 |
| Findings de severidade média | 4 |
| Findings de severidade alta/baixa | 0 |

## Independência e implementação

AUD-C atuou como auditor independente e não foi autor de nenhum dos conteúdos revistos. Não consultou relatórios de outros auditores e não editou JSON, Markdown, relatórios de investigação, pacotes de entrada ou qualquer outro conteúdo.

**Implementação realizada: zero.** O único artefacto produzido foi este relatório de auditoria.
