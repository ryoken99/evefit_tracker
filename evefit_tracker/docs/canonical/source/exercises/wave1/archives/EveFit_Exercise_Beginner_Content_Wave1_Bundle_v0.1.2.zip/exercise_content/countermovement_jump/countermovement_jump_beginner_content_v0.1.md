# Salto vertical com contramovimento

Conteúdo para principiantes em português europeu.

## Descrição curta

Salto vertical bipodal com uma descida preparatória contínua, impulsão imediata e aterragem controlada nos dois pés.

## O que é

Partes de pé, baixas o corpo através da anca, dos joelhos e dos tornozelos e inverte-se logo essa descida para projetar o corpo verticalmente. Depois da breve fase aérea, regressas ao solo com os dois pés e absorves a aterragem através dessas mesmas articulações. A continuidade entre a descida e a subida distingue este exercício do salto iniciado após uma pausa em agachamento.

## O que vais fazer

Vais organizar uma base bipodal estável, executar uma descida curta e coordenada, mudar de direção sem parar, empurrar o solo para saltar a direito e terminar numa receção bipodal estável.

## Porque existe este movimento

O movimento permite observar e praticar a coordenação entre travagem, inversão rápida da direção, projeção balística e receção do corpo. Esta finalidade técnica não garante qualquer resultado individual.

## Antes de começares

1. Confirma que compreendes como interromper a tarefa e que consegues seguir as indicações do profissional que observa a primeira exposição técnica.
2. Esta explicação não constitui autorização para praticar autonomamente no primeiro dia.
3. Não avances se existir dor aguda, mal-estar, perda de coordenação ou incapacidade de controlar uma descida e uma receção bipodais.
4. As pessoas em retorno funcional, grávidas ou no pós-parto, ou com doença crónica relevante devem obter a revisão adequada ao seu contexto antes de experimentar este exercício.
5. Escolhe, com o profissional, uma posição simples para os braços e mantém essa opção consistente; o balanço dos braços não é obrigatório nesta base.

## Preparar o equipamento

1. sim
2. Não é necessário equipamento. Retira objetos soltos do corpo e do chão que possam interferir com a impulsão ou a aterragem.

## Preparar o espaço

1. Usa uma superfície firme, plana, regular e antiderrapante.
2. Mantém a zona de impulsão e receção sem objetos, trânsito, pessoas a atravessar ou limites próximos.
3. Confirma espaço livre por cima da cabeça e visibilidade suficiente.
4. Não uses superfícies escorregadias, instáveis ou que se desloquem sob os pés.

## Verificação do corpo

1. Consegues permanecer de pé com o peso distribuído pelos dois pés sem oscilar de forma evidente.
2. Consegues fletir anca, joelhos e tornozelos numa descida simples mantendo os pés apoiados e os joelhos orientados com os pés.
3. Consegues regressar a uma posição estável sem dor, mal-estar ou perda súbita de coordenação.
4. Consegues demonstrar ao supervisor uma receção bipodal simples, silenciosa e controlada antes de acrescentar a fase aérea.

## Posição inicial

Fica de pé com os dois pés totalmente apoiados, aproximadamente à largura da anca, orientados para a frente ou ligeiramente para fora conforme a tua estrutura. Distribui o peso pelos dois lados, mantém o tronco organizado e olha em frente para um ponto estável. Coloca os braços na posição simples previamente definida com o profissional.

## Confirmar a posição inicial

1. Dois pés em contacto firme com o solo.
2. Peso distribuído pelos dois lados.
3. Ancas, joelhos e pés orientados de forma coerente.
4. Tronco estável, sem inclinação ou rotação excessiva.
5. Zona de receção e espaço superior livres.

## Passos de execução

1. Estabiliza a base bipodal e fixa o olhar em frente.
2. Desce o centro do corpo através de flexão coordenada da anca, dos joelhos e dos tornozelos, mantendo o tronco controlado.
3. Quando terminares a descida preparatória, muda imediatamente de direção sem fazer uma pausa deliberada.
4. Estende rapidamente anca, joelhos e tornozelos e empurra o solo para projetar o corpo para cima.
5. Mantém o corpo organizado durante a breve fase aérea e prepara os dois pés para regressarem à mesma zona.
6. Contacta o solo com os dois pés de forma quase simultânea e deixa o pé assentar de modo controlado.
7. Flete anca, joelhos e tornozelos para absorver a receção, mantendo os joelhos orientados com os pés.
8. Recupera uma posição de pé estável e confirma o controlo antes de terminar a ação.

## Fases do movimento

### Descida preparatória

A anca, os joelhos e os tornozelos fletam e travam a descida do corpo.

### Transição

A direção muda de descendente para ascendente sem pausa artificial.

### Propulsão

A extensão coordenada da anca, dos joelhos e dos tornozelos projeta o corpo verticalmente.

### Voo

Os dois pés deixam o solo e o corpo mantém uma trajetória predominantemente vertical.

### Receção e estabilização

Os dois pés regressam ao solo e a flexão coordenada absorve a carga até o corpo recuperar estabilidade.

## Respiração

Mantém a respiração natural e contínua. Se surgir espontaneamente, uma expiração curta durante a impulsão é aceitável; não imponhas uma contagem, uma inspiração profunda nem retenhas a respiração. A evidência consultada sustenta evitar a apneia no esforço, mas não estabelece um padrão respiratório específico e universal para um salto com contramovimento.

## Sensações esperadas

1. Esforço rápido nos músculos das pernas e das ancas durante a impulsão.
2. Breve sensação de leveza na fase aérea.
3. Carga curta e distribuída pelos dois membros inferiores na receção.
4. Trabalho muscular para travar o corpo e recuperar equilíbrio.

## Sensações inesperadas ou de alerta

1. Dor aguda ou dor que altera imediatamente a forma de mover.
2. Tontura, desmaio iminente, falta de ar invulgar ou mal-estar.
3. Sensação súbita de falha, cedência ou perda de coordenação.
4. Impacto que não consegues absorver ou repetida incapacidade de aterrar de forma estável.
5. Dormência ou outro sintoma neurológico súbito.

## Indicações técnicas principais

1. Desce e sobe como uma ação contínua.
2. Empurra o chão e salta a direito.
3. Sai e chega com os dois pés.
4. Aterra suave e silenciosamente.
5. Dobra anca, joelhos e tornozelos na receção.
6. Mantém os joelhos orientados com os pés.

## Erros comuns e correções

### Erro 1: Fazer uma pausa no fundo da descida.

- Como reconhecer: A descida termina, o corpo fica imóvel e só depois começa a impulsão.
- Como corrigir: Liga a descida à subida numa única ação; se ainda não for possível, ensaia a mudança de direção sem fase aérea sob observação.

### Erro 2: Deslocar o salto excessivamente para a frente.

- Como reconhecer: Os pés aterram claramente à frente da zona de partida ou é necessário perseguir o equilíbrio.
- Como corrigir: Mantém o olhar estável e pensa em empurrar o chão para cima, reduzindo a intenção de avançar.

### Erro 3: Deixar os joelhos aproximarem-se um do outro.

- Como reconhecer: Na descida ou na aterragem, um ou ambos os joelhos desviam-se para dentro relativamente aos pés.
- Como corrigir: Reduz a complexidade e mantém cada joelho orientado na mesma direção do respetivo pé, com feedback do supervisor.

### Erro 4: Aterrar com as pernas rígidas.

- Como reconhecer: A aterragem é ruidosa e há pouca flexão da anca, dos joelhos e dos tornozelos.
- Como corrigir: Pensa em aterrar suavemente e deixa as três articulações fletirem para aumentar o tempo de absorção.

### Erro 5: Aterrar de forma assimétrica.

- Como reconhecer: Um pé toca muito antes do outro, o tronco cai para um lado ou o peso fica claramente num único membro.
- Como corrigir: Interrompe o salto, recupera a base bipodal e regressa a um ensaio de receção mais simples com observação.

### Erro 6: Iniciar outra ação antes de recuperar controlo.

- Como reconhecer: O corpo volta a saltar ou a descer enquanto ainda oscila da aterragem anterior.
- Como corrigir: Termina cada salto numa posição estável; se precisas de um passo, considera a tentativa concluída e não voltes a saltar de imediato.

## Formas de simplificar ou ensaiar

1. Ensaiar apenas a base, a descida coordenada e a inversão para voltar a ficar de pé, sem tirar os pés do chão.
2. Ensaiar a posição de receção a partir de uma elevação mínima dos calcanhares, sob supervisão, antes de acrescentar uma fase aérea.
3. Usar uma intenção de salto baixa definida pelo supervisor enquanto se aprende a aterrar; isto é uma simplificação pedagógica, não uma dose nem uma nova identidade.
4. Manter os braços quietos numa posição simples para reduzir exigências de coordenação; o balanço dos braços continua a não ser parte obrigatória desta base.

## Supervisão

A supervisão profissional é recomendada devido ao impacto elevado e é especialmente importante na primeira exposição técnica, quando existe inexperiência, dificuldade de alinhamento, receção ruidosa, assimetria ou progressão para maior velocidade ou impacto. No primeiro dia, a leitura deste conteúdo não substitui observação, feedback nem decisão de elegibilidade; não pratiques autonomamente apenas com base nesta explicação.

## Como terminar

Depois da aterragem, estabiliza sobre os dois pés, deixa a respiração regressar ao padrão natural e sai da zona de execução a caminhar. Não encadeies outra tentativa enquanto o equilíbrio, a coordenação ou a atenção não estiverem restabelecidos.

## Nota de segurança

Este é um exercício balístico com fase aérea e impacto elevado. Confirma altura livre, zona de receção desimpedida e superfície firme, plana, regular e antiderrapante. Interrompe quando a aterragem deixa de ser suave, bipodal e controlada. O conteúdo é educativo e não constitui avaliação clínica nem autorização universal para executar.

## Quando parar ou reduzir

1. Dor aguda.
2. Mal-estar, tontura ou falta de ar invulgar.
3. Perda súbita de coordenação.
4. Incapacidade de controlar a travagem ou a receção.
5. Aterragem progressivamente ruidosa, rígida ou assimétrica.
6. Necessidade repetida de passos ou apoio externo para não cair.

## Segurança do equipamento

Não existe equipamento obrigatório nem equipamento alternativo necessário. Mantém calçado, roupa e objetos pessoais seguros e não acrescentes caixas, cargas, alvos, superfícies instáveis ou material improvisado, porque alterariam as condições de execução e o risco.

## Segurança do espaço

Executa apenas numa superfície firme, plana, regular e antiderrapante, com área de receção segura, espaço livre por cima e percurso sem obstáculos. Evita superfícies escorregadias ou instáveis, iluminação insuficiente, trânsito, pessoas a atravessar, calor ou frio que comprometam o controlo e qualquer local com altura livre insuficiente.

## Limitações

1. Este conteúdo documenta uma identidade técnica de risco operacional elevado e não prescreve repetições, séries, intensidade, frequência, carga, duração, progressão ou momento da sessão. Não avalia lesões, condições clínicas, prontidão individual nem segurança de um local concreto. A evidência sobre respiração não é específica do salto com contramovimento. A relação de aquecimento permanece condicional e dependente de lógica de produto futura. Implementação realizada: não
2. Limite documentado: Não existe evidência direta suficiente para impor uma sincronização respiratória universal neste exercício.
3. Limite documentado: A posição e o uso dos braços continuam opcionais na identidade base e devem ser definidos no contexto técnico sem criar prescrição.
4. Limite documentado: A relação de aquecimento mantém classificação condicional por lógica de produto ainda não resolvida.

## Teste de compreensão

### 1. O que distingue este salto de um salto iniciado após uma pausa em agachamento?

Resposta esperada: A descida preparatória muda imediatamente para a impulsão, sem pausa deliberada.

### 2. Qual deve ser a direção principal do corpo?

Resposta esperada: Para cima, numa trajetória predominantemente vertical.

### 3. Com quantos pés se faz a saída e a receção nesta base?

Resposta esperada: Com os dois pés.

### 4. Que articulações ajudam a absorver a aterragem?

Resposta esperada: A anca, os joelhos e os tornozelos.

### 5. Que sinais auditivos e visuais sugerem uma aterragem controlada?

Resposta esperada: Som discreto, flexão coordenada, alinhamento dos joelhos com os pés e estabilidade sem novo salto.

### 6. O balanço dos braços é obrigatório nesta identidade base?

Resposta esperada: Não; é uma opção técnica e deve manter-se coerente com a orientação do profissional.

### 7. Deves reter a respiração para produzir mais força?

Resposta esperada: Não; a respiração deve manter-se natural e contínua, sem retenção imposta.

### 8. O que fazes se precisares de um passo para recuperar a aterragem?

Resposta esperada: Usas o passo para ficar seguro, consideras a tentativa terminada e não saltas novamente de imediato.

### 9. Que superfície é exigida?

Resposta esperada: Firme, plana, regular e antiderrapante.

### 10. Que condições de espaço devem ser confirmadas?

Resposta esperada: Zona de receção desimpedida, espaço livre por cima e ausência de trânsito ou pessoas a atravessar.

### 11. Indica dois sinais que obrigam a interromper.

Resposta esperada: Por exemplo, dor aguda, mal-estar, perda súbita de coordenação ou incapacidade de controlar a receção.

### 12. Ler esta explicação autoriza prática autónoma no primeiro dia?

Resposta esperada: Não; a primeira exposição técnica deve ser observada e orientada por um profissional qualificado.

## Fontes e limites da evidência

### Fonte 1: Current Concepts of Plyometric Exercise

- Autor ou entidade: Davies, Riemann e Manske
- Tipo: Revisão clínica com arbitragem científica
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC4637913/
- Usada para: Mecânica do ciclo alongamento-encurtamento, exigência de preparação, controlo da aterragem e limites de segurança da família pliométrica.
- Limite: B1-S15 — Current Concepts of Plyometric Exercise — Davies, Riemann e Manske — Revisão clínica com arbitragem científica — https://pmc.ncbi.nlm.nih.gov/articles/PMC4637913/ — Mecânica do ciclo alongamento-encurtamento, exigência de preparação, controlo da aterragem e limites de segurança da família pliométrica. — Evidência de família; não valida uma dose nem a elegibilidade de uma pessoa concreta.

### Fonte 2: Plyometric Jump Training in Female Soccer Players

- Autor ou entidade: Ramirez-Campillo et al.
- Tipo: Revisão sistemática
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC9424421/
- Usada para: Contexto de evidência da família de treino de saltos.
- Limite: SP-B2-S30 — Plyometric Jump Training in Female Soccer Players — Ramirez-Campillo et al. — Revisão sistemática — https://pmc.ncbi.nlm.nih.gov/articles/PMC9424421/ — Contexto de evidência da família de treino de saltos. — População e intervenções específicas; não fornece autorização universal nem instrução respiratória.

### Fonte 3: Basics of Strength and Conditioning Manual

- Autor ou entidade: National Strength and Conditioning Association
- Tipo: Manual profissional
- Localizador: https://www.nsca.com/contentassets/48a12160221541acbdc048498d77192d/basics_of_strength_and_conditioning_manual.pdf
- Usada para: Sequência do salto vertical com contramovimento, ausência de pausa, extensão coordenada e aterragem suave com flexão da anca, dos joelhos e dos tornozelos.
- Limite: EX16-S1 — Basics of Strength and Conditioning Manual — National Strength and Conditioning Association — Manual profissional — https://www.nsca.com/contentassets/48a12160221541acbdc048498d77192d/basics_of_strength_and_conditioning_manual.pdf — Sequência do salto vertical com contramovimento, ausência de pausa, extensão coordenada e aterragem suave com flexão da anca, dos joelhos e dos tornozelos. — Manual geral de treino; a ilustração usa balanço de braços, que não foi tornado obrigatório nesta identidade.

### Fonte 4: Why is countermovement jump height greater than squat jump height?

- Autor ou entidade: Bobbert, Gerritsen, Litjens e Van Soest
- Tipo: Estudo biomecânico primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/8933491/
- Usada para: Distinção biomecânica entre salto com contramovimento e salto iniciado de posição estática, e importância da fase preparatória contínua.
- Limite: EX16-S2 — Why is countermovement jump height greater than squat jump height? — Bobbert, Gerritsen, Litjens e Van Soest — Estudo biomecânico primário — https://pubmed.ncbi.nlm.nih.gov/8933491/ — Distinção biomecânica entre salto com contramovimento e salto iniciado de posição estática, e importância da fase preparatória contínua. — Estudo mecanístico sobre desempenho; não testa segurança, principiantes ou respiração.

### Fonte 5: Simple verbal instruction improves knee biomechanics during landing in female athletes

- Autor ou entidade: Milner, Fairbrother, Srivatsan e Zhang
- Tipo: Estudo biomecânico primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/21676618/
- Usada para: Suporte experimental para o indicação técnica de aterragem suave, associado a menor pico de força vertical e maior flexão do joelho.
- Limite: EX16-S3 — Simple verbal instruction improves knee biomechanics during landing in female athletes — Milner, Fairbrother, Srivatsan e Zhang — Estudo biomecânico primário — https://pubmed.ncbi.nlm.nih.gov/21676618/ — Suporte experimental para o indicação técnica de aterragem suave, associado a menor pico de força vertical e maior flexão do joelho. — População feminina atleta e tarefa experimental; o efeito não garante prevenção de lesão nem generalização universal.

### Fonte 6: Decreasing landing forces: effect of instruction

- Autor ou entidade: McNair, Prapavessis e Callender
- Tipo: Estudo experimental primário
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC1724204/
- Usada para: Efeito de instruções verbais e cinemáticas na redução das forças verticais de aterragem.
- Limite: EX16-S4 — Decreasing landing forces: effect of instruction — McNair, Prapavessis e Callender — Estudo experimental primário — https://pmc.ncbi.nlm.nih.gov/articles/PMC1724204/ — Efeito de instruções verbais e cinemáticas na redução das forças verticais de aterragem. — Investiga aterragem em condições controladas; não define elegibilidade nem prescrição.

### Fonte 7: Weight training: Do's and don'ts of proper technique

- Autor ou entidade: Mayo Clinic
- Tipo: Orientação profissional de saúde
- Localizador: https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/weight-training/art-20045842
- Usada para: Orientação conservadora para não reter a respiração durante esforço.
- Limite: EX16-S5 — Weight training: Do's and don'ts of proper technique — Mayo Clinic — Orientação profissional de saúde — https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/weight-training/art-20045842 — Orientação conservadora para não reter a respiração durante esforço. — Não é específica do salto com contramovimento; por isso não foi imposto um padrão respiratório rígido.
