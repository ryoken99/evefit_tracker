# Ergometria estacionária de manivela para braços

Conteúdo para principiantes em português europeu.

## Descrição curta

Rotação contínua de manivelas fixas usando os membros superiores.

## O que é

É um ciclo manual feito num ergómetro fixo. Sentado ou de pé, seguras as duas manivelas e fazes com as mãos um percurso circular contínuo contra a resistência do aparelho. O corpo permanece no mesmo local: não há veículo, direção de deslocamento nem travagem de rota.

## O que vais fazer

Vais preparar uma posição estável, ajustar o alcance das manivelas, segurá-las com ambas as mãos e rodá-las de forma contínua e controlada. Conforme a configuração própria do ergómetro, os braços podem alternar ou mover-se em conjunto. No fim, deixas as manivelas parar por completo antes de largar.

## Porque existe este movimento

O propósito técnico imediato é produzir propulsão cíclica dos membros superiores num ergómetro fixo. A forma como duração, resistência, cadência ou ritmo são escolhidos pertence à prescrição e não a esta explicação.

## Antes de começares

1. Confirma que estás perante um ergómetro estacionário de manivela para braços, estável e ajustável.
2. Consulta as instruções do modelo para regular e bloquear o assento, a altura, o alcance e as manivelas.
3. Usa apenas uma configuração sentada ou de pé prevista pelo fabricante e que mantenha o corpo estável sem aproximar roupa ou apoios das partes móveis.
4. Retira objetos soltos e prende roupa, cabelo ou acessórios junto das manivelas.
5. A primeira configuração exige supervisão de uma pessoa que conheça o aparelho.

## Preparar o equipamento

1. Coloca ou confirma o ergómetro numa superfície interior nivelada e verifica que não oscila.
2. Inspeciona visualmente as manivelas, pegas, fixações, pinos e alavancas. Não uses o aparelho se estiver danificado, solto ou com comportamento irregular.
3. Ajusta a altura do eixo das manivelas para uma posição confortável, em geral próxima da altura dos ombros, seguindo o manual do modelo.
4. Ajusta a distância para que, no ponto mais afastado do círculo, o cotovelo ainda conserve uma ligeira flexão, sem afastar o tronco do apoio.
5. Confirma que todos os ajustes ficaram completamente bloqueados antes de agarrar e mover as manivelas.
6. Se houver cabo de alimentação, mantém-no fora da zona de acesso e de passagem.
7. Não alteres a configuração relativa das manivelas, a resistência ou outros parâmetros para seguir esta ficha; esses elementos são definidos pelo manual do aparelho, por uma prescrição externa ou por um profissional.

## Preparar o espaço

1. Usa um local interior com piso nivelado, boa visibilidade e acesso desimpedido ao ergómetro.
2. Mantém pessoas, objetos e cabos fora do círculo das manivelas.
3. Garante espaço para entrares e saíres sem tropeçar e sem teres de contornar partes móveis.
4. Não uses uma máquina instável ou danificada.

## Verificação do corpo

1. Consegues manter a posição sentada ou de pé escolhida sem instabilidade marcada.
2. Consegues segurar ambas as pegas e alcançar o ponto mais distante sem dor nova, sem bloquear os cotovelos e sem perder o apoio.
3. Ombros, cotovelos e punhos permitem um círculo confortável e controlado.
4. Não tens, naquele momento, desconforto no peito, falta de ar atípica, tonturas, confusão ou dor nova.
5. Se regressas após lesão ou cirurgia, ou se tens sintomas cardiorrespiratórios relevantes, procura revisão adequada antes de executares; esta ficha não determina elegibilidade individual.

## Posição inicial

Fica sentado num assento estável do sistema ou de pé, conforme a configuração prevista pelo fabricante. Mantém os apoios firmes, a bacia controlada e o peito orientado para o ergómetro. Segura as pegas com os punhos alinhados; no ponto mais distante, conserva uma ligeira flexão dos cotovelos.

## Confirmar a posição inicial

1. Ergómetro estável e ajustes bloqueados.
2. Acesso e círculo das manivelas livres.
3. Base de apoio segura.
4. Eixo numa altura confortável, em geral próximo dos ombros.
5. Alcance sem bloquear cotovelos nem arredondar o tronco para a frente.
6. Pegas seguras com punhos alinhados.
7. Ombros relaxados e tronco controlado.

## Passos de execução

1. Assume a posição inicial e confirma que o assento, o corpo do ergómetro e todos os bloqueios permanecem imóveis sob pressão ligeira.
2. Segura ambas as pegas sem apertar mais do que o necessário e alinha cada punho com o antebraço.
3. Inicia a rotação com um movimento pequeno para reconhecer a ligação e a direção das manivelas.
4. Percorre o círculo permitido pelo aparelho de forma suave, sem aproximar o tronco das partes móveis.
5. Mantém os cotovelos sem bloqueio no ponto mais afastado e evita encolher os ombros.
6. Conserva a bacia e o tronco controlados; não uses balanço, impulso ou torção exagerada.
7. Mantém a respiração natural e contínua.
8. Para terminar, abranda de forma controlada até as manivelas ficarem completamente imóveis.
9. Larga as pegas e sai apenas depois da paragem total, usando os pontos fixos previstos pelo fabricante.

## Fases do movimento

### Preparação e contacto

Estabilizas a posição, confirmas os bloqueios e agarras as duas pegas com alcance confortável.

### Entrada no ciclo

Começas a rodar de forma deliberada para reconhecer a ligação e a direção das manivelas.

### Ciclo contínuo

As mãos percorrem círculos sucessivos; ombros, cotovelos e punhos participam, enquanto bacia e tronco dão controlo postural.

### Saída do ciclo

Deixas o movimento abrandar sob controlo, esperas pela imobilização completa e só então largas as pegas.

## Respiração

Respira de forma natural e contínua; não prendas a respiração. Deixa a frequência respiratória adaptar-se ao movimento sem impor contagens. Mantém a parte superior do peito e os ombros tão descontraídos quanto o controlo das pegas permitir. Falta de ar atípica é um sinal para parar.

## Sensações esperadas

1. Trabalho cíclico nos braços e ombros.
2. Participação dos antebraços para segurar as pegas.
3. Atividade do tronco para manter a posição.
4. Respiração mais evidente com o movimento, mantendo controlo.

## Sensações inesperadas ou de alerta

1. Dor nova ou crescente.
2. Desconforto no peito.
3. Falta de ar atípica.
4. Tonturas, confusão ou sensação de desmaio.
5. Perda de controlo das pegas ou instabilidade da posição.
6. Sintomas súbitos, intensos ou persistentes, que justificam assistência adequada.

## Indicações técnicas principais

1. Alinha o eixo com uma posição de trabalho confortável, geralmente próxima da altura dos ombros.
2. Mantém uma ligeira flexão dos cotovelos no ponto mais afastado.
3. Mantém punhos alinhados e ombros afastados das orelhas.
4. Faz círculos suaves sem puxões nem mudanças bruscas.
5. Evita balançar ou torcer o tronco de forma descontrolada.
6. Pára completamente as manivelas antes de libertar as mãos.

## Erros comuns e correções

### Erro 1: Usar um ajuste que obriga a bloquear o cotovelo ou a afastar o tronco do apoio.

- Como reconhecer: No ponto mais distante, o ombro avança muito, o cotovelo fica rígido ou perdes a posição da bacia.
- Como corrigir: Pára as manivelas, larga-as apenas depois de imóveis e reajusta a distância segundo o manual, até manteres uma ligeira flexão do cotovelo.

### Erro 2: Aproximar os ombros das orelhas durante o ciclo.

- Como reconhecer: Sentes tensão desnecessária no pescoço ou vês os ombros subir a cada volta.
- Como corrigir: Mantém o peito orientado para o ergómetro, reduz a tensão da pega e deixa os ombros descer sem perder o controlo.

### Erro 3: Deixar os punhos inclinarem-se para cima, para baixo ou para os lados.

- Como reconhecer: A mão deixa de formar uma linha aproximada com o antebraço ou a pressão concentra-se numa zona da palma.
- Como corrigir: Reposiciona a mão na pega e mantém o punho alinhado durante todo o círculo.

### Erro 4: Usar impulso do tronco para vencer partes do círculo.

- Como reconhecer: A bacia desloca-se, o peito oscila muito ou a cabeça acompanha cada volta.
- Como corrigir: Recupera uma base de apoio estável e faz o círculo apenas enquanto consegues manter a bacia e o tronco controlados.

### Erro 5: Acelerar e travar repetidamente dentro da mesma volta.

- Como reconhecer: As pegas mudam de velocidade de repente, ouves pancadas ou perdes a continuidade do círculo.
- Como corrigir: Retoma a rotação de modo deliberado e uniforme; se o aparelho continuar irregular, pára e não o uses até ser verificado.

### Erro 6: Abrir as mãos antes de as manivelas estarem imóveis.

- Como reconhecer: As pegas continuam a circular quando já estás a retirar as mãos ou a sair da posição.
- Como corrigir: Mantém ambas as mãos nas pegas, controla a paragem completa e só depois liberta o contacto.

## Formas de simplificar ou ensaiar

1. Aprende primeiro na posição sentada quando esta estiver disponível e for a opção que te dá melhor estabilidade.
2. Pede a um profissional que faça o primeiro ajuste de altura e distância num aparelho desconhecido.
3. Antes de encadear o movimento, explora apenas o início da rotação para perceber a direção e a ligação das manivelas; depois pára-as completamente.
4. Mantém a atenção em duas referências simples: cotovelos sem bloqueio e tronco sem balanço.
5. Estas simplificações não definem dose, intensidade nem progressão.

## Supervisão

A primeira configuração exige supervisão presencial de uma pessoa que conheça o aparelho. Essa pessoa confirma ajustes, bloqueios, alcance, acesso e saída segura, sem presumir elegibilidade clínica. Mantém supervisão se houver dificuldade de apoio, equilíbrio, compreensão ou controlo das manivelas.

## Como terminar

Mantém as duas mãos nas pegas e deixa a rotação diminuir de forma controlada. Espera até as manivelas estarem completamente imóveis. Retira então as mãos, confirma os pés e os apoios e sai sem te apoiar numa peça móvel. Se interrompeste por um sinal de aviso, não reinicies automaticamente.

## Nota de segurança

O ajuste, a estabilidade do ergómetro e a tolerância dos membros superiores condicionam a utilização. O principal risco técnico é um alcance incorreto ou acumular esforço nos membros superiores com técnica degradada. Não uses uma máquina instável, danificada, com fixações soltas ou com movimento irregular.

## Quando parar ou reduzir

1. Desconforto no peito ou falta de ar atípica.
2. Tonturas, confusão ou sensação de desmaio.
3. Perda de controlo das pegas, da posição ou do apoio.
4. Dor nova ou crescente.
5. Ruído, folga, ressalto ou instabilidade inesperada do equipamento.

## Segurança do equipamento

Segue o manual do modelo. Confirma a estabilidade da base e o bloqueio de assento, altura, alcance e manivelas. Mantém mãos, roupa e objetos longe de uniões e partes móveis. Não faças ajustes enquanto as manivelas rodam. Não uses o ergómetro perante dano, fixação solta ou funcionamento irregular; sinaliza-o para verificação.

## Segurança do espaço

Usa um local interior, nivelado, bem visível e sem obstáculos na zona de acesso. Mantém cabos fora da passagem. Garante que ninguém entra no círculo das manivelas. Mantém espaço para entrar e sair depois de o equipamento parar.

## Limitações

1. As instruções são gerais e não substituem o manual do modelo.
2. A posição exata do eixo, o raio das manivelas e a configuração entre os dois braços variam entre ergómetros.
3. Uma pequena rotação natural do tronco pode ocorrer nalguns aparelhos; esta ficha distingue-a de balanço ou torção descontrolada.
4. Não são definidos resistência, carga, cadência, ritmo, duração, séries, repetições, intervalos ou progressão.
5. Não é feita avaliação clínica, diagnóstico, tratamento, promessa de resultado ou autorização universal para executar.
6. A maior parte da evidência profissional específica disponível centra-se em contextos de reabilitação ou lesão medular.

## Teste de compreensão

### 1. O ergómetro deve deslocar-se durante o exercício?

Resposta esperada: Não. O aparelho é estacionário e deve permanecer estável.

### 2. Como deve ficar o cotovelo no ponto mais afastado?

Resposta esperada: Com uma ligeira flexão, sem bloqueio.

### 3. Podes compensar um alcance longo afastando o tronco?

Resposta esperada: Não. Deves parar e reajustar a distância segundo o manual.

### 4. Quando confirmas os bloqueios do assento e das manivelas?

Resposta esperada: Antes de iniciares a rotação.

### 5. Como devem ficar os punhos?

Resposta esperada: Aproximadamente alinhados com os antebraços.

### 6. É obrigatório eliminar toda a rotação do tronco?

Resposta esperada: Não. Pode existir pequena rotação natural, mas não balanço ou torção descontrolada.

### 7. Como deves respirar?

Resposta esperada: De forma natural e contínua, sem prender a respiração.

### 8. Podes largar as pegas enquanto ainda rodam?

Resposta esperada: Não. Primeiro controlas a paragem completa.

### 9. O que fazes se o aparelho oscilar ou produzir movimentos irregulares?

Resposta esperada: Paras com segurança e não o usas até ser verificado.

### 10. Que sinais exigem interrupção?

Resposta esperada: Entre outros, desconforto no peito, falta de ar atípica, tonturas, confusão, dor nova ou perda de controlo.

### 11. Esta ficha define resistência, cadência ou duração?

Resposta esperada: Não. Esses elementos pertencem à prescrição.

### 12. Quando é particularmente útil ter supervisão?

Resposta esperada: Com equipamento desconhecido, instabilidade marcada, dificuldade de apoio, regresso após lesão ou cirurgia, ou sintomas cardiorrespiratórios relevantes.

## Fontes e limites da evidência

### Fonte 1: UE8 User Manual

- Autor ou entidade: NuStep
- Tipo: manual oficial do fabricante
- Localizador: https://www.nustep.com/wp-content/uploads/2022/05/20099_UE8-User-Manual-English-Rev-A.pdf
- Usada para: WEB-EX03-01 — UE8 User Manual — NuStep — manual oficial do fabricante — https://www.nustep.com/wp-content/uploads/2022/05/20099_UE8-User-Manual-English-Rev-A.pdf — ajuste da distância com ligeira flexão do cotovelo bloqueio do assento e dos ajustes posições sentada, de pé e em cadeira de rodas alcance e postura segurança de cabos e espaço livre — Específico do modelo UE8; não autoriza copiar comandos ou medidas para todos os ergómetros.
- Limite: WEB-EX03-01 — UE8 User Manual — NuStep — manual oficial do fabricante — https://www.nustep.com/wp-content/uploads/2022/05/20099_UE8-User-Manual-English-Rev-A.pdf — ajuste da distância com ligeira flexão do cotovelo bloqueio do assento e dos ajustes posições sentada, de pé e em cadeira de rodas alcance e postura segurança de cabos e espaço livre — Específico do modelo UE8; não autoriza copiar comandos ou medidas para todos os ergómetros.

### Fonte 2: PRO1 Users’ Operations Manual

- Autor ou entidade: SCIFIT
- Tipo: manual oficial do fabricante
- Localizador: https://kb.cybexintl.com/Owners_Manuals/PRO/SCIFIT_P3858_PRO1_Legacy_Operations_Manual.pdf
- Usada para: WEB-EX03-02 — PRO1 Users’ Operations Manual — SCIFIT — manual oficial do fabricante — https://kb.cybexintl.com/Owners_Manuals/PRO/SCIFIT_P3858_PRO1_Legacy_Operations_Manual.pdf — posição biomecânica alcance sem bloqueio dos cotovelos controlo do tronco ajustes e bloqueios supervisão em utilização de reabilitação interrupção perante sensação de desmaio — Manual de um modelo legado; algumas instruções são específicas da máquina e algumas orientações de treino ficaram fora do conteúdo.
- Limite: WEB-EX03-02 — PRO1 Users’ Operations Manual — SCIFIT — manual oficial do fabricante — https://kb.cybexintl.com/Owners_Manuals/PRO/SCIFIT_P3858_PRO1_Legacy_Operations_Manual.pdf — posição biomecânica alcance sem bloqueio dos cotovelos controlo do tronco ajustes e bloqueios supervisão em utilização de reabilitação interrupção perante sensação de desmaio — Manual de um modelo legado; algumas instruções são específicas da máquina e algumas orientações de treino ficaram fora do conteúdo.

### Fonte 3: Monark 881E

- Autor ou entidade: Monark Sports & Medical
- Tipo: documentação oficial do fabricante
- Localizador: https://monarksportsmed.com/en/shop/monark-881e/
- Usada para: WEB-EX03-03 — Monark 881E — Monark Sports & Medical — documentação oficial do fabricante — https://monarksportsmed.com/en/shop/monark-881e/ — ergómetro fixo para braços manivelas ajustáveis horizontal e verticalmente uso sentado variação da resistência pelo mecanismo do aparelho — Página de produto, não guia técnico completo para principiantes.
- Limite: WEB-EX03-03 — Monark 881E — Monark Sports & Medical — documentação oficial do fabricante — https://monarksportsmed.com/en/shop/monark-881e/ — ergómetro fixo para braços manivelas ajustáveis horizontal e verticalmente uso sentado variação da resistência pelo mecanismo do aparelho — Página de produto, não guia técnico completo para principiantes.

### Fonte 4: Arm Cycle Ergometry (ACE) Training

- Autor ou entidade: SCIRE Professional
- Tipo: síntese profissional de evidência
- Localizador: https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/cardiorespiratory-fitness-and-endurance/arm-cycle-ergometry-ace-training/
- Usada para: WEB-EX03-04 — Arm Cycle Ergometry (ACE) Training — SCIRE Professional — síntese profissional de evidência — https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/cardiorespiratory-fitness-and-endurance/arm-cycle-ergometry-ace-training/ — definição do ciclo rítmico de braços necessidade de ajuste de altura a diferentes utilizadores limite de sobreutilização dos membros superiores utilização em posição sentada — Foco principal em pessoas com lesão medular; não estabelece elegibilidade geral nem técnica universal.
- Limite: WEB-EX03-04 — Arm Cycle Ergometry (ACE) Training — SCIRE Professional — síntese profissional de evidência — https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/cardiorespiratory-fitness-and-endurance/arm-cycle-ergometry-ace-training/ — definição do ciclo rítmico de braços necessidade de ajuste de altura a diferentes utilizadores limite de sobreutilização dos membros superiores utilização em posição sentada — Foco principal em pessoas com lesão medular; não estabelece elegibilidade geral nem técnica universal.

### Fonte 5: Breathing exercises in the treatment of hyperventilation

- Autor ou entidade: Cambridge University Hospitals NHS Foundation Trust
- Tipo: orientação profissional hospitalar
- Localizador: https://www.cuh.nhs.uk/patient-information/breathing-exercises-in-the-treatment-of-hyperventilation/
- Usada para: WEB-EX03-05 — Breathing exercises in the treatment of hyperventilation — Cambridge University Hospitals NHS Foundation Trust — orientação profissional hospitalar — https://www.cuh.nhs.uk/patient-information/breathing-exercises-in-the-treatment-of-hyperventilation/ — ombros relaxados respiração confortável aumento natural da frequência respiratória no exercício — Não é uma instrução específica de ergometria; sustenta apenas linguagem respiratória geral, sem contagens.
- Limite: WEB-EX03-05 — Breathing exercises in the treatment of hyperventilation — Cambridge University Hospitals NHS Foundation Trust — orientação profissional hospitalar — https://www.cuh.nhs.uk/patient-information/breathing-exercises-in-the-treatment-of-hyperventilation/ — ombros relaxados respiração confortável aumento natural da frequência respiratória no exercício — Não é uma instrução específica de ergometria; sustenta apenas linguagem respiratória geral, sem contagens.

### Fonte 6: About Heart Attack Symptoms, Risk, and Recovery

- Autor ou entidade: Centers for Disease Control and Prevention
- Tipo: orientação oficial de saúde pública
- Localizador: https://www.cdc.gov/heart-disease/about/heart-attack.html
- Usada para: WEB-EX03-06 — About Heart Attack Symptoms, Risk, and Recovery — Centers for Disease Control and Prevention — orientação oficial de saúde pública — https://www.cdc.gov/heart-disease/about/heart-attack.html — desconforto no peito falta de ar tonturas ou sensação de cabeça leve como sinais de aviso — Fonte geral de sinais de alerta; não serve para diagnóstico nem avaliação de elegibilidade.
- Limite: WEB-EX03-06 — About Heart Attack Symptoms, Risk, and Recovery — Centers for Disease Control and Prevention — orientação oficial de saúde pública — https://www.cdc.gov/heart-disease/about/heart-attack.html — desconforto no peito falta de ar tonturas ou sensação de cabeça leve como sinais de aviso — Fonte geral de sinais de alerta; não serve para diagnóstico nem avaliação de elegibilidade.

### Fonte 7: Wheelchair Propulsion Training

- Autor ou entidade: SCIRE
- Tipo: síntese profissional pré-existente no pacote
- Localizador: https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/wheelchair-propulsion-training/
- Usada para: A1-S22 — Wheelchair Propulsion Training — SCIRE — síntese profissional pré-existente no pacote — https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/wheelchair-propulsion-training/ — contexto de propulsão manual e equipamento adaptado — Não descreve diretamente a técnica do ergómetro estacionário de braços.
- Limite: A1-S22 — Wheelchair Propulsion Training — SCIRE — síntese profissional pré-existente no pacote — https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/wheelchair-propulsion-training/ — contexto de propulsão manual e equipamento adaptado — Não descreve diretamente a técnica do ergómetro estacionário de braços.

### Fonte 8: Physical Activity Guidelines for Adults with Spinal Cord Injury

- Autor ou entidade: CSEP
- Tipo: guideline profissional pré-existente no pacote
- Localizador: https://csepguidelines.ca/guidelines/physical-activity-guidelines-for-adults-with-spinal-cord-injury/
- Usada para: A1-S23 — Physical Activity Guidelines for Adults with Spinal Cord Injury — CSEP — guideline profissional pré-existente no pacote — https://csepguidelines.ca/guidelines/physical-activity-guidelines-for-adults-with-spinal-cord-injury/ — enquadramento de modalidades aeróbias adaptadas — População específica; nenhuma dose ou autorização individual foi transposta.
- Limite: A1-S23 — Physical Activity Guidelines for Adults with Spinal Cord Injury — CSEP — guideline profissional pré-existente no pacote — https://csepguidelines.ca/guidelines/physical-activity-guidelines-for-adults-with-spinal-cord-injury/ — enquadramento de modalidades aeróbias adaptadas — População específica; nenhuma dose ou autorização individual foi transposta.

### Fonte 9: Arm-crank exercise review

- Autor ou entidade: PubMed
- Tipo: revisão indexada pré-existente no pacote
- Localizador: https://pubmed.ncbi.nlm.nih.gov/32675708/
- Usada para: A2-S22 — Arm-crank exercise review — PubMed — revisão indexada pré-existente no pacote — https://pubmed.ncbi.nlm.nih.gov/32675708/ — enquadramento da ergometria de braços e respostas cardiorrespiratórias — Os parâmetros dependem da população; não sustenta dose, resultado individual nem elegibilidade automática.
- Limite: A2-S22 — Arm-crank exercise review — PubMed — revisão indexada pré-existente no pacote — https://pubmed.ncbi.nlm.nih.gov/32675708/ — enquadramento da ergometria de braços e respostas cardiorrespiratórias — Os parâmetros dependem da população; não sustenta dose, resultado individual nem elegibilidade automática.
