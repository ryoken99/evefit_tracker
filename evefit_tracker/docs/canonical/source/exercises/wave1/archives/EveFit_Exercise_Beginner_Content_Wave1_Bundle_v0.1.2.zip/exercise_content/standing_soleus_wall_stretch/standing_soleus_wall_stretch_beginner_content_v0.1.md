# Alongamento do sóleo à parede com joelho fletido

Conteúdo para principiantes em português europeu.

## Descrição curta

Alongamento sustentado da parte posterior da perna com o joelho de trás fletido, o calcanhar no chão e as mãos apoiadas numa parede estável.

## O que é

Numa passada curta diante de uma parede, a pessoa mantém os dois pés no chão, flete o joelho posterior e deixa esse joelho avançar de forma controlada. Esta configuração cria dorsiflexão do tornozelo posterior e uma sensação de alongamento na zona inferior da barriga da perna.

## O que vais fazer

Vais colocar um pé atrás do outro, apoiar as mãos na parede, fletir o joelho de trás sem levantar o calcanhar e deslocar o corpo ligeiramente para a frente e para baixo. Depois estabilizas a posição e regressas com controlo.

## Porque existe este movimento

O movimento permite praticar uma posição tolerada de dorsiflexão do tornozelo com o joelho fletido e alongamento da parte posterior da perna. A flexão do joelho distingue esta identidade da versão à parede com o joelho posterior estendido.

## Antes de começares

1. Confirma que consegues ficar de pé numa passada curta, compreender as instruções e interromper o movimento sem ajuda. Não avances se a parede mexer, o piso escorregar ou a posição inicial já provocar dor, dormência, instabilidade ou mal-estar.

## Preparar o equipamento

1. Não é necessário equipamento portátil. Usa uma parede ou outro apoio vertical fixo, resistente e sem elementos soltos; coloca as mãos numa zona limpa e segura do apoio.

## Preparar o espaço

1. Escolhe uma superfície plana, estável e antiderrapante, com espaço livre para colocar os pés em passada e para recuar. Evita zonas de passagem, trânsito ativo, piso molhado, tapetes soltos e apoios instáveis.

## Verificação do corpo

1. Antes de entrares no alongamento, verifica se consegues apoiar completamente os dois pés, fletir o joelho posterior e respirar normalmente sem dor aguda, sintomas neurológicos, perda de controlo ou sensação de desmaio.

## Posição inicial

Fica de frente para a parede e pousa ambas as mãos. Dá uma passada curta, deixando a perna a alongar atrás. Orienta os pés aproximadamente para a frente, mantém as solas em contacto com o chão, distribui o apoio entre os dois pés e mantém o tronco organizado sobre a base de suporte.

## Confirmar a posição inicial

1. A parede ou apoio vertical não mexe quando é pressionado.
2. O piso está seco, estável e sem objetos junto aos pés.
3. As duas mãos estão apoiadas e os ombros permanecem confortáveis.
4. O pé posterior está totalmente apoiado, incluindo o calcanhar.
5. O joelho posterior está fletido e orientado na direção dos dedos do mesmo pé.
6. A passada permite entrar e sair sem perder o equilíbrio.

## Passos de execução

1. De frente para a parede, apoia as duas mãos e organiza uma passada curta com a perna a alongar atrás.
2. Flete o joelho posterior, mantendo o calcanhar desse lado pousado.
3. Mantém o pé posterior estável e deixa o joelho avançar na direção dos dedos do mesmo pé.
4. Desloca o corpo ligeiramente para a frente e para baixo, usando a parede apenas como apoio.
5. Mantém as ancas centradas entre os pés e o tronco estável enquanto reconheces uma tensão gradual na parte posterior inferior da perna.
6. Respira de forma natural, contínua e confortável, sem prender o ar.
7. Para sair, desloca o corpo para trás, reduz a flexão do joelho posterior e aproxima os pés com controlo.

## Fases do movimento

### Preparação

Verificar apoio, superfície e espaço; colocar as mãos na parede e organizar a passada.

### Entrada

Fletir o joelho posterior e avançá-lo de forma controlada, mantendo o calcanhar no chão.

### Estabilização

Conservar o alinhamento pé-joelho, as ancas centradas e a respiração contínua, sem ressalto.

### Saída

Recuar o corpo, aliviar a dorsiflexão e reunir os pés sem perder o apoio.

## Respiração

Respira naturalmente durante a entrada, a estabilização e a saída. Mantém o fluxo de ar contínuo e confortável; não prendas a respiração nem uses uma manobra de força.

## Sensações esperadas

1. Tensão gradual e tolerável na parte posterior inferior da perna de trás, possivelmente mais próxima do tornozelo.
2. Pressão de apoio distribuída pelo pé posterior, sem perda do contacto do calcanhar.
3. Apoio leve das mãos na parede e sensação de posição estável.
4. Movimento controlado do joelho posterior para a frente sobre o pé.

## Sensações inesperadas ou de alerta

1. Dor aguda, crescente ou localizada na articulação do tornozelo, joelho ou pé.
2. Dormência, formigueiro, sensação elétrica ou fraqueza súbita.
3. Tontura, náusea, falta de ar invulgar ou sensação de desmaio.
4. Instabilidade, deslizamento do pé ou incapacidade de controlar a entrada ou a saída.
5. Sensação de bloqueio articular ou necessidade de forçar para manter o calcanhar no chão.

## Indicações técnicas principais

1. Parede firme e piso que não escorrega.
2. Joelho de trás fletido.
3. Calcanhar de trás sempre apoiado.
4. Joelho na direção dos dedos do mesmo pé.
5. Ancas centradas entre os pés.
6. Respiração contínua, sem prender o ar.
7. Entrada e saída sem ressalto.

## Erros comuns e correções

### Erro 1: Levantar o calcanhar posterior.

- Como reconhecer: O calcanhar perde contacto com o chão ou o peso passa para a parte da frente do pé.
- Como corrigir: Recua ligeiramente e reorganiza uma passada que permita manter toda a planta do pé apoiada.

### Erro 2: Deixar o joelho posterior estender.

- Como reconhecer: A perna de trás fica direita e a tensão sobe para a parte superior da barriga da perna.
- Como corrigir: Volta a fletir o joelho de trás antes de avançar o corpo.

### Erro 3: Deixar o joelho posterior colapsar para dentro.

- Como reconhecer: A rótula afasta-se da direção dos dedos e o tornozelo ou o arco do pé cedem para dentro.
- Como corrigir: Reduz a deslocação e orienta o joelho na direção dos dedos do mesmo pé.

### Erro 4: Rodar o pé posterior para procurar mais amplitude.

- Como reconhecer: Os dedos mudam de direção durante a entrada ou o peso passa para uma borda do pé.
- Como corrigir: Reposiciona o pé e mantém a planta estável enquanto o joelho avança sobre ele.

### Erro 5: Entrar com ressalto ou empurrar com força contra a parede.

- Como reconhecer: O corpo oscila, a tensão surge de forma abrupta ou os braços fazem uma pressão forte.
- Como corrigir: Interrompe o impulso, volta a uma posição estável e entra de forma contínua e controlada.

### Erro 6: Arquear as costas ou deslocar as ancas para um lado.

- Como reconhecer: O tronco perde a organização e a bacia deixa de ficar centrada entre os pés.
- Como corrigir: Reduz a deslocação, suaviza o apoio das mãos e recentra as ancas sobre a base de suporte.

## Formas de simplificar ou ensaiar

1. Usar uma passada mais curta para facilitar o contacto do calcanhar posterior.
2. Aplicar menos flexão do joelho posterior quando o alinhamento ainda não é estável.
3. Colocar as mãos um pouco mais afastadas na parede para aumentar a sensação de apoio.
4. Ensaiar apenas a entrada e a saída controladas antes de estabilizar a posição.
5. Pedir observação de um profissional qualificado se for difícil distinguir esta versão da versão com joelho estendido.

## Supervisão

A identidade canónica não exige supervisão nem assistente de segurança. Considera orientação de um profissional qualificado quando existe historial de lesão ou cirurgia, doença crónica relevante, retorno funcional, hipermobilidade, dificuldade em compreender ou interromper a ação, ou incapacidade de manter apoio e alinhamento. A supervisão não torna aceitável executar perante sinais de paragem.

## Como terminar

Mantém as mãos apoiadas enquanto recuas o corpo e deixas o joelho posterior regressar a uma posição confortável. Quando a tensão tiver diminuído e o equilíbrio estiver estável, aproxima os pés e só depois retira as mãos da parede.

## Nota de segurança

Este é um exercício de risco operacional baixo, mas depende de amplitude controlável, alinhamento e apoio seguros. Não forces o joelho para a frente, não uses ressalto e interrompe perante dor aguda ou crescente, sintomas neurológicos, instabilidade ou mal-estar.

## Quando parar ou reduzir

1. Dor aguda ou crescente.
2. Dormência, formigueiro, sensação elétrica ou fraqueza súbita.
3. Perda de controlo, instabilidade ou deslizamento.
4. Tontura, mal-estar ou sensação de desmaio.
5. Incapacidade de manter o calcanhar posterior apoiado sem forçar.
6. Aumento de desconforto articular ao avançar o joelho.

## Segurança do equipamento

Não há equipamento portátil obrigatório. A parede ou apoio vertical faz parte das condições de execução: deve estar fixo, resistir à pressão das mãos e não ter superfícies cortantes, quentes, húmidas ou soltas.

## Segurança do espaço

Executa apenas numa superfície estável e antiderrapante, sem tapetes soltos, humidade, desníveis ou objetos junto aos pés. Mantém a zona de entrada e saída livre e não uses uma área com trânsito ativo.

## Limitações

1. A evidência consultada apoia a identidade e a mecânica próxima, mas não estabelece resultado individual, isolamento muscular, prevenção, elegibilidade universal ou dose. Este conteúdo não substitui avaliação profissional perante sintomas, lesão, cirurgia ou doença relevante. Implementação realizada: não.

## Teste de compreensão

### 1. Que apoio deves verificar antes de começar?

Resposta esperada: Uma parede ou apoio vertical fixo e estável.

### 2. Como deve estar o piso?

Resposta esperada: Plano, estável, seco e antiderrapante.

### 3. Qual das pernas fica atrás?

Resposta esperada: A perna cuja parte posterior se pretende alongar.

### 4. O que distingue esta execução da versão para o gastrocnémio?

Resposta esperada: O joelho posterior mantém-se fletido em vez de estendido.

### 5. O que deve acontecer ao calcanhar posterior?

Resposta esperada: Deve permanecer em contacto com o chão.

### 6. Em que direção deve avançar o joelho posterior?

Resposta esperada: Na direção dos dedos do mesmo pé, sem colapsar para dentro.

### 7. Para que servem as mãos na parede?

Resposta esperada: Para apoio e controlo, não para criar um impulso forte.

### 8. Como deve ser a entrada no alongamento?

Resposta esperada: Controlada, para a frente e para baixo, sem ressalto.

### 9. Onde é esperada a sensação principal?

Resposta esperada: Na parte posterior inferior da perna de trás, possivelmente perto do tornozelo.

### 10. Como deves respirar?

Resposta esperada: De forma natural, contínua e confortável, sem prender o ar.

### 11. Que sinais exigem interromper o movimento?

Resposta esperada: Dor aguda ou crescente, dormência, fraqueza súbita, instabilidade, deslizamento ou mal-estar.

### 12. Como sais da posição com segurança?

Resposta esperada: Manténs as mãos apoiadas, recuas o corpo, alivias a flexão e aproximas os pés com controlo.

## Fontes e limites da evidência

### Fonte 1: Foot and Ankle Conditioning Program

- Autor ou entidade: D1-EXT-11 — Foot and Ankle Conditioning Program — American Academy of Orthopaedic Surgeons — OrthoInfo — guia profissional oficial — https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/ — Sustenta a configuração à parede com joelho posterior fletido, ambos os calcanhares no chão, avanço das ancas e centragem entre os pés. — O guia tem enquadramento de condicionamento e inclui dose; a dose não foi importada.
- Tipo: guia profissional oficial
- Localizador: https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/
- Usada para: D1-EXT-11 — Foot and Ankle Conditioning Program — American Academy of Orthopaedic Surgeons — OrthoInfo — guia profissional oficial — https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/ — Sustenta a configuração à parede com joelho posterior fletido, ambos os calcanhares no chão, avanço das ancas e centragem entre os pés. — O guia tem enquadramento de condicionamento e inclui dose; a dose não foi importada.
- Limite: O guia tem enquadramento de condicionamento e inclui dose; a dose não foi importada.

### Fonte 2: Foot or ankle pain — Standing soleus stretch

- Autor ou entidade: EX27-EXT-01 — Foot or ankle pain — Standing soleus stretch — Dynamic Health, Cambridgeshire and Peterborough NHS Foundation Trust — orientação profissional oficial — https://www.dynamichealth.nhs.uk/help-and-advice/foot-or-ankle-pain/ — Confirma posição de passada, apoio externo, flexão da perna posterior e manutenção do calcanhar no chão. — A página dirige-se a pessoas com dor no pé ou tornozelo; foi usada apenas para mecânica observável, não para diagnóstico, tratamento ou dose.
- Tipo: orientação profissional oficial
- Localizador: https://www.dynamichealth.nhs.uk/help-and-advice/foot-or-ankle-pain/
- Usada para: EX27-EXT-01 — Foot or ankle pain — Standing soleus stretch — Dynamic Health, Cambridgeshire and Peterborough NHS Foundation Trust — orientação profissional oficial — https://www.dynamichealth.nhs.uk/help-and-advice/foot-or-ankle-pain/ — Confirma posição de passada, apoio externo, flexão da perna posterior e manutenção do calcanhar no chão. — A página dirige-se a pessoas com dor no pé ou tornozelo; foi usada apenas para mecânica observável, não para diagnóstico, tratamento ou dose.
- Limite: A página dirige-se a pessoas com dor no pé ou tornozelo; foi usada apenas para mecânica observável, não para diagnóstico, tratamento ou dose.

### Fonte 3: Anterior cruciate ligament injury: non-operative management

- Autor ou entidade: EX27-EXT-02 — Anterior cruciate ligament injury: non-operative management — Royal Berkshire NHS Foundation Trust, Physiotherapy Department — folheto profissional oficial — https://www.royalberkshire.nhs.uk/media/ycqhnrh4/anterior-cruciate-ligament-injury-non-operative-management_nov24.pdf — A secção de alongamento do sóleo sustenta calcanhar no chão, joelho alinhado com os dedos, controlo do colapso medial do tornozelo e respiração suave. — O documento tem contexto de reabilitação do joelho e inclui dose; foram importadas apenas indicações técnicas gerais e não conteúdo clínico ou prescritivo.
- Tipo: folheto profissional oficial
- Localizador: https://www.royalberkshire.nhs.uk/media/ycqhnrh4/anterior-cruciate-ligament-injury-non-operative-management_nov24.pdf
- Usada para: EX27-EXT-02 — Anterior cruciate ligament injury: non-operative management — Royal Berkshire NHS Foundation Trust, Physiotherapy Department — folheto profissional oficial — https://www.royalberkshire.nhs.uk/media/ycqhnrh4/anterior-cruciate-ligament-injury-non-operative-management_nov24.pdf — A secção de alongamento do sóleo sustenta calcanhar no chão, joelho alinhado com os dedos, controlo do colapso medial do tornozelo e respiração suave. — O documento tem contexto de reabilitação do joelho e inclui dose; foram importadas apenas indicações técnicas gerais e não conteúdo clínico ou prescritivo.
- Limite: O documento tem contexto de reabilitação do joelho e inclui dose; foram importadas apenas indicações técnicas gerais e não conteúdo clínico ou prescritivo.

### Fonte 4: The influence of knee position on ankle dorsiflexion — a biometric study

- Autor ou entidade: EX27-PRI-01 — The influence of knee position on ankle dorsiflexion — a biometric study — Baumbach et al., BMC Musculoskeletal Disorders — estudo biomecânico primário — https://link.springer.com/article/10.1186/1471-2474-15-246 — Demonstra, em adultos assintomáticos e em condições com e sem carga, que a flexão do joelho altera a limitação da dorsiflexão atribuída ao gastrocnémio, apoiando a distinção mecânica face à versão de joelho estendido. — Estudo pequeno de medição, não estudo de ensino do exercício, segurança, resultados clínicos ou prescrição; não prova isolamento do sóleo.
- Tipo: estudo biomecânico primário
- Localizador: https://link.springer.com/article/10.1186/1471-2474-15-246
- Usada para: EX27-PRI-01 — The influence of knee position on ankle dorsiflexion — a biometric study — Baumbach et al., BMC Musculoskeletal Disorders — estudo biomecânico primário — https://link.springer.com/article/10.1186/1471-2474-15-246 — Demonstra, em adultos assintomáticos e em condições com e sem carga, que a flexão do joelho altera a limitação da dorsiflexão atribuída ao gastrocnémio, apoiando a distinção mecânica face à versão de joelho estendido. — Estudo pequeno de medição, não estudo de ensino do exercício, segurança, resultados clínicos ou prescrição; não prova isolamento do sóleo.
- Limite: Estudo pequeno de medição, não estudo de ensino do exercício, segurança, resultados clínicos ou prescrição; não prova isolamento do sóleo.
