# Relatório de investigação — `static_rowing_ergometer`

**Agente:** EX-08  
**Data de investigação:** 2026-07-23  
**Idioma do conteúdo:** português europeu  
**Implementação realizada: não**

## Resultado

Foi produzido conteúdo documental para principiante absoluto sobre o exercício canónico **Remo em ergómetro estático**, com estado `beginner_content_approved_with_limits`.

A identidade, o risco operacional moderado, o requisito de ergómetro estático, o ambiente interior, a supervisão recomendada e as seis relações canónicas recebidas foram preservados sem alteração. Não foram aprovados elementos multimédia, criadas variantes, acrescentadas relações ou definidas prescrições.

## Âmbito investigado

A pesquisa incidiu exclusivamente em:

- definição e distinção do remo em ergómetro estático;
- preparação do equipamento e do local;
- posição inicial;
- ataque, fase propulsiva, finalização e recuperação;
- trajetória da pega e controlo do assento;
- orientação respiratória defensável;
- erros observáveis e respetivas correções;
- segurança do equipamento e do ambiente;
- sinais de interrupção;
- situações que justificam supervisão.

Ficaram fora do âmbito dose, séries, repetições fixas, duração, distância, carga, intensidade, cadência, descanso, progressão programada, promessa de resultado, diagnóstico, tratamento, autorização clínica, código e publicação.

## Fontes consultadas

| Código | Fonte | Tipo | Contributo |
|---|---|---|---|
| `A1-S05` | [Concept2 — Indoor Rowing Technique](https://www.concept2.com/training/rowing-technique) | Documentação técnica oficial do fabricante | Fases, posições, sequência, trajetória da pega e postura. |
| `A2-S08` | [USRowing — Learn About Rowing](https://usrowing.org/learn-about-rowing) | Federação nacional | Confirmação do remo indoor em ergómetro. |
| `A2-S09` | [World Rowing — Indoor Events](https://worldrowing.com/events/indoor-events/) | Federação internacional | Confirmação federativa da modalidade indoor. |
| `A2-S11` | [Concept2 — Training and Education](https://www.concept2.com/training) | Documentação oficial do fabricante | Enquadramento da aprendizagem técnica. |
| `EX08-S01` | [Concept2 — RowErg Product Manual](https://cms.concept2.com/sites/default/files/2024-11/RowErg_Manual_1024.pdf) | Manual oficial do fabricante | Superfície estável, peças defeituosas, partes móveis, pega bilateral, corrente, retorno da pega e sensação de desmaio. |
| `EX08-S02` | [British Rowing — British Rowing Technique](https://www.britishrowing.org/indoor-rowing/go-row-indoor/how-to-indoor-row/british-rowing-technique/) | Federação nacional | Confirmação independente da sequência e da postura. |
| `EX08-S03` | [British Rowing — Perfect Your Technique](https://www.britishrowing.org/indoor-rowing/go-row-indoor/how-to-indoor-row/perfect-your-technique/) | Federação nacional | Ajuste dos pés, trajetória da pega, sequência da recuperação e erros. |
| `EX08-S04` | [British Rowing — RowSafe 2026](https://www.britishrowing.org/wp-content/uploads/2026/02/2026-RowSafe.pdf) | Guia oficial de segurança | Técnica correta, interrupção perante dor, espaço adequado, controlo da exigência e responsabilidades de treinadores. |
| `EX08-S05` | [Concept2 — Improve Your Rowing Technique](https://www.concept2.com/training/improve-your-rowing-technique) | Documentação técnica oficial do fabricante | Erros de braços, preensão, tronco, joelhos, recuperação e sobrecompressão. |
| `EX08-S06` | [Concept2 — Find Your Optimal Foot Position on the RowErg](https://www.concept2.com/blog/find-your-optimal-foot-position-on-the-rowerg) | Documentação técnica oficial do fabricante | Correia sobre a zona mais larga do pé e relação do ajuste com canelas verticais. |

Todas as fontes foram consultadas em 2026-07-23. As fontes técnicas externas usadas são documentação oficial de fabricante, federações ou guia profissional oficial. A execução e a segurança têm apoio de duas organizações independentes: Concept2 e British Rowing.

## Síntese da evidência

### Identidade e execução

Concept2 e British Rowing descrevem o ciclo com ataque, fase propulsiva, finalização e recuperação. As duas fontes convergem na ordem:

- fase propulsiva: pernas, tronco e braços;
- recuperação: braços, tronco e pernas.

Também convergem em braços estendidos no início, inclinação do tronco a partir das ancas, canelas aproximadamente verticais, pega em linha reta, finalização junto à zona inferior das costelas e joelhos a dobrarem apenas depois de a pega os ultrapassar.

### Preparação

Concept2 e British Rowing sustentam a colocação da correia sobre a zona mais larga do pé e o ajuste das plataformas para permitir um ataque confortável sem sobrecompressão. O manual Concept2 sustenta a utilização numa superfície estável e nivelada e a retirada de serviço perante componentes defeituosos.

Não foi incluída qualquer posição numérica do regulador, fator de arrasto ou outra regulação, pois isso seria dependente do modelo e poderia funcionar como prescrição.

### Respiração

As fontes oficiais consultadas apoiam a necessidade de manter controlo respiratório e de não deixar a técnica degradar-se, mas não forneceram suporte independente suficientemente consistente para impor a todos os principiantes uma sincronização respiratória rígida por fase.

Decisão: documentar respiração natural e contínua, sem retenção e sem contagem. A possibilidade de expirar na fase propulsiva e inspirar na recuperação é apresentada apenas como opção confortável, não como regra universal.

### Erros

Foram selecionados cinco erros com forma completa — erro, reconhecimento observável e correção:

1. puxar primeiro com os braços;
2. dobrar os joelhos demasiado cedo na recuperação;
3. arredondar o tronco ou inclinar-se excessivamente para trás;
4. desviar a pega, dobrar os punhos ou puxar lateralmente;
5. apressar o assento ou deixar a pega regressar sem controlo.

Estes erros são diretamente apoiados pela documentação técnica da Concept2 e cruzados, quando aplicável, com a orientação da British Rowing.

### Segurança e supervisão

O manual Concept2 sustenta:

- superfície estável e nivelada;
- retirada de serviço de componentes defeituosos;
- afastamento de dedos, roupa, crianças e animais dos roletes;
- tração bilateral em linha reta;
- ausência de torção ou tração lateral da corrente;
- devolução controlada da pega;
- interrupção perante sensação de desmaio.

RowSafe sustenta:

- conhecimento e ensino da técnica correta;
- interrupção perante dor;
- espaço adequado entre máquinas e em redor das mesmas;
- não incentivar esforço excessivo;
- responsabilidade de treinadores na técnica e segurança.

A supervisão foi mantida como recomendada, sem introduzir spotter obrigatório. Os gatilhos canónicos — instabilidade marcada e equipamento ou ambiente desconhecido — foram preservados. Foram igualmente preservadas as populações que requerem adaptação ou revisão.

## Preservação canónica

| Elemento | Valor preservado | Decisão |
|---|---|---|
| `exercise_id` | `static_rowing_ergometer` | Sem alteração |
| Entidade | `canonical_exercise` | Sem alteração |
| Estado canónico | `approved` | Sem alteração |
| Capacidade principal | `cardio_conditioning` | Sem alteração |
| Capacidade secundária | `motor_control_coordination` | Refletida apenas no enquadramento, sem nova relação |
| Família | `rowing_ergometer_family` | Sem alteração |
| Variante/base | `none` / `none` | Sem alteração |
| Equipamento obrigatório | `static_rowing_ergometer` | Sem alternativa criada |
| Ambiente | interior, superfície nivelada, trajetórias desimpedidas | Sem alteração |
| Risco operacional | moderado | Sem redução |
| Supervisão | recomendada; sem spotter | Sem alteração |
| Relações | seis relações recebidas | Sem criação, remoção ou reclassificação |

## Relações preservadas

1. `static_rowing_ergometer__main_training__cardio_conditioning__cyclic_propulsion__increase_sustained_propulsive_output` — compatível, `alternative_primary`.
2. `static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__improve_transition_efficiency_within_sequence` — compatível, `alternative_primary`.
3. `static_rowing_ergometer__main_training__cardio_conditioning__repeated_motor_sequence__increase_sequence_endurance_under_fatigue` — condicional, `alternative_primary`.
4. `static_rowing_ergometer__main_training__motor_control_coordination__repeated_motor_sequence__improve_sequence_transition_control` — condicional, `complementary`.
5. `static_rowing_ergometer__warmup__cardio_conditioning__repeated_motor_sequence__rehearse_motor_sequence` — condicional, `principal_candidate`.
6. `static_rowing_ergometer__warmup__motor_control_coordination__repeated_motor_sequence__rehearse_motor_sequence` — condicional, `principal_candidate`.

As relações condicionais não foram convertidas em relações prontas para implementação.

## Limites e campos não resolvidos

- O conteúdo não atribui dose nem prescrição.
- A elegibilidade individual não é inferida.
- Não são feitas promessas de resultado.
- Não há diagnóstico, tratamento ou autorização universal.
- Os detalhes de montagem, bloqueio, manutenção e limites variam entre modelos.
- A sincronização respiratória específica por fase permanece não resolvida como regra universal; aplica-se respiração natural e contínua sem retenção.
- Controlos específicos do modelo devem ser tratados pelo respetivo manual.

## Validação do contrato

| Requisito | Resultado |
|---|---|
| Português europeu | Cumprido |
| UTF-8 NFC | Cumprido |
| JSON válido | Cumprido |
| Chaves obrigatórias pela ordem contratada | Cumprido |
| Mínimo de cinco passos | Oito passos |
| Mínimo de quatro pistas | Seis pistas |
| Mínimo de quatro erros completos | Cinco erros completos |
| Doze perguntas | Doze perguntas |
| Respiração documentada | Natural, contínua e sem retenção |
| Duas fontes independentes quando possível | Concept2 e British Rowing |
| Documentação oficial do ergómetro | Manual oficial Concept2 RowErg incluído |
| Sem dose, promessa, diagnóstico ou tratamento | Cumprido |
| Sem alterações de identidade, risco, equipamento ou relações | Cumprido |
| Sem código ou publicação | Cumprido |

## Cobertura defensável

A cobertura é defensável para identidade, preparação, execução, erros, segurança do equipamento, segurança do ambiente e supervisão porque cada domínio foi ligado a documentação oficial e, nos elementos técnicos centrais, cruzado entre fabricante e federação.

A respiração tem cobertura defensável apenas no nível conservador adotado: continuidade, ausência de retenção e interrupção perante falta de ar atípica. Não foi transformada em regra de sincronização rígida.

O conteúdo é adequado para revisão documental e futura implementação, mas não constitui implementação, prescrição individual nem autorização clínica.
