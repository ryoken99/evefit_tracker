# Alongamento peitoral no vão da porta

Conteúdo para principiantes em português europeu.

## Descrição curta

Alongamento peitoral unilateral com o antebraço apoiado numa ombreira estável.

## O que é

De pé junto a um vão estável, apoias um antebraço na ombreira e deslocas o tronco gradualmente para a frente ou para o lado oposto. O antebraço fica em contacto com o apoio enquanto o ombro permanece controlado.

## O que vais fazer

Vais organizar os pés numa base estável, apoiar um antebraço numa ombreira fixa e mover o tronco até surgir uma tração confortável no peito e na zona anterior do ombro. Para sair, recuas primeiro o tronco e só depois retiras o braço.

## Porque existe este movimento

O movimento existe para praticar uma posição controlada de alongamento da parte anterior do peito e do ombro com um suporte externo fixo. Não determina uma dose nem garante um resultado individual.

## Antes de começares

1. Confirma que o vão e a ombreira estão fixos, sem porta em movimento, arestas cortantes ou objetos salientes.
2. Verifica se o piso está estável, seco e antiderrapante e se ninguém vai atravessar o vão.
3. Garante que consegues entrar na posição e recuar sem impulso nem ajuda.
4. Não inicies se já houver dor aguda ou crescente, dormência, formigueiro, fraqueza súbita, sensação de instabilidade ou mal-estar.

## Preparar o equipamento

1. Não é necessário equipamento portátil. É indispensável uma ombreira estável ou outra aresta vertical fixa, sem arestas cortantes nem obstáculos, que permita apoiar o antebraço sem pressão direta concentrada no cotovelo.

## Preparar o espaço

1. Escolhe um espaço interior desimpedido, sem circulação de pessoas pelo vão. Mantém ambos os pés num piso estável e antiderrapante e confirma que a porta não pode fechar-se ou deslocar o apoio.

## Verificação do corpo

1. Consegues ficar de pé numa passada confortável e mudar o peso entre os pés com controlo.
2. Consegues colocar o antebraço na ombreira sem dor, formigueiro ou sensação de ombro solto.
3. Consegues respirar de forma natural sem prender a respiração.
4. Consegues recuar o tronco e libertar o braço sem impulso.

## Posição inicial

Fica de pé junto a um dos lados do vão, de frente para a passagem. Coloca os pés desencontrados numa passada estável. Apoia todo o antebraço do lado a alongar na ombreira, com o cotovelo fletido e sem pressionar a ponta do cotovelo. Mantém o tronco alto, a bacia e as costelas organizadas e o ombro afastado da orelha.

## Confirmar a posição inicial

1. Os dois pés estão totalmente apoiados e não escorregam.
2. O antebraço, e não apenas a mão ou a ponta do cotovelo, contacta uma ombreira fixa.
3. O cotovelo está fletido numa altura confortável para o ombro.
4. O pescoço está comprido e o ombro não está encolhido.
5. As costelas não estão projetadas para a frente e a lombar não está arqueada.
6. A passagem está livre e a saída para trás está desimpedida.

## Passos de execução

1. Confirma novamente a estabilidade da ombreira e do piso antes de lhe transferires pressão.
2. Coloca o antebraço na ombreira com contacto distribuído e deixa a mão descontraída.
3. Ajusta a passada para poderes mover o tronco sem perder o equilíbrio.
4. Organiza o tronco: mantém a cabeça alinhada, o peito sem exagero e as costelas sobre a bacia.
5. Avança ligeiramente o tronco ou roda-o para o lado oposto ao antebraço apoiado.
6. Interrompe o avanço quando surgir uma tração suave e distribuída no peito ou na zona anterior do ombro.
7. Mantém a posição controlada sem aumentar a rotação do braço e continua a respirar naturalmente.
8. Para sair, recua o tronco até desaparecer a tração; depois baixa e retira o antebraço.

## Fases do movimento

### Preparação

Verifica o apoio, organiza a passada e distribui o contacto pelo antebraço.

### Entrada

Avança ou roda o tronco gradualmente para longe do antebraço fixo.

### Controlo da posição

Mantém o ombro afastado da orelha, o tronco sem arco lombar e a sensação dentro do confortável.

### Saída

Recua primeiro o tronco e só depois liberta o antebraço.

## Respiração

Respira de forma natural e contínua durante a entrada, a posição e a saída. Não prendas a respiração nem uses uma inspiração para elevar as costelas e arquear a lombar. Se a respiração ficar bloqueada, reduz o deslocamento do tronco.

## Sensações esperadas

1. Tração suave e distribuída na parte anterior do peito.
2. Possível sensação de alongamento na zona anterior do ombro, sem pressão concentrada na articulação.
3. Contacto firme mas confortável do antebraço com a ombreira.
4. Trabalho ligeiro dos pés e do tronco para manter a posição estável.

## Sensações inesperadas ou de alerta

1. Dor aguda, crescente ou localizada profundamente na parte anterior do ombro.
2. Picada, aperto articular ou sensação de que o ombro vai sair do lugar.
3. Formigueiro, dormência ou alteração da sensibilidade no braço, mão ou dedos.
4. Fraqueza súbita, perda de controlo, tontura ou mal-estar.
5. Dor que obriga a prender a respiração ou a fazer força para permanecer na posição.

## Indicações técnicas principais

1. Antebraço apoiado; cotovelo sem pressão.
2. Pés firmes numa passada estável.
3. Costelas sobre a bacia; lombar sem arco.
4. Ombro longe da orelha e sem avançar.
5. Move o tronco devagar, sem forçar o braço.
6. Recua o tronco antes de retirar o antebraço.

## Erros comuns e correções

### Erro 1: Forçar a rotação externa do ombro.

- Como reconhecer: A mão é empurrada para trás, a pressão concentra-se na frente do ombro ou surge uma picada em vez de tração no peito.
- Como corrigir: Recua o tronco, reposiciona o antebraço numa altura confortável e volta a entrar com menos deslocamento.

### Erro 2: Deixar o ombro avançar ou encolher.

- Como reconhecer: O ombro aproxima-se da orelha, o peito roda sem controlo ou a cabeça do braço parece pressionada para a frente.
- Como corrigir: Afasta suavemente o ombro da orelha e reduz a rotação do tronco até recuperares controlo.

### Erro 3: Arquear a lombar para criar mais amplitude.

- Como reconhecer: As costelas projetam-se para a frente e o movimento aparece sobretudo na zona lombar.
- Como corrigir: Reposiciona as costelas sobre a bacia e usa uma deslocação menor dos pés e do tronco.

### Erro 4: Pressionar diretamente a ponta do cotovelo.

- Como reconhecer: O contacto é pequeno, duro ou desconfortável e o antebraço não está distribuído pela ombreira.
- Como corrigir: Recua e apoia uma área maior do antebraço, sem esmagar o cotovelo contra a aresta.

### Erro 5: Entrar depressa ou usar impulso.

- Como reconhecer: A tração aparece de repente, os pés perdem estabilidade ou torna-se difícil parar na amplitude desejada.
- Como corrigir: Recomeça com uma passada mais estável e desloca o peso de forma gradual.

### Erro 6: Usar uma porta móvel, uma ombreira instável ou um piso escorregadio.

- Como reconhecer: O apoio cede, a porta mexe, o pé desliza ou alguém pode atravessar o vão.
- Como corrigir: Interrompe e escolhe um apoio vertical fixo, uma passagem sem circulação e um piso estável e antiderrapante.

## Formas de simplificar ou ensaiar

1. Começa com o tronco mais próximo da posição neutra e usa apenas um deslocamento pequeno que consigas inverter facilmente.
2. Baixa ligeiramente a altura do cotovelo se isso permitir colocar o antebraço sem dor e sem encolher o ombro.
3. Mantém a rotação do tronco mínima e privilegia uma passagem suave do peso entre os pés.
4. Faz primeiro um ensaio de entrada e saída sem procurar sensação de alongamento, apenas para confirmar equilíbrio e controlo.

## Supervisão

O registo canónico não exige parceiro, observador nem supervisão para uma pessoa elegível que compreenda a tarefa e controle a entrada e a saída. Procura orientação de um profissional qualificado antes de executar se regressas após lesão ou cirurgia, tens historial de instabilidade ou hipermobilidade, sintomas relevantes, ou não consegues encontrar uma posição confortável e reversível. A supervisão também é apropriada quando é necessária assistência humana ou uma amplitude extrema.

## Como terminar

Desfaz o movimento pela ordem inversa: transfere o peso para trás e roda o tronco de volta até a tração desaparecer. Mantém o antebraço apoiado enquanto recuperas a posição neutra. Só depois retira o braço, baixa-o com controlo e reorganiza os pés.

## Nota de segurança

Mantém a sensação suave e muscular, nunca articular ou neurológica. Não forces o ombro para trás nem uses a ombreira para ficar pendurado. Interrompe se surgir dor anterior, instabilidade, formigueiro, dormência, fraqueza súbita, perda de controlo ou mal-estar.

## Quando parar ou reduzir

1. Reduz o deslocamento se a tração deixar de ser suave, a respiração ficar presa ou o ombro começar a encolher ou avançar.
2. Interrompe perante dor aguda ou crescente.
3. Interrompe perante dormência, formigueiro, alteração de sensibilidade ou fraqueza súbita.
4. Interrompe perante sensação de instabilidade, perda de controlo, tontura ou mal-estar.
5. Não retomes no mesmo momento se não conseguires recuperar uma posição confortável e estável.

## Segurança do equipamento

Embora não haja equipamento portátil, o apoio externo é obrigatório. Verifica a ombreira ou aresta vertical antes de cada utilização; não uses portas móveis, estruturas soltas, superfícies com arestas cortantes ou locais onde o antebraço fique sobre um obstáculo.

## Segurança do espaço

Executa apenas num espaço interior desimpedido, com piso estável e antiderrapante e sem circulação através do vão. Evita superfícies escorregadias ou instáveis, apoio sujeito a fechar ou rodar e qualquer situação em que não exista espaço livre para recuar.

## Limitações

1. A documentação descreve identidade, execução e segurança geral, não uma dose, prescrição, diagnóstico, tratamento ou promessa de resultado. A evidência direta é sobretudo aguda, biomecânica e proveniente de populações específicas. A adequação após lesão, cirurgia, doença crónica, hipermobilidade ou sintomas relevantes exige apreciação individual. Implementação realizada: não.

## Teste de compreensão

### 1. Que parte do braço deve ficar apoiada na ombreira?

Resposta esperada: O antebraço, com contacto distribuído e sem concentrar pressão na ponta do cotovelo.

### 2. Como devem estar os pés antes de mover o tronco?

Resposta esperada: Numa passada estável, ambos firmemente apoiados num piso antiderrapante.

### 3. De onde deve vir o movimento que cria o alongamento?

Resposta esperada: Do avanço ou da rotação gradual do tronco, controlados pelos pés, enquanto o antebraço permanece fixo.

### 4. Qual é a sensação esperada?

Resposta esperada: Uma tração suave e distribuída no peito e, possivelmente, na zona anterior do ombro, sem dor articular.

### 5. O que deves fazer se sentires formigueiro ou dormência?

Resposta esperada: Interromper, recuar o tronco com controlo e sair da posição.

### 6. Como deves respirar durante o exercício?

Resposta esperada: De forma natural e contínua, sem prender a respiração.

### 7. Qual é um sinal de que estás a compensar com a lombar?

Resposta esperada: As costelas avançam e a zona lombar arqueia para criar amplitude.

### 8. O que deve acontecer primeiro ao terminar: retirar o braço ou recuar o tronco?

Resposta esperada: Recuar o tronco até desaparecer a tração; só depois retirar o braço.

### 9. Podes usar uma porta que se move como apoio?

Resposta esperada: Não. O apoio tem de ser uma ombreira ou aresta vertical fixa e estável.

### 10. Como reconheces que o ombro perdeu controlo?

Resposta esperada: O ombro sobe para a orelha, avança, fica com pressão concentrada ou parece instável.

### 11. Quando é indicada orientação profissional antes da execução?

Resposta esperada: Quando há regresso após lesão ou cirurgia, historial de instabilidade ou hipermobilidade, sintomas relevantes ou incapacidade de entrar e sair confortavelmente.

### 12. Este conteúdo define quanto tempo manter a posição?

Resposta esperada: Não. O conteúdo não define dose nem tempo de retenção.

## Fontes e limites da evidência

### Fonte 1: Higuchi T, Nakao Y, Tanaka Y, et al. Acute effects of doorway stretch on the glenohumeral rotational range of motion and scapular position in high-school baseball players. JSES International. 2021;5(6):972-977.

- Autor ou entidade: EX30-EXT-01 — literatura científica primária — Higuchi T, Nakao Y, Tanaka Y, et al. Acute effects of doorway stretch on the glenohumeral rotational range of motion and scapular position in high-school baseball players. JSES International. 2021;5(6):972-977. — https://pubmed.ncbi.nlm.nih.gov/34766072/ — Sustenta a configuração do ombro em abdução e rotação externa, o cotovelo fletido e o uso do antebraço estabilizado num alongamento no vão. — Estudo agudo em rapazes praticantes de basebol do ensino secundário; o protocolo incluiu estabilização do antebraço por um investigador e não fundamenta segurança universal, dose ou resultados individuais.
- Tipo: literatura científica primária
- Localizador: https://pubmed.ncbi.nlm.nih.gov/34766072/
- Usada para: Sustenta a configuração do ombro em abdução e rotação externa, o cotovelo fletido e o uso do antebraço estabilizado num alongamento no vão.
- Limite: Estudo agudo em rapazes praticantes de basebol do ensino secundário; o protocolo incluiu estabilização do antebraço por um investigador e não fundamenta segurança universal, dose ou resultados individuais.

### Fonte 2: Borstad JD, Ludewig PM. Comparison of three stretches for the pectoralis minor muscle. Journal of Shoulder and Elbow Surgery. 2006;15(3):324-330.

- Autor ou entidade: EX30-EXT-02 — literatura científica primária — Borstad JD, Ludewig PM. Comparison of three stretches for the pectoralis minor muscle. Journal of Shoulder and Elbow Surgery. 2006;15(3):324-330. — https://pubmed.ncbi.nlm.nih.gov/16679233/ — Sustenta a família de autoalongamento unilateral do peitoral menor e a plausibilidade de alteração do comprimento muscular durante a posição. — Amostra sem patologia do ombro e foco biomecânico imediato; não estabelece benefício clínico, dose nem adequação individual.
- Tipo: literatura científica primária
- Localizador: https://pubmed.ncbi.nlm.nih.gov/16679233/
- Usada para: Sustenta a família de autoalongamento unilateral do peitoral menor e a plausibilidade de alteração do comprimento muscular durante a posição.
- Limite: Amostra sem patologia do ombro e foco biomecânico imediato; não estabelece benefício clínico, dose nem adequação individual.

### Fonte 3: University Hospitals of Leicester NHS Trust. Exercises to help manage your thoracic outlet syndrome.

- Autor ou entidade: EX30-EXT-03 — orientação profissional oficial — University Hospitals of Leicester NHS Trust. Exercises to help manage your thoracic outlet syndrome. — https://yourhealth.leicestershospitals.nhs.uk/library/csi/therapies/physiotherapy/4419-exercises-to-help-manage-your-thoracic-outlet-syndrome-tos/file — Descreve apoio no vão, cotovelo fletido, avanço e rotação do tronco para longe do braço; recomenda uma sensação suave e redução ou interrupção perante formigueiro ou dormência. — Material dirigido a um contexto clínico específico; foram aproveitados apenas elementos mecânicos e sinais de aviso compatíveis com o registo canónico.
- Tipo: orientação profissional oficial
- Localizador: https://yourhealth.leicestershospitals.nhs.uk/library/csi/therapies/physiotherapy/4419-exercises-to-help-manage-your-thoracic-outlet-syndrome-tos/file
- Usada para: Descreve apoio no vão, cotovelo fletido, avanço e rotação do tronco para longe do braço; recomenda uma sensação suave e redução ou interrupção perante formigueiro ou dormência.
- Limite: Material dirigido a um contexto clínico específico; foram aproveitados apenas elementos mecânicos e sinais de aviso compatíveis com o registo canónico.

### Fonte 4: University Hospitals Plymouth NHS Trust. Physiotherapy for Breast Surgery.

- Autor ou entidade: EX30-EXT-04 — orientação profissional oficial — University Hospitals Plymouth NHS Trust. Physiotherapy for Breast Surgery. — https://www.plymouthhospitals.nhs.uk/display-pil/pil-physiotherapy-for-breast-surgery-7032/ — Sustenta o contacto do antebraço na ombreira, a entrada lenta controlada pelas pernas, a sensação de alongamento no peito e ombro e a redução da posição quando há dor ou retenção da respiração. — Folheto de reabilitação pós-cirúrgica; não foi usado para autorizar execução após cirurgia nem para definir dose.
- Tipo: orientação profissional oficial
- Localizador: https://www.plymouthhospitals.nhs.uk/display-pil/pil-physiotherapy-for-breast-surgery-7032/
- Usada para: Sustenta o contacto do antebraço na ombreira, a entrada lenta controlada pelas pernas, a sensação de alongamento no peito e ombro e a redução da posição quando há dor ou retenção da respiração.
- Limite: Folheto de reabilitação pós-cirúrgica; não foi usado para autorizar execução após cirurgia nem para definir dose.

### Fonte 5: American Academy of Orthopaedic Surgeons. Rotator Cuff and Shoulder Conditioning Program.

- Autor ou entidade: D1-EXT-10 — guia profissional oficial — American Academy of Orthopaedic Surgeons. Rotator Cuff and Shoulder Conditioning Program. — https://www.orthoinfo.org/recovery/rotator-cuff-and-shoulder-conditioning-program/ — Sustenta a regra de não ignorar dor durante exercícios do ombro e de procurar um médico ou fisioterapeuta quando existe dor ou dúvida sobre a execução. — Guia geral de condicionamento do ombro, não instrução direta deste exercício.
- Tipo: guia profissional oficial
- Localizador: https://www.orthoinfo.org/recovery/rotator-cuff-and-shoulder-conditioning-program/
- Usada para: Sustenta a regra de não ignorar dor durante exercícios do ombro e de procurar um médico ou fisioterapeuta quando existe dor ou dúvida sobre a execução.
- Limite: Guia geral de condicionamento do ombro, não instrução direta deste exercício.
