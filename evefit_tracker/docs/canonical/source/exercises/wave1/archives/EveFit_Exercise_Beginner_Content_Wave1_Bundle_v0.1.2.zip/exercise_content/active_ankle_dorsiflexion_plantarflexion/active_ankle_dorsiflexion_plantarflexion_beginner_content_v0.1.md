# Flexão dorsal e plantar ativa do tornozelo

Conteúdo para principiantes em português europeu.

## Descrição curta

Movimento ativo do tornozelo para cima e para baixo, realizado em posição sentada e sem carga externa.

## O que é

Sentada numa cadeira estável, mantém a coxa e o joelho organizados e move o pé livre alternadamente em direção à perna e para longe dela. O movimento acontece sobretudo no tornozelo, no plano sagital; não é um círculo nem o alfabeto com o pé.

## O que vais fazer

Vais libertar um pé do chão e explorar duas direções opostas: aproximar o dorso do pé da perna, em flexão dorsal, e apontar o pé para longe da perna, em flexão plantar. Entre as duas direções, o pé passa pela posição neutra com controlo.

## Porque existe este movimento

Este movimento existe para explorar e controlar ativamente a amplitude sagital disponível no tornozelo. Esta finalidade técnica não constitui uma promessa de resultado nem uma prescrição individual.

## Antes de começares

1. Confirma que compreendes as duas direções e que consegues mover voluntariamente o pé sem deslocar de forma relevante o joelho.
2. Usa uma cadeira sólida, estável e sem rodas.
3. Confirma que a cadeira está num piso firme, nivelado e antiderrapante, com a área em redor desimpedida.
4. Se tens cirurgia recente, estás em retorno à função, tens sintomas persistentes ou instabilidade conhecida, procura revisão de um profissional de saúde antes de integrar o movimento numa rotina.

## Preparar o equipamento

1. Coloca uma cadeira estável e sem rodas no local ativo. Não é necessário outro equipamento. A cadeira deve ficar completamente imóvel quando te sentas e quando seguras nas suas laterais.

## Preparar o espaço

1. Escolhe um espaço estacionário mínimo, com piso firme, nivelado e antiderrapante sob toda a cadeira. Retira obstáculos próximos e não executes numa plataforma instável, num veículo em movimento ou sobre um piso escorregadio.

## Verificação do corpo

1. Consegues sentar-te com estabilidade e manter o tronco organizado.
2. Consegues deixar o pé alvo sem carga e mover o tornozelo de forma voluntária.
3. Não tens dor aguda, bloqueio articular, perda súbita de controlo, tontura ou mal-estar antes de começares.

## Posição inicial

Senta-te numa cadeira estável e sem rodas, com a bacia apoiada e o tronco organizado. Mantém o pé do lado oposto apoiado no chão. Deixa a coxa do lado alvo apoiada no assento, organiza o joelho e eleva apenas o suficiente para o pé alvo ficar sem carga. Começa com o tornozelo numa posição neutra confortável.

## Confirmar a posição inicial

1. A cadeira está imóvel e sem rodas.
2. O piso sob a cadeira é firme, nivelado e antiderrapante.
3. O pé do lado oposto está disponível para apoio.
4. A coxa do lado alvo está apoiada e o joelho mantém-se orientado.
5. O pé alvo está livre do chão e sem carga externa.
6. A respiração está natural e sem retenção.

## Passos de execução

1. Confirma a posição sentada estável e segura as laterais da cadeira apenas se isso ajudar a manter o corpo imóvel.
2. Liberta o pé alvo do chão sem levantar nem rodar a coxa e sem deslocar o joelho.
3. Parte de uma posição neutra confortável, com o pé alinhado com a perna.
4. Puxa o dorso do pé e os dedos em direção à parte da frente da perna, movendo no tornozelo dentro de uma amplitude controlada e tolerada.
5. Regressa pela posição neutra sem deixar o pé cair e sem usar impulso.
6. Aponta o pé para longe da perna, mantendo a direção para a frente e sem forçar o fim da amplitude.
7. Regressa com controlo à posição neutra, mantendo a coxa e o joelho sem deslocamento relevante.

## Fases do movimento

### Preparação

Pé alvo livre, tornozelo neutro, coxa apoiada e joelho organizado.

### Flexão dorsal

O dorso do pé aproxima-se da perna sem o joelho subir.

### Transição

O pé passa pela posição neutra com controlo ativo.

### Flexão plantar

O pé aponta para longe da perna sem desviar para os lados.

### Regresso

O tornozelo regressa à posição neutra e o pé pode voltar ao apoio.

## Respiração

Respira de forma natural e contínua durante todo o movimento. Não prendas a respiração. As fontes consultadas não sustentam uma fase respiratória específica para esta execução, por isso não se impõe uma contagem nem uma coordenação fixa entre respiração e direção do pé.

## Sensações esperadas

1. Movimento localizado sobretudo no tornozelo.
2. Ativação ligeira na parte da frente da perna ao puxar o pé para cima.
3. Ativação ligeira na barriga da perna ao apontar o pé.
4. Sensação suave de aproximação do limite de movimento, sem dor aguda nem bloqueio.

## Sensações inesperadas ou de alerta

1. Dor aguda.
2. Sensação de bloqueio articular.
3. Perda súbita de controlo do pé ou da perna.
4. Tontura ou mal-estar.

## Indicações técnicas principais

1. Cadeira firme, sem rodas e completamente imóvel.
2. Pé alvo livre; coxa apoiada e joelho quieto.
3. Puxa o pé para a perna e aponta-o depois para a frente.
4. Move para cima e para baixo, sem desenhar círculos.
5. Mantém controlo nas mudanças de direção.
6. Respira naturalmente, sem prender a respiração.

## Erros comuns e correções

### Erro 1: Mover a coxa ou o joelho em vez de isolar o movimento no tornozelo.

- Como reconhecer: O joelho sobe, desce ou desloca-se para os lados enquanto o pé se move.
- Como corrigir: Mantém a coxa apoiada, organiza o joelho e usa apenas a amplitude em que o membro permanece estável.

### Erro 2: Transformar o movimento num círculo ou desviar o pé para dentro e para fora.

- Como reconhecer: Os dedos desenham uma curva lateral em vez de seguirem para cima e para baixo.
- Como corrigir: Orienta os dedos para a frente e alterna apenas flexão dorsal e flexão plantar.

### Erro 3: Usar impulso ou deixar o pé cair na mudança de direção.

- Como reconhecer: O pé acelera sem controlo ou chega ao fim do movimento de forma brusca.
- Como corrigir: Mantém controlo ativo ao passar pela posição neutra e em cada regresso.

### Erro 4: Forçar o fim da amplitude.

- Como reconhecer: Surge dor aguda, bloqueio ou necessidade de mover toda a perna para avançar mais.
- Como corrigir: Não avances contra dor ou bloqueio; interrompe o movimento perante estes sinais.

### Erro 5: Usar uma cadeira com rodas ou colocada num piso instável.

- Como reconhecer: A cadeira desloca-se, oscila ou escorrega durante a preparação.
- Como corrigir: Muda para uma cadeira sólida sem rodas, sobre piso firme, nivelado e antiderrapante.

### Erro 6: Prender a respiração.

- Como reconhecer: A respiração fica suspensa ou o rosto e os ombros ficam desnecessariamente tensos.
- Como corrigir: Retoma uma respiração natural e contínua, sem contagens nem retenções.

## Formas de simplificar ou ensaiar

1. Aprende primeiro com um tornozelo de cada vez; a identidade permite execução unilateral ou bilateral.
2. Usa como referência uma trajetória simples para cima, neutro e para a frente, sem tentar alcançar o limite.
3. Mantém o pé livre perto do chão, sem lhe dar apoio, para ser mais fácil observar se a perna permanece quieta.
4. Pede a alguém que observe apenas se o joelho se desloca; essa pessoa não precisa de tocar nem mover o teu pé.

## Supervisão

Não requer parceiro, assistente de segurança nem supervisão em condições habituais quando os pré-requisitos, o equipamento e o ambiente são cumpridos. — Não consegues manter a posição sentada ou o suporte previsto. Tens medo de cair. Surgem sintomas durante a amplitude. Não consegues distinguir o movimento do tornozelo do deslocamento da perna. — Cirurgia recente, retorno à função, sintomas persistentes ou instabilidade conhecida requerem revisão profissional contextual antes de integrar o exercício numa rotina.

## Como terminar

Regressa o tornozelo a uma posição neutra confortável. Baixa o pé com controlo até ficar apoiado no piso. Confirma que não surgiu nenhum sinal de interrupção antes de mudares de posição. Levanta-te da cadeira apenas quando te sentires estável.

## Nota de segurança

Move apenas dentro de uma amplitude voluntária, controlada e tolerada. Não forces o fim da amplitude nem uses impulso. Interrompe perante dor aguda, bloqueio articular, perda súbita de controlo, tontura ou mal-estar.

## Quando parar ou reduzir

1. Dor aguda — Interrompe o movimento.
2. Bloqueio articular — Interrompe o movimento.
3. Perda súbita de controlo — Apoia o pé e interrompe o movimento.
4. Tontura ou mal-estar — Apoia os pés, permanece sentada em segurança e interrompe o movimento.

## Segurança do equipamento

A cadeira estável e sem rodas é obrigatória. Não uses assentos com rodas, instáveis ou que se desloquem quando te sentas ou seguras nas laterais. Não é suportada execução sem cadeira.

## Segurança do espaço

O piso sob a cadeira deve ser firme, nivelado e antiderrapante e a área deve estar desimpedida. Não uses piso escorregadio, plataforma instável ou veículo em movimento.

## Limitações

1. As fontes disponíveis usam contextos diferentes, incluindo exercício geral sentado, condicionamento do tornozelo, pós-operatório e investigação hemodinâmica em decúbito. Não foram importadas doses, ritmos, amplitudes máximas, indicações de tratamento ou promessas de resultado. O documento não determina adequação individual nem substitui revisão profissional quando existem gatilhos clínicos. Implementação realizada: não

## Teste de compreensão

### 1. Que cadeira deves usar?

Resposta esperada: Uma cadeira sólida, estável e sem rodas.

### 2. Que características deve ter o piso sob a cadeira?

Resposta esperada: Deve ser firme, nivelado e antiderrapante.

### 3. O pé alvo fica apoiado no chão durante o movimento?

Resposta esperada: Não. Fica livre e sem carga.

### 4. Que partes do membro devem permanecer sem deslocamento relevante?

Resposta esperada: A coxa, o joelho e a perna.

### 5. Em que direção se move o pé na flexão dorsal?

Resposta esperada: O dorso do pé e os dedos aproximam-se da parte da frente da perna.

### 6. Em que direção se move o pé na flexão plantar?

Resposta esperada: O pé aponta para longe da perna.

### 7. Deves desenhar círculos com o pé?

Resposta esperada: Não. O movimento é para cima e para baixo no plano sagital.

### 8. Deves forçar para chegar ao fim da amplitude?

Resposta esperada: Não. A amplitude deve permanecer voluntária, controlada e tolerada.

### 9. Como deves respirar?

Resposta esperada: De forma natural e contínua, sem prender a respiração.

### 10. O que fazes se surgir dor aguda ou bloqueio articular?

Resposta esperada: Interrompo o movimento.

### 11. Este exercício exige sempre parceiro, assistente de segurança ou supervisão?

Resposta esperada: Não, mas devo procurar supervisão se não consigo manter o suporte, tenho medo de cair, surgem sintomas ou não distingo o movimento da compensação.

### 12. O que deves fazer se tens cirurgia recente, sintomas persistentes ou instabilidade conhecida?

Resposta esperada: Procurar revisão profissional contextual antes de integrar o exercício numa rotina.

## Fontes e limites da evidência

### Fonte 1: Sitting exercises

- Autor ou entidade: C1-S07 — Sitting exercises — National Health Service, Reino Unido — orientação institucional oficial — https://www.nhs.uk/live-well/exercise/sitting-exercises/ — Cadeira sólida, estável e sem rodas; organização sentada; pé livre; apontar os dedos para longe e aproximá-los da pessoa. — Orientação geral; inclui dose e uma posição específica do joelho que não foram importadas. — 2026-07-24
- Tipo: orientação institucional oficial
- Localizador: https://www.nhs.uk/live-well/exercise/sitting-exercises/
- Usada para: Cadeira sólida, estável e sem rodas; organização sentada; pé livre; apontar os dedos para longe e aproximá-los da pessoa.
- Limite: C1-S07 — Sitting exercises — National Health Service, Reino Unido — orientação institucional oficial — https://www.nhs.uk/live-well/exercise/sitting-exercises/ — Cadeira sólida, estável e sem rodas; organização sentada; pé livre; apontar os dedos para longe e aproximá-los da pessoa. — Orientação geral; inclui dose e uma posição específica do joelho que não foram importadas. — 2026-07-24

### Fonte 2: Foot and Ankle Conditioning Program

- Autor ou entidade: C2-S02 — Foot and Ankle Conditioning Program — American Academy of Orthopaedic Surgeons — guia profissional oficial revisto por pares — https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/ — Movimento pequeno realizado pelo pé e tornozelo; dorsiflexão como puxar os dedos para a pessoa; flexão plantar como apontar os dedos; não ignorar dor e procurar orientação quando existe dúvida. — Programa de condicionamento e reabilitação; usa exercícios com banda ou alfabeto e inclui dose, que não foram importados para esta identidade sem resistência. — 2026-07-24
- Tipo: guia profissional oficial revisto por pares
- Localizador: https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/
- Usada para: Movimento pequeno realizado pelo pé e tornozelo; dorsiflexão como puxar os dedos para a pessoa; flexão plantar como apontar os dedos; não ignorar dor e procurar orientação quando existe dúvida.
- Limite: C2-S02 — Foot and Ankle Conditioning Program — American Academy of Orthopaedic Surgeons — guia profissional oficial revisto por pares — https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/ — Movimento pequeno realizado pelo pé e tornozelo; dorsiflexão como puxar os dedos para a pessoa; flexão plantar como apontar os dedos; não ignorar dor e procurar orientação quando existe dúvida. — Programa de condicionamento e reabilitação; usa exercícios com banda ou alfabeto e inclui dose, que não foram importados para esta identidade sem resistência. — 2026-07-24

### Fonte 3: Total Hip Replacement Exercise Guide — Ankle Pumps

- Autor ou entidade: EX25-S01 — Total Hip Replacement Exercise Guide — Ankle Pumps — American Academy of Orthopaedic Surgeons — guia profissional oficial — https://www.orthoinfo.org/recovery/total-hip-replacement-exercise-guide/ — Execução sentada ou deitada e movimento ativo do pé para cima e para baixo, dobrando no tornozelo. — Contexto pós-operatório específico; indicações, efeitos e dose não foram transferidos para conteúdo geral. — 2026-07-24
- Tipo: guia profissional oficial
- Localizador: https://www.orthoinfo.org/recovery/total-hip-replacement-exercise-guide/
- Usada para: Execução sentada ou deitada e movimento ativo do pé para cima e para baixo, dobrando no tornozelo.
- Limite: EX25-S01 — Total Hip Replacement Exercise Guide — Ankle Pumps — American Academy of Orthopaedic Surgeons — guia profissional oficial — https://www.orthoinfo.org/recovery/total-hip-replacement-exercise-guide/ — Execução sentada ou deitada e movimento ativo do pé para cima e para baixo, dobrando no tornozelo. — Contexto pós-operatório específico; indicações, efeitos e dose não foram transferidos para conteúdo geral. — 2026-07-24

### Fonte 4: Ankle positions and exercise intervals effect on the blood flow velocity in the common femoral vein during ankle pumping exercises

- Autor ou entidade: EX25-S02 — Ankle positions and exercise intervals effect on the blood flow velocity in the common femoral vein during ankle pumping exercises — Toya K, Sasano K, Takasoh T, et al. — estudo experimental primário — https://doi.org/10.1589/jpts.28.685 — Operacionalização do ankle pumping como alternância simples entre dorsiflexão e flexão plantar. — Amostra pequena de homens sem contraindicações e execução em decúbito; resultados hemodinâmicos, amplitude máxima, intervalos e ritmo experimental não foram usados como prescrição. — 2026-07-24
- Tipo: estudo experimental primário
- Localizador: https://doi.org/10.1589/jpts.28.685
- Usada para: Operacionalização do ankle pumping como alternância simples entre dorsiflexão e flexão plantar.
- Limite: EX25-S02 — Ankle positions and exercise intervals effect on the blood flow velocity in the common femoral vein during ankle pumping exercises — Toya K, Sasano K, Takasoh T, et al. — estudo experimental primário — https://doi.org/10.1589/jpts.28.685 — Operacionalização do ankle pumping como alternância simples entre dorsiflexão e flexão plantar. — Amostra pequena de homens sem contraindicações e execução em decúbito; resultados hemodinâmicos, amplitude máxima, intervalos e ritmo experimental não foram usados como prescrição. — 2026-07-24

### Fonte 5: Lateral Ankle Ligament Sprains: Revision 2021 Clinical Practice Guidelines

- Autor ou entidade: C2-S21 — Lateral Ankle Ligament Sprains: Revision 2021 Clinical Practice Guidelines — Martin RL, Davenport TE, Fraser JJ, et al. — guideline clínica profissional — https://www.jospt.org/doi/10.2519/jospt.2021.0302 — Enquadramento conservador de movimento do tornozelo e necessidade de distinguir exercício geral de decisão clínica em lesão. — Documento específico para entorse lateral e dirigido a profissionais; não define esta execução pública nem autoriza exercício perante sintomas. — 2026-07-24
- Tipo: guideline clínica profissional
- Localizador: https://www.jospt.org/doi/10.2519/jospt.2021.0302
- Usada para: Enquadramento conservador de movimento do tornozelo e necessidade de distinguir exercício geral de decisão clínica em lesão.
- Limite: C2-S21 — Lateral Ankle Ligament Sprains: Revision 2021 Clinical Practice Guidelines — Martin RL, Davenport TE, Fraser JJ, et al. — guideline clínica profissional — https://www.jospt.org/doi/10.2519/jospt.2021.0302 — Enquadramento conservador de movimento do tornozelo e necessidade de distinguir exercício geral de decisão clínica em lesão. — Documento específico para entorse lateral e dirigido a profissionais; não define esta execução pública nem autoriza exercício perante sintomas. — 2026-07-24
