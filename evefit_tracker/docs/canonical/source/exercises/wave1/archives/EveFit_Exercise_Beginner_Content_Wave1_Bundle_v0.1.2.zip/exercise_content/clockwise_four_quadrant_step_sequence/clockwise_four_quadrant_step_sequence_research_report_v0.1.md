# Relatório de investigação — sequência de passos em quatro quadrantes no sentido horário

**Exercise ID:** `clockwise_four_quadrant_step_sequence`  
**Agente:** EX-39  
**Data da pesquisa:** 24 de julho de 2026  
**Implementação realizada:** não

## Âmbito

Este relatório sustenta conteúdo documental para principiante sobre:

- preparação de uma grelha plana de quatro quadrantes;

- sequência passo-junta no sentido horário;

- respiração;

- risco de tropeção e queda;

- erros frequentes;

- supervisão.

Ficaram fora do âmbito código, publicação, prescrição, dose, diagnóstico, tratamento, aprovação de multimédia, criação de variantes e criação ou alteração de relações canónicas.

## Identidade e limites congelados

A identidade recebida foi preservada sem alterações:

1. início em pé no quadrante posterior esquerdo;

2. deslocação passo-junta para o quadrante anterior esquerdo;

3. deslocação passo-junta para o anterior direito;

4. deslocação passo-junta para o posterior direito;

5. regresso passo-junta ao posterior esquerdo.

O exercício mantém risco operacional **moderado**, alvo visual obrigatório, ausência de equipamento obrigatório, fita plana opcional, superfície firme, nivelada e antiderrapante, marcações sem relevo, espaço multidirecional livre e supervisão recomendada.

Não foi confundido com o Four Square Step Test: não contém obstáculos, cronometragem ou pontuação. Também não foi tratado como o programa Square-Stepping Exercise completo, que inclui múltiplos padrões e organização programática.

## Perguntas de investigação

1. Que características do Square-Stepping Exercise sustentam uma tarefa em grelha com passos multidirecionais?

2. Que instruções profissionais apoiam o padrão de passo lateral seguido de reunião dos pés?

3. Que cuidados são adequados para um passo para trás e para mudanças de direção?

4. Como devem ser preparados o piso, as marcações, a iluminação e o espaço?

5. Existe uma relação respiratória específica para esta sequência?

6. Quando é prudente recomendar supervisão ou revisão de elegibilidade?

## Fontes e apreciação

### 1. Shigematsu et al., 2008 — literatura primária

**Referência:** Shigematsu R, Okura T, Nakagaichi M, et al. *Square-stepping exercise and fall risk factors in older adults: a single-blind, randomized controlled trial*. J Gerontol A Biol Sci Med Sci. 2008;63(1):76-82.  
**Ligação:** [PubMed](https://pubmed.ncbi.nlm.nih.gov/18245764/) | [DOI](https://doi.org/10.1093/gerona/63.1.76)

**Contributo:** estudo primário aleatorizado sobre Square-Stepping Exercise, um programa de baixo custo realizado em interior e composto por padrões de passos em grelha. Sustenta a existência da família de sequências multidirecionais e o envolvimento de aptidão dos membros inferiores e controlo de deslocamento.

**Limite:** o estudo avalia um programa, não a sequência fechada específica deste exercício. Os resultados do estudo não foram convertidos em promessa, dose ou instrução clínica.

### 2. Shigematsu e Okura, 2006 — literatura primária independente

**Referência:** Shigematsu R, Okura T. *A novel exercise for improving lower-extremity functional fitness in the elderly*. Aging Clin Exp Res. 2006;18(3):242-248.  
**Ligação:** [DOI](https://doi.org/10.1007/BF03324655) | [PubMed](https://pubmed.ncbi.nlm.nih.gov/16804371/)

**Contributo:** estudo controlado não aleatorizado que descreve o Square-Stepping Exercise com passos para a frente, para trás, laterais e oblíquos. Confirma que as direções presentes na identidade pertencem à família técnica investigada.

**Limite:** também se refere a um programa com vários padrões, não à ordem posterior esquerdo → anterior esquerdo → anterior direito → posterior direito → posterior esquerdo.

### 3. NHS — orientação profissional oficial

**Fonte:** NHS, [Balance exercises](https://www.nhs.uk/live-well/exercise/balance-exercises/).

**Contributo:** a caminhada lateral é descrita como um passo controlado de um pé seguido da reunião do outro. A fonte recomenda considerar uma parede ou cadeira estável caso haja perda de equilíbrio e enfatiza movimento lento e controlado.

**Aplicação ao conteúdo:** fundamenta as pistas “um pé entra; o outro junta-se”, controlo nas transições e atenção à necessidade de apoio ou supervisão. Não foi introduzida uma cadeira no trajeto, pois isso criaria um obstáculo e alteraria as condições canónicas do espaço.

### 4. Oxford University Hospitals NHS Foundation Trust — orientação profissional oficial

**Fonte:** [OTAGO Strength and Balance: Home Exercise Programme](https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf).

**Contributo:** recomenda preparar o espaço, usar vestuário confortável e calçado de suporte, respirar normalmente e usar um apoio firme conforme a necessidade de equilíbrio. As instruções para caminhada lateral e para trás enfatizam controlo, postura e atenção à segurança.

**Aplicação ao conteúdo:** sustenta respiração natural e contínua, preparação do espaço, controlo do passo lateral e posterior e a necessidade de ajustar supervisão à capacidade. Não foram transpostas doses do programa.

### 5. CDC/NIOSH — prevenção oficial de escorregões, tropeções e quedas

**Fonte:** CDC/NIOSH, [Slip, Trip, and Fall Prevention for Healthcare Workers](https://www.cdc.gov/niosh/docs/2011-123/pdfs/2011-123.pdf).

**Contributo:** a orientação para elementos colocados no piso favorece materiais planos, fixos e sem bordos enrolados, rasgados ou móveis.

**Aplicação ao conteúdo:** apoia a exigência de fita totalmente aderente e a exclusão de marcações soltas ou elevadas. A fonte é ocupacional e não específica de exercício, pelo que foi usada apenas para o mecanismo ambiental de tropeção.

### 6. CDC STEADI — prevenção oficial de quedas

**Fonte:** CDC STEADI, [Check for Safety: A Home Fall Prevention Checklist for Older Adults](https://www.cdc.gov/steadi/pdf/steadi-brochure-checkforsafety-508.pdf).

**Contributo:** recomenda percursos livres de móveis, objetos e cabos, tratamento de tapetes soltos e iluminação adequada.

**Aplicação ao conteúdo:** sustenta a inspeção de toda a área multidirecional, incluindo a zona posterior que não fica sempre visível durante o passo para trás.

## Síntese da evidência por tema

| Tema | Conclusão documental | Base |
|---|---|---|
| Quatro quadrantes | Devem ser alvos visuais planos; fita é opcional e totalmente aderente. | Identidade canónica; CDC/NIOSH; CDC STEADI. |
| Sequência | A ordem fica congelada: frente, direita, trás, esquerda, com reunião dos pés em cada destino. | Identidade canónica; NHS para passo lateral e reunião. |
| Passo para trás | Exige confirmação prévia do destino e controlo; não se introduzem obstáculos. | Identidade canónica; OTAGO; CDC STEADI. |
| Respiração | Natural e contínua, sem retenção, contagem ou associação rígida a passos. | OTAGO; ausência de evidência específica para esta sequência. |
| Tropeção/queda | Piso firme, nivelado, seco e antiderrapante; percurso iluminado e livre; marcações sem relevo. | CDC/NIOSH; CDC STEADI; identidade canónica. |
| Supervisão | Recomendada; deve ser revista perante risco elevado de queda, quedas recentes, apoio não planeado ou incapacidade de sair autonomamente. | Identidade canónica; NHS; OTAGO. |

## Decisões editoriais

### Ordem e orientação

Foi usada a mnemónica “frente, direita, trás, esquerda”. Cada transição termina com os dois pés no mesmo quadrante. Não foi definido um pé líder obrigatório porque a identidade canónica não congela a lateralidade do primeiro pé em cada transição.

### Respiração

Não foi encontrada base para sincronizar inspiração ou expiração com qualquer passo. A formulação segura e proporcional é respirar naturalmente, sem reter o ar, e parar em apoio estável se a concentração levar a sustentar a respiração.

### Segurança do passo para trás

A pessoa deve confirmar que o quadrante posterior direito e a margem estão livres antes da transferência de peso. Não se aconselha olhar prolongadamente por cima do ombro nem rodar o corpo de modo a transformar a identidade; a prioridade documental é conhecer o espaço antes de iniciar e antecipar o destino.

### Marcações

As marcações são opcionais como equipamento, mas os quatro alvos visuais são necessários. Fita mal colada, corda, vara, barra ou qualquer separador elevado aumenta o risco de tropeção e foi explicitamente excluído.

### Supervisão

A supervisão continua classificada como recomendada, não universalmente obrigatória. Os gatilhos canónicos foram mantidos: risco elevado de queda, contexto clinicamente condicionado e incapacidade de sair da tarefa de forma independente. Quedas recentes, dificuldade no passo para trás e apoio repetido não planeado justificam revisão da adequação.

## Erros selecionados

Foram incluídos erros observáveis e diretamente corrigíveis:

- saltar um quadrante ou trocar a ordem;

- não reunir os dois pés;

- cruzar os pés;

- acelerar quando a ordem deixa de estar clara;

- usar marcações elevadas ou soltas;

- recuar sem confirmar o espaço.

Estes erros cobrem identidade, controlo motor e risco ambiental sem introduzir prescrição.

## Relações canónicas preservadas

| Relação | Estado | Papel | Limite preservado |
|---|---|---|---|
| Ativação → controlo motor e coordenação → sequência motora repetida → preparar temporização | Condicional | Complementar | Não implica cadência alta; risco mínimo moderado. |
| Treino principal → controlo motor e coordenação → controlo da base de apoio → melhorar equilíbrio dinâmico | Compatível | Alternativa primária | Sem obstáculos elevados ou rapidez obrigatória; risco mínimo moderado. |
| Treino principal → controlo motor e coordenação → sequência motora repetida → melhorar ordenação | Compatível | Alternativa primária | Ordem congelada; não inferir outras ordens; risco mínimo moderado. |
| Aquecimento → controlo motor e coordenação → sequência motora repetida → ensaiar sequência | Condicional | Candidata principal | O risco do passo para trás tem de ser aceitável; risco mínimo moderado. |

Não foram adicionadas, removidas ou reclassificadas relações.

## Confiança e limitações

**Confiança global:** moderada.

- **Alta** para identidade, ambiente, risco e relações, porque foram recebidos como dados canónicos.

- **Alta** para prevenção ambiental de tropeção e queda, sustentada por duas fontes oficiais independentes.

- **Moderada** para instruções de execução, porque a literatura primária sustenta a família de passos multidirecionais, mas não esta sequência isolada.

- **Moderada** para respiração, porque existe orientação profissional para respirar normalmente, mas não uma relação respiratória específica para este padrão.

Não se inferem efeitos, dose, velocidade, cadência, progressão, tratamento, diagnóstico, autorização universal ou aprovação de multimédia.

## Verificação contratual

- Português europeu e UTF-8 NFC: previsto para validação final.

- Passos de execução: sete.

- Pistas principais: seis.

- Erros comuns: seis, cada um com reconhecimento e correção.

- Perguntas de compreensão: doze.

- Fontes independentes: duas fontes primárias e quatro fontes oficiais/profissionais.

- Identidade, risco moderado, equipamento, marcações, superfície, espaço e relações: preservados.

- Dose e prescrição: ausentes.

- Promessa, diagnóstico e tratamento: ausentes.

- Código, publicação e implementação: ausentes.

- Implementação realizada: não.
