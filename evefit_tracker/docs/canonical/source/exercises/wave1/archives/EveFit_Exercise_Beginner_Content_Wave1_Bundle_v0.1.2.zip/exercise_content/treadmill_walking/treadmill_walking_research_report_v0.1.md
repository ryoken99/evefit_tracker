# Relatório de investigação — `treadmill_walking`

## Âmbito

Investigação documental para conteúdo de execução destinado a principiantes absolutos. Foram estudados preparação, entrada, posição inicial, execução, respiração, paragem, saída, chave de segurança, falhas comuns e limites da variante formal de `overground_walking`.

Foram preservados sem alteração:

- identidade `treadmill_walking`;
- tipo `exercise_variant`;
- risco operacional `moderate`;
- equipamento obrigatório `motorized_treadmill`;
- relação formal com `overground_walking`;
- relações canónicas aprovadas;
- estado dos meios.

Implementação realizada: não

## Método e critérios de fonte

Foram mantidas as três fontes profissionais já associadas ao registo canónico. A pesquisa adicional privilegiou documentação oficial de equipamento de dois fabricantes independentes, orientação profissional para respiração e literatura científica primária para a distinção entre passadeira e marcha no solo.

Não foram usadas fontes comerciais secundárias, fóruns ou conteúdo editorial para decidir técnica ou segurança.

## Fontes e contributos

| Código | Fonte | Tipo | Contributo utilizado | Limite |
|---|---|---|---|---|
| `A1-S01` | ACSM, *Exercising Your Way to Lowering Your Blood Pressure* | Organização profissional | Caminhada como modalidade aeróbia ao nível da família | Não descreve técnica fina da passadeira; nenhuma dose foi transportada |
| `A1-S31` | ACSM / Exercise is Medicine, *Preparticipation Screening Guidelines* | Guideline profissional | Prudência perante sintomas e separação da elegibilidade individual | Não decide elegibilidade para uma pessoa |
| `A2-S04` | ACSM, *Investing in a Personal Trainer* | Organização profissional | Caminhada como atividade aeróbia e valor da orientação qualificada | Não sustenta a identidade fina |
| `EX11-S01` | Life Fitness, *T3.0/T3.5 Treadmill Operation Manual, 7965201 Rev A* | Documentação oficial de equipamento | Plataformas laterais no arranque; área posterior livre; apoios para estabilidade; objetos afastados das partes móveis; interrupção perante sintomas | Manual de modelos específicos |
| `EX11-S02` | TRUE Fitness, *TM50-23 Owner's Manual and Assembly Guide, MAN-TM50-23 REV04* | Documentação oficial de equipamento independente | Chave presa à roupa; montagem com tapete parado; plataformas laterais; apoio na entrada/saída; inspeção de anomalias; chave remove-se após uso | Manual de um modelo específico |
| `EX11-S03` | American Heart Association, *Getting Active to Control High Blood Pressure* | Orientação profissional | Respiração regular e contínua; evitar retenção | Orientação geral, não técnica específica da caminhada |
| `EX11-S04` | Lee e Hidler, 2008, *Biomechanics of overground vs. treadmill walking in healthy individuals* | Estudo científico primário | Comparabilidade parcial e diferenças biomecânicas entre as duas condições | Amostra de adultos saudáveis; não determina resposta individual |

## Ligações

- `A1-S01`: https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf
- `A1-S31`: https://www.exerciseismedicine.org/assets/page_documents/ACSM%20Preparticipation%20Screening%20Guidelines.pdf
- `A2-S04`: https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf
- `EX11-S01`: https://kb.cybexintl.com/Owners_Manuals/Treadmill/Life_Fitness_T3.0_T3.5_Operation_Manual_7965201_English.pdf
- `EX11-S02`: https://shop.truefitness.com/wp-content/uploads/sites/2/2024/12/MAN-TM50-23-REV04-Owners-Manual-and-Assembly-Guide.pdf
- `EX11-S03`: https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure
- `EX11-S04`: https://pubmed.ncbi.nlm.nih.gov/18048582/

## Síntese da evidência

### Preparação e entrada

Os dois manuais independentes convergem em não iniciar sobre a superfície móvel: a pessoa posiciona-se nas plataformas laterais fixas, orientada para a consola, e mantém acesso aos apoios e comandos. O tapete deve estar parado durante a montagem da estrutura.

Esta sequência foi adotada porque reduz a exposição a movimento inesperado sem alterar a identidade mecânica da caminhada.

### Chave de segurança

A TRUE Fitness descreve a chave como um dispositivo com cordão que liga utilizador e consola e cuja remoção pára o movimento. Os manuais também deixam claro que o clipe deve ser preso à roupa antes da utilização.

O conteúdo evita afirmar uma paragem instantânea: usa “inicia a paragem”, porque a desaceleração concreta depende do modelo. A chave é apresentada como uma salvaguarda adicional e não como substituto dos apoios, dos comandos ou da posição controlada.

### Execução

O padrão nuclear continua a ser uma sequência de passos alternados. A superfície move-se sob os pés e exige ajustes contínuos para o corpo permanecer aproximadamente centrado relativamente à máquina.

A literatura de Lee e Hidler sustenta que marcha no solo e em passadeira são semelhantes em vários resultados, mas não idênticas. Isto apoia a classificação como variante: preserva-se a caminhada, mas muda a relação corpo-superfície e deixam de existir deslocamento líquido e trajetória global pelo espaço.

### Apoios

O manual Life Fitness permite o uso dos corrimãos quando é necessária estabilidade adicional, mas refere que não se destinam a uso contínuo. O conteúdo, por isso, aceita apoio na entrada, utilização de comandos, saída ou adaptação prevista, sem normalizar dependência contínua que altere o padrão.

### Respiração

A American Heart Association recomenda respirar regularmente durante a atividade e evitar reter a respiração. Como não foi encontrada uma técnica respiratória específica e necessária para a identidade desta variante, foi adotada a formulação conservadora: respiração natural, regular e contínua, sem contagens nem retenções.

### Paragem e saída

Os fabricantes sustentam controlo pelos comandos, utilização dos apoios na transição e montagem/desmontagem com o tapete parado. O conteúdo pede que a pessoa acompanhe a desaceleração, aguarde a imobilização completa, passe para as plataformas laterais e só depois desça.

### Segurança e sinais de interrupção

Foram preservados os sinais canónicos:

- desconforto no peito ou falta de ar atípica;
- tonturas ou confusão;
- perda de controlo ou dor nova.

Foram acrescentados apenas sinais operacionais observáveis da máquina: deslizamento, ruído anormal, velocidade inesperada ou falta de resposta. Estes sinais não alteram o nível de risco; explicam quando não continuar a utilizar o equipamento.

## Decisões editoriais

1. A explicação da variante foi escrita a partir das diferenças formais, sem reproduzir o conteúdo público de `overground_walking`.
2. Não foi acrescentado equipamento alternativo, opcional ou improvisado.
3. Não foi reduzida a supervisão recomendada.
4. Não foram introduzidas novas relações de contexto, capacidade, conceito ou intenção.
5. Não foram definidos velocidade, inclinação, duração, distância, intervalos, intensidade ou progressão.
6. Não foram feitas promessas de resultado, diagnósticos, tratamentos ou autorizações universais.
7. A linguagem da chave de segurança foi limitada para acomodar diferenças entre modelos.

## Qualidade e limitações

**Confiança global:** alta.

- **Execução e segurança do equipamento:** alta, pela convergência de dois manuais oficiais independentes.
- **Distinção da variante:** alta, pela coerência entre identidade canónica e literatura biomecânica primária.
- **Respiração:** moderada, por assentar em orientação profissional geral e não numa exigência técnica específica da passadeira.

Limitações:

- Os comandos, a sequência eletrónica e a desaceleração variam entre modelos.
- Um manual específico da máquina prevalece sobre descrições genéricas.
- A literatura biomecânica não autoriza extrapolações para todas as populações.
- O conteúdo não decide elegibilidade individual nem substitui avaliação clínica, supervisão ou assistência técnica.

## Verificação do contrato

- Português europeu e UTF-8 NFC: verificado.
- Passos de execução: 9.
- Pistas principais: 5.
- Erros comuns estruturados: 6.
- Perguntas de compreensão: 12.
- `formal_variant_explanation`: preenchido.
- Identidade, risco, equipamento e relações: preservados.
- Dose e prescrição: ausentes.
- Promessas, diagnóstico e tratamento: ausentes.
- Código, publicação e aprovação de meios: não realizados.
