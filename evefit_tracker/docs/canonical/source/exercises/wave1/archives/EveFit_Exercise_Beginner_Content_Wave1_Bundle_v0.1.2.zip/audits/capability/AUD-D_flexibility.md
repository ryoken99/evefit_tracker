# AUD-D — Auditoria independente de flexibilidade

## Âmbito

Auditoria independente, exclusivamente de leitura, dos exercícios cujo JSON declara `capability_primary == "flexibility"` em `EveFit_Exercise_Beginner_Content_Wave1_v0.1/exercise_content`.

Foram revistos 9 exercícios, 27 outputs (JSON, Markdown público e relatório de investigação por exercício) e os 9 pacotes de entrada correspondentes em `_beginner_content_workspace/agent_inputs`:

1. `seated_butterfly_adductor_stretch` — EX-26;
2. `standing_soleus_wall_stretch` — EX-27;
3. `standing_gastrocnemius_wall_stretch` — EX-28;
4. `supine_self_assisted_hamstring_stretch` — EX-29;
5. `doorway_pectoral_stretch` — EX-30;
6. `seated_single_leg_hamstring_stretch` — EX-31;
7. `front_to_back_leg_swing` — EX-32;
8. `lateral_leg_swing` — EX-33;
9. `supine_hamstring_strap_stretch` — EX-34.

Não foram revistos exercícios de outras capacidades nem relatórios de outros auditores.

## Método

Para cada exercício:

- confirmei o âmbito pelo valor estruturado de `capability_primary`;
- comparei identidade, família, tipo, `variant_of`, `base_exercise_id`, risco, equipamento, ambiente, supervisão e relações com o pacote de entrada;
- confrontei JSON, Markdown e relatório quanto a clareza, posição inicial, passos, fases, respiração, sensações esperadas, sinais de aviso, erros, correções, saída, segurança, equipamento e supervisão;
- validei as chaves obrigatórias e a sua ordem, mínimos de passos/pistas/erros, forma dos erros, 12 perguntas de compreensão e explicação formal da variante EX-34;
- procurei dose fixa, séries, repetições fixas, carga, cadência, duração, tempo de retenção, progressão programada, promessas, diagnóstico, tratamento e autorização universal;
- verifiquei coerência entre os pares familiares: gémeos/sóleo, balanço sagital/lateral e isquiotibiais sentado/supino autoassistido/supino com correia.

Escala usada: **conforme**, **conforme com achado não bloqueante** ou **não conforme**. Severidades dos findings: alta, média ou baixa. `Blocker: sim` impediria aprovação do pacote; nenhum foi encontrado.

## Estados por exercício

| Exercício | Estado | Síntese |
|---|---|---|
| EX-26 `seated_butterfly_adductor_stretch` | Conforme | Posição, abertura autolimitada, ausência de pressão nos joelhos, respiração, sensação medial, saída e risco baixo são coerentes. |
| EX-27 `standing_soleus_wall_stretch` | Conforme com achado não bloqueante | Identidade de joelho posterior fletido, calcanhar apoiado e avanço controlado está preservada. Abrangido pelo finding F-01. |
| EX-28 `standing_gastrocnemius_wall_stretch` | Conforme | Distingue corretamente o joelho posterior estendido da versão do sóleo; apoio, alinhamento, sensação e saída são claros. |
| EX-29 `supine_self_assisted_hamstring_stretch` | Conforme com achado não bloqueante | Execução pública é clara e segura, mas a descrição da fonte no JSON/relatório contém a contradição F-02. |
| EX-30 `doorway_pectoral_stretch` | Conforme | Apoio fixo, posição do antebraço, movimento do tronco, risco do ombro, respiração e saída estão coerentes com o pacote. |
| EX-31 `seated_single_leg_hamstring_stretch` | Conforme | Inclinação pela anca, joelho sem bloqueio agressivo, tornozelo descontraído e fronteira muscular/neural estão bem delimitados. |
| EX-32 `front_to_back_leg_swing` | Conforme com achado não bloqueante | Trajetória sagital, travagem, apoio opcional e controlo do impulso estão coerentes. Abrangido pelo finding F-01. |
| EX-33 `lateral_leg_swing` | Conforme com achado não bloqueante | Trajetória lateral, pelve orientada, espaço, travagem e apoio opcional estão coerentes. Abrangido pelo finding F-01. |
| EX-34 `supine_hamstring_strap_stretch` | Conforme com achados não bloqueantes | Variante, grupo alternativo correia/toalha, riscos adicionais e saída estão preservados; aplicam-se F-01 e F-03. |

## Findings

### F-01 — Tipos JSON variam entre exercícios para os mesmos campos

- **Severidade:** média
- **Blocker:** não
- **Campo:** coerência familiar / contrato JSON — `equipment_setup_pt_pt`, `environment_setup_pt_pt`, `body_readiness_check_pt_pt`, `execution_steps_pt_pt`, `breathing_guidance_pt_pt`, `ending_the_exercise_pt_pt` e `stop_or_reduce_signs_pt_pt`
- **Evidência:** `standing_soleus_wall_stretch_beginner_content_v0.1.json:18` usa texto simples em `body_readiness_check_pt_pt`, enquanto os restantes usam listas; `front_to_back_leg_swing_beginner_content_v0.1.json:22` usa objeto em `equipment_setup_pt_pt`, `lateral_leg_swing_beginner_content_v0.1.json:22` usa lista e vários siblings usam texto; `supine_hamstring_strap_stretch_beginner_content_v0.1.json:68` usa uma lista de strings em `execution_steps_pt_pt`, enquanto `doorway_pectoral_stretch_beginner_content_v0.1.json:38` e os demais usam objetos com número e instrução. Há variações equivalentes nos campos de respiração, saída e sinais de redução/paragem.
- **Impacto:** o conteúdo humano permanece compreensível e as chaves e mínimos contratuais estão presentes, mas um consumidor estruturado não pode tratar estes campos de forma uniforme sem lógica específica por exercício. A incoerência reduz a previsibilidade do pacote e a coerência entre siblings.
- **Revisão requerida:** definir no contrato um tipo único por campo e normalizar os 9 JSON sem alterar o significado. Para passos, preferir uma lista de objetos com pelo menos `step` e `instruction_pt_pt`; aplicar o mesmo princípio a setup, respiração, saída e sinais de paragem.

### F-02 — A posição das mãos é descrita de forma anatomicamente contraditória na proveniência

- **Severidade:** baixa
- **Blocker:** não
- **Campo:** EX-29 `sources_consulted[].used_for_pt_pt` e relatório de investigação / posição das mãos
- **Evidência:** `supine_self_assisted_hamstring_stretch_beginner_content_v0.1.json:211` e `supine_self_assisted_hamstring_stretch_research_report_v0.1.md:34` dizem “mãos atrás da coxa abaixo do joelho”. O próprio relatório em `:36`, o JSON de execução em `:31`, `:47`, `:108`, `:119` e `:186`, e o Markdown em `:28`, `:42`, `:71` e `:151` instruem corretamente “na parte posterior da coxa, acima da dobra do joelho”.
- **Impacto:** não contamina a execução pública, que é consistente e segura, mas cria ambiguidade anatómica na rastreabilidade da fonte e contradiz a decisão editorial.
- **Revisão requerida:** corrigir a descrição de proveniência para “mãos atrás da coxa, acima da dobra do joelho” ou reproduzir com precisão a formulação da fonte, deixando explícita a diferença editorial.

### F-03 — “Zona estável do pé” não é suficientemente operacional para um principiante

- **Severidade:** baixa
- **Blocker:** não
- **Campo:** EX-34 / posição e segurança da correia — `formal_variant_explanation.additional_setup_pt_pt`, `equipment_setup_pt_pt`, `starting_position_checklist_pt_pt` e instrução pública
- **Evidência:** `supine_hamstring_strap_stretch_beginner_content_v0.1.md:26`, `:49`, `:78`, `:96` e `:155`, e o JSON em `:15`, `:40`, `:63`, `:81` e `:148`, repetem “zona estável do pé” sem a tornar visualmente reconhecível. O próprio Markdown em `:258`, o JSON em `:337` e o relatório em `:67` reconhecem que não foi encontrada uma norma única para a zona exata.
- **Impacto:** as salvaguardas “não sobre os dedos”, sem pressão dolorosa e teste com tração mínima reduzem o risco, pelo que o finding não é bloqueante. Ainda assim, a instrução central de colocação do equipamento exige interpretação por parte de um principiante e pode favorecer deslizamento ou pressão localizada.
- **Revisão requerida:** obter validação técnica/editorial para uma descrição operacional e observável da zona permitida, sem inventar uma posição universal; se não houver base para maior precisão, declarar explicitamente que a colocação deve ser demonstrada ou revista antes da primeira utilização.

## Padrões confirmados

- As 9 identidades, nomes, tipos, famílias, capacidades, `variant_of` e `base_exercise_id` coincidem com os pacotes de entrada.
- Os níveis de risco foram preservados: baixo em 6 exercícios e moderado em 3.
- Equipamento, alternativas, ausência de parceiro/spotter e requisito de supervisão `none` foram preservados.
- As condições ambientais obrigatórias e proibidas foram traduzidas sem redução de segurança.
- A variante EX-34 mantém corretamente o exercício-base, a mudança da assistência manual direta para correia/toalha, o grupo alternativo obrigatório, o tapete opcional e os riscos adicionais.
- As famílias são mecanicamente coerentes: joelho estendido versus fletido na parede; plano sagital versus lateral nos balanços; assistência pelas mãos versus assistência através do pé na família supina.
- Todos os exercícios incluem entrada e saída controladas, respiração natural e contínua sem retenção, sensação de alongamento tolerável e distinção clara de dor/sintomas neurológicos.
- Todos incluem pelo menos 5 passos, pelo menos 4 pistas, pelo menos 4 erros com reconhecimento e correção, e 12 perguntas de compreensão.
- Não foram encontrados números fixos de repetições, séries, duração, distância, carga, cadência, frequência, tempo de retenção ou progressão programada.
- Não foram encontradas promessas de resultado, prevenção garantida, diagnóstico, tratamento ou autorização universal.

## Contagens

- Exercícios auditados: **9**
- Outputs auditados: **27** (9 JSON, 9 Markdown, 9 relatórios)
- Pacotes de invariantes auditados: **9**
- Exercícios conformes: **9**
- Exercícios não conformes: **0**
- Findings: **3**
- Severidade alta: **0**
- Severidade média: **1**
- Severidade baixa: **2**
- Blockers: **0**
- Violações de identidade/risco/equipamento/relações: **0**
- Violações de dose/tempo de retenção/promessas: **0**
- Campos por resolver declarados nos JSON: **0**

## Independência e implementação

AUD-D não foi autor destes conteúdos. Não foram lidos relatórios de outros auditores. A revisão foi limitada aos ficheiros do âmbito e aos respetivos pacotes de entrada.

Nenhum conteúdo de exercício foi editado. Não foi implementado código, publicação, multimédia, prescrição, alteração ontológica ou correção. **Implementação realizada: zero.**
