# Relatório de investigação — `half_kneeling_ankle_dorsiflexion_rock`

## Resultado

O conteúdo para principiante pode ser aprovado com limites. Há convergência suficiente para documentar a posição de meio-ajoelhado, o avanço do joelho com o pé apoiado, o controlo do calcanhar, a amplitude limitada por tolerância e controlo e a necessidade de distinguir exercício de teste. A evidência direta não demonstra a eficácia desta identidade exata nem sustenta dose, metas de amplitude ou adequação universal.

**Implementação realizada: não**

## Âmbito investigado

Foram investigados:

- execução e fases do movimento;

- posicionamento do pé, joelho, bacia e contactos de suporte;

- respiração;

- segurança, sinais de redução e interrupção;

- controlo da amplitude;

- erros técnicos;

- necessidades de supervisão;

- fronteira com teste joelho-à-parede e com mobilização assistida.

Não foram investigadas nem produzidas dose, prescrição individual, diagnóstico, tratamento, promessa de resultado, código ou publicação.

## Âncoras canónicas preservadas

| Campo | Decisão preservada |
|---|---|
| Identidade | Avanço e regresso do joelho em meio-ajoelhado, com o pé dianteiro totalmente apoiado e o calcanhar no chão. |
| Distinção | Não é teste joelho-à-parede nem versão em pé. |
| Família | `weight_bearing_ankle_dorsiflexion_family` |
| Variante/base | `variant_of: none`; `base_exercise_id: none` |
| Equipamento | Nenhum obrigatório; `exercise_mat` opcional. |
| Superfície | Firme, nivelada, antiderrapante e tolerável para o joelho de trás. |
| Supervisão | `none`; sem spotter, mantendo os gatilhos canónicos de procura de supervisão. |
| Risco | Moderado. |
| Relações aprovadas | Preservadas sem adição, remoção ou alteração. |

## Estratégia de pesquisa

Foram priorizadas fontes clínicas oficiais, guidelines e literatura primária. As fontes existentes no pacote foram usadas como ponto de partida e complementadas por uma guideline hospitalar independente e estudos primários sobre dorsiflexão em carga e a distinção entre screen, medida e exercício.

Não foi usada literatura comercial como base decisória. Não foram transferidas doses, cronologias de reabilitação, valores normativos ou alegações de prevenção.

## Fontes consultadas e apreciação

### C1-S21 — Kingston and Richmond NHS Foundation Trust

**Referência:** [What to expect after an ankle fracture](https://www.kingstonandrichmond.nhs.uk/patients-and-families/patient-leaflets/what-expect-after-ankle-fracture), 2024.  
**Tipo:** orientação clínica profissional oficial.  
**Contributo:** descreve colocar o pé num apoio e mover o joelho para a frente quando confortável; recomenda não agravar demasiado a dor. Sustenta o sentido do movimento e uma fronteira conservadora de tolerância.  
**Limite:** conteúdo pós-fratura. Não autoriza uso geral, não valida esta posição exata e a dose publicada não foi transferida.

### C2-S21 — Martin et al.

**Referência:** [Ankle Stability and Movement Coordination Impairments: Lateral Ankle Ligament Sprains Revision 2021](https://www.orthopt.org/uploads/content_files/files/jospt.2021.0302.pdf). *J Orthop Sports Phys Ther.* 2021;51(4):CPG1-CPG80.  
**Tipo:** guideline de prática clínica da Academy of Orthopaedic Physical Therapy/APTA.  
**Contributo:** apoia programas estruturados que podem incluir amplitude ativa protegida e alongamento, ajustados à gravidade da lesão, limitações, preferências e necessidades de aprendizagem. Sustenta prudência, adaptação e separação entre conteúdo geral e decisão clínica.  
**Limite:** condição específica e público clínico. Não demonstra que esta identidade isolada seja adequada ou eficaz para todas as pessoas.

### C2-S22 — Alamer et al.

**Referência:** [Effect of Ankle Joint Mobilization with Movement on Range of Motion, Balance and Gait Function: A Systematic Review](https://pubmed.ncbi.nlm.nih.gov/34512072/), 2021.  
**Tipo:** revisão sistemática.  
**Contributo:** esclarece que mobilização com movimento manual ou assistida é uma intervenção técnica própria. Foi usada para não acrescentar banda, força manual ou deslizamento articular à identidade base.  
**Limite:** refere técnicas e populações clínicas específicas. Não valida configurações arbitrárias nem a eficácia do avanço simples para o público geral.

### EX21-R1 — Chisholm et al.

**Referência:** [Reliability and validity of a weight-bearing measure of ankle dorsiflexion range of motion](https://pmc.ncbi.nlm.nih.gov/articles/PMC3484905/). *Physiother Can.* 2012;64(4):347-355.  
**Tipo:** estudo primário de fiabilidade e validade.  
**Contributo:** sustenta a observação de dorsiflexão do tornozelo em carga por uma ação de avanço. É também importante para a fronteira: o estudo avalia uma medida clínica, enquanto o conteúdo EveFit descreve um exercício sem distância ou resultado.  
**Limite:** não é um ensaio de intervenção; não sustenta eficácia, dose ou um valor-alvo para o exercício.

### EX21-R2 — Plisky et al.

**Referência:** [The Dorsiflexion Range of Motion Screen: A Validation Study](https://ijspt.scholasticahq.com/article/21253-the-dorsiflexion-range-of-motion-screen-a-validation-study). *Int J Sports Phys Ther.* 2021;16(2):306-311. DOI: 10.26603/001c.21253.  
**Tipo:** estudo primário de validação.  
**Contributo:** demonstra que a dorsiflexão em cadeia fechada é observada em posições de avanço e distingue explicitamente screen de medida. Refere o meio-ajoelhado como posição usada em medições anteriores. Sustenta a necessidade de não apresentar o exercício como teste.  
**Limite:** amostra jovem, ambulatória e sem lesão atual; o protocolo principal é em pé e mede amplitude. Não demonstra o efeito do exercício.

### EX21-R3 — Massachusetts General Hospital

**Referência:** [Physical Therapy Guidelines for Lateral Ankle Sprain](https://www.massgeneral.org/assets/mgh/pdf/orthopaedics/foot-ankle/pt-guidelines-for-ankle-sprain.pdf).  
**Tipo:** protocolo clínico profissional oficial.  
**Contributo:** recomenda amplitude sem dor e progressão para posições em carga conforme toleradas, com decisões ajustadas ao exame, evolução e complicações. Sustenta os limites de tolerância e a recomendação de revisão em contexto clínico.  
**Limite:** é um protocolo para entorse lateral e contém cronologia e progressões que não foram transferidas.

## Síntese por tópico

### Execução e posicionamento

A mecânica canónica é coerente com a literatura sobre dorsiflexão em cadeia fechada: o pé permanece apoiado enquanto a tíbia e o joelho avançam. Para esta identidade, o joelho de trás e a parte inferior da perna completam a base de apoio. A instrução pública usa três pontos observáveis no pé — calcanhar e bases do primeiro e quinto dedos — já presentes nos cues canónicos, sem criar equipamento ou alvo.

O alinhamento foi descrito de forma funcional: o joelho avança sobre o pé sem colapsar para dentro; o pé e a bacia não rodam para simular mais amplitude. Não foi imposto um dedo específico como alvo, porque as fontes variam nas instruções de testes e a identidade não é uma medição.

### Amplitude

Não foi adotado um valor normativo, distância ou ângulo. O limite operacional é observável:

- antes de o calcanhar levantar;

- antes de o pé colapsar;

- antes de o joelho ou a bacia perderem controlo;

- antes de dor aguda, bloqueio ou outro sinal de interrupção.

Isto preserva a capacidade de ajustar amplitude sem produzir prescrição.

### Respiração

Não foi encontrada evidência que imponha uma fase inspiratória ou expiratória específica para o avanço de dorsiflexão em meio-ajoelhado. Foi aplicada a orientação conservadora do contrato: respiração natural e contínua, sem retenção e sem contagens.

### Segurança

O risco moderado foi preservado. A informação clínica sustenta não agravar a dor e adaptar movimento/carga à tolerância e ao contexto. O conteúdo inclui os sinais canónicos de redução ou interrupção:

- dor aguda;

- bloqueio articular;

- perda súbita de controlo;

- tontura ou mal-estar.

Foram ainda descritas sensações de aviso observáveis, sem diagnosticar a sua causa: compressão anterior forte crescente, formigueiro, dormência e instabilidade.

### Erros

Os erros principais derivam da identidade e dos limites observáveis:

1. levantar o calcanhar;
2. colapsar o pé e deixar o joelho cair para dentro;
3. rodar o pé ou a bacia;
4. forçar amplitude;
5. transformar o movimento numa medição;
6. prender a respiração.

Cada erro inclui reconhecimento e correção, sempre por reorganização ou redução de amplitude, sem dose.

### Supervisão

A supervisão canónica permanece `none` e não há spotter obrigatório. O conteúdo apenas operacionaliza os gatilhos já aprovados:

- incapacidade de manter o suporte;

- medo de queda;

- sintomas durante a amplitude;

- dificuldade em distinguir movimento alvo de compensação.

Retorno à função, cirurgia recente, sintomas persistentes ou instabilidade conhecida continuam a exigir revisão contextual; isto não altera o campo geral `clinical_review_required: false`.

## Decisões de exclusão

- Não foi acrescentada parede, alvo, fita métrica, inclinómetro, banda ou assistência manual.

- Não foram usados valores normativos, distâncias, ângulos ou critérios de aprovação.

- Não foi prescrita frequência, velocidade, duração, séries ou repetições.

- Não foram importadas cronologias de reabilitação das fontes clínicas.

- Não foram feitas promessas de mobilidade, prevenção, desempenho ou recuperação.

- Não foi inferido diagnóstico a partir de dor, rigidez, pinçamento ou limitação.

- Não foram alteradas as relações canónicas aprovadas.

## Confiança

| Domínio | Confiança | Razão |
|---|---|---|
| Identidade | Alta | Definição e distinções são canónicas e foram preservadas. |
| Execução | Moderada | A mecânica em carga é convergente, mas as fontes diretas estudam sobretudo testes ou contextos clínicos. |
| Posicionamento | Moderada | Calcanhar apoiado e avanço em cadeia fechada são sustentados; detalhes finos variam entre protocolos de avaliação. |
| Amplitude e segurança | Moderada | Há suporte profissional para amplitude protegida/tolerada, sem validação universal. |
| Respiração | Baixa a moderada | Não existe padrão específico; foi usada orientação conservadora não faseada. |
| Supervisão | Moderada | Os gatilhos resultam do registo canónico e são coerentes com as limitações clínicas das fontes. |

## Limitações e campos por resolver

- Não foi encontrada investigação primária sobre a identidade pública exata, sem alvo, medição ou assistência.

- A maioria da evidência externa é de avaliação de amplitude ou reabilitação de lesão.

- Não existe padrão respiratório específico validado para esta ação.

- A adequação em cirurgia recente, retorno à função, sintomas persistentes ou instabilidade conhecida depende de avaliação contextual.

- A informação não permite inferir benefício individual, dose, meta de amplitude ou autorização universal.

## Verificação do contrato

- Português europeu e conteúdo claro para principiante: sim.

- UTF-8 e intenção de normalização NFC: sim.

- Passos de execução: 8.

- Indicações principais: 6.

- Erros com reconhecimento e correção: 6.

- Perguntas de compreensão: 12 no ficheiro estruturado.

- Identidade, risco, equipamento, superfície, supervisão e relações preservados: sim.

- Dose, prescrição, promessa, diagnóstico, tratamento, código e publicação: ausentes.

- Implementação realizada: não.
