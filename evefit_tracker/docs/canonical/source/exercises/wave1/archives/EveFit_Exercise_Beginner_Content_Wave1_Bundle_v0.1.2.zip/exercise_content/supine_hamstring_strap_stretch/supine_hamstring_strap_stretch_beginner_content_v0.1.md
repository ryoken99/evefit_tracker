# Alongamento dos isquiotibiais em decúbito dorsal com correia

Conteúdo para principiantes em português europeu.

## Descrição curta

Alongamento unilateral em decúbito dorsal no qual uma correia ou toalha no pé ajuda a elevar a perna e a regular a tensão na parte posterior da coxa.

## O que é

Deitado de costas, colocas uma correia ou toalha aprovada à volta de um pé e usas as mãos para elevar essa perna. O joelho aproxima-se da extensão sem ser bloqueado à força, enquanto a bacia e o tronco permanecem apoiados.

## O que vais fazer

Vais preparar o material, apoiar o corpo numa superfície estável, elevar uma perna com ajuda da correia, encontrar uma tensão suave e controlável atrás da coxa e regressar sem perder o controlo.

## Porque existe este movimento

Esta configuração permite autoassistir a elevação da perna através do pé quando a assistência manual direta na coxa não é a opção escolhida. A correia altera a alavanca, mas não define uma amplitude nem um resultado individual.

## Antes de começares

1. Confirma que consegues deitar-te e levantar-te da superfície com controlo.
2. Escolhe uma correia de alongamento ou toalha aprovada, íntegra, seca e suficientemente comprida para segurares as extremidades sem encolher os ombros.
3. Usa uma superfície horizontal, estável e antiderrapante; um tapete de exercício é opcional.
4. Afasta objetos da zona onde a perna vai subir e descer.
5. Não comeces se já tens dor aguda ou crescente, dormência, formigueiro, sensação elétrica, fraqueza súbita, instabilidade ou mal-estar.
6. Se regressas após lesão ou cirurgia, tens uma condição crónica relevante ou a tua situação altera a forma de te deitares, moveres ou sentires a perna, obtém orientação individual antes de usar esta variante.

## Preparar o equipamento

1. Inspeciona toda a correia ou toalha e não a uses se estiver rasgada, gasta, húmida ou escorregadia.
2. Passa o centro do material por uma zona estável do pé da perna a elevar.
3. Confirma que o material não está sobre os dedos, não corta a pele e não cria pressão dolorosa.
4. Segura uma extremidade em cada mão, com comprimento suficiente para manter mãos, ombros e pescoço confortáveis.
5. Faz uma tração mínima de teste e confirma que o material permanece no lugar antes de a perna sair da superfície.
6. Na primeira utilização, pede demonstração da colocação da correia numa zona do pé compatível contigo; não a coloques sobre os dedos. Testa com tensão mínima.

## Preparar o espaço

1. Deita-te numa superfície horizontal, estável e antiderrapante.
2. Garante espaço livre acima e à volta da perna que vai ser elevada.
3. Não uses uma superfície instável ou escorregadia.
4. Mantém-te afastado de trânsito ativo e de apoios que possam deslocar-se.

## Verificação do corpo

1. Consegues respirar normalmente em decúbito dorsal.
2. Consegues manter o tronco e a bacia apoiados sem desconforto crescente.
3. Consegues iniciar uma pequena elevação da perna e voltar atrás com controlo.
4. O contacto da correia no pé é firme, mas não doloroso.
5. Não existem dormência, formigueiro, sensação elétrica ou fraqueza antes de começares.

## Posição inicial

Deita-te de costas com a cabeça, o tronco e a bacia apoiados. Mantém a perna que não vai ser alongada apoiada numa posição confortável. Passa a correia ou toalha pelo pé da outra perna, segura as extremidades com as mãos e começa com pouca tensão.

## Confirmar a posição inicial

1. Cabeça e pescoço confortáveis.
2. Tronco e bacia em contacto estável com a superfície.
3. Perna contrária apoiada e quieta.
4. Correia ou toalha centrada numa zona estável do pé.
5. Uma extremidade segura em cada mão.
6. Ombros afastados das orelhas e respiração livre.
7. Sem pressão dolorosa, dormência, formigueiro ou sensação elétrica.

## Passos de execução

1. Inicia com a correia quase sem tensão e confirma que o material não desliza no pé.
2. Eleva lentamente a perna, usando as mãos apenas para guiar e assistir o movimento através da correia.
3. À medida que a anca flete, aproxima o joelho da extensão sem o empurrar nem o bloquear com força.
4. Mantém o tronco e a bacia apoiados; reduz a elevação se a bacia começar a levantar ou a rodar.
5. Interrompe o aumento da tração quando surgir uma tensão suave, difusa e controlável na parte posterior da coxa.
6. Mantém a posição organizada com uma tração estável e respiração natural, sem puxões nem balanços.
7. Para sair, alivia primeiro a força das mãos e permite que o joelho amoleça ligeiramente.
8. Baixa a perna devagar até recuperar apoio completo e só depois retira a correia do pé.

## Fases do movimento

### Preparação

Corpo apoiado, material inspecionado e correia colocada numa zona estável do pé com tensão mínima.

### Entrada controlada

A perna sobe por flexão da anca, assistida pelas mãos através da correia, enquanto o joelho se aproxima da extensão.

### Posição assistida

A tensão permanece suave e estável, a bacia não se desloca e a respiração continua livre.

### Libertação

A força das mãos diminui antes de a perna começar a descer.

### Saída controlada

A perna regressa à superfície sem queda e o material só é retirado depois de o apoio estar restabelecido.

## Respiração

Respira de forma natural e contínua durante a subida, a posição assistida e a descida. Não prendas a respiração quando aplicas tensão com as mãos. Se deixas de conseguir respirar confortavelmente, reduz a tração e a elevação da perna. Não são necessárias contagens respiratórias nem uma fase respiratória obrigatória.

## Sensações esperadas

1. Tensão suave e progressiva na parte posterior da coxa da perna elevada.
2. Possível sensação ligeira de alongamento nos gémeos, sem dor nem sensação elétrica.
3. Trabalho leve das mãos e dos braços para manter a correia estável, sem necessidade de esforço máximo.
4. Contacto firme, mas confortável, da correia ou toalha no pé.
5. Sensação de controlo suficiente para reduzir imediatamente a tensão.

## Sensações inesperadas ou de alerta

1. Dor aguda, localizada ou crescente na coxa, atrás do joelho, na anca, nas costas ou no pé.
2. Dormência, formigueiro, ardor ou sensação elétrica ao longo da perna.
3. Fraqueza súbita ou sensação de que a perna deixa de responder.
4. Pressão dolorosa, corte ou deslizamento da correia no pé.
5. Mal-estar, tontura, falta de ar ou perda de controlo.
6. Estalido acompanhado de dor.

## Indicações técnicas principais

1. Material íntegro e bem assente no pé.
2. Eleva devagar; a correia guia, não arranca.
3. Bacia e tronco permanecem apoiados.
4. Joelho próximo da extensão, sem bloqueio forçado.
5. Tensão suave atrás da coxa, nunca dor ou sensação elétrica.
6. Respira sem prender e alivia a tração antes de desceres.

## Erros comuns e correções

### Erro 1: Puxar a correia de forma brusca.

- Como reconhecer: A perna dá um salto, os braços fazem um puxão ou a tensão aparece de repente.
- Como corrigir: Volta a uma tração mínima e eleva a perna de forma gradual e contínua.

### Erro 2: Procurar altura em vez de controlo.

- Como reconhecer: A bacia levanta, roda ou o fundo das costas perde o apoio para a perna subir mais.
- Como corrigir: Baixa ligeiramente a perna até recuperares apoio estável do tronco e da bacia.

### Erro 3: Bloquear o joelho com força.

- Como reconhecer: Sentes pressão localizada atrás do joelho ou empurras a articulação para trás.
- Como corrigir: Amolece ligeiramente o joelho e mantém apenas uma extensão próxima e confortável.

### Erro 4: Colocar mal a correia no pé.

- Como reconhecer: O material desliza para os dedos, corta a pele ou concentra pressão num ponto.
- Como corrigir: Baixa a perna, retira tensão e reposiciona o material numa zona estável do pé.

### Erro 5: Encolher os ombros e prender a respiração.

- Como reconhecer: Os ombros aproximam-se das orelhas, o pescoço fica tenso ou a respiração para.
- Como corrigir: Dá mais comprimento à pega, reduz a força das mãos e retoma uma respiração natural.

### Erro 6: Continuar perante sinais neurais ou dor.

- Como reconhecer: Aparecem dormência, formigueiro, sensação elétrica, fraqueza ou dor crescente.
- Como corrigir: Liberta imediatamente a tração, baixa a perna com controlo e não retomes nessa condição.

## Formas de simplificar ou ensaiar

1. Mantém a perna contrária fletida com o pé apoiado se isso facilitar a estabilidade da bacia.
2. Eleva menos a perna e privilegia uma tensão suave em vez de procurar uma posição mais alta.
3. Permite uma ligeira flexão do joelho da perna elevada, mantendo-o apenas próximo da extensão.
4. Ajusta o comprimento da correia para os cotovelos e ombros ficarem confortáveis.

## Supervisão

Não exige observador nem supervisão por defeito quando a pessoa cumpre os pré-requisitos, compreende os sinais de paragem e controla a entrada e a saída. É indicada orientação qualificada se a posição não é compreendida, se não é possível manter o material e o corpo estáveis, se a primeira exposição parece complexa, ou se existe historial, sintoma, retorno após lesão ou cirurgia, hipermobilidade ou outra condição que altere a elegibilidade.

## Como terminar

Reduz primeiro a tensão exercida pelas mãos. Deixa o joelho amolecer ligeiramente se isso facilitar a saída. Baixa a perna devagar, sem deixar que a correia a puxe nem que a perna caia. Recupera apoio completo da perna na superfície. Retira a correia do pé apenas quando já não existe tensão. Senta-te ou levanta-te apenas quando te sentires estável.

## Nota de segurança

Liberta imediatamente a tensão perante dor aguda ou crescente, dormência, formigueiro, sensação elétrica, fraqueza súbita, pressão dolorosa no pé, deslizamento do material, perda de controlo, instabilidade ou mal-estar. Não uses a correia para forçar amplitude.

## Quando parar ou reduzir

1. Dor aguda ou crescente.
2. Dormência, parestesia ou fraqueza súbita.
3. Formigueiro ou sensação elétrica na perna.
4. Perda de controlo, instabilidade ou mal-estar.
5. Pressão dolorosa da correia no pé.
6. Deslizamento, rutura ou perda de firmeza do material.
7. Levantamento ou rotação da bacia que não desaparece ao reduzir a elevação.
8. Se a correia começar a deslizar, alivia primeiro toda a tração e baixa a perna com controlo antes de a reposicionar.

## Segurança do equipamento

Usa apenas uma correia de alongamento ou toalha aprovada, íntegra, seca e sem zonas gastas. Confirma que o material tem comprimento suficiente para não puxares com os ombros elevados. Evita nós, fivelas ou dobras rígidas em contacto com o pé. Não coloques o material sobre os dedos nem o deixes apertar uma zona sensível. Testa a aderência com pouca tensão antes de elevar a perna. Se o material deslizar, alivia a tração e baixa a perna antes de o reposicionar. Um tapete de exercício é opcional e não substitui uma superfície estável e antiderrapante.

## Segurança do espaço

Usa uma superfície horizontal, estável e antiderrapante. Evita superfícies instáveis ou escorregadias. Mantém livre a zona imediata de elevação e descida da perna. Não executes junto de trânsito ativo ou de apoios que possam mover-se. Confirma que a temperatura e o contacto com a superfície não alteram o conforto nem a perceção da tensão.

## Limitações

1. Não foi encontrada uma norma única que defina uma posição exata e universal da correia no pé; o conteúdo usa a formulação canónica de zona estável e confortável.
2. As fontes não permitem definir uma amplitude universal nem uma sensação idêntica para todas as pessoas.
3. O estudo sobre mecânica neural foi realizado em cadáveres e serve apenas para justificar prudência, não para interpretar individualmente sintomas.
4. O estudo sobre dor usou uma amostra e uma forma de alongamento específicas; não comprova segurança universal nem superioridade desta variante.
5. A orientação de supervisão preserva o requisito canónico de ausência de supervisão por defeito, sem substituir avaliação quando existem fatores que alteram a elegibilidade.
6. Não foram transpostos parâmetros quantitativos ou temporais das fontes.

## Teste de compreensão

### 1. Que material define esta variante?

Resposta esperada: Uma correia de alongamento ou uma toalha aprovada colocada no pé.

### 2. O tapete de exercício é obrigatório?

Resposta esperada: Não. É opcional; a superfície estável e antiderrapante é o requisito essencial.

### 3. O que deve permanecer apoiado enquanto a perna sobe?

Resposta esperada: O tronco e a bacia, com a perna contrária apoiada numa posição confortável.

### 4. Deves bloquear o joelho da perna elevada?

Resposta esperada: Não. O joelho aproxima-se da extensão sem ser empurrado para um bloqueio.

### 5. Qual é a sensação esperada principal?

Resposta esperada: Uma tensão suave, gradual e controlável na parte posterior da coxa.

### 6. A altura da perna é o objetivo principal?

Resposta esperada: Não. O objetivo técnico é manter controlo, apoio da bacia e tensão tolerável.

### 7. O que fazes se surgir formigueiro ou sensação elétrica?

Resposta esperada: Liberto imediatamente a tração, baixo a perna com controlo e não continuo nessa condição.

### 8. Como deve ser a respiração?

Resposta esperada: Natural e contínua, sem a prender quando puxo a correia.

### 9. Quando se retira a correia do pé?

Resposta esperada: Depois de aliviar a tração e de a perna recuperar apoio completo.

### 10. O que indica que a correia está mal colocada?

Resposta esperada: Deslizamento para os dedos, pressão concentrada, corte da pele ou dor no pé.

### 11. O que muda em relação ao exercício-base autoassistido?

Resposta esperada: As mãos aplicam a força através de uma correia ou toalha no pé, em vez de assistirem diretamente a perna.

### 12. É sempre necessária supervisão?

Resposta esperada: Não por defeito. É indicada orientação quando a posição não é controlável ou quando historial, sintomas ou retorno após lesão ou cirurgia alteram a elegibilidade.

## Fontes e limites da evidência

### Fonte 1: Knee Conditioning Program

- Autor ou entidade: D1-EXT-08 — Knee Conditioning Program — American Academy of Orthopaedic Surgeons — guia profissional oficial — https://orthoinfo.aaos.org/en/recovery/knee-conditioning-program/ — entrada gradual num alongamento dos isquiotibiais evitar tração diretamente na articulação do joelho sensação esperada na região posterior da coxa — Fonte profissional já existente no pacote, usada como apoio de família e para erros técnicos. — Não descreve esta configuração exata com a correia aplicada ao pé e não estabelece elegibilidade individual.
- Tipo: guia profissional oficial
- Localizador: https://orthoinfo.aaos.org/en/recovery/knee-conditioning-program/
- Usada para: D1-EXT-08 — Knee Conditioning Program — American Academy of Orthopaedic Surgeons — guia profissional oficial — https://orthoinfo.aaos.org/en/recovery/knee-conditioning-program/ — entrada gradual num alongamento dos isquiotibiais evitar tração diretamente na articulação do joelho sensação esperada na região posterior da coxa — Fonte profissional já existente no pacote, usada como apoio de família e para erros técnicos. — Não descreve esta configuração exata com a correia aplicada ao pé e não estabelece elegibilidade individual.
- Limite: Não descreve esta configuração exata com a correia aplicada ao pé e não estabelece elegibilidade individual.

### Fonte 2: Current concepts in muscle stretching for exercise and rehabilitation

- Autor ou entidade: D2-S05 — Current concepts in muscle stretching for exercise and rehabilitation — Page P. — revisão profissional — https://pmc.ncbi.nlm.nih.gov/articles/PMC3273886/ — distinção entre alongamento estático e outras modalidades princípios gerais de aplicação controlada — Fonte já existente no pacote, usada para enquadrar a modalidade sem transformar a execução numa prescrição. — É uma revisão de modalidade e não valida todos os pormenores desta variante.
- Tipo: revisão profissional
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC3273886/
- Usada para: D2-S05 — Current concepts in muscle stretching for exercise and rehabilitation — Page P. — revisão profissional — https://pmc.ncbi.nlm.nih.gov/articles/PMC3273886/ — distinção entre alongamento estático e outras modalidades princípios gerais de aplicação controlada — Fonte já existente no pacote, usada para enquadrar a modalidade sem transformar a execução numa prescrição. — É uma revisão de modalidade e não valida todos os pormenores desta variante.
- Limite: É uma revisão de modalidade e não valida todos os pormenores desta variante.

### Fonte 3: Lower Body Stretches — Supine Hamstring Stretch with Strap

- Autor ou entidade: EX34-EXT-01 — Lower Body Stretches — Supine Hamstring Stretch with Strap — UCSF Orthopaedic Institute — material técnico institucional — https://sportsrehab.ucsf.edu/sites/g/files/tkssra10961/files/doc/Lower_Body_Stretches_Nov2025.pdf — correia ou toalha colocada no pé elevação lenta assistida aproximação do joelho à extensão regresso lento à posição inicial — Principal apoio direto para a sequência específica da variante com correia no pé. — Material instrucional breve; não detalha respiração, sinais neurais, pressão do material ou supervisão.
- Tipo: material técnico institucional
- Localizador: https://sportsrehab.ucsf.edu/sites/g/files/tkssra10961/files/doc/Lower_Body_Stretches_Nov2025.pdf
- Usada para: EX34-EXT-01 — Lower Body Stretches — Supine Hamstring Stretch with Strap — UCSF Orthopaedic Institute — material técnico institucional — https://sportsrehab.ucsf.edu/sites/g/files/tkssra10961/files/doc/Lower_Body_Stretches_Nov2025.pdf — correia ou toalha colocada no pé elevação lenta assistida aproximação do joelho à extensão regresso lento à posição inicial — Principal apoio direto para a sequência específica da variante com correia no pé. — Material instrucional breve; não detalha respiração, sinais neurais, pressão do material ou supervisão.
- Limite: Material instrucional breve; não detalha respiração, sinais neurais, pressão do material ou supervisão.

### Fonte 4: 10 Stretches to Do Before Bed to Improve Your Sleep — Supine Hamstring Stretch

- Autor ou entidade: EX34-EXT-02 — 10 Stretches to Do Before Bed to Improve Your Sleep — Supine Hamstring Stretch — Hospital for Special Surgery — orientação profissional institucional — https://www.hss.edu/health-library/move-better/stretches-before-bed — correia posicionada no pé tração suave não ultrapassar a dor capacidade de respirar durante o alongamento — Apoio independente para equipamento, sensação tolerável e respiração contínua. — O contexto da página é geral e não substitui avaliação de situações individuais.
- Tipo: orientação profissional institucional
- Localizador: https://www.hss.edu/health-library/move-better/stretches-before-bed
- Usada para: EX34-EXT-02 — 10 Stretches to Do Before Bed to Improve Your Sleep — Supine Hamstring Stretch — Hospital for Special Surgery — orientação profissional institucional — https://www.hss.edu/health-library/move-better/stretches-before-bed — correia posicionada no pé tração suave não ultrapassar a dor capacidade de respirar durante o alongamento — Apoio independente para equipamento, sensação tolerável e respiração contínua. — O contexto da página é geral e não substitui avaliação de situações individuais.
- Limite: O contexto da página é geral e não substitui avaliação de situações individuais.

### Fonte 5: Stretching: Focus on flexibility

- Autor ou entidade: EX34-EXT-03 — Stretching: Focus on flexibility — Mayo Clinic — orientação profissional institucional — https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20047931 — movimento suave sem balanços respiração normal tensão esperada em vez de dor necessidade de adaptação quando existem lesão ou condição relevante — Apoio geral de segurança, respiração e fronteira entre tensão e dor. — Não é uma instrução específica para a variante com correia e não define a posição exata do pé.
- Tipo: orientação profissional institucional
- Localizador: https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20047931
- Usada para: EX34-EXT-03 — Stretching: Focus on flexibility — Mayo Clinic — orientação profissional institucional — https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20047931 — movimento suave sem balanços respiração normal tensão esperada em vez de dor necessidade de adaptação quando existem lesão ou condição relevante — Apoio geral de segurança, respiração e fronteira entre tensão e dor. — Não é uma instrução específica para a variante com correia e não define a posição exata do pé.
- Limite: Não é uma instrução específica para a variante com correia e não define a posição exata do pé.

### Fonte 6: The acute benefits and risks of passive stretching to the point of pain

- Autor ou entidade: EX34-PRI-01 — The acute benefits and risks of passive stretching to the point of pain — Muanjai P. et al. — estudo primário — https://pubmed.ncbi.nlm.nih.gov/28391391/ — 10.1007/s00421-017-3608-y — relação entre intensidade percebida, desconforto e dor limite para não apresentar a dor como necessária — O estudo não encontrou vantagem aguda em levar o alongamento até à dor comparativamente ao ponto de desconforto, sustentando linguagem conservadora centrada em tensão controlável. — A amostra foi específica, o protocolo não corresponde a esta variante e os resultados não demonstram segurança universal.
- Tipo: estudo primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/28391391/
- Usada para: EX34-PRI-01 — The acute benefits and risks of passive stretching to the point of pain — Muanjai P. et al. — estudo primário — https://pubmed.ncbi.nlm.nih.gov/28391391/ — 10.1007/s00421-017-3608-y — relação entre intensidade percebida, desconforto e dor limite para não apresentar a dor como necessária — O estudo não encontrou vantagem aguda em levar o alongamento até à dor comparativamente ao ponto de desconforto, sustentando linguagem conservadora centrada em tensão controlável. — A amostra foi específica, o protocolo não corresponde a esta variante e os resultados não demonstram segurança universal.
- Limite: A amostra foi específica, o protocolo não corresponde a esta variante e os resultados não demonstram segurança universal.

### Fonte 7: Differential movement of the sciatic nerve and hamstrings during the straight leg raise with ankle dorsiflexion

- Autor ou entidade: EX34-PRI-02 — Differential movement of the sciatic nerve and hamstrings during the straight leg raise with ankle dorsiflexion — Bueno-Gracia E. et al. — estudo biomecânico primário em cadáveres — https://pubmed.ncbi.nlm.nih.gov/31374476/ — 10.1016/j.msksp.2019.07.011 — efeito da posição do tornozelo na mecânica neural durante a elevação da perna estendida prudência ao usar a correia para puxar o pé para trás importância de interromper perante sensação elétrica ou formigueiro — Mostrou que a dorsiflexão alterou a tensão e o deslocamento do nervo ciático sem alterar do mesmo modo o bicípite femoral, apoiando uma posição confortável do pé e linguagem prudente sobre sintomas neurais. — Estudo cadavérico e biomecânico; não avalia esta execução em principiantes nem permite inferir causa clínica de uma sensação.
- Tipo: estudo biomecânico primário em cadáveres
- Localizador: https://pubmed.ncbi.nlm.nih.gov/31374476/
- Usada para: EX34-PRI-02 — Differential movement of the sciatic nerve and hamstrings during the straight leg raise with ankle dorsiflexion — Bueno-Gracia E. et al. — estudo biomecânico primário em cadáveres — https://pubmed.ncbi.nlm.nih.gov/31374476/ — 10.1016/j.msksp.2019.07.011 — efeito da posição do tornozelo na mecânica neural durante a elevação da perna estendida prudência ao usar a correia para puxar o pé para trás importância de interromper perante sensação elétrica ou formigueiro — Mostrou que a dorsiflexão alterou a tensão e o deslocamento do nervo ciático sem alterar do mesmo modo o bicípite femoral, apoiando uma posição confortável do pé e linguagem prudente sobre sintomas neurais. — Estudo cadavérico e biomecânico; não avalia esta execução em principiantes nem permite inferir causa clínica de uma sensação.
- Limite: Estudo cadavérico e biomecânico; não avalia esta execução em principiantes nem permite inferir causa clínica de uma sensação.
