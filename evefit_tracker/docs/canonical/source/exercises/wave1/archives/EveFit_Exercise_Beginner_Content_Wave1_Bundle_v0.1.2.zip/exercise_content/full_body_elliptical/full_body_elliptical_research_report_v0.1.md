# Relatório de investigação — `full_body_elliptical`

**Agente:** EX-05  
**Data de fecho:** 2026-07-23  
**Âmbito:** preparação, execução, respiração, segurança, erros e supervisão  
**Resultado:** cobertura defensável; pesquisa encerrada

Implementação realizada: não

## 1. Restrições preservadas

Este trabalho não alterou:

- `exercise_id`: `full_body_elliptical`;

- nome: `Movimento elíptico de corpo inteiro`;

- tipo: `canonical_exercise`;

- família: `elliptical_trainer_family`;

- risco operacional base: `low`;

- equipamento obrigatório: `full_body_elliptical_trainer`;

- supervisão: `recommended`;

- revisão clínica base: não obrigatória;

- relações canónicas aprovadas.

Não foram acrescentadas variantes, relações, equipamento alternativo, aprovação multimédia, dose, prescrição, promessa de resultado, diagnóstico ou tratamento.

## 2. Perguntas de investigação

1. Como deve uma pessoa entrar e sair de uma elíptica com segurança?
2. Que contactos e orientação corporal caracterizam a execução de corpo inteiro?
3. Como se coordenam pedais e alavancas móveis?
4. Que orientação respiratória é defensável sem impor uma técnica artificial?
5. Que sinais exigem paragem?
6. Que verificações de equipamento e espaço são consistentes entre fabricantes?
7. Que erros são reconhecíveis por um principiante e como podem ser corrigidos sem prescrição?
8. Quando é especialmente importante aplicar a supervisão já classificada como recomendada?

## 3. Estratégia e fecho da pesquisa

A pesquisa foi limitada a documentação de fabricantes, orientação profissional e literatura biomecânica primária. Foram comparados manuais de três fabricantes independentes para reduzir dependência de uma única geometria de máquina. A pesquisa terminou quando houve convergência suficiente sobre:

- base firme e máquina funcional;

- entrada e saída lateral com apoio;

- pedal do lado de entrada ou saída baixo;

- imobilização antes de montar ou desmontar;

- contacto contínuo com pedais e pegas;

- corpo voltado para a frente e tronco controlado;

- coordenação recíproca de braços e pernas;

- desaceleração controlada;

- respiração contínua sem retenção;

- sinais pessoais e mecânicos de paragem.

Não foi procurada nem adotada evidência sobre dose, programas, intensidade, resultados, tratamento ou elegibilidade clínica individual.

## 4. Fontes técnicas e profissionais

| Código | Fonte | Tipo e independência | Contributo utilizado | Limite aplicado |
|---|---|---|---|---|
| `EX05-S01` | [Life Fitness — X3 Total-Body Elliptical Cross-Trainer User Manual](https://www.lftechsupport.com/c/document_library/get_file?folderId=1626631&name=DLFE-45559.pdf&p_l_id=1691375) | Documentação oficial do fabricante | Entrada e saída, pés orientados para a frente, joelhos na direção dos pés, tronco direito, dois pés nos pedais, mãos nas alavancas móveis, estabilidade e área livre | Manual de modelo específico; comandos e medidas não foram generalizados |
| `EX05-S02` | [Precor — Precision and Energy Series Elliptical Fitness Crosstrainers Owner's Manual](https://static.precor.com/precor-at-home/legacy/EFX_222_Manuals_103117_ENU.pdf) | Documentação oficial de fabricante independente | Superfície nivelada, zona desimpedida, corpo voltado para a frente, preensão segura, retirada de equipamento danificado e paragem perante sintomas | Funcionalidades e bloqueios próprios da família Precor |
| `EX05-S03` | [Matrix Fitness — Elliptical Frame Owner's Guide](https://www.jhta.com.au/wp-content/uploads/2021/03/Elliptical-Frame-Owners-Guide.pdf) | Documentação de fabricante independente | Pedal baixo, imobilização antes de entrar ou sair, preensão para equilíbrio, superfície do pedal seca e desaceleração controlada em máquina sem roda livre | Modelos comerciais específicos; o valor de cadência indicado no manual não foi importado |
| `EX05-S04` | [American Heart Association — Getting Active to Control High Blood Pressure](https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure) | Orientação profissional independente | Respiração regular durante a atividade e prevenção da retenção do ar | Orientação geral, não específica da elíptica |
| `EX05-S05` | [American Heart Association — Heart Attack, Stroke and Cardiac Arrest Symptoms](https://www.heart.org/en/about-us/heart-attack-and-stroke-symptoms) | Orientação profissional independente | Reconhecimento de desconforto no peito, falta de ar e sensação de cabeça leve como sinais de alarme | Não foi usada para diagnóstico nem para decidir elegibilidade |

## 5. Evidência biomecânica já associada à entidade

| Código | Fonte | Uso restrito |
|---|---|---|
| `A1-S17` | [He et al. — Effects of Stationary Bikes and Elliptical Machines on Knee Joint Kinematics and Kinetics during Exercise](https://pubmed.ncbi.nlm.nih.gov/38541224/) | Distingue a mecânica da elíptica da bicicleta estacionária; não suporta instruções universais |
| `A1-S18` | [Burnfield et al. — Similarity of joint kinematics and muscle demands between elliptical training and walking](https://pubmed.ncbi.nlm.nih.gov/20022994/) | Apoia a natureza cíclica guiada e a comparação com marcha; não suporta prescrição |
| `A2-S19` | [Moreside et al. — How do elliptical machines differ from walking](https://pubmed.ncbi.nlm.nih.gov/22534321/) | Apoia a relevância do controlo do tronco; não valida uma posição única para todas as máquinas |
| `A2-S20` | [Lu et al. — Joint loading in the lower extremities during elliptical exercise](https://pubmed.ncbi.nlm.nih.gov/17805099/) | Apoia a trajetória e carga próprias da elíptica; não sustenta segurança clínica universal |
| `A2-S42` | [Life Fitness — Ellipticals](https://shop.lifefitness.com/collections/ellipticals) | Confirma configurações com alavancas móveis e apoio fixo; uso limitado a equipamento |

## 6. Síntese por tema

### 6.1 Preparação e equipamento

Os fabricantes convergem na necessidade de uma máquina estável, numa superfície firme e nivelada, com componentes seguros, pedais secos e área livre. O conteúdo transforma esta convergência em verificações observáveis, sem importar medidas de espaço específicas de um modelo.

Decisão:

- verificar estabilidade, danos, secura e área livre;

- seguir o manual do modelo para alimentação, consola e bloqueio;

- retirar de utilização uma máquina instável, danificada ou com comportamento anormal;

- não definir um método universal de desbloqueio ou posicionamento manual dos pedais.

### 6.2 Entrada e saída

Life Fitness e Matrix descrevem entrada lateral, apoio nas pegas e pedal próximo numa posição baixa. Matrix explicita imobilização total; Life Fitness descreve estabilização pelo apoio fixo; Precor também recomenda preensão segura ao subir.

Decisão:

- máquina completamente parada;

- entrada e saída lateral;

- apoio fixo para transferência;

- pedal do lado de entrada ou saída baixo pelo método do fabricante;

- um pé de cada vez;

- saída apenas após imobilização completa.

### 6.3 Identidade de corpo inteiro

O manual Life Fitness identifica a variação de corpo inteiro como pedalar para a frente com as mãos nas alavancas móveis. A própria descrição do fabricante combina pedalar elíptico com empurrar e puxar dos braços. Isto coincide com a identidade canónica fornecida.

Decisão:

- os dois pés permanecem nos pedais;

- as duas mãos permanecem nas alavancas móveis durante a parte ativa;

- os braços alternam empurrar e puxar em coordenação recíproca com as pernas;

- o apoio fixo é reservado à estabilização da entrada e da saída, não à execução ativa desta identidade.

### 6.4 Postura e alinhamento

Life Fitness recomenda pés voltados para a frente, joelhos a acompanharem esse plano, costas direitas e joelhos sem bloqueio. Precor recomenda corpo e cabeça voltados para a frente. A literatura de Moreside et al. demonstra que a mecânica do tronco na elíptica difere da marcha, o que reforça a prudência em evitar alegações de equivalência.

Decisão:

- tronco direito e estável, sem se pendurar na consola;

- cabeça e corpo voltados para a frente;

- ombros descontraídos;

- pés orientados para a frente;

- joelhos desbloqueados e na direção dos pés.

O conteúdo não impõe ângulos articulares, amplitude ou posição milimétrica.

### 6.5 Respiração

Não foi encontrada uma técnica respiratória específica da elíptica suficientemente forte para justificar contagens ou sincronização com o ciclo. A orientação profissional disponível sustenta respiração regular e prevenção da retenção.

Decisão:

- respiração natural, regular e contínua;

- sem contagens;

- sem retenções;

- sem sincronização obrigatória com braços ou pernas;

- falta de ar atípica tratada como sinal de paragem já previsto no registo canónico.

### 6.6 Paragem e falha

Os guias de fabricante convergem na desaceleração controlada e em não sair enquanto os pedais se movem. A Matrix salienta que a unidade não tem roda livre; por isso, a pessoa não deve presumir paragem imediata. Life Fitness e Precor indicam a não utilização de equipamento danificado.

Decisão:

- manter os quatro contactos enquanto se reduz o movimento;

- esperar pela imobilização completa;

- usar apoio fixo antes de sair;

- perante falha mecânica, parar, sair em segurança e retirar a máquina de utilização.

### 6.7 Sinais pessoais de paragem

O registo canónico já define:

- desconforto no peito ou falta de ar atípica;

- tonturas ou confusão;

- perda de controlo ou dor nova.

Os manuais de fabricante e a American Heart Association são consistentes com estes sinais. O conteúdo preserva-os sem criar diagnóstico, prognóstico ou autorização para retomar.

### 6.8 Supervisão

A classificação canónica é `recommended`, com gatilhos de instabilidade marcada e equipamento ou ambiente desconhecido.

Decisão:

- recomendar demonstração da entrada, paragem e saída;

- confirmar estabilidade da máquina;

- permanecer próximo sem tocar nas partes móveis;

- reforçar supervisão perante desconhecimento do modelo, instabilidade ou dificuldade de coordenação.

## 7. Erros documentados

Foram incluídos seis erros completos, cada um com reconhecimento e correção:

1. usar apoios fixos e deixar os braços passivos;
2. subir ou sair com pedais em movimento;
3. perder contacto de uma mão ou de um pé;
4. inclinar o tronco sobre a consola;
5. deixar os joelhos desviarem-se da direção dos pés;
6. parar de forma brusca ou tentar sair antes da imobilização.

As correções mantêm a identidade e não atribuem dose.

## 8. Decisões de exclusão

Não foram importados:

- valores numéricos de espaço livre, por variarem entre fabricantes e modelos;

- limites de cadência ou ritmo de um manual específico;

- resistência, inclinação, programa, amplitude, duração ou distância;

- indicações de frequência, progressão ou recuperação;

- afirmações comerciais sobre calorias, eficácia, condicionamento ou proteção articular;

- recomendações clínicas por diagnóstico;

- valores ou interpretações dos sensores de frequência cardíaca;

- instruções de manutenção ou reparação além de retirar equipamento defeituoso de utilização.

## 9. Integridade do resultado

- Idioma: português europeu.
- Codificação: UTF-8.
- Normalização pretendida: Unicode NFC.
- Passos de execução: 8.
- Indicações principais: 6.
- Erros completos: 6.
- Perguntas de compreensão: 12.
- Dose: ausente.
- Prescrição: ausente.
- Promessas de resultado: ausentes.
- Diagnóstico e tratamento: ausentes.
- Identidade, risco, equipamento e relações: preservados.
- Campos por resolver: nenhum.

## 10. Confiança e limitações

**Confiança global:** alta, com limites.

A confiança é alta para entrada, saída, contactos, postura geral, paragem e segurança do equipamento porque há convergência entre manuais independentes. É moderada para respiração porque a orientação é profissional e geral, não específica da elíptica.

Limitações residuais:

- as máquinas diferem em geometria, comandos, bloqueios e comportamento de paragem;

- o manual do modelo concreto prevalece;

- a indicação de postura é geral e pode exigir adaptação individual;

- a literatura biomecânica não sustenta elegibilidade universal nem promessas clínicas;

- este conteúdo não substitui supervisão ou revisão quando os gatilhos canónicos estão presentes.
