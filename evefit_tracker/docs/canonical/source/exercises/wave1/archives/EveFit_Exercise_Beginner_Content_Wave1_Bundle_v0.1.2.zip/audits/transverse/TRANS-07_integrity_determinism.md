# TRANS-07 — Auditoria transversal independente de integridade e determinismo

**Data da verificação:** 2026-07-24  
**Papel:** especialista transversal TRANS-07; auditor independente; não autor  
**Resultado global:** **não conforme / bloqueado para empacotamento final**  
**Implementação realizada:** **não**

## 1. Âmbito e independência

Foram revistos, em modo exclusivamente de leitura:

- os 49 pacotes individuais `EX-01` a `EX-49`;
- os 147 ficheiros finais individuais sob
  `EveFit_Exercise_Beginner_Content_Wave1_v0.1/exercise_content`;
- o manifest de distribuição dos pacotes e o resultado agregado do validador de autor;
- o validador `validate_beginner_agent_outputs.py`;
- as sete auditorias de capacidade AUD-A a AUD-G;
- a ordem de trabalho aplicável, apenas para obter contrato, gates e entregáveis.

Não foram consultados outputs de outros especialistas transversais. TRANS-07 não foi
autor de qualquer exercício nem de qualquer auditoria de capacidade. Não houve
coordenação de conclusões com autores. A análise não alterou JSON, Markdown,
relatórios de investigação, pacotes, fontes, código, estados, relações, ZIP ou hashes.
O único artefacto escrito por TRANS-07 é este relatório.

## 2. Método

As verificações foram executadas diretamente sobre os bytes e estruturas finais:

1. enumeração fechada de pastas, ficheiros, nomes, IDs, agentes e caminhos esperados;
2. descodificação UTF-8 estrita, normalização Unicode NFC, BOM, finais de linha,
   carácter de substituição, NUL e newline terminal;
3. parse de todos os JSON, incluindo deteção de chaves duplicadas com preservação dos
   pares, presença e ordem das chaves obrigatórias, chaves adicionais e tipos;
4. comparação dos oito invariantes de identidade com cada pacote canónico;
5. validação de estados, risco elevado, variantes e campos não resolvidos;
6. comparação mecânica Markdown–JSON e das fontes/URLs entre JSON, Markdown e
   relatório;
7. pesquisa de `omitted_by_scope`, dose fixa, prescrição, promessa, diagnóstico,
   tratamento e autorização universal no conteúdo público;
8. inspeção das sete auditorias de capacidade e reconciliação dos blockers com os
   estados JSON;
9. inspeção dos requisitos de geração, manifest, SHA256SUMS, segunda geração e ZIP
   reproduzível;
10. nova execução do validador existente, sem gravar resultados no pacote.

Não foi feita verificação HTTP ao vivo. A validação de URLs deste relatório é
sintática e de rastreabilidade interna; disponibilidade remota não foi inferida.

## 3. Verificações conformes

| Verificação | Resultado |
|---|---:|
| Agentes `EX-01` a `EX-49` | 49/49, únicos e sequenciais |
| IDs canónicos finais | 49/49, únicos |
| Pastas individuais | 49/49 |
| Ficheiros individuais | 147/147 |
| Markdown de conteúdo | 49/49 |
| JSON de conteúdo | 49/49 |
| Relatórios de investigação | 49/49 |
| Ficheiros em falta face aos `output_paths` | 0 |
| Ficheiros extra dentro de `exercise_content` | 0 |
| Nomes/pastas fora da convenção | 0 |
| Symlinks | 0 |
| JSON com parse inválido | 0/49 |
| Chaves JSON duplicadas | 0 |
| Chaves obrigatórias ausentes | 0 |
| Ordem relativa das 39 chaves obrigatórias | 49/49 |
| Invariantes canónicos divergentes | 0/392 comparações |
| UTF-8 inválido | 0/147 |
| Unicode não NFC | 0/147 |
| BOM UTF-8 | 0/147 |
| CR/CRLF | 0/147 |
| NUL ou U+FFFD | 0/147 |
| Ficheiros sem newline terminal | 0/147 |
| Permissões dos artefactos individuais | 147/147 em `0644` |
| Variantes formais | 3/3 |
| Campos formais de variante | 3/3 presentes |
| Exercícios de risco elevado | 9 |
| Campos adicionais de risco elevado | 45/45 presentes e não vazios |
| Perguntas de compreensão | 588/588, 12 por exercício |
| Sete auditorias de capacidade | 7/7, UTF-8 e NFC |

As três variantes confirmadas são:

- `treadmill_walking` → `overground_walking`;
- `sled_resisted_sprint` → `linear_sprint`;
- `supine_hamstring_strap_stretch` →
  `supine_self_assisted_hamstring_stretch`.

Os 49 valores `record_status` continuam `approved`. Os 49 valores
`content_status` são `beginner_content_approved_with_limits`. Não existem
`beginner_content_specialist_review`, `beginner_content_rejected` nem `failed` nos
JSON finais, situação que não é reconciliável com os blockers das auditorias de
capacidade; ver TRANS-07-002.

## 4. Contagens verificadas

| Métrica | Resultado |
|---|---:|
| Cardio e condicionamento | 11 |
| Velocidade e potência | 9 |
| Mobilidade | 5 |
| Flexibilidade | 9 |
| Controlo motor e coordenação | 6 |
| Técnica e habilidade | 5 |
| Respiração e regulação | 4 |
| Risco baixo / moderado / alto | 22 / 18 / 9 |
| Passos de execução | 380 |
| Cues principais | 303 |
| Erros comuns completos | 297 |
| Entradas em `sources_consulted` | 337 |
| URLs JSON, soma por exercício | 329 |
| URLs distintas no conjunto | 292 |
| URLs JSON ausentes do respetivo relatório | 0 |
| URLs sintaticamente malformadas | 0 |
| JSON com `unresolved_fields` não vazio | 8 |
| Findings nas sete auditorias de capacidade | 27 |
| Blockers nas sete auditorias de capacidade | 3 |
| Exercícios abrangidos por blocker de capacidade | 2 |

O validador existente devolveu `checked: 49`, `passed: 49`, `failed: 0`, mas também
304 warnings em 48 exercícios. Esta aparente aprovação não constitui um gate
fail-closed; ver TRANS-07-003 e TRANS-07-007.

## 5. Conteúdo proibido

A pesquisa mecânica no conteúdo público não encontrou:

- `omitted_by_scope` ou `not_applicable`;
- números fixos associados a repetições, séries, segundos, minutos, horas, metros,
  quilómetros ou carga;
- frequência semanal fixa;
- uma instrução positiva inequívoca de diagnóstico, tratamento ou promessa clínica.

O validador existente também não reportou dose escondida. Esta confirmação é limitada
a padrões mecânicos e não elimina o finding de intensidade relativa já identificado
pela AUD-B em `countermovement_jump.beginner_simplifications_pt_pt[2]`.

## 6. Findings

### TRANS-07-001 — Entrega global, SHA256SUMS e Bundle ZIP inexistentes

- **Severidade:** crítica
- **Blocker:** sim
- **Exercício:** global, 49 exercícios
- **Campo:** entregáveis globais 1–14; manifest final; SHA256SUMS; Bundle ZIP
- **Evidência:** a raiz `EveFit_Exercise_Beginner_Content_Wave1_v0.1` contém apenas
  a pasta `exercise_content`. Estão ausentes os dois Masters, Manifest, Validation
  Report, Source Ledger, Audit Findings, quatro relatórios temáticos, Unresolved
  Items, Worker Report, `SHA256SUMS_EveFit_Exercise_Beginner_Content_Wave1.txt` e
  `EveFit_Exercise_Beginner_Content_Wave1_Bundle.zip`. Assim, não existe hash final,
  lista fechada das entradas, contagem de hashes internos nem artefacto ZIP a testar.
- **Revisão exigida:** após resolver todos os blockers de conteúdo, gerar os 14
  entregáveis globais a partir de uma fonte fechada; incluir no SHA256SUMS todos os
  ficheiros internos exceto o próprio ficheiro de somas e o ZIP exterior; validar
  todas as entradas e produzir o ZIP apenas a partir desse conjunto fechado.

### TRANS-07-002 — Três blockers de capacidade não refletidos nos estados finais

- **Severidade:** crítica
- **Blocker:** sim
- **Exercícios:** `standing_multidirectional_weight_shift`; `paced_breathing`
- **Campo:** `content_status`; `before_you_start_pt_pt`; `safety_note_pt_pt`;
  `short_description_pt_pt`; `beginner_definition_pt_pt`;
  `what_you_will_do_pt_pt`; `execution_steps_pt_pt`
- **Evidência:** AUD-E contém dois blockers de severidade alta em
  `standing_multidirectional_weight_shift`: introdução de vestuário/calçado não
  canónico e transformação de apoio opcional em imperativo. AUD-G contém um blocker
  em `paced_breathing`: a via canónica de ritmo autoescolhido desaparece e o conteúdo
  fica restrito a sinal externo. Apesar disso, ambos os JSON, tal como os restantes
  47, declaram `beginner_content_approved_with_limits`. As sete auditorias somam 27
  findings e três blockers.
- **Revisão exigida:** não integrar nem empacotar estes dois exercícios como aprovados.
  Submeter os campos indicados às revisões das auditorias respetivas, repetir a
  auditoria da capacidade e só depois fixar o estado final. O manifest e o Master
  devem derivar o estado auditado, não copiar cegamente o valor pré-auditoria.

### TRANS-07-003 — Paridade Markdown–JSON não demonstrada

- **Severidade:** alta
- **Blocker:** sim
- **Exercício:** global; 48 de 49 exercícios têm pelo menos um warning do validador
- **Campo:** conteúdo público Markdown versus os campos JSON obrigatórios
- **Evidência:** a execução atual do validador produziu 304 avisos de reescrita:
  `short_description` 31, `beginner_definition` 29, `what_you_will_do` 42,
  `why_this_movement_exists` 40, `starting_position` 30,
  `breathing_guidance` 26, `ending_the_exercise` 27, `safety_note` 38 e
  `execution_step` 33. Só `stationary_arm_crank_ergometry` não recebeu warning.
  As auditorias de capacidade confirmam divergências concretas adicionais, incluindo
  a prontidão de `tandem_stance`, a finalização de `lateral_costal_breathing`, a
  orientação das manoplas no boxe e omissões seletivas das respostas do teste.
  O contrato exige coerência e determina paragem quando Markdown e JSON não
  coincidirem.
- **Revisão exigida:** definir o JSON como fonte canónica e gerar as secções Markdown
  de forma determinística, ou declarar formalmente uma transformação única e
  testável. O gate deve comparar todos os campos públicos, incluindo listas, objetos,
  erros, teste e ordem, e falhar perante qualquer divergência não autorizada.

### TRANS-07-004 — Seis JSON contêm campos inventados fora do contrato

- **Severidade:** alta
- **Blocker:** sim
- **Exercícios:** `archery_shot_cycle_to_target`, `plyometric_push_up`,
  `sprint_to_controlled_stop`, `supine_hamstring_strap_stretch`,
  `bilateral_pogo_jump`, `march_in_place_to_external_beat`
- **Campo:** chaves de topo `implementation_status_pt_pt`,
  `Implementação realizada`, `implementacao_realizada_pt_pt`
- **Evidência:** quatro JSON acrescentam `implementation_status_pt_pt`; um acrescenta
  a chave com espaço e acento `Implementação realizada`; um acrescenta
  `implementacao_realizada_pt_pt`. Nenhuma destas chaves pertence às 39 chaves
  obrigatórias, aos cinco campos condicionais de risco elevado ou ao campo formal de
  variante. A ordem de trabalho exige JSON “sem campos inventados”. Existem oito
  sequências distintas de chaves de topo, explicadas em parte por estes campos e em
  parte pelos extras condicionais.
- **Revisão exigida:** remover dos JSON as seis chaves não contratuais. Manter a
  declaração de zero implementação no relatório de investigação, onde é obrigatória.
  Validar `additionalProperties` por classe de registo: base, risco elevado, variante
  e risco elevado + variante.

### TRANS-07-005 — Tipos dos mesmos campos variam sem schema discriminado

- **Severidade:** média
- **Blocker:** não, desde que seja fechado antes da geração dos Masters
- **Exercício:** global
- **Campo:** `what_you_will_do_pt_pt`, `before_you_start_pt_pt`,
  `equipment_setup_pt_pt`, `environment_setup_pt_pt`,
  `body_readiness_check_pt_pt`, `breathing_guidance_pt_pt`,
  `supervision_guidance_pt_pt`, `ending_the_exercise_pt_pt`,
  `stop_or_reduce_signs_pt_pt`, `equipment_safety_pt_pt`,
  `environment_safety_pt_pt`, `exercise_detail_sections`, `limitations_pt_pt`
- **Evidência:** 13 campos obrigatórios apresentam mais de um tipo JSON. Exemplos:
  `equipment_setup_pt_pt` usa string/lista/objeto em 23/15/11 exercícios;
  `environment_setup_pt_pt` usa lista/string/objeto em 25/19/5;
  `exercise_detail_sections` usa lista/objeto em 43/6;
  `breathing_guidance_pt_pt` usa string/lista/objeto em 45/3/1. O contrato nomeia os
  campos, mas não fornece uma união discriminada nem uma transformação canónica.
- **Revisão exigida:** escolher um tipo canónico por campo, ou publicar um schema com
  uniões explicitamente discriminadas e serialização definida. Normalizar sem alterar
  texto, ordem ou sentido. O Master JSON não deve depender de heurísticas por
  exercício.

### TRANS-07-006 — Rastreabilidade de fontes é completa nos relatórios, mas não no Markdown

- **Severidade:** média
- **Blocker:** não para a estrutura individual; bloqueia a alegação de equivalência
  integral entre formatos
- **Exercícios:** 17 exercícios com pelo menos um URL JSON ausente no Markdown
- **Campo:** `sources_consulted`; secções públicas de fontes
- **Evidência:** foram contabilizadas 337 entradas de fontes e 329 URLs por exercício.
  Todos os URLs JSON aparecem no respetivo relatório de investigação e nenhum dos
  URLs extraídos é sintaticamente malformado. Porém, 71 URLs JSON não aparecem no
  respetivo Markdown, distribuídos por 17 exercícios; `linear_sprint` omite os nove.
  O validador também assinala oito relatórios que não nomeiam o agente:
  EX-11, EX-15, EX-17, EX-21, EX-30, EX-34, EX-47 e EX-49. AUD-B identifica ainda
  metadados bibliográficos incompletos em três exercícios.
- **Revisão exigida:** definir se o Markdown público deve conter a lista integral ou
  uma projeção documentada. Em qualquer caso, manter no Source Ledger e relatórios
  agente, URL, título, entidade/autoria, ano, uso e limites; adicionar um gate de
  cobertura e eliminar metadados vazios. Validar disponibilidade HTTP numa fase
  separada e registada, sem confundir indisponibilidade temporária com erro sintático.

### TRANS-07-007 — O validador atual não é fail-closed

- **Severidade:** crítica
- **Blocker:** sim
- **Exercício:** global
- **Campo:** `validate_beginner_agent_outputs.py`;
  `_beginner_content_workspace/all_author_validation.json`
- **Evidência:** o validador declara 49/49 `passed` apesar de 304 warnings e dos três
  blockers das auditorias. Verifica presença, mas não a ordem real das chaves; não
  rejeita chaves adicionais; o parser normal não deteta duplicados; não fecha a
  contagem/ausência de ficheiros extra; a comparação Markdown–JSON cobre apenas oito
  escalares e um passo, convertendo divergências em warnings; não valida todas as
  formas/tipos; não reconcilia estados auditados; não gera nem verifica SHA256SUMS;
  não executa duas gerações; não compara ZIPs.
- **Revisão exigida:** substituir o “passed com warnings” por gates explícitos e
  bloqueantes para estrutura, schema, paridade, conteúdo proibido, estado auditado,
  fontes, manifest, hashes e ZIP. O relatório agregado só pode declarar `passed`
  quando todos os gates obrigatórios forem zero.

### TRANS-07-008 — Não existe prova de geração determinística ou ZIP reproduzível

- **Severidade:** crítica
- **Blocker:** sim
- **Exercício:** global
- **Campo:** pipeline de geração; serialização JSON; ordem de entradas; metadados ZIP;
  hash final
- **Evidência:** os 147 ficheiros atuais são bytes estáveis, LF/NFC, sem timestamps no
  conteúdo, com nomes determináveis e permissões uniformes. Isto permite construir um
  processo determinístico, mas não o prova. Não existe gerador dos Masters/Manifest,
  recipe de ZIP, época fixa, política de owner/group, ordem `LC_ALL=C`, versão e nível
  de compressão fixos, nem comparação entre duas gerações limpas. Os mtimes dos
  ficheiros não são normalizados. O `agent_packet_manifest.json` usa caminhos
  absolutos dependentes de `/workspace/scratch/...`, inadequados como input portátil
  de uma geração reproduzível.
- **Revisão exigida:** criar uma geração puramente derivada e documentada com inputs
  por hash, caminhos relativos, locale e timezone fixos, serialização JSON canónica,
  newline final, ordem lexicográfica de entradas, permissões fixas, mtime/epoch fixo,
  owner/group neutros e ferramenta/versão/nível de compressão fixos. Executar duas
  gerações em diretórios limpos e comparar todos os ficheiros, o SHA256SUMS e o ZIP
  byte a byte. Qualquer diferença deve falhar o gate.

## 7. Condições mínimas para reauditoria

1. Resolver e voltar a auditar os três blockers de capacidade.
2. Tornar Markdown uma projeção determinística do JSON ou reconciliar integralmente
   os 304 warnings.
3. Remover as seis chaves inventadas e fechar tipos/schema.
4. Produzir os 14 entregáveis globais a partir de inputs fechados.
5. Substituir o validador permissivo por gates fail-closed.
6. Executar duas gerações limpas e obter igualdade byte a byte.
7. Validar todas as entradas do SHA256SUMS.
8. Recriar duas vezes o Bundle ZIP com metadados normalizados e obter o mesmo SHA-256.

## 8. Conclusão

Os 49 IDs, 49 pastas e 147 ficheiros individuais existem, têm nomes corretos,
JSON válido, UTF-8/NFC e não contêm ficheiros extra. Esta integridade estática é
necessária, mas insuficiente. A entrega permanece bloqueada porque há blockers de
capacidade não refletidos nos estados, divergência Markdown–JSON, campos fora do
contrato, um validador que aprova apesar desses desvios e ausência completa da prova
de segunda geração, SHA256SUMS e ZIP reproduzível.

**Decisão TRANS-07:** não gerar nem aceitar hash final, não aceitar Bundle ZIP e não
declarar a Wave1 pronta enquanto TRANS-07-001, 002, 003, 004, 007 e 008 não forem
fechados e revalidados.

## 9. Declaração de zero implementação

**Implementação realizada: não.** TRANS-07 não corrigiu conteúdos, não alterou
estados, não criou Masters, Manifest, SHA256SUMS ou ZIP, não publicou nada e não
modificou código. Este relatório contém apenas verificação, findings, evidência e
revisões requeridas.
