# TRANS-06 — Auditoria transversal de consistência de dados

**Estado global:** `failed_consistency_gate`  
**Blockers:** 2 exercícios (`EX-40`, `EX-49`)  
**Implementação:** zero

## Âmbito e método

Foram revistos, sem editar:

- 49 pacotes em `_beginner_content_workspace/agent_inputs`;
- 49 JSON e 49 Markdown de conteúdo;
- o manifesto dos 49 pacotes e `all_author_validation.json`;
- as sete auditorias de capacidade AUD-A a AUD-G.

Não foram consultados outros outputs transversais. A verificação foi mecânica e comparativa: validade JSON; IDs e caminhos; capacidade, família, variante/base, risco, equipamento, ambiente e relações; chaves, ordem e tipos; estados; fontes; testes; paridade Markdown–JSON; e referências internas.

## Resultado executivo

- Os 49 JSON são sintaticamente válidos e existem em par 1:1 com 49 Markdown e 49 pacotes.
- Os 49 IDs canónicos, nomes, tipos de entidade, estados canónicos, capacidades, famílias, `variant_of` e `base_exercise_id` coincidem exatamente entre JSON e pacote.
- Os 21 mapeamentos de ID ordenado para ID canónico estão corretamente assinalados.
- As sete capacidades cobrem os 49 exercícios uma vez cada: 11/9/5/9/6/5/4.
- Os riscos estruturados preservam 22 `low`, 18 `moderate` e 9 `high`.
- As três variantes formais são coerentes: EX-11 → `overground_walking`, EX-20 → `linear_sprint`, EX-34 → `supine_self_assisted_hamstring_stretch`.
- Os 154 registos em `approved_relations` referenciam IDs presentes nesta wave; não há IDs nem caminhos duplicados ou em falta.
- Os 49 JSON contêm as 39 chaves contratuais na ordem requerida; os nove exercícios de risco alto contêm os cinco campos adicionais e as três variantes contêm `formal_variant_explanation`.
- Contudo, o estado público não incorpora dois blockers de capacidade, 13 campos partilhados divergem no tipo de topo, existem seis chaves não contratuais, o teste perde conteúdo em 13 Markdown e fontes/testes não têm uma forma estável.

## Findings

### TRANS-06-001 — Estado público incompatível com blockers de capacidade

- **Severidade:** crítica
- **Blocker:** sim
- **Exercícios:** EX-40 `standing_multidirectional_weight_shift`; EX-49 `paced_breathing`
- **Campo:** `content_status`; `all_author_validation.results[].status`; estados AUD-E/AUD-G
- **Evidência:** os 49 JSON declaram `beginner_content_approved_with_limits` e `all_author_validation.json` declara 49/49 `passed`. AUD-E bloqueia EX-40 por dois desvios de equipamento/apoio; AUD-G bloqueia EX-49 por reduzir a identidade canónica, eliminando da execução pública a modalidade de ritmo autoescolhido e tornando opaca a execução sem equipamento.
- **Impacto:** um consumidor do JSON ou do validador autoral aprovaria conteúdo que a revisão independente bloqueou.
- **Revisão exigida:** sincronizar o estado de EX-40 e EX-49 com uma enumeração canónica de gate — pelo menos `beginner_content_specialist_review` até resolução — e fazer o roll-up falhar quando uma auditoria de capacidade contém `Blocker: sim`. Não alterar identidade, risco ou ontologia.

### TRANS-06-002 — Invariantes de identidade/equipamento não estão integralmente preservados na redação pública

- **Severidade:** alta
- **Blocker:** sim para EX-40 e EX-49; não para os restantes
- **Exercícios:** EX-03, EX-04, EX-24, EX-40, EX-49
- **Campo:** identidade; `before_you_start_pt_pt`; `equipment_setup_pt_pt`; `safety_note_pt_pt`; execução; Markdown correspondente
- **Evidência:**
  - EX-03 autoriza cadeira de rodas sem a reconciliar com o inventário canónico nem operacionalizar a estabilização;
  - EX-04 transforma calçado estável em ordem, embora `personal_gear_requirements` esteja vazio;
  - EX-24 exige encosto capaz de reter o fulcro, requisito não fechado no inventário canónico;
  - EX-40 introduz roupa/calçado e converte apoio opcional em imperativo;
  - EX-49 reduz “ritmo autoescolhido ou sinal externo” à via com sinal externo.
- **Revisão exigida:** alinhar a redação com os invariantes já existentes nos pacotes. Condicionar equipamento pessoal opcional, não criar requisitos implícitos e repor as duas vias canónicas de EX-49. Não editar os pacotes para legitimar retroativamente a redação.

### TRANS-06-003 — Deriva de tipos nos campos partilhados

- **Severidade:** alta
- **Blocker:** não
- **Exercícios:** conjunto dos 49; outliers identificados abaixo
- **Campo:** esquema dos JSON
- **Evidência:** 13 das 39 chaves contratuais variam no tipo de topo:

| Campo | Tipos e contagens |
|---|---|
| `what_you_will_do_pt_pt` | 48 string; 1 array (EX-08) |
| `before_you_start_pt_pt` | 43 array; 6 string |
| `equipment_setup_pt_pt` | 23 string; 15 array; 11 object |
| `environment_setup_pt_pt` | 25 array; 19 string; 5 object |
| `body_readiness_check_pt_pt` | 44 array; 5 string |
| `breathing_guidance_pt_pt` | 45 string; 3 array; 1 object (EX-32) |
| `supervision_guidance_pt_pt` | 44 string; 2 array; 3 object |
| `ending_the_exercise_pt_pt` | 35 string; 14 array |
| `stop_or_reduce_signs_pt_pt` | 48 array; 1 object (EX-22) |
| `equipment_safety_pt_pt` | 28 string; 20 array; 1 object (EX-32) |
| `environment_safety_pt_pt` | 28 string; 20 array; 1 object (EX-32) |
| `exercise_detail_sections` | 43 array; 6 object |
| `limitations_pt_pt` | 32 array; 17 string |

Há ainda 10 formas internas de `execution_steps_pt_pt`, 17 de `exercise_detail_sections`, 45 de `confidence`, 48 de `sources_consulted`, sete de `beginner_comprehension_test` e três de `unresolved_fields`. EX-15 é o único cujo `beginner_simplifications_pt_pt` contém objetos em vez de strings. O único shape integralmente uniforme entre os campos compostos auditados é `common_errors_pt_pt`.
- **Revisão exigida:** versionar um esquema que defina um tipo e shape por campo e normalizar valores sem mudar o conteúdo semântico. Se uniões forem indispensáveis, documentá-las explicitamente; não inferir um novo tipo por exercício.

### TRANS-06-004 — Seis chaves de topo não pertencem ao contrato

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** EX-13, EX-17, EX-18, EX-34, EX-35, EX-41
- **Campo:** chaves de topo do JSON
- **Evidência:** EX-13/18/34/41 acrescentam `implementation_status_pt_pt`; EX-17 acrescenta `Implementação realizada`; EX-35 acrescenta `implementacao_realizada_pt_pt`. Nenhuma chave consta das 39 obrigatórias, dos cinco extras de risco alto ou de `formal_variant_explanation`.
- **Revisão exigida:** remover estas seis chaves dos dados de conteúdo e manter a declaração processual de zero implementação apenas nos relatórios. Se metadados de workflow forem necessários, defini-los numa camada e versão próprias.

### TRANS-06-005 — Teste de compreensão perde paridade no Markdown

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** EX-05, EX-06, EX-09, EX-11, EX-12, EX-16, EX-21, EX-27, EX-28, EX-42, EX-43, EX-45, EX-48
- **Campo:** `beginner_comprehension_test`; secção pública de compreensão
- **Evidência:** todos os JSON têm 12 itens. Em EX-21 o Markdown não contém qualquer secção de teste; nos outros 12 afetados o Markdown publica as 12 perguntas sem as respostas presentes no JSON. AUD-A, AUD-F e AUD-G detetaram oito destes casos; ficaram por detetar EX-12, EX-16, EX-21, EX-27 e EX-28. O shape JSON do teste também varia entre sete formas (`question_number`, `question_id` string/number, ausência de ID, `answer_pt_pt`, `correct_answer_pt_pt`, `id`, e campos extra).
- **Revisão exigida:** publicar no Markdown os 12 pares pergunta/resposta já existentes e escolher um único shape JSON, preservando perguntas e respostas. Acrescentar ao validador uma comparação explícita do teste.

### TRANS-06-006 — Proveniência sem interface estável e com lacunas de rastreabilidade

- **Severidade:** alta
- **Blocker:** não
- **Exercícios:** todos por deriva de shape; lacunas locais em EX-13, EX-18, EX-19, EX-31, EX-46 e EX-49
- **Campo:** `sources_consulted`; fontes Markdown; relatório de investigação
- **Evidência:** existem 48 shapes de itens de fonte nos 49 JSON. O identificador alterna entre `source_code`, `source_id` e ausência; as seis fontes de EX-49 não têm identificador. Quatro registos internos têm `url: null` (dois em EX-31, dois em EX-46), fazendo `url` alternar entre string e null sem união documentada. AUD-B confirma metadados bibliográficos ausentes/incompletos nas 9 fontes de EX-13, 6 de EX-18 e 9 de EX-19; o Markdown de EX-13 omite uma fonte e o de EX-19 não apresenta secção nem os nove URLs.
- **Revisão exigida:** definir um shape mínimo estável (`source_id`, título, autoria/organização, tipo, locator discriminado e uso/limite), atribuir IDs às seis fontes de EX-49, representar referências internas por campo próprio em vez de `url: null` e sincronizar as listas Markdown sem acrescentar evidência nova.

### TRANS-06-007 — `unresolved_fields` mistura pendências, limites e decisões fora de âmbito

- **Severidade:** média
- **Blocker:** não
- **Exercícios:** EX-07, EX-08, EX-14, EX-16, EX-18, EX-21, EX-23, EX-47
- **Campo:** `unresolved_fields`; `content_status`
- **Evidência:** oito JSON aprovados com limites têm `unresolved_fields` não vazio. EX-07 e EX-23 usam objetos `{field,status,note_pt_pt}`; os outros seis usam strings. Parte dos valores é uma fronteira legítima de prescrição ou variabilidade individual, parte é insuficiência de evidência e parte é relação de produto ainda por resolver.
- **Revisão exigida:** definir a semântica do campo e um shape único. Mover limites estáveis para `limitations_pt_pt`; manter em `unresolved_fields` apenas pendências que exijam decisão e associá-las a owner/gate. Fazer o estado depender da criticidade, não apenas da existência do campo.

### TRANS-06-008 — O validador autoral não funciona como gate de consistência

- **Severidade:** alta
- **Blocker:** não por si só
- **Exercícios:** 49
- **Campo:** `_beginner_content_workspace/all_author_validation.json`; integração das auditorias
- **Evidência:** o validador declara 49 `passed`, apesar de 304 warnings em 48 exercícios, seis chaves extra, deriva de tipos, 13 perdas do teste no Markdown e dois exercícios bloqueados pelas auditorias de capacidade. Os sete relatórios cobrem corretamente os 49 exercícios, mas usam vocabulários diferentes de estado (`passed`, `conforme`, `aprovado`, `bloqueado`, `revisão obrigatória`) e não existe roll-up estruturado.
- **Revisão exigida:** separar validação sintática de aprovação, adicionar checks de esquema/paridade/fontes e produzir um roll-up machine-readable com enumeração única, severidade e blocker. Um blocker de capacidade tem de prevalecer sobre `passed`.

## Estado por afetado

| Estado TRANS-06 | Afetados | Findings |
|---|---|---|
| **Bloqueado** | EX-40, EX-49 | 001, 002, 003, 006, 008 |
| **Revisão alta obrigatória** | EX-03, EX-04, EX-13, EX-18, EX-19, EX-24, EX-31, EX-46 | 002/003/004/006/007/008 conforme aplicável |
| **Revisão de paridade obrigatória** | EX-05, EX-06, EX-09, EX-11, EX-12, EX-16, EX-21, EX-27, EX-28, EX-42, EX-43, EX-45, EX-48 | 003, 005, 006, 007, 008 conforme aplicável |
| **Revisão estrutural/local** | EX-07, EX-08, EX-14, EX-17, EX-23, EX-34, EX-35, EX-37, EX-41, EX-47 | 003, 004, 006, 007, 008 conforme aplicável |
| **Sem finding semântico local; afetado pelo contrato transversal** | EX-01, EX-02, EX-10, EX-15, EX-20, EX-22, EX-25, EX-26, EX-29, EX-30, EX-32, EX-33, EX-36, EX-38, EX-39, EX-44 | 003, 006, 008 |

EX-37 aparece em revisão local porque o JSON verifica mover o pé “para a frente” e o Markdown “para o lado”. EX-47 aparece também porque o Markdown manda retirar as mãos sem preservar a condição “se as estiveres a usar”.

## Padrões e contagens

| Métrica | Resultado |
|---|---:|
| Pacotes / JSON / Markdown | 49 / 49 / 49 |
| JSON válidos | 49/49 |
| IDs e invariantes estruturados exatos | 49/49 |
| Mapeamentos de ID aplicados | 21 |
| Capacidades cobertas pelas auditorias | 49/49, sem duplicação |
| Famílias | 40 |
| Variantes formais | 3 |
| Relações aprovadas com referência interna válida | 154/154 |
| Chaves obrigatórias e ordem | 49/49 |
| Campos extra de risco alto | 45/45 |
| Estados públicos `approved_with_limits` | 49/49 |
| Exercícios bloqueados por auditoria de capacidade | 2 |
| Campos contratuais com tipo de topo divergente | 13/39 |
| Keysets de topo observados | 8 |
| Chaves não contratuais | 6 |
| Shapes de fonte | 48 |
| Shapes de teste | 7 |
| Markdown com perda clara do teste | 13 |
| JSON com `unresolved_fields` não vazio | 8 |
| Warnings do validador autoral | 304 em 48 exercícios |

Padrões positivos: IDs, capacidade, família, variante/base, risco estruturado, caminhos, mínimos contratuais e relações estão estáveis. Padrões negativos: cada autor modelou campos compostos e fontes de forma própria; processo, conteúdo e estado foram misturados; a paridade é avaliada por presença/reformulação, não por equivalência completa; e os blockers não chegam ao estado público.

## Independência

TRANS-06 não foi autor de nenhum conteúdo auditado. A revisão foi executada diretamente sobre os 49 pares JSON/Markdown, os 49 pacotes, o manifesto, a validação autoral e as sete auditorias de capacidade. Não foram lidos outros outputs transversais e não houve coordenação de conclusões com autores.

## Zero implementação

Não foram alterados JSON, Markdown de conteúdo, pacotes, relatórios de investigação, auditorias de capacidade, IDs, relações, equipamento, risco, ambiente, ontologia, código ou multimédia. Não houve publicação nem implementação. O único artefacto produzido é este relatório.
