# Passe de antebraços de voleibol para alvo

Conteúdo para principiantes em português europeu.

## Descrição curta

Receção controlada de uma bola de voleibol, alimentada por um parceiro, nos antebraços unidos e redireção para uma zona-alvo previamente definida.

## O que é

É uma tarefa técnica de manchete em que a pessoa observa uma bola lançada de forma controlada por um parceiro, ajusta os pés, forma uma plataforma com os antebraços e deixa a bola ressaltar em direção a um alvo conhecido. A bola não é agarrada nem lançada pelos braços.

## O que vais fazer

Vais acompanhar a trajetória da bola, ajustar a base, unir os antebraços, contactar a bola à frente do corpo e orientar o ressalto para a zona-alvo.

## Porque existe este movimento

Existe para praticar a formação da plataforma, o momento do contacto e a direção da bola numa ação isolada. A presença do alvo permite observar consistência direcional, sem transformar a tarefa em rally, sequência coletiva ou prescrição.

## Antes de começares

1. Confirma que tens uma bola de voleibol em bom estado, um parceiro capaz de alimentar a bola de forma controlada e uma zona-alvo definida.
2. Combina com o parceiro um sinal de início, a zona de receção e o alvo.
3. Liberta o percurso da bola e o espaço lateral e superior.
4. Confirma uma superfície firme, plana, regular e não escorregadia, com boa iluminação.
5. Não comeces num espaço partilhado sem controlo, junto de obstáculos ou sob um teto baixo.

## Preparar o equipamento

1. Bola de voleibol.
2. Marcador de alvo no chão.
3. sim
4. sim
5. Inspeciona visualmente a superfície e a forma da bola; não uses uma bola danificada, deformada, molhada ou com enchimento claramente inadequado. Define uma zona-alvo antes de começares. O marcador de chão é opcional, mas o alvo não é. O alvo pode ser uma zona assinalada ou uma zona cujos limites foram claramente combinados com o parceiro. Mantém bolas não utilizadas fora da zona de deslocação.

## Preparar o espaço

1. sim
2. sim
3. Superfície firme, nivelada e antiderrapante.
4. Área livre para a trajetória da bola e espaço livre por cima.
5. Evita tetos demasiado baixos e espaços partilhados sem controlo.
6. Escolhe um pavilhão, campo de voleibol ou zona de treino segura, com percurso da bola desimpedido, espaço lateral e superior livre e superfície firme, plana e não escorregadia. No exterior, considera vento, humidade e iluminação antes de iniciares.

## Verificação do corpo

1. Consegues ficar de pé numa base estável e fazer pequenos ajustes dos pés?
2. Consegues fletir confortavelmente os joelhos e manter os olhos na trajetória esperada?
3. Consegues unir os antebraços e estender os cotovelos sem dor aguda?
4. Se existir dor aguda ou perda de equilíbrio já nesta verificação, não inicies a alimentação.
5. Esta verificação operacional não determina aptidão clínica.

## Posição inicial

Fica de pé, orientado para o parceiro e para a trajetória esperada da bola. Usa uma base bipodal estável, com um pé ligeiramente à frente se for confortável, joelhos fletidos e ombros ligeiramente à frente. Mantém as mãos separadas enquanto te ajustas e prontas para formar a plataforma.

## Confirmar a posição inicial

1. Pés estáveis e prontos para ajustar.
2. Joelhos fletidos e ombros ligeiramente à frente.
3. Olhos na bola.
4. Alvo conhecido por ambos os parceiros.
5. Braços disponíveis à frente do corpo.
6. Espaço lateral e superior desimpedido.

## Passos de execução

1. Dá ao parceiro um sinal claro de que estás pronto e acompanha a bola desde que sai das mãos dele.
2. Ajusta-te com passos curtos para colocar a trajetória da bola à frente e, quando possível, perto da linha central do corpo.
3. Une as mãos, aproxima os antebraços, coloca os polegares lado a lado e estende os cotovelos para formar uma plataforma plana e firme.
4. Mantém a plataforma afastada do tronco e orienta-a para a zona-alvo.
5. Recebe a parte inferior da bola na superfície uniforme dos antebraços, entre os punhos e os cotovelos, à frente do corpo.
6. Deixa a bola ressaltar e orienta-a com o ângulo da plataforma e uma extensão controlada das pernas, evitando um balanço amplo dos braços.
7. Acompanha visualmente a saída da bola e recupera uma posição equilibrada.

## Fases do movimento

### Preparação

Observar a bola, ajustar a base e aproximar-se da linha da sua trajetória.

### Formação da plataforma

Unir mãos e antebraços, com cotovelos estendidos e superfície plana.

### Contacto e redireção

Contactar a bola à frente do corpo e orientar o ressalto para o alvo.

### Conclusão

Recuperar o equilíbrio, observar a zona e preparar a saída segura da trajetória.

## Respiração

Respira de forma natural e contínua enquanto acompanhas a bola. Podes deixar sair o ar suavemente no contacto, sem prender a respiração e sem impor contagens. As fontes técnicas de voleibol consultadas não definem um padrão respiratório específico para esta ação, pelo que a orientação se mantém deliberadamente geral.

## Sensações esperadas

1. Contacto breve e distribuído na superfície dos antebraços.
2. Participação controlada das pernas ao orientar a bola.
3. Necessidade de ajustar o equilíbrio e o momento do contacto.
4. Sensação de plataforma firme, sem apertar excessivamente mãos e ombros.

## Sensações inesperadas ou de alerta

1. Dor aguda.
2. Contactos repetidos da bola na face ou nos dedos.
3. Perda de equilíbrio que crie risco de queda ou colisão.
4. Entrada inesperada de outra pessoa na trajetória da bola.

## Indicações técnicas principais

1. Pés até à linha da bola.
2. Joelhos fletidos, ombros à frente.
3. Antebraços unidos, plataforma plana.
4. Contacto à frente do corpo.
5. Ângulo da plataforma para o alvo.
6. Deixa ressaltar; não balances os braços.

## Erros comuns e correções

### Erro 1: Tentar agarrar ou transportar a bola entre os braços.

- Como reconhecer: A bola fica presa ou acompanha os braços em vez de ressaltar.
- Como corrigir: Mantém um contacto breve numa plataforma firme e deixa a bola sair.

### Erro 2: Separar os antebraços no contacto.

- Como reconhecer: A bola toca superfícies diferentes e sai sem direção consistente.
- Como corrigir: Junta as mãos, aproxima os antebraços e alinha os polegares.

### Erro 3: Balancear excessivamente os braços.

- Como reconhecer: As mãos sobem muito depois do contacto e a bola dispara.
- Como corrigir: Mantém a plataforma estável e usa sobretudo o ângulo e uma extensão controlada das pernas.

### Erro 4: Contactar demasiado perto do corpo.

- Como reconhecer: A plataforma fica entre os joelhos ou a bola sobe para a face.
- Como corrigir: Ajusta os pés mais cedo e cria espaço entre o tronco e o ponto de contacto.

### Erro 5: Perseguir uma bola fora da zona segura.

- Como reconhecer: A pessoa corre para obstáculos, outra pessoa ou para fora da área combinada.
- Como corrigir: Deixa a bola cair, interrompe a alimentação e repõe a zona antes de continuar.

## Formas de simplificar ou ensaiar

1. O parceiro pode usar um lançamento suave, previsível e em arco confortável, dirigido à frente do corpo.
2. A zona-alvo pode ser visualmente ampla e clara, sem alterar a identidade da tarefa.
3. A pessoa pode ensaiar a posição e a plataforma sem bola antes de receber a alimentação.
4. A alimentação pode ser interrompida após cada contacto para permitir reposicionamento completo.
5. Estas opções reduzem a dificuldade momentânea; não constituem dose nem progressão programada.

## Supervisão

A supervisão é recomendada, não sendo necessário um assistente de segurança. Na primeira exposição ou quando a alimentação se torna mais exigente, é especialmente útil a observação de um treinador, professor ou adulto competente que controle o lançamento, o espaço e a formação da plataforma. Jovens, pessoas com deficiência, pessoas previamente sedentárias e pessoas em retorno funcional podem precisar de adaptação ou revisão apropriada ao contexto.

## Como terminar

Deixa a última bola cair ou entrega-a ao parceiro sem a perseguir. Se a bola sair da zona, espera que o espaço esteja livre antes de a recolher. Perante um sinal de interrupção, para a alimentação e afasta-te da trajetória.

## Nota de segurança

O risco operacional canónico é baixo, mas não é nulo. Usa alimentação controlada, protege a face e os dedos mantendo a bola à frente, comunica com o parceiro e interrompe perante dor aguda, contactos repetidos na face ou entrada de uma pessoa na zona.

## Quando parar ou reduzir

1. Contactos repetidos na face.
2. Dor aguda.
3. Entrada de uma pessoa na zona.
4. Risco imediato de colisão ou perda da zona livre.
5. Para perante este sinal de alerta: Dor aguda.
6. Para perante este sinal de alerta: Contactos repetidos da bola na face ou nos dedos.
7. Para perante este sinal de alerta: Perda de equilíbrio que crie risco de queda ou colisão.
8. Para perante este sinal de alerta: Entrada inesperada de outra pessoa na trajetória da bola.
9. O parceiro interrompe imediatamente o envio; ninguém persegue a bola e a recolha só acontece depois de a pessoa e a trajetória estarem estáveis.

## Segurança do equipamento

Usa uma bola de voleibol em bom estado. Não uses uma bola danificada, deformada, molhada ou com enchimento claramente inadequado. Mantém bolas não utilizadas fora da zona de deslocação. Coloca o marcador de chão opcional de forma plana e sem criar risco de tropeção.

## Segurança do espaço

Mantém espaço livre à frente, aos lados e por cima. Usa uma superfície firme, plana, regular e não escorregadia. Não pratiques sob teto baixo nem num espaço partilhado sem controlo. Considera pouca iluminação, piso molhado e vento como fatores que dificultam a trajetória e o controlo. Interrompe se alguém entrar na zona da bola.

## Limitações

1. Conteúdo documental para um principiante, sem prescrição de repetições, séries, duração, distância, carga, intensidade, velocidade, ritmo, frequência, descanso ou progressão.
2. Não é diagnóstico, tratamento, autorização universal nem avaliação individual de elegibilidade.
3. A supervisão recomendada e as adaptações dependem do contexto da pessoa e do local.
4. A fonte FIVB de exercícios de praia foi usada apenas para pontos técnicos transferíveis de passe e não altera a compatibilidade indoor e outdoor do exercício canónico.
5. Os conteúdos multimédia continuam por aprovar.
6. Implementação realizada: não.

## Teste de compreensão

### 1. Que material, parceiro e alvo são indispensáveis?

Resposta esperada: Uma bola de voleibol, um parceiro capaz de alimentar a bola de forma controlada e uma zona-alvo definida.

### 2. Que características deve ter a zona de prática?

Resposta esperada: Superfície firme, plana, regular e não escorregadia, com espaço lateral e superior livre e sem obstáculos.

### 3. Quando deves unir as mãos e formar a plataforma?

Resposta esperada: Depois de te ajustares à trajetória e quando estiveres posicionado para o contacto.

### 4. Onde deve ocorrer o contacto com a bola?

Resposta esperada: À frente do corpo, na superfície uniforme dos antebraços entre os punhos e os cotovelos.

### 5. Como ficam os polegares e os cotovelos?

Resposta esperada: Polegares lado a lado e cotovelos estendidos para formar uma plataforma plana.

### 6. O que dirige principalmente a bola para o alvo?

Resposta esperada: O ângulo da plataforma, apoiado por uma extensão controlada das pernas.

### 7. Porque não deves fazer um balanço amplo dos braços?

Resposta esperada: Porque torna o contacto e a saída da bola menos controlados; a plataforma deve manter-se estável.

### 8. O que fazes se a bola sair da zona segura?

Resposta esperada: Deixo-a cair, interrompo a alimentação e só a recolho quando o espaço estiver livre.

### 9. Como deve o parceiro alimentar a bola no início?

Resposta esperada: De forma controlada, previsível e dirigida para a frente do corpo.

### 10. Como deves respirar durante a ação?

Resposta esperada: De forma natural e contínua, podendo expirar suavemente no contacto, sem prender a respiração nem seguir contagens.

### 11. Que sinais obrigam a interromper a tarefa?

Resposta esperada: Dor aguda, contactos repetidos na face, entrada de uma pessoa na zona ou risco imediato de colisão.

### 12. A tarefa inclui uma dose ou garante um resultado?

Resposta esperada: Não. O conteúdo explica a execução e a segurança, sem dose, promessa ou resultado garantido.

## Fontes e limites da evidência

### Fonte 1: Coaches Manual Level II

- Autor ou entidade: FIVB
- Tipo: manual técnico oficial
- Localizador: https://www.fivb.com/wp-content/uploads/2024/03/Coaches_Manual_Level_II_EN.pdf
- Usada para: Distingue o passe de antebraços e documenta contacto nos antebraços, plataforma e direção para o alvo.
- Limite: F2-S09 — FIVB — Coaches Manual Level II — https://www.fivb.com/wp-content/uploads/2024/03/Coaches_Manual_Level_II_EN.pdf — manual técnico oficial — Distingue o passe de antebraços e documenta contacto nos antebraços, plataforma e direção para o alvo. — 2026-07-24

### Fonte 2: Beach Volleyball exercício técnico-book

- Autor ou entidade: FIVB
- Tipo: manual técnico oficial
- Localizador: https://www.fivb.com/wp-content/uploads/2024/03/FIVB_Beachvolley_Drill-Book_EN.pdf
- Usada para: Sustenta base ampla, joelhos fletidos, braços estendidos, movimento para a linha da bola, contacto à frente e alimentação por parceiro ou treinador.
- Limite: EX43-S01 — FIVB — Beach Volleyball exercício técnico-book — https://www.fivb.com/wp-content/uploads/2024/03/FIVB_Beachvolley_Drill-Book_EN.pdf — manual técnico oficial — Sustenta base ampla, joelhos fletidos, braços estendidos, movimento para a linha da bola, contacto à frente e alimentação por parceiro ou treinador. — 2026-07-24

### Fonte 3: Official Volleyball Rules 2025–2028

- Autor ou entidade: FIVB
- Tipo: regras oficiais
- Localizador: https://www.fivb.com/wp-content/uploads/2025/01/FIVB-Volleyball_Rules2025_2028-EN-v05.pdf
- Usada para: Sustenta superfície plana e não escorregadia, espaço livre de obstáculos, inspeção da bola e contacto em ressalto sem agarrar ou lançar.
- Limite: EX43-S02 — FIVB — Official Volleyball Rules 2025–2028 — https://www.fivb.com/wp-content/uploads/2025/01/FIVB-Volleyball_Rules2025_2028-EN-v05.pdf — regras oficiais — Sustenta superfície plana e não escorregadia, espaço livre de obstáculos, inspeção da bola e contacto em ressalto sem agarrar ou lançar. — 2026-07-24

### Fonte 4: Junior High Lesson Plans

- Autor ou entidade: USA Volleyball
- Tipo: manual pedagógico oficial
- Localizador: https://usavolleyball.org/wp-content/uploads/2020/12/Junior-High-Lesson-Plans.pdf
- Usada para: Sustenta pés à largura dos ombros, joelhos fletidos, deslocação à bola, polegares lado a lado, plataforma afastada do corpo e orientada ao alvo, bem como lançamento controlado.
- Limite: F1S06 — USA Volleyball — Junior High Lesson Plans — https://usavolleyball.org/wp-content/uploads/2020/12/Junior-High-Lesson-Plans.pdf — manual pedagógico oficial — Sustenta pés à largura dos ombros, joelhos fletidos, deslocação à bola, polegares lado a lado, plataforma afastada do corpo e orientada ao alvo, bem como lançamento controlado. — 2026-07-24

### Fonte 5: Teaching Goals, Objectives, Glossary and indicação técnica Words

- Autor ou entidade: USA Volleyball
- Tipo: glossário técnico oficial
- Localizador: https://usavolleyball.org/wp-content/uploads/2020/12/Junior-High-Glossary-indicação técnica-Words.pdf
- Usada para: Sustenta braços unidos, polegares lado a lado, cotovelos estendidos, contacto entre punhos e cotovelos e indicações técnicas de plataforma plana.
- Limite: EX43-S03 — USA Volleyball — Teaching Goals, Objectives, Glossary and indicação técnica Words — https://usavolleyball.org/wp-content/uploads/2020/12/Junior-High-Glossary-indicação técnica-Words.pdf — glossário técnico oficial — Sustenta braços unidos, polegares lado a lado, cotovelos estendidos, contacto entre punhos e cotovelos e indicações técnicas de plataforma plana. — 2026-07-24

### Fonte 6: Lesson Plans

- Autor ou entidade: USA Volleyball
- Tipo: índice oficial de recursos
- Localizador: https://usavolleyball.org/resources-for-coaches/lesson-plans/
- Usada para: Confirma a proveniência institucional dos planos pedagógicos consultados.
- Limite: F1S05 — USA Volleyball — Lesson Plans — https://usavolleyball.org/resources-for-coaches/lesson-plans/ — índice oficial de recursos — Confirma a proveniência institucional dos planos pedagógicos consultados. — 2026-07-24

### Fonte 7: Getting Active to Control High Blood Pressure

- Autor ou entidade: American Heart Association
- Tipo: orientação profissional oficial
- Localizador: https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure
- Usada para: Apoia apenas a orientação geral de respirar regularmente e evitar prender a respiração; não fornece uma técnica respiratória específica para o passe.
- Limite: EX43-S04 — American Heart Association — Getting Active to Control High Blood Pressure — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — orientação profissional oficial — Apoia apenas a orientação geral de respirar regularmente e evitar prender a respiração; não fornece uma técnica respiratória específica para o passe. — 2026-07-24
