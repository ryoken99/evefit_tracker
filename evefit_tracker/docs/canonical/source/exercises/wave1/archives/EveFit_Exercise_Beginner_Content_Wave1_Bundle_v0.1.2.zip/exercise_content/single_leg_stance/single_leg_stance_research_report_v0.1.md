# Relatório de investigação — Postura unipodal

**Agente:** EX-38  
**Exercise ID:** `single_leg_stance`  
**Nome:** Postura unipodal  
**Data da pesquisa:** 24 de julho de 2026  
**Implementação realizada:** não

## Âmbito

A pesquisa incidiu exclusivamente na execução documental para principiante da postura unipodal: posição, apoio opcional, respiração, visão, superfície, risco de queda, erros observáveis, saída segura e supervisão.

Foram preservados sem alteração:

- a identidade canónica de postura estática sobre um único pé, com visão disponível e sem deslocamento global;

- o risco operacional moderado;

- a ausência de equipamento obrigatório e o apoio estável opcional;

- a superfície firme, nivelada e antiderrapante;

- as relações canónicas aprovadas;

- a separação entre esta identidade e condições com olhos fechados, rotação da cabeça, superfície instável ou manipulação de objetos.

Não foram produzidos dose, tempo de manutenção, progressão programada, promessa de resultado, diagnóstico, tratamento, código ou publicação.

## Método

Foram consideradas as fontes já associadas ao registo canónico e realizada pesquisa adicional em:

- orientações oficiais e materiais profissionais de saúde;

- literatura científica primária sobre postura unipodal, visão e fadiga;

- uma revisão sistemática para delimitar a família de tarefas.

A evidência foi usada apenas quando sustentava uma instrução observável ou um limite de segurança. Não foram transpostas indicações de dose, resultados clínicos específicos nem autorizações universais.

## Fontes e contributos

| Código | Fonte | Tipo | Contributo utilizado | Limite relevante |
|---|---|---|---|---|
| `E1-SRC-003` | [Oxford University Hospitals NHS — OTAGO Strength and Balance](https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf) | Manual profissional | Postura alta, joelho de apoio desbloqueado, proximidade e firmeza do apoio conforme a necessidade. | Material centrado sobretudo em pessoas idosas; as indicações de dose foram excluídas. |
| `EX38-SRC-001` | [CDC — STEADI Coordinated Care Plan: Tele-Med Adaptation](https://www.cdc.gov/steadi/media/pdfs/2024/08/Telesteadi-Guide_H_WEB.pdf) | Orientação oficial | Área desimpedida, avaliação prévia do risco, ajuda próxima em contextos de maior risco e cautela acrescida com a postura unipodal à distância. | Contexto de avaliação clínica remota, não de ensino autónomo do exercício. |
| `EX38-SRC-002` | [Torbay and South Devon NHS Foundation Trust — Chair Based Home Exercise Programme](https://www.torbayandsouthdevon.nhs.uk/uploads/chair-based-home-exercise-programme.pdf) | Material profissional | Respiração normal e contínua, sem retenção; estabilidade do apoio. | A orientação respiratória é geral e não específica da postura unipodal. |
| `EX38-SRC-003` | [Springer et al. — Normative Values for the Unipedal Stance Test with Eyes Open and Closed](https://pubmed.ncbi.nlm.nih.gov/19839175/) | Estudo primário | Comparação direta entre visão disponível e indisponível; o desempenho foi superior com os olhos abertos. | Estudo de avaliação e valores normativos; não define ensino nem dose. |
| `EX38-SRC-004` | [Kozinc et al. — The Effect of Fatigue on Single-Leg Postural Sway and Its Transient Characteristics in Healthy Young Adults](https://pubmed.ncbi.nlm.nih.gov/34489739/) | Estudo primário | A fadiga alterou características da oscilação postural em apoio unipodal, sustentando cautela perante degradação do controlo. | Adultos jovens fisicamente ativos e protocolo laboratorial; sem transferência automática para outras populações. |
| `E2-S07` | [Marcori et al. — Single Leg Balance Training: A Systematic Review](https://pubmed.ncbi.nlm.nih.gov/35084234/) | Revisão sistemática | Confirma a postura unipodal como família reconhecível de tarefas de equilíbrio. | Heterogeneidade de visão, superfície, apoio e tarefas adicionais; não define uma execução universal. |

As fontes são independentes entre si e incluem organismos oficiais, materiais profissionais e dois estudos primários.

## Síntese por questão

### Posição unipodal

O manual Otago descreve uma postura alta, com equilíbrio sobre uma perna e joelho de apoio desbloqueado. Isto é coerente com a identidade canónica e sustenta as indicações “tronco direito”, “pé de apoio assente” e “joelho alinhado e desbloqueado”.

Não existe base suficiente para impor uma posição rígida dos braços ou uma altura específica do pé livre. O conteúdo permite braços confortáveis e elevação apenas suficiente para retirar o contacto do pé livre com o piso.

### Apoio opcional

O manual Otago recomenda um apoio seguro ajustado à necessidade de equilíbrio. O conteúdo mantém esse apoio como opcional, tal como exige o registo canónico, mas especifica que deve estar imobilizado, ao alcance e disponível antes de elevar o pé.

Objetos com rodas, leves, móveis ou suscetíveis de tombar foram excluídos por não satisfazerem a condição de apoio estável.

### Visão

O estudo primário de Springer et al. encontrou desempenho superior na condição com olhos abertos. A identidade canónica também exige visão disponível. Por isso, a instrução mantém os olhos abertos e uma referência visual estável à frente.

Fechar os olhos não é tratado como erro a corrigir dentro de uma variante; é explicitamente identificado como condição fora desta execução.

### Respiração

Não foi encontrada uma técnica respiratória específica e necessária para a postura unipodal. O material profissional do NHS sustenta respiração normal sem retenção. A orientação final é, portanto, respirar de forma natural e contínua, sem contagens nem apneia voluntária.

### Superfície e espaço

O registo canónico determina piso firme, nivelado e antiderrapante e área livre. A orientação do CDC reforça a remoção de obstáculos e a avaliação do espaço em tarefas de equilíbrio. O conteúdo exclui pisos escorregadios, instáveis ou atravancados, alturas sem proteção e veículos em movimento.

Espuma e outras superfícies instáveis permanecem fora da identidade.

### Risco de queda e saída

O risco operacional permanece moderado. A redução da base de apoio e a possibilidade de perda de equilíbrio justificam uma saída simples e imediata: usar o apoio, pousar o pé livre e recuperar a base bipodal.

O estudo de Kozinc et al. mostra que a fadiga pode alterar a oscilação postural, mas não permite definir limiares universais. Em vez disso, o conteúdo usa sinais observáveis: passos descontrolados, necessidade repetida de apoio não planeado e incapacidade de regressar a dois apoios.

### Supervisão

O registo canónico classifica a supervisão como recomendada. O CDC acrescenta cautela quando a história de quedas, a fragilidade visível ou a capacidade de ajuda tornam uma avaliação remota insegura.

A redação final recomenda supervisão próxima perante risco elevado de queda, quedas recentes, contexto neurológico ou vestibular, incapacidade de sair da tarefa de forma independente ou dificuldade em recuperar dois apoios. Não foi acrescentada exigência universal de observador.

## Erros selecionados

Foram incluídos erros com reconhecimento visual e correção imediata:

1. fechar os olhos ou perder a referência visual;

2. bloquear o joelho ou deixá-lo colapsar para dentro;

3. inclinar ou rodar excessivamente o tronco;

4. deslocar, rodar ou levantar partes do pé de apoio;

5. usar um apoio inseguro ou demasiado afastado;

6. continuar depois de perder estabilidade.

Estes erros cobrem identidade, alinhamento, contacto com o piso, segurança do equipamento opcional e estratégia de saída.

## Decisões de conteúdo

- Estado: `beginner_content_approved_with_limits`.

- Confiança global: moderada-alta.

- A definição pública descreve a ação sem associar uma intenção de treino exclusiva.

- A execução contém preparação bipodal, transferência de peso, apoio unipodal e saída para dois apoios.

- A respiração é natural e contínua, sem técnica específica.

- Pequenas oscilações são apresentadas como esperadas; perda de controlo, dor aguda, tontura, mal-estar e necessidade repetida de apoio não planeado são sinais de interrupção.

- Foram incluídas perguntas de compreensão sobre superfície, visão, apoio, alinhamento, respiração, sinais de interrupção, limites da identidade e supervisão.

## Limitações

A evidência profissional consultada dirige-se em parte a pessoas idosas, enquanto os estudos primários têm objetivos de avaliação ou protocolos laboratoriais. Estas fontes sustentam instruções delimitadas, mas não uma transferência automática para todas as populações.

O conteúdo não substitui avaliação individual. Pessoas com risco elevado de queda, quedas recentes, condições neurológicas ou vestibulares, ou incapacidade de recuperar dois apoios permanecem sujeitas a revisão e supervisão adequadas ao contexto.

As relações aprovadas foram preservadas e nenhuma relação nova foi proposta. O risco moderado, o apoio opcional e os requisitos de superfície não foram alterados.

**Implementação realizada: não.**
