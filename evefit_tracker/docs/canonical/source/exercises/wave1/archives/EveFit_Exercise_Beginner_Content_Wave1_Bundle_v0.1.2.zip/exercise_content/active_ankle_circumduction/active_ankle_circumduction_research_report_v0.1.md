# Relatório de investigação — `active_ankle_circumduction`

**Agente:** EX-22  
**Exercício:** Circundução ativa do tornozelo  
**Data de consulta:** 24 de julho de 2026  
**Implementação realizada: não**

## Âmbito e resultado

A investigação incidiu apenas na execução para principiantes, posicionamento, respiração, segurança, amplitude, erros técnicos e critérios de supervisão. Não alterou a identidade canónica, o risco, o equipamento, a superfície, o ambiente, as relações aprovadas ou o estado dos média.

O conteúdo resultante é defensável como orientação documental de execução com limites. Há convergência entre fontes profissionais independentes quanto a pé livre, condução pelo tornozelo, movimento lento, controlo sem impulso, joelho relativamente imóvel e amplitude confortável. Não existe suporte para prometer eficácia individual nem para definir uma trajetória circular ideal.

## Fontes consultadas

### 1. American Academy of Orthopaedic Surgeons — OrthoInfo

**Título:** *Foot and Ankle Conditioning Program*  
**Tipo:** orientação ortopédica oficial, com autoria de fisioterapia e revisão médica por pares  
**Ligação:** https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/  
**Códigos existentes:** `C1-S10`, `C2-S02`

Elementos usados:

- Para amplitude ativa do tornozelo, indica posição sentada com os pés sem tocar no chão.
- A tarefa é conduzida pelo pé, com a ponta do pé como referência.
- Recomenda manter os movimentos pequenos e usar apenas o pé e o tornozelo.
- A orientação geral afirma que a dor não deve ser ignorada e remete dúvidas ou desconforto para médico ou fisioterapeuta.

Limites:

- A tarefa direta é o alfabeto do tornozelo, não uma circundução isolada.
- Integra um programa clínico mais amplo.
- Não foram importados volume, frequência, indicações clínicas ou alegações de resultado.

### 2. Royal Berkshire NHS Foundation Trust

**Título:** *Ankle range of movement exercises*  
**Tipo:** orientação clínica oficial de fisioterapia  
**Data:** dezembro de 2025  
**Ligação:** https://www.royalberkshire.nhs.uk/media/iz3hdgmm/ankle-range-of-movement-exercises_dec25.pdf  
**Código de trabalho:** `EX22-S01`

Elementos usados:

- A circundução pode ser feita em posição sentada.
- O tornozelo é movido lentamente em círculos.
- A direção pode ser invertida.
- A orientação de inversão associada explicita manter o joelho imóvel, reforçando a distinção entre movimento do tornozelo e compensação da perna.

Limites:

- O folheto dirige-se a pessoas após lesão.
- Não avalia a eficácia isolada do exercício.
- Não foram importadas indicação clínica, dose ou progressão.

### 3. American Council on Exercise

**Título:** *Controlled Articular Rotations: Shifting Mobility into High Gear*  
**Tipo:** orientação profissional para exercício  
**Data:** outubro de 2024  
**Ligação:** https://www.acefitness.org/continuing-education/certified/october-2024/8725/controlled-articular-rotations-shifting-mobility-into-high-gear/  
**Código existente:** `C1-S04`

Elementos usados:

- Define rotações articulares como movimentos lentos, deliberados e ativos.
- Valoriza controlo intencional e ausência de impulso ou balanço.
- Enquadra a amplitude como controlada e sem dor.
- Separa instrução geral de exercício de avaliação, diagnóstico ou intervenção individual.

Limites:

- Descreve a família geral de rotações articulares controladas, não a circundução sentada do tornozelo isoladamente.
- Não é um ensaio clínico de eficácia.
- Alegações de prevenção ou melhoria não foram convertidas em promessas.

### 4. Leardini, Stagni e O'Connor

**Título:** *Mobility of the subtalar joint in the intact ankle complex*  
**Periódico:** *Journal of Biomechanics* 34(6):805–809  
**Ano:** 2001  
**PMID:** 11470119  
**DOI:** 10.1016/S0021-9290(01)00031-8  
**Ligação:** https://pubmed.ncbi.nlm.nih.gov/11470119/  
**Tipo:** literatura primária biomecânica  
**Código de trabalho:** `EX22-S02`

Elementos usados:

- Documenta acoplamento entre flexão plantar, supinação/rotação interna e entre dorsiflexão, pronação/rotação externa no complexo subtalar intacto.
- Mostra que os eixos de inversão e eversão mudam ao longo de uma trajetória preferencial.
- Observa menor movimento subtalar perto dos extremos de dorsiflexão e flexão plantar.

Interpretação conservadora:

- A circundução não deve ser apresentada como rotação pura de uma única articulação.
- Uma trajetória individual pode não ser geometricamente perfeita.
- Não há base para forçar extremos articulares para “completar” o círculo.

Limites:

- Estudo in vitro em sete espécimes.
- Movimento passivo com momentos externos aplicados.
- Não estudou principiantes, execução sentada, respiração, segurança operacional ou eficácia.

## Síntese por domínio

| Domínio | Decisão documental | Base |
|---|---|---|
| Posição | Sentada em cadeira estável, coxa apoiada, pé-alvo livre do chão | Identidade canónica; AAOS |
| Condução | O pé move-se a partir do tornozelo; coxa e joelho relativamente imóveis | Identidade canónica; AAOS; Royal Berkshire NHS |
| Trajetória | Círculo contínuo, lento, deliberado e sem impulso | Royal Berkshire NHS; ACE |
| Amplitude | Tolerada e controlável; pode ser pequena ou irregular; não forçar fim de amplitude | AAOS; ACE; Leardini et al. como suporte biomecânico indireto |
| Respiração | Natural e contínua, sem retenção ou contagem imposta | Regra contratual; não foi encontrada orientação respiratória específica nas fontes do exercício |
| Sensações esperadas | Movimento à volta do tornozelo, esforço ligeiro de controlo e alongamento suave possível | AAOS, de forma geral; formulação conservadora |
| Sinais de paragem | Dor aguda, bloqueio, perda súbita de controlo, tontura ou mal-estar | Registo canónico preservado |
| Erros | Movimento conduzido pela perna, impulso, amplitude forçada, círculo perfeito a qualquer custo, contacto com o chão e retenção respiratória | Derivação técnica conservadora das fontes e do registo canónico |
| Supervisão | Não exigida de base; orientação profissional perante dificuldade de suporte/controlo, medo de queda, sintomas ou contexto clínico de revisão | Registo canónico preservado; limites de âmbito da AAOS e ACE |

## Decisões de segurança

Foram mantidos sem alteração:

- Risco operacional base: `low`.
- Fatores principais: compensação com joelho ou anca; forçar o fim da amplitude.
- Cadeira obrigatória: `stable_chair_without_wheels`.
- Superfície obrigatória: `firm_level_non_slip_floor_under_chair`.
- Espaço: `minimal_stationary`, com percurso sem obstáculos.
- Superfícies inadequadas: piso escorregadio e assento instável ou com rodas.
- Supervisão de base: `none`; observador não obrigatório.
- Sinais canónicos de interrupção: dor aguda, bloqueio articular, perda súbita de controlo, tontura ou mal-estar.
- Gatilhos de supervisão: incapacidade de manter o suporte, medo de queda, sintomas durante a amplitude e dificuldade em distinguir o movimento-alvo da compensação.

## Relações canónicas preservadas

| Contexto | Capacidade | Conceito | Intenção | Estado | Papel | Piso de risco efetivo |
|---|---|---|---|---|---|---|
| `main_training` | `mobility` | `active_joint_exploration` | `increase_active_joint_range_of_motion` | `compatible` | `principal_candidate` | `moderate` |
| `prevention` | `mobility` | `active_joint_exploration` | `maintain_active_joint_range_capacity` | `compatible` | `principal_candidate` | `moderate` |
| `recovery` | `mobility` | `active_joint_exploration` | `maintain_light_joint_mobility_activity` | `compatible` | `complementary` | `low` |
| `warmup` | `mobility` | `active_joint_exploration` | `prepare_required_joint_ranges` | `compatible` | `principal_candidate` | `low` |

Nenhuma relação nova foi criada e nenhum estado, papel, limite ou modificador de risco foi reduzido.

## Confiança e limitações

**Confiança global:** moderada.

- **Execução e posicionamento:** alta, pela concordância entre AAOS, NHS e identidade canónica.
- **Segurança e amplitude:** moderada, porque as fontes clínicas são orientações profissionais e a literatura primária é biomecânica indireta.
- **Respiração:** moderada, por ausência de padrão específico do exercício; aplicou-se apenas respiração natural e contínua sem retenção.

Limitações finais:

- Não foi identificada investigação primária sobre esta exata circundução sentada como instrução isolada para principiantes.
- Não há suporte para uma forma geométrica perfeita, amplitude universal ou resultado garantido.
- O conteúdo não substitui revisão individual perante cirurgia recente, retorno à função, sintomas persistentes ou instabilidade conhecida.
- Não foram introduzidos volume, frequência, duração, intensidade, progressão ou outros parâmetros de dose.
- Não houve aprovação de imagem ou vídeo.
- Não houve código, publicação ou implementação.
