# Marcha no lugar

Conteúdo para principiantes em português europeu.

## Descrição curta

Alternância controlada dos pés em posição de pé, sem sair do lugar e sem saltar.

## O que é

A marcha no lugar imita o padrão alternado da caminhada, mas mantém o corpo na mesma zona. Um pé sustenta o corpo enquanto o outro se eleva e volta ao chão; depois, os lados trocam. Não existe uma fase de corrida ou salto.

## O que vais fazer

Vais transferir o peso de um lado para o outro, elevar um pé de cada vez e pousá-lo com controlo na mesma zona. Se o equilíbrio permitir, os braços podem acompanhar naturalmente o movimento das pernas.

## Porque existe este movimento

Este movimento permite executar um padrão rítmico alternado de corpo inteiro num espaço reduzido. Pode integrar treino principal e, quando as condições e a elegibilidade o permitem, contextos de aquecimento ou recuperação; a forma concreta de o usar pertence à prescrição.

## Antes de começares

1. Confirma que consegues ficar de pé e alternar o apoio entre os pés sem perda marcada de equilíbrio.
2. Escolhe uma zona pequena, plana, firme, bem iluminada e sem objetos no chão.
3. Usa roupa que não prenda os passos e calçado estável que não escorregue.
4. Se tens limitações de equilíbrio, estás a regressar após lesão ou cirurgia, ou tens sintomas cardiorrespiratórios relevantes, procura orientação adequada antes de executares sem supervisão.

## Preparar o equipamento

1. Não é necessário equipamento. Se precisares de apoio para manter a estabilidade, coloca-te junto de uma superfície fixa, firme e à altura confortável das mãos; o apoio é uma adaptação de segurança e não altera a identidade do exercício.

## Preparar o espaço

1. Reserva uma pequena área sem obstáculos, com piso firme, regular, seco e não escorregadio. Garante espaço suficiente para mover os braços sem tocar em paredes, móveis ou outras pessoas e mantém boa visibilidade do espaço.

## Verificação do corpo

1. Em pé, confirma que consegues distribuir o peso pelos dois pés.
2. Transfere ligeiramente o peso para cada lado e verifica se manténs o controlo.
3. Confirma que não existe dor nova, tontura, confusão, desconforto no peito ou falta de ar fora do habitual antes de começares.
4. Se a estabilidade for incerta, usa um apoio fixo ou pede supervisão.

## Posição inicial

Fica de pé, com os pés aproximadamente à largura das ancas, joelhos sem bloqueio, tronco direito e olhar em frente. Mantém os ombros relaxados e as mãos soltas; aproxima uma mão do apoio fixo se precisares.

## Confirmar a posição inicial

1. Pés assentes numa superfície firme e regular.
2. Peso distribuído de forma confortável entre os dois pés.
3. Tronco direito, sem inclinação marcada para a frente ou para trás.
4. Olhar em frente e ombros relaxados.
5. Zona à volta livre de obstáculos.
6. Apoio fixo ao alcance, se necessário.

## Passos de execução

1. A partir da posição inicial, mantém o peito orientado em frente e transfere o peso para um pé sem inclinar bruscamente o tronco.
2. Eleva o pé oposto do chão, deixando o joelho dobrar apenas até uma altura confortável e controlável.
3. Mantém pelo menos um pé em contacto com o chão; não transformes a elevação num salto.
4. Volta a pousar o pé suavemente perto do ponto de partida, sem bater no chão nem avançar pela divisão.
5. Transfere o peso para esse pé e eleva o outro, repetindo a mesma sequência com controlo.
6. Continua a alternar os lados num padrão regular, mantendo o tronco estável e a amplitude que consegues controlar.
7. Se permaneceres estável, deixa os braços balançarem naturalmente em oposição às pernas, com cotovelos confortavelmente dobrados e mãos descontraídas.
8. Respira de forma natural e contínua durante toda a alternância, sem prender a respiração.

## Fases do movimento

### Transferência de peso

O peso passa de forma controlada para o pé que fica no chão.

### Elevação do pé

O pé oposto eleva-se e o joelho dobra dentro de uma amplitude confortável.

### Regresso controlado

O pé volta ao chão perto do ponto de partida, sem impacto marcado.

### Troca de lado

O apoio muda para o outro pé e o ciclo repete-se do lado oposto.

## Respiração

Mantém uma respiração natural e contínua. Não é necessário sincronizar a respiração com cada passo e não deves fazer retenções. Se a respiração se tornar atípica ou desconfortável, reduz o movimento ou termina em segurança.

## Sensações esperadas

1. Transferência alternada do peso entre os pés.
2. Trabalho suave e repetido nas pernas e ancas.
3. Movimento leve dos braços, se os usares.
4. Respiração mais percetível do que em repouso, mas sem desconforto atípico.

## Sensações inesperadas ou de alerta

1. Dor nova ou crescente.
2. Desconforto, pressão ou aperto no peito.
3. Falta de ar atípica ou desproporcionada.
4. Tontura, sensação de desmaio ou confusão.
5. Perda de controlo, tropeção repetida ou instabilidade que aumenta.

## Indicações técnicas principais

1. Mantém pelo menos um pé no chão.
2. Cresce pelo topo da cabeça e olha em frente.
3. Pousa cada pé de forma suave e controlada.
4. Alterna os lados sem sair da tua zona.
5. Relaxa os ombros e as mãos.
6. Respira de forma contínua, sem prender o ar.

## Erros comuns e correções

### Erro 1: Transformar a marcha numa corrida ou num salto.

- Como reconhecer: Os dois pés deixam o chão ao mesmo tempo ou ouvem-se contactos bruscos e rápidos.
- Como corrigir: Reduz a elevação e garante que um pé permanece apoiado enquanto o outro se move.

### Erro 2: Elevar o joelho para além da amplitude controlável.

- Como reconhecer: O tronco inclina-se para trás, a bacia roda excessivamente ou surge desequilíbrio a cada elevação.
- Como corrigir: Eleva menos o pé e mantém o tronco direito; usa um apoio fixo se a estabilidade continuar incerta.

### Erro 3: Pousar o pé sem controlo.

- Como reconhecer: O pé bate no chão, cruza à frente do outro ou cai longe da posição inicial.
- Como corrigir: Abranda a troca de apoio e coloca o pé suavemente debaixo do corpo antes de mudar de lado.

### Erro 4: Deslocar-se progressivamente pela divisão.

- Como reconhecer: A posição aproxima-se de uma parede, móvel ou obstáculo em vez de permanecer na mesma zona.
- Como corrigir: Usa uma referência visual no chão e faz elevações menores, pousando cada pé perto do ponto de partida.

### Erro 5: Prender a respiração e acumular tensão na parte superior do corpo.

- Como reconhecer: Os ombros sobem, as mãos fecham-se com força ou a respiração fica interrompida.
- Como corrigir: Solta as mãos, baixa os ombros e deixa o ar entrar e sair naturalmente enquanto alternas os pés.

## Formas de simplificar ou ensaiar

1. Eleva cada pé apenas o suficiente para o libertar do chão.
2. Mantém uma mão numa superfície fixa e firme.
3. Deixa os braços junto ao corpo até conseguires alternar os pés com estabilidade.
4. Faz uma pausa com os dois pés apoiados sempre que precisares de recuperar o controlo.

## Supervisão

A supervisão não é necessária por defeito. Deve ser considerada quando existe instabilidade marcada, quando a pessoa não consegue alternar o apoio com controlo ou quando o ambiente é desconhecido. Um apoio fixo pode ajudar numa incerteza ligeira de equilíbrio, mas não substitui supervisão quando há risco de queda.

## Como terminar

Diminui gradualmente a amplitude das elevações, pousa os dois pés no chão e estabiliza a postura. Mantém o apoio ao alcance se precisares e confirma que te sentes estável antes de te afastares.

## Nota de segurança

Executa apenas numa superfície firme, regular e livre de obstáculos. Não aumentes a velocidade para compensar uma perda de equilíbrio. Termina se perderes o controlo ou se surgir um sinal de alerta.

## Quando parar ou reduzir

1. Perda de controlo, tropeção ou instabilidade crescente. — Reduz a elevação, volta a apoiar os dois pés e termina se o controlo não regressar.
2. Dor nova ou crescente. — Termina o movimento e não tentes corrigir aumentando o ritmo.
3. Tontura, sensação de desmaio ou confusão. — Termina imediatamente e procura ajuda adequada.
4. Desconforto no peito ou falta de ar atípica. — Termina imediatamente e procura avaliação adequada, sobretudo se o sintoma for intenso, persistente ou acompanhado por outros sinais preocupantes.

## Segurança do equipamento

Não há equipamento obrigatório. Se usares uma superfície como apoio, verifica primeiro que é fixa, firme e que não desliza nem roda; não te apoies em objetos instáveis.

## Segurança do espaço

Usa uma zona plana, firme, seca, bem iluminada e sem tapetes soltos, cabos, objetos ou pessoas na área de movimento. Evita superfícies instáveis e condições de visibilidade reduzida.

## Limitações

1. As fontes técnicas descrevem versões semelhantes, mas variam na altura sugerida para o joelho e no contexto de utilização; por isso, o conteúdo usa apenas a amplitude confortável e controlável.
2. Não foi encontrada uma norma biomecânica primária dedicada exclusivamente à marcha no lugar para principiantes.
3. A orientação respiratória é de exercício geral: respiração natural e contínua, sem contagens nem retenções.
4. O conteúdo não determina elegibilidade individual e não substitui avaliação profissional quando existem sintomas, instabilidade marcada ou regresso após lesão ou cirurgia.
5. Não são definidos dose, intensidade, velocidade, cadência, progressão ou resultados esperados.

## Teste de compreensão

### 1. O objetivo é avançar pela divisão ou permanecer na mesma zona?

Resposta esperada: Permanecer na mesma zona, sem deslocamento global.

### 2. Os dois pés devem deixar o chão ao mesmo tempo?

Resposta esperada: Não. Pelo menos um pé permanece em contacto com o chão.

### 3. Até onde deves elevar o joelho?

Resposta esperada: Apenas até uma altura confortável que permita manter o controlo e o tronco estável.

### 4. Como deve regressar o pé ao chão?

Resposta esperada: De forma suave e controlada, perto do ponto de partida.

### 5. O que fazes se começares a perder o equilíbrio?

Resposta esperada: Reduzo a elevação, apoio os dois pés e termino se o controlo não regressar.

### 6. Que tipo de superfície é adequada?

Resposta esperada: Uma superfície firme, regular, seca e sem obstáculos.

### 7. É necessário equipamento?

Resposta esperada: Não. Pode usar-se uma superfície fixa como apoio de segurança quando necessário.

### 8. Como devem estar os ombros e as mãos?

Resposta esperada: Relaxados, sem tensão excessiva.

### 9. Como deves respirar?

Resposta esperada: De forma natural e contínua, sem prender a respiração.

### 10. Que sinais exigem terminar imediatamente?

Resposta esperada: Desconforto no peito, falta de ar atípica, tontura, sensação de desmaio, confusão, dor nova ou perda de controlo.

### 11. O apoio fixo substitui sempre a supervisão?

Resposta esperada: Não. Instabilidade marcada ou incapacidade de alternar o apoio com controlo pode exigir supervisão.

### 12. Este conteúdo define quantas vezes ou durante quanto tempo executar?

Resposta esperada: Não. A dose pertence à prescrição e não é definida aqui.

## Fontes e limites da evidência

### Fonte 1: Recommendations for Adults

- Autor ou entidade: American Heart Association
- Tipo: orientação de organização profissional
- Localizador: https://www.heart.org/en/healthy-living/exercise-and-physical-activity/fitness-basics/aha-recs-for-physical-activity-in-adults
- Usada para: Contextualização geral de atividade aeróbia.
- Limite: Não fornece instruções técnicas específicas para marcha no lugar e não foi usada para dose.

### Fonte 2: Foundations of Group Exercise

- Autor ou entidade: YMCA
- Tipo: manual profissional
- Localizador: https://contentcdn.eacefitness.com/continuingeducation/courses/support_items/CERT-YMCA-FGE/YMCA_Group_Cert_Workbook.pdf
- Usada para: Reconhece a marcha como bloco simples de exercício de grupo.
- Limite: Suporte ao nível da família; não determina elegibilidade nem prescrição.

### Fonte 3: Physical Activity Guidelines for Americans, 2nd edition

- Autor ou entidade: U.S. Department of Health and Human Services
- Tipo: orientação governamental
- Localizador: https://health.gov/sites/default/files/2019-09/Physical_Activity_Guidelines_2nd_edition.pdf
- Usada para: Enquadramento geral da atividade aeróbia e da necessidade de adaptação.
- Limite: Não descreve a execução específica; recomendações de volume não foram transportadas.

### Fonte 4: How to warm up before exercising

- Autor ou entidade: NHS
- Tipo: orientação profissional oficial
- Localizador: https://www.nhs.uk/live-well/exercise/how-to-warm-up-before-exercising/
- Usada para: Marcha no lugar, coordenação dos braços com os passos, cotovelos dobrados e mãos descontraídas.
- Limite: A página enquadra a marcha num aquecimento e inclui dose, que não foi transportada.

### Fonte 5: Standing Exercises

- Autor ou entidade: North Tees and Hartlepool NHS Foundation Trust
- Tipo: instrução clínica profissional
- Localizador: https://www.nth.nhs.uk/resources/standing-exercises/
- Usada para: Posição de pé, elevação alternada dos joelhos, regresso do pé ao chão e uso de superfície de apoio.
- Limite: A página inclui progressões e dose, que foram excluídas.

### Fonte 6: Standing Exercises

- Autor ou entidade: University Hospitals Sussex NHS Foundation Trust
- Tipo: instrução clínica profissional
- Localizador: https://www.uhsussex.nhs.uk/resources/standing-exercises/
- Usada para: Uso de apoio estável, elevação do joelho até uma amplitude confortável, descida controlada e alternância das pernas.
- Limite: Material clínico geral; não define uma técnica universal para todas as pessoas.

### Fonte 7: OTAGO Strength and Balance

- Autor ou entidade: Oxford University Hospitals NHS Foundation Trust
- Tipo: manual clínico profissional
- Localizador: https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf
- Usada para: Respiração normal durante o exercício e interrupção perante dor persistente; inclui a marcha como preparação para outros exercícios.
- Limite: Destina-se a um programa específico e contém dose, que não foi transportada.

### Fonte 8: Home Exercise Programme Advanced

- Autor ou entidade: Calderdale and Huddersfield NHS Foundation Trust
- Tipo: folheto clínico de segurança
- Localizador: https://plr.cht.nhs.uk/download/909/Home%20Exercise%20Programme%20Advanced%20A4
- Usada para: Sustenta interrupção perante dor, falta de ar, tontura, mal-estar ou desconforto durante exercício.
- Limite: Os sinais foram usados como apoio geral de segurança, sem diagnóstico ou tratamento.
