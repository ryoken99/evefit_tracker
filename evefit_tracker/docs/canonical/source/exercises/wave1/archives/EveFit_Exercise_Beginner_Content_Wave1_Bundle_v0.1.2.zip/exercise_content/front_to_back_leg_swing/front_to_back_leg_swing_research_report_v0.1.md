# Relatório de investigação — `front_to_back_leg_swing`

**Agente:** EX-32  
**Objeto:** conteúdo de execução para principiante  
**Idioma:** português europeu  
**Implementação realizada: não**

## Resultado

Foi produzido conteúdo documental defensável para o **Balanço da perna à frente e atrás**, com estado `beginner_content_approved_with_limits`.

Foram preservados sem alteração:

- identidade canónica `front_to_back_leg_swing`;

- família `standing_dynamic_leg_swing`;

- capacidade principal `flexibility`;

- risco operacional `moderate`;

- ausência de equipamento obrigatório e apoio estável independente opcional;

- superfície estável e antiderrapante, espaço sagital livre e proibições ambientais;

- ausência de parceiro, observador e supervisão obrigatórios;

- três relações aprovadas e respetivos estados, papéis e limites.

Não foram criadas variantes, relações, aprovações de multimédia, doses, prescrições ou alegações de resultado.

## Perguntas de investigação

1. Como descrever a execução dinâmica sem a transformar em ressalto balístico?
2. Que apoio é defensável para um principiante?
3. Que postura do tronco e da pelve deve ser preservada?
4. Como limitar amplitude e impulso?
5. Que orientação respiratória é sustentada?
6. Que erros são diretamente documentados e quais decorrem da assinatura canónica?
7. Que sinais de segurança e critérios de interrupção devem permanecer?
8. A supervisão é obrigatória ou apenas acionada por contexto?

## Síntese dos achados

| Tema | Evidência encontrada | Decisão editorial |
|---|---|---|
| Execução dinâmica | O Marine Corps descreve uma oscilação sagital com mão em parede ou superfície estável e sem inclinação do peito. Kansas Health System descreve balanços à frente e atrás, com arcos pequenos que só aumentam conforme tolerado e sempre com controlo. | A perna move-se a partir da anca; peito e pelve ficam orientados; cada extremidade é travada. |
| Apoio | Zhou et al. colocaram o peso sobre uma perna e usaram o encosto de uma cadeira para equilíbrio. NIA recomenda cadeira robusta, parede ou pessoa próxima em tarefas de equilíbrio. | O apoio de mão é opcional, mas recomendado quando o equilíbrio o exige; tem de ser firme, imóvel e ficar fora da trajetória. |
| Amplitude | A fonte hospitalar recomenda começar com arcos pequenos e não ultrapassar o conforto. O registo canónico exige travagem ativa e exclui amplitude máxima como requisito. | A amplitude termina antes de inclinação do tronco, rotação pélvica, arqueamento lombar ou perda de travagem. |
| Impulso e diferença face ao balístico | Matsuo et al. distinguem alongamento dinâmico controlado de movimento balístico com maior velocidade, ressalto e menor controlo. | Não usar embalo crescente, ressalto ou tentativa de ganhar amplitude pela velocidade. |
| Respiração | A American Heart Association recomenda respirar regularmente durante aquecimento e exercício e evitar retenção. | Respiração natural, contínua e regular, sem sincronização obrigatória, contagens ou retenções. |
| Erros | A instrução oficial do Marine Corps identifica a inclinação do peito. Outros erros decorrem diretamente da identidade e dos riscos canónicos: impulso excessivo, compensação lombar, rotação pélvica e colisão. | Foram documentados seis erros, cada um com reconhecimento observável e correção não prescritiva. |
| Segurança | Kansas Health System enfatiza controlo e conforto; as fontes de equilíbrio sustentam apoio robusto. O registo canónico lista perda de equilíbrio, colisão e impulso como riscos principais. | Mantiveram-se superfície antiderrapante, trajetória livre, apoio seguro e todos os sinais canónicos de redução ou interrupção. |
| Supervisão | A identidade canónica indica `none`, sem parceiro ou observador. Os acionadores canónicos incluem historial relevante, sintomas, retorno funcional, amplitude extrema, assistência humana e primeira exposição complexa. | Não se tornou a supervisão obrigatória. Foi indicada orientação qualificada apenas perante os acionadores já aprovados. |

## Fontes avaliadas

### Fontes existentes no pacote

1. **Behm DG et al. (2016), revisão sistemática.**  
   [PubMed](https://pubmed.ncbi.nlm.nih.gov/26642915/)  
   Utilidade: enquadramento dos efeitos agudos do alongamento e cautela contra promessas de desempenho ou prevenção.  
   Limite: evidência de família, não instrução específica do balanço.

2. **Opplert J, Babault N. (2018), revisão.**  
   [PubMed](https://pubmed.ncbi.nlm.nih.gov/29063454/)  
   Utilidade: enquadramento do alongamento dinâmico controlado e da preparação.  
   Limite: não define por si só a técnica completa.

3. **Matsuo S et al. (2025), revisão sistemática e meta-análise.**  
   [PubMed](https://pubmed.ncbi.nlm.nih.gov/40469856/)  
   Utilidade: distinção operacional entre movimento dinâmico controlado e alongamento balístico com ressalto.  
   Limite: agrega vários exercícios e não valida execução individual.

4. **American Academy of Orthopaedic Surgeons — Hockey Injury Prevention.**  
   [OrthoInfo](https://www.orthoinfo.org/staying-healthy/hockey-injury-prevention/)  
   Utilidade: reconhece balanços de perna como alongamento dinâmico em preparação.  
   Limite: contexto desportivo e ausência de instrução detalhada; não foi usada para prometer prevenção.

### Pesquisa externa específica

5. **U.S. Marine Corps Training and Education Command — Sagittal Leg Swing (2017).**  
   [DVIDS](https://www.dvidshub.net/video/551823/sagittal-leg-swing)  
   Tipo: instrução técnica oficial e demonstração direta do exercício.  
   Achados relevantes: postura alta, mão numa parede ou superfície estável, balanço à frente e atrás, erro de inclinar o peito.  
   Decisão de adaptação: a fonte militar menciona amplitude elevada; o conteúdo para principiante reteve apenas a trajetória e o controlo postural, subordinando a amplitude à travagem e ao registo canónico.

6. **The University of Kansas Health System — Dynamic Stretching Exercises.**  
   [Kansas Health System](https://www.kansashealthsystem.com/news-room/blog/0001/01/dynamic-stretching-exercises)  
   Tipo: orientação profissional hospitalar.  
   Achados relevantes: apoio numa perna, balanço da outra à frente e atrás, arcos pequenos que aumentam apenas conforme tolerado, controlo e conforto.  
   Limite: orientação geral, sem medição biomecânica.

7. **Zhou WS, Lin JH, Chen SC, Chien KY. (2019). Effects of Dynamic Stretching with Different Loads on Hip Joint Range of Motion in the Elderly.**  
   [Journal of Sports Science and Medicine](https://www.jssm.org/researchjssm-18-52.xml.xml)  
   Tipo: estudo primário aleatorizado de medidas repetidas.  
   Achados relevantes: postura neutra de pé, peso centrado sobre a perna não mobilizada, mão no encosto de uma cadeira para equilíbrio e movimento dinâmico de flexão e extensão da anca.  
   Limites: amostra pequena de adultos mais velhos, protocolo laboratorial e condições com carga. Não foram transpostos dose, carga, resultados, recomendações de programa ou autorização para outras populações.

8. **National Institute on Aging — Three Types of Exercise Can Improve Your Health and Physical Ability.**  
   [NIA](https://www.nia.nih.gov/health/exercise-and-physical-activity/three-types-exercise-can-improve-your-health-and-physical)  
   Tipo: orientação oficial de saúde pública.  
   Achado relevante: cadeira robusta, parede ou pessoa próxima para apoio em tarefas de equilíbrio.  
   Limite: não é específica para o balanço sagital.

9. **American Heart Association — Getting Active to Control High Blood Pressure.**  
   [AHA](https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure)  
   Tipo: orientação profissional oficial, revista em 2025.  
   Achado relevante: respiração regular durante aquecimento e exercício, sem retenção.  
   Limite: indicação geral; não sustenta uma sincronização respiratória específica.

## Triangulação e independência

A cobertura não depende de uma única organização ou de uma única classe de evidência:

- uma entidade oficial de treino fornece execução específica e erro postural;

- um sistema hospitalar independente fornece controlo e gestão da amplitude;

- um estudo primário revisto por pares documenta apoio, organização corporal e oscilação da anca;

- uma entidade oficial de saúde pública sustenta apoio em tarefas de equilíbrio;

- uma organização profissional cardiovascular sustenta respiração contínua;

- revisões científicas delimitam a família dinâmica e a diferença face ao balístico.

Esta convergência sustenta confiança global **moderada**, com confiança moderada-alta apenas para execução e apoio.

## Decisões técnicas

### Identidade

Foi preservada a definição: oscilação sagital ativa de uma perna entre flexão e extensão da anca, com tronco orientado, apoio principal na outra perna e travagem ativa. Não foi introduzido movimento lateral, carga externa, ressalto ou assistência humana.

### Apoio e equipamento

Não existe equipamento obrigatório. O apoio estável independente permanece opcional. Foi descrito como contacto de mão para equilíbrio, nunca como força externa aplicada à perna.

### Amplitude e impulso

Não foi definida amplitude individual. O critério é observável: o arco termina antes de desaparecer a travagem ou surgirem inclinação do tronco, rotação pélvica, compensação lombar ou aproximação perigosa a obstáculos. Isto preserva a identidade não balística.

### Respiração

Não foi encontrada evidência que justifique associar inspiração ou expiração a uma fase específica. A orientação final é natural e contínua, sem retenção.

### Erros

O erro de inclinação do peito tem apoio direto na fonte oficial do Marine Corps. Impulso crescente, arqueamento lombar, rotação pélvica, desvio do plano e apoio ou espaço inadequados são inferências biomecânicas e operacionais ancoradas na identidade, mecânica e risco canónicos. Não foram apresentados como diagnósticos.

### Supervisão

O requisito geral permanece `none`, `spotter_required: false`. Os acionadores de orientação qualificada foram copiados semanticamente do registo aprovado; não se criou uma obrigação universal.

## Auditoria de conformidade

| Requisito | Resultado |
|---|---|
| Português europeu e UTF-8 | Cumprido |
| Identidade preservada | Cumprido |
| Risco moderado preservado | Cumprido |
| Equipamento e superfície preservados | Cumprido |
| Relações preservadas | Cumprido |
| Execução com pelo menos cinco passos | Cumprido: sete passos |
| Pelo menos quatro pistas | Cumprido: seis pistas |
| Pelo menos quatro erros com reconhecimento e correção | Cumprido: seis erros |
| Doze perguntas de compreensão | Cumprido |
| Respiração documentada | Cumprido: natural, contínua, sem retenção |
| Literatura primária | Cumprido: Zhou et al. (2019) |
| Pelo menos duas fontes independentes | Cumprido |
| Sem dose ou prescrição | Cumprido |
| Sem promessa, diagnóstico ou tratamento | Cumprido |
| Sem código ou publicação | Cumprido |
| Multimédia não aprovada | Cumprido |

## Limitações

- A evidência direta sobre esta identidade é limitada.

- O estudo primário mais próximo incluiu poucos participantes mais velhos e um protocolo laboratorial.

- As revisões sustentam a família de alongamento dinâmico, não um resultado individual deste exercício.

- A instrução militar e a orientação hospitalar provêm de contextos diferentes do produto e foram usadas apenas para elementos técnicos convergentes.

- Não existe base para impor sincronização respiratória, amplitude máxima, velocidade, cadência, dose ou progressão.

- O conteúdo não substitui avaliação individual perante sintomas, historial de lesão ou cirurgia, doença crónica relevante ou retorno funcional.

## Conclusão

O conteúdo final descreve execução dinâmica controlada, apoio opcional seguro, respiração contínua, amplitude autolimitada pela travagem, erros observáveis, saída controlada e critérios de interrupção. A cobertura é suficiente para aprovação de conteúdo de principiante **com limites**, sem alterar o registo canónico nem ultrapassar a fronteira documental.
