# Relatório de investigação — Observação das sensações respiratórias

## Identificação

- **Agente:** EX-46
- **Exercício:** `respiratory_sensation_observation`
- **Nome:** Observação das sensações respiratórias
- **Tipo canónico:** `technique_drill`
- **Risco operacional preservado:** baixo
- **Data da consulta externa:** 24 de julho de 2026

## Objetivo da investigação

Fundamentar conteúdo introdutório para uma tarefa delimitada de observação interoceptiva da respiração. A investigação procurou esclarecer:

- como preparar uma posição estável e segura;
- como orientar a atenção para sensações respiratórias sem impor um padrão;
- que locais e aspetos do ciclo podem ser observados;
- como lidar com distração, ausência de sensação nítida e desconforto;
- que erros descaracterizam a tarefa;
- quando terminar e quando procurar apoio qualificado;
- quais são os limites da evidência.

O âmbito foi mantido estritamente observacional. Não foram criadas novas relações, alterações de identidade, alterações de equipamento, alterações de risco ou regras individuais.

## Método

Foi analisado exclusivamente o pacote EX-46 fornecido para este exercício. A pesquisa externa usou:

- estudos primários indexados em PubMed sobre atenção e acuidade interoceptiva respiratória;
- materiais clínicos e profissionais oficiais do NHS sobre observação da respiração;
- informação oficial do NCCIH sobre segurança de práticas de atenção plena;
- orientação oficial do NHS sobre sinais respiratórios e torácicos que justificam ajuda.

As fontes foram usadas apenas para sustentar execução geral, escolha, limites e segurança. Resultados de estudos de neuroimagem, medição ou programas amplos não foram extrapolados para efeitos individuais deste drill.

## Fontes consultadas e uso

| Fonte | Tipo | Contributo válido | Limite aplicado |
|---|---|---|---|
| Farb, Zuo & Price, 2023, [PubMed](https://pubmed.ncbi.nlm.nih.gov/37316296/) | Estudo primário | Distingue atenção ao próprio ciclo respiratório de atenção a um estímulo externo; inclui observação passiva e acompanhamento ativo de inspiração e expiração | Amostra pequena de adultos saudáveis em neuroimagem; não estabelece resultados para principiantes |
| Daubenmier et al., 2013, [PubMed](https://pubmed.ncbi.nlm.nih.gov/23692525/) | Estudo primário | Mostra que a perceção respiratória pode ser investigada como capacidade própria | A tarefa de investigação mede desempenho e inclui meditadores experientes; não deve ser convertida num teste informal |
| Torbay and South Devon NHS Foundation Trust, [Mindfulness of breathing: instructions](https://www.torbayandsouthdevon.nhs.uk/uploads/mindfulness-of-breath-instructions.pdf) | Orientação clínica profissional oficial | Posição confortável, olhos opcionais, foco nas narinas ou no abdómen e observação sem alterar a respiração | Material de mindfulness mais amplo; só foram retidos elementos compatíveis com a identidade |
| Guy's and St Thomas' NHS Foundation Trust, [MBSR exercises](https://www.guysandstthomas.nhs.uk/health-information/mindfulness-based-stress-reduction-mbsr/mbsr-exercises) | Orientação clínica profissional oficial | Observar o corpo a respirar sem controlar, reconhecer início e fim das fases, aceitar ausência de sensação e escolher onde colocar a atenção | A página contém práticas corporais mais amplas; o conteúdo produzido não se tornou uma exploração do corpo inteiro |
| NHS, [Mindfulness](https://www.nhs.uk/mental-health/self-help/tips-and-support/mindfulness/) | Orientação de saúde oficial | Atenção às sensações respiratórias, regresso após distração e reconhecimento de que a prática pode fazer algumas pessoas sentirem-se pior | Informação geral, não específica do exercício |
| NCCIH, [Meditation and Mindfulness: Effectiveness and Safety](https://www.nccih.nih.gov/health/meditation-and-mindfulness-effectiveness-and-safety) | Síntese oficial de segurança | Recomenda prudência: há poucos estudos de efeitos indesejados e foram relatadas experiências negativas, incluindo ansiedade | Abrange práticas heterogéneas; não quantifica o risco específico deste drill |
| NHS, [Shortness of breath](https://www.nhs.uk/symptoms/shortness-of-breath/) | Orientação clínica oficial de segurança | Dificuldade respiratória grave, aperto ou peso no peito e confusão súbita justificam ajuda imediata | Não permite inferir a causa de uma sensação |
| NHS, [Chest pain](https://www.nhs.uk/symptoms/chest-pain/) | Orientação clínica oficial de segurança | Dor torácica súbita ou persistente e sinais associados justificam ajuda imediata | Não permite inferir a causa da dor |
| CAN-01 e CAN-03, resumos incluídos no pacote EX-46 | Fontes canónicas internas | Preservação de identidade, fronteiras, ambiente, equipamento, risco e elegibilidade | Não foram consultados ficheiros externos ao pacote atribuído |

## Síntese dos achados

### 1. A ação nuclear é observar, não modificar

As orientações dos dois serviços NHS convergem numa instrução essencial: levar a atenção às sensações da respiração e deixar o ciclo acontecer sem o controlar. O estudo de Farb et al. distingue ainda a atenção ao próprio ciclo de uma condição em que a respiração é sincronizada com um estímulo externo.

Consequência para o conteúdo:

- a respiração é descrita como espontânea e contínua;
- não se impõe profundidade, velocidade, via do ar ou pausa;
- qualquer tentativa de fabricar um padrão é tratada como erro;
- não se usa um estímulo externo para conduzir o ciclo.

### 2. O foco pode ser simples e localizado

As fontes profissionais mencionam sensações nas narinas, no peito e no abdómen. Estas opções coincidem com a necessidade canónica de observar localização e excursão toracoabdominal percebida.

Consequência para o conteúdo:

- o principiante escolhe um único local fácil de notar;
- não é necessário sentir todas as zonas;
- não existe um local universalmente correto;
- «não noto claramente» é aceite como descrição válida.

### 3. Fase, ritmo percebido e esforço percebido são descritores, não resultados

O estudo de Farb et al. operacionaliza atenção à inspiração e à expiração, mas também mostra que a própria tarefa pode coincidir com alterações espontâneas da respiração. Por isso, observar pode influenciar o ciclo, mesmo quando a instrução não pede mudança.

Consequência para o conteúdo:

- a pessoa nota entrada, transição e saída do ar;
- ritmo e esforço são apresentados como perceções atuais;
- nenhuma diferença observada é classificada como êxito ou falha;
- não se transforma a tarefa num valor de desempenho.

### 4. A distração é compatível com a tarefa

Os materiais NHS indicam que a atenção pode afastar-se e regressar ao objeto escolhido sem crítica.

Consequência para o conteúdo:

- afastar-se do foco não é descrito como execução falhada;
- o regresso é simples, gentil e limitado ao sinal respiratório escolhido;
- o conteúdo não exige concentração perfeita.

### 5. A escolha de manter ou retirar a atenção é uma salvaguarda

As orientações clínicas profissionais permitem olhos abertos, escolha do foco e movimento quando a experiência se torna demasiado intensa. O NHS informa também que práticas de atenção plena não ajudam todas as pessoas e podem fazê-las sentir-se pior. O NCCIH refere incerteza na base de segurança e experiências negativas relatadas.

Consequência para o conteúdo:

- os olhos fechados nunca são obrigatórios;
- mudar para atenção externa e terminar são opções válidas;
- sofrimento crescente não é algo a ultrapassar;
- história de sofrimento com foco interoceptivo, incapacidade de parar, desmaio prévio, restrições cardiovasculares ou respiratórias e sinais novos ou sem explicação acionam orientação qualificada.

### 6. Sinais de alarme exigem interrupção, não interpretação

As páginas de segurança do NHS sustentam ação prudente perante dificuldade respiratória grave, aperto ou peso no peito, dor torácica e confusão súbita. O registo canónico acrescenta tontura, sensação de desmaio, desmaio, formigueiro e pânico crescente.

Consequência para o conteúdo:

- estes sinais aparecem como razões para terminar;
- sinais graves, súbitos ou persistentes remetem para ajuda urgente adequada ao local;
- nenhuma causa é sugerida;
- o drill não é usado para decidir se um sinal é benigno.

## Tradução dos achados para a execução

Foi construída uma sequência com as seguintes funções:

1. confirmar estabilidade e possibilidade de saída;
2. selecionar um local respiratório percetível;
3. acompanhar entrada, transição e saída do ar;
4. descrever localização e movimento;
5. reconhecer ritmo e esforço percebidos sem os alterar;
6. regressar ao foco após distração;
7. terminar por escolha ou perante desconforto crescente.

A sequência não introduz parâmetros temporais, metas de desempenho ou progressão.

## Erros priorizados

Foram incluídos cinco erros, todos diretamente ligados à identidade e à segurança:

1. impor profundidade, lentidão ou regularidade;
2. transformar a observação numa medição numérica;
3. usar a sensação como prova sobre o estado de saúde;
4. alargar o foco a uma exploração corporal ampla;
5. insistir perante sinais de alarme ou sofrimento crescente.

Cada erro inclui um sinal observável para o principiante e uma correção que recupera a identidade ou termina a tarefa.

## Preservação do registo canónico

| Elemento | Decisão no conteúdo |
|---|---|
| Identidade | Mantida como observação deliberada de localização, fase, ritmo percebido e esforço, sem padrão imposto |
| Tipo | Mantido como `technique_drill` |
| Família | Mantida como `respiratory_interoception_drills` |
| Relação aprovada | Mantida sem acrescentos |
| Equipamento | Nenhum obrigatório; cadeira estável e apoio para cabeça ou joelhos permanecem opcionais |
| Ambiente | Zona estável, firme, ventilada e sem obstáculos; exclusão de veículo em movimento, água, altura desprotegida e apoio instável |
| Risco | Mantido em baixo, sem o reduzir; ansiedade ou vigilância interna permanecem como fator principal |
| Supervisão | Nenhuma por defeito; gatilhos canónicos foram convertidos em orientação clara |
| Multimédia | Sem aprovação ou alteração |

## Confiança

**Global: moderada.**

- **Identidade e âmbito: alta.** Há concordância entre o registo canónico, o estudo primário de atenção respiratória e as orientações profissionais.
- **Execução para principiantes: moderada.** As instruções são sustentadas por fontes profissionais, mas não foram estudadas como este conteúdo autónomo exato.
- **Segurança: moderada.** Os sinais de alarme têm apoio oficial, mas a incidência de sofrimento específico desta tarefa não está estabelecida.

## Limitações

- Os estudos primários consultados investigam neuroimagem ou acuidade interoceptiva, não esta versão pública exata.
- Os materiais profissionais inserem a atenção respiratória em programas mais amplos.
- A evidência não define uma sensação «correta» para todas as pessoas.
- Observar a respiração pode coincidir com mudanças espontâneas do ciclo; isso não deve ser interpretado como resultado.
- O risco de desconforto ligado a foco interno varia entre pessoas e contextos.
- O conteúdo não decide elegibilidade individual nem substitui avaliação profissional perante restrições ou sinais preocupantes.

## Conclusão

O conteúdo final mantém a observação respiratória como uma tarefa descritiva, voluntária, delimitada e de baixo risco operacional. A respiração não é conduzida. A pessoa conserva escolha sobre posição, olhos, foco e fim da tarefa. Os sinais de alarme remetem para interrupção e ajuda adequada, nunca para uma conclusão sobre a causa.

**Implementação realizada: não**
