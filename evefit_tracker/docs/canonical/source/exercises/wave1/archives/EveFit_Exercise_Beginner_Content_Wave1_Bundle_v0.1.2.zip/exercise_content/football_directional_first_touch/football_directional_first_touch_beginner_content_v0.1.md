# Primeiro toque direcional no futebol

Conteúdo para principiantes em português europeu.

## Descrição curta

Receção de um passe e orientação da bola, no primeiro contacto, para uma direção definida antes da tentativa.

## O que é

O primeiro toque direcional é a ação de receber uma bola em movimento com o pé e, nesse mesmo contacto, encaminhá-la para uma zona-alvo previamente escolhida. Nesta versão fixa não há escolha entre várias respostas depois de o passe começar e não há oposição.

## O que vais fazer

Ficas de pé diante de um parceiro, confirmas uma única direção-alvo, ajustas a posição à trajetória de um passe rasteiro controlado e usas uma superfície do pé para amortecer e redirecionar a bola no primeiro contacto. Terminas equilibrado, com a bola alcançável na zona indicada.

## Porque existe este movimento

A tarefa existe para praticar a ligação entre preparar a receção, absorver parte da velocidade da bola e orientá-la para a ação seguinte. O objetivo imediato é técnico: controlar onde fica a bola após o primeiro contacto, sem prometer transferência automática para o jogo.

## Antes de começares

1. Confirma que tens uma bola de futebol, calçado adequado à superfície, um parceiro e uma zona-alvo visível.
2. Combina com o parceiro qual é a origem do passe e qual é a direção-alvo; nesta versão, ambas permanecem definidas antes da tentativa.
3. Combina um sinal simples para indicar que estás pronto e outro para parar.
4. Verifica que o parceiro consegue fornecer um passe rasteiro, controlado e previsível.
5. Liberta o corredor entre o parceiro, a tua posição e a zona para onde a bola será dirigida.
6. Se esta é a primeira exposição, garante observação próxima de uma pessoa competente.

## Preparar o equipamento

1. Usa uma bola de futebol em bom estado e adequada ao piso onde vais praticar.
2. Usa calçado desportivo com aderência apropriada à superfície.
3. Marca uma única zona-alvo com linhas já existentes ou marcadores de chão baixos, sem criar obstáculos salientes.
4. Coloca o parceiro de modo que o passe possa rolar pelo corredor livre até ti.
5. Não acrescentes balizas, adversários ou outro equipamento: não são necessários para esta identidade.

## Preparar o espaço

1. Escolhe uma superfície firme, nivelada e seca, ou relva curta em condições regulares.
2. Reserva espaço lateral para o pequeno ajuste do corpo e para a trajetória de saída da bola.
3. Mantém a linha do passe e a zona-alvo sem pessoas, bolas soltas, sacos, paredes próximas ou outros obstáculos.
4. Garante iluminação suficiente para veres a bola, o parceiro e o alvo durante toda a ação.
5. Não uses uma zona com trânsito ativo, piso escorregadio ou superfície irregular e perigosa.
6. Em pavilhão, confirma que a bola e o calçado são apropriados ao piso e que a bola não ressalta de forma inesperada.

## Verificação do corpo

1. Consegues estar de pé com apoio estável e dar um pequeno passo de ajuste sem perder o equilíbrio.
2. Consegues ver a bola a aproximar-se e identificar a zona-alvo antes do passe.
3. Consegues mover livremente tornozelo, joelho e anca para apresentar o pé à bola.
4. Não sentes dor aguda antes de começares.
5. Consegues comunicar claramente com o parceiro e usar o sinal combinado para parar.

## Posição inicial

Fica de pé, orientado para a origem do passe, com o corpo ligeiramente aberto para conseguires ver também a zona-alvo. Mantém os pés prontos para pequenos ajustes, os joelhos descontraídos e o peso distribuído de modo a poderes apoiar-te numa perna enquanto a outra recebe a bola.

## Confirmar a posição inicial

1. A bola, o parceiro e a zona-alvo estão visíveis.
2. A direção de saída foi escolhida antes do passe.
3. O corredor de receção e a trajetória de saída estão livres.
4. Os pés não estão cruzados e permitem um pequeno ajuste.
5. O pé de apoio pode ficar ao lado da trajetória sem bloquear a bola.
6. O parceiro recebeu o sinal de que estás pronto.

## Passos de execução

1. Olha para a zona-alvo e confirma a direção de saída antes de pedires o passe.
2. Dá ao parceiro o sinal combinado e acompanha visualmente a bola desde que sai do pé dele.
3. Faz um pequeno ajuste para te colocares na linha da bola, mantendo os pés descruzados e o corpo equilibrado.
4. Coloca o pé de apoio de forma estável ao lado da trajetória e abre o corpo para a direção-alvo.
5. Apresenta à bola uma superfície ampla e controlável do pé recetor, escolhida antes do contacto.
6. Quando a bola chega, acompanha ligeiramente o movimento para absorver parte da sua velocidade, sem prender a respiração.
7. No mesmo primeiro contacto, orienta a superfície do pé para encaminhar a bola para a zona-alvo; não a pares primeiro para só depois escolheres.
8. Recupera um apoio estável e confirma que a bola terminou alcançável e controlada na direção definida.

## Fases do movimento

### Preparação

Ver a origem do passe e a zona-alvo, comunicar com o parceiro e organizar o corpo para a direção já escolhida.

### Ajuste à trajetória

Acompanhar a bola e fazer pequenos ajustes dos pés para criar uma base de apoio estável.

### Receção e redireção

Apresentar o pé, amortecer a chegada e orientar a bola no mesmo primeiro contacto.

### Controlo final

Reorganizar os apoios e verificar se a bola ficou controlada e alcançável na zona prevista.

## Respiração

Respira de forma natural e contínua. Podes deixar sair o ar espontaneamente durante o contacto, mas não imponhas contagens nem retenhas a respiração. As fontes técnicas consultadas não estabelecem um padrão respiratório específico para este gesto.

## Sensações esperadas

1. Apoio estável na perna que fica no chão.
2. Pequeno ajuste coordenado de tornozelo, joelho e anca.
3. Contacto breve e controlado do pé com a bola.
4. Sensação de acompanhar e orientar a bola, em vez de lhe dar uma pancada rígida.
5. Bola suficientemente próxima para continuar a ação após o toque.

## Sensações inesperadas ou de alerta

1. Dor aguda no pé, tornozelo, joelho, anca ou noutra região.
2. Sensação de que o tornozelo ou o joelho cede durante o apoio.
3. Tonturas, alteração súbita da visão ou mal-estar.
4. Perda repetida do apoio ou incapacidade de parar a bola com segurança.
5. Qualquer colisão ou impacto inesperado com pessoa, parede ou equipamento.

## Indicações técnicas principais

1. Vê a bola e o alvo antes do passe.
2. Abre o corpo para a direção já escolhida.
3. Ajusta os pés à linha da bola.
4. Amortece e orienta no mesmo contacto.
5. Respira sem prender o ar.
6. Termina equilibrado, com a bola alcançável.
7. Como exemplo não universal, podes receber com a face interior do pé; mantém o tornozelo estável e orienta o toque para a zona livre.

## Erros comuns e correções

### Erro 1: Escolher a direção apenas depois de tocar na bola.

- Como reconhecer: A bola é primeiro parada ou fica presa sob o pé enquanto procuras o alvo.
- Como corrigir: Olha e aponta o corpo para uma única zona-alvo antes de o parceiro passar.

### Erro 2: Ficar parado com os pés rígidos enquanto a bola se aproxima.

- Como reconhecer: Tens de esticar demasiado a perna ou a bola passa fora da superfície do pé.
- Como corrigir: Mantém os pés disponíveis e faz um pequeno ajuste para entrar na linha da bola.

### Erro 3: Cruzar os pés ou colocar o apoio à frente da trajetória.

- Como reconhecer: O corpo oscila, o pé recetor fica sem espaço ou a bola bate na perna de apoio.
- Como corrigir: Descruza os pés e coloca o apoio estável ao lado da linha de chegada.

### Erro 4: Usar um contacto rígido que empurra a bola para longe.

- Como reconhecer: A bola sai da zona-alvo ou deixa de ficar alcançável.
- Como corrigir: Apresenta uma superfície ampla do pé e acompanha ligeiramente a chegada antes de orientar.

### Erro 5: Travar completamente a bola quando a tarefa é redirecioná-la.

- Como reconhecer: A bola fica imóvel junto ao pé, sem viajar para a zona marcada.
- Como corrigir: Inclina a superfície de contacto para o alvo e liga o amortecimento à saída da bola num só toque.

### Erro 6: Olhar apenas para os pés no momento da preparação.

- Como reconhecer: Perdes de vista o parceiro ou só procuras o alvo depois do contacto.
- Como corrigir: Antes do passe, alterna o olhar entre parceiro, bola e alvo; depois acompanha a bola até ao contacto.

## Formas de simplificar ou ensaiar

1. Usa uma zona-alvo ampla e claramente visível.
2. Mantém a origem, o tipo de passe e a direção-alvo constantes, sem oposição.
3. Pede ao parceiro que faça um passe rasteiro controlado e previsível.
4. Faz uma pausa completa entre tentativas para voltar a confirmar o corredor e o alvo.
5. Usa primeiro a superfície do pé com que consegues apresentar uma área de contacto mais estável.
6. Se o passe deixar de ser controlável, para e reorganiza a tarefa com supervisão em vez de improvisares outra resposta.

## Supervisão

A supervisão é recomendada. Na primeira exposição, uma pessoa competente deve confirmar a organização do espaço, demonstrar a orientação corporal e observar o apoio, o contacto e a posição final da bola. A supervisão volta a ser especialmente importante se a velocidade ou a trajetória do passe mudar de forma relevante, se o praticante for jovem, precisar de adaptação ou estiver em retorno funcional. O supervisor não substitui avaliação clínica quando esta for necessária.

## Como terminar

Deixa a bola parar numa zona segura, recupera uma posição estável sobre os dois pés e confirma com o parceiro que a tentativa terminou antes de alguém entrar no corredor ou recolher marcadores.

## Nota de segurança

Esta é uma tarefa de risco operacional baixo quando o passe é controlado, o corredor está livre e a superfície e o calçado são adequados. Para imediatamente perante dor aguda, entrada de alguém no corredor, colisão ou perda repetida do apoio.

## Quando parar ou reduzir

1. Dor aguda.
2. Entrada de uma pessoa ou de outra bola no corredor.
3. Perda repetida do apoio.
4. Passe que chega de forma não controlável para a tarefa combinada.
5. Superfície que se torna escorregadia, irregular ou mal iluminada.
6. Fadiga que altera visivelmente o apoio ou o controlo do primeiro toque.
7. Para perante este sinal de alerta: Dor aguda no pé, tornozelo, joelho, anca ou noutra região.
8. Para perante este sinal de alerta: Sensação de que o tornozelo ou o joelho cede durante o apoio.
9. Para perante este sinal de alerta: Tonturas, alteração súbita da visão ou mal-estar.
10. Para perante este sinal de alerta: Perda repetida do apoio ou incapacidade de parar a bola com segurança.
11. Para perante este sinal de alerta: Qualquer colisão ou impacto inesperado com pessoa, parede ou equipamento.
12. O parceiro interrompe imediatamente o envio; ninguém persegue a bola e a recolha só acontece depois de a pessoa e a trajetória estarem estáveis.

## Segurança do equipamento

Verifica se a bola está em bom estado e adequada à superfície. Usa calçado desportivo compatível com o piso e com aderência suficiente. Usa apenas marcadores de chão baixos e bem visíveis quando forem necessários. Retira bolas e equipamento não utilizados do corredor de receção. Não uses paredes ou objetos duros próximos como limite da zona-alvo.

## Segurança do espaço

Mantém o corredor de receção e a trajetória de saída livres. Usa uma superfície firme, nivelada, regular e sem zonas escorregadias. Garante espaço lateral para o ajuste do corpo e para a bola abrandar em segurança. Evita locais com trânsito ativo, obstáculos, cruzamento de outras tarefas ou iluminação insuficiente. Interrompe se as condições do piso, da luz ou da circulação de pessoas mudarem.

## Limitações

1. Implementação realizada: não. Conteúdo documental para uma versão fixa, cooperativa e sem oposição. Não contém dose, intensidade, progressão programada, diagnóstico, tratamento, autorização clínica ou promessa de resultado. A orientação respiratória é uma regra conservadora de não retenção, porque não foi encontrada orientação federativa específica para este gesto. A adequação individual, o uso em aquecimento e qualquer alteração relevante da velocidade, trajetória, escolha ou oposição exigem decisão fora deste conteúdo.

## Teste de compreensão

### 1. Quando deve ser escolhida a direção-alvo nesta versão fixa?

Resposta esperada: Antes de o parceiro iniciar o passe.

### 2. Que duas coisas deves conseguir ver na preparação, além da bola?

Resposta esperada: O parceiro e a zona-alvo.

### 3. Porque é útil manter os pés descruzados enquanto esperas?

Resposta esperada: Para poderes fazer um pequeno ajuste à trajetória e manter o equilíbrio.

### 4. O que deve acontecer no primeiro contacto?

Resposta esperada: Amortecer parte da chegada e orientar a bola para a direção-alvo no mesmo contacto.

### 5. Como sabes se o toque ficou demasiado forte?

Resposta esperada: A bola sai da zona prevista ou deixa de ficar alcançável.

### 6. Deves prender a respiração durante o contacto?

Resposta esperada: Não; deves respirar de forma natural e contínua.

### 7. Que tipo de passe deve o parceiro conseguir fornecer nesta versão para principiante?

Resposta esperada: Um passe rasteiro, controlado e previsível.

### 8. Que sinal exige interrupção imediata: contacto breve com a bola ou dor aguda?

Resposta esperada: Dor aguda.

### 9. O que fazes se outra pessoa entrar no corredor?

Resposta esperada: Paras a tentativa e só recomeças quando o corredor estiver livre.

### 10. Que superfícies não são adequadas?

Resposta esperada: Superfícies escorregadias, irregulares ou com obstáculos.

### 11. Quando é especialmente importante ter supervisão?

Resposta esperada: Na primeira exposição e quando a velocidade ou a trajetória do passe muda de forma relevante.

### 12. Adicionar um adversário mantém exatamente a mesma tarefa?

Resposta esperada: Não.

## Fontes e limites da evidência

### Fonte 1: Passing circuit: Receiving between the lines

- Autor ou entidade: FIFA Training Centre
- Tipo: sessão técnica oficial
- Localizador: https://www.fifatrainingcentre.com/en/practice/talent-coach-programme/build-and-progress/passing-circuit-receiving-between-the-lines.php
- Usada para: Contexto técnico de passe e receção.
- Limite: F1S01 — Passing circuit: Receiving between the lines — FIFA Training Centre — sessão técnica oficial — https://www.fifatrainingcentre.com/en/practice/talent-coach-programme/build-and-progress/passing-circuit-receiving-between-the-lines.php — Contexto técnico de passe e receção. — A sessão completa não define por si só a identidade deste exercício.

### Fonte 2: Midfielders receiving on the half-turn

- Autor ou entidade: FIFA Training Centre
- Tipo: sessão técnica oficial
- Localizador: https://www.fifatrainingcentre.com/en/practice/talent-coach-programme/build-and-progress/passing-circuit-midfielders-receiving-on-the-half-turn.php
- Usada para: Orientação corporal e preparação da receção.
- Limite: F1S02 — Midfielders receiving on the half-turn — FIFA Training Centre — sessão técnica oficial — https://www.fifatrainingcentre.com/en/practice/talent-coach-programme/build-and-progress/passing-circuit-midfielders-receiving-on-the-half-turn.php — Orientação corporal e preparação da receção. — Não prova decisão numa versão predeterminada.

### Fonte 3: John Peacock: Passing and receiving

- Autor ou entidade: FIFA Training Centre
- Tipo: sessão técnica oficial
- Localizador: https://www.fifatrainingcentre.com/en/practice/elite-sessions/in-possession/john-peacock-passing-and-receiving.php
- Usada para: Postura aberta, leitura do espaço, peso do passe e primeiro toque para o espaço.
- Limite: F2-S06 — John Peacock: Passing and receiving — FIFA Training Centre — sessão técnica oficial — https://www.fifatrainingcentre.com/en/practice/elite-sessions/in-possession/john-peacock-passing-and-receiving.php — Postura aberta, leitura do espaço, peso do passe e primeiro toque para o espaço. — Inclui tarefas de equipa e pressão que excedem esta versão fixa e cooperativa.

### Fonte 4: The Role of Variability in Motor Learning

- Autor ou entidade: Neural Networks / PubMed Central
- Tipo: revisão científica
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC6091866/
- Usada para: Limite entre prática fixa e introdução de variabilidade.
- Limite: F2-S26 — The Role of Variability in Motor Learning — Neural Networks / PubMed Central — revisão científica — https://pmc.ncbi.nlm.nih.gov/articles/PMC6091866/ — Limite entre prática fixa e introdução de variabilidade. — Não valida automaticamente manipulações específicas desta tarefa.

### Fonte 5: Directing the ball with the first touch

- Autor ou entidade: FIFA Training Centre
- Tipo: sessão técnica oficial
- Localizador: https://www.fifatrainingcentre.com/en/practice/elite-sessions/in-possession/directing-the-ball-with-the-first-touch.php
- Usada para: Orientação corporal, ajuste dos pés, comunicação da direção e controlo do primeiro contacto.
- Limite: EX44-R1 — Directing the ball with the first touch — FIFA Training Centre — sessão técnica oficial — https://www.fifatrainingcentre.com/en/practice/elite-sessions/in-possession/directing-the-ball-with-the-first-touch.php — Orientação corporal, ajuste dos pés, comunicação da direção e controlo do primeiro contacto. — A sessão inclui finalização, oposição e outras tarefas que não foram transpostas para esta identidade.

### Fonte 6: Top tips for receiving the ball

- Autor ou entidade: The Football Association
- Tipo: orientação oficial de treinadores
- Localizador: https://www.thefa.com/bootroom/resources/coaching/top-tips-for-receiving-the-ball
- Usada para: Planeamento antes da posse, forma corporal, encontro da trajetória e atenção aos colegas.
- Limite: EX44-R2 — Top tips for receiving the ball — The Football Association — orientação oficial de treinadores — https://www.thefa.com/bootroom/resources/coaching/top-tips-for-receiving-the-ball — Planeamento antes da posse, forma corporal, encontro da trajetória e atenção aos colegas. — Orientação geral de receção, não protocolo específico para principiantes absolutos.

### Fonte 7: How to coach players on receiving in football

- Autor ou entidade: England Football Learning
- Tipo: orientação oficial de treinadores
- Localizador: https://learn.englandfootball.com/articles-and-resources/coaching/resources/2022/how-to-coach-receiving-skills-in-football
- Usada para: Preparação, leitura prévia, comunicação e ligação entre dois jogadores.
- Limite: EX44-R3 — How to coach players on receiving in football — England Football Learning — orientação oficial de treinadores — https://learn.englandfootball.com/articles-and-resources/coaching/resources/2022/how-to-coach-receiving-skills-in-football — Preparação, leitura prévia, comunicação e ligação entre dois jogadores. — Aborda desenvolvimento amplo da receção e não prescreve a mecânica exata de um único toque.

### Fonte 8: Small team exercises

- Autor ou entidade: FIFA Training Centre
- Tipo: orientação oficial de futebol de base
- Localizador: https://www.fifatrainingcentre.com/en/practice/grassroots/4-to-8/small-team-exercises.php
- Usada para: Comunicação para receber e criação de um espaço seguro de prática.
- Limite: EX44-R4 — Small team exercises — FIFA Training Centre — orientação oficial de futebol de base — https://www.fifatrainingcentre.com/en/practice/grassroots/4-to-8/small-team-exercises.php — Comunicação para receber e criação de um espaço seguro de prática. — Destina-se a tarefas de grupo e não substitui a avaliação local de riscos.

### Fonte 9: A guide to risk management for grassroots football

- Autor ou entidade: The Football Association / Gloucestershire FA
- Tipo: guia oficial de gestão de risco
- Localizador: https://www.thefa.com/-/media/cfa/gloucestershirefa/files/leagues-and-clubs/club-management/ngis---a-guide-to-risk-management-for-grassroots-football.ashx?la=en
- Usada para: Necessidade de identificar perigos no equipamento e na atividade e de proporcionar condições tão seguras quanto possível.
- Limite: EX44-R5 — A guide to risk management for grassroots football — The Football Association / Gloucestershire FA — guia oficial de gestão de risco — https://www.thefa.com/-/media/cfa/gloucestershirefa/files/leagues-and-clubs/club-management/ngis---a-guide-to-risk-management-for-grassroots-football.ashx?la=en — Necessidade de identificar perigos no equipamento e na atividade e de proporcionar condições tão seguras quanto possível. — É orientação organizacional geral e não classifica o risco específico do exercício.
