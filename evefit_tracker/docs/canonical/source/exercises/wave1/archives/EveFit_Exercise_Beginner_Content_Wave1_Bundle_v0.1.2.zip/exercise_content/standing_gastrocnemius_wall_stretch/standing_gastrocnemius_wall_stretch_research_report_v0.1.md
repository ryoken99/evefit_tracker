# Relatório de investigação — `standing_gastrocnemius_wall_stretch`

**Agente:** EX-28  
**Exercício:** Alongamento dos gémeos à parede com joelho estendido  
Implementação realizada: não

## Âmbito

A investigação foi limitada à execução para principiantes, posição do joelho, contacto do calcanhar, orientação do pé, apoio na parede, respiração, sensações, segurança, erros frequentes e condições de supervisão.

Foram preservados sem alteração:

- identidade de exercício canónico;
- risco operacional baixo;
- ausência de equipamento portátil obrigatório;
- contacto das mãos com apoio vertical estável;
- apoio dos dois pés numa superfície firme e antiderrapante;
- joelho posterior estendido e calcanhar posterior apoiado;
- relações canónicas já aprovadas;
- estado pendente dos meios visuais.

## Estratégia de pesquisa

Foram priorizadas orientações de organizações de saúde e ortopedia, complementadas por literatura biomecânica primária. As fontes foram comparadas apenas quanto a elementos observáveis da execução e a princípios gerais de segurança.

## Síntese dos achados

### Execução e apoio

A American Academy of Orthopaedic Surgeons descreve uma passada de frente para a parede, com a perna posterior direita, o calcanhar no chão e avanço da bacia em direção à parede. Identifica ainda o arqueamento das costas como erro técnico.

O National Health Service apresenta a mesma organização nuclear: uma perna à frente, a perna posterior estendida, o calcanhar posterior no chão e utilização da parede como apoio quando necessário. Outra página de flexibilidade do NHS especifica as mãos contra a parede para estabilidade.

Esta convergência sustenta a sequência pública: verificar apoio e piso, organizar a passada, estender o joelho posterior, manter o calcanhar, avançar gradualmente e sair com controlo.

### Joelho posterior estendido

Baumbach et al. avaliaram dorsiflexão do tornozelo em adultos assintomáticos com várias posições do joelho. A dorsiflexão diferiu materialmente entre extensão completa e flexão do joelho; no protocolo em carga, os participantes ficaram em passada e puderam apoiar-se na parede para estabilização.

O resultado sustenta a distinção mecânica usada no conteúdo: manter o joelho posterior estendido é essencial para esta identidade. Fleti-lo altera a influência biarticular do gastrocnémio e aproxima a configuração da versão com predominância do sóleo.

### Orientação do pé

As fontes profissionais não são totalmente uniformes no detalhe da orientação dos dedos. A AAOS refere ligeira orientação para dentro, enquanto páginas do NHS usam uma orientação para a frente. Johanson et al. investigaram a posição subtalar durante o alongamento do gastrocnémio e não estabeleceram uma única posição pública universalmente superior.

Por isso, o conteúdo evita impor um ângulo rígido. A indicação adotada é manter o pé posterior numa orientação natural para a frente e impedir rotação excessiva, sem alterar o contacto do calcanhar e da planta do pé.

### Respiração

Harvard Health Publishing recomenda respirar confortavelmente durante alongamentos e não reter a respiração. Como nenhuma fonte específica deste exercício sustenta um padrão respiratório próprio, foi adotada respiração natural, confortável e contínua, sem contagens e sem usar a expiração para aumentar à força a amplitude.

### Segurança e sensações

A AAOS orienta a não ignorar dor durante o exercício e a procurar esclarecimento profissional quando a execução não é clara ou algo não parece correto. Harvard Health distingue tensão suave de dor e recomenda atenção ao alinhamento.

O conteúdo público usa uma fronteira conservadora: tensão suave e difusa na parte posterior da perna pode ser esperada; dor aguda ou crescente, dormência, formigueiro, fraqueza súbita, perda de controlo, instabilidade, mal-estar ou escorregamento exigem redução ou interrupção.

### Erros frequentes

Os erros foram selecionados por contrariar diretamente a identidade ou as condições operacionais:

1. levantar o calcanhar posterior;
2. fletir o joelho posterior;
3. rodar excessivamente o pé posterior;
4. arquear a zona lombar;
5. usar balanços ou pressão excessiva;
6. usar parede ou piso inseguros.

Cada erro recebeu um sinal observável e uma correção que preserva a mesma identidade. As simplificações reduzem apenas a amplitude ou facilitam a organização inicial.

### Supervisão

O registo canónico não exige acompanhante nem supervisão em condições habituais. A AAOS enquadra o seu programa numa situação de recuperação acompanhada por médico ou fisioterapeuta; esse contexto não foi generalizado a todos os utilizadores.

A orientação final mantém autonomia quando os pré-requisitos canónicos estão presentes. É indicada orientação profissional quando lesão ou cirurgia prévia, doença crónica relevante, gravidez ou pós-parto, deficiência, hipermobilidade, dificuldade de equilíbrio ou sintomas alteram a capacidade de executar e sair com controlo.

## Fontes avaliadas

| Código | Fonte | Tipo | Contributo usado | Limite |
|---|---|---|---|---|
| D1-EXT-11 / D2-S16 | [AAOS — Foot and Ankle Conditioning Program](https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/) | Guia profissional oficial | Passada, parede, joelho posterior estendido, calcanhar apoiado, avanço da bacia e alinhamento das costas | Contexto de condicionamento e recuperação |
| EX28-EXT-01 | [NHS — How to stretch after exercising](https://www.nhs.uk/live-well/exercise/how-to-stretch-after-exercising/) | Orientação oficial de saúde | Perna posterior estendida, calcanhar no chão e parede como apoio | Orientação geral |
| EX28-PRI-01 | [Baumbach et al. — The influence of knee position on ankle dorsiflexion](https://link.springer.com/article/10.1186/1471-2474-15-246) | Estudo biomecânico primário | Efeito da posição do joelho e estabilização na parede durante avaliação em passada | Amostra pequena de adultos assintomáticos |
| EX28-PRI-02 | [Johanson et al. — Subtalar joint position during gastrocnemius stretching](https://pubmed.ncbi.nlm.nih.gov/18345342/) | Estudo primário | Limite para alegações rígidas sobre uma orientação única do pé | Voluntários saudáveis; não estabelece instrução universal |
| EX28-PRO-02 | [Harvard Health Publishing — Six tips for safe stretches](https://www.health.harvard.edu/healthy-aging-and-longevity/six-tips-for-safe-stretches) | Orientação médica revista | Respiração contínua, tensão suave, dor e alinhamento | Não é específica deste exercício |

## Decisões editoriais

- Foi mantido o nome canónico e não foi criada variante.
- A parede foi tratada como característica obrigatória do local, não como equipamento portátil.
- Não foram introduzidos acessórios, parceiro ou acompanhante.
- A versão de joelho fletido foi apenas distinguida como exercício semelhante.
- A amplitude foi autorregulada por alinhamento, contacto do calcanhar, controlo e sensações.
- A linguagem não atribui resultados pessoais nem efeitos clínicos.
- Nenhum meio visual recebeu aprovação.

## Verificação contratual

- Português europeu e Unicode NFC.
- Estrutura JSON completa e ordenada conforme o contrato.
- Sete passos de execução.
- Seis indicações principais.
- Seis erros com reconhecimento e correção.
- Doze perguntas de compreensão.
- Respiração natural e contínua, sem retenção.
- Sem quantidades fixas, carga, ritmo, frequência ou planeamento.
- Sem alteração de identidade, risco, equipamento, ambiente ou relações.

## Confiança e limites

Confiança alta na identidade e na mecânica essencial, sustentadas por convergência entre fontes profissionais e por investigação primária. Confiança moderada na orientação respiratória e de supervisão por serem princípios gerais aplicados dentro dos limites canónicos.

O conteúdo não determina adequação individual. Os estudos citados não sustentam inferências sobre resultados pessoais, prevenção de lesões ou resposta clínica.
