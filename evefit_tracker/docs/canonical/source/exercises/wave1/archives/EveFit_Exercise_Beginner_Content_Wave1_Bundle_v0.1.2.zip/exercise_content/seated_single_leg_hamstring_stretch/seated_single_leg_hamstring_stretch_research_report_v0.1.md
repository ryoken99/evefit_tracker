# Relatório de investigação — `seated_single_leg_hamstring_stretch`

**Agente:** EX-31  
**Data de consulta:** 2026-07-24  
**Âmbito:** execução, inclinação da anca, respiração, segurança, sensação de alongamento, erros e supervisão  
**Implementação realizada: não**

## Resultado

O conteúdo para principiante é defensável com limites. A identidade, o risco operacional baixo, a ausência de equipamento obrigatório, o tapete opcional, a superfície estável e antiderrapante, a ausência de parceiro ou supervisão geral e as duas relações aprovadas foram preservados sem alteração.

A cobertura externa inclui duas fontes profissionais independentes e duas investigações primárias. A AAOS descreve diretamente a variante sentada unilateral: uma perna estendida, outra dobrada junto à face interna da coxa, inclinação a partir da anca e tornozelo descontraído. A ACE descreve a mecânica próxima em versão bilateral e sustenta alinhamento, expiração suave, inclinação pela anca, controlo lombar, movimento lento, ausência de ressalto e limite anterior à dor. A literatura primária apoia a importância da organização pélvica e mostra que posições de alongamento dos isquiotibiais também podem produzir respostas neurais.

Estado recomendado: `beginner_content_approved_with_limits`.

## Método

1. A identidade e as restrições foram extraídas exclusivamente do pacote de entrada atribuído ao EX-31.
2. Foram procuradas fontes oficiais ou profissionais com instruções observáveis para a variante ou para mecânica muito próxima.
3. Foram procurados estudos primários sobre posição pélvica e resposta neurodinâmica.
4. Cada conclusão foi limitada ao que a fonte permite; dose, promessas, diagnóstico, tratamento e autorização universal foram excluídos.
5. As instruções finais foram verificadas contra identidade, risco, equipamento, superfície, supervisão e relações canónicas.

## Fontes e utilização

### Fontes profissionais

1. **American Academy of Orthopaedic Surgeons, OrthoInfo — [Warm Up, Cool Down and Be Flexible](https://www.orthoinfo.org/en/staying-healthy/warm-up-cool-down-and-be-flexible/)**  
   Tipo: guia profissional oficial, com autoria e revisão clínica identificadas.  
   Aplicação: variante unilateral diretamente compatível; sustenta sentar, estender uma perna, dobrar a outra, inclinar a partir da anca e manter tornozelo e dedos descontraídos. A orientação geral apoia movimento lento, respiração e ausência de ressalto.  
   Limite adotado: não foram reproduzidas dose nem alegações de prevenção.

2. **American Council on Exercise — [Seated Toe Touches](https://www.acefitness.org/resources/everyone/exercise-library/213/seated-toe-touches/)**  
   Tipo: biblioteca profissional de exercício.  
   Aplicação: fonte independente para tronco inicialmente vertical, cabeça alinhada, expiração suave, inclinação a partir da anca, controlo da coluna, tensão sem dor e ausência de ressalto.  
   Limite adotado: a demonstração é bilateral; foi usada apenas para mecânica partilhada e não para redefinir a identidade unilateral.

3. **American Academy of Orthopaedic Surgeons, OrthoInfo — [Flexibility Exercises for Young Athletes](https://www.orthoinfo.org/en/staying-healthy/flexibility-exercises-for-young-athletes/)**  
   Tipo: guia profissional oficial e revisto por pares.  
   Aplicação: reforça movimento cuidadoso, velocidade não prioritária, ausência de ressalto e necessidade de orientação adequada perante lesão existente.  
   Limite adotado: a população etária e qualquer dose da página não foram transferidas.

### Literatura primária

4. **Sullivan MK, Dejulia JJ, Worrell TW — [Effect of pelvic position and stretching method on hamstring muscle flexibility](https://europepmc.org/article/MED/1470022). *Medicine & Science in Sports & Exercise*. 1992;24(12):1383–1389. PMID: 1470022.**  
   Desenho: comparação experimental de métodos de alongamento com posição pélvica anterior ou posterior.  
   Resultado relevante: a posição de inclinação pélvica anterior foi mais determinante para a alteração de flexibilidade observada do que a comparação entre os métodos testados.  
   Aplicação: sustenta a instrução de inclinar pela anca e evitar obter alcance apenas por flexão lombar.  
   Limite adotado: amostra pequena, protocolo diferente e ausência de validação do guião público exato; não suporta promessa de resultado.

5. **López-de-Celis C, Izquierdo-Nebreda P, González-Rueda V, et al. — [Short-Term Effects of Three Types of Hamstring Stretching on Length, Neurodynamic Response, and Perceived Sense of Effort: A Randomised Cross-Over Trial](https://pubmed.ncbi.nlm.nih.gov/36295102/). *Life*. 2022;12(10):1666. DOI: 10.3390/life12101666.**  
   Desenho: ensaio cruzado aleatorizado em participantes assintomáticos.  
   Resultado relevante: foram observadas respostas musculoesqueléticas e neurais, com maior proporção de resposta neural na condição com maior carga neurodinâmica e referência frequente à região posterior do joelho.  
   Aplicação: sustenta manter o tornozelo descontraído, não puxar agressivamente o pé e tratar formigueiro, dormência, ardor ou sensação elétrica como sinais de interrupção, não como objetivo.  
   Limite adotado: a investigação não permite diagnosticar a origem de sintomas numa pessoa nem transforma auto-observação em teste clínico.

### Fontes já registadas no pacote

- `D1-CAN-01`: especificação canónica interna; fronteira entre identidade, conteúdo e prescrição.
- `D1-CAN-03`: registo corretivo interno; preservação de identidade, risco, equipamento e relações.
- `D1-EXT-03`: Konrad et al., [revisão sistemática e meta-análise](https://pubmed.ncbi.nlm.nih.gov/37301370/); usada apenas como evidência de família.
- `D2-S19`: AAOS, *Flexibility Exercises for Young Athletes*.
- `D2-S20`: AAOS, *Warm Up, Cool Down and Be Flexible*.

## Matriz de cobertura

| Tema | Decisão documental | Base principal | Confiança |
|---|---|---|---|
| Execução | Sentado, uma perna estendida, outra dobrada, inclinação controlada sobre a perna-alvo | AAOS; ACE | Alta |
| Inclinação da anca | Movimento nasce na anca; evitar ganhar alcance por flexão lombar excessiva | AAOS; ACE; Sullivan et al. | Alta |
| Respiração | Expiração suave na entrada; respiração natural e contínua; sem retenção | ACE; AAOS | Moderada |
| Sensação esperada | Tensão muscular gradual e tolerável sobretudo atrás da coxa | AAOS; ACE | Moderada |
| Sintomas neurais | Formigueiro, dormência, ardor ou sensação elétrica exigem interrupção; não são alvo | López-de-Celis et al.; limites canónicos | Moderada |
| Joelho e tornozelo | Joelho estendido sem bloqueio agressivo; pé alinhado e descontraído | AAOS; limites canónicos | Alta |
| Erros | Flexão lombar excessiva, bloqueio agressivo do joelho, tração do pé, rotação, ressalto e apneia | ACE; AAOS; limites canónicos | Alta |
| Supervisão | Nenhuma na execução geral; orientação qualificada quando compreensão, historial, sintomas ou regresso funcional alteram a elegibilidade | Registo canónico; AAOS | Alta |
| Ambiente | Superfície estável e antiderrapante, sem trânsito ativo ou apoio instável | Registo canónico | Alta |

## Decisões editoriais

- Foi usada linguagem em segunda pessoa, clara para principiante absoluto e em português europeu.
- A entrada pela anca foi descrita como deslocação da bacia e do tronco em conjunto, uma instrução observável que evita jargão desnecessário.
- “Chegar ao pé” foi explicitamente retirado como objetivo, porque incentiva compensação lombar e tração externa sem fazer parte da identidade.
- O joelho foi descrito como estendido sem bloqueio agressivo, preservando a mecânica e o fator de risco posterior do joelho.
- O tornozelo foi descrito como descontraído para não acrescentar carga neural deliberada.
- A sensação aceitável ficou limitada a tensão muscular tolerável e localizada sobretudo na parte posterior da coxa.
- A linguagem sobre sintomas neurais é uma regra de interrupção, não um diagnóstico diferencial.
- A supervisão geral permaneceu `none`; foram apenas traduzidos os gatilhos de orientação já aprovados.

## Elementos deliberadamente não adotados

- Qualquer série, repetição, duração, retenção, frequência, ritmo, intensidade, carga ou progressão programada.
- Promessas de aumento de amplitude, prevenção de lesão, recuperação, correção postural, alívio de dor ou tratamento.
- Instruções para insistir perante dor ou aprofundar a posição através de outra pessoa, correia, peso ou tração sobre o pé.
- Testes destinados a distinguir de forma diagnóstica tensão muscular de envolvimento neural.
- Aprovação de multimédia, código, publicação ou nova relação.

## Preservação canónica

- `exercise_id`: `seated_single_leg_hamstring_stretch`
- Nome: Alongamento unilateral dos isquiotibiais sentado
- Tipo: `canonical_exercise`
- Família: `seated_hamstring_lengthening`
- `variant_of`: `none`
- `base_exercise_id`: `none`
- Risco: `low`
- Equipamento obrigatório: nenhum
- Equipamento opcional: `exercise_mat`
- Superfície: `stable_non_slip_surface`
- Superfícies inadequadas: `slippery_surface`, `unstable_surface`
- Parceiro: não
- Observador de segurança: não
- Supervisão geral: `none`

Relações preservadas:

1. `cooldown → flexibility → sustained_lengthening → release_perceived_tension`, condicional, `principal_candidate`.
2. `main_training → flexibility → sustained_lengthening → increase_passive_range_of_motion`, compatível, `alternative_primary`.

## Limitações e confiança

Confiança global: moderada-alta.

A identidade e a execução nuclear têm suporte direto e convergente. A respiração e a sensação esperada têm suporte profissional, mas não foram testadas como um guião autónomo para todas as populações. A literatura neural informa prudência, não diagnóstico. Não existem campos por resolver.

## Verificação contratual

- Português europeu e UTF-8 NFC: verificado.
- Passos de execução: 8.
- Pistas principais: 6.
- Erros comuns estruturados: 7.
- Perguntas de compreensão: 12.
- Dose ou tempo de retenção: ausentes.
- Prescrição, promessa, diagnóstico, tratamento, código e publicação: ausentes.
- Identidade, risco, equipamento, superfície, supervisão e relações: preservados.
