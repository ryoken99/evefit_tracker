# Relatório de investigação — `standing_soleus_wall_stretch`

## Identificação e âmbito

- **Agente:** EX-27
- **Exercício:** Alongamento do sóleo à parede com joelho fletido
- **ID canónico:** `standing_soleus_wall_stretch`
- **Tipo:** `canonical_exercise`
- **Risco operacional preservado:** baixo
- **Âmbito:** execução para principiante, joelho fletido, apoio na parede, respiração, segurança, erros, saída e supervisão
- **Fora do âmbito:** dose, tempo de retenção, prescrição, diagnóstico, tratamento, promessa de resultado, código, aprovação de multimédia ou publicação

Implementação realizada: não

## Método

Foi consultado exclusivamente o pacote de entrada EX-27 para o enquadramento interno. A pesquisa externa foi limitada a documentação oficial ou profissional e literatura primária. Foram procuradas fontes independentes que descrevessem diretamente a posição à parede com joelho fletido e calcanhar apoiado, além de evidência biomecânica sobre a influência da flexão do joelho na dorsiflexão.

As instruções de dose existentes nas fontes foram deliberadamente excluídas. Não foram criadas nem alteradas identidades, relações, níveis de risco, requisitos ambientais ou requisitos de equipamento.

## Fontes e extração

| Código | Fonte | Tipo | Informação aproveitada | Limite aplicado |
|---|---|---|---|---|
| `D1-EXT-11` | [AAOS — Foot and Ankle Conditioning Program](https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/) | Guia profissional oficial | De frente para uma parede; perna posterior com joelho fletido; calcanhares no chão; ancas centradas entre os pés | Não foi importada dose nem inferido resultado clínico |
| `EX27-EXT-01` | [Dynamic Health, Cambridgeshire and Peterborough NHS Foundation Trust — Foot or ankle pain](https://www.dynamichealth.nhs.uk/help-and-advice/foot-or-ankle-pain/) | Orientação profissional oficial | Passada; apoio externo; flexão da perna posterior; peso corporal a criar dorsiflexão sem levantar o calcanhar | O contexto de dor não foi usado para diagnóstico, tratamento ou elegibilidade |
| `EX27-EXT-02` | [Royal Berkshire NHS Foundation Trust — ACL injury: non-operative management](https://www.royalberkshire.nhs.uk/media/ycqhnrh4/anterior-cruciate-ligament-injury-non-operative-management_nov24.pdf) | Folheto profissional oficial | Calcanhar no chão; joelho alinhado com os dedos; evitar colapso medial do tornozelo; respirar suavemente | O contexto de reabilitação e a dose foram excluídos |
| `EX27-PRI-01` | [Baumbach et al. — The influence of knee position on ankle dorsiflexion](https://link.springer.com/article/10.1186/1471-2474-15-246) | Estudo biomecânico primário | A flexão do joelho altera a limitação da dorsiflexão atribuída ao gastrocnémio em medições com e sem carga | Amostra pequena de adultos assintomáticos; não é estudo de ensino, segurança, eficácia ou prescrição |

As três fontes profissionais são independentes entre si e convergem nos elementos essenciais. O estudo primário apoia a distinção biomecânica, mas não justifica afirmar isolamento absoluto do sóleo.

## Síntese por tema

### Execução e joelho fletido

A assinatura comum é uma passada com a perna a alongar atrás, joelho posterior fletido, calcanhar posterior apoiado e deslocação controlada do corpo. A AAOS explicita a posição de frente para a parede e as ancas centradas. O Dynamic Health NHS confirma o uso de apoio e a manutenção do calcanhar no piso. O Royal Berkshire NHS acrescenta alinhamento do joelho com os dedos e controlo do colapso medial.

O estudo de Baumbach et al. observou alteração da dorsiflexão quando o joelho passa da extensão para flexão em adultos assintomáticos. Isto sustenta a fronteira de identidade face ao `standing_gastrocnemius_wall_stretch`; não demonstra que apenas o sóleo recebe tensão.

### Apoio na parede e superfície

A parede é uma característica ambiental obrigatória, não equipamento portátil. O contacto das duas mãos melhora a referência e o controlo da posição. A segurança depende de apoio vertical fixo e superfície estável e antiderrapante. Piso molhado, tapete solto, desnível, zona de passagem ou apoio móvel contradizem o registo canónico.

### Respiração

O Royal Berkshire NHS instrui a manter respiração suave durante o alongamento do sóleo. A redação pública adotada é respiração natural, contínua e confortável, sem retenção. Não foram introduzidas contagens, sincronizações obrigatórias ou manobras respiratórias.

### Sensações e segurança

As fontes profissionais colocam a sensação esperada na parte posterior inferior da perna, podendo aproximar-se do tornozelo. O conteúdo distingue essa tensão gradual de dor aguda ou crescente, sintomas neurológicos, bloqueio articular, instabilidade e mal-estar. Os sinais de interrupção permanecem os do registo canónico e não constituem diagnóstico.

### Erros observáveis

Os erros foram derivados diretamente da assinatura mecânica e das indicações profissionais:

- levantar o calcanhar posterior;
- estender o joelho posterior e aproximar a execução do exercício sibling;
- deixar o joelho ou tornozelo colapsar medialmente;
- rodar o pé para obter amplitude;
- entrar com ressalto ou pressão excessiva na parede;
- arquear as costas ou descentrar as ancas.

Cada erro recebeu um sinal observável e uma correção que reduz a deslocação ou reorganiza o apoio, sem atribuir dose.

### Supervisão

Foi preservado `supervision_requirement: none` e `spotter_required: false`. O conteúdo não exige supervisão para a identidade base. Orientação profissional é indicada como consideração quando historial, sintomas, retorno funcional, hipermobilidade ou dificuldade de controlo alteram a elegibilidade. Supervisão não substitui a interrupção perante sinais de paragem.

## Decisões editoriais

1. Usar “joelho posterior fletido” em toda a instrução para proteger a identidade.
2. Manter “calcanhar posterior no chão” como cue e autocheck central.
3. Tratar a parede como apoio vertical estável obrigatório, sem a reclassificar como equipamento portátil.
4. Explicar o avanço do joelho na direção dos dedos, sem impor ângulo ou amplitude.
5. Usar respiração natural e contínua, sem retenção ou contagem.
6. Não usar linguagem de prevenção como promessa.
7. Não apresentar a sensação de alongamento como prova de isolamento muscular.
8. Preservar risco baixo e separar esse risco da elegibilidade individual.

## Identidade, relações e requisitos preservados

Não foi alterada a identidade `standing_soleus_wall_stretch`, a família `standing_calf_wall_stretch`, o sibling `standing_gastrocnemius_wall_stretch`, o risco operacional baixo, o requisito de superfície estável e antiderrapante ou o requisito de apoio vertical estável.

Foram preservadas sem modificação:

- `standing_soleus_wall_stretch__main_training__flexibility__sustained_lengthening__maintain_tolerated_passive_range` — compatível;
- `standing_soleus_wall_stretch__prevention__flexibility__sustained_lengthening__maintain_functional_flexibility` — condicional.

A segunda relação mantém o limite explícito de não prometer prevenção e depende de elegibilidade, apoio e contexto adequados.

## Confiança e limitações

**Confiança na execução:** alta, pela convergência de três entidades profissionais independentes.

**Confiança na explicação biomecânica:** moderada a alta, porque existe literatura primária coerente, mas o estudo consultado é de medição e não de ensino deste exercício.

**Confiança na segurança e supervisão:** moderada, por assentarem em documentação profissional e no registo canónico, sem ensaio específico de conteúdo para principiantes.

O conjunto de fontes não demonstra dose ótima, retenção ótima, isolamento do sóleo, resultado individual, prevenção, tratamento ou elegibilidade universal. Não foi feita inferência clínica.

## Verificações de conformidade

- Português europeu e UTF-8 NFC.
- Identidade e risco preservados.
- Parede estável e superfície antiderrapante preservadas.
- Relações canónicas preservadas.
- Execução com mais de cinco passos.
- Mais de quatro cues.
- Mais de quatro erros com reconhecimento e correção.
- Doze perguntas de compreensão.
- Sem dose, tempo de retenção, prescrição ou progressão programada.
- Sem promessa, diagnóstico, tratamento, código ou publicação.
- Sem alteração ou aprovação de multimédia.
