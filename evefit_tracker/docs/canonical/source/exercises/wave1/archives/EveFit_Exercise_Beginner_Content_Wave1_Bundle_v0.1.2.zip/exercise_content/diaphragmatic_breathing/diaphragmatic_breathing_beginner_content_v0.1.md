# Respiração diafragmática

Conteúdo para principiantes em português europeu.

## Descrição curta

Respirar voluntariamente com expansão confortável da zona inferior do tronco, sem bloquear o movimento natural do tórax.

## O que é

A respiração diafragmática é um ciclo respiratório voluntário no qual a inspiração é acompanhada por uma expansão suave da zona inferior do tronco e a expiração decorre sem esforço excessivo. O tórax pode mover-se; o objetivo não é empurrar o abdómen para fora, encher ao máximo os pulmões ou cumprir um ritmo.

## O que vais fazer

Escolher uma posição estável, observar primeiro a respiração natural, usar o contacto leve das mãos como referência opcional e permitir que a parte inferior do tronco se expanda ao inspirar e recue ao expirar.

## Porque existe este movimento

Existe para praticar o controlo voluntário da movimento do diafragma ao longo de um ciclo respiratório. Não define uma dose, não promete um resultado e não substitui avaliação profissional de sintomas respiratórios.

## Antes de começares

1. Confirma que consegues iniciar, ajustar e interromper voluntariamente a tarefa.
2. Começa apenas se a tua respiração estiver estável no estado atual e a posição escolhida for confortável.
3. Escolhe entre deitado, sentado ou de pé, privilegiando a opção em que te sintas apoiado e seguro.
4. Afrouxa roupa ou acessórios que limitem de forma desconfortável a expansão do tronco.
5. Se tens doença cardiovascular ou respiratória, tendência para desmaiar, dificuldade respiratória atual, usas oxigénio ou tens indicação clínica específica, procura orientação da tua equipa de saúde antes de experimentar sem acompanhamento.

## Preparar o equipamento

1. Não é necessário equipamento. Se ajudar ao conforto, usa uma cadeira estável ou um apoio para a cabeça ou os joelhos; coloca qualquer apoio numa posição firme, sem rodas soltas, deslizamento ou risco de queda. As mãos podem servir de referência tátil, sem pressionar o tronco.

## Preparar o espaço

1. Escolhe um local com ar aceitável, superfície firme e estável e espaço livre à tua volta. Pode ser interior ou exterior abrigado. Não pratiques num veículo em movimento, em apoio instável, submerso ou junto de uma altura sem proteção.

## Verificação do corpo

1. Consigo respirar de forma confortável antes de começar.
2. Consigo manter a posição sem esforço postural desnecessário.
3. Não tenho dor torácica, tontura, sensação de desmaio, confusão, formigueiro ou falta de ar atípica ou crescente.
4. Consigo parar de imediato e regressar à respiração espontânea se algo não estiver bem.

## Posição inicial

Adota uma posição estável. Se estiveres deitado, apoia a cabeça e, se for confortável, os joelhos; se estiveres sentado, apoia os pés e deixa o tronco alto sem rigidez; se estiveres de pé, distribui o apoio de forma segura. Relaxa a mandíbula, o pescoço e os ombros. Opcionalmente, pousa uma mão na parte superior do peito e outra sobre a zona inferior do abdómen, sem fazer pressão.

## Confirmar a posição inicial

1. A base de apoio está firme e não desliza.
2. A cabeça, o pescoço, os ombros e a mandíbula estão confortáveis.
3. A roupa e os apoios não comprimem o tronco.
4. As mãos, se usadas, estão pousadas de forma leve.
5. Há espaço para interromper a tarefa em segurança.
6. A respiração inicial está confortável e sob controlo.

## Passos de execução

1. Mantém a posição estável e observa um ciclo da tua respiração espontânea, sem o tentar alterar.
2. Ao surgir a inspiração seguinte, deixa o ar entrar sem puxar, sorver ou encher ao máximo.
3. Permite que a zona inferior do tronco se expanda suavemente à frente, aos lados e atrás, conforme for natural para ti.
4. Deixa o tórax acompanhar a inspiração; não o prendas nem tentes mantê-lo completamente imóvel.
5. Deixa a expiração acontecer de forma confortável, permitindo que a zona inferior do tronco recue sem apertar ou empurrar com força.
6. Passa diretamente para a inspiração seguinte quando o corpo a iniciar, mantendo o fluxo contínuo e sem prender o ar entre fases.
7. Se perderes o conforto, o controlo ou a coordenação, deixa de orientar o ciclo e regressa à tua respiração espontânea.

## Fases do movimento

### Observação

Reconhecer a respiração espontânea e confirmar conforto antes de intervir.

### Inspiração

O diafragma desce e a zona inferior do tronco expande de forma suave e coordenada com algum movimento natural das costelas.

### Expiração

O diafragma relaxa, o ar sai e a zona inferior do tronco recua sem esforço abdominal excessivo.

### Retorno

O controlo voluntário é reduzido até a respiração espontânea voltar a ser confortável.

## Respiração

A própria respiração é a tarefa. Mantém-na natural, contínua e confortável: inspira sem procurar amplitude máxima, expira sem forçar e não prendas o ar. Não são impostas contagens, retenções, cadência, proporção entre fases nem via respiratória; usa uma via confortável e desobstruída.

## Sensações esperadas

1. Movimento suave da zona inferior do abdómen e das costelas baixas durante a inspiração.
2. Recuo natural dessa zona durante a expiração.
3. Algum movimento do tórax, sem necessidade de o imobilizar.
4. Trabalho respiratório confortável, sem pressão para conseguir uma respiração muito grande.

## Sensações inesperadas ou de alerta

1. Tontura, sensação de cabeça leve, formigueiro ou sensação de desmaio.
2. Falta de ar atípica, crescente ou que não melhora ao parar.
3. Dor ou pressão no peito.
4. Confusão, perda de controlo ou ansiedade que aumenta com a tarefa.
5. Necessidade de fazer força marcada no pescoço, nos ombros ou no abdómen para respirar.

## Indicações técnicas principais

1. Deixa o ar entrar; não o puxes nem procures encher ao máximo.
2. Sente a zona inferior do tronco expandir de forma suave e ampla.
3. Mantém pescoço, mandíbula e ombros soltos.
4. Permite que as costelas e o tórax também se movam.
5. Expira sem apertar e passa para o ciclo seguinte sem prender o ar.
6. Escolhe sempre conforto e controlo em vez de amplitude.

## Erros comuns e correções

### Erro 1: Empurrar deliberadamente o abdómen para fora.

- Como reconhecer: A barriga projeta-se por contração ou esforço, mas o ar parece não entrar com fluidez e o tronco fica tenso.
- Como corrigir: Reduz o esforço, pousa a mão de forma leve e deixa a expansão surgir como consequência da inspiração.

### Erro 2: Tentar imobilizar completamente o tórax.

- Como reconhecer: Fazes força para impedir qualquer movimento das costelas ou sentes o ciclo dividido entre peito e abdómen.
- Como corrigir: Permite movimento natural do tórax e procura uma expansão coordenada, com maior atenção à zona inferior do tronco.

### Erro 3: Inspirar demasiado fundo ou depressa.

- Como reconhecer: Surge tensão, necessidade de suspirar, tontura, formigueiro ou sensação de cabeça leve.
- Como corrigir: Interrompe o controlo, regressa à respiração espontânea e, se retomares com conforto, usa menor amplitude sem impor ritmo.

### Erro 4: Prender o ar entre a inspiração e a expiração.

- Como reconhecer: Há uma pausa voluntária, fecho da garganta ou acumulação de tensão antes de o ar voltar a fluir.
- Como corrigir: Deixa a transição acontecer sem retenção e sem contar.

### Erro 5: Elevar os ombros ou contrair o pescoço para inspirar.

- Como reconhecer: Os ombros sobem visivelmente e o pescoço fica rígido a cada inspiração.
- Como corrigir: Reduz a amplitude, volta a apoiar o corpo e deixa ombros e mandíbula relaxarem antes de continuar.

## Formas de simplificar ou ensaiar

1. Experimenta uma posição deitada ou sentada bem apoiada se estar de pé desviar a atenção para o equilíbrio.
2. Usa apenas uma mão sobre a zona inferior do abdómen se duas mãos forem desconfortáveis.
3. Observa primeiro a respiração espontânea e introduz apenas uma expansão ligeiramente mais percetível, sem aprofundar à força.
4. Mantém os olhos abertos e fixa um ponto confortável se fechar os olhos causar insegurança.
5. Se coordenar a tarefa for difícil, interrompe e pede demonstração a um profissional qualificado, sem tentar compensar com maior esforço.

## Supervisão

Não é necessário observador ou parceiro numa situação geral de baixo risco, desde que a pessoa compreenda a instrução, esteja estável e consiga parar ou ajustar sozinha. Procura supervisão de um profissional de saúde qualificado se houver doença cardiovascular ou respiratória relevante, tendência para desmaiar, uso de oxigénio, regresso à função num contexto clínico, sintomas novos ou inexplicados, ou incapacidade para interromper e ajustar a tarefa de forma independente.

## Como terminar

Deixa de orientar deliberadamente o ciclo, mantém a posição estável e permite que a respiração espontânea retome um padrão confortável. Retira as mãos, muda de posição devagar se estiveres deitado ou sentado e confirma que não há tontura, falta de ar atípica, dor no peito, formigueiro, confusão ou sensação de desmaio antes de prosseguir com outra atividade.

## Nota de segurança

Este é um exercício de baixo risco quando realizado numa posição segura e com respiração estável, mas forçar a profundidade ou respirar em excesso pode causar desconforto e sinais compatíveis com hiperventilação. Interrompe perante sinais de alarme. A técnica não substitui avaliação de dificuldade respiratória ou de outros sintomas.

## Quando parar ou reduzir

1. Desconforto leve, tensão crescente ou perda de coordenação. — Reduz imediatamente o controlo e a amplitude; se não normalizar, termina e regressa à respiração espontânea.
2. Tontura, formigueiro, sensação de cabeça leve, pré-síncope ou síncope. — Interrompe. Mantém-te numa posição segura e procura ajuda apropriada se o sinal for intenso, persistente ou envolver perda de consciência.
3. Falta de ar atípica, nova, crescente ou persistente. — Interrompe e procura avaliação profissional; se for súbita, intensa ou acompanhada por dor ou pressão no peito, trata-a como situação urgente.
4. Dor ou pressão no peito, confusão ou perda de controlo. — Interrompe e procura ajuda urgente apropriada.

## Segurança do equipamento

Não há equipamento obrigatório. Uma cadeira ou apoio opcional deve estar firme, estável e colocado de modo a não deslizar nem dificultar a saída. Não coloques peso sobre o abdómen e não uses objetos para obrigar o tronco a mover-se.

## Segurança do espaço

Usa uma área segura, ventilada, com apoio firme e sem obstáculos imediatos. Evita ar de má qualidade, veículos em movimento, superfícies instáveis, ambiente submerso e alturas sem proteção. Se estiveres ao ar livre, escolhe um local abrigado onde possas parar e sentar-te em segurança.

## Limitações

1. O conteúdo não avalia elegibilidade individual nem sintomas.
2. Não determina se uma via respiratória, posição ou amplitude é a melhor para uma pessoa específica.
3. A literatura usa definições e instruções de respiração diafragmática que não são totalmente uniformes.
4. Uma parte relevante da investigação é clínica ou usa amostras pequenas; não se inferem resultados universais.
5. Implementação realizada: não

## Teste de compreensão

### 1. Qual é o movimento principal a observar durante a inspiração?

Resposta esperada: Uma expansão suave da zona inferior do tronco, coordenada com o movimento natural do tórax.

### 2. O abdómen deve ser empurrado deliberadamente para fora?

Resposta esperada: Não. A expansão deve surgir como consequência da inspiração, sem empurrar ou contrair à força.

### 3. O tórax tem de ficar completamente imóvel?

Resposta esperada: Não. Pode mover-se naturalmente; a atenção está na expansão inferior do tronco.

### 4. É necessário inspirar até à amplitude máxima?

Resposta esperada: Não. A amplitude deve ser confortável e controlada.

### 5. É permitido prender o ar entre fases?

Resposta esperada: Não. O fluxo deve manter-se contínuo, sem retenções voluntárias.

### 6. Que posição pode um principiante escolher?

Resposta esperada: Deitado, sentado ou de pé, desde que a posição seja estável, segura e confortável.

### 7. Para que servem as mãos colocadas no tronco?

Resposta esperada: Servem apenas de referência tátil leve para notar o movimento, sem pressionar ou obrigar o tronco a expandir.

### 8. O que deves fazer se surgir tontura ou formigueiro?

Resposta esperada: Interromper o controlo voluntário, manter uma posição segura e regressar à respiração espontânea; procurar ajuda apropriada se o sinal for intenso ou persistente.

### 9. Que sinais exigem interrupção e ajuda urgente apropriada?

Resposta esperada: Dor ou pressão no peito, falta de ar súbita ou intensa, confusão, perda de controlo ou perda de consciência.

### 10. Quando é prudente procurar supervisão profissional antes ou durante a aprendizagem?

Resposta esperada: Perante doença cardiovascular ou respiratória relevante, uso de oxigénio, tendência para desmaiar, contexto clínico, sintomas novos ou incapacidade para ajustar e parar sozinho.

### 11. Que características deve ter o local?

Resposta esperada: Ar aceitável, apoio firme e estável, área livre de obstáculos e possibilidade de parar em segurança.

### 12. Como termina o exercício?

Resposta esperada: Reduzindo o controlo voluntário, deixando regressar a respiração espontânea confortável e verificando se não há sinais de alarme antes de mudar de posição.

## Fontes e limites da evidência

### Fonte 1: EveFit — Especificação Canónica de Classificação de Exercícios v0.1

- Autor ou entidade: EveFit
- Tipo: especificação canónica interna incluída no input autorizado
- Localizador: não aplicável
- Usada para: CAN-01 — EveFit — Especificação Canónica de Classificação de Exercícios v0.1 — EveFit — especificação canónica interna incluída no input autorizado — não aplicável — 2026-07-24 — Fronteira entre identidade, execução, risco, elegibilidade e prescrição.
- Limite: CAN-01 — EveFit — Especificação Canónica de Classificação de Exercícios v0.1 — EveFit — especificação canónica interna incluída no input autorizado — não aplicável — 2026-07-24 — Fronteira entre identidade, execução, risco, elegibilidade e prescrição.

### Fonte 2: Breathing and Health

- Autor ou entidade: U.S. Department of Veterans Affairs, Veterans Health Administration
- Tipo: material clínico-profissional oficial
- Localizador: https://www.va.gov/wholehealth/veteran-handouts/docs/BreathingAndHealth-508Final-9-4-2018.pdf
- Usada para: G2-S20 — Breathing and Health — U.S. Department of Veterans Affairs, Veterans Health Administration — material clínico-profissional oficial — https://www.va.gov/wholehealth/veteran-handouts/docs/BreathingAndHealth-508Final-9-4-2018.pdf — 2026-07-24 — Posições apoiadas, contacto das mãos, observação inicial, conforto e necessidade de apoio profissional perante dificuldade respiratória, oxigénio ou tontura fácil. — As sugestões de contagem e retenção presentes noutras secções da fonte não foram transpostas por estarem fora do âmbito deste conteúdo.
- Limite: G2-S20 — Breathing and Health — U.S. Department of Veterans Affairs, Veterans Health Administration — material clínico-profissional oficial — https://www.va.gov/wholehealth/veteran-handouts/docs/BreathingAndHealth-508Final-9-4-2018.pdf — 2026-07-24 — Posições apoiadas, contacto das mãos, observação inicial, conforto e necessidade de apoio profissional perante dificuldade respiratória, oxigénio ou tontura fácil. — As sugestões de contagem e retenção presentes noutras secções da fonte não foram transpostas por estarem fora do âmbito deste conteúdo.

### Fonte 3: How the Lungs Work: What Breathing Does for the Body

- Autor ou entidade: National Heart, Lung, and Blood Institute, National Institutes of Health
- Tipo: informação fisiológica oficial
- Localizador: https://www.nhlbi.nih.gov/health/lungs/breathing-benefits
- Usada para: NHLBI-2025 — How the Lungs Work: What Breathing Does for the Body — National Heart, Lung, and Blood Institute, National Institutes of Health — informação fisiológica oficial — https://www.nhlbi.nih.gov/health/lungs/breathing-benefits — 2026-07-24 — Mecânica da descida do diafragma e participação das costelas na inspiração; relaxamento na expiração.
- Limite: NHLBI-2025 — How the Lungs Work: What Breathing Does for the Body — National Heart, Lung, and Blood Institute, National Institutes of Health — informação fisiológica oficial — https://www.nhlbi.nih.gov/health/lungs/breathing-benefits — 2026-07-24 — Mecânica da descida do diafragma e participação das costelas na inspiração; relaxamento na expiração.

### Fonte 4: Breathing Exercises for Better Lung Health

- Autor ou entidade: American Lung Association
- Tipo: orientação profissional oficial
- Localizador: https://www.lung.org/lung-health-diseases/wellness/breathing-exercises
- Usada para: G2-S14 — Breathing Exercises for Better Lung Health — American Lung Association — orientação profissional oficial — https://www.lung.org/lung-health-diseases/wellness/breathing-exercises — 2026-07-24 — Posição confortável, referência tátil no abdómen, relaxamento do pescoço e ombros e necessidade de assistência quando a falta de ar persiste. — O conteúdo clínico dirigido a asma ou DPOC e as sugestões de duração não foram generalizados.
- Limite: G2-S14 — Breathing Exercises for Better Lung Health — American Lung Association — orientação profissional oficial — https://www.lung.org/lung-health-diseases/wellness/breathing-exercises — 2026-07-24 — Posição confortável, referência tátil no abdómen, relaxamento do pescoço e ombros e necessidade de assistência quando a falta de ar persiste. — O conteúdo clínico dirigido a asma ou DPOC e as sugestões de duração não foram generalizados.

### Fonte 5: Breathing exercises: influence on breathing patterns and thoracoabdominal motion in healthy subjects

- Autor ou entidade: Vieira DSR et al., Brazilian Journal of Physical Therapy
- Tipo: estudo primário transversal
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC4311599/
- Usada para: VIEIRA-2014 — Breathing exercises: influence on breathing patterns and thoracoabdominal motion in healthy subjects — Vieira DSR et al., Brazilian Journal of Physical Therapy — estudo primário transversal — https://pmc.ncbi.nlm.nih.gov/articles/PMC4311599/ — 10.1590/bjpt-rbf.2014.0048 — 2026-07-24 — Confirma maior contribuição abdominal durante a respiração diafragmática e informa a cautela contra uma instrução rígida que suprima o movimento torácico. — A amostra foi pequena, jovem e saudável; os participantes foram avaliados numa posição inclinada e com uma execução específica.
- Limite: VIEIRA-2014 — Breathing exercises: influence on breathing patterns and thoracoabdominal motion in healthy subjects — Vieira DSR et al., Brazilian Journal of Physical Therapy — estudo primário transversal — https://pmc.ncbi.nlm.nih.gov/articles/PMC4311599/ — 10.1590/bjpt-rbf.2014.0048 — 2026-07-24 — Confirma maior contribuição abdominal durante a respiração diafragmática e informa a cautela contra uma instrução rígida que suprima o movimento torácico. — A amostra foi pequena, jovem e saudável; os participantes foram avaliados numa posição inclinada e com uma execução específica.

### Fonte 6: Diaphragmatic breathing reduces efficiency of breathing in patients with chronic obstructive pulmonary disease

- Autor ou entidade: Gosselink RA et al., American Journal of Respiratory and Critical Care Medicine
- Tipo: estudo primário clínico
- Localizador: https://pubmed.ncbi.nlm.nih.gov/7697243/
- Usada para: GOSSELINK-1995 — Diaphragmatic breathing reduces efficiency of breathing in patients with chronic obstructive pulmonary disease — Gosselink RA et al., American Journal of Respiratory and Critical Care Medicine — estudo primário clínico — https://pubmed.ncbi.nlm.nih.gov/7697243/ — 10.1164/ajrccm.151.4.7697243 — 2026-07-24 — Sustenta não presumir benefício universal e recomendar enquadramento profissional em doença respiratória relevante. — A amostra clínica foi muito pequena e composta por pessoas com DPOC grave; os resultados não devem ser extrapolados para principiantes saudáveis.
- Limite: GOSSELINK-1995 — Diaphragmatic breathing reduces efficiency of breathing in patients with chronic obstructive pulmonary disease — Gosselink RA et al., American Journal of Respiratory and Critical Care Medicine — estudo primário clínico — https://pubmed.ncbi.nlm.nih.gov/7697243/ — 10.1164/ajrccm.151.4.7697243 — 2026-07-24 — Sustenta não presumir benefício universal e recomendar enquadramento profissional em doença respiratória relevante. — A amostra clínica foi muito pequena e composta por pessoas com DPOC grave; os resultados não devem ser extrapolados para principiantes saudáveis.
