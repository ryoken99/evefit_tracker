# Postura unipodal

Conteúdo para principiantes em português europeu.

## Descrição curta

Postura estática em que o corpo fica sobre um único pé, com os olhos abertos e sem deslocamento.

## O que é

Elevar um pé do solo e controlar o corpo sobre o pé de apoio, numa superfície firme, nivelada e antiderrapante, com visão disponível. Pode existir um apoio estável ao alcance ou em contacto com a mão.

## O que vais fazer

Partir de uma posição estável com os dois pés no chão, transferir o peso para uma perna, elevar o outro pé e conservar uma postura controlada antes de regressar voluntariamente a dois apoios.

## Porque existe este movimento

A tarefa organiza o controlo do centro de massa sobre a base reduzida formada por um único pé. O objetivo técnico imediato é controlar a postura, sem deslocamento global.

## Antes de começares

1. Confirma que compreende como iniciar, interromper e regressar a dois apoios.
2. Escolhe uma área desimpedida, bem iluminada e afastada de escadas, desníveis e alturas sem proteção.
3. Confirma que o piso é firme, nivelado, seco e antiderrapante.
4. Se precisares, coloca um apoio estável ao alcance e confirma que não desliza nem roda.
5. Não inicies se sentires dor aguda, tontura, mal-estar ou instabilidade que impeça uma saída controlada.

## Preparar o equipamento

1. Não é obrigatório equipamento. Um apoio estável é opcional; se for usado, deve ficar ao lado, ao alcance da mão e firmemente imobilizado. Não uses objetos com rodas, leves, soltos ou suscetíveis de tombar.

## Preparar o espaço

1. Usa uma zona livre de obstáculos, com iluminação suficiente e piso firme, nivelado e antiderrapante. Não executes numa superfície escorregadia, instável ou atravancada, num veículo em movimento ou junto de uma altura sem proteção.

## Verificação do corpo

1. Consegues ficar de pé com os dois pés apoiados e iniciar a tarefa voluntariamente.
2. Consegues transferir o peso para uma perna sem um passo descontrolado.
3. Consegues elevar e voltar a pousar o pé livre com controlo.
4. Consegues alcançar o apoio opcional ou regressar de imediato a dois apoios.
5. Não apresentas dor aguda, tontura, mal-estar ou perda de controlo antes de começares.

## Posição inicial

Fica de pé, com os olhos abertos, o tronco direito e os dois pés assentes no piso. Posiciona-te ao lado do apoio opcional, sem te afastares dele. Mantém os braços descontraídos ou coloca uma mão no apoio.

## Confirmar a posição inicial

1. Piso firme, nivelado, seco e antiderrapante.
2. Área livre e bem iluminada.
3. Apoio opcional estável e ao alcance.
4. Olhar em frente e olhos abertos.
5. Pé de apoio totalmente assente.
6. Joelho de apoio alinhado com o pé e sem estar bloqueado.
7. Saída para dois apoios disponível.

## Passos de execução

1. Assuma uma posição estável com os dois pés no chão e olhe em frente.
2. Se utilizar o apoio opcional, toque-lhe ou segure-o antes de retirar um pé do chão.
3. Transfere o peso de forma controlada para o pé que ficará em apoio, mantendo o tronco direito.
4. Mantém o pé de apoio assente e o respetivo joelho alinhado e ligeiramente desbloqueado.
5. Eleva o outro pé apenas o suficiente para deixar de tocar no chão, sem o prender à perna de apoio.
6. Controla as pequenas oscilações pelo tornozelo e pela anca, sem deslocar o pé de apoio nem dar passos.
7. Continua a respirar de forma natural e contínua, sem suster a respiração.
8. Para terminar, ou ao primeiro sinal de perda de estabilidade, pousa o pé livre e recupera uma posição segura com os dois pés no chão.

## Fases do movimento

### Preparação

Organiza a posição bipodal, a visão, o piso e o apoio opcional.

### Transferência

Leva o centro de massa para o pé de apoio sem inclinar excessivamente o tronco.

### Apoio unipodal

Eleva o pé livre e controla a oscilação com o pé de apoio assente, o joelho desbloqueado e o olhar em frente.

### Saída

Pousa o pé livre de forma deliberada e restabelece uma base bipodal estável.

## Respiração

Respira de forma natural e contínua. Não prendas a respiração enquanto procuras equilíbrio e não associes a respiração a uma contagem.

## Sensações esperadas

1. Pequenas oscilações do corpo para a frente, para trás ou para os lados.
2. Atividade de controlo no tornozelo, na anca e no tronco do lado de apoio.
3. Pressão distribuída pelo pé de apoio, que permanece em contacto com o piso.
4. Necessidade de correções posturais pequenas e contínuas.

## Sensações inesperadas ou de alerta

1. Dor aguda ou dor que aumenta.
2. Tontura, sensação de desmaio ou mal-estar.
3. Falta de ar invulgar ou desconforto no peito.
4. Perda de controlo, passos descontrolados ou necessidade repetida de apoio não planeado.
5. Incapacidade de pousar o pé livre ou de recuperar dois apoios de forma segura.

## Indicações técnicas principais

1. Olhos abertos e olhar em frente.
2. Pé de apoio totalmente assente.
3. Joelho alinhado e desbloqueado.
4. Tronco direito, sem inclinação excessiva.
5. Apoio firme ao alcance, se necessário.
6. Respiração natural e contínua.

## Erros comuns e correções

### Erro 1: Fechar os olhos ou desviar a visão para uma condição em que deixa de ver o espaço.

- Como reconhecer: A pessoa fecha os olhos, fixa o chão junto aos pés ou perde a referência visual em frente.
- Como corrigir: Mantém os olhos abertos e escolhe um ponto estável à frente, num espaço bem iluminado.

### Erro 2: Bloquear o joelho de apoio ou deixá-lo colapsar para dentro.

- Como reconhecer: O joelho fica rigidamente estendido ou desloca-se para dentro em relação ao pé.
- Como corrigir: Desbloqueia ligeiramente o joelho e mantém-no orientado na mesma direção do pé.

### Erro 3: Inclinar ou rodar excessivamente o tronco para compensar.

- Como reconhecer: Os ombros afastam-se claramente da vertical, a bacia roda ou o corpo procura equilíbrio com movimentos amplos.
- Como corrigir: Recupera dois apoios, reorganiza o tronco direito e usa o apoio opcional para reduzir a necessidade de compensação.

### Erro 4: Deslocar, rodar ou levantar partes do pé de apoio.

- Como reconhecer: O pé muda de lugar, roda sobre o piso ou perde contacto claro no calcanhar ou na parte anterior.
- Como corrigir: Pousa o pé livre, reposiciona o pé de apoio totalmente no chão e reinicia apenas com controlo.

### Erro 5: Usar um apoio inseguro ou demasiado afastado.

- Como reconhecer: O objeto desliza, roda, abana, pode tombar ou exige uma inclinação para ser alcançado.
- Como corrigir: Escolhe um apoio firme, imobilizado e ao alcance antes de elevar o pé.

### Erro 6: Continuar depois de perder estabilidade.

- Como reconhecer: Surgem passos descontrolados, agarrões bruscos ou contactos repetidos do pé livre no chão.
- Como corrigir: Termina de imediato, pousa o pé livre e estabiliza-te com os dois pés no chão.

## Formas de simplificar ou ensaiar

1. Usa contacto contínuo da mão num apoio estável, mantendo o apoio como equipamento opcional.
2. Eleva o pé livre apenas o suficiente para o separar do piso, sem mudar a organização unipodal.
3. Mantém os braços numa posição confortável, desde que não crie movimentos amplos nem impeça o acesso ao apoio.
4. Escolhe uma zona com boa iluminação e uma referência visual fixa à frente.

## Supervisão

A supervisão é recomendada. Deve ser próxima quando existe risco elevado de queda, histórico recente de quedas, contexto neurológico ou vestibular, incapacidade de interromper a tarefa de forma independente ou dificuldade em recuperar dois apoios. O supervisor deve manter-se suficientemente perto para ajudar, sem bloquear os movimentos naturais dos braços.

## Como terminar

Baixa o pé livre com controlo até ao chão, distribui novamente o peso pelos dois pés e confirma que estás estável antes de te afastares do apoio. Se a estabilidade se perder, usa o apoio e regressa imediatamente a dois apoios.

## Nota de segurança

Risco operacional moderado, sobretudo por queda, perda de equilíbrio e apoio num único membro. Não transformes esta execução em olhos fechados, superfície instável, rotação da cabeça ou tarefa com objeto. Interrompe de imediato se não conseguires manter ou recuperar o controlo.

## Quando parar ou reduzir

1. Dor aguda.
2. Tontura ou sensação de desmaio.
3. Mal-estar.
4. Falta de ar invulgar ou desconforto no peito.
5. Necessidade repetida de apoio não planeado.
6. Perda de controlo ou passos descontrolados.
7. Incapacidade de regressar voluntariamente a dois apoios.

## Segurança do equipamento

O apoio é opcional, mas, quando usado, tem de ser estável, estar imobilizado e ficar ao alcance antes do início. Não confies em cadeiras com rodas, mesas leves, portas móveis ou objetos que possam deslizar ou tombar.

## Segurança do espaço

Executa apenas numa área livre, bem iluminada e sobre piso firme, nivelado, seco e antiderrapante. Evita tapetes soltos, cabos, objetos no chão, superfícies escorregadias ou instáveis, veículos em movimento e alturas sem proteção.

## Limitações

1. Conteúdo educativo geral para principiante, não avaliação individual, diagnóstico, tratamento, prescrição ou autorização universal. A evidência técnica inclui materiais centrados em pessoas idosas e estudos laboratoriais; não foi feita transferência automática entre populações. As relações aprovadas, o risco moderado, o apoio opcional e os requisitos de superfície foram preservados. Implementação realizada: não.

## Teste de compreensão

### 1. Que tipo de superfície deves escolher?

Resposta esperada: Uma superfície firme, nivelada, seca e antiderrapante.

### 2. Os olhos ficam abertos ou fechados?

Resposta esperada: Abertos, com uma referência visual estável à frente.

### 3. O apoio externo é obrigatório?

Resposta esperada: Não. É opcional, mas deve ser firme, estar imobilizado e ficar ao alcance quando for usado.

### 4. Como deve ficar o joelho da perna de apoio?

Resposta esperada: Alinhado com o pé e ligeiramente desbloqueado.

### 5. O pé de apoio pode rodar ou mudar de lugar?

Resposta esperada: Não. Deve permanecer totalmente assente e sem deslocamento.

### 6. Como deves posicionar o tronco?

Resposta esperada: Direito, sem inclinação ou rotação excessiva.

### 7. Como deves respirar?

Resposta esperada: De forma natural e contínua, sem suster a respiração nem seguir contagens.

### 8. Pequenas oscilações significam sempre erro?

Resposta esperada: Não. Pequenas correções são esperadas; movimentos amplos, passos ou perda de controlo exigem saída.

### 9. O que faz ao perder estabilidade?

Resposta esperada: Usa o apoio se estiver disponível, pousa o pé livre e regressa imediatamente a dois apoios.

### 10. Que sinais obrigam a interromper?

Resposta esperada: Dor aguda, tontura, mal-estar, falta de ar invulgar, desconforto no peito, perda de controlo ou apoio não planeado repetido.

### 11. Olhos fechados, espuma ou rotação da cabeça pertencem a esta execução?

Resposta esperada: Não. São condições diferentes e ficam fora desta identidade.

### 12. Quando é especialmente importante ter supervisão próxima?

Resposta esperada: Quando há risco elevado de queda, quedas recentes, contexto neurológico ou vestibular, ou dificuldade em interromper e recuperar dois apoios.

## Fontes e limites da evidência

### Fonte 1: OTAGO Strength and Balance

- Autor ou entidade: E1-SRC-003 — OTAGO Strength and Balance — Oxford University Hospitals NHS Foundation Trust — manual profissional — https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf — Sustenta a posição alta, o joelho de apoio desbloqueado e a disponibilidade de um apoio firme ajustado à necessidade de equilíbrio. — Material dirigido sobretudo a pessoas idosas; as indicações de dose do manual não foram transpostas.
- Tipo: manual profissional
- Localizador: https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf
- Usada para: E1-SRC-003 — OTAGO Strength and Balance — Oxford University Hospitals NHS Foundation Trust — manual profissional — https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf — Sustenta a posição alta, o joelho de apoio desbloqueado e a disponibilidade de um apoio firme ajustado à necessidade de equilíbrio. — Material dirigido sobretudo a pessoas idosas; as indicações de dose do manual não foram transpostas.
- Limite: Material dirigido sobretudo a pessoas idosas; as indicações de dose do manual não foram transpostas.

### Fonte 2: STEADI Coordinated Care Plan: Tele-Med Adaptation

- Autor ou entidade: EX38-SRC-001 — STEADI Coordinated Care Plan: Tele-Med Adaptation — Centers for Disease Control and Prevention — orientação oficial — https://www.cdc.gov/steadi/media/pdfs/2024/08/Telesteadi-Guide_H_WEB.pdf — Sustenta área desimpedida, avaliação prévia do risco, presença de outra pessoa em contextos de maior risco e cautela específica com a postura unipodal à distância. — Documento de avaliação clínica remota, não um guia de prescrição deste exercício.
- Tipo: orientação oficial
- Localizador: https://www.cdc.gov/steadi/media/pdfs/2024/08/Telesteadi-Guide_H_WEB.pdf
- Usada para: EX38-SRC-001 — STEADI Coordinated Care Plan: Tele-Med Adaptation — Centers for Disease Control and Prevention — orientação oficial — https://www.cdc.gov/steadi/media/pdfs/2024/08/Telesteadi-Guide_H_WEB.pdf — Sustenta área desimpedida, avaliação prévia do risco, presença de outra pessoa em contextos de maior risco e cautela específica com a postura unipodal à distância. — Documento de avaliação clínica remota, não um guia de prescrição deste exercício.
- Limite: Documento de avaliação clínica remota, não um guia de prescrição deste exercício.

### Fonte 3: Chair Based Home Exercise Programme

- Autor ou entidade: EX38-SRC-002 — Chair Based Home Exercise Programme — Torbay and South Devon NHS Foundation Trust e Later Life Training — material profissional — https://www.torbayandsouthdevon.nhs.uk/uploads/chair-based-home-exercise-programme.pdf — Sustenta a orientação geral para respirar normalmente, não suster a respiração e usar apoio firme. — A orientação respiratória é geral e o programa é sentado; foi usada apenas para a regra respiratória não específica.
- Tipo: material profissional
- Localizador: https://www.torbayandsouthdevon.nhs.uk/uploads/chair-based-home-exercise-programme.pdf
- Usada para: EX38-SRC-002 — Chair Based Home Exercise Programme — Torbay and South Devon NHS Foundation Trust e Later Life Training — material profissional — https://www.torbayandsouthdevon.nhs.uk/uploads/chair-based-home-exercise-programme.pdf — Sustenta a orientação geral para respirar normalmente, não suster a respiração e usar apoio firme. — A orientação respiratória é geral e o programa é sentado; foi usada apenas para a regra respiratória não específica.
- Limite: A orientação respiratória é geral e o programa é sentado; foi usada apenas para a regra respiratória não específica.

### Fonte 4: Normative Values for the Unipedal Stance Test with Eyes Open and Closed

- Autor ou entidade: EX38-SRC-003 — Normative Values for the Unipedal Stance Test with Eyes Open and Closed — Springer et al. — estudo primário — https://pubmed.ncbi.nlm.nih.gov/19839175/ — Compara diretamente a postura unipodal com olhos abertos e fechados; o desempenho foi superior com visão disponível, apoiando a manutenção dos olhos abertos nesta identidade. — Estudo de avaliação e valores normativos, não de ensino do exercício; não autoriza inferência de dose.
- Tipo: estudo primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/19839175/
- Usada para: EX38-SRC-003 — Normative Values for the Unipedal Stance Test with Eyes Open and Closed — Springer et al. — estudo primário — https://pubmed.ncbi.nlm.nih.gov/19839175/ — Compara diretamente a postura unipodal com olhos abertos e fechados; o desempenho foi superior com visão disponível, apoiando a manutenção dos olhos abertos nesta identidade. — Estudo de avaliação e valores normativos, não de ensino do exercício; não autoriza inferência de dose.
- Limite: Estudo de avaliação e valores normativos, não de ensino do exercício; não autoriza inferência de dose.

### Fonte 5: The Effect of Fatigue on Single-Leg Postural Sway and Its Transient Characteristics in Healthy Young Adults

- Autor ou entidade: EX38-SRC-004 — The Effect of Fatigue on Single-Leg Postural Sway and Its Transient Characteristics in Healthy Young Adults — Kozinc et al. — estudo primário — https://pubmed.ncbi.nlm.nih.gov/34489739/ — Mostra que a fadiga pode alterar características da oscilação postural em apoio unipodal, apoiando a cautela perante perda de controlo. — Amostra de adultos jovens fisicamente ativos e protocolo laboratorial; não permite generalização automática a outras populações.
- Tipo: estudo primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/34489739/
- Usada para: EX38-SRC-004 — The Effect of Fatigue on Single-Leg Postural Sway and Its Transient Characteristics in Healthy Young Adults — Kozinc et al. — estudo primário — https://pubmed.ncbi.nlm.nih.gov/34489739/ — Mostra que a fadiga pode alterar características da oscilação postural em apoio unipodal, apoiando a cautela perante perda de controlo. — Amostra de adultos jovens fisicamente ativos e protocolo laboratorial; não permite generalização automática a outras populações.
- Limite: Amostra de adultos jovens fisicamente ativos e protocolo laboratorial; não permite generalização automática a outras populações.

### Fonte 6: Single Leg Balance Training: A Systematic Review

- Autor ou entidade: E2-S07 — Single Leg Balance Training: A Systematic Review — Marcori et al. — revisão sistemática — https://pubmed.ncbi.nlm.nih.gov/35084234/ — Sustenta a postura unipodal como família reconhecível de tarefas de equilíbrio. — Os estudos variam em visão, superfície, apoio e tarefas adicionais; não define uma execução única nem uma dose universal.
- Tipo: revisão sistemática
- Localizador: https://pubmed.ncbi.nlm.nih.gov/35084234/
- Usada para: E2-S07 — Single Leg Balance Training: A Systematic Review — Marcori et al. — revisão sistemática — https://pubmed.ncbi.nlm.nih.gov/35084234/ — Sustenta a postura unipodal como família reconhecível de tarefas de equilíbrio. — Os estudos variam em visão, superfície, apoio e tarefas adicionais; não define uma execução única nem uma dose universal.
- Limite: Os estudos variam em visão, superfície, apoio e tarefas adicionais; não define uma execução única nem uma dose universal.
