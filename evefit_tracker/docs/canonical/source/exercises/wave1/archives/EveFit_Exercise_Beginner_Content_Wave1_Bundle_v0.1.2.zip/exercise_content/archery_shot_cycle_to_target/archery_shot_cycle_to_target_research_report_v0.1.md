# Relatório de investigação — `archery_shot_cycle_to_target`

## Estado

- Agente: EX-41
- Âmbito: conteúdo documental para principiante absoluto
- Identidade canónica preservada: sim
- Risco operacional `high` preservado: sim
- Equipamento obrigatório preservado: sim
- Alvo e ambiente controlado preservados: sim
- Relações aprovadas preservadas sem alteração: sim
- Aprovação de multimédia: não realizada
- Prescrição individual: não realizada
- Implementação realizada: não

## Conclusão

O registo descreve corretamente um ciclo completo de tiro com arco para alvo, e não um exercício sem projétil, uma distância específica ou uma prova de pontuação. As fontes oficiais sustentam uma sequência que inclui preparação dos pés, colocação da flecha, mãos, organização corporal, elevação, puxada, ancoragem, mira, largada e seguimento.

O risco continua alto porque existe um projétil real. O conteúdo só é defensável com todos os controlos canónicos intactos: arco e flechas aprovados, anteparo de alvo, barreira de retenção verificada, pista fechada, comandos de campo, inspeção e supervisão obrigatória. Nenhuma simplificação proposta reduz estes requisitos.

O conteúdo recebe `beginner_content_approved_with_limits`: a sequência e a segurança têm sustentação oficial forte, mas certos pormenores técnicos variam com o tipo de arco, o método do instrutor e a pessoa. A respiração exige ainda um limite explícito, pois o manual técnico descreve padrões possíveis, incluindo uma breve pausa, enquanto o contrato do conteúdo proíbe impor contagens ou retenções.

## Perguntas de investigação

1. Qual é a ordem oficial do ciclo de tiro ensinada a principiantes?
2. Que posição, puxada, ancoragem, largada e seguimento são comuns às descrições oficiais?
3. Que verificações pertencem ao arco, às flechas, ao anteparo e à barreira de retenção?
4. Quando pode a pessoa colocar a flecha, puxar o arco e avançar para recuperar flechas?
5. Que fatores exigem paragem imediata?
6. Que erros técnicos são observáveis sem criar uma prescrição?
7. Que orientação respiratória pode ser documentada sem impor contagens ou retenções?
8. Que nível de supervisão é compatível com o risco canónico `high`?

## Síntese da evidência

### 1. Ciclo oficial de tiro

O programa de principiantes da World Archery apresenta uma sequência ordenada que começa nos pés e prossegue por colocação da flecha, mão do arco, mão da corda, organização corporal, elevação e puxada. O mesmo documento continua pela ancoragem, mira, largada e seguimento. O objetivo declarado é repetir com consistência os passos do tiro.

O manual de treinadores de nível 1 desenvolve cada componente e dedica secções específicas ao seguimento, respiração e problemas comuns. A descrição pública foi organizada em 11 passos para tornar explícitos os comandos de campo e o fecho seguro, sem alterar a identidade mecânica canónica.

### 2. Postura, puxada, ancoragem, largada e seguimento

A World Archery descreve postura ereta e estável, elevação do arco diretamente para o alvo, puxada com participação das costas, ancoragem consistente e continuidade da ação durante a mira. Na largada, a mão da corda segue para trás no plano do tiro; no seguimento, as atividades físicas, visuais e mentais continuam brevemente após a saída da flecha.

Foram retidos apenas elementos transversais a uma iniciação supervisionada. A posição exata dos dedos e a referência no rosto não foram universalizadas, porque dependem do equipamento aprovado e do método ensinado.

### 3. Preparação do alvo e da barreira

O Livro 2 da World Archery exige que os anteparos de alvo estejam firmemente presos aos suportes e seguros contra tombamento. Também exige barreiras para o público, fecho do campo e uma zona posterior suficiente ou uma barreira de retenção adequada.

O conteúdo distingue as duas funções:

- o `archery_target_butt` recebe a flecha dirigida ao alvo;
- o `verified_backstop` retém uma flecha que falhe o anteparo.

Esta distinção preserva os quatro equipamentos obrigatórios do registo e impede que um alvo isolado seja apresentado como ambiente suficiente.

### 4. Segurança da linha e comandos

O Livro 3 da World Archery estabelece que o arco só é puxado na linha de tiro. Quando existe flecha, esta é dirigida ao anteparo, depois de a pessoa confirmar que o campo está livre à frente e atrás do alvo.

A orientação de instalações da Archery GB exige ausência de acesso à frente da linha durante o tiro, direção única para o alvo e períodos separados para disparar e recuperar. Os sinais exatos variam entre sistemas; por isso, o conteúdo não fixa contagens de apitos e manda aprender os comandos locais.

O manual de clubes da USA Archery reforça que as flechas permanecem na aljava até haver indicação para disparar e que a corda só é largada com uma flecha colocada e dirigida em segurança ao alvo.

### 5. Supervisão

A USA Archery associa a operação segura do campo a instrutores formados para montar e controlar a instalação e ensinar tiro responsável. O programa de principiantes da World Archery é dirigido a principiantes e treinadores de nível 1 e recomenda colaboração com um treinador.

Estas fontes sustentam a formulação conservadora exigida pelo registo: toda a utilização com flecha real requer supervisão contínua. O conteúdo não cria exceções por experiência, idade, local interior ou exterior.

### 6. Inspeção do equipamento

As fontes oficiais convergem na necessidade de equipamento adequado, cuidado e inspecionado. Para tornar a verificação observável sem entrar em ajuste técnico, o conteúdo pede ao instrutor que confirme estrutura do arco, membros, corda, ponto de encaixe, apoio e acessórios. Cada flecha é excluída se houver fissura, lasca, deformação ou componente solto.

Não foram propostos equipamento improvisado, reparações na linha, substitutos ao alvo ou barreira, nem alterações à lista canónica.

### 7. Respiração

O manual de nível 1 da World Archery dedica uma secção à continuidade respiratória e salienta consistência durante mira, largada e seguimento. Também descreve um padrão comum no qual alguns arqueiros fazem uma breve pausa.

Esse padrão não foi transformado numa instrução universal. O contrato deste pacote determina que nunca sejam impostas contagens ou retenções, e o conteúdo canónico já orienta a expirar naturalmente sem prender deliberadamente a respiração. A formulação final é, por isso:

- respiração natural e discreta;
- ausência de contagens;
- ausência de inspiração ou expiração forçada;
- ausência de retenção deliberada;
- descida controlada se a respiração ficar presa ou a estabilidade se perder.

Confiança neste ponto: moderada. A redação é deliberadamente conservadora e não contradiz o limite do produto.

### 8. Erros frequentes

O capítulo de problemas comuns do manual World Archery inclui ombros a elevar durante a subida, puxada feita com o braço em vez das costas, movimento da cabeça para a corda, transferência inadequada do peso, subida ou recuo do ombro do arco, inclinação do arco e agarrar o arco na largada.

O conteúdo selecionou erros que um principiante e um instrutor podem reconhecer:

- colocação precoce da flecha;
- arco ou flecha fora da direção do alvo;
- puxada dominada pelo braço e ombro elevado;
- cabeça a procurar a corda ou ancoragem variável;
- agarrar o arco ou abrir a mão da corda bruscamente;
- respiração deliberadamente presa ou forçada;
- cruzar a linha sem comando.

As correções perigosas não são executadas autonomamente: o principiante baixa o arco e pede intervenção do instrutor.

## Decisões de conteúdo e limites

| Tema | Decisão | Razão |
|---|---|---|
| Identidade | Manter `canonical_exercise` | Ação observável com flecha real e sequência nuclear completa |
| Variante | Nenhuma | Não foi alterado tipo de exercício, equipamento essencial ou ação |
| Distância e pontuação | Omitidas | Pertencem ao uso concreto, não à identidade |
| Equipamento | Preservar os quatro itens e as duas proteções pessoais | Contrato proíbe alterações e o risco exige falha fechada |
| Campo | Apenas instalação especializada controlada | Preserva pista segura, alvo, barreira e ausência de cruzamento público |
| Supervisão | Obrigatória e contínua | O gatilho canónico abrange qualquer flecha real |
| Respiração | Natural, sem contagens ou retenção deliberada | Preserva o cue canónico e o limite do contrato |
| Descida do arco | Estratégia de saída antes da largada | Permite interromper sem lançar uma flecha insegura |
| Seguimento | Incluído como fase nuclear | Sustentado pela World Archery e presente na definição canónica |

## Fontes consultadas

### Fontes canónicas existentes

1. **F1S21 — World Archery Coaching Manual Level 1.** World Archery. Manual oficial de federação internacional.  
   https://extranet.worldarchery.sport/documents/index.php/Coaches/Accreditation/Coaching_Levels/MANUAL_COACHING_LEVEL_1.pdf  
   Uso: ciclo de tiro, seguimento, respiração, equipamento, segurança e problemas frequentes.

2. **F1S22 — The World Archery Beginners' Awards Program.** World Archery. Programa técnico oficial.  
   https://extranet.worldarchery.sport/documents/index.php/Federation/Award_Schemes/Beginners_Awards_Programme_ENGLISH.pdf  
   Uso: ensino a principiantes, passos da sequência, segurança, cuidado do equipamento, largada e seguimento.

3. **F2-S15 — World Archery Coaching Manual Level 1.** World Archery. Registo independente existente no pacote canónico para a mesma fonte técnica.  
   https://extranet.worldarchery.sport/documents/index.php/Coaches/Accreditation/Coaching_Levels/MANUAL_COACHING_LEVEL_1.pdf  
   Uso: confirmação da sequência postura–puxada–ancoragem–mira–largada–seguimento.

### Fontes oficiais adicionais

4. **World Archery Rulebook, Book 2: Events, versão 2026-01-27.** World Archery.  
   https://extranet.worldarchery.sport/documents/index.php/Rules/Rule_Book_versions/2026-01-27/EN-Book_2_-_2026-01-27_Version.pdf  
   Uso: barreiras ao público, fecho do campo, zona posterior, barreira de retenção e fixação dos anteparos.

5. **World Archery Rulebook, Book 3: Target Archery, versão 2022-09-01.** World Archery.  
   https://extranet.worldarchery.sport/documents/index.php/Rules/Rule_Book_versions/2022-09-01/EN-Book3.pdf  
   Uso: puxar apenas na linha, orientar ao alvo e confirmar a zona livre à frente e atrás.

6. **Archery Facilities: Guidance & Specifications.** Archery GB. Orientação oficial de federação nacional.  
   https://archerygb.org/files/FacilityrequirementsandspecificationsFinalLOWRES-16543.pdf  
   Uso: controlo da linha, direção de tiro, separação entre disparo e recuperação e sinais de campo.

7. **Archery Safety.** USA Archery. Orientação oficial de federação nacional.  
   https://www.usarchery.org/participate/archery-safety  
   Uso: formação de instrutores para montar e operar campos seguros.

8. **USA Archery Club Handbook.** USA Archery. Manual oficial.  
   https://www.usarchery.org/resources/usa-archery-club-handbook-030220184842.pdf  
   Uso: flechas na aljava até ao comando, direção segura e circulação no campo.

Todas as fontes foram consultadas em 2026-07-24. A World Archery foi usada como autoridade técnica principal; Archery GB e USA Archery forneceram confirmação oficial independente para segurança do campo e supervisão.

## Confiança

- Sequência técnica: alta
- Segurança da linha e do campo: alta
- Preparação de alvo e barreira: alta
- Supervisão: alta
- Erros comuns: alta
- Respiração: moderada
- Confiança global: alta com limites

## Limitações

- O conteúdo não substitui demonstração nem correção presencial.
- A posição exata dos dedos, a referência facial e detalhes da largada dependem do equipamento e do método ensinado.
- Não foram definidos distância, pontuação, volume, carga, ritmo ou progressão.
- Não foi feita inferência de elegibilidade clínica nem autorização universal.
- A segurança real só pode ser confirmada no campo pelo responsável.
- Não foram criadas relações, variantes, aprovações de multimédia ou alterações canónicas.

## Campos não resolvidos

Nenhum. A variação respiratória foi resolvida por um limite explícito e conservador, sem impor retenção.

**Implementação realizada: não**
