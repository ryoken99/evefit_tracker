# Caminhada terrestre

Conteúdo para principiantes em português europeu.

## Descrição curta

Locomoção a pé sobre solo firme, com passos alternados e sem fase aérea intencional.

## O que é

A caminhada terrestre é uma deslocação para a frente sobre uma superfície fixa. Um pé e depois o outro contactam o solo de forma alternada; o corpo avança sem uma fase aérea intencional. Distingue-se da caminhada numa passadeira porque existe deslocamento real ao longo do percurso e não exige as regras competitivas da marcha atlética.

## O que vais fazer

Partir de pé, transferir o peso de um lado para o outro e avançar com passos alternados. Cada pé recebe apoio no solo antes de o outro avançar. Os braços podem acompanhar naturalmente as pernas, com atenção ao trajeto e respiração contínua.

## Porque existe este movimento

O propósito técnico imediato é executar locomoção cíclica terrestre de forma controlada. Os contextos de treino aprovados não alteram esta identidade, e o ritmo, a distância e a duração são definidos fora deste conteúdo.

## Antes de começares

1. Confirma que consegues permanecer de pé e transferir o peso entre os pés com controlo.
2. Escolhe um percurso contínuo, firme, regular, visível e desimpedido.
3. Evita tráfego não controlado, obstáculos, piso instável e zonas onde não consigas ver o caminho.
4. No exterior, verifica as condições meteorológicas e a qualidade do ar.
5. Não inicies se já sentires tontura, confusão, desconforto no peito, falta de ar fora do habitual, dor nova ou perda de controlo.

## Preparar o equipamento

1. Sem equipamento obrigatório.
2. O vestuário e o calçado dependem da pessoa e da superfície. Se forem usados, confirma que não dificultam o apoio, não causam desconforto e não criam risco de tropeçar.
3. Não transportes objetos que tapem a visão, ocupem as mãos de forma desnecessária ou alterem o equilíbrio.

## Preparar o espaço

1. Usa uma rota transitável no interior ou no exterior.
2. Observa o piso e identifica desníveis, objetos, pessoas, animais, mudanças de luz e possíveis cruzamentos com veículos.
3. Se a visibilidade, o calor, o frio, a qualidade do ar ou o tráfego tornarem o percurso inseguro, não uses esse percurso.

## Verificação do corpo

1. Consigo manter-me de pé com controlo.
2. Consigo transferir o peso entre os pés sem instabilidade marcada.
3. Não tenho desconforto no peito, falta de ar atípica, tontura, confusão, dor nova ou perda de controlo.
4. Se estou a regressar após lesão ou cirurgia ou tenho sintomas cardiorrespiratórios relevantes, já obtive a orientação adequada ao meu caso.

## Posição inicial

Fica de pé no início do percurso, com os pés apoiados de forma confortável e o peso distribuído de modo estável. Mantém o tronco naturalmente erguido, os ombros descontraídos, os braços livres e o olhar dirigido para a zona à tua frente.

## Confirmar a posição inicial

1. Estou estável de pé.
2. Tenho espaço livre à frente.
3. Consigo ver o percurso e os seus limites.
4. Os meus braços podem mover-se sem obstáculos.
5. Não tenho nenhum sinal que indique que devo adiar ou interromper.

## Passos de execução

1. Observa novamente o início do percurso e confirma que a direção para a frente está livre.
2. Mantém uma postura confortável, com o olhar à frente e sem fixar continuamente os pés.
3. Transfere o peso de forma controlada para uma perna e leva o outro pé para a frente.
4. Pousa o pé que avança de forma controlada, permitindo que o apoio progrida naturalmente pelo pé sem forçar um contacto rígido.
5. Transfere o peso para esse apoio e deixa a perna oposta avançar para o passo seguinte.
6. Continua a alternar os pés e deixa os braços acompanhar naturalmente as pernas, sem exagerar nem bloquear o movimento.
7. Mantém atenção ao trajeto. Para mudar de direção, usa passos controlados e evita rodar todo o corpo sobre um único pé fixo.
8. Respira de forma natural e contínua durante o deslocamento, sem prender nem impor uma contagem à respiração.
9. Quando decidires terminar, completa o passo em curso, aproxima os pés para uma posição estável e confirma o equilíbrio.

## Fases do movimento

### Preparação

Confirmar o percurso e organizar uma posição de pé estável.

### Início

Transferir o peso e avançar com o primeiro passo.

### Apoio alternado

Receber o peso num pé enquanto o outro avança.

### Progressão

Repetir a alternância com deslocamento para a frente, balanço natural dos braços e atenção ao espaço.

### Mudança de direção, quando necessária

Reorientar o corpo através de passos, sem pivotar de forma brusca num pé fixo.

### Finalização

Completar o passo e recuperar uma posição estável de pé.

## Respiração

Deixa a respiração acompanhar naturalmente a caminhada. Inspira e expira de forma contínua, sem retenções e sem tentar sincronizar os passos com uma contagem obrigatória. Uma alteração ligeira da respiração pode acompanhar o movimento; falta de ar atípica, dificuldade em recuperar a respiração ou incapacidade súbita de respirar confortavelmente são sinais para parar.

## Sensações esperadas

1. Transferência alternada do peso entre os pés.
2. Contacto repetido e controlado dos pés com o solo.
3. Movimento das pernas e balanço discreto dos braços.
4. Respiração possivelmente mais percetível, sem que isso constitua uma garantia de adequação individual.

## Sensações inesperadas ou de alerta

1. Desconforto no peito.
2. Falta de ar atípica ou dificuldade em recuperar a respiração.
3. Tontura ou confusão.
4. Dor nova.
5. Instabilidade marcada ou perda de controlo.

## Indicações técnicas principais

1. Mantém o percurso desimpedido.
2. Olha para a zona à tua frente sem perder noção do piso.
3. Pousa cada pé de forma controlada.
4. Alterna os apoios sem forçar o comprimento do passo.
5. Deixa os braços acompanhar naturalmente as pernas.
6. Mantém a respiração contínua.

## Erros comuns e correções

### Erro 1: Olhar apenas para os pés.

- Como reconhecer: A cabeça permanece inclinada e deixas de observar obstáculos, pessoas ou mudanças no trajeto.
- Como corrigir: Dirige o olhar para a zona à frente e usa a visão periférica para acompanhar o piso próximo.

### Erro 2: Forçar um passo demasiado comprido.

- Como reconhecer: Precisas de inclinar o tronco, travas de forma brusca ou sentes que o pé aterra longe do teu controlo.
- Como corrigir: Volta a um passo confortável, no qual consigas transferir o peso sem alcançar o chão à força.

### Erro 3: Pousar o pé sem controlo ou arrastá-lo.

- Como reconhecer: Ouves impactos fortes repetidos, o pé raspa no chão ou tropeças com facilidade.
- Como corrigir: Levanta o pé apenas o necessário para o libertar do piso e volta a pousá-lo de forma controlada.

### Erro 4: Bloquear ou exagerar o movimento dos braços.

- Como reconhecer: Os braços ficam rígidos junto ao tronco ou balançam de forma forçada e perturbam o equilíbrio.
- Como corrigir: Relaxa os ombros e permite um balanço pequeno e natural, sem o impor.

### Erro 5: Rodar sobre um pé fixo para mudar de direção.

- Como reconhecer: O pé permanece preso ao chão enquanto o corpo gira por cima dele e o equilíbrio piora.
- Como corrigir: Levanta os pés e completa a mudança de direção através de passos controlados.

### Erro 6: Prender a respiração.

- Como reconhecer: Fechas a boca, crias tensão no tronco ou só libertas o ar após vários passos.
- Como corrigir: Retoma uma inspiração e expiração naturais, sem contagens nem retenções.

### Erro 7: Continuar apesar de sinais de aviso.

- Como reconhecer: Ignoras tontura, confusão, dor nova, desconforto no peito, falta de ar atípica ou perda de controlo.
- Como corrigir: Interrompe o movimento, fica num local seguro e procura ajuda adequada ao sinal e ao contexto.

## Formas de simplificar ou ensaiar

1. Escolhe um trajeto familiar, plano, bem iluminado e com poucas distrações.
2. Começa num ponto onde seja fácil parar em segurança, sem atravessar tráfego.
3. Evita transportar objetos enquanto aprendes a observar o percurso e a coordenar os passos.
4. Se o ambiente for novo, observa-o primeiro sem iniciar o deslocamento.
5. Se não mantiveres um apoio alternado controlado, não tentes compensar aumentando a velocidade ou o comprimento do passo.

## Supervisão

A caminhada terrestre não exige supervisão por definição. Contudo, instabilidade marcada, ambiente desconhecido, regresso após lesão ou cirurgia, limitações de equilíbrio ou sintomas cardiorrespiratórios relevantes justificam avaliação e orientação por um profissional qualificado antes de executar de forma autónoma. Ter outra pessoa por perto pode ajudar a gerir o contexto, mas não substitui avaliação quando esta é necessária.

## Como terminar

Não pares com uma rotação brusca. Completa o passo, coloca os pés numa base estável e confirma que tens controlo antes de virar, sentar ou iniciar outra ação. Se parares por um sinal de aviso, permanece num local protegido de tráfego e outros perigos e pede ajuda adequada.

## Nota de segurança

Confirma sempre a superfície, a visibilidade e o tráfego. A caminhada não é automaticamente adequada a todas as pessoas ou a todas as fases de regresso à atividade. A fadiga, a visibilidade reduzida, a qualidade do ar, o calor, o frio e o tráfego podem aumentar o risco mesmo quando a técnica habitual é simples.

## Quando parar ou reduzir

1. Desconforto no peito ou falta de ar atípica.
2. Tontura ou confusão.
3. Perda de controlo ou dor nova.

## Segurança do equipamento

Não existe equipamento obrigatório. Qualquer calçado, vestuário ou objeto pessoal utilizado deve ser compatível com o piso e não deve criar instabilidade, fricção dolorosa, limitação da visão ou risco de tropeçar.

## Segurança do espaço

Usa apenas uma superfície firme e regular, com um percurso contínuo e livre de obstáculos. Evita tráfego não controlado e superfícies inseguras. No exterior, considera calor, frio, chuva, baixa visibilidade e qualidade do ar; no interior, confirma iluminação, espaço de passagem e ausência de objetos no chão.

## Limitações

1. Conteúdo documental de execução; não prescreve ritmo, intensidade, duração, distância, frequência, séries ou repetições.
2. Não determina elegibilidade individual, não diagnostica e não substitui avaliação clínica ou profissional.
3. A forma exata do contacto do pé varia entre pessoas; não é imposto um padrão rígido.
4. As fontes sustentam sobretudo a família de caminhada, princípios gerais de marcha e segurança; não validam resultados individuais.
5. Não foi aprovado conteúdo multimédia e não foi realizada qualquer implementação.

## Teste de compreensão

### 1. Que tipo de superfície deves escolher?

Resposta esperada: Uma superfície firme, regular, visível e desimpedida.

### 2. A caminhada terrestre acontece numa passadeira?

Resposta esperada: Não; implica deslocamento real sobre uma superfície fixa.

### 3. Como deve estar o olhar?

Resposta esperada: Dirigido para a zona à frente, mantendo noção do piso próximo.

### 4. Deves forçar um contacto específico do pé?

Resposta esperada: Não; deves pousar o pé de forma controlada sem impor um apoio rígido.

### 5. Como se organizam os passos?

Resposta esperada: De forma alternada, transferindo o peso de um pé para o outro.

### 6. O que fazem os braços?

Resposta esperada: Acompanham naturalmente as pernas, sem rigidez nem exagero.

### 7. Como deves respirar?

Resposta esperada: De forma natural e contínua, sem retenções nem contagens obrigatórias.

### 8. Como mudas de direção?

Resposta esperada: Através de passos controlados, sem rodar sobre um único pé fixo.

### 9. Como terminas?

Resposta esperada: Completas o passo e recuperas uma posição estável de pé.

### 10. Que sinais obrigam a parar?

Resposta esperada: Desconforto no peito, falta de ar atípica, tontura, confusão, dor nova ou perda de controlo.

### 11. A caminhada exige supervisão por definição?

Resposta esperada: Não, mas certos sintomas, limitações ou contextos justificam avaliação ou orientação.

### 12. Este guia define uma dose de treino?

Resposta esperada: Não; não define ritmo, intensidade, duração, distância, frequência, séries ou repetições.

## Fontes e limites da evidência

### Fonte 1: Exercising Your Way to Lowering Your Blood Pressure

- Autor ou entidade: American College of Sports Medicine
- Tipo: organização profissional
- Localizador: https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf
- Usada para: Reconhecimento da caminhada como modalidade aeróbia da família.
- Limite: A1-S01 — American College of Sports Medicine — Exercising Your Way to Lowering Your Blood Pressure — https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf — organização profissional — Reconhecimento da caminhada como modalidade aeróbia da família. — Fonte de família; não sustenta identidade fina, dose ou resultado individual.

### Fonte 2: Recommendations for Adults

- Autor ou entidade: American Heart Association
- Tipo: organização profissional
- Localizador: https://www.heart.org/en/healthy-living/exercise-and-physical-activity/fitness-basics/aha-recs-for-physical-activity-in-adults
- Usada para: Reconhecimento da caminhada como exemplo de atividade física.
- Limite: A1-S03 — American Heart Association — Recommendations for Adults — https://www.heart.org/en/healthy-living/exercise-and-physical-activity/fitness-basics/aha-recs-for-physical-activity-in-adults — organização profissional — Reconhecimento da caminhada como exemplo de atividade física. — Não foi transportada qualquer recomendação de volume ou intensidade.

### Fonte 3: Investing in a Personal Trainer

- Autor ou entidade: American College of Sports Medicine
- Tipo: organização profissional
- Localizador: https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf
- Usada para: Confirmação da caminhada entre exemplos típicos de atividade aeróbia.
- Limite: A2-S04 — American College of Sports Medicine — Investing in a Personal Trainer — https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf — organização profissional — Confirmação da caminhada entre exemplos típicos de atividade aeróbia. — Lista exemplificativa; não é uma taxonomia mecânica.

### Fonte 4: Physical Activity Guidelines for Americans, 2nd edition

- Autor ou entidade: U.S. Department of Health and Human Services
- Tipo: orientação governamental
- Localizador: https://health.gov/sites/default/files/2019-09/Physical_Activity_Guidelines_2nd_edition.pdf
- Usada para: Contexto geral de atividade física e necessidade de opções adequadas à pessoa.
- Limite: A2-S05 — U.S. Department of Health and Human Services — Physical Activity Guidelines for Americans, 2nd edition — https://health.gov/sites/default/files/2019-09/Physical_Activity_Guidelines_2nd_edition.pdf — orientação governamental — Contexto geral de atividade física e necessidade de opções adequadas à pessoa. — Nenhuma recomendação de dose foi transportada.

### Fonte 5: Walking for health

- Autor ou entidade: NHS
- Tipo: orientação oficial de saúde
- Localizador: https://www.nhs.uk/live-well/exercise/walking-for-health/
- Usada para: Preparação e compatibilidade do calçado pessoal com conforto e apoio.
- Limite: EX01-R01 — NHS — Walking for health — https://www.nhs.uk/live-well/exercise/walking-for-health/ — orientação oficial de saúde — Preparação e compatibilidade do calçado pessoal com conforto e apoio. — As recomendações de duração e intensidade da página ficaram fora do conteúdo.

### Fonte 6: Advice on gait (walking)

- Autor ou entidade: Leicestershire Partnership NHS Trust
- Tipo: orientação profissional de fisioterapia
- Localizador: https://www.leicspart.nhs.uk/wp-content/uploads/2019/02/660-Advice-on-gait.pdf
- Usada para: Transferência de peso, balanço dos braços, apoio controlado e mudança de direção por passos.
- Limite: EX01-R02 — Leicestershire Partnership NHS Trust — Advice on gait (walking) — https://www.leicspart.nhs.uk/wp-content/uploads/2019/02/660-Advice-on-gait.pdf — orientação profissional de fisioterapia — Transferência de peso, balanço dos braços, apoio controlado e mudança de direção por passos. — Material clínico de marcha; a indicação calcanhar-ponta foi convertida em orientação não rígida e não universal.

### Fonte 7: Pedestrian Safety: Prevent Pedestrian Crashes

- Autor ou entidade: National Highway Traffic Safety Administration
- Tipo: orientação governamental de segurança rodoviária
- Localizador: https://www.nhtsa.gov/road-safety/pedestrian-safety
- Usada para: Atenção visual e auditiva, travessias e risco de interação com veículos.
- Limite: EX01-R03 — National Highway Traffic Safety Administration — Pedestrian Safety: Prevent Pedestrian Crashes — https://www.nhtsa.gov/road-safety/pedestrian-safety — orientação governamental de segurança rodoviária — Atenção visual e auditiva, travessias e risco de interação com veículos. — Aplica-se a percursos expostos a tráfego, não à mecânica do exercício.

### Fonte 8: Exercising in Hot and Cold Environments

- Autor ou entidade: American College of Sports Medicine
- Tipo: orientação de organização profissional
- Localizador: https://acsm.org/wp-content/uploads/2025/02/Exercising-in-hot-and-cold-environments.pdf
- Usada para: Modificadores ambientais e sinais como confusão, tontura ou desorientação.
- Limite: EX01-R04 — American College of Sports Medicine — Exercising in Hot and Cold Environments — https://acsm.org/wp-content/uploads/2025/02/Exercising-in-hot-and-cold-environments.pdf — orientação de organização profissional — Modificadores ambientais e sinais como confusão, tontura ou desorientação. — Fonte geral de exercício em ambiente térmico; não define a técnica de caminhada.

### Fonte 9: Rehabilitation Following COVID-19

- Autor ou entidade: Royal Devon University Healthcare NHS Foundation Trust
- Tipo: orientação hospitalar de reabilitação
- Localizador: https://www.royaldevon.nhs.uk/media/vcxdfzst/rehabilitation-following-covid-19.pdf
- Usada para: Sustento limitado para evitar a retenção da respiração durante atividades gerais.
- Limite: EX01-R05 — Royal Devon University Healthcare NHS Foundation Trust — Rehabilitation Following COVID-19 — https://www.royaldevon.nhs.uk/media/vcxdfzst/rehabilitation-following-covid-19.pdf — orientação hospitalar de reabilitação — Sustento limitado para evitar a retenção da respiração durante atividades gerais. — População clínica específica; não foi transportada qualquer técnica respiratória terapêutica nem prescrição.

### Fonte 10: OTAGO Strength and Balance

- Autor ou entidade: Oxford University Hospitals NHS Foundation Trust
- Tipo: orientação hospitalar de fisioterapia
- Localizador: https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf
- Usada para: Atenção à estabilidade, apoio adequado à necessidade e interrupção perante dor no peito, tontura ou falta de ar grave.
- Limite: EX01-R06 — Oxford University Hospitals NHS Foundation Trust — OTAGO Strength and Balance — https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf — orientação hospitalar de fisioterapia — Atenção à estabilidade, apoio adequado à necessidade e interrupção perante dor no peito, tontura ou falta de ar grave. — Programa dirigido à prevenção de quedas; usado apenas como apoio de segurança e não como prescrição de caminhada.
