# Relatório de investigação — Sprint com paragem controlada

**Agente:** EX-18  
**Exercise ID:** `sprint_to_controlled_stop`  
**Data da pesquisa:** 23 de julho de 2026  
**Classificação de risco preservada:** elevada  
**Implementação realizada: não**

## Âmbito

Este relatório fundamenta conteúdo documental para principiantes sobre execução, desaceleração, respiração, segurança, travagem, erros e supervisão. Não altera identidade, risco, equipamento, superfície, relações canónicas ou estado de multimédia. Não inclui prescrição, dose, diagnóstico, tratamento, promessa de resultado, código ou publicação.

Foram preservados:

- a entrada em sprint linear;

- a travagem por passos sucessivos;

- o fim bipodal, estável e orientado para a frente;

- a ausência de equipamento obrigatório;

- a superfície firme, regular e antiderrapante;

- o corredor linear com zona de desaceleração;

- as duas relações aprovadas, incluindo o caráter condicional do uso no aquecimento;

- o requisito canónico de supervisão recomendada e os gatilhos de primeira exposição e aumento de velocidade ou impacto.

## Perguntas de investigação

1. Que organização corporal distingue a desaceleração da aceleração?
2. Porque deve a travagem ser distribuída por vários contactos?
3. Que elementos permitem reconhecer uma paragem controlada?
4. Como descrever o espaço de travagem sem inventar uma distância universal?
5. Qual é a saída mais segura quando a pessoa não vai parar onde esperava?
6. Que orientação respiratória é sustentável sem impor um padrão artificial?
7. O que justifica supervisão e familiarização na primeira exposição?
8. Que erros observáveis podem ser descritos sem diagnóstico ou prescrição?

## Fontes consultadas

| Código | Fonte | Tipo | Contributo principal | Limite |
|---|---|---|---|---|
| SP-B2-S11 | [NSCA — Acceleration and Deceleration Mechanics](https://www.nsca.com/education/articles/kinetic-select/acceleration-and-deceleration-mechanics/) | Organização profissional | A desaceleração usa flexão coordenada do tornozelo, joelho e anca; o tronco fica mais vertical ou ligeiramente posterior; os passos encurtam e o contacto tende a prolongar-se. | Orientação profissional, não estudo em principiantes absolutos. |
| B1-S21 | [Harper et al. — Measuring maximal horizontal deceleration ability using radar technology](https://doi.org/10.1080/14763141.2020.1792968) | Estudo biomecânico primário | Trata a travagem horizontal como fase mensurável, incluindo tempo e distância até parar; o protocolo teve demonstração, familiarização e supervisão. | Atletas universitários familiarizados com desaceleração; protocolo de teste não é prescrição pública. |
| SP-B2-S21 | [McBurnie et al. — Deceleration Training in Team Sports](https://pmc.ncbi.nlm.nih.gov/articles/PMC8761154/) | Revisão científica | Enquadra a desaceleração como exigência mecânica distinta, com trabalho ativo de travagem e carregamento relevante. | Evidência de família, não valida uma técnica única nem uma dose universal. |
| EX18-S04 | [Philipp et al. — Acute effects of lower limb wearable resistance on horizontal deceleration and change of direction biomechanics](https://doi.org/10.1371/journal.pone.0308536) | Estudo biomecânico primário independente | Analisa parâmetros de desaceleração e passos de travagem; incluiu aquecimento, ensaio da tarefa, familiarização e supervisão por especialista. | Adultos treinados; o componente com resistência vestível não é transferido para a identidade sem equipamento. |
| EX18-S05 | [American Heart Association — Getting Active to Control High Blood Pressure](https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure) | Orientação oficial de saúde | Recomenda respiração regular durante a atividade e evitar prender voluntariamente a respiração. | Não é específica para sprint; não suporta sincronização respiratória rígida. |
| EX18-S06 | [England Athletics — Leadership in Running Fitness](https://www.englandathletics.org/coaches-and-officials/coaching-qualifications/leadership-in-running-fitness/) | Federação nacional; enquadramento profissional | Valoriza avaliação de risco, aquecimento, técnica, instruções claras, demonstração e supervisão na condução de corrida. | Formação de líderes, não estudo experimental deste drill. |

As fontes biomecânicas primárias são independentes quanto a equipas e instituições: Harper et al. trabalharam a partir da University of Central Lancashire, Université Côte d’Azur e contexto de desempenho da federação francesa; Philipp et al. trabalharam na University of Kansas.

## Síntese da evidência

### Mecânica de aceleração e travagem

A orientação profissional da NSCA distingue claramente as duas fases. Na aceleração, a organização favorece propulsão horizontal; na travagem, o tronco torna-se mais vertical ou ligeiramente inclinado para trás e tornozelo, joelho e anca participam numa flexão coordenada. A NSCA também descreve passos mais curtos e contactos progressivamente mais longos durante a redução da velocidade.

Esta evidência apoia linguagem simples como “fica mais vertical”, “flete tornozelos, joelhos e ancas” e “usa vários passos”. Não sustenta ângulos articulares-alvo para o público nem uma técnica idêntica para todas as pessoas.

### Exigência da travagem

Harper et al. mostram que uma fase horizontal de desaceleração pode ser delimitada e descrita por velocidade, tempo, distância, força, potência e impulso. O trabalho de Philipp et al. reforça que as características biomecânicas mudam com as condições da tarefa. A revisão de McBurnie et al. descreve a desaceleração como uma exigência distinta, associada a elevada receção de força e ação muscular de travagem.

Daqui resulta uma decisão conservadora: não orientar o principiante a “parar o mais depressa possível” nem a travar num contacto. O conteúdo pede distribuição por vários passos e separa a identidade do exercício da velocidade concreta prescrita.

### Distância e espaço de travagem

Os estudos medem tempo e distância até parar, mas não oferecem uma distância segura universal para principiantes. A distância depende, entre outros fatores, da velocidade de entrada, do momento corporal, da estratégia, da experiência e da superfície.

Por isso, o conteúdo não apresenta metros nem uma marca fixa. Define uma arquitetura de espaço:

1. corredor de entrada;
2. zona ampla de travagem;
3. zona de saída reta além da paragem pretendida.

A regra operacional é fechada: se o supervisor não puder confirmar margem suficiente para travar ou continuar em frente, a tentativa não começa.

### Estratégia de saída

Não foi encontrada uma comparação experimental direta entre estratégias de falha para principiantes. A solução foi inferida conservadoramente a partir da identidade linear, da necessidade de distribuir o impulso de travagem por mais tempo e do risco de acrescentar uma mudança de direção brusca.

Se a pessoa já está em movimento e percebe que não vai parar onde planeava, a estratégia documentada é:

- manter orientação frontal;

- continuar pela zona de saída previamente desimpedida;

- usar mais passos naturais de desaceleração;

- não plantar um único pé, virar, cair ou procurar um obstáculo.

Esta é uma inferência de segurança, não uma técnica clinicamente validada. O controlo principal continua a ser preventivo: não arrancar sem zona de saída livre.

### Respiração

A American Heart Association recomenda respirar regularmente durante a atividade e evitar prender a respiração. Não foi encontrada evidência específica que justifique um ciclo respiratório rígido no sprint com paragem.

O conteúdo usa, portanto, a orientação mínima defensável: respiração natural, contínua e sem retenção voluntária; a expiração pode ocorrer espontaneamente durante a desaceleração, sem contagens. Dificuldade respiratória inesperada, desconforto no peito ou tonturas são sinais de interrupção, não alvos técnicos a ultrapassar.

### Supervisão e primeira exposição

Os dois estudos biomecânicos primários envolveram pessoas treinadas e usaram familiarização, ensaio da tarefa e supervisão. A England Athletics inclui avaliação de risco, demonstração, instrução clara e supervisão no enquadramento de liderança segura de corrida.

Isto não prova que uma forma específica de supervisão elimine o risco, mas demonstra que a evidência técnica foi recolhida em contextos controlados, não através de autoaprendizagem de principiantes absolutos. A decisão de conteúdo é, por isso, explícita: uma explicação clara não autoriza prática autónoma no primeiro dia.

## Decisões de redação

| Tema | Decisão | Justificação |
|---|---|---|
| Velocidade | Não indicar valor, percentagem ou intensidade. | Pertence à prescrição; altera a exigência e o espaço necessário. |
| Distância | Não indicar metros. | Não existe valor seguro universal nas fontes consultadas. |
| Travagem | Vários apoios, sem paragem num só passo. | Distribui a redução do momento e preserva controlo linear. |
| Tronco | “Progressivamente mais vertical”, sem ângulo-alvo. | Coerente com a NSCA e mais adequado à variabilidade individual. |
| Pé | Não impor um tipo rígido de contacto. | A evidência descreve tendências, mas o foco público é controlo global e não uma posição universal. |
| Respiração | Natural, regular, contínua e sem retenção. | É a orientação específica mínima sustentada; não há base para contagens. |
| Fim | Apoio bipodal estável e frontal. | Preserva a identidade canónica. |
| Falha | Continuar em frente pela zona de saída e usar mais passos. | Evita acrescentar corte, rotação, queda ou colisão deliberada. |
| Primeira exposição | Supervisão presencial obrigatória no conteúdo para principiantes. | Risco elevado, gatilho canónico e fontes baseadas em demonstração/familiarização. |
| Equipamento | Nenhum; não sugerir cargas ou barreiras. | Preserva o registo canónico e evita transferir condições de estudos com carga. |

## Erros priorizados

Foram selecionados erros que um principiante ou supervisor consegue observar sem avaliação clínica:

- começar a travar demasiado tarde;

- tentar parar num único passo;

- rodar ou cortar para conseguir parar;

- bloquear os joelhos ou dobrar apenas a cintura;

- terminar sem apoio bipodal estável;

- prender a respiração.

Cada erro inclui sinal observável e correção documental. As correções não prescrevem uma progressão nem autorizam repetição imediata; quando o erro envolve espaço, velocidade ou controlo, remetem a decisão para o supervisor.

## Salvaguardas de risco elevado

### Competência prévia

Compreender e interromper a tarefa; demonstrar corrida linear antecedente e desaceleração frontal controlada; reconhecer o fim bipodal. O supervisor confirma estes pontos.

### Recomendação de supervisão

Presencial e indispensável na primeira exposição. O supervisor fica fora da trajetória, controla o corredor, define a condição de entrada, demonstra, observa e interrompe.

### Espaço seguro

Corredor linear totalmente livre, superfície firme, regular e antiderrapante, zona de travagem ampla e zona de saída adicional. Ausência de parede, vedação, trânsito, cruzamento público ou espectadores no alinhamento.

### Controlo de travagem

Redução por passos sucessivos, flexão coordenada dos membros inferiores, orientação frontal e fim bipodal estável. Rotação, salto, bloqueio brusco ou apoio de emergência indicam falha de controlo.

### Saída perante falha

Continuar em frente pela rota livre e usar mais passos, sem virar, cair ou procurar apoio. Sem zona de saída livre, não há tentativa.

## Limitações

- A evidência direta incide sobretudo em atletas e adultos treinados.

- Não foram identificados estudos diretos de primeira exposição em principiantes absolutos.

- Não foi encontrada uma distância universal de travagem segura.

- A orientação respiratória é geral e oficial, mas não específica deste drill.

- A estratégia de saída é uma inferência conservadora baseada na mecânica e na preservação de uma rota linear; não é resultado de um ensaio comparativo.

- O documento não avalia elegibilidade individual nem substitui revisão profissional ou clínica quando aplicável.

- O uso condicional no aquecimento permanece dependente de lógica de produto não resolvida.

- Nenhuma fonte sustenta dose, prescrição, promessa de resultado ou autorização universal para executar.

## Conclusão

Existe suporte moderado para explicar a mecânica geral da travagem linear e para exigir uma organização preventiva do espaço. A evidência é insuficiente para fixar distância, velocidade ou prática autónoma para principiantes. O conteúdo final conserva o risco elevado, exige supervisão na primeira exposição e faz da zona de saída reta uma condição de preparação, não uma improvisação depois de a travagem falhar.
