# EveFit Beginner Content Wave1 v0.1.2 — Relatório de validação

Resultado: **APROVADO**.

- Verificações: 1200
- Falhas: 0
- Exercícios: 49 de 49
- Ficheiros individuais: 147
- Markdown individuais: 49
- JSON individuais: 49
- Relatórios de investigação: 49
- Auditorias por capacidade: 7
- Auditorias transversais: 7
- JSON válidos: 51 de 51
- Markdown-JSON coerentes: 49 de 49
- Exercícios alterados: 7
- Campos ou itens públicos alterados: 20
- Identificadores técnicos removidos: 29
- Enums técnicos removidos: 4
- Tokens técnicos públicos restantes: 0
- Formas formais dirigidas restantes: 0
- IDs, estados, variantes, risco, relações, supervisão e fontes: preservados
- Dose e prescrição introduzidas: zero
- UTF-8 e Unicode NFC: aprovados
- Implementação, alteração da app e publicação: não

## Falhas

- Nenhuma.
