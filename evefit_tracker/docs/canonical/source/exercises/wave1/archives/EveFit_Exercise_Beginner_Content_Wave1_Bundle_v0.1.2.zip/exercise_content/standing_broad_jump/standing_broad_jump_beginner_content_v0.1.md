# Salto horizontal bipodal parado

Conteúdo para principiantes em português europeu.

## Descrição curta

Salto horizontal isolado com impulsão e receção nos dois pés.

## O que é

Partes parado sobre os dois pés, projetas o corpo para a frente numa única impulsão e recebes o solo com ambos os pés, terminando em equilíbrio sem ligar outro salto.

## O que vais fazer

Vais verificar o espaço, organizar a posição de partida, preparar a impulsão com a anca e os joelhos, usar os dois pés para sair do solo, preparar os pés durante a fase aérea e absorver a receção antes de te endireitares.

## Porque existe este movimento

Este movimento pratica a projeção balística horizontal do corpo e o controlo de uma receção bipodal. A explicação descreve a técnica; não atribui uma distância, esforço, volume ou resultado.

## Antes de começares

1. Não executes este exercício de forma autónoma no primeiro dia. A primeira exposição deve ser demonstrada e observada por um profissional de exercício qualificado, que confirme a compreensão da tarefa, a competência de receção bipodal, a condição da superfície e a área frontal livre. Não comeces se houver dor aguda, mal-estar, perda de coordenação ou incapacidade de controlar a travagem.

## Preparar o equipamento

1. Não é necessário equipamento. Retira objetos soltos do corpo e da zona de salto. Se usares calçado, confirma que está bem ajustado e que a sola não escorrega; o calçado não substitui a verificação do piso.

## Preparar o espaço

1. Escolhe uma superfície firme, plana, regular e não escorregadia, com boa visibilidade. Deixa livre todo o corredor à frente, incluindo a zona provável de receção e espaço adicional para recuperar o equilíbrio. Garante altura livre e impede a passagem de pessoas, animais ou objetos.

## Verificação do corpo

1. Com supervisão, confirma que consegues ficar estável sobre os dois pés, dobrar a anca e os joelhos mantendo os pés apoiados e assumir uma posição de receção bipodal silenciosa e controlada sem dor, mal-estar ou perda de coordenação. Se o controlo não estiver presente, fica pelos ensaios preparatórios indicados pelo supervisor e não realizes o salto completo.

## Posição inicial

Fica de pé, voltado para a área livre, com os pés paralelos e aproximadamente à largura da anca, ambos totalmente apoiados. Distribui o peso pelos dois pés, mantém o tronco organizado e deixa os braços disponíveis para balançar.

## Confirmar a posição inicial

1. Os dois pés estão apoiados, paralelos e estáveis.
2. A zona de receção e o espaço para recuperar o equilíbrio estão livres.
3. O piso está firme, regular, seco e não escorregadio.
4. Tens altura e espaço frontal suficientes.
5. Consegues dobrar anca e joelhos sem dor, mal-estar ou perda de coordenação.
6. Na primeira exposição, o profissional está presente e pronto para observar.

## Passos de execução

1. Olha para a zona livre onde pretendes receber o solo e confirma novamente que ninguém vai atravessar o percurso.
2. Leva a anca para trás e dobra a anca e os joelhos, mantendo ambos os pés apoiados; acompanha a preparação levando os braços para trás.
3. Muda de direção de forma coordenada e empurra o solo com os dois pés, estendendo anca, joelhos e tornozelos enquanto os braços balançam para a frente.
4. Durante a fase aérea, mantém os pés próximos e paralelos e traz as pernas para a frente apenas o necessário para preparar a receção; não tentes procurar mais distância à custa do equilíbrio.
5. Recebe o solo com os dois pés quase ao mesmo tempo, deixando o contacto avançar para o pé inteiro.
6. Absorve o contacto dobrando de imediato a anca e os joelhos, com estes orientados na direção dos pés, e mantém o tronco controlado.
7. Fica na posição de receção até o corpo estar estável; só depois te endireitas ou sais da zona a andar.

## Fases do movimento

### Preparação

Confirma o espaço, mantém os dois apoios e cria o contramovimento com a anca, os joelhos e os braços.

### Impulsão

Empurra o solo simultaneamente com os dois pés e coordena a extensão dos membros inferiores com o balanço dos braços.

### Voo

O corpo desloca-se para a frente sem contacto com o solo; os pés preparam-se juntos para a receção.

### Receção e travagem

Os dois pés contactam o solo e a anca e os joelhos dobram para absorver o impacto.

### Estabilização

Mantém a posição final sem novo salto até recuperares controlo.

## Respiração

Respira de forma natural e contínua durante a preparação. Podes deixar sair o ar durante a impulsão, sem forçar nem seguir uma contagem, e retomar a respiração normal depois de estabilizar. Não retenhas voluntariamente a respiração. Não foi encontrada uma sequência respiratória específica validada para este exercício.

## Sensações esperadas

1. Esforço breve e coordenado nas ancas, coxas e pernas durante a impulsão.
2. Sensação de deslocamento para a frente durante a fase aérea.
3. Contacto distribuído pelos dois pés.
4. Trabalho muscular nas ancas e pernas ao dobrar para travar e estabilizar.

## Sensações inesperadas ou de alerta

1. Dor aguda ou dor que surge subitamente.
2. Tontura, sensação de desmaio, falta de ar invulgar ou mal-estar.
3. Sensação de cedência, bloqueio ou perda súbita de controlo num membro.
4. Impacto doloroso ou incapacidade de manter a receção.
5. Perda súbita de coordenação ou equilíbrio que obrigue a uma queda.

## Indicações técnicas principais

1. Confirma primeiro a zona de receção.
2. Prepara com a anca para trás e os dois pés no chão.
3. Empurra o solo com os dois pés ao mesmo tempo.
4. Leva os pés juntos para a receção.
5. Aterra silencioso e dobra anca e joelhos.
6. Estabiliza antes de saíres da posição.
7. Na receção, deixa tornozelos, joelhos e ancas cederem de forma coordenada e mantém os pés estáveis.

## Erros comuns e correções

### Erro 1: Saltar sem verificar toda a zona frontal.

- Como reconhecer: Há objetos, pessoas, piso irregular ou espaço insuficiente na trajetória ou após a zona de receção.
- Como corrigir: Não saltes. Liberta e verifica o corredor completo antes de assumir a posição de partida.

### Erro 2: Perder um dos apoios antes da impulsão ou sair com os pés em tempos claramente diferentes.

- Como reconhecer: Um pé levanta, roda ou desliza antes do outro, ou a impulsão deixa de ser bipodal.
- Como corrigir: Reorganiza os pés paralelos, distribui o peso e ensaia a preparação sem sair do solo sob observação.

### Erro 3: Tentar ganhar distância esticando demasiado os pés à frente.

- Como reconhecer: Os calcanhares chegam muito à frente das ancas e o corpo cai para trás ou precisa de apoiar as mãos.
- Como corrigir: Prioriza uma receção que consigas travar; traz os pés para a frente apenas o necessário e mantém o tronco preparado para acompanhar a aterragem.

### Erro 4: Aterrar rígido.

- Como reconhecer: O contacto é ruidoso e a anca e os joelhos quase não dobram.
- Como corrigir: Prepara a flexão antes do contacto e deixa a anca e os joelhos dobrar assim que os pés tocam no solo.

### Erro 5: Deixar os joelhos deslocarem-se marcadamente para dentro na receção.

- Como reconhecer: Os joelhos aproximam-se um do outro e deixam de acompanhar a direção dos pés.
- Como corrigir: Mantém os pés paralelos e orienta os joelhos na mesma direção durante a absorção; interrompe se não conseguires controlar esta posição.

### Erro 6: Ligar imediatamente outro salto ou sair antes de estabilizar.

- Como reconhecer: Há ressalto, passo precipitado ou nova impulsão antes de a posição final ficar controlada.
- Como corrigir: Mantém a posição de receção até recuperares equilíbrio; este exercício termina aí.

## Formas de simplificar ou ensaiar

1. Ensaiar apenas a posição de receção, sem salto. — É um ensaio preparatório e não conta como execução do exercício completo.
2. Ensaiar o movimento de anca e o balanço dos braços mantendo os pés no chão. — Serve para compreender a preparação, sem fase balística ou aérea.
3. Usar uma marca visual apenas como referência de direção, colocada pelo supervisor. — A marca não é uma distância-alvo, não deve exigir alcançar um ponto e não altera a obrigação de aterrar com controlo.

## Supervisão

A supervisão é recomendada para este exercício de risco operacional alto e é necessária na primeira exposição técnica do principiante. O profissional deve demonstrar, verificar a competência de receção, observar de frente e de lado sem ocupar a trajetória, controlar o acesso à zona e interromper perante perda de coordenação, receção rígida, assimetria evidente, dor ou mal-estar. Esta explicação não autoriza execução autónoma no primeiro dia.

## Como terminar

Depois da receção, permanece estável sobre os dois pés. Quando estiveres equilibrado, endireita-te sem ressalto e abandona a zona a andar, confirmando que o percurso fica livre. Se tiveres precisado de passos, mãos no chão ou queda para recuperar, considera a tentativa terminada, não repitas de imediato e comunica-o ao supervisor.

## Nota de segurança

É um salto com fase aérea e impacto alto. Usa apenas uma superfície firme, plana, regular e não escorregadia, com o caminho frontal totalmente desimpedido. A prioridade é receber e travar com controlo, não alcançar distância. Interrompe perante dor aguda, mal-estar, perda súbita de coordenação ou incapacidade de controlar a receção.

## Quando parar ou reduzir

1. Dor aguda.
2. Mal-estar, tontura ou sensação de desmaio.
3. Perda súbita de coordenação.
4. Incapacidade de controlar a travagem ou a receção.
5. Queda, apoio involuntário das mãos ou necessidade repetida de passos para não cair.
6. Alteração inesperada da superfície, iluminação ou circulação na área.
7. Para perante este sinal de alerta: Dor aguda ou dor que surge subitamente.
8. Para perante este sinal de alerta: Tontura, sensação de desmaio, falta de ar invulgar ou mal-estar.
9. Para perante este sinal de alerta: Sensação de cedência, bloqueio ou perda súbita de controlo num membro.
10. Para perante este sinal de alerta: Impacto doloroso ou incapacidade de manter a receção.
11. Para perante este sinal de alerta: Perda súbita de coordenação ou equilíbrio que obrigue a uma queda.

## Segurança do equipamento

Não existe equipamento obrigatório. Não acrescentes obstáculos, caixas, barreiras, pesos ou superfícies instáveis. Qualquer marca visual deve ficar plana, não escorregar e não criar um alvo obrigatório. Verifica atacadores, sola e objetos pessoais antes de saltar.

## Segurança do espaço

São adequados um ginásio, pavilhão interior ou campo exterior apenas quando oferecem piso firme, regular e não escorregadio, boa visibilidade, altura livre, espaço frontal e zona de receção desimpedida. Não uses superfícies molhadas, soltas, inclinadas, instáveis ou escorregadias, nem zonas com trânsito, cruzamento público ou pessoas a circular.

## Limitações

1. A literatura direta sobre o salto horizontal parado concentra-se sobretudo em desempenho e em amostras pequenas ou específicas; a evidência de aterragem inclui outras tarefas de salto e não permite inferir risco individual. Não foi encontrada uma cadência respiratória específica validada para este exercício. O conteúdo não substitui avaliação profissional, não autoriza execução autónoma no primeiro dia e não contém prescrição. Implementação realizada: não.

## Teste de compreensão

### 1. Qual é a primeira coisa a confirmar antes de saltar?

Resposta esperada: Que todo o corredor frontal, a zona de receção e o espaço para recuperar o equilíbrio estão livres e seguros.

### 2. Podes executar autonomamente no primeiro dia?

Resposta esperada: Não. A primeira exposição deve ser demonstrada e observada por um profissional qualificado.

### 3. Com quantos pés se inicia a impulsão?

Resposta esperada: Com os dois pés apoiados e a empurrar o solo de forma coordenada.

### 4. O que fazem a anca e os joelhos na preparação?

Resposta esperada: A anca vai para trás e a anca e os joelhos dobram, mantendo os pés apoiados.

### 5. O que deves fazer com os pés durante a fase aérea?

Resposta esperada: Mantê-los próximos e paralelos e prepará-los para uma receção bipodal.

### 6. Como deve soar uma receção controlada?

Resposta esperada: Relativamente silenciosa, sem impacto rígido ou estrondo.

### 7. O que fazem a anca e os joelhos quando os pés contactam o solo?

Resposta esperada: Dobram de imediato para ajudar a absorver e travar o contacto.

### 8. Para onde devem apontar os joelhos durante a receção?

Resposta esperada: Na mesma direção dos pés, sem colapso marcado para dentro.

### 9. Quando termina o exercício?

Resposta esperada: Quando a receção fica estabilizada sobre os dois pés, sem ligar outro salto.

### 10. Deves prender a respiração para saltar?

Resposta esperada: Não. A respiração deve manter-se natural e contínua, sem retenção voluntária.

### 11. O que fazes se precisares de passos ou das mãos para evitar uma queda?

Resposta esperada: Termino a tentativa, recupero a segurança, informo o supervisor e não começo nova tentativa.

### 12. Que sinais obrigam a parar?

Resposta esperada: Dor aguda, mal-estar, tontura, perda súbita de coordenação ou incapacidade de controlar a travagem e a receção.

## Fontes e limites da evidência

### Fonte 1: Forward Linear Jumps

- Autor ou entidade: ACE_FORWARD_LINEAR_JUMPS — Forward Linear Jumps — American Council on Exercise — orientação profissional de técnica — https://www.acefitness.org/resources/everyone/exercise-library/177/forward-linear-jumps/ — 2026-07-23 — Posição inicial, preparação da anca, extensão coordenada, preparação dos pés e absorção da receção.
- Tipo: orientação profissional de técnica
- Localizador: https://www.acefitness.org/resources/everyone/exercise-library/177/forward-linear-jumps/
- Usada para: Posição inicial, preparação da anca, extensão coordenada, preparação dos pés e absorção da receção.
- Limite: ACE_FORWARD_LINEAR_JUMPS — Forward Linear Jumps — American Council on Exercise — orientação profissional de técnica — https://www.acefitness.org/resources/everyone/exercise-library/177/forward-linear-jumps/ — 2026-07-23 — Posição inicial, preparação da anca, extensão coordenada, preparação dos pés e absorção da receção.

### Fonte 2: Plyometric Implementation: Setup and Execution of Jump Landing Positions to Decrease Likelihood of Injuries

- Autor ou entidade: NSCA_LANDOW_2016 — Plyometric Implementation: Setup and Execution of Jump Landing Positions to Decrease Likelihood of Injuries — National Strength and Conditioning Association; Loren Landow — formação profissional — https://www.nsca.com/education/videos/plyometric-implementation-setup-and-execution-of-jump-landing-positions-to-decrease-likelihood-of-injuries/ — 2026-07-23 — Competência de aterragem, progressão por capacidade e prioridade ao controlo das estruturas na receção.
- Tipo: formação profissional
- Localizador: https://www.nsca.com/education/videos/plyometric-implementation-setup-and-execution-of-jump-landing-positions-to-decrease-likelihood-of-injuries/
- Usada para: Competência de aterragem, progressão por capacidade e prioridade ao controlo das estruturas na receção.
- Limite: NSCA_LANDOW_2016 — Plyometric Implementation: Setup and Execution of Jump Landing Positions to Decrease Likelihood of Injuries — National Strength and Conditioning Association; Loren Landow — formação profissional — https://www.nsca.com/education/videos/plyometric-implementation-setup-and-execution-of-jump-landing-positions-to-decrease-likelihood-of-injuries/ — 2026-07-23 — Competência de aterragem, progressão por capacidade e prioridade ao controlo das estruturas na receção.

### Fonte 3: A Beginner’s Guide to Plyometrics Workouts

- Autor ou entidade: HSS_ACCETTA_2026 — A Beginner’s Guide to Plyometrics Workouts — Hospital for Special Surgery; Matthew Accetta — orientação profissional clínica para principiantes — https://www.hss.edu/health-library/move-better/plyometrics-workouts-for-beginner — 2026-07-23 — Aprender primeiro a receção, observar alinhamento e reconhecer aterragem ruidosa como absorção insuficiente.
- Tipo: orientação profissional clínica para principiantes
- Localizador: https://www.hss.edu/health-library/move-better/plyometrics-workouts-for-beginner
- Usada para: Aprender primeiro a receção, observar alinhamento e reconhecer aterragem ruidosa como absorção insuficiente.
- Limite: HSS_ACCETTA_2026 — A Beginner’s Guide to Plyometrics Workouts — Hospital for Special Surgery; Matthew Accetta — orientação profissional clínica para principiantes — https://www.hss.edu/health-library/move-better/plyometrics-workouts-for-beginner — 2026-07-23 — Aprender primeiro a receção, observar alinhamento e reconhecer aterragem ruidosa como absorção insuficiente.

### Fonte 4: Optimum take-off angle in the standing long jump

- Autor ou entidade: WAKAI_LINTHORNE_2005 — Optimum take-off angle in the standing long jump — Masaki Wakai e Nicholas P. Linthorne — estudo biomecânico primário — https://bura.brunel.ac.uk/bitstream/2438/537/1/%27Standing%20Long%20Jump%27%20Post-print.pdf — 10.1016/j.humov.2004.12.001 — 2026-07-23 — Identidade mecânica, contramovimento, balanço bilateral dos braços, impulsão bipodal, preparação das pernas e necessidade de manter equilíbrio após a receção.
- Tipo: estudo biomecânico primário
- Localizador: https://bura.brunel.ac.uk/bitstream/2438/537/1/%27Standing%20Long%20Jump%27%20Post-print.pdf
- Usada para: Identidade mecânica, contramovimento, balanço bilateral dos braços, impulsão bipodal, preparação das pernas e necessidade de manter equilíbrio após a receção.
- Limite: WAKAI_LINTHORNE_2005 — Optimum take-off angle in the standing long jump — Masaki Wakai e Nicholas P. Linthorne — estudo biomecânico primário — https://bura.brunel.ac.uk/bitstream/2438/537/1/%27Standing%20Long%20Jump%27%20Post-print.pdf — 10.1016/j.humov.2004.12.001 — 2026-07-23 — Identidade mecânica, contramovimento, balanço bilateral dos braços, impulsão bipodal, preparação das pernas e necessidade de manter equilíbrio após a receção.

### Fonte 5: Biomechanical Analysis of the Standing Long Jump

- Autor ou entidade: WU_ET_AL_2003 — Biomechanical Analysis of the Standing Long Jump — Wen-Lan Wu, Jia-Hroung Wu, Hwai-Ting Lin e Gwo-Jaw Wang — estudo biomecânico primário — https://www.worldscientific.com/doi/abs/10.4015/S1016237203000286 — 10.4015/S1016237203000286 — 2026-07-23 — Papel do balanço dos braços e da configuração do joelho na preparação do salto.
- Tipo: estudo biomecânico primário
- Localizador: https://www.worldscientific.com/doi/abs/10.4015/S1016237203000286
- Usada para: Papel do balanço dos braços e da configuração do joelho na preparação do salto.
- Limite: WU_ET_AL_2003 — Biomechanical Analysis of the Standing Long Jump — Wen-Lan Wu, Jia-Hroung Wu, Hwai-Ting Lin e Gwo-Jaw Wang — estudo biomecânico primário — https://www.worldscientific.com/doi/abs/10.4015/S1016237203000286 — 10.4015/S1016237203000286 — 2026-07-23 — Papel do balanço dos braços e da configuração do joelho na preparação do salto.

### Fonte 6: Effect of different landing actions on knee joint biomechanics of female college athletes: Based on OpenSim simulation

- Autor ou entidade: CHEN_ET_AL_2022 — Effect of different landing actions on knee joint biomechanics of female college athletes: Based on OpenSim simulation — Liang Chen, Ziang Jiang, Chen Yang, Rongshan Cheng, Size Zheng e Jingguang Qian — estudo biomecânico primário — https://www.frontiersin.org/journals/bioengineering-and-biotechnology/articles/10.3389/fbioe.2022.899799/full — 10.3389/fbioe.2022.899799 — 2026-07-23 — Apoio à flexão do joelho como componente da estratégia de absorção na aterragem, com limites de generalização.
- Tipo: estudo biomecânico primário
- Localizador: https://www.frontiersin.org/journals/bioengineering-and-biotechnology/articles/10.3389/fbioe.2022.899799/full
- Usada para: Apoio à flexão do joelho como componente da estratégia de absorção na aterragem, com limites de generalização.
- Limite: CHEN_ET_AL_2022 — Effect of different landing actions on knee joint biomechanics of female college athletes: Based on OpenSim simulation — Liang Chen, Ziang Jiang, Chen Yang, Rongshan Cheng, Size Zheng e Jingguang Qian — estudo biomecânico primário — https://www.frontiersin.org/journals/bioengineering-and-biotechnology/articles/10.3389/fbioe.2022.899799/full — 10.3389/fbioe.2022.899799 — 2026-07-23 — Apoio à flexão do joelho como componente da estratégia de absorção na aterragem, com limites de generalização.

### Fonte 7: Exercise for the Prevention and Treatment of Hypertension

- Autor ou entidade: ACSM_BREATHING — Exercise for the Prevention and Treatment of Hypertension — American College of Sports Medicine — orientação profissional — https://acsm.org/exercise-for-the-prevention-and-treatment-of-hypertension/ — 2026-07-23 — Fundamento geral para evitar retenção voluntária da respiração durante esforço; não fornece cadência específica para este salto.
- Tipo: orientação profissional
- Localizador: https://acsm.org/exercise-for-the-prevention-and-treatment-of-hypertension/
- Usada para: Fundamento geral para evitar retenção voluntária da respiração durante esforço; não fornece cadência específica para este salto.
- Limite: ACSM_BREATHING — Exercise for the Prevention and Treatment of Hypertension — American College of Sports Medicine — orientação profissional — https://acsm.org/exercise-for-the-prevention-and-treatment-of-hypertension/ — 2026-07-23 — Fundamento geral para evitar retenção voluntária da respiração durante esforço; não fornece cadência específica para este salto.
