# Relatório de investigação — `lateral_costal_breathing`

## Resultado

Foi produzida cobertura defensável para conteúdo de principiante, com confiança global moderada. A identidade canónica, o risco baixo, a ausência de equipamento obrigatório, a cadeira opcional, o ambiente estável e as relações aprovadas foram preservados.

A instrução pública foi limitada a expansão costal lateral confortável, expiração sem esforço, transição contínua e feedback tátil leve. Foram excluídos inspiração máxima, retenções, contagens, cadência, dose, pressão manual terapêutica, correção de assimetrias, tratamento e promessas.

**Implementação realizada: não.**

## Pergunta de investigação

Que elementos de preparação, posição, execução, segurança, erros e supervisão podem ser documentados para um principiante absoluto sem alterar a identidade `lateral_costal_breathing` nem transformar o drill numa intervenção clínica?

## Fontes independentes consultadas

### 1. British Thoracic Society / ACPRC

Bott J, et al. *Guidelines for the physiotherapy management of the adult, medical, spontaneously breathing patient*. Thorax. 2009;64 Suppl 1:i1-i51.  
Ligação: https://www.brit-thoracic.org.uk/document-library/guidelines/physiotherapy/btsacprc-guidelines-for-physiotherapy-management-of-the-adult-medical-spontaneously-breathing-patient/

Contributos:

- define controlo respiratório como respiração suave com relaxamento da parte superior do tórax e dos ombros;
- separa controlo respiratório, exercícios de expansão torácica e técnicas manuais;
- apoia uma posição confortável, pouco esforço e relaxamento dos ombros e mãos;
- assinala que técnicas respiratórias podem ter respostas diferentes em populações clínicas.

Limite: é uma guideline clínica para doença respiratória e não demonstra benefícios deste drill numa população geral.

### 2. Cambridge University Hospitals NHS Foundation Trust

*Airway clearance: active cycle of breathing technique (ACBT)*. Versão 8, aprovada em 5 de setembro de 2025.  
Ligação: https://www.cuh.nhs.uk/patient-information/airway-clearance-active-cycle-of-breathing-technique-acbt/

Contributos:

- recomenda posição confortável com braços e ombros relaxados;
- apresenta posição sentada ou decúbito lateral como opções iniciais em contexto clínico;
- orienta entrada e saída de ar a velocidade confortável e evita elevação dos ombros;
- reforça avaliação individual por fisioterapeuta respiratório no protocolo clínico.

Limite: a fonte trata limpeza das vias aéreas, inclui retenção e elementos de dose. Esses componentes foram deliberadamente excluídos porque não pertencem à identidade canónica nem ao contrato.

### 3. Blaney e Sawyer, 1997

Blaney F, Sawyer T. *Sonographic measurement of diaphragmatic motion after upper abdominal surgery: a comparison of three breathing manoeuvres*. Physiotherapy Theory and Practice. 1997;13(3):207-215. doi:10.3109/09593989709036464.  
Ligação: https://doi.org/10.3109/09593989709036464

Contributos:

- estudo primário que trata a expansão torácica, descrita como respiração costal lateral, como manobra treinável;
- distingue-a de uma instrução geral para respirar fundo e da respiração abdominal;
- confirma que a manobra pode ser observada através de movimento respiratório.

Limite: amostra pequena, pós-operatória e clínica. Não sustenta promessas de resultado, generalização para principiantes saudáveis ou uso sem revisão em contexto pós-operatório.

### 4. Korkie, 2015

Korkie E. *Effect of lateral costal breathing dissociation exercises on the position of the scapula in level two up to senior national level swimmers*. Tese de doutoramento, University of Pretoria, 2015.  
Ligação: https://repository.up.ac.za/items/5b6145e9-d9ae-4730-95fb-2eb1a8b4d1c7

Contributos:

- investigação primária que documenta facilitação voluntária da respiração costal lateral;
- mede expansão torácica e demonstra que a direção regional é operacionalizável.

Limite: treino respiratório combinado com treino escapular e alongamento em nadadores. Não permite isolar o efeito da respiração nem transferir resultados para o público geral.

### 5. MedlinePlus / National Library of Medicine

*Hyperventilation*. Revisão de 23 de julho de 2024.  
Ligação: https://medlineplus.gov/ency/article/003071.htm

Contributos:

- caracteriza hiperventilação como respiração demasiado rápida e profunda;
- associa respiração excessiva a tontura, fraqueza, sensação de falta de ar, dor torácica, formigueiro e dificuldade de concentração;
- apoia a necessidade de interromper perante sintomas novos ou crescentes.

Limite: recurso geral de segurança, não específico da expansão costal lateral.

## Síntese técnica

A expansão lateral das costelas é uma direção observável da inspiração e pode ser praticada voluntariamente. A evidência profissional converge em três princípios adequados ao conteúdo geral: posição confortável e estável, ombros relaxados e respiração sem esforço excessivo.

A literatura clínica usa frequentemente “expansão torácica” em protocolos de limpeza das vias aéreas, pós-operatórios ou de fisioterapia e pode incluir inspiração profunda máxima, retenção ou facilitação manual. Esses elementos não são equivalentes ao drill canónico aprovado. Foram rejeitados na transposição pública.

O uso das próprias mãos foi mantido apenas como feedback tátil leve, coerente com o registo canónico. Qualquer compressão, resistência ou pressão transforma a ação e aproxima-a de técnica clínica manual.

## Decisões de conteúdo

| Tema | Decisão | Fundamento |
|---|---|---|
| Posição | Posição estável; cadeira firme como opção inicial | Preserva orientação mista e equipamento opcional |
| Inspiração | Confortável e não máxima | Reduz risco de respiração excessiva e respeita a identidade |
| Direção | Expansão bilateral para os lados, com possível componente posterior | Núcleo mecânico canónico |
| Expiração | Confortável e sem força | Regresso natural das costelas |
| Transição | Contínua, sem retenção | Contrato proíbe retenções |
| Mãos | Feedback leve e opcional | Registo canónico; exclui pressão manual |
| Ombros e pescoço | Relaxados | Consistência profissional e redução de compensações |
| Assimetria | Não corrigir nem diagnosticar | Limite canónico e clínico |
| Supervisão | Não exigida em contexto geral; revisão em gatilhos canónicos | Preserva risco e requisitos operacionais |

## Erros sustentados

1. Inspiração máxima ou forçada: aumenta esforço e pode favorecer respiração excessiva.
2. Elevação excessiva dos ombros: contraria a orientação profissional de relaxamento do complexo superior.
3. Arqueamento lombar: altera a posição em vez de produzir o movimento costal pretendido.
4. Pressão das mãos: deixa de ser feedback leve e aproxima-se de facilitação manual.
5. Tentativa de corrigir assimetria: excede o âmbito não diagnóstico.
6. Retenção do ar: não pertence à identidade nem ao contrato.

## Segurança e supervisão

O risco operacional de base permanece baixo. Os principais riscos são inspiração excessivamente profunda, sobre-respiração e desconforto provocado pelo padrão voluntário.

Sinais de interrupção preservados:

- confusão ou perda de controlo;
- falta de ar atípica ou crescente;
- dor torácica ou costal;
- formigueiro ou outros sinais associados a hiperventilação;
- tontura, pré-síncope ou síncope.

Não se exige parceiro, observador de segurança ou supervisão num contexto geral. Revisão profissional é adequada em contexto pós-operatório, assimetria clínica, regresso à função, doença cardiovascular ou respiratória, história de síncope, incapacidade de parar ou ajustar e sintomas novos ou inexplicados.

## Limitações da evidência

- A evidência direta específica para respiração costal lateral é escassa.
- Estudos primários identificados usam amostras clínicas ou populações específicas.
- Pelo menos um estudo combina o exercício com outras intervenções.
- Fontes profissionais descrevem frequentemente protocolos terapêuticos mais amplos.
- Não há fundamento para prometer aumento de capacidade pulmonar, correção postural, correção de assimetria ou resultado individual.
- A amplitude confortável e a posição mais adequada variam entre pessoas e não devem ser convertidas numa meta fixa.

## Verificação do contrato

- Português europeu e UTF-8: cumprido.
- Identidade, risco, equipamento, ambiente e relações: preservados.
- Passos de execução: 7.
- Indicações técnicas: 6.
- Erros comuns: 6, com reconhecimento e correção.
- Perguntas de compreensão: 12.
- Contagens, retenções, dose e cadência: ausentes.
- Pressão manual terapêutica: excluída.
- Tratamento, diagnóstico e promessa: excluídos.
- Código, publicação e implementação: não realizados.
