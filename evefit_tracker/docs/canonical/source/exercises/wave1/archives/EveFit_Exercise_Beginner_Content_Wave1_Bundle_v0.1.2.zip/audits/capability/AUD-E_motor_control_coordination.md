# AUD-E — auditoria independente de controlo motor e coordenação

**Auditor:** AUD-E  
**Capacidade auditada:** `motor_control_coordination`  
**Data:** 2026-07-24  
**Natureza:** revisão independente, sem autoria, sem edição de conteúdos e sem implementação

## 1. Âmbito

Foram revistos todos e apenas os seis exercícios cujo JSON declara `capability_primary == motor_control_coordination`:

1. `march_in_place_to_external_beat`
2. `tandem_walk`
3. `tandem_stance`
4. `single_leg_stance`
5. `clockwise_four_quadrant_step_sequence`
6. `standing_multidirectional_weight_shift`

Para cada exercício foram comparados os três artefactos locais — JSON de conteúdo, Markdown público e relatório de investigação — e o pacote de entrada correspondente `EX-35` a `EX-40` em `_beginner_content_workspace/agent_inputs`.

Total revisto: **18 artefactos de conteúdo + 6 pacotes de entrada = 24 ficheiros**. Não foram lidos relatórios de outros auditores.

## 2. Método

A revisão cobriu:

- identidade, família, tipo, variante e exercício-base;
- clareza para principiante, posição inicial, sequência, fases e saída;
- orientação respiratória;
- risco de queda, apoio, superfície, espaço e equipamento;
- sinais de interrupção, erros observáveis e correções;
- supervisão, gatilhos de revisão e ausência de redução do risco;
- ausência de dose, progressão programada, promessa, diagnóstico e tratamento;
- coerência entre JSON, Markdown, relatório e tarefas da mesma capacidade;
- validade JSON, ordem das chaves obrigatórias, mínimos contratuais e Unicode NFC.

Os invariantes foram confirmados diretamente nos pacotes de entrada; não se inferiram alterações a partir dos relatórios.

## 3. Estados por exercício

| Exercício | Estado AUD-E | Blocker | Síntese |
|---|---|---:|---|
| `march_in_place_to_external_beat` | Aprovado | Não | Identidade, sinal auditivo obrigatório por alternativa, risco moderado, apoio opcional, respiração e saída coerentes. |
| `tandem_walk` | Aprovado | Não | Sequência calcanhar-ponta, transferência de peso, percurso, apoio, supervisão e saída são claras e coerentes nos três artefactos. |
| `tandem_stance` | Aprovado com correção editorial menor | Não | Posição tandem, apoio bipodal, base estreita, supervisão e saída são seguras; uma verificação de prontidão diverge entre JSON e Markdown. |
| `single_leg_stance` | Aprovado | Não | Preparação bipodal, entrada unipodal, visão, apoio opcional, retorno imediato a dois apoios e supervisão estão coerentes. |
| `clockwise_four_quadrant_step_sequence` | Aprovado | Não | Ordem fechada, padrão passo-junta, alvos visuais planos, passo para trás, espaço, supervisão e saída estão bem delimitados. |
| `standing_multidirectional_weight_shift` | **Bloqueado para aprovação** | **Sim** | Identidade e sequência estão claras, mas há dois desvios do invariante de equipamento/apoio. |

Contagem de estados: **4 aprovados**, **1 aprovado com correção menor**, **1 bloqueado**.

## 4. Findings

### A. Blockers

#### AUD-E-MCC-001 — introdução de requisito de vestuário/calçado

- **Severidade:** alta
- **Blocker:** sim
- **Exercício:** `standing_multidirectional_weight_shift`
- **Campo:** `before_you_start_pt_pt` / invariantes de equipamento
- **Evidência:** o pacote `EX-40` fixa `required_equipment: []`, `personal_gear_requirements: []` e `no_equipment_changes: true` (linhas 145–151 e 624). O JSON de conteúdo acrescenta “Use roupa que não limite o movimento e calçado adequado ao piso” (linha 18), repetido no Markdown (linha 31). O relatório, em contraste, resume “Nenhum obrigatório; apoio estável opcional” (linha 93).
- **Revisão exigida:** remover a instrução como requisito ou reformulá-la sem criar obrigação material não existente no registo. Não preencher implicitamente `personal_gear_requirements`.

#### AUD-E-MCC-002 — apoio opcional transformado em imperativo

- **Severidade:** alta
- **Blocker:** sim
- **Exercício:** `standing_multidirectional_weight_shift`
- **Campo:** `safety_note_pt_pt`
- **Evidência:** o pacote `EX-40` classifica `stable_support` como equipamento opcional (linhas 146–149). O próprio relatório confirma que o apoio é opcional e não deve tornar-se requisito universal (linhas 63–65 e 93). Porém, a nota de segurança ordena “Use apoio estável ao alcance” no JSON (linha 148) e no Markdown (linha 167), sem qualificador. Isto contradiz `equipment_setup_pt_pt` e `equipment_safety_pt_pt`, que dizem corretamente “Se usar”/“O apoio é opcional”.
- **Revisão exigida:** qualificar a nota, por exemplo condicionando o apoio à necessidade prevista, e manter explícito que é opcional. A nota de segurança, a preparação e o relatório devem transmitir a mesma regra.

### B. Não bloqueantes

#### AUD-E-MCC-003 — verificação de prontidão divergente entre JSON e Markdown

- **Severidade:** baixa
- **Blocker:** não
- **Exercício:** `tandem_stance`
- **Campo:** `body_readiness_check_pt_pt`
- **Evidência:** o JSON pergunta se a pessoa consegue “mover um pé para a frente e regressar a uma base mais larga” (linha 37); o Markdown pergunta se consegue “mover um pé para o lado e regressar voluntariamente a uma base mais larga” (linha 47). A primeira formulação testa entrada e saída; a segunda testa sobretudo a saída.
- **Revisão exigida:** escolher uma formulação única que cubra de modo inequívoco a entrada em tandem e a saída para base confortável, e replicá-la nos dois artefactos.

## 5. Invariantes e verificações contratuais

### 5.1 Identidade e risco

- Os seis JSON correspondem ao `exercise_id`, nome, `entity_type`, estado, capacidade principal, família, variante e exercício-base dos respetivos pacotes.
- Risco preservado: **moderado** em EX-35 a EX-39 e **baixo** em EX-40.
- Nenhum conteúdo reduz os gatilhos de revisão por risco elevado de queda, contexto clinicamente restringido ou incapacidade de sair da tarefa de forma independente.
- Os cinco exercícios com risco moderado apresentam saída controlada explícita; EX-40 também apresenta regresso ao centro e saída segura.

### 5.2 Equipamento, apoio e ambiente

- `march_in_place_to_external_beat` preserva a necessidade de uma fonte auditiva válida por grupo alternativo e não afirma suporte sem equipamento.
- `clockwise_four_quadrant_step_sequence` preserva alvo visual obrigatório, ausência de equipamento obrigatório e fita plana opcional.
- `tandem_walk`, `tandem_stance` e `single_leg_stance` preservam apoio estável opcional.
- EX-40 só deixa de cumprir integralmente esta dimensão pelos findings AUD-E-MCC-001 e AUD-E-MCC-002.
- Piso firme, nivelado/plano e antiderrapante, área livre e exclusão de altura desprotegida/veículo em movimento estão coerentes com cada pacote.

### 5.3 Clareza, sequência, respiração e erros

- Todos os exercícios têm posição inicial, pelo menos cinco passos, fases, saída e instruções observáveis.
- A respiração é natural e contínua, sem retenção ou contagens. Não foi imposta sincronização respiratória não sustentada.
- Os erros incluem reconhecimento e correção; as correções favorecem parar, estabilizar, reduzir alcance não controlado ou regressar a apoio seguro.
- Não foram encontradas doses fixas, cadências numéricas, durações, distâncias, cargas, séries ou progressões programadas.
- Não foram encontradas promessas de resultado, diagnóstico, tratamento ou autorização universal.

### 5.4 Estrutura mecânica

Todos os JSON são válidos, estão em Unicode NFC, mantêm as chaves obrigatórias na ordem contratual e cumprem os mínimos:

| Exercício | Passos | Pistas | Erros | Perguntas |
|---|---:|---:|---:|---:|
| `march_in_place_to_external_beat` | 8 | 7 | 5 | 12 |
| `tandem_walk` | 7 | 6 | 5 | 12 |
| `tandem_stance` | 8 | 6 | 6 | 12 |
| `single_leg_stance` | 8 | 6 | 6 | 12 |
| `clockwise_four_quadrant_step_sequence` | 7 | 6 | 6 | 12 |
| `standing_multidirectional_weight_shift` | 7 | 6 | 6 | 12 |

Todos os objetos de erro incluem `error_pt_pt`, `how_to_recognise_pt_pt` e `correction_pt_pt`; todos os exercícios declaram `unresolved_fields` vazio.

## 6. Padrões transversais

### Padrões positivos

- Sequência geral consistente: preparar ambiente e apoio, verificar prontidão, assumir posição, executar, terminar e estabilizar.
- Boa separação entre sensação esperada e sinal de interrupção.
- Supervisão `recommended` mantida em todos os exercícios, com aumento prudente perante risco individual.
- Saídas de falha são específicas à tarefa: apoio bipodal, base mais larga, regresso ao centro ou paragem no quadrante.
- As fronteiras entre tarefas são claras: marcha tandem versus postura tandem; postura unipodal versus variantes sem visão/superfície instável; transferência de peso versus passo; sequência em quadrantes versus teste cronometrado/programa.

### Padrões a corrigir

- EX-40 é o único pacote em que a redação pública introduz equipamento pessoal e torna o apoio opcional aparentemente obrigatório.
- A divergência editorial restante é local e não altera identidade, risco ou segurança substantiva.

## 7. Contagens finais

- Exercícios auditados: **6**
- Artefactos de conteúdo auditados: **18**
- Pacotes de entrada auditados: **6**
- Findings: **3**
- Findings de severidade alta: **2**
- Findings de severidade baixa: **1**
- Blockers: **2**, ambos em `standing_multidirectional_weight_shift`
- Exercícios sem findings: **4**
- Exercícios com finding não bloqueante: **1**
- Exercícios bloqueados: **1**

## 8. Independência e zero implementação

AUD-E não foi autor dos conteúdos. A revisão foi feita apenas sobre os artefactos e pacotes indicados no âmbito, sem consulta de relatórios de outros auditores. Nenhum conteúdo foi editado, nenhuma relação foi criada ou alterada, nenhum código foi implementado, nenhuma publicação ou aprovação de multimédia foi realizada. **Implementação realizada por AUD-E: zero.**
