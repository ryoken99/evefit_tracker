# Relatório de investigação — Passe de peito com bola medicinal em pé

**Agente:** EX-14  
**Exercise ID:** `standing_medicine_ball_chest_pass`  
**Data da pesquisa:** 23 de julho de 2026  
**Implementação realizada: não**

## Resultado

O conteúdo para principiantes pode ser aprovado com limites. A identidade canónica está bem sustentada: apoio bipodal em pé, bola medicinal ao peito, ação bilateral, libertação anterior e natureza balística. A segurança exige controlo do projétil, verificação do equipamento, espaço isolado e supervisão recomendada. Não foi localizada uma norma única que padronize todos os detalhes da versão exata, estacionária, sem passo e sem receção obrigatória.

## Âmbito investigado

A pesquisa incidiu em:

- preparação corporal, do equipamento e do espaço;
- sequência de execução e transferência de força;
- respiração;
- risco balístico e controlo da trajetória;
- uso opcional de parceiro, alvo ou zona de queda;
- erros observáveis e correções;
- critérios de interrupção;
- supervisão de principiantes.

Foram excluídos dose, carga concreta, distância, cadência, progressão programada, promessa de resultado, diagnóstico, tratamento, publicação e implementação.

## Fontes consultadas

### B1-S08 — Turner et al., 2021

**Título:** *Developing Powerful Athletes Part 2: Practical Applications*  
**Entidade:** National Strength and Conditioning Association  
**Tipo:** artigo técnico profissional com suporte científico  
**Ligação:** https://www.nsca.com/contentassets/e4dd144726594fd3ba2cc4af571d6079/developing_powerful_athletes_part_2__practical.3.pdf

O artigo caracteriza os movimentos balísticos como ações de aceleração rápida contra resistência nas quais a massa se torna um projétil. Inclui o passe de peito com bola medicinal entre os exercícios balísticos e assinala que o contramovimento permite contribuição dos membros inferiores; sem essa contribuição, o gesto aproxima-se de uma ação mais localizada ao membro superior.

**Aplicação:** natureza balística, necessidade de libertação, sequência corpo-braços e pequeno contramovimento compatível com a forma em pé.  
**Limite:** não fornece uma instrução completa e padronizada para principiantes.

### EX14-S01 — NSCA, *Basics of Strength and Conditioning Manual*

**Entidade:** National Strength and Conditioning Association  
**Tipo:** manual profissional oficial  
**Ligação:** https://www.nsca.com/contentassets/48a12160221541acbdc048498d77192d/basics_of_strength_and_conditioning_manual.pdf

O manual recomenda expirar na fase de maior esforço e inspirações na fase menos exigente, alertando para efeitos adversos de retenção respiratória. Também distingue supervisão direta durante ensino de competências e supervisão indireta quando a competência já está consolidada. Para treino com bolas medicinais, exige instalações adequadas, paredes sólidas quando aplicável, vias desimpedidas, luz suficiente e piso apropriado.

**Aplicação:** expiração durante aceleração/libertação, ausência de retenção prolongada, supervisão direta na primeira exposição, observação de toda a zona e requisitos ambientais.  
**Limite:** orientações transversais, não exclusivas deste exercício.

### EX14-S02 — Vincent, Traywick e Washburn

**Título:** *Strength Training With Medicine Balls*  
**Entidade:** University of Arkansas System Division of Agriculture, Research & Extension  
**Tipo:** guia profissional universitário oficial  
**Ligação:** https://www.uaex.uada.edu/publications/pdf/FSFCS37.pdf

O guia descreve o passe de peito com a bola ao nível do peito e uma ação dos dois braços para a frente. Exige que o passe dirigido a parceiro seja controlável e indica que a bola não deve comprometer controlo, precisão ou amplitude. Distingue execução com parceiro de execução contra parede e chama a atenção para o espaço disponível e a adequação do tipo de bola.

**Aplicação:** posição da bola, ação bilateral, prontidão do parceiro, passe controlável, compatibilidade da bola e distinção entre parceiro e alvo.  
**Limite importante:** a versão ilustrada inclui um passo e eventual receção. O passo não foi transposto porque alteraria a organização estacionária do registo canónico; a receção também não foi tornada obrigatória.

### SP-B2-S20 — Garcia-Carrillo et al., 2023

**Título:** *Effects of Upper-Body Plyometric Training on Physical Fitness in Healthy Youth and Young Adult Participants: A Systematic Review*  
**Tipo:** revisão sistemática científica  
**Ligação:** https://pmc.ncbi.nlm.nih.gov/articles/PMC10575843/

A revisão documenta lançamentos com bola medicinal dentro da família de treino pliométrico do membro superior e mostra heterogeneidade entre intervenções, testes e formas de execução.

**Aplicação:** suporte de família e justificação de linguagem prudente.  
**Limite:** não permite inferir uma técnica universal, dose, carga ou resultado individual.

### EX14-S03 — Trajković et al., 2024

**Título:** *Diurnal Variations in Upper and Lower Body Power in Adolescent Volleyball Players: Exploring Time-of-Day Effects on Performance*  
**Tipo:** estudo primário  
**Ligação:** https://pubmed.ncbi.nlm.nih.gov/39728860/  
**DOI:** https://doi.org/10.3390/sports12120320

O estudo utiliza um lançamento de bola medicinal em pé como tarefa distinta de versões sentada e deitada, em jovens jogadores de voleibol.

**Aplicação:** evidência primária de que a forma em pé é operacionalmente distinguível de outras posições.  
**Limite:** estudo de avaliação, numa população treinada específica; não é uma fonte de instrução técnica para principiantes nem de segurança.

## Triangulação das decisões

| Decisão documental | Suporte | Decisão final |
|---|---|---|
| Classificar o gesto como balístico | Turner et al.; registo canónico | A bola é explicitamente tratada como projétil após a libertação. |
| Permitir pequeno contramovimento | Turner et al.; registo canónico | Incluído sem passo, salto ou deslocamento global. |
| Bola ao centro do peito e ação bilateral anterior | University of Arkansas; registo canónico | Incluído como núcleo da execução. |
| Expirar durante a libertação | NSCA manual | Incluído como orientação simples, sem contagem ou retenção. |
| Proteger toda a trajetória | Natureza balística; NSCA manual; University of Arkansas | Zona de lançamento, queda e ressalto têm de estar controladas. |
| Tornar parceiro obrigatório | Registo canónico e University of Arkansas | Rejeitado; parceiro permanece opcional. |
| Tornar alvo obrigatório | Registo canónico e University of Arkansas | Rejeitado; alvo permanece opcional. |
| Incluir receção obrigatória | Registo canónico e limites das fontes | Rejeitado; a receção acrescenta exigência não intrínseca. |
| Incluir passo à frente | Registo canónico versus guia da University of Arkansas | Rejeitado; preserva-se apoio bipodal estacionário. |
| Recomendar supervisão | NSCA manual; registo canónico | Mantida, com observação direta na primeira exposição ou mudança de contexto. |

## Preparação e execução resultantes

A síntese mais defensável para um principiante é:

1. Isolar a trajetória e definir previamente a zona de receção.
2. Verificar a bola e, quando exista, a compatibilidade do alvo com impacto e ressalto.
3. Adotar apoio nos dois pés, bola ao centro do peito, punhos alinhados e tronco organizado.
4. Usar apenas um pequeno contramovimento controlável, sem passo.
5. Transferir força de forma coordenada para uma extensão simultânea dos braços.
6. Expirar e libertar a bola para a frente.
7. Travar o corpo sobre os dois pés.
8. Recuperar a bola apenas quando a zona voltar a estar segura.

Esta sequência não fixa massa, distância, velocidade concreta, volume ou ritmo.

## Segurança balística, alvo e parceiro

O risco principal não é uma receção de carga pelo executante durante a libertação, mas a perda de controlo de um projétil. Por inferência operacional conservadora, toda a zona provável — voo, impacto, ressalto, queda e rolamento — é tratada como área controlada.

Um parceiro é apenas uma opção de receção. Quando existe, deve haver contacto visual e sinal explícito de prontidão, e a trajetória combinada deve ser controlável. Um alvo é também opcional e só deve ser usado se for estável, resistente e compatível com o comportamento da bola. Quando não existe parceiro nem alvo, uma zona de queda isolada preserva a identidade do passe sem acrescentar uma receção reativa.

## Erros prioritários

Foram selecionados erros que um principiante ou supervisor consegue observar diretamente:

- lançar para uma zona ocupada;
- usar uma bola que degrada controlo ou precisão;
- perder a base ou dar um passo involuntário;
- colapsar os punhos;
- desviar a trajetória para baixo ou demasiado para cima;
- rodar o tronco ou empurrar de forma assimétrica.

As correções não prescrevem carga, distância, volume ou progressão.

## Supervisão e interrupção

A recomendação de supervisão foi preservada. A supervisão direta é especialmente pertinente na primeira exposição, quando há terceiros próximos e quando muda a bola, o alvo, o espaço ou a velocidade pretendida. O supervisor deve ver simultaneamente a pessoa e toda a trajetória e conseguir interromper a tarefa.

Os sinais de interrupção mantêm os do registo canónico: dor aguda, mal-estar, perda súbita de coordenação e incapacidade de controlar travagem ou receção. Foram acrescentados apenas equivalentes operacionais observáveis, como entrada de terceiros na trajetória ou dano visível na bola, sem alterar o nível de risco.

## Confiança e limites

**Confiança global:** moderada.

- **Identidade:** alta, por concordância entre registo canónico, fonte profissional e estudo primário.
- **Execução:** moderada, porque as fontes profissionais descrevem formas próximas, mas não existe uma norma única para esta versão exata.
- **Respiração:** moderada, apoiada por orientação geral profissional.
- **Segurança:** moderada, baseada em princípios profissionais de supervisão, instalações e controlo da bola, com inferência conservadora para a trajetória.

Não são afirmados resultados individuais. Não se define dose, carga, distância, velocidade concreta, progressão ou adequação universal. A resposta de ressalto depende do modelo de bola e das instruções do fabricante. A seleção individual da bola e a eventual revisão clínica permanecem fora deste documento.
