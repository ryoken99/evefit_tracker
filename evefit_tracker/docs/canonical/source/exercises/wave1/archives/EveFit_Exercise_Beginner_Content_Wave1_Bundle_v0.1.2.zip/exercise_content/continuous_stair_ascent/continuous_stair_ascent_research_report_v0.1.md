# Relatório de investigação — `continuous_stair_ascent`

**Agente:** EX-10  
**Data de pesquisa:** 23 de julho de 2026  
**Idioma do conteúdo:** português europeu  
**Implementação realizada: não**

## Resultado

Foi produzido conteúdo documental para principiantes sobre a subida contínua de escadas, com cobertura de preparação, posição inicial, execução, fases, respiração, sensações, erros, corrimão, supervisão, fim da tarefa e sinais de interrupção.

O conteúdo recebeu o estado `beginner_content_approved_with_limits`. A identidade canónica, o risco operacional moderado, o equipamento, o ambiente e as relações aprovadas foram preservados. Não foi criada qualquer nova relação e não foi feita aprovação de multimédia.

## Âmbito e fronteiras preservadas

| Elemento | Estado preservado |
|---|---|
| Identidade | Locomoção cíclica ascendente em degraus fixos, com alternância dos apoios e ganho real de altura. |
| Tipo | `canonical_exercise` |
| Família | `stair_locomotion_family` |
| Variante/base | `none` / `none` |
| Risco | Moderado; queda de altura, passo em falso e carga vertical repetida. |
| Equipamento | Sem equipamento obrigatório; corrimão apenas como característica opcional do local/adaptação. |
| Ambiente | Escada fixa, uniforme, iluminada, sem obstáculos e com entrada e saída seguras. |
| Exclusões | Descida, escadas móveis, escada rotativa, stepper e trepador vertical. |
| Supervisão | Recomendada; sem spotter universalmente obrigatório. |

As relações canónicas foram mantidas sem alteração:

1. `continuous_stair_ascent__main_training__cardio_conditioning__cyclic_locomotion__develop_aerobic_endurance` — compatível, `alternative_primary`.
2. `continuous_stair_ascent__main_training__cardio_conditioning__repetitive_rhythmic_movement__increase_repetitive_movement_endurance` — compatível, `alternative_primary`.
3. `continuous_stair_ascent__warmup__cardio_conditioning__repetitive_rhythmic_movement__prepare_repetitive_contact` — condicional, `complementary`, dependente da elegibilidade e de uma escada segura e familiar.

## Questões investigadas

- Como descrever a mecânica essencial sem transformar a explicação em prescrição?
- Que verificações do local são sustentadas por fontes oficiais?
- Que orientação respiratória é específica e prudente?
- Como enquadrar o corrimão sem o tornar equipamento obrigatório?
- Quando é defensável recomendar supervisão?
- Que erros são observáveis e têm correções simples para principiantes?
- Que sinais justificam interromper ou não iniciar?

## Fontes e utilização

### Fontes pré-existentes no pacote

1. [American College of Sports Medicine — Exercising Your Way to Lowering Your Blood Pressure](https://acsm.org/wp-content/uploads/2025/02/Exercising-Your-Way-to-Lowering-Your-Blood-Pressure-handout.pdf) (`A1-S01`)
   - Tipo: organização profissional.
   - Uso: confirma a subida de escadas dentro da família de atividade aeróbia.
   - Limite: não fornece técnica fina nem critérios de segurança específicos da escada.

2. [McCord, Nichols e Patterson — The effects of low impact aerobic dance and stair climbing on physical fitness in untrained females](https://pubmed.ncbi.nlm.nih.gov/8289616/) (`A2-S41`)
   - Tipo: estudo científico indexado.
   - Uso: confirma a subida de escadas como modalidade de condicionamento.
   - Limite: não distingue todas as máquinas nem valida uma sequência pedagógica universal.

### Fontes adicionais independentes

3. [Health and Safety Executive — Reducing the risk of falls on stairs](https://www.hse.gov.uk/healthservices/slips/reducing-risks-stairs.htm) (`EX10-S01`)
   - Tipo: orientação oficial de segurança.
   - Contributos: escadas bem iluminadas, corrimãos adequados, boa resistência ao deslizamento, bordas distinguíveis, ausência de obstáculos e avaliação quando mobilidade ou equilíbrio aumentam o risco.
   - Aplicação: preparação do ambiente, segurança, corrimão e gatilhos de supervisão.

4. [Cambridge University Hospitals NHS Foundation Trust — Breathing techniques to ease breathlessness](https://www.cuh.nhs.uk/patient-information/breathing-techniques-to-ease-breathlessness/) (`EX10-S02`)
   - Tipo: orientação profissional hospitalar.
   - Contributos: evitar reter a respiração durante a subida, não apressar e deixar a expiração acompanhar o esforço.
   - Aplicação: respiração natural e contínua, sem contagens impostas.
   - Limite: o documento é dirigido a pessoas com falta de ar; a adaptação ao público geral foi conservadora e não incluiu técnicas respiratórias clínicas.

5. [National Institute on Aging — Home safety tips for older adults](https://www.nia.nih.gov/sites/default/files/2024-04/home-safety-tips-adults-nia.pdf) (`EX10-S03`)
   - Tipo: orientação oficial de saúde pública.
   - Contributos: iluminação adequada, corrimãos e redução de perigos de queda.
   - Aplicação: verificação do local e utilização prudente do corrimão.
   - Limite: fonte orientada para pessoas mais velhas; os princípios ambientais foram usados por serem gerais, sem inferir incapacidade pela idade.

6. [Vallabhajosula et al. — Biomechanical analyses of stair-climbing while dual-tasking](https://pubmed.ncbi.nlm.nih.gov/25773590/) (`EX10-S04`)
   - Tipo: investigação biomecânica primária.
   - Contributos: caracteriza a subida por ciclos de apoio, extensão da anca e do joelho e flexão plantar do tornozelo; avalia também a interferência de tarefas simultâneas.
   - Aplicação: fases do movimento e exclusão de distrações.
   - Limite: estudo laboratorial; não é um manual de instrução para principiantes.

7. [Francksen et al. — Underlying mechanisms of fall risk on stairs with inconsistent going size](https://pubmed.ncbi.nlm.nih.gov/35151119/) (`EX10-S05`)
   - Tipo: investigação primária de segurança.
   - Contributos: degraus com profundidade inconsistente podem reduzir a folga e o comprimento de contacto do pé, aumentando mecanismos de tropeção, prisão do calcanhar ou sobrepassagem.
   - Aplicação: exclusão de escadas irregulares, colocação completa do pé e atenção à borda.
   - Limite: resultados sobre uma alteração geométrica específica; não permitem quantificar risco individual.

Estas fontes representam pelo menos quatro entidades independentes: ACSM, HSE, NHS/CUH, NIA e equipas de investigação científica.

## Matriz afirmação–evidência

| Afirmação do conteúdo | Base principal | Força | Limite aplicado |
|---|---|---|---|
| A subida usa alternância de apoios e extensão da anca/joelho com ação do tornozelo. | Vallabhajosula et al.; assinatura canónica. | Moderada a alta | Descrição qualitativa, sem ângulos ou valores normativos. |
| Degraus devem estar uniformes, iluminados, aderentes e sem obstáculos. | HSE; NIA. | Alta para segurança ambiental | Não transforma características opcionais em equipamento obrigatório. |
| A colocação do pé deve evitar apoio mínimo junto à borda. | Francksen et al.; orientação profissional sobre contacto do pé. | Moderada | “Completa e estável” é condicionada à área útil; uma escada incompatível não deve ser usada. |
| Deve evitar-se a retenção da respiração. | CUH. | Moderada | Sem contagens, retenções ou técnica clínica específica. |
| Distrações devem ser removidas. | Estudo de dupla tarefa; princípios de prevenção de quedas. | Moderada | Não é feita estimativa quantitativa de risco. |
| O corrimão pode apoiar o equilíbrio, mas deve estar firme. | HSE; NIA. | Alta para ambiente | Continua opcional na identidade e não substitui elegibilidade. |
| Instabilidade ou limitações relevantes justificam avaliação/supervisão. | HSE; registo canónico. | Alta para decisão prudente | Sem diagnóstico nem autorização clínica. |
| A execução termina no patamar, não a meio do lanço. | Requisito canónico de saída segura; inferência operacional. | Moderada | Explicitamente identificado como orientação de segurança, não como resultado experimental isolado. |

## Decisões editoriais

### Colocação do pé

A formulação “de forma completa, centrada e estável na área útil” preserva a pista pública canónica e evita uma regra impossível em degraus demasiado estreitos. Quando a área útil não permite um apoio seguro, o conteúdo manda rejeitar o local, coerente com a exigência de degraus uniformes e adequados.

### Corrimão

O corrimão não foi adicionado como equipamento obrigatório. É descrito como característica opcional do local e adaptação de segurança. O utilizador deve verificar a firmeza antes de o usar; confiar num corrimão solto é tratado como erro observável.

### Respiração

Foi adotada a orientação mais conservadora sustentada: respiração natural e contínua, sem retenção. A expiração pode acompanhar a fase de elevação se for confortável, mas não foi imposta qualquer contagem ou sincronização.

### Supervisão

A recomendação segue o estado canónico `recommended`. O texto destaca instabilidade marcada e ambiente desconhecido, os dois gatilhos canónicos, e inclui as populações que exigem adaptação ou revisão sem presumir incapacidade. Não foi convertido em requisito universal de spotter.

### Erros

Foram documentados seis erros completos, cada um com:

- erro observável;
- forma de o reconhecer;
- correção imediata e não prescritiva.

Os erros cobrem ambiente, colocação do pé, velocidade descontrolada, distração, corrimão e saída.

## Cobertura contratual

| Requisito | Cobertura |
|---|---|
| Português europeu e UTF-8 NFC | Verificado. |
| Chaves JSON na ordem pedida | Verificado. |
| Passos de execução | Oito. |
| Pistas principais | Seis. |
| Erros completos | Seis, com os três campos obrigatórios. |
| Perguntas de compreensão | Doze. |
| Duas fontes independentes ou mais | Cumprido. |
| Preparação | Incluída. |
| Execução e fases | Incluídas. |
| Respiração | Incluída, sem retenção ou contagem. |
| Segurança e sinais de interrupção | Incluídos. |
| Corrimão | Incluído como característica opcional/adaptação. |
| Supervisão | Incluída e coerente com `recommended`. |
| Identidade, risco, equipamento e ambiente | Preservados. |
| Relações | Preservadas; nenhuma relação criada ou alterada. |
| Dose, prescrição e progressão programada | Não incluídas. |
| Promessas, diagnóstico ou tratamento | Não incluídos. |
| Código, publicação ou implementação | Não realizados. |

## Confiança e limites

**Confiança global:** moderada.

Há forte convergência para segurança ambiental e uso de corrimãos, e sustentação biomecânica suficiente para a descrição geral da subida. A orientação respiratória é profissional e específica à atividade, mas parte de um contexto hospitalar de falta de ar. A evidência direta para uma sequência pedagógica universal de principiante é limitada; por isso, o conteúdo não reivindica universalidade nem elegibilidade automática.

Permanecem fora do âmbito:

- qualquer dose, intensidade, cadência, velocidade, duração, distância, carga, descanso ou progressão;
- diagnóstico, tratamento ou autorização clínica;
- descida de escadas;
- escadas móveis e máquinas;
- aprovação de imagem ou vídeo;
- implementação em produto.

## Conclusão

A cobertura é defensável para conteúdo introdutório: combina fontes oficiais independentes, orientação profissional e investigação primária; explicita os limites da evidência; conserva todos os atributos canónicos relevantes; e fecha os principais riscos sem transformar o documento em prescrição ou autorização individual.
