# AUD-F — Auditoria independente de Técnica e Habilidade

## Âmbito

Auditoria independente de todos e apenas os exercícios cujo conteúdo final declara
`capability_primary == "technique_skill"`.

Exercícios auditados:

1. `archery_shot_cycle_to_target` — EX-41;
2. `basketball_set_shot_to_basket` — EX-42;
3. `volleyball_forearm_pass_to_target` — EX-43;
4. `football_directional_first_touch` — EX-44;
5. `boxing_jab_cross_to_focus_mitts` — EX-45.

Foram revistos 15 ficheiros de conteúdo, três por exercício:

- `*_beginner_content_v0.1.json`;
- `*_beginner_content_v0.1.md`;
- `*_research_report_v0.1.md`.

Foram ainda consultados exclusivamente os cinco pacotes de invariantes correspondentes
em `_beginner_content_workspace/agent_inputs/EX-41...EX-45`.

Não foram lidos relatórios de outros auditores.

## Método

1. Identificação programática do âmbito pelo valor de `capability_primary`.
2. Validação sintática dos cinco JSON finais.
3. Comparação de identidade, família, tipo, estado, equipamento obrigatório e opcional,
   equipamento pessoal, parceiro, alvo, spotter, supervisão, risco, ambiente, superfície,
   pré-requisitos e sinais de paragem com o `canonical_record` e as relações aprovadas
   de cada pacote.
4. Verificação do contrato documental: chaves obrigatórias e ordem, mínimos de passos,
   cues e erros, forma tripla dos erros e 12 perguntas de compreensão.
5. Leitura cruzada de JSON, Markdown e relatório para clareza, sequência técnica,
   posição inicial, respiração, erros e correções, segurança específica da modalidade,
   supervisão e fronteiras da identidade.
6. Pesquisa de dose fixa, progressão programada, promessa de resultado, diagnóstico,
   tratamento e autorização universal.
7. Revisão linguística de português europeu e consistência entre formatos.

## Resultado global

**Estado: CONFORME COM REVISÕES NÃO BLOQUEANTES.**

- Bloqueadores: **0**
- Findings moderados: **1**
- Findings menores: **3**
- Findings totais: **4**
- Exercícios sem finding próprio: **1**
- Exercícios com pelo menos um finding não bloqueante: **4**

Os cinco conteúdos preservam os invariantes críticos. Não foi encontrada dose fixa,
promessa de resultado, prescrição individual, redução de risco, remoção de equipamento,
dispensa indevida de parceiro/alvo/supervisão ou transformação da modalidade.

## Estados por exercício

| Exercício | Estado AUD-F | Findings | Síntese |
|---|---|---:|---|
| `archery_shot_cycle_to_target` | CONFORME | — | Sequência completa, saída segura antes da largada, campo especializado, alvo, barreira, proteções e supervisão obrigatória corretamente preservados. |
| `basketball_set_shot_to_basket` | CONFORME COM AJUSTES MENORES | F-003, F-004 | Técnica, ressalto, cesto, alvo e supervisão estão coerentes; restam linguagem pública e paridade do teste no Markdown. |
| `volleyball_forearm_pass_to_target` | CONFORME COM AJUSTES MENORES | F-003, F-004 | Plataforma, contacto, parceiro, alvo e espaço superior estão bem documentados; restam linguagem pública e paridade do teste. |
| `football_directional_first_touch` | CONFORME COM REVISÃO TÉCNICA | F-001 | Identidade fixa, parceiro, alvo, apoio e segurança estão preservados; a instrução da superfície de contacto é pouco operacional para principiante absoluto. |
| `boxing_jab_cross_to_focus_mitts` | CONFORME COM AJUSTES MENORES | F-002, F-003, F-004 | Ordem, guarda, rotação, proteção das mãos, parceiro e supervisão obrigatória estão preservados; há uma ambiguidade textual e ajustes editoriais. |

## Findings

### F-001 — Superfície de contacto do primeiro toque insuficientemente operacional

- **Severidade:** moderada
- **Blocker:** não
- **Exercício:** `football_directional_first_touch`
- **Campo:** `execution_steps_pt_pt` (passos 5–7), `principal_cues_pt_pt`,
  secção Markdown `Execução`
- **Evidência:** o conteúdo manda apresentar “uma superfície ampla e controlável do pé
  recetor” e orientar essa superfície para o alvo, mas não dá ao principiante absoluto
  um exemplo executável de superfície nem um critério simples de organização do
  tornozelo. O relatório confirma que a generalidade foi deliberada por não existir
  uma única superfície válida em todos os contextos. Essa prudência preserva a
  identidade, mas deixa a ação nuclear menos específica do que as restantes
  modalidades auditadas.
- **Impacto:** o principiante pode compreender o objetivo sem saber como configurar o
  pé para um contacto previsível; o supervisor fica sem um cue explícito para distinguir
  superfície estável de pé relaxado ou contacto na ponta.
- **Revisão pedida:** acrescentar, sem universalizar, um exemplo introdutório
  observável, como o interior do pé para uma direção simples, e um cue de tornozelo
  estável durante o contacto. Explicitar que outra superfície só é escolhida quando a
  direção definida a exigir e tiver sido demonstrada. Preservar passe rasteiro,
  resposta fixa, ausência de oposição e ausência de dose.

### F-002 — Referente ambíguo na orientação das manoplas

- **Severidade:** menor
- **Blocker:** não
- **Exercício:** `boxing_jab_cross_to_focus_mitts`
- **Campo:** `equipment_setup_pt_pt[2]`
- **Evidência:** o JSON diz que o parceiro fica “com as palmas das manoplas viradas para
  ele”. O antecedente de “ele” pode exigir releitura. O Markdown elimina a ambiguidade
  com “palmas viradas para o praticante”.
- **Impacto:** pequena perda de clareza numa instrução de equipamento e alvo com
  contacto.
- **Revisão pedida:** substituir no JSON o pronome por “viradas para o praticante”,
  alinhando literalmente os dois formatos, sem alterar posição, equipamento ou papel
  do parceiro.

### F-003 — Terminologia pública parcialmente não localizada

- **Severidade:** menor
- **Blocker:** não
- **Exercícios:** `basketball_set_shot_to_basket`,
  `volleyball_forearm_pass_to_target`, `boxing_jab_cross_to_focus_mitts`
- **Campo:** Markdown público e, no voleibol, `limitations_pt_pt`
- **Evidência:** aparecem termos como `spotter`, “cue/cues” e a construção “Os média
  permanecem por aprovar”. Os identificadores canónicos em inglês estão devidamente
  preservados, mas estas ocorrências encontram-se em prosa dirigida ao utilizador.
- **Impacto:** português europeu compreensível, mas menos natural para principiante
  absoluto e editorialmente inconsistente.
- **Revisão pedida:** usar “assistente de segurança (spotter)” na primeira ocorrência,
  “pista/pistas técnicas” ou “indicação/indicações”, e “conteúdos multimédia permanecem
  por aprovar”. Manter intactos IDs e valores canónicos quando apresentados como dados.

### F-004 — Teste de compreensão sem respostas no Markdown

- **Severidade:** menor
- **Blocker:** não
- **Exercícios:** `basketball_set_shot_to_basket`,
  `volleyball_forearm_pass_to_target`, `boxing_jab_cross_to_focus_mitts`
- **Campo:** secções Markdown `Verificação de compreensão` / `Teste de compreensão`
- **Evidência:** os JSON contêm 12 perguntas com respostas esperadas, mas os Markdown
  destes três exercícios apresentam apenas as perguntas. Tiro com arco e futebol
  incluem pergunta e resposta no Markdown.
- **Impacto:** não existe contradição técnica, mas há perda de paridade entre formatos
  e menor utilidade para auto-verificação ou revisão por supervisor.
- **Revisão pedida:** incluir uma chave de respostas ou respostas imediatamente após
  cada pergunta, seguindo o padrão já usado nos Markdown de tiro com arco e futebol.

## Invariantes confirmados

### Identidade e relações

- Os cinco `exercise_id`, nomes, tipos, famílias, `record_status`, `variant_of` e
  `base_exercise_id` coincidem com os pacotes.
- Os mapeamentos de ID de EX-42, EX-44 e EX-45 foram respeitados.
- Não foram criadas nem removidas relações. As relações condicionais de aquecimento de
  basquetebol e futebol permanecem condicionais e exteriores à decisão documental.

### Equipamento, parceiro, alvo e supervisão

- **Tiro com arco:** arco, flechas, anteparo, barreira de retenção, proteção de antebraço
  e dedos; alvo obrigatório; campo especializado; supervisão obrigatória.
- **Basquetebol:** bola e cesto; alvo obrigatório; parceiro não obrigatório;
  supervisão recomendada.
- **Voleibol:** bola; marcador de chão opcional; parceiro e alvo obrigatórios;
  supervisão recomendada.
- **Futebol:** bola; marcadores opcionais; calçado apropriado; parceiro e alvo
  obrigatórios; supervisão recomendada.
- **Boxe:** par de manoplas, luvas e ligaduras; parceiro e alvo obrigatórios;
  supervisão obrigatória.

### Risco e segurança da modalidade

- `high` no tiro com arco, com projétil, linha, acessos, alvo, barreira, comandos,
  inspeção e estratégia de saída fechada.
- `low` no basquetebol, voleibol e futebol, sem omitir ressalto/trajetória da bola,
  colisão, piso, iluminação e circulação.
- `moderate` no boxe, com proteção das mãos, controlo do contacto, competência do
  parceiro, proibição de sparring e critérios claros de interrupção.

Nenhum conteúdo reduz verbalmente o risco canónico nem usa o estado de principiante
como autorização universal.

### Estrutura contratual

| Exercício | Passos | Cues | Erros completos | Perguntas | Chaves obrigatórias em ordem |
|---|---:|---:|---:|---:|---|
| Tiro com arco | 11 | 7 | 7 | 12 | sim |
| Basquetebol | 7 | 6 | 6 | 12 | sim |
| Voleibol | 7 | 6 | 5 | 12 | sim |
| Futebol | 8 | 6 | 6 | 12 | sim |
| Boxe | 8 | 6 | 6 | 12 | sim |

Todos os erros têm `error_pt_pt`, `how_to_recognise_pt_pt` e `correction_pt_pt`.
Os cinco campos `unresolved_fields` estão vazios. Os cinco conteúdos usam
`beginner_content_approved_with_limits`.

### Respiração, dose e promessas

- Tiro com arco, basquetebol, voleibol e futebol usam respiração natural e contínua,
  sem contagens nem retenção deliberada.
- O boxe usa expiração curta em cada contacto, sustentada no relatório, sem contagem,
  retenção ou promessa fisiológica.
- Não há séries, repetições, duração, distância, carga, intensidade, cadência,
  frequência ou progressão programada prescritas.
- Não há promessa de resultado, diagnóstico, tratamento ou garantia de segurança
  universal.

## Padrões observados

1. Forte preservação transversal de equipamento, parceiro/alvo e supervisão.
2. Sequências técnicas ordenadas e com fecho seguro em todas as modalidades.
3. Boa separação entre identidade do exercício e prescrição.
4. Respiração tratada de forma conservadora quando não existe orientação federativa
   específica.
5. Os únicos desvios recorrentes são editoriais: anglicismos em prosa pública e
   respostas do teste omitidas em alguns Markdown.
6. A única lacuna técnica materialmente relevante é a operacionalização da superfície
   de contacto no primeiro toque de futebol.

## Independência

AUD-F não foi autor de qualquer conteúdo auditado. A revisão foi efetuada a partir dos
15 ficheiros finais e dos cinco pacotes de invariantes aplicáveis, sem consulta de
relatórios de outros auditores e sem coordenação de conclusões com autores.

## Zero implementação

Esta auditoria não alterou JSON, Markdown de conteúdo, relatórios de investigação,
registos canónicos, relações, risco, equipamento, multimédia ou código. Não publicou
conteúdo e não executou implementação. O único artefacto produzido por AUD-F é este
relatório.
