# Relatório de investigação — `two_point_sprint_start`

**Agente:** EX-12  
**Data:** 2026-07-23  
**Âmbito:** execução documental para principiante, posição, respiração, segurança, travagem, erros e supervisão  
**Classificação de risco preservada:** alto  
**Implementação realizada: não**

## Resultado

O conteúdo pode ser marcado como `beginner_content_approved_with_limits`. A identidade canónica está bem delimitada: partida em pé com dois apoios e base assimétrica, projeção inicial e primeiros apoios acelerativos, terminando antes do sprint contínuo.

A cobertura técnica é defensável por convergência entre um manual oficial de federação, um guia profissional independente e investigação biomecânica primária. O limite principal é a escassez de evidência direta que descreva, passo a passo, esta exata partida de dois apoios para principiantes.

## Preservação do registo

Não foram alterados:

- `exercise_id`: `two_point_sprint_start`;
- nome: Arranque de sprint de dois apoios;
- tipo: `technique_drill`;
- família: `sprint_locomotion`;
- exercício-base: `linear_sprint`;
- `variant_of`: `none`;
- capacidade principal: `speed_power`;
- risco operacional: `high`;
- ausência de equipamento obrigatório e opcional;
- requisito de supervisão: recomendado;
- ambientes, superfície, corredor e zona de desaceleração;
- relações canónicas aprovadas de ativação e aquecimento.

Não foram criadas relações, variantes, prescrições, aprovações de multimédia ou alterações de risco.

## Fontes consultadas

### B1-S02 — Athletics Ireland

**Fonte:** *AAi Coach Sprints Manual*  
**Tipo:** manual oficial de federação  
**Ligação:** https://www.athleticsireland.ie/wp-content/uploads/2024/10/AAI-Coach_Sprints_Manual.pdf

Contributos usados:

- a aceleração é ensinada através de pressão para trás contra o chão e separação coordenada dos braços e pernas;
- o corpo e a cabeça sobem gradualmente durante a aceleração, em vez de se erguerem abruptamente;
- a partida em posição baixa e o primeiro apoio forte são usados como progressões técnicas;
- a sessão de sprint inclui preparação geral e específica;
- a desaceleração deve ser gradual e não uma paragem súbita;
- os princípios devem ser ajustados à idade e à experiência.

Limite: o manual abrange a família do sprint e várias partidas, não apenas a partida de dois apoios.

### EX12-S01 — Kugler e Janshen

**Fonte:** *Body position determines propulsive forces in accelerated running*  
**Tipo:** estudo biomecânico primário revisto por pares  
**Ligação:** https://pubmed.ncbi.nlm.nih.gov/19863962/  
**DOI:** https://doi.org/10.1016/j.jbiomech.2009.07.041

Contributo usado: a orientação da força propulsiva durante a aceleração está relacionada com a posição do corpo; acelerações superiores foram associadas a forças mais baixas e orientadas mais para a frente. Isto sustenta uma inclinação corporal coerente e a instrução de empurrar o chão para trás, sem transformar o resultado num ângulo prescrito.

Limite: a amostra incluiu estudantes de educação física e o protocolo não constituiu ensino específico para principiantes.

### EX12-S02 — Special Olympics

**Fonte:** *Sports Essentials Athletics Coaching Guide*  
**Tipo:** guia profissional oficial de treino  
**Ligação:** https://media.specialolympics.org/resources/sports-essentials/coaching-guides/Sports-Essentials-Athletics-Coaching-Guide-2017-Version.pdf

Contributos usados:

- reconhece a partida de pé;
- inclui postura equilibrada, bacia organizada e oposição entre joelho e braço;
- usa a capacidade de sprintar sob controlo como critério observável;
- enquadra adaptação e supervisão no ensino.

Limite: é um guia amplo para uma população específica e não fornece todos os pormenores biomecânicos deste drill.

### EX12-S03 — Donaldson e colaboradores

**Fonte:** *Inter- and intra-limb coordination during initial sprint acceleration*  
**Tipo:** estudo biomecânico primário revisto por pares  
**Ligação:** https://pmc.ncbi.nlm.nih.gov/articles/PMC9555766/

Contributo usado: a aceleração inicial exige coordenação organizada entre membros e ao longo dos primeiros contactos, sustentando a ênfase em oposição braço–perna e transição progressiva.

Limite: os resultados descrevem investigação biomecânica e não equivalem a instruções universais.

### SP-B2-S16 — Haugen e colaboradores

**Fonte:** *Training and Development of Elite Sprint Performance: an Integration of Scientific and Best Practice Literature*  
**Tipo:** revisão científica e de prática profissional  
**Ligação:** https://doi.org/10.1186/s40798-019-0221-0

Contributo usado: enquadramento da aceleração, da mecânica de sprint e da prática técnica.

Limite: o foco é o desenvolvimento de desempenho, não um guia autónomo de segurança para principiantes.

## Síntese técnica

### Posição inicial

O conteúdo usa uma posição em pé com dois pés no chão e base assimétrica. Um pé fica à frente, os joelhos e ancas mantêm flexão ligeira, o corpo inclina-se de forma organizada e o braço oposto à perna da frente prepara-se à frente. Não foram definidos ângulos, distâncias entre os pés ou marcas universais.

### Projeção e primeiros apoios

A instrução central é empurrar o chão para trás para projetar o corpo para a frente, coordenando braços e pernas em oposição. O primeiro pé que avança procura contacto perto da trajetória da bacia, evitando um apoio muito adiantado que introduza travagem. O tronco sobe progressivamente.

### Respiração

Não foi encontrada uma orientação respiratória específica, primária e exclusiva para a partida de dois apoios. Aplicou-se a regra contratual conservadora: expiração natural na saída, respiração livre e contínua e ausência de retenção ou contagem imposta.

### Travagem

O drill termina antes do sprint contínuo, mas a pessoa não deve parar nesse instante. Deixa de procurar aceleração, mantém a direção, eleva o tronco progressivamente e reduz a velocidade com passos controlados dentro da zona reservada. Foram excluídas travagens com joelhos bloqueados, mudança brusca de direção ou paragem súbita.

## Segurança de risco alto

Foram preenchidos os cinco campos adicionais obrigatórios:

1. pré-requisito técnico: compreensão do sinal de interrupção, corrida linear básica, equilíbrio na base assimétrica e desaceleração controlada;
2. supervisão: recomendada e prioritária na primeira exposição, perante inexperiência e antes de aumentar rapidez ou impacto;
3. espaço seguro: corredor linear visível, superfície firme, regular e não escorregadia, percurso e zona de travagem livres;
4. controlo de apoio e travagem: contacto perto da trajetória da bacia e desaceleração progressiva, sem bloqueio dos joelhos ou viragem abrupta;
5. estratégia de saída: não iniciar a partir de uma posição instável; depois da saída, abandonar a aceleração e reduzir a velocidade na trajetória livre mais segura.

Os sinais de interrupção preservam o registo canónico e incluem dor aguda, mal-estar, perda súbita de coordenação e incapacidade de controlar a travagem ou a paragem.

## Erros documentados

Foram descritos oito erros com sinal observável e correção:

- passo de balanço ou alteração dos pés;
- flexão apenas pela cintura;
- subida abrupta do tronco;
- primeiro apoio demasiado à frente;
- braços ipsilaterais ou a cruzar o peito;
- posição baixa mantida de forma forçada;
- retenção da respiração e tensão desnecessária;
- continuação da aceleração ou travagem brusca sem espaço.

## Limitações e confiança

**Confiança global:** moderada.

A identidade e os requisitos de risco têm confiança alta por derivarem do registo canónico. A execução e a segurança têm confiança moderada: existe convergência de fontes independentes, mas a evidência direta para principiantes nesta exata configuração é limitada. Por essa razão, o conteúdo não prescreve ângulos, velocidade, distância, volume, frequência, descanso ou progressão programada e mantém a recomendação de supervisão.

## Verificação contratual

- Português europeu: sim.
- UTF-8 e normalização NFC: confirmadas mecanicamente.
- JSON com chaves obrigatórias e ordem contratada: confirmado mecanicamente.
- Passos de execução: 8.
- Pistas principais: 7.
- Erros com forma completa: 8.
- Perguntas de compreensão: 12.
- Campos adicionais de risco alto: 5.
- Dose ou prescrição: não incluída.
- Promessa, diagnóstico ou tratamento: não incluídos.
- Relações, equipamento, identidade e risco: preservados.
- Código ou publicação: não realizados.
- Implementação realizada: não.
