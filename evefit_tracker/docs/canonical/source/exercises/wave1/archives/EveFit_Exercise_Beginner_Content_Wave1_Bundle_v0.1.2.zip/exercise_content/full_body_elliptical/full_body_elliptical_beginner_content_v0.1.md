# Movimento elíptico de corpo inteiro

Conteúdo para principiantes em português europeu.

## Descrição curta

Ciclo guiado numa máquina elíptica, com os pés nos pedais e as mãos nas alavancas móveis, coordenando braços e pernas.

## O que é

Neste exercício permaneces de pé numa máquina estacionária. Os pés acompanham pedais de trajetória elíptica e as mãos empurram e puxam as alavancas móveis em coordenação com as pernas. Não existe fase aérea: os pés mantêm-se apoiados nos pedais.

## O que vais fazer

Vais entrar na máquina parada, colocar os dois pés nos pedais, segurar as duas alavancas móveis e produzir um ciclo contínuo: uma perna avança enquanto o braço oposto acompanha a respetiva alavanca, alternando os lados de forma fluida.

## Porque existe este movimento

A finalidade técnica imediata é produzir um movimento propulsivo, rítmico e estacionário de corpo inteiro contra a resistência guiada da máquina.

## Antes de começares

1. Lê e segue as instruções do modelo concreto, incluindo bloqueio de pedais, alimentação, consola e limites de utilização.
2. Confirma que a máquina está nivelada, não oscila e não apresenta peças soltas, desgaste visível, cabos danificados ou funcionamento irregular.
3. Mantém a zona de entrada, saída e movimento das alavancas livre de pessoas e objetos.
4. Confirma que pedais e pegas estão limpos e secos e que roupa solta, atacadores, toalhas e outros objetos não podem alcançar partes móveis.
5. Se não conheces a máquina ou tens dificuldade de equilíbrio, pede supervisão antes de subir.

## Preparar o equipamento

1. Usa uma máquina elíptica de corpo inteiro com dois pedais e duas alavancas móveis funcionais.
2. Segue o manual do fabricante para ligar, desbloquear ou preparar o modelo; os comandos variam entre máquinas.
3. Testa a estabilidade sem subir: a base deve permanecer firme e os componentes devem estar seguros.
4. Coloca o pedal do lado de entrada na posição mais baixa apenas pelo método indicado pelo fabricante e com a máquina parada.
5. Não uses a máquina se estiver danificada, instável, húmida nas zonas de contacto ou a funcionar de forma anormal.

## Preparar o espaço

1. Escolhe uma zona interior, nivelada e bem iluminada.
2. Deixa livre o espaço necessário ao percurso dos pedais e das alavancas e à entrada e saída lateral.
3. Afasta mobiliário, objetos, cabos de passagem e outras pessoas da área ativa.
4. Se o modelo tiver cabo de alimentação, confirma que não fica preso nem numa zona onde possa ser pisado.

## Verificação do corpo

1. Consegues manter-te de pé com ambos os pés apoiados e alcançar as alavancas sem te inclinares sobre a consola.
2. Consegues segurar um apoio e subir lateralmente de forma controlada.
3. Não tens, antes de começares, desconforto no peito, falta de ar fora do habitual, tonturas, confusão, dor nova ou instabilidade marcada.
4. Se regressas após lesão ou cirurgia, ou tens sintomas cardiorrespiratórios relevantes, procura revisão adequada antes de executares.

## Posição inicial

Com a máquina completamente parada, aproxima-te por um lado. Segura o apoio fixo, coloca o pé mais próximo no pedal baixo e sobe de forma controlada para o outro pedal. Fica voltado para a consola, com os pés orientados para a frente e as mãos confortavelmente nas duas alavancas móveis.

## Confirmar a posição inicial

1. A máquina está parada, estável e sem sinais de avaria.
2. Os dois pés estão apoiados nos pedais e orientados para a frente.
3. As duas mãos seguram as alavancas móveis.
4. O tronco está direito, voltado para a frente, sem apoio de peso na consola.
5. Os ombros estão descontraídos e os joelhos não estão bloqueados.
6. Há espaço livre para pedais, alavancas, entrada e saída.

## Passos de execução

1. Com a máquina parada, segura primeiro o apoio fixo e sobe lateralmente, colocando um pé de cada vez nos pedais.
2. Depois de estabilizares os dois pés, coloca uma mão em cada alavanca móvel e mantém o corpo voltado para a frente.
3. Inicia o ciclo sem impulso brusco, fazendo os pedais percorrerem a trajetória guiada enquanto acompanhas o movimento das alavancas.
4. Coordena a alternância: quando um braço empurra, o outro puxa, acompanhando o movimento recíproco das pernas.
5. Mantém os dois pés em contacto com os pedais e as duas mãos em contacto seguro com as alavancas móveis.
6. Mantém o tronco direito e estável, os ombros descontraídos e os joelhos a acompanhar a direção dos pés, sem os bloquear.
7. Deixa a respiração decorrer de forma natural, regular e contínua, sem prender o ar e sem impor uma contagem.
8. Para terminar, reduz o movimento de forma controlada, espera pela imobilização completa e só depois usa o apoio fixo para sair.

## Fases do movimento

### Entrada e estabilização

A máquina está parada; o apoio fixo ajuda a subir lateralmente e a colocar os dois pés nos pedais.

### Início do ciclo

Os pedais começam a mover-se na trajetória guiada e as mãos passam a acompanhar as alavancas móveis.

### Alternância coordenada

Braços e pernas alternam num padrão recíproco, com empurrar de um lado e puxar do outro.

### Continuidade controlada

Mantêm-se os contactos, a orientação para a frente, a postura estável e a respiração contínua.

### Paragem e saída

O ciclo desacelera sob controlo até a máquina parar; a saída faz-se lateralmente com apoio fixo.

## Respiração

Respira de forma natural, regular e contínua durante todo o ciclo. Não prendas a respiração e não forces uma sincronização com cada passada ou cada movimento das alavancas. Uma alteração progressiva da ventilação pode acompanhar o esforço, mas falta de ar atípica é sinal para parar.

## Sensações esperadas

1. Contacto contínuo dos pés com os pedais e das mãos com as alavancas.
2. Resistência guiada e regular ao empurrar os pedais e ao empurrar e puxar as alavancas.
3. Alternância coordenada entre os lados do corpo.
4. Trabalho simultâneo dos membros inferiores e superiores, com o tronco a estabilizar.
5. Respiração que pode tornar-se mais evidente, mas permanece contínua e controlável.

## Sensações inesperadas ou de alerta

1. Desconforto no peito ou falta de ar atípica.
2. Tonturas ou confusão.
3. Dor nova.
4. Perda de controlo, desequilíbrio ou incapacidade de manter mão ou pé em contacto.
5. Solavancos, travagem inesperada, ruído anormal ou movimento instável da máquina.

## Indicações técnicas principais

1. Pés apoiados e orientados para a frente.
2. Mãos nas alavancas móveis.
3. Empurra e puxa em alternância com as pernas.
4. Tronco direito, cabeça e corpo voltados para a frente.
5. Joelhos desbloqueados e alinhados com os pés.
6. Respira continuamente e controla a paragem.

## Erros comuns e correções

### Erro 1: Usar os apoios fixos durante o ciclo e deixar os braços passivos.

- Como reconhecer: As pernas movem os pedais, mas as mãos não acompanham as alavancas móveis; a execução deixa de corresponder à identidade de corpo inteiro.
- Como corrigir: Depois de estabilizares a entrada, coloca ambas as mãos nas alavancas móveis e coordena o empurrar e puxar com as pernas.

### Erro 2: Subir ou sair enquanto os pedais ainda se movem.

- Como reconhecer: O pedal muda de posição durante a transferência do peso ou a pessoa tenta saltar para o chão.
- Como corrigir: Espera pela imobilização completa, coloca o pedal do lado de saída baixo pelo método indicado no manual e usa o apoio fixo.

### Erro 3: Perder contacto de uma mão ou de um pé durante o ciclo.

- Como reconhecer: Uma mão larga a alavanca, um pé levanta do pedal ou há necessidade de recuperar o equilíbrio de forma súbita.
- Como corrigir: Interrompe o ciclo de forma controlada, recupera uma posição estável e retoma apenas quando consegues manter os quatro contactos.

### Erro 4: Inclinar o tronco sobre a consola ou puxar o corpo pelas alavancas.

- Como reconhecer: O peito aproxima-se da consola, os ombros sobem ou o tronco oscila a cada ciclo.
- Como corrigir: Volta a colocar o tronco direito e estável, relaxa os ombros e usa as alavancas para empurrar e puxar sem te pendurares nelas.

### Erro 5: Deixar os joelhos desviarem-se para dentro ou para fora.

- Como reconhecer: Os joelhos não acompanham a direção dos pés ao longo da trajetória.
- Como corrigir: Reposiciona os pés para a frente e acompanha a trajetória guiada mantendo os joelhos na mesma direção.

### Erro 6: Parar de forma brusca ou tentar travar saltando dos pedais.

- Como reconhecer: O corpo é projetado, as mãos apertam subitamente as alavancas ou os pedais continuam a deslocar-se quando a pessoa tenta sair.
- Como corrigir: Mantém os contactos, reduz o movimento progressivamente e aguarda que pedais e alavancas parem por completo.

## Formas de simplificar ou ensaiar

1. Pede a um profissional que identifique o apoio fixo, as alavancas móveis, o lado de entrada e os comandos de paragem antes de subires.
2. Organiza a aprendizagem por prioridades: primeiro os quatro contactos, depois a postura e, por fim, a alternância dos braços, mantendo sempre a identidade de corpo inteiro.
3. Faz as alterações de consola antes de iniciares ou depois de parar, para não teres de largar uma alavanca durante o ciclo.
4. Usa indicações verbais simples, como «pés apoiados», «olhar em frente» e «empurra e puxa», sem acrescentar dose.

## Supervisão

A supervisão é recomendada. É especialmente importante quando a pessoa não conhece o modelo, apresenta instabilidade marcada ou não consegue coordenar pedais e alavancas mantendo os contactos. O supervisor deve demonstrar entrada, paragem e saída, confirmar a estabilidade da máquina e permanecer perto sem interferir nas partes móveis.

## Como terminar

Mantém os pés nos pedais e as mãos nas alavancas enquanto reduzes o movimento de forma controlada. Espera até pedais e alavancas ficarem completamente imóveis. Passa uma mão para o apoio fixo. Confirma que o pedal do lado de saída está baixo, conforme o método do fabricante. Sai lateralmente, um pé de cada vez, mantendo o apoio até estares estável no chão. Deixa a máquina no estado seguro indicado pelo respetivo manual.

## Nota de segurança

A configuração de corpo inteiro exige controlo simultâneo dos pedais e das alavancas móveis. Não uses a máquina se estiver instável, danificada ou com comportamento anormal; não largues os apoios durante a entrada ou saída e não desmontes antes de a máquina parar.

## Quando parar ou reduzir

1. Desconforto no peito ou falta de ar atípica. — Para o movimento de forma controlada e não continues sem avaliação adequada.
2. Tonturas ou confusão. — Para, mantém apoio seguro e pede ajuda.
3. Perda de controlo ou dor nova. — Termina a execução e não retomes até a causa ter sido adequadamente revista.
4. Falha, instabilidade ou movimento anormal da máquina. — Interrompe, sai apenas após imobilização completa e retira a máquina de utilização.

## Segurança do equipamento

Segue sempre o manual do modelo concreto; mecanismos de bloqueio, comandos e geometrias diferem. Confirma que base, pedais e alavancas estão firmes e funcionais antes de subires. Mantém pedais e pegas limpos e secos. Mantém mãos, pés, roupa solta, atacadores e objetos afastados das zonas móveis que não são pontos normais de contacto. Não uses acessórios não aprovados nem tentes reparar a máquina durante a utilização. Retira de serviço qualquer máquina danificada, instável ou com funcionamento irregular.

## Segurança do espaço

Utiliza apenas num espaço interior compatível, com base nivelada e máquina estável. Mantém desimpedida a área lateral de entrada e saída e todo o percurso de pedais e alavancas. Garante visibilidade suficiente para ver os apoios, os pedais e a zona de saída. Evita proximidade de água, humidade excessiva e cabos atravessados na passagem. Não permitas que outras pessoas interfiram com a máquina durante o movimento.

## Limitações

1. Os mecanismos de bloqueio, os comandos da consola, a geometria dos pedais e o comportamento de paragem variam entre modelos; o manual da máquina prevalece.
2. Não foi fixada qualquer dose, resistência, inclinação, velocidade, cadência, amplitude, duração ou programa.
3. O conteúdo não determina elegibilidade individual, não diagnostica sintomas e não substitui revisão clínica ou supervisão quando indicada.
4. Os estudos biomecânicos sustentam a família mecânica, mas não autorizam promessas de resultado nem generalização clínica.
5. A indicação «tronco direito» descreve controlo postural geral; ajustes individuais dependem da geometria da máquina e da capacidade da pessoa.

## Teste de compreensão

### 1. Que componentes tornam esta execução «de corpo inteiro»?

Resposta esperada: Os pedais são usados em conjunto com as duas alavancas móveis, coordenando pernas e braços.

### 2. A máquina pode estar em movimento quando sobes?

Resposta esperada: Não. A entrada é feita com a máquina completamente parada.

### 3. Que apoio deves usar para estabilizar a entrada e a saída?

Resposta esperada: O apoio fixo indicado pelo fabricante.

### 4. Onde devem permanecer os pés durante o ciclo?

Resposta esperada: Apoiados nos pedais e orientados para a frente.

### 5. Onde devem estar as mãos durante a parte ativa?

Resposta esperada: Nas duas alavancas móveis.

### 6. Como se coordenam os braços?

Resposta esperada: Alternam empurrar e puxar em coordenação com o movimento recíproco das pernas.

### 7. Qual é a posição geral do tronco e da cabeça?

Resposta esperada: Direitos, estáveis e voltados para a frente, sem apoio de peso na consola.

### 8. Como deve decorrer a respiração?

Resposta esperada: De forma natural, regular e contínua, sem prender o ar nem impor contagens.

### 9. O que fazes antes de sair dos pedais?

Resposta esperada: Reduzo o movimento sob controlo e espero pela imobilização completa.

### 10. Que sinais pessoais obrigam a parar?

Resposta esperada: Desconforto no peito ou falta de ar atípica, tonturas ou confusão, perda de controlo ou dor nova.

### 11. O que fazes se a máquina oscilar, travar ou produzir movimento anormal?

Resposta esperada: Paro de forma controlada, saio apenas depois da imobilização e retiro a máquina de utilização.

### 12. Quando é especialmente importante ter supervisão?

Resposta esperada: Quando a máquina é desconhecida, existe instabilidade marcada ou não se consegue coordenar pedais e alavancas com contactos seguros.

## Fontes e limites da evidência

### Fonte 1: X3 Total-Body Elliptical Cross-Trainer — User Manual

- Autor ou entidade: EX05-S01 — X3 Total-Body Elliptical Cross-Trainer — User Manual — Life Fitness — documentação oficial do fabricante — https://www.lftechsupport.com/c/document_library/get_file?folderId=1626631&name=DLFE-45559.pdf&p_l_id=1691375 — Entrada e saída, postura, contacto dos pés, alavancas móveis, estabilidade, área livre e segurança do equipamento. — Manual de um modelo específico; os comandos e alguns detalhes de montagem não são universais.
- Tipo: documentação oficial do fabricante
- Localizador: https://www.lftechsupport.com/c/document_library/get_file?folderId=1626631&name=DLFE-45559.pdf&p_l_id=1691375
- Usada para: EX05-S01 — X3 Total-Body Elliptical Cross-Trainer — User Manual — Life Fitness — documentação oficial do fabricante — https://www.lftechsupport.com/c/document_library/get_file?folderId=1626631&name=DLFE-45559.pdf&p_l_id=1691375 — Entrada e saída, postura, contacto dos pés, alavancas móveis, estabilidade, área livre e segurança do equipamento. — Manual de um modelo específico; os comandos e alguns detalhes de montagem não são universais.
- Limite: Manual de um modelo específico; os comandos e alguns detalhes de montagem não são universais.

### Fonte 2: Precision and Energy Series Elliptical Fitness Crosstrainers — Owner's Manual

- Autor ou entidade: EX05-S02 — Precision and Energy Series Elliptical Fitness Crosstrainers — Owner's Manual — Precor — documentação oficial do fabricante — https://static.precor.com/precor-at-home/legacy/EFX_222_Manuals_103117_ENU.pdf — Superfície nivelada, área desimpedida, orientação do corpo, pegas seguras, paragem perante sintomas e retirada de equipamento danificado. — Abrange uma família de modelos Precor e inclui funcionalidades que podem não existir noutras máquinas.
- Tipo: documentação oficial do fabricante
- Localizador: https://static.precor.com/precor-at-home/legacy/EFX_222_Manuals_103117_ENU.pdf
- Usada para: EX05-S02 — Precision and Energy Series Elliptical Fitness Crosstrainers — Owner's Manual — Precor — documentação oficial do fabricante — https://static.precor.com/precor-at-home/legacy/EFX_222_Manuals_103117_ENU.pdf — Superfície nivelada, área desimpedida, orientação do corpo, pegas seguras, paragem perante sintomas e retirada de equipamento danificado. — Abrange uma família de modelos Precor e inclui funcionalidades que podem não existir noutras máquinas.
- Limite: Abrange uma família de modelos Precor e inclui funcionalidades que podem não existir noutras máquinas.

### Fonte 3: Elliptical Frame Owner's Guide

- Autor ou entidade: EX05-S03 — Elliptical Frame Owner's Guide — Matrix Fitness — documentação do fabricante — https://www.jhta.com.au/wp-content/uploads/2021/03/Elliptical-Frame-Owners-Guide.pdf — Pedal baixo e máquina parada para entrada e saída, preensão para equilíbrio, pedais sem roda livre e desaceleração controlada. — Manual de modelos comerciais específicos; não sustenta uma configuração universal.
- Tipo: documentação do fabricante
- Localizador: https://www.jhta.com.au/wp-content/uploads/2021/03/Elliptical-Frame-Owners-Guide.pdf
- Usada para: EX05-S03 — Elliptical Frame Owner's Guide — Matrix Fitness — documentação do fabricante — https://www.jhta.com.au/wp-content/uploads/2021/03/Elliptical-Frame-Owners-Guide.pdf — Pedal baixo e máquina parada para entrada e saída, preensão para equilíbrio, pedais sem roda livre e desaceleração controlada. — Manual de modelos comerciais específicos; não sustenta uma configuração universal.
- Limite: Manual de modelos comerciais específicos; não sustenta uma configuração universal.

### Fonte 4: Getting Active to Control High Blood Pressure

- Autor ou entidade: EX05-S04 — Getting Active to Control High Blood Pressure — American Heart Association — orientação profissional — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Respiração regular durante a atividade e prevenção da retenção da respiração. — Orientação geral de atividade física, não específica da elíptica.
- Tipo: orientação profissional
- Localizador: https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure
- Usada para: EX05-S04 — Getting Active to Control High Blood Pressure — American Heart Association — orientação profissional — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — Respiração regular durante a atividade e prevenção da retenção da respiração. — Orientação geral de atividade física, não específica da elíptica.
- Limite: Orientação geral de atividade física, não específica da elíptica.

### Fonte 5: Heart Attack, Stroke and Cardiac Arrest Symptoms

- Autor ou entidade: EX05-S05 — Heart Attack, Stroke and Cardiac Arrest Symptoms — American Heart Association — orientação profissional — https://www.heart.org/en/about-us/heart-attack-and-stroke-symptoms — Reconhecimento de desconforto no peito, falta de ar e tontura como sinais de alarme. — Fonte de reconhecimento de sinais; não determina diagnóstico nem elegibilidade individual.
- Tipo: orientação profissional
- Localizador: https://www.heart.org/en/about-us/heart-attack-and-stroke-symptoms
- Usada para: EX05-S05 — Heart Attack, Stroke and Cardiac Arrest Symptoms — American Heart Association — orientação profissional — https://www.heart.org/en/about-us/heart-attack-and-stroke-symptoms — Reconhecimento de desconforto no peito, falta de ar e tontura como sinais de alarme. — Fonte de reconhecimento de sinais; não determina diagnóstico nem elegibilidade individual.
- Limite: Fonte de reconhecimento de sinais; não determina diagnóstico nem elegibilidade individual.

### Fonte 6: Effects of Stationary Bikes and Elliptical Machines on Knee Joint Kinematics and Kinetics during Exercise

- Autor ou entidade: A1-S17 — Effects of Stationary Bikes and Elliptical Machines on Knee Joint Kinematics and Kinetics during Exercise — He et al. — estudo biomecânico — https://pubmed.ncbi.nlm.nih.gov/38541224/ — Apoio à distinção mecânica entre elíptica e bicicleta estacionária. — Não define instruções universais de execução nem elegibilidade.
- Tipo: estudo biomecânico
- Localizador: https://pubmed.ncbi.nlm.nih.gov/38541224/
- Usada para: A1-S17 — Effects of Stationary Bikes and Elliptical Machines on Knee Joint Kinematics and Kinetics during Exercise — He et al. — estudo biomecânico — https://pubmed.ncbi.nlm.nih.gov/38541224/ — Apoio à distinção mecânica entre elíptica e bicicleta estacionária. — Não define instruções universais de execução nem elegibilidade.
- Limite: Não define instruções universais de execução nem elegibilidade.

### Fonte 7: Similarity of joint kinematics and muscle demands between elliptical training and walking

- Autor ou entidade: A1-S18 — Similarity of joint kinematics and muscle demands between elliptical training and walking — Burnfield et al. — estudo biomecânico — https://pubmed.ncbi.nlm.nih.gov/20022994/ — Apoio à natureza cíclica guiada e à comparação com marcha. — Amostra e equipamento específicos; não sustenta prescrição.
- Tipo: estudo biomecânico
- Localizador: https://pubmed.ncbi.nlm.nih.gov/20022994/
- Usada para: A1-S18 — Similarity of joint kinematics and muscle demands between elliptical training and walking — Burnfield et al. — estudo biomecânico — https://pubmed.ncbi.nlm.nih.gov/20022994/ — Apoio à natureza cíclica guiada e à comparação com marcha. — Amostra e equipamento específicos; não sustenta prescrição.
- Limite: Amostra e equipamento específicos; não sustenta prescrição.

### Fonte 8: How do elliptical machines differ from walking: a study of torso motion and muscle activity

- Autor ou entidade: A2-S19 — How do elliptical machines differ from walking: a study of torso motion and muscle activity — Moreside et al. — estudo biomecânico — https://pubmed.ncbi.nlm.nih.gov/22534321/ — Apoio à atenção dada ao controlo do tronco. — Condições experimentais específicas; não valida uma postura única para todos os modelos.
- Tipo: estudo biomecânico
- Localizador: https://pubmed.ncbi.nlm.nih.gov/22534321/
- Usada para: A2-S19 — How do elliptical machines differ from walking: a study of torso motion and muscle activity — Moreside et al. — estudo biomecânico — https://pubmed.ncbi.nlm.nih.gov/22534321/ — Apoio à atenção dada ao controlo do tronco. — Condições experimentais específicas; não valida uma postura única para todos os modelos.
- Limite: Condições experimentais específicas; não valida uma postura única para todos os modelos.

### Fonte 9: Joint loading in the lower extremities during elliptical exercise

- Autor ou entidade: A2-S20 — Joint loading in the lower extremities during elliptical exercise — Lu et al. — estudo biomecânico — https://pubmed.ncbi.nlm.nih.gov/17805099/ — Apoio à trajetória guiada e à carga articular própria da elíptica. — Amostra pequena e equipamento específico; não justifica promessas de segurança clínica.
- Tipo: estudo biomecânico
- Localizador: https://pubmed.ncbi.nlm.nih.gov/17805099/
- Usada para: A2-S20 — Joint loading in the lower extremities during elliptical exercise — Lu et al. — estudo biomecânico — https://pubmed.ncbi.nlm.nih.gov/17805099/ — Apoio à trajetória guiada e à carga articular própria da elíptica. — Amostra pequena e equipamento específico; não justifica promessas de segurança clínica.
- Limite: Amostra pequena e equipamento específico; não justifica promessas de segurança clínica.

### Fonte 10: Ellipticals

- Autor ou entidade: A2-S42 — Ellipticals — Life Fitness — página oficial de fabricante — https://shop.lifefitness.com/collections/ellipticals — Confirma a existência de configurações com braços móveis e apoio fixo. — Fonte comercial, usada apenas para equipamento e variantes.
- Tipo: página oficial de fabricante
- Localizador: https://shop.lifefitness.com/collections/ellipticals
- Usada para: A2-S42 — Ellipticals — Life Fitness — página oficial de fabricante — https://shop.lifefitness.com/collections/ellipticals — Confirma a existência de configurações com braços móveis e apoio fixo. — Fonte comercial, usada apenas para equipamento e variantes.
- Limite: Fonte comercial, usada apenas para equipamento e variantes.
