# Relatório de investigação — `lateral_leg_swing`

**Agente:** EX-33  
**Data da pesquisa:** 24-07-2026  
**Idioma do conteúdo:** português europeu  
**Âmbito:** execução para principiante, apoio, respiração, segurança, amplitude, impulso, erros e supervisão  
**Implementação realizada: não**

## Mandato e limites

Foi analisado exclusivamente o pacote de entrada `EX-33__lateral_leg_swing.json`. Não foram consultados outros pacotes ou outputs locais.

O trabalho foi documental. Não incluiu código, publicação, prescrição, diagnóstico, tratamento, promessa de resultado, aprovação de média ou alteração de identidade, risco, equipamento ou relações.

Foram mantidos:

- `exercise_id`: `lateral_leg_swing`;
- identidade: oscilação ativa da perna livre em adução e abdução da anca, em apoio unipodal, com pelve orientada e travagem nas mudanças de direção;
- risco operacional: `moderate`;
- equipamento obrigatório: nenhum;
- equipamento opcional: `freestanding_stable_support`;
- superfície: estável e antiderrapante;
- espaço: trajeto lateral livre e sem obstáculos;
- supervisão-base: `none`;
- parceiro, alvo e observador: não obrigatórios;
- relações aprovadas: duas compatíveis e uma condicional, sem novas relações.

## Perguntas de investigação

1. Como deve ser organizada a posição inicial?
2. Que apoio manual é defensável sem o tornar obrigatório?
3. Como se descreve a trajetória lateral a um principiante?
4. Como se distingue amplitude controlada de amplitude criada por compensação?
5. Como deve ser gerido o impulso?
6. Onde deve ocorrer a travagem?
7. Qual é a orientação respiratória mais prudente?
8. Que sensações são esperáveis e quais exigem redução ou paragem?
9. Que erros são observáveis por um principiante?
10. Como terminar a oscilação em segurança?
11. Quando é pertinente supervisão apesar de não ser exigida na execução-base?
12. Até onde a literatura permite sustentar efeitos ou benefícios?

## Estratégia de pesquisa

Foram priorizadas:

- a fonte canónica interna para identidade, risco, elegibilidade, ambiente, equipamento e relações;
- fontes profissionais e oficiais com instruções de execução;
- literatura científica primária sobre alongamento dinâmico;
- uma fonte clínica profissional para respiração e interpretação de dor;
- fontes independentes entre si.

As pesquisas abrangeram combinações de “lateral leg swing”, “side-to-side leg swing”, “dynamic stretching”, “stable support”, “control”, “range of motion”, “ballistic stretching” e “breathing”.

## Fontes externas consultadas

| Fonte | Tipo | Contributo utilizado | Limite |
|---|---|---|---|
| NASM, [Dynamic Warm-ups for Athletes: Exercises for Sports Performance](https://blog.nasm.org/dynamic-warm-ups-for-athletes-injury-prevention-and-sports-performance-benefits) | Profissional | Para o balanço lateral, recomenda ficar de frente para uma superfície estável, segurar para estabilidade, mover a perna como pêndulo de forma controlada e manter o tronco alto. | Artigo profissional, não ensaio sobre esta execução nem validação de segurança individual. |
| Special Olympics, [DYNAMIC WARM UP Forward and Lateral Leg Swings](https://resources.specialolympics.org/sports-essentials/sports-and-coaching/warm-up-and-cool-down-videos/dynamic-warm-up-forward-and-lateral-leg-swings) | Oficial desportiva | Confirma que o balanço lateral da perna é reconhecido num guia de aquecimento dinâmico. | A página textual tem pouco detalhe técnico; não foi usada isoladamente para construir passos ou alegar benefícios. |
| University of Kansas Health System, [Dynamic Stretching Exercises](https://www.kansashealthsystem.com/news-room/blog/0001/01/dynamic-stretching-exercises) | Sistema de saúde | Recomenda começar com oscilações pequenas, aumentar apenas conforme tolerado, manter controlo, não forçar demasiado e preservar conforto. | Orientação geral, não específica de todos os detalhes mecânicos do balanço lateral. |
| Mayo Clinic, [Stretching and flexibility](https://www.mayoclinic.org/healthy-lifestyle/fitness/basics/stretching-and-flexibility/hlv-20049447) | Clínica profissional | Sustenta respirar livremente, evitar retenção e não forçar um alongamento doloroso. | A orientação de respiração incide em alongamento geral, não numa fase própria deste exercício dinâmico. |
| Iwata M. et al., [Dynamic Stretching Has Sustained Effects on Range of Motion and Passive Stiffness of the Hamstring Muscles](https://pmc.ncbi.nlm.nih.gov/articles/PMC6370952/), 2019 | Literatura primária | Confirma que alongamento dinâmico pode ser operacionalizado como movimento ativo repetido e estudado em medidas de amplitude e propriedades passivas. | Estudou isquiotibiais e um protocolo próprio; não valida o balanço lateral, a sua dose ou resultados individuais. |
| Zhou W.-S. et al., [Effects of Dynamic Stretching with Different Loads on Hip Joint Range of Motion in the Elderly](https://pmc.ncbi.nlm.nih.gov/articles/PMC6370971/), 2019 | Literatura primária | É relevante para a anca e distingue protocolos dinâmicos sem carga de protocolos com carga externa. Apoia não introduzir carga na execução-base. | População, planos de movimento, protocolo e outcomes não equivalem a este exercício. Não foi extrapolada dose. |
| Matsuo S. et al., [Acute Effects of Dynamic and Ballistic Stretching on Flexibility](https://pmc.ncbi.nlm.nih.gov/articles/PMC12131144/), 2025 | Literatura primária | Ajuda a preservar a fronteira entre alongamento dinâmico controlado e execução balística com ressalto. | Não demonstra que qualquer amplitude ou impulso seja seguro para qualquer pessoa; não é validação direta do balanço lateral. |

Consultadas em 24-07-2026.

## Fontes canónicas e científicas já presentes no pacote

Foram preservados os códigos `D1-CAN-01`, `D1-CAN-03`, `D1-EXT-04`, `D1-EXT-24`, `D2-S07`, `D2-S08` e `D2-S27`.

Em particular:

- Behm et al. (2016), registado em `D1-EXT-04` e `D2-S07`, é uma revisão sistemática de efeitos agudos do alongamento e sustenta cautela com extrapolações para desempenho ou prevenção;
- Opplert e Babault (2018), `D2-S08`, é uma revisão sobre alongamento dinâmico e apoia a classificação familiar, não uma promessa para esta execução;
- AAOS, `D2-S27`, reconhece balanços de perna como exemplos dinâmicos num contexto desportivo, sem permitir promessa de prevenção;
- Matsuo et al. (2025), `D1-EXT-24`, informa a distinção entre execução dinâmica e balística.

## Síntese das decisões documentais

### Execução dinâmica lateral

A instrução nuclear é deslocar a perna livre para fora e para dentro pela anca, como um pêndulo controlado. O cruzamento ligeiro à frente da perna de apoio foi descrito como opcional e dependente de espaço e controlo, evitando transformar amplitude individual em requisito.

A pelve continua orientada para a frente. Rodar a pelve ou balançar o tronco para aparentar uma trajetória maior foi classificado como erro, de acordo com a identidade canónica.

### Apoio e equilíbrio

O apoio manual permaneceu opcional. A redação não tornou equipamento obrigatório: pessoas capazes de manter apoio unipodal e travagem podem executar sem equipamento, enquanto principiantes podem usar um apoio estável autónomo.

O apoio é testado antes da oscilação e não pode ter rodas, oscilar, deslizar ou tombar. Uma pessoa não é usada como apoio improvisado, porque parceiro e assistência humana não pertencem à execução-base.

### Amplitude, impulso e travagem

A amplitude é definida funcionalmente: termina onde ainda é possível manter o pé de apoio firme, a pelve orientada, o tronco estável e a travagem deliberada. Esta formulação evita uma amplitude universal.

O impulso faz parte da aceleração da perna livre, mas não pode crescer a ponto de retirar controlo. A travagem ocorre antes de cada inversão. Ressalto, puxão, velocidade descontrolada e amplitude máxima não pertencem à execução documentada.

### Respiração

Não foi encontrada uma fase respiratória específica para este balanço. A orientação adotada é respirar de forma natural, regular e contínua, sem retenção e sem contagem. Isto cumpre a regra de não inventar coordenação respiratória quando não existe suporte específico.

### Segurança e saída

O risco moderado foi preservado. Os fatores operacionais dominantes são:

- perda de equilíbrio em apoio unipodal;
- impulso excessivo;
- colisão com o ambiente.

A saída normal reduz a oscilação, trava a perna, pousa o pé e recupera uma base com dois pés antes de libertar o apoio manual.

Os sinais de interrupção preservam o pacote canónico: dor aguda ou crescente, dormência, parestesia, fraqueza súbita, incapacidade de travar, perda de controlo, instabilidade ou mal-estar. Foi também explicitada a colisão iminente como aplicação direta do risco ambiental já aprovado.

### Erros

Foram documentados cinco erros observáveis:

1. rodar a pelve;
2. aumentar o impulso;
3. inclinar o tronco;
4. usar espaço insuficiente;
5. prender a respiração.

Cada erro inclui sinal de reconhecimento e correção sem prescrição de dose.

### Supervisão

A supervisão-base continua `none`. A recomendação de orientação é acionada apenas pelos gatilhos já aprovados: primeira exposição complexa, amplitude extrema, assistência humana, sintomas, historial ou estado que altere a elegibilidade. Não foi criada uma exigência universal de supervisão.

## Relações preservadas

| Contexto | Capacidade | Conceito | Intenção | Estado | Papel |
|---|---|---|---|---|---|
| `main_training` | `flexibility` | `dynamic_lengthening` | `increase_repeated_lengthening_tolerance` | `compatible` | `alternative_primary` |
| `prevention` | `flexibility` | `dynamic_lengthening` | `maintain_functional_dynamic_range` | `conditional` | `alternative_primary` |
| `warmup` | `flexibility` | `dynamic_lengthening` | `prepare_required_joint_ranges` | `compatible` | `principal_candidate` |

A relação de prevenção continua dependente do motor de elegibilidade e não constitui promessa de prevenção de lesão.

## Avaliação da evidência

**Confiança global: moderada.**

- **Identidade: alta.** O registo canónico é explícito e aprovado.
- **Execução para principiantes: moderada.** Existe convergência entre fontes profissionais independentes sobre apoio, controlo, tronco e amplitude, mas não uma validação direta de toda a sequência.
- **Respiração: moderada.** Existe suporte profissional para respiração livre e sem retenção, porém não específico deste exercício.
- **Segurança: moderada.** Os riscos e sinais vêm do pacote canónico; a literatura externa não determina elegibilidade individual.
- **Efeitos: limitados ao nível familiar.** Não há base para prometer melhoria, prevenção, tratamento ou resultado individual.

## Limitações

- Não foi identificada literatura primária que valide diretamente a descrição completa do balanço lateral da perna.
- Os estudos consultados usam protocolos, músculos, planos de movimento, populações e outcomes próprios.
- Nenhum resultado de investigação foi convertido em dose ou prescrição.
- Não se inferiu autorização universal para grávidas ou pessoas no pós-parto, pessoas idosas, pessoas com deficiência ou hipermobilidade, pessoas previamente sedentárias, pessoas após lesão ou cirurgia, ou pessoas com doença crónica relevante.
- O conteúdo não substitui avaliação profissional quando historial, sintomas ou equilíbrio alterem a elegibilidade.
- Não foram alterados identidade, risco, equipamento, superfície, supervisão-base ou relações.

## Verificações do contrato

- Português europeu e UTF-8 NFC: verificado.
- JSON com chaves obrigatórias pela ordem pedida: preparado.
- Passos de execução: 8.
- Pistas principais: 6.
- Erros comuns estruturados: 5.
- Perguntas de compreensão: 12.
- Dose fixa, séries, duração, distância, carga, intensidade, cadência, frequência e progressão programada: ausentes.
- Promessa, diagnóstico, tratamento e autorização universal: ausentes.
- Revisão por pelo menos duas fontes independentes: cumprida.
- Literatura primária: Iwata et al. (2019), Zhou et al. (2019) e Matsuo et al. (2025).
- Relações novas: nenhuma.
- Aprovação de média: não realizada.
- Código ou publicação: não realizados.

**Implementação realizada: não**
