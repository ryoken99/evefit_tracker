# Marcha tandem

Conteúdo para principiantes em português europeu.

## Descrição curta

Caminhar em frente numa linha, colocando o calcanhar de cada passo diretamente junto à ponta do outro pé.

## O que é

A marcha tandem é uma deslocação em linha reta com apoios estreitos e alternados: um pé avança e o respetivo calcanhar fica diretamente junto à ponta do pé que está atrás. Não é uma postura parada, uma marcha para trás nem uma caminhada sobre uma superfície elevada.

## O que vais fazer

Vais partir de pé, avançar em linha com contactos sucessivos calcanhar–ponta e transferir o peso para o pé da frente antes de moveres o outro. Vais terminar novamente de pé e com controlo.

## Porque existe este movimento

A tarefa existe para praticar transições de apoio e coordenação durante deslocação numa base funcionalmente estreita. Esta explicação não promete resultados nem substitui uma decisão individual sobre elegibilidade.

## Antes de começares

1. Escolhe um percurso linear livre, bem iluminado, com piso firme, nivelado e antiderrapante.
2. Retira do percurso objetos, tapetes soltos, líquidos e outros elementos que possam provocar um tropeção ou escorregamento.
3. Se pretenderes apoio, escolhe uma superfície estável e fixa ao longo de um dos lados, ao alcance da mão; não uses mobiliário que possa deslizar ou tombar.
4. Confirma que consegues compreender a tarefa, iniciar e interromper voluntariamente e voltar a um apoio confortável com os dois pés.
5. Organiza supervisão quando o risco de queda for elevado, quando não conseguires sair da tarefa de forma autónoma ou quando estiveres num contexto clinicamente restringido.

## Preparar o equipamento

1. Não é necessário equipamento. Podes usar uma linha visual no chão apenas como referência e um apoio estável opcional ao lado. Verifica primeiro que o apoio não desliza, roda nem tomba e que não obriga a alcançar longe do corpo.

## Preparar o espaço

1. Usa apenas um percurso linear desimpedido, num piso firme, nivelado e antiderrapante, com luz suficiente para ver a linha e o fim do trajeto. Não executes num veículo em movimento, junto de uma altura desprotegida nem sobre uma superfície escorregadia, instável ou atravancada.

## Verificação do corpo

1. Em pé, confirma que te sentes capaz de permanecer estável com ambos os pés assentes.
2. Confirma que consegues alcançar o apoio opcional sem inclinar o tronco ou esticar excessivamente o braço.
3. Não inicies se já estiveres com dor aguda, mal-estar, tontura ou perda de controlo.
4. Se tiveres quedas recentes, estiveres a regressar à função ou existir uma condição neurológica ou vestibular relevante, esta tarefa requer revisão e adaptação individual antes de ser usada sem orientação.

## Posição inicial

Fica de pé no início do percurso, virado para a frente, com postura confortável e ambos os pés assentes. Se usares o apoio opcional, coloca-te de lado para ele, suficientemente perto para o alcançar sem te inclinares. Orienta o olhar para a frente e confirma que o percurso está livre.

## Confirmar a posição inicial

1. Corpo virado no sentido do percurso.
2. Ambos os pés assentes e posição inicial estável.
3. Olhar dirigido para a frente.
4. Percurso livre e fim do trajeto visível.
5. Apoio opcional fixo, estável e ao alcance.
6. Possibilidade de parar e recuperar apoio com os dois pés.

## Passos de execução

1. A partir da posição estável, escolhe o pé que vai avançar primeiro e mantém o tronco direito, sem prender a respiração.
2. Eleva esse pé apenas o necessário para o deslocar em frente ao outro, mantendo o olhar orientado para a frente.
3. Pousa o calcanhar do pé que avançou diretamente junto à ponta do pé que ficou atrás, de modo que os dois pés formem a mesma linha.
4. Aceita o apoio no pé da frente e transfere o peso com controlo antes de retirar o pé de trás.
5. Avança o pé que estava atrás e coloca o respetivo calcanhar diretamente junto à ponta do outro pé.
6. Continua a alternar os pés com uma ação estável e controlada, usando o apoio opcional sempre que necessário para manter o controlo.
7. No fim do percurso, pára antes de mudares de direção, coloca os pés numa posição confortável com apoio bipodal e estabiliza-te.

## Fases do movimento

### Preparação do passo

Estabiliza o apoio atual, mantém o olhar em frente e escolhe o pé que avança.

### Colocação calcanhar–ponta

Desloca o pé em frente e alinha o calcanhar diretamente junto à ponta do pé oposto.

### Transferência de peso

Passa o apoio para o pé da frente com controlo antes de libertar o pé de trás.

### Alternância

Repita a mesma organização com o outro pé, preservando a progressão linear.

### Saída

Interrompe a sequência, recupera apoio confortável com os dois pés e só depois reposiciona-te.

## Respiração

Respira de forma natural, regular e contínua durante toda a marcha. Não existe uma fase respiratória obrigatória para cada passo; não prendas a respiração nem imponha contagens.

## Sensações esperadas

1. Necessidade de atenção à colocação dos pés e à transferência do peso.
2. Desafio de equilíbrio lateral devido à base de apoio estreita.
3. Trabalho ligeiro dos músculos estabilizadores dos tornozelos, ancas e tronco.
4. Alternância clara do apoio entre um pé e o outro, sem dor aguda nem perda de controlo.

## Sensações inesperadas ou de alerta

1. Dor aguda.
2. Mal-estar.
3. Tontura.
4. Perda de controlo.
5. Necessidade repetida de recorrer a apoio que não estava planeado.

## Indicações técnicas principais

1. Percurso livre; apoio estável ao alcance se precisar.
2. Calcanhar diretamente junto à ponta do outro pé.
3. Transfere o peso antes de avançar o pé seguinte.
4. Olha em frente e mantém o tronco direito.
5. Respira naturalmente, sem prender a respiração.
6. Pára com os dois pés estáveis antes de te reposicionares.

## Erros comuns e correções

### Erro 1: Pousar o pé ao lado, deixando um intervalo lateral em vez de formar uma linha.

- Como reconhecer: O calcanhar novo não fica diretamente à frente da ponta do outro pé e os pés passam a ocupar duas linhas paralelas.
- Como corrigir: Estabiliza o apoio atual e direciona o calcanhar para ficar diretamente junto à ponta do pé oposto.

### Erro 2: Cruzar um pé para além da linha do outro.

- Como reconhecer: O pé que avança atravessa para o lado oposto e as pernas ficam cruzadas lateralmente.
- Como corrigir: Mantém ambos os pés orientados ao longo da mesma linha de progressão, sem atravessar um pé para o lado oposto.

### Erro 3: Avançar o pé seguinte antes de controlar a transferência de peso.

- Como reconhecer: Os passos tornam-se apressados, surge um passo lateral de recuperação ou é necessário agarrar subitamente o apoio.
- Como corrigir: Conclui cada colocação e aceita o peso no pé da frente antes de levantar o pé de trás.

### Erro 4: Olhar continuamente para os pés e inclinar o tronco.

- Como reconhecer: A cabeça e o peito ficam dirigidos para o chão e perde-se a orientação do percurso.
- Como corrigir: Confirma a linha antes de começares e, durante a marcha, mantém o olhar orientado para a frente e o tronco direito.

### Erro 5: Tentar virar ou sair da linha enquanto os pés ainda estão em tandem.

- Como reconhecer: A mudança de direção começa a partir da base estreita e provoca rotação apressada ou desequilíbrio.
- Como corrigir: Pára primeiro, recupera uma posição confortável com os dois pés e só depois reposiciona-te.

## Formas de simplificar ou ensaiar

1. Executa junto de um apoio estável e usa um contacto leve ou mais firme conforme necessário para preservar o controlo.
2. Faz uma pausa controlada depois de cada colocação calcanhar–ponta antes de avançares o outro pé.
3. Usa uma linha visual no piso para tornar o alinhamento mais fácil de perceber.
4. Usa apenas a parte do percurso livre que consegues completar e abandonar com controlo; isto não define uma distância prescrita.
5. Mantém o exercício em frente. Marcha para trás, olhos fechados, aumento de velocidade e superfícies instáveis não pertencem a esta execução de principiante.

## Supervisão

A supervisão é recomendada. Deve estar próxima o suficiente para ajudar a tornar o ambiente seguro sem puxar a pessoa nem alterar a colocação dos pés. Organiza supervisão presencial quando houver risco elevado de queda, incapacidade de sair da tarefa de modo autónomo ou contexto clinicamente restringido. Quedas recentes e condições neurológicas ou vestibulares requerem revisão e adaptação individual. Um observador não substitui um apoio instável por um apoio seguro.

## Como terminar

Pára antes do fim do percurso livre, assenta ambos os pés numa posição confortável e estabiliza-te. Se estiveres junto de um apoio, mantém-no ao alcance. Só depois de recuperares controlo deves mudar de direção ou afastar-te.

## Nota de segurança

Esta tarefa tem risco operacional moderado porque combina deslocação com uma base de apoio estreita. Interrompe perante passos laterais descontrolados ou qualquer sinal de perda de controlo. O apoio é opcional, mas, quando usado, tem de ser estável; a supervisão é recomendada e pode tornar-se necessária de acordo com a elegibilidade da pessoa.

## Quando parar ou reduzir

1. Dor aguda.
2. Mal-estar.
3. Necessidade repetida de apoio não planeado.
4. Perda de controlo.
5. Tontura.

## Segurança do equipamento

Não há equipamento obrigatório. Uma linha visual não deve criar relevo nem risco de tropeção. O apoio opcional tem de estar fixo e estável; não uses cadeiras leves, mesas com rodas, portas móveis ou objetos que possam deslizar, rodar ou tombar.

## Segurança do espaço

O percurso deve ser linear, livre, bem iluminado e ter piso firme, nivelado e antiderrapante. Evita superfícies atravancadas, escorregadias ou instáveis, veículos em movimento e alturas desprotegidas. Confirma que o fim do percurso permite parar com apoio bipodal antes de qualquer reposicionamento.

## Limitações

1. A maioria das instruções profissionais consultadas foi produzida para adultos mais velhos ou contextos de equilíbrio; não autoriza transferência automática para todas as populações.
2. O estudo primário direto incluiu uma amostra pequena de pessoas com perda vestibular unilateral e avaliou também biofeedback vibrotátil; os seus resultados não sustentam promessas para principiantes em geral.
3. Não foi encontrada uma relação respiratória específica entre inspiração, expiração e fase do passo; por isso, a orientação limita-se a respiração natural e contínua sem retenção.
4. Não se define dose, distância, duração, velocidade, progressão programada, diagnóstico, tratamento ou autorização universal.
5. Implementação realizada: não

## Teste de compreensão

### 1. Que tipo de piso deves escolher?

Resposta esperada: Um piso firme, nivelado e antiderrapante, num percurso livre.

### 2. O apoio lateral é obrigatório?

Resposta esperada: Não. É opcional, mas, se for usado, tem de ser estável, fixo e estar ao alcance.

### 3. Onde deves pousar o calcanhar do pé que avança?

Resposta esperada: Diretamente junto à ponta do pé oposto, na mesma linha.

### 4. O que deve acontecer antes de avançar o pé seguinte?

Resposta esperada: A transferência de peso para o pé da frente deve ficar controlada.

### 5. Para onde deves orientar o olhar durante a marcha?

Resposta esperada: Para a frente, mantendo o tronco direito.

### 6. Como deves respirar?

Resposta esperada: De forma natural, regular e contínua, sem prender a respiração nem usar contagens.

### 7. O que deves fazer se surgir um passo lateral descontrolado?

Resposta esperada: Interromper a progressão e recuperar uma posição estável com os dois pés.

### 8. Podes usar uma cadeira leve como apoio?

Resposta esperada: Não. Um apoio que possa deslizar ou tombar não é seguro.

### 9. Como deves terminar antes de mudares de direção?

Resposta esperada: Parar, assentar ambos os pés numa posição confortável e estabilizar-se.

### 10. Quando é especialmente importante organizar supervisão?

Resposta esperada: Quando há risco elevado de queda, incapacidade de sair da tarefa autonomamente ou contexto clinicamente restringido.

### 11. Que sinais indicam que deves parar ou reduzir?

Resposta esperada: Dor aguda, mal-estar, tontura, perda de controlo ou necessidade repetida de apoio não planeado.

### 12. A marcha para trás faz parte desta execução?

Resposta esperada: Não. A identidade documentada progride em frente; a marcha para trás é outra variante.

## Fontes e limites da evidência

### Fonte 1: OTAGO Strength and Balance — Home Exercise Programme

- Autor ou entidade: Oxford University Hospitals NHS Foundation Trust
- Tipo: manual profissional oficial
- Localizador: https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf
- Usada para: E1-SRC-003 — OTAGO Strength and Balance — Home Exercise Programme — Oxford University Hospitals NHS Foundation Trust — manual profissional oficial — https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf — 2026-07-24 — Fundamentou postura direita, colocação dos pés numa linha, olhar em frente, ação estável, apoio seguro, posição bipodal antes de virar e respiração normal.
- Limite: E1-SRC-003 — OTAGO Strength and Balance — Home Exercise Programme — Oxford University Hospitals NHS Foundation Trust — manual profissional oficial — https://www.ouh.nhs.uk/media/5xydterh/85619otago.pdf — 2026-07-24 — Fundamentou postura direita, colocação dos pés numa linha, olhar em frente, ação estável, apoio seguro, posição bipodal antes de virar e respiração normal.

### Fonte 2: Balance exercises — Heel-to-toe walk

- Autor ou entidade: NHS
- Tipo: orientação pública oficial
- Localizador: https://www.nhs.uk/live-well/exercise/balance-exercises/
- Usada para: E1-SRC-004-WEB — Balance exercises — Heel-to-toe walk — NHS — orientação pública oficial — https://www.nhs.uk/live-well/exercise/balance-exercises/ — 2026-07-24 — Confirmou execução calcanhar–ponta, postura de pé, olhar em frente e uso opcional dos dedos na parede para estabilidade.
- Limite: E1-SRC-004-WEB — Balance exercises — Heel-to-toe walk — NHS — orientação pública oficial — https://www.nhs.uk/live-well/exercise/balance-exercises/ — 2026-07-24 — Confirmou execução calcanhar–ponta, postura de pé, olhar em frente e uso opcional dos dedos na parede para estabilidade.

### Fonte 3: Balance exercises for older patients

- Autor ou entidade: Royal Berkshire NHS Foundation Trust
- Tipo: material clínico profissional oficial
- Localizador: https://www.royalberkshire.nhs.uk/media/dijm12l5/balance-exercises-for-older-patients_pd-3_jan26.pdf
- Usada para: RBFT-2026-BALANCE — Balance exercises for older patients — Royal Berkshire NHS Foundation Trust — material clínico profissional oficial — https://www.royalberkshire.nhs.uk/media/dijm12l5/balance-exercises-for-older-patients_pd-3_jan26.pdf — 2026-07-24 — Fundamentou percurso bem iluminado e sem obstáculos, vigilância quando apropriada, proximidade de suporte e interrupção se surgir queda iminente ou desequilíbrio marcado.
- Limite: RBFT-2026-BALANCE — Balance exercises for older patients — Royal Berkshire NHS Foundation Trust — material clínico profissional oficial — https://www.royalberkshire.nhs.uk/media/dijm12l5/balance-exercises-for-older-patients_pd-3_jan26.pdf — 2026-07-24 — Fundamentou percurso bem iluminado e sem obstáculos, vigilância quando apropriada, proximidade de suporte e interrupção se surgir queda iminente ou desequilíbrio marcado.

### Fonte 4: Effects of practicing tandem gait with and without vibrotactile biofeedback in subjects with unilateral vestibular loss

- Autor ou entidade: Journal of Vestibular Research
- Tipo: estudo primário, desenho cruzado
- Localizador: https://doi.org/10.3233/VES-2007-17405
- Usada para: DOZZA-2007 — Effects of practicing tandem gait with and without vibrotactile biofeedback in subjects with unilateral vestibular loss — Journal of Vestibular Research — estudo primário, desenho cruzado — https://doi.org/10.3233/VES-2007-17405 — 2026-07-24 — Sustentou a relevância do desvio do tronco, deslocamento lateral, largura mediolateral dos pés e erros de passo como aspetos observáveis da tarefa; não foi usado para prometer benefício.
- Limite: DOZZA-2007 — Effects of practicing tandem gait with and without vibrotactile biofeedback in subjects with unilateral vestibular loss — Journal of Vestibular Research — estudo primário, desenho cruzado — https://doi.org/10.3233/VES-2007-17405 — 2026-07-24 — Sustentou a relevância do desvio do tronco, deslocamento lateral, largura mediolateral dos pés e erros de passo como aspetos observáveis da tarefa; não foi usado para prometer benefício.

### Fonte 5: Getting Active to Control High Blood Pressure

- Autor ou entidade: American Heart Association
- Tipo: orientação profissional oficial
- Localizador: https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure
- Usada para: AHA-2025-BREATH — Getting Active to Control High Blood Pressure — American Heart Association — orientação profissional oficial — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — 2026-07-24 — Corroborou respiração regular durante o exercício e a indicação de não prender a respiração.
- Limite: AHA-2025-BREATH — Getting Active to Control High Blood Pressure — American Heart Association — orientação profissional oficial — https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure — 2026-07-24 — Corroborou respiração regular durante o exercício e a indicação de não prender a respiração.
