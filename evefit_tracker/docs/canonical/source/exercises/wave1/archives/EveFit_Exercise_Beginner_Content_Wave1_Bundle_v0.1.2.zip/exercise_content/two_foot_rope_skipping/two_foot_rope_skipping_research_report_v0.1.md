# Relatório de investigação — Salto à corda a dois pés

**Agente:** EX-09  
**Exercício:** `two_foot_rope_skipping`  
**Data de consulta:** 2026-07-23  
**Implementação realizada: não**

## Âmbito e decisão

Foi produzido conteúdo documental para principiantes sobre execução, preparação, respiração, sensações, segurança, impacto, erros e supervisão. Não foi criado código, não houve publicação, não foi prescrita dose e não foram alteradas identidade, risco, equipamento, relações ou estado de multimédia.

A identidade foi preservada como exercício canónico: saltos bilaterais repetidos sobre uma corda que roda ciclicamente por baixo dos pés, com fase aérea por passagem. Permanecem excluídas as variantes alternadas e as rotações múltiplas.

O risco operacional permanece **moderado**. A corda de saltar continua a ser o único equipamento obrigatório, sem alternativa sem equipamento. Não existe requisito geral de observador nem de supervisão, mantendo-se os gatilhos canónicos de instabilidade marcada e equipamento ou ambiente desconhecido.

## Método de pesquisa

Foram usados os três registos de evidência já associados ao exercício e acrescentadas fontes externas independentes de natureza federativa e profissional. Para técnica específica, foi privilegiado um manual oficial de uma federação desportiva. Para impacto, foram usados estudos biomecânicos primários. Para respiração, interrupção, monitorização, equipamento, piso e supervisão, foram usadas orientações de organizações profissionais.

Não foram transpostas para o conteúdo quaisquer doses, sessões, intervalos, cadências ou progressões presentes nas fontes. Recomendações de resultado e generalizações clínicas também foram excluídas.

## Fontes consultadas e leitura crítica

### A1-S24 — Lin et al., 2022

**Fonte:** [The Influence of Different Rope Jumping Methods on Adolescents’ Lower Limb Biomechanics during the Ground-Contact Phase](https://pmc.ncbi.nlm.nih.gov/articles/PMC9139829/)  
**Tipo:** estudo biomecânico primário, revisto por pares.

Contribuições:

- define o salto bilateral com impulsão e receção simultâneas como técnica distinta do salto alternado;
- descreve fases de voo, receção e impulsão;
- confirma que existe força de reação do solo e necessidade de estratégia de amortecimento;
- sustenta a atenção a flexão coordenada dos membros inferiores e ao impacto repetido;
- mostra que diferentes técnicas de corda não são mecanicamente intercambiáveis.

Limites:

- amostra de rapazes adolescentes, pequena e com experiência prévia;
- resultados laboratoriais não estabelecem uma técnica ideal para todas as pessoas;
- a associação entre variáveis biomecânicas e lesão não autoriza previsão individual.

### A1-S25 — Mullerpatan et al., 2021

**Fonte:** [Lower extremity joint loading during Bounce rope skip in comparison to run and walk](https://pmc.ncbi.nlm.nih.gov/articles/PMC9760008/)  
**Tipo:** estudo biomecânico primário, revisto por pares.

Contribuições:

- confirma carga articular e fase de receção no salto bilateral à corda;
- no protocolo estudado, a força vertical de reação do solo na receção foi inferior à corrida e superior à marcha;
- sustenta a classificação de impacto presente e a necessidade de receção controlada.

Limites:

- comparação laboratorial de tarefas específicas;
- não demonstra que a atividade seja segura para qualquer pessoa;
- não define superfície, supervisão ou dose individual.

### A2-S33 — exigência cardiorrespiratória

**Fonte:** [Rope skipping cardiorespiratory demand — PMID 7421480](https://pubmed.ncbi.nlm.nih.gov/7421480/)  
**Tipo:** artigo científico indexado.

Contribuição:

- sustenta que a atividade tem exigência cardiorrespiratória, justificando a descrição de aumento da respiração e pulsação como sensação esperável.

Limites:

- estudo antigo;
- não usa a taxonomia atual de variantes;
- não sustenta dose, promessa de resultado ou elegibilidade automática.

### EX09-S1 — England Boxing

**Fonte:** [Boxing Coaching Handbook Part 1](https://www.englandboxing.org/wp-content/uploads/2022/03/EB_Boxing-Coaching-Handbook-Part-1_v8-002.pdf), secção “Skipping”.  
**Tipo:** manual técnico oficial de federação desportiva.

Contribuições:

- propõe verificar o comprimento com os pés no centro da corda e as pegas perto da zona inferior das axilas;
- recomenda pegas seguras e ajuste pela própria pega, sem nós;
- descreve cotovelos junto ao corpo, mãos junto da cintura, rotação circular com participação dos punhos e postura alta;
- orienta para salto baixo e joelhos ligeiramente fletidos;
- recomenda demonstração para principiantes.

Limites:

- foi elaborado para treino de boxe;
- inclui exemplos de dose que ficaram fora deste conteúdo;
- algumas indicações de progressão do manual não pertencem à identidade canónica e não foram usadas.

### EX09-S2 — American College of Sports Medicine

**Fonte:** [ACSM Certified Personal Trainer Exam Content Outline](https://acsm.org/wp-content/uploads/2024/12/ACSM-Certified-Personal-Trainer-Exam-Content-Outline.pdf).  
**Tipo:** documento profissional oficial.

Contribuições:

- sustenta monitorização da técnica e da resposta ao exercício;
- inclui falta de ar, dor articular e tonturas entre exemplos de respostas que podem justificar terminação;
- identifica adaptação segundo capacidade e historial, orientação no uso de equipamento e segurança do piso;
- sustenta feedback e supervisão quando necessários para reduzir risco.

Limites:

- documento de competências profissionais gerais;
- não fornece técnica específica de salto à corda;
- não substitui avaliação clínica individual.

### EX09-S3 — American Heart Association

**Fonte:** [Getting Active to Control High Blood Pressure](https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure).  
**Tipo:** orientação profissional oficial.

Contribuições:

- recomenda respiração regular durante aquecimento, exercício e retorno à calma;
- alerta contra prender a respiração;
- permite sustentar orientação simples de respiração contínua, sem contagens ou retenções.

Limites:

- orientação geral com enquadramento cardiovascular;
- não define sincronização respiratória específica para o salto à corda.

## Matriz de cobertura

| Tema | Evidência principal | Aplicação no conteúdo | Limite preservado |
|---|---|---|---|
| Execução | England Boxing; Lin et al. | Posição, punhos, salto baixo, apoio bilateral, fases | Sem transformar conselho técnico em prescrição |
| Preparação | England Boxing; ACSM | Comprimento, pegas, corda íntegra, prontidão, demonstração | Sem adicionar equipamento |
| Respiração | American Heart Association; ACSM | Respiração natural, regular e contínua; sem retenção | Sem contagens respiratórias |
| Segurança | ACSM; registo canónico | Interrupção, monitorização, piso, controlo | Sem autorização universal |
| Impacto | Lin et al.; Mullerpatan et al. | Impacto presente, receção controlada, fadiga como modificador | Sem promessa de prevenção de lesão |
| Erros | England Boxing; inferência biomecânica limitada | Ombros dominantes, salto alto, receção rígida, alternância, tropeço, olhar para baixo | Erros observáveis, não diagnósticos |
| Supervisão | ACSM; registo canónico | Não obrigatória em geral; prudente nos gatilhos previstos | Não foi criado requisito novo |

## Decisões de redação

### Execução

Foram definidos sete passos observáveis, desde a corda atrás dos calcanhares até à continuidade condicionada ao controlo. Cada passo inclui uma auto-verificação. A formulação “salta apenas o necessário” evita impor altura numérica e é coerente com a identidade.

### Preparação

A preparação cobre exclusivamente a corda obrigatória e os requisitos ambientais já aprovados. O teste prático de comprimento foi incluído por convergência entre o manual federativo e orientação profissional, mas não é apresentado como medida universal exata.

### Respiração

Não foi encontrada uma sincronização respiratória específica e robusta para esta técnica. Aplicou-se, por isso, a regra contratual de respiração natural e contínua, sem retenção nem contagens.

### Impacto e receção

O conteúdo não chama ao exercício “baixo impacto”. Os dados diretos mostram carga de receção e contacto repetido; embora um protocolo tenha registado força inferior à corrida, registou também força superior à marcha. Assim, mantém-se o risco moderado e a linguagem centra-se no controlo, não na eliminação do risco.

### Erros

Foram documentados seis erros completos, cada um com erro, forma de reconhecimento e correção. As correções mantêm a identidade bilateral e não introduzem variantes.

### Supervisão

Foi preservado `supervision_requirement: none`. A orientação apenas torna prudente a ajuda profissional nos gatilhos canónicos ou quando a pessoa não consegue compreender e controlar a técnica. Isto não altera o requisito base.

## Integridade canónica

- `exercise_id`: preservado como `two_foot_rope_skipping`;
- entidade: preservada como `canonical_exercise`;
- família: preservada como `rope_skipping_family`;
- exercício-base e variante: ambos preservados como `none`;
- capacidade principal: preservada como `cardio_conditioning`;
- risco operacional: preservado como moderado;
- equipamento: preservado como `skipping_rope`, sem alternativa;
- ambiente: preservado como zona firme, regular, tolerante ao impacto e desimpedida, com espaço superior e lateral;
- supervisão: preservada como não obrigatória, com gatilhos contextuais;
- relações: preservadas sem criação, remoção ou reclassificação;
- multimédia: não aprovada;
- campos de dose: ausentes.

## Relações preservadas

1. Treino principal, condicionamento cardiorrespiratório, movimento rítmico repetitivo, melhorar coordenação sob esforço sustentado — **condicional**, papel complementar.
2. Treino principal, condicionamento cardiorrespiratório, movimento rítmico repetitivo, aumentar resistência de movimento repetitivo — **compatível**, alternativa principal.
3. Treino principal, controlo motor e coordenação, sincronização rítmica, melhorar coordenação intermembros — **condicional**, alternativa principal.
4. Aquecimento, condicionamento cardiorrespiratório, movimento rítmico repetitivo, preparar contacto repetido — **condicional**, complementar.
5. Aquecimento, controlo motor e coordenação, sincronização rítmica, preparar sincronização intermembros — **condicional**, complementar.

Os limites de elegibilidade, impacto, fadiga, superfície, tropeço e lógica de produto foram mantidos. Nenhuma relação condicional foi convertida em compatível.

## Limitações globais

- A evidência direta não cobre todas as populações.
- Os estudos biomecânicos não permitem estimar risco individual de lesão.
- A orientação de execução resulta de triangulação entre manual federativo, fontes profissionais e evidência mecânica.
- Não foi feita avaliação individual, diagnóstico, tratamento ou autorização clínica.
- Não foram definidos dose, intensidade, ritmo, velocidade, cadência, duração, descanso ou progressão.
- Não houve aprovação de imagem ou vídeo.

## Verificação contratual

- idioma: português europeu;
- codificação: UTF-8, normalização NFC;
- passos de execução: sete;
- pistas principais: seis;
- erros completos: seis;
- perguntas de compreensão: doze;
- fontes independentes: England Boxing, ACSM, American Heart Association e estudos científicos de grupos distintos;
- zero dose ou prescrição;
- zero promessa, diagnóstico ou tratamento;
- implementação ou publicação: não.

## Conclusão

A cobertura é defensável para conteúdo introdutório de execução: combina fonte federativa específica, duas fontes profissionais independentes e três fontes científicas já associadas ao exercício. As conclusões foram limitadas ao que estas fontes permitem sustentar, com identidade bilateral, risco moderado, equipamento obrigatório, relações e fronteira de prescrição preservados.
