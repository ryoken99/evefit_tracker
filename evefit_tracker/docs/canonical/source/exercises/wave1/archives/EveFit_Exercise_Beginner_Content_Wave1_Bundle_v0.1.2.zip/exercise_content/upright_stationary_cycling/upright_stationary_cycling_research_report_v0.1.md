# Relatório de investigação — `upright_stationary_cycling`

**Agente:** EX-06  
**Data de fecho:** 2026-07-23  
**Âmbito:** execução, preparação, respiração, segurança, erros e supervisão  
**Conclusão:** cobertura defensável; investigação encerrada  
**Estado proposto do conteúdo:** `beginner_content_approved_with_limits`

Implementação realizada: não

## 1. Resultado

Foi produzido conteúdo para principiante absoluto sobre a pedalada em bicicleta estacionária vertical. A redação mantém a identidade canónica, o risco operacional baixo, o equipamento obrigatório e as relações aprovadas. Não foram introduzidas dose, prescrição, promessa de resultado, diagnóstico, tratamento, autorização universal, aprovação de multimédia, código ou publicação.

O estado “aprovado com limites” deve-se à variação dos mecanismos de ajuste, travagem e paragem entre modelos. O texto dá princípios gerais e remete os comandos concretos para o manual da bicicleta utilizada.

## 2. Limites da pesquisa

A pesquisa foi deliberadamente limitada a:

- ajuste do selim, guiador, pedais e correias;
- posição inicial e ciclo de pedalada;
- controlo do tronco, bacia, joelhos e pés;
- respiração natural e contínua;
- montagem, desaceleração, paragem e desmontagem;
- sinais de interrupção;
- erros observáveis e respetivas correções;
- necessidade de demonstração ou supervisão perante instabilidade ou equipamento desconhecido.

Não foram pesquisados nem documentados programas, intensidade, cadência, carga, duração, distância, frequência, progressões ou resultados individuais.

## 3. Preservação canónica

### Identidade

- `exercise_id`: `upright_stationary_cycling`
- nome: Pedalada em bicicleta estacionária vertical
- tipo: `canonical_exercise`
- capacidade principal: `cardio_conditioning`
- família: `cycling_family`
- `base_exercise_id`: `none`
- `variant_of`: `none`
- definição preservada: pedalada cíclica alternada numa bicicleta estacionária, com tronco em configuração vertical e sem deslocamento global.

Não foi criada distinção nova, variante ou identidade adicional.

### Equipamento e ambiente

- Equipamento obrigatório preservado: `upright_stationary_cycle`.
- Não foi criada alternativa sem equipamento.
- Não foram acrescentados requisitos pessoais obrigatórios.
- Ambiente interior, base nivelada, zona segura para montar e desmontar e exclusão de máquina instável ou danificada foram preservados.

### Risco e supervisão

- Risco operacional preservado: `low`.
- Fatores principais preservados: escorregamento do pé e ajuste incorreto.
- Modificadores preservados: fadiga, visibilidade reduzida e bicicleta instável ou danificada.
- Parceiro e observador não são exigidos.
- Supervisão de rotina não é exigida.
- Os gatilhos de supervisão preservados são instabilidade marcada e equipamento ou ambiente desconhecido.
- Os sinais de interrupção preservados são desconforto no peito ou falta de ar atípica, tonturas ou confusão e perda de controlo ou dor nova.

### Relações

Não foi acrescentada, removida ou reclassificada qualquer relação. Permanecem:

| Contexto | Conceito | Intenção | Compatibilidade | Papel |
|---|---|---|---|---|
| `main_training` | `cyclic_propulsion` | `develop_aerobic_endurance` | `compatible` | `alternative_primary` |
| `main_training` | `cyclic_propulsion` | `improve_propulsive_efficiency` | `compatible` | `alternative_primary` |
| `recovery` | `cyclic_propulsion` | `maintain_light_cardiorespiratory_activity` | `conditional` | `complementary` |
| `warmup` | `cyclic_propulsion` | `rehearse_propulsive_cycle` | `conditional` | `principal_candidate` |

O conteúdo público descreve apenas a ação técnica. Não operacionaliza estas relações através de dose.

## 4. Fontes avaliadas

### Fontes existentes

| Código | Fonte | Uso e limite |
|---|---|---|
| `A1-S19` | [Bouillon et al., estudo biomecânico](https://pubmed.ncbi.nlm.nih.gov/27104052/) | Sustenta a distinção preliminar entre bicicleta vertical e modalidades próximas. Não foi usado para prescrição. |
| `A2-S04` | [ACSM, *Investing in a Personal Trainer*](https://acsm.org/wp-content/uploads/2025/02/Investing-in-a-personal-trainer-handout.pdf) | Enquadra ciclismo entre atividades aeróbias. Não fornece a técnica específica necessária. |
| `A2-S11` | [Concept2 Training](https://www.concept2.com/training) | Documentação de fabricante sobre ergómetros. Usada apenas como contexto mecânico; não foram extrapolados comandos. |

### Fontes adicionais

| Código | Fonte e tipo | Elementos sustentados |
|---|---|---|
| `EX06-S01` | [Hospital for Special Surgery, *How to Set Up an Exercise (or Spin) Bike Properly*](https://www.hss.edu/health-library/move-better/set-up-exercise-bike), orientação profissional | Ajuste individual; ligeira flexão do joelho; verificação da distância do selim; alcance confortável; coluna neutra; cotovelos ligeiramente fletidos; ombros relaxados; reconhecimento de selim alto ou baixo. |
| `EX06-S02` | [Life Fitness, manual das bicicletas verticais 95C/97C](https://kb.cybexintl.com/Owners_Manuals/Bike/OM_LC_95C-ALLxx-xx_97C-ALLxx-xx_M051-00K67-A131_English.pdf), manual oficial | Bloqueio do selim; não ajustar durante a pedalada; correias confortáveis e suficientemente seguras; inspeção de danos e desgaste; retirada de serviço de equipamento defeituoso. |
| `EX06-S03` | [Cybex, manual da R Series Upright Bike](https://kb.cybexintl.com/Assembly_Manuals/Bike/Cybex_R_Series/Upright/Cybex_R_Series_Upright_1008126-0001_English.pdf), manual oficial | Ligeira flexão do joelho na maior extensão; ausência de bloqueio, oscilação no selim ou extensão forçada da anca; correias; ajuste apenas com a pedalada parada; inspeção de niveladores, pedais e correias. |
| `EX06-S04` | [Schwinn/Nautilus, manual da IC3](https://download.bowflex.com/supportdocs/AM_OM/Schwinn/SCH.IC3.QSM.EN.pdf), manual oficial | Base sólida e nivelada; cautela ao montar e desmontar; dispositivos de ajuste engatados; redução controlada da rotação; pedais totalmente parados antes de desmontar. A conclusão sobre volante fixo é apresentada apenas como condição de alguns modelos. |
| `EX06-S05` | [ACSM, *Certified Personal Trainer Crosswalk*](https://acsm.org/wp-content/uploads/2025/01/acsm-cpt-crosswalk.pdf), documento profissional oficial | Necessidade de reconhecer técnica correta e incorreta em bicicletas estacionárias e critérios de interrupção como falta de ar, dor articular e tonturas. |
| `EX06-S06` | [American Heart Association, *Warning Signs of a Heart Attack*](https://www.heart.org/en/health-topics/heart-attack/warning-signs-of-a-heart-attack), orientação profissional oficial | Apoia a decisão conservadora de não ignorar desconforto no peito ou falta de ar. Não foi usada para diagnosticar nem atribuir causa. |

## 5. Síntese da evidência

### Ajuste do selim

O HSS e o manual oficial da Cybex convergem numa verificação simples: na maior extensão da perna, o joelho não deve bloquear e deve conservar ligeira flexão. O manual da Cybex acrescenta sinais observáveis de mau ajuste — oscilação no selim e extensão forçada da anca. Por isso, o conteúdo usa estes sinais sem impor ângulos ou medidas fixas.

### Guiador e tronco

O HSS sustenta um alcance confortável, coluna neutra, cotovelos ligeiramente fletidos e ombros afastados das orelhas. O conteúdo transforma estes pontos em instruções observáveis, sem afirmar uma única altura universal do guiador.

### Pés e correias

Os manuais oficiais da Life Fitness e da Cybex convergem: as correias devem impedir o escorregamento do calçado sem desconforto e devem ser verificadas antes do uso. O conteúdo mantém o risco canónico de escorregamento do pé e não cria requisito novo de equipamento pessoal.

### Ajustes e manutenção

Ambos os manuais de bicicleta vertical desaconselham ajustar o selim durante a pedalada e exigem que o mecanismo fique engatado. Também recomendam inspeção regular e retirada de serviço do equipamento defeituoso. Daqui resultam as instruções de parar, desmontar e bloquear os ajustes antes de retomar.

### Paragem e desmontagem

O manual da Schwinn explica que, num sistema de volante fixo, os pedais podem continuar a rodar e a desmontagem só deve ocorrer depois da paragem completa. Como nem todas as bicicletas verticais partilham o mesmo mecanismo, o conteúdo formula a regra geral de paragem completa e qualifica o uso de travão ou comando pelo manual do modelo.

### Respiração

Não foi encontrada uma sincronização respiratória específica ou necessária para cada volta do pedal. O contrato determina, na ausência de suporte específico, respiração natural e contínua sem retenção. A orientação final segue esta regra e não usa contagens.

### Interrupção e supervisão

A ACSM inclui falta de ar, dor articular e tonturas entre respostas que o profissional deve reconhecer ao monitorizar exercício, incluindo bicicleta estacionária. A AHA apoia cautela perante desconforto no peito e falta de ar. O conteúdo conserva exatamente os sinais canónicos e evita interpretação diagnóstica.

O registo canónico não exige supervisão. A recomendação de demonstração perante máquina desconhecida decorre do gatilho canónico de supervisão e da variação documentada entre comandos.

## 6. Decisões editoriais

- Foi usada linguagem de ação direta, adequada a principiante absoluto.
- A execução contém passos distintos desde a inspeção até à desmontagem.
- As pistas centram-se em bloqueios, joelho, apoio dos pés, estabilidade da bacia, relaxamento do tronco, respiração e paragem.
- Cada erro inclui descrição, forma de reconhecimento e correção.
- A orientação de paragem não assume que todas as bicicletas têm o mesmo travão.
- A respiração não é sincronizada com a manivela.
- A referência a ajuda profissional não altera o campo canónico de supervisão.
- Não foi usado qualquer valor de dose.

## 7. Confiança e limitações

| Área | Confiança | Fundamentação |
|---|---|---|
| Execução | Alta | Convergência entre HSS e manuais oficiais de bicicletas verticais. |
| Ajuste do equipamento | Alta | Dois manuais oficiais e uma fonte profissional independente. |
| Segurança de paragem | Alta com qualificação | Regra clara em documentação oficial; o mecanismo concreto varia por modelo. |
| Respiração | Moderada | Orientação genérica determinada pelo contrato, sem padrão próprio da pedalada. |
| Supervisão | Moderada | Preserva gatilhos canónicos; a necessidade individual depende da pessoa e do ambiente. |

Limitações:

- O ajuste indicado é uma triagem técnica geral e não substitui avaliação individual quando existe desconforto.
- A disposição dos comandos, o modo de travagem e os bloqueios devem ser confirmados no manual do equipamento presente.
- As fontes de fabricante são adequadas para operação e segurança do produto, mas não sustentam resultados de treino.
- As fontes de sinais de alarme sustentam interrupção e procura de ajuda, não diagnóstico.

## 8. Verificação do contrato

- Português europeu, UTF-8 e linguagem para principiante: cumprido.
- Identidade, risco, equipamento e relações preservados: cumprido.
- Passos de execução: cumprido.
- Pistas principais: cumprido.
- Erros completos com reconhecimento e correção: cumprido.
- Perguntas de compreensão: cumprido.
- Respiração sem retenção nem contagem: cumprido.
- Duas ou mais fontes independentes quando possível: cumprido.
- Documentação oficial de equipamento: cumprido.
- Ausência de dose, prescrição, promessa, diagnóstico, código e publicação: cumprido.
- Campos pendentes: nenhum.
