# Relatório de pesquisa — Respiração diafragmática

**Agente:** EX-48  
**Exercise ID:** `diaphragmatic_breathing`  
**Data da pesquisa:** 24 de julho de 2026  
**Âmbito:** mecânica, execução, preparação, segurança, erros e supervisão  
**Implementação realizada: não**

## Resultado

O conteúdo para principiantes pode ser aprovado com limites. A identidade canónica está bem sustentada como ciclo respiratório voluntário com excursão diafragmática observável e expansão inferior do tronco. A documentação pública deve, contudo, evitar transformar “respiração diafragmática” em inspiração máxima, abdómen empurrado para fora, tórax imobilizado, protocolo temporizado ou intervenção clínica universal.

## Fontes e independência

Foram consultadas três fontes profissionais oficiais de organizações independentes e dois estudos primários:

1. **Veterans Health Administration, U.S. Department of Veterans Affairs — *Breathing and Health*.** Material oficial revisto por clínicos. Sustenta posição deitada ou sentada, apoios de conforto, observação da respiração antes de a modificar, contacto leve das mãos e precaução em caso de dificuldade respiratória, uso de oxigénio ou tendência para tontura. A fonte também apresenta contagens e retenções noutra secção; esses elementos não foram transpostos porque estão excluídos pelo contrato.
2. **National Heart, Lung, and Blood Institute, NIH — *How the Lungs Work: What Breathing Does for the Body*.** Fonte fisiológica oficial. Sustenta que o diafragma contrai e desce na inspiração, enquanto os músculos intercostais ajudam a expandir a caixa torácica; na expiração confortável, essas estruturas relaxam.
3. **American Lung Association — *Breathing Exercises for Better Lung Health*.** Orientação profissional. Sustenta posição confortável, referência tátil no abdómen e relaxamento do pescoço e ombros. A página é dirigida em parte a pessoas com asma ou DPOC e inclui dose; essas componentes não foram generalizadas.
4. **Vieira DSR et al., 2014 — estudo primário em pessoas saudáveis.** A pletismografia optoeletrónica mostrou maior contribuição abdominal durante a execução estudada. Também registou aumento de variáveis de assincronia toracoabdominal quando a instrução enfatizava movimento abdominal e evitava movimento da caixa torácica. Isto sustenta a decisão conservadora de não pedir imobilidade torácica.
5. **Gosselink RA et al., 1995 — estudo primário em pessoas com DPOC grave.** Na pequena amostra clínica, a execução diafragmática prejudicou a coordenação da parede torácica e a eficiência mecânica, com tendência para maior dispneia. O estudo não autoriza extrapolação para pessoas saudáveis, mas impede uma alegação de benefício universal e reforça a supervisão em doença respiratória relevante.

## Síntese da mecânica

Na inspiração, a contração do diafragma aumenta o volume torácico e associa-se a expansão da parede abdominal inferior. As costelas também participam no aumento do volume torácico. Por isso, uma instrução pública mecanicamente fiel deve orientar a atenção para a expansão inferior e circunferencial do tronco, mas permitir movimento do tórax.

Na expiração confortável, o diafragma e os músculos inspiratórios relaxam. Não há fundamento para exigir contração abdominal forte numa execução básica. A transição entre fases deve permanecer contínua, sem retenção.

## Decisões de execução

### Posição e preparação

- Mantiveram-se as três configurações aprovadas: deitado, sentado e de pé.
- Para principiantes, uma posição deitada ou sentada bem apoiada é apresentada como simplificação opcional, não como nova variante.
- A colocação das mãos é uma referência tátil opcional, não equipamento nem resistência.
- Não foi acrescentado equipamento obrigatório. Cadeira e apoio da cabeça ou joelhos mantêm-se opcionais.
- O ambiente preserva os requisitos canónicos: superfície firme e estável, área segura, ar aceitável, sem veículo em movimento, apoio instável, submersão ou altura desprotegida.

### Movimento

- Observar primeiro a respiração espontânea.
- Inspirar sem esforço excessivo nem amplitude máxima.
- Permitir expansão anterior, lateral e posterior da zona inferior do tronco.
- Permitir movimento natural do tórax.
- Expirar sem apertar ou empurrar com força.
- Prosseguir sem prender o ar.
- Regressar à respiração espontânea se o controlo causar desconforto.

### Via e ritmo

As fontes profissionais frequentemente sugerem inspiração nasal e expiração oral ou com lábios semicerrados. Esses elementos não são necessários à identidade canónica e podem corresponder a uma instrução clínica ou técnica adicional. O conteúdo final não impõe via, proporção entre fases, contagem, cadência ou retenção. Recomenda apenas uma via confortável e desobstruída.

## Erros identificados

1. **Empurrar o abdómen para fora:** confunde expansão decorrente da inspiração com esforço abdominal voluntário.
2. **Imobilizar o tórax:** introduz rigidez desnecessária e pode prejudicar a coordenação toracoabdominal.
3. **Inspirar demasiado fundo ou depressa:** pode promover excesso de ventilação, tontura, formigueiro ou sensação de cabeça leve.
4. **Prender o ar:** quebra a continuidade do ciclo e está fora da identidade aprovada.
5. **Elevar os ombros e contrair o pescoço:** indica esforço acessório desnecessário para a tarefa básica.

## Segurança e supervisão

O risco operacional base permanece baixo. Não é necessário observador ou parceiro no contexto geral se a pessoa estiver estável, compreender a instrução e conseguir parar ou ajustar de forma independente.

O conteúdo recomenda supervisão profissional perante:

- doença cardiovascular ou respiratória relevante;
- uso de oxigénio;
- tendência para desmaiar;
- regresso à função num contexto clínico;
- sintomas novos ou inexplicados;
- incapacidade para interromper ou ajustar a tarefa de forma independente.

São sinais para interromper: tontura, formigueiro, pré-síncope ou síncope, falta de ar atípica ou crescente, dor ou pressão no peito, confusão ou perda de controlo. Dor ou pressão no peito, dificuldade respiratória súbita ou intensa, confusão ou perda de consciência justificam ajuda urgente apropriada.

Estas formulações documentam segurança sem diagnosticar, tratar, prometer resultado ou presumir elegibilidade.

## Limitações da evidência

- As instruções de “respiração diafragmática” variam entre fontes e estudos.
- O estudo de Vieira incluiu uma amostra pequena, jovem, saudável e avaliada numa posição inclinada com uma execução específica.
- O estudo de Gosselink incluiu uma amostra clínica muito pequena com DPOC grave; serve como cautela, não como regra para pessoas saudáveis.
- Fontes profissionais dirigidas a pessoas com doença pulmonar incluem recomendações clínicas e dose que não pertencem à identidade deste exercício.
- A pesquisa sustenta execução documental e cautelas, não eficácia universal nem seleção individual.

## Conformidade com o contrato

- Identidade canónica preservada.
- Risco baixo preservado.
- Equipamento, ambiente, supervisão e relações preservados.
- Sem dose, contagens, retenções ou progressão programada.
- Sem promessa de resultado, diagnóstico ou tratamento.
- Conteúdo em português europeu.
- Mais de cinco passos de execução.
- Mais de quatro pistas principais.
- Pelo menos quatro erros com reconhecimento e correção.
- Doze perguntas de compreensão.
- Sem código, publicação ou aprovação de multimédia.

## Referências

- U.S. Department of Veterans Affairs, Veterans Health Administration. [*Breathing and Health*](https://www.va.gov/wholehealth/veteran-handouts/docs/BreathingAndHealth-508Final-9-4-2018.pdf). Revisto por clínicos e especialistas da VHA; versão datada de 15 de junho de 2020. Consultado em 24 de julho de 2026.
- National Heart, Lung, and Blood Institute. [*How the Lungs Work: What Breathing Does for the Body*](https://www.nhlbi.nih.gov/health/lungs/breathing-benefits). Atualizado em 27 de junho de 2025. Consultado em 24 de julho de 2026.
- American Lung Association. [*Breathing Exercises for Better Lung Health*](https://www.lung.org/lung-health-diseases/wellness/breathing-exercises). Atualizado em 22 de junho de 2026. Consultado em 24 de julho de 2026.
- Vieira DSR, Mendes LPS, Elmiro NS, Velloso M, Britto RR, Parreira VF. [*Breathing exercises: influence on breathing patterns and thoracoabdominal motion in healthy subjects*](https://pmc.ncbi.nlm.nih.gov/articles/PMC4311599/). *Braz J Phys Ther*. 2014;18(6):544–552. DOI: [10.1590/bjpt-rbf.2014.0048](https://doi.org/10.1590/bjpt-rbf.2014.0048).
- Gosselink RA, Wagenaar RC, Rijswijk H, Sargeant AJ, Decramer ML. [*Diaphragmatic breathing reduces efficiency of breathing in patients with chronic obstructive pulmonary disease*](https://pubmed.ncbi.nlm.nih.gov/7697243/). *Am J Respir Crit Care Med*. 1995;151(4):1136–1142. DOI: [10.1164/ajrccm.151.4.7697243](https://doi.org/10.1164/ajrccm.151.4.7697243).
