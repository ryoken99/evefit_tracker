# Marcha no lugar sincronizada com pulso externo

Conteúdo para principiantes em português europeu.

## Descrição curta

Marchar no mesmo local, fazendo coincidir cada apoio do pé com um pulso externo audível.

## O que é

Em pé, eleva e apoia os pés alternadamente sem avançar. Cada novo contacto do pé com o chão coincide com uma batida claramente audível de uma fonte externa.

## O que vais fazer

Vais ouvir primeiro o pulso, iniciar uma marcha estacionária, alternar os pés e usar cada batida como referência para o contacto seguinte. O objetivo técnico é manter o controlo e a coincidência com o sinal, não perseguir o sinal à custa do equilíbrio.

## Porque existe este movimento

Esta tarefa existe para praticar a sincronização de contactos alternados dos pés com uma referência temporal externa. Pode ser usada nos contextos aprovados de ativação, aquecimento ou treino principal, com os limites próprios de cada relação, sem garantir qualquer resultado.

## Antes de começares

1. Confirma que compreendes a tarefa e que consegues iniciá-la e terminá-la voluntariamente.
2. Escolhe uma fonte que produza um pulso regular e claramente audível: dispositivo de reprodução áudio, aplicação de marcação auditiva ou metrónomo.
3. Confirma que o som se distingue do ruído de fundo sem desviar a tua atenção do equilíbrio.
4. Prepare uma área livre, num piso firme, nivelado e antiderrapante.
5. Coloca um apoio estável ao alcance se puderes precisar dele; o apoio é opcional, mas deve estar pronto antes de começares.
6. Não executes num veículo em movimento, junto de uma altura desprotegida ou numa superfície escorregadia, instável ou com objetos soltos.

## Preparar o equipamento

1. Usa uma das alternativas válidas: dispositivo de reprodução áudio, aplicação de marcação auditiva ou metrónomo. Verifica o sinal antes de te colocares em marcha.
2. Se necessário, usa uma parede, bancada fixa ou cadeira estável sem rodas, posicionada de modo a não bloquear os pés.
3. O pulso audível é a referência temporal constitutiva da tarefa; não é necessário um alvo físico separado.
4. O sinal deve manter-se regular e percetível. Se ficar inaudível, irregular ou confuso, pára a marcha antes de ajustar o dispositivo.

## Preparar o espaço

1. Reserva uma pequena área estacionária livre de obstáculos, apesar de não haver deslocamento planeado.
2. Usa apenas piso firme, nivelado e antiderrapante.
3. Retira tapetes soltos, cabos, objetos e qualquer elemento que possa prender o pé.
4. Reduz o ruído de fundo para que o pulso seja claramente distinguível.
5. Mantém distância de escadas, desníveis, trânsito e alturas desprotegidas.
6. Garante iluminação suficiente para ver a posição dos pés e o apoio estável.

## Verificação do corpo

1. Consegues ficar em pé e alternar o apoio dos pés com controlo?
2. Consegues parar por decisão própria e colocar ambos os pés no chão?
3. Consegues ouvir e distinguir o pulso externo?
4. Sentes-te estável antes de levantar o primeiro pé?
5. Tens o apoio definido e ao alcance, se dele precisares?
6. Se existir dor aguda, mal-estar, tontura ou sensação de perda de controlo antes de começar, não inicies.

## Posição inicial

Fica em pé no centro da área livre, com os pés aproximadamente à largura das ancas, peso distribuído pelos dois pés, tronco direito sem rigidez e olhar em frente. Mantém o apoio estável ao alcance, se previsto. Ativa a fonte auditiva e confirma que ouves o pulso com clareza antes de moveres os pés.

## Confirmar a posição inicial

1. Área livre e piso firme, nivelado e antiderrapante.
2. Fonte auditiva ligada, regular e claramente percetível.
3. Apoio estável ao alcance, quando necessário.
4. Pés apoiados e peso distribuído.
5. Tronco direito, ombros soltos e olhar em frente.
6. Capacidade de iniciar e parar voluntariamente confirmada.

## Passos de execução

1. Ouve o pulso sem mover os pés e identifica a batida que servirá de referência para cada contacto.
2. Transfere o peso com controlo para um pé e eleva o outro apenas o suficiente para o libertar do chão.
3. Apoie suavemente o pé elevado, procurando que o contacto coincida com uma batida.
4. Transfere o peso para esse pé e eleva o pé oposto, mantendo-se no mesmo local.
5. Faz o contacto do pé oposto coincidir com a batida seguinte e continua a alternância.
6. Mantém o tronco controlado, o olhar em frente e os contactos silenciosos; o balanço alternado dos braços é opcional.
7. Se deixares de coincidir com o sinal, não aceleres de forma brusca: pousa ambos os pés, recupera a estabilidade, volta a ouvir o pulso e reinicia.
8. Para terminar, escolhe parar, assenta os dois pés e confirma que estás estável antes de mexeres na fonte auditiva.

## Fases do movimento

### Preparação auditiva

Ouvir e reconhecer o pulso antes do primeiro passo.

### Transferência de peso e elevação

Manter um pé em apoio enquanto o outro se liberta do chão.

### Contacto sincronizado

Apoiar o pé elevado em coincidência com a batida.

### Alternância contínua

Repetir a sequência com o outro pé sem deslocar o corpo para a frente.

### Saída controlada

Interromper voluntariamente, assentar ambos os pés e estabilizar.

## Respiração

Respira de forma natural e contínua durante toda a tarefa. Não retenhas a respiração e não forcess a inspiração ou a expiração a coincidir com as batidas; o pulso orienta os contactos dos pés, não a respiração.

## Sensações esperadas

1. Transferência alternada do peso entre os pés.
2. Trabalho de elevação das pernas e de estabilização do tronco e da bacia.
3. Atenção dividida entre o equilíbrio, a alternância e o som.
4. Contacto controlado do pé com o chão.
5. Possível aumento natural da ventilação se a marcha for mantida, sem necessidade de sincronizar a respiração com o pulso.

## Sensações inesperadas ou de alerta

1. Dor aguda.
2. Tontura ou mal-estar.
3. Sensação de queda, tropeço ou perda de controlo.
4. Necessidade repetida de agarrar o apoio sem o ter planeado.
5. Confusão crescente causada pelo sinal ou incapacidade de parar voluntariamente.
6. Falta de ar invulgar ou qualquer sensação que impeça falar e agir com controlo.

## Indicações técnicas principais

1. Ouve primeiro; move-te depois.
2. Um contacto de pé por batida.
3. Alterne os pés sem avançar.
4. Pousa o pé com controlo, sem bater no chão.
5. Olhar em frente e tronco estável.
6. Respira naturalmente; não prendas a respiração.
7. Perdeste o sinal ou o equilíbrio? Pára, estabiliza e só depois recomeça.

## Erros comuns e correções

### Erro 1: Avançar ou recuar em vez de marchar no mesmo local.

- Como reconhecer: Os pés afastam-se progressivamente do ponto inicial ou aproxima-se de objetos à volta.
- Como corrigir: Pára, volta ao centro da área e retoma com elevações menores, concentrando-se em apoiar cada pé debaixo do corpo.

### Erro 2: Perseguir o pulso com passos apressados.

- Como reconhecer: Os contactos tornam-se bruscos, o tronco perde controlo ou surge necessidade de passos extra para recuperar.
- Como corrigir: Não tentes recuperar enquanto marchas. Assenta os dois pés, estabiliza, volta a ouvir o sinal e reinicia apenas se conseguires manter controlo.

### Erro 3: Bater ou arrastar os pés no chão.

- Como reconhecer: O contacto é ruidoso, o pé não se liberta claramente do chão ou prende na superfície.
- Como corrigir: Eleva apenas o suficiente para libertar o pé e faz um apoio suave e completo, mantendo o piso livre.

### Erro 4: Deixar de ouvir o sinal e continuar por memória ou adivinhação.

- Como reconhecer: O ruído de fundo encobre batidas ou deixa de conseguir dizer se o contacto coincidiu com o pulso.
- Como corrigir: Pára a marcha, ajusta a fonte ou o ambiente em segurança e confirma novamente a audibilidade antes de reiniciar.

### Erro 5: Fixar a respiração ao pulso ou reter o ar.

- Como reconhecer: A respiração fica presa, forçada ou aos soluços enquanto tenta seguir as batidas.
- Como corrigir: Deixa a respiração fluir de forma independente e natural; usa o sinal apenas para os contactos dos pés.

## Formas de simplificar ou ensaiar

1. Mantém uma mão em contacto leve com um apoio estável já preparado.
2. Eleva cada pé apenas o necessário para o libertar do chão.
3. Deixa os braços relaxados se o balanço alternado aumentar a dificuldade.
4. Sempre que perderes a coincidência com o sinal, pára completamente e reinicia a partir de uma posição estável.
5. Pede supervisão presencial para aprender a saída da tarefa e a utilização segura do apoio.
6. Estas simplificações preservam o pulso externo audível; retirar o sinal transformaria a tarefa em marcha livre no lugar.

## Supervisão

A supervisão é recomendada, sobretudo na aprendizagem inicial. Deve existir avaliação ou acompanhamento adequado quando há risco elevado de queda, quedas recentes, limitações auditivas que impeçam perceber o sinal, condições neurológicas ou vestibulares, utilização clínica de cueing, incapacidade de interromper a tarefa de forma independente ou necessidade repetida de apoio não planeado. Não é exigido um assistente de segurança por defeito, mas a pessoa que supervisiona deve conseguir interromper o exercício e manter livre o acesso ao apoio.

## Como terminar

Decide terminar sem fazer um último passo apressado. Assenta um pé e depois o outro até ficares com ambos apoiados, recupera uma posição estável e só então desliga ou ajusta a fonte auditiva. Se usaste apoio, mantém-no até teres a estabilidade confirmada.

## Nota de segurança

Risco operacional moderado. Reduz ou interrompe se o pulso induzir pressa, tropeço ou perda de equilíbrio. Pára perante dor aguda, mal-estar, tontura, perda de controlo ou necessidade repetida de apoio não planeado. A utilização clínica de pistas auditivas requer revisão adequada ao contexto.

## Quando parar ou reduzir

1. Dor aguda.
2. Mal-estar.
3. Tontura.
4. Perda de controlo.
5. Tropeço ou sensação de queda.
6. Necessidade repetida de apoio não planeado.
7. Incapacidade de ouvir o pulso com clareza.
8. Incapacidade de interromper a tarefa de forma independente.

## Segurança do equipamento

Usa apenas uma fonte auditiva que produza um sinal regular, estável e claramente percetível. Coloca o dispositivo e os cabos fora da área dos pés. Não mexas no dispositivo enquanto estás a marchar; pára e estabiliza primeiro. Se usares cadeira como apoio, escolhe uma cadeira sólida, estável e sem rodas. Não uses auscultadores ou volume que impeçam perceber o ambiente e as indicações da pessoa que supervisiona.

## Segurança do espaço

Piso firme, nivelado e antiderrapante. Área estacionária livre de obstáculos, cabos e tapetes soltos. Ruído de fundo suficientemente baixo para distinguir o pulso. Iluminação que permita ver os pés, o chão e o apoio. Nunca num veículo em movimento nem junto de uma altura desprotegida. Não executar numa superfície escorregadia, instável ou desorganizada.

## Limitações

1. A evidência direta de sincronização auditiva no passo no lugar é sobretudo proveniente de populações clínicas.
2. Não se generalizam resultados de investigação nem se promete melhoria.
3. Não é definido qualquer valor temporal do pulso, dose, intensidade ou progressão.
4. A respiração natural e contínua é uma orientação conservadora de segurança, não um protocolo respiratório estudado especificamente nesta tarefa.
5. Condições neurológicas, vestibulares, quedas recentes, risco elevado de queda ou utilização clínica de cueing requerem revisão adequada.

## Teste de compreensão

### 1. O corpo deve avançar durante este exercício?

Resposta esperada: Não. Os pés alternam no mesmo local, sem deslocamento planeado.

### 2. Que acontecimento deve coincidir com cada batida?

Resposta esperada: O contacto de um pé com o chão.

### 3. Podes iniciar se não ouvir claramente o pulso?

Resposta esperada: Não. Deves primeiro tornar o sinal claramente percetível.

### 4. O que fazes se ficares atrasado em relação ao sinal?

Resposta esperada: Não acelera de forma brusca; para, estabiliza, volta a ouvir e só depois reinicia.

### 5. Em que tipo de piso deves executar?

Resposta esperada: Num piso firme, nivelado e antiderrapante, numa área livre.

### 6. Quando deves mexer no dispositivo de áudio?

Resposta esperada: Apenas depois de parar a marcha e recuperar uma posição estável.

### 7. Tens de sincronizar a respiração com as batidas?

Resposta esperada: Não. Deves respirar naturalmente e sem reter o ar.

### 8. O apoio estável pode ser preparado antes de começar?

Resposta esperada: Sim. É opcional, mas deve estar ao alcance quando possa ser necessário.

### 9. Quais são três sinais para interromper?

Resposta esperada: Por exemplo, dor aguda, tontura e perda de controlo.

### 10. É adequado continuar quando precisa repetidamente de apoio não planeado?

Resposta esperada: Não. Deves interromper e procurar revisão ou supervisão adequada.

### 11. O balanço dos braços é obrigatório?

Resposta esperada: Não. Pode ser alternado, mas é opcional.

### 12. Como termina o exercício em segurança?

Resposta esperada: Decide parar, assenta ambos os pés, confirma a estabilidade e só depois desliga ou ajusta o som.

## Fontes e limites da evidência

### Fonte 1: Chang HY, Lee YY, Wu RM, Yang YR, Luh JJ. Effects of rhythmic auditory cueing on stepping in place in patients with Parkinson's disease. Medicine. 2019;98(45):e17874.

- Autor ou entidade: E2-S21 — Chang HY, Lee YY, Wu RM, Yang YR, Luh JJ. Effects of rhythmic auditory cueing on stepping in place in patients with Parkinson's disease. Medicine. 2019;98(45):e17874. — https://pmc.ncbi.nlm.nih.gov/articles/PMC6855520/ — estudo primário aleatorizado cruzado — Evidência direta de que o passo no lugar pode ser organizado por uma pista auditiva externa. — A amostra era clínica e de dimensão limitada; não permite generalizar efeitos nem parâmetros a principiantes em geral.
- Tipo: estudo primário aleatorizado cruzado
- Localizador: https://pmc.ncbi.nlm.nih.gov/articles/PMC6855520/
- Usada para: E2-S21 — Chang HY, Lee YY, Wu RM, Yang YR, Luh JJ. Effects of rhythmic auditory cueing on stepping in place in patients with Parkinson's disease. Medicine. 2019;98(45):e17874. — https://pmc.ncbi.nlm.nih.gov/articles/PMC6855520/ — estudo primário aleatorizado cruzado — Evidência direta de que o passo no lugar pode ser organizado por uma pista auditiva externa. — A amostra era clínica e de dimensão limitada; não permite generalizar efeitos nem parâmetros a principiantes em geral.
- Limite: E2-S21 — Chang HY, Lee YY, Wu RM, Yang YR, Luh JJ. Effects of rhythmic auditory cueing on stepping in place in patients with Parkinson's disease. Medicine. 2019;98(45):e17874. — https://pmc.ncbi.nlm.nih.gov/articles/PMC6855520/ — estudo primário aleatorizado cruzado — Evidência direta de que o passo no lugar pode ser organizado por uma pista auditiva externa. — A amostra era clínica e de dimensão limitada; não permite generalizar efeitos nem parâmetros a principiantes em geral.

### Fonte 2: Thaut MH, McIntosh GC, Rice RR, Miller RA, Rathbun J, Brault JM. Rhythmic auditory stimulation in gait training for Parkinson's disease patients. Movement Disorders. 1996;11(2):193-200.

- Autor ou entidade: E2-S20 — Thaut MH, McIntosh GC, Rice RR, Miller RA, Rathbun J, Brault JM. Rhythmic auditory stimulation in gait training for Parkinson's disease patients. Movement Disorders. 1996;11(2):193-200. — https://pubmed.ncbi.nlm.nih.gov/8684391/ — ensaio clínico primário comparativo — Suporte de família para acoplamento temporal entre contactos da marcha e estimulação auditiva rítmica. — Estudou marcha numa população clínica e não estabelece conteúdo universal nem uma cadência para esta tarefa.
- Tipo: ensaio clínico primário comparativo
- Localizador: https://pubmed.ncbi.nlm.nih.gov/8684391/
- Usada para: E2-S20 — Thaut MH, McIntosh GC, Rice RR, Miller RA, Rathbun J, Brault JM. Rhythmic auditory stimulation in gait training for Parkinson's disease patients. Movement Disorders. 1996;11(2):193-200. — https://pubmed.ncbi.nlm.nih.gov/8684391/ — ensaio clínico primário comparativo — Suporte de família para acoplamento temporal entre contactos da marcha e estimulação auditiva rítmica. — Estudou marcha numa população clínica e não estabelece conteúdo universal nem uma cadência para esta tarefa.
- Limite: E2-S20 — Thaut MH, McIntosh GC, Rice RR, Miller RA, Rathbun J, Brault JM. Rhythmic auditory stimulation in gait training for Parkinson's disease patients. Movement Disorders. 1996;11(2):193-200. — https://pubmed.ncbi.nlm.nih.gov/8684391/ — ensaio clínico primário comparativo — Suporte de família para acoplamento temporal entre contactos da marcha e estimulação auditiva rítmica. — Estudou marcha numa população clínica e não estabelece conteúdo universal nem uma cadência para esta tarefa.

### Fonte 3: Harrison EC et al. Auditory indicações técnicas and gait variability in Parkinson disease: a systematic review. 2023. PMID 36695189.

- Autor ou entidade: E1-SRC-024 — Harrison EC et al. Auditory indicações técnicas and gait variability in Parkinson disease: a systematic review. 2023. PMID 36695189. — https://pubmed.ncbi.nlm.nih.gov/36695189/ — revisão sistemática — Contextualização da variabilidade individual da resposta a pistas auditivas. — Evidência clínica específica; não sustenta promessas nem transferência automática entre populações.
- Tipo: revisão sistemática
- Localizador: https://pubmed.ncbi.nlm.nih.gov/36695189/
- Usada para: E1-SRC-024 — Harrison EC et al. Auditory indicações técnicas and gait variability in Parkinson disease: a systematic review. 2023. PMID 36695189. — https://pubmed.ncbi.nlm.nih.gov/36695189/ — revisão sistemática — Contextualização da variabilidade individual da resposta a pistas auditivas. — Evidência clínica específica; não sustenta promessas nem transferência automática entre populações.
- Limite: E1-SRC-024 — Harrison EC et al. Auditory indicações técnicas and gait variability in Parkinson disease: a systematic review. 2023. PMID 36695189. — https://pubmed.ncbi.nlm.nih.gov/36695189/ — revisão sistemática — Contextualização da variabilidade individual da resposta a pistas auditivas. — Evidência clínica específica; não sustenta promessas nem transferência automática entre populações.

### Fonte 4: American Parkinson Disease Association. Freezing of Gait and Parkinson's Disease.

- Autor ou entidade: E1-SRC-031 — American Parkinson Disease Association. Freezing of Gait and Parkinson's Disease. — https://www.apdaparkinson.org/what-is-parkinsons/symptoms/freezing-of-gait/ — organização profissional — Confirma o cueing como estratégia clínica reconhecida e reforça a separação entre conteúdo geral e utilização clínica. — Não é uma instrução universal de treino nem substitui revisão profissional.
- Tipo: organização profissional
- Localizador: https://www.apdaparkinson.org/what-is-parkinsons/symptoms/freezing-of-gait/
- Usada para: E1-SRC-031 — American Parkinson Disease Association. Freezing of Gait and Parkinson's Disease. — https://www.apdaparkinson.org/what-is-parkinsons/symptoms/freezing-of-gait/ — organização profissional — Confirma o cueing como estratégia clínica reconhecida e reforça a separação entre conteúdo geral e utilização clínica. — Não é uma instrução universal de treino nem substitui revisão profissional.
- Limite: E1-SRC-031 — American Parkinson Disease Association. Freezing of Gait and Parkinson's Disease. — https://www.apdaparkinson.org/what-is-parkinsons/symptoms/freezing-of-gait/ — organização profissional — Confirma o cueing como estratégia clínica reconhecida e reforça a separação entre conteúdo geral e utilização clínica. — Não é uma instrução universal de treino nem substitui revisão profissional.

### Fonte 5: NHS. Balance exercises. Revisto em 7 de novembro de 2023.

- Autor ou entidade: PRO-NHS-01 — NHS. Balance exercises. Revisto em 7 de novembro de 2023. — https://www.nhs.uk/live-well/exercise/balance-exercises/ — orientação oficial de saúde — Suporte para roupa confortável e presença de parede ou cadeira estável quando existe possibilidade de perda de equilíbrio. — Orientação geral de equilíbrio; não aborda sincronização auditiva específica.
- Tipo: orientação oficial de saúde
- Localizador: https://www.nhs.uk/live-well/exercise/balance-exercises/
- Usada para: PRO-NHS-01 — NHS. Balance exercises. Revisto em 7 de novembro de 2023. — https://www.nhs.uk/live-well/exercise/balance-exercises/ — orientação oficial de saúde — Suporte para roupa confortável e presença de parede ou cadeira estável quando existe possibilidade de perda de equilíbrio. — Orientação geral de equilíbrio; não aborda sincronização auditiva específica.
- Limite: PRO-NHS-01 — NHS. Balance exercises. Revisto em 7 de novembro de 2023. — https://www.nhs.uk/live-well/exercise/balance-exercises/ — orientação oficial de saúde — Suporte para roupa confortável e presença de parede ou cadeira estável quando existe possibilidade de perda de equilíbrio. — Orientação geral de equilíbrio; não aborda sincronização auditiva específica.

### Fonte 6: Leicestershire Partnership NHS Trust. Balance Class Exercises: Marching on the Spot.

- Autor ou entidade: PRO-NHS-02 — Leicestershire Partnership NHS Trust. Balance Class Exercises: Marching on the Spot. — https://www.leicspart.nhs.uk/wp-content/uploads/2020/06/Balance-Class-Exercises.pdf — material profissional oficial — Suporte técnico para postura direita, pés afastados de forma confortável, peso distribuído, marcha no lugar e apoio estável quando necessário. — A folha inclui opções de dificuldade e dose que não foram importadas para este conteúdo.
- Tipo: material profissional oficial
- Localizador: https://www.leicspart.nhs.uk/wp-content/uploads/2020/06/Balance-Class-Exercises.pdf
- Usada para: PRO-NHS-02 — Leicestershire Partnership NHS Trust. Balance Class Exercises: Marching on the Spot. — https://www.leicspart.nhs.uk/wp-content/uploads/2020/06/Balance-Class-Exercises.pdf — material profissional oficial — Suporte técnico para postura direita, pés afastados de forma confortável, peso distribuído, marcha no lugar e apoio estável quando necessário. — A folha inclui opções de dificuldade e dose que não foram importadas para este conteúdo.
- Limite: PRO-NHS-02 — Leicestershire Partnership NHS Trust. Balance Class Exercises: Marching on the Spot. — https://www.leicspart.nhs.uk/wp-content/uploads/2020/06/Balance-Class-Exercises.pdf — material profissional oficial — Suporte técnico para postura direita, pés afastados de forma confortável, peso distribuído, marcha no lugar e apoio estável quando necessário. — A folha inclui opções de dificuldade e dose que não foram importadas para este conteúdo.
