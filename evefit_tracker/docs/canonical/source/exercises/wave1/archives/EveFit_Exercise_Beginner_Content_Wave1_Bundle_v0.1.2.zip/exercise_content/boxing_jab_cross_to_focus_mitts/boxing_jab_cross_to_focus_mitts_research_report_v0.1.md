# Relatório de investigação — sequência jab-direto para manoplas

**Exercise ID:** `boxing_jab_cross_to_focus_mitts`  
**Agente:** EX-45  
**Data da pesquisa:** 2026-07-24  
**Implementação realizada: não**

## Resultado

O conteúdo documental para principiantes pode ser aprovado com limites. A identidade permanece um drill fechado de dois golpes retos — jab e direto traseiro — contra duas manoplas sustentadas por parceiro, seguido do regresso à guarda. O risco continua moderado. Parceiro, proteção das mãos, duas manoplas, espaço controlado e supervisão continuam obrigatórios.

Não foi encontrada base para transformar o exercício em sparring, reduzir o risco, retirar equipamento, dispensar parceiro ou supervisão, ou prescrever dose.

## Fontes primárias e oficiais consultadas

### F1S18 — England Boxing, *Coaching Handbook Part 1*

<https://www.englandboxing.org/wp-content/uploads/2022/03/EB_Boxing-Coaching-Handbook-Part-1_v8-002.pdf>

Secções relevantes:

- proteção das mãos, pp. 18–20;
- golpe reto da mão da frente, pp. 72–73;
- direto da mão traseira, pp. 74–75;
- combinações, pp. 88–89;
- padwork, pp. 95–98.

Contributos:

- luvas e ligaduras são necessárias quando há contacto com manoplas;
- o jab parte de uma base estável, mantém a mão traseira em guarda e regressa pela mesma linha;
- o direto usa rotação do pé traseiro, anca e tronco, sem compromisso excessivo da base;
- combinações simples devem terminar equilibradas e sob controlo;
- o parceiro apresenta um alvo realista, controla o contexto e não move a manopla ao encontro do golpe.

### F2-S20 — Boxing Canada, *Instruction Beginners Reference Manual*

<https://boxingcanada.org/wp-content/uploads/2025/01/Instruction-Beginners-Reference-Manual-EN.pdf>

Secções relevantes:

- jab, pp. 51–53;
- direto traseiro, pp. 56–58;
- combinação one-two, pp. 59–60;
- uso eficaz de manoplas, pp. 61–64.

Contributos:

- o jab é um golpe reto da mão da frente, com a mão traseira em guarda, retração rápida e equilíbrio;
- o direto é conduzido pela perna traseira e pela rotação coordenada da anca e dos ombros, com a mão da frente em guarda;
- a combinação one-two liga jab e direto, mantendo mecânica e equilíbrio;
- o trabalho de manoplas requer experiência do parceiro, luvas, atenção e feedback;
- técnica e precisão prevalecem sobre força;
- as manoplas não devem ser mantidas demasiado afastadas para golpes destinados a uma linha-alvo comum.

### EX45-S01 — USA Boxing, *Grassroots Task Force Training Manual v.01*

<https://d36m266ykvepgv.cloudfront.net/uploads/media/lYivrDbNV6/o/usab-gtf-trainingmanual-v-01-1.pdf>

Secções relevantes:

- respiração, pp. 116–118;
- posição de guarda, pp. 134–135;
- jab e direto, pp. 136–139.

Contributos:

- uma expiração curta pode acompanhar cada golpe;
- a respiração deve continuar fluida durante a ação, sem bloqueio;
- o jab prepara o direto e ambos dependem de guarda e base organizadas.

A aplicação ao conteúdo foi deliberadamente conservadora: expiração curta e confortável em cada contacto, entrada de ar natural, sem contagens, retenções ou promessas fisiológicas.

### EX45-S02 — AIBA, *Coaches Manual*

<https://www.iba.sport/wp-content/uploads/2019/01/AIBA-Coach-Regulations-Manual_WEB_2019_01-1.pdf>

Secções relevantes:

- ensino dos golpes retos;
- jab e direto traseiro;
- combinações de dois golpes.

Contributos:

- cada golpe parte e termina na guarda;
- a mão que não golpeia protege;
- a combinação jab-direto é uma sequência básica reconhecida;
- a coordenação da anca e dos ombros deve ser preservada.

## Síntese técnica adotada

| Tema | Decisão documental |
|---|---|
| Ordem | Jab da mão da frente, retração, direto da mão traseira, regresso à guarda |
| Jab | Linha reta, punho alinhado, mão traseira em guarda e retorno pela mesma linha |
| Direto | Apoio e rotação coordenada do pé, anca e ombro traseiros, mão da frente em guarda |
| Base | Ambos os pés mantêm apoio funcional; evitar inclinação e rotação excessivas |
| Manoplas | Dois alvos sucessivos próximos da linha central; palmas voltadas ao praticante; não avançar contra o golpe |
| Contacto | Controlado e dirigido ao centro das manoplas; técnica acima de força |
| Respiração | Expiração curta e confortável em cada golpe; respiração fluida; sem retenção |
| Final | Guarda, olhar no parceiro e equilíbrio recuperado |

## Preparação do parceiro e segurança

O parceiro é obrigatório e deve ter competência para segurar manoplas. Assume uma base estável, prende corretamente as manoplas, combina os sinais com o praticante e apresenta cada alvo de modo previsível. A referência da Boxing Canada a uma única linha-alvo para golpes à cabeça foi reconciliada com a identidade canónica de duas manoplas: as duas manoplas continuam a ser contactadas, mas são apresentadas sucessivamente perto da mesma linha central, não como alvos simultâneos muito afastados.

O parceiro não deve “apanhar” o golpe lançando a manopla para a frente. As fontes da England Boxing pedem que o alvo não se desloque ao encontro do golpe, preservando o percurso técnico e reduzindo choque desnecessário.

Os controlos documentados incluem:

- luvas e ligaduras obrigatórias;
- verificação do estado e ajuste do equipamento;
- piso firme, nivelado, seco e antiderrapante;
- espaço lateral livre e sem circulação não controlada;
- sinal de início e palavra de paragem;
- contacto apenas nas manoplas;
- interrupção perante dor na mão ou no punho, alvo repetidamente mal colocado, perda de guarda ou equilíbrio, ou outros sinais de alerta;
- supervisão obrigatória, com atenção reforçada na primeira exposição, com parceiro novo ou perante aumento do contacto.

## Erros suportados

As fontes sustentam diretamente ou por convergência:

- baixar a mão que devia permanecer em guarda;
- executar o direto apenas com o braço;
- rodar ou inclinar em excesso e perder a base;
- falhar o alinhamento do punho ou o centro do alvo;
- afastar demasiado as manoplas;
- mover a manopla ao encontro do golpe;
- não retrair as mãos à guarda;
- sacrificar a técnica por força.

## Relações canónicas preservadas

Não foram criadas, removidas ou alteradas relações.

| Capacidade | Conceito | Intenção | Papel |
|---|---|---|---|
| `motor_control_coordination` | `repeated_motor_sequence` | `improve_sequence_transition_control` | `complementary` |
| `technique_skill` | `contextual_technical_application` | `integrate_skill_in_task_context` | `principal_candidate` |
| `technique_skill` | `repeated_motor_sequence` | `improve_technical_sequence_fluency` | `alternative_primary` |
| `technique_skill` | `target_oriented_precision` | `improve_target_spatial_precision` | `complementary` |

Os limites associados permanecem: não inferir potência, sparring, transferência competitiva ou dose; conservar parceiro competente, proteção das mãos, contacto controlado, risco moderado e supervisão obrigatória.

## Confiança e limites

**Confiança global:** alta para execução documental com limites.

Existe concordância forte entre England Boxing e Boxing Canada sobre guarda, trajetória, rotação, equilíbrio e uso das manoplas. A orientação respiratória específica é sustentada pela USA Boxing e foi formulada sem contagens nem retenções. O manual AIBA funciona como confirmação independente da sequência básica.

O conteúdo:

- não prescreve repetições, séries, duração, carga, intensidade, ritmo, frequência ou progressão;
- não promete resultados;
- não diagnostica, trata ou concede autorização universal;
- não substitui instrução presencial;
- não aprova multimédia;
- não altera identidade, risco, equipamento, parceiro, espaço, supervisão ou relações;
- não implementa código nem publica conteúdo.

**Campos por resolver:** nenhum no âmbito documental atribuído.
