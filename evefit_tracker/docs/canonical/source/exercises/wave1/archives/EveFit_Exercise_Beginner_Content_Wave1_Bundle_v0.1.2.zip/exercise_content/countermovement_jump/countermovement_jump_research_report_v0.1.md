# Relatório de investigação — salto vertical com contramovimento

**Agente:** EX-16  
**Exercício:** `countermovement_jump`  
**Data de consulta:** 2026-07-23  
**Idioma do conteúdo:** português europeu  
**Risco operacional preservado:** `high`  

## Resultado

Foi produzido conteúdo documental para principiante com estado `beginner_content_approved_with_limits`. A identidade canónica, o risco elevado, a ausência de equipamento obrigatório, a superfície firme, plana, regular e antiderrapante, a receção bipodal e as duas relações canónicas foram preservados.

A explicação não equivale a autorização de prática autónoma no primeiro dia. A primeira exposição técnica é apresentada como situação que deve ser observada por profissional qualificado.

## Perguntas investigadas

- Como se distingue o contramovimento de um salto iniciado após pausa?
- Que sequência articular caracteriza a descida, a propulsão e a receção?
- Que cues são sustentáveis para uma aterragem controlada?
- Que erros são reconhecíveis por um principiante e observáveis por um supervisor?
- Que orientação respiratória é defensável sem impor retenções ou contagens?
- Que condições de espaço, superfície e supervisão são coerentes com risco elevado?
- Como deve a pessoa sair de uma tentativa cuja aterragem se desorganiza?

## Síntese da evidência

### Execução e contramovimento

O manual profissional da National Strength and Conditioning Association descreve o salto vertical a partir de uma base bipodal, seguido de descida preparatória, extensão imediata da anca, dos joelhos e dos tornozelos e aterragem com flexão dessas articulações. Também explicita que não deve existir pausa entre baixar e estender.

O estudo biomecânico primário de Bobbert et al. comparou o salto com contramovimento e o salto iniciado estaticamente. O trabalho sustenta que a fase preparatória altera as condições mecânicas da propulsão e ajuda a explicar a diferença de desempenho. Para o conteúdo público, esta evidência foi usada apenas para preservar a distinção técnica: descida e inversão contínuas, sem transformar o achado numa promessa de maior altura.

Decisão editorial:

- descrever uma descida coordenada pela anca, joelhos e tornozelos;
- exigir inversão sem pausa artificial;
- manter a trajetória vertical;
- não fixar profundidade, velocidade, altura ou esforço;
- não tornar o balanço dos braços obrigatório.

### Propulsão e posição dos braços

A extensão coordenada da anca, dos joelhos e dos tornozelos é consistente entre o registo canónico e o manual da NSCA. Literatura biomecânica mostra que o balanço dos braços pode alterar o desempenho e o trabalho dos membros inferiores, mas o registo canónico determina que os braços não fazem parte necessária desta base.

Decisão editorial:

- recomendar uma posição simples e estável escolhida com o supervisor;
- permitir que os braços fiquem quietos durante a aprendizagem;
- não prescrever balanço nem criar uma variante;
- não prometer aumento de altura.

### Aterragem e travagem

O manual da NSCA descreve aterragem suave, flexão imediata da anca, dos joelhos e dos tornozelos e prevenção da aproximação dos joelhos. Milner et al., num estudo primário, observaram que a instrução para aterrar suavemente reduziu o pico de força vertical e aumentou a flexão máxima do joelho na população estudada. McNair, Prapavessis e Callender também estudaram instruções dirigidas à aterragem e mostraram que o feedback verbal pode alterar as forças verticais.

Estes estudos apoiam os cues “aterra suave e silenciosamente” e “dobra anca, joelhos e tornozelos”, mas não demonstram prevenção garantida de lesão. A relação entre alinhamento observado e risco individual não foi apresentada como diagnóstico.

Critérios documentais de receção controlada:

- contacto quase simultâneo dos dois pés;
- assentamento controlado;
- flexão coordenada da anca, dos joelhos e dos tornozelos;
- joelhos orientados de forma coerente com os pés;
- tronco estável;
- capacidade de parar sem novo salto;
- ausência de passo de recuperação como objetivo técnico.

Um passo usado para evitar uma queda é tratado como saída de segurança, não como parte correta do exercício.

### Respiração

Não foi encontrada evidência direta que imponha uma sincronização respiratória universal no salto com contramovimento. A orientação profissional geral da Mayo Clinic recomenda não reter a respiração durante esforço e sugere expirar na fase de elevação.

Decisão conservadora:

- manter respiração natural e contínua;
- aceitar uma expiração curta na impulsão se surgir espontaneamente;
- não impor contagens, inspiração profunda ou apneia;
- classificar a confiança respiratória como moderada;
- declarar explicitamente a extrapolação de orientação geral.

### Segurança, superfície e supervisão

O risco `high` foi preservado por existir fase aérea, impacto e necessidade de absorver rapidamente a carga na receção. O registo canónico exige superfície firme, regular e antiderrapante, área segura de aterragem, espaço livre superior e ausência de obstáculos. Não foi acrescentado qualquer equipamento.

A revisão de Davies, Riemann e Manske sustenta que tarefas pliométricas exigem preparação, progressão e domínio técnico. A NSCA salienta a aprendizagem da aterragem e a execução correta. O registo canónico identifica a primeira exposição técnica como gatilho de supervisão.

Decisão editorial:

- supervisão profissional recomendada no exercício em geral;
- primeira prática não autónoma;
- spotter não obrigatório;
- demonstração prévia de base, descida e receção simples;
- interrupção perante dor aguda, mal-estar, perda súbita de coordenação ou incapacidade de controlar a receção;
- nenhuma conclusão clínica ou autorização universal.

## Fontes consultadas

| Código | Fonte | Tipo | Contributo | Limite |
|---|---|---|---|---|
| `B1-S15` | Davies, Riemann e Manske, [Current Concepts of Plyometric Exercise](https://pmc.ncbi.nlm.nih.gov/articles/PMC4637913/) | Revisão clínica com arbitragem | Ciclo alongamento-encurtamento, preparação, aterragem e fronteiras de risco | Evidência de família; não define elegibilidade individual |
| `SP-B2-S30` | Ramirez-Campillo et al., [Plyometric Jump Training in Female Soccer Players](https://pmc.ncbi.nlm.nih.gov/articles/PMC9424421/) | Revisão sistemática | Contexto de evidência da família de saltos | População e intervenções específicas |
| `EX16-S1` | NSCA, [Basics of Strength and Conditioning Manual](https://www.nsca.com/contentassets/48a12160221541acbdc048498d77192d/basics_of_strength_and_conditioning_manual.pdf) | Manual profissional | Sequência do salto vertical, ausência de pausa, extensão e aterragem | Usa balanço dos braços no exemplo; não foi tornado obrigatório |
| `EX16-S2` | Bobbert et al., [Why is countermovement jump height greater than squat jump height?](https://pubmed.ncbi.nlm.nih.gov/8933491/) | Estudo biomecânico primário | Função mecânica do contramovimento e distinção do salto estático | Não testa segurança, principiantes ou respiração |
| `EX16-S3` | Milner et al., [Simple verbal instruction improves knee biomechanics during landing in female athletes](https://pubmed.ncbi.nlm.nih.gov/21676618/) | Estudo biomecânico primário | Efeito do cue de aterragem suave | População atleta feminina; não garante prevenção de lesão |
| `EX16-S4` | McNair, Prapavessis e Callender, [Decreasing landing forces: effect of instruction](https://pmc.ncbi.nlm.nih.gov/articles/PMC1724204/) | Estudo experimental primário | Efeito de instruções na força de aterragem | Condições laboratoriais; não define prescrição |
| `EX16-S5` | Mayo Clinic, [Weight training: Do's and don'ts of proper technique](https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/weight-training/art-20045842) | Orientação profissional | Evitar retenção respiratória durante esforço | Não específica do salto |

## Campos adicionais de risco elevado

### Competência prévia

Demonstrar sob supervisão uma base bipodal estável, descida coordenada e receção bipodal simples sem dor, colapso evidente dos joelhos ou perda de equilíbrio.

### Recomendação de supervisão

Supervisão por profissional de exercício qualificado, com prioridade à primeira exposição técnica e a qualquer situação de receção ruidosa, assimetria, inexperiência ou perda de alinhamento. O spotter não é obrigatório.

### Espaço seguro

Zona pequena mas totalmente desimpedida, superfície firme, plana, regular e antiderrapante, espaço livre por cima da cabeça, área de receção segura e ausência de trânsito ou cruzamentos públicos.

### Controlo da aterragem ou travagem

Contacto bipodal quase simultâneo, assentamento controlado, flexão coordenada, alinhamento observável, tronco estável e paragem sem novo salto.

### Estratégia de saída

Não salvar uma aterragem desorganizada com outro salto. Usar um passo de recuperação se necessário, afastar-se a caminhar e interromper. Perante queda iminente, proteger a cabeça e não agarrar objetos instáveis.

## Relações e fronteiras preservadas

1. `countermovement_jump__main_training__speed_power__ballistic_projection__increase_ballistic_power`
   - estado: `compatible`
   - papel: `principal_candidate`
   - risco contextual: `high`

2. `countermovement_jump__warmup__speed_power__ballistic_projection__rehearse_landing_or_reception`
   - estado: `conditional`
   - papel: `complementary`
   - risco contextual: `moderate_or_higher_by_session`
   - classificação condicional: `unresolved_product_logic`

Não foram criadas relações, variantes, requisitos de equipamento, aprovações de multimédia ou alterações de identidade.

## Limitações

- O conteúdo não prescreve dose, intensidade, ritmo, frequência, carga, duração ou progressão.
- Não existe avaliação individual de prontidão, historial, lesão ou contexto clínico.
- A evidência respiratória é geral e não específica do salto com contramovimento.
- Os estudos de aterragem utilizam populações e tarefas experimentais que limitam a generalização.
- Um cue que reduz forças numa tarefa não prova prevenção de lesão.
- A relação de aquecimento continua dependente de lógica de produto ainda não resolvida.
- O texto não autoriza prática autónoma no primeiro dia.

## Verificações finais

- Português europeu: sim.
- UTF-8 e conteúdo preparado em Unicode NFC: sim.
- Passos de execução: oito.
- Cues principais: seis.
- Erros comuns com reconhecimento e correção: seis.
- Perguntas de compreensão: doze.
- Campos adicionais de risco elevado: cinco.
- Equipamento obrigatório preservado como nenhum: sim.
- Superfície e espaço preservados: sim.
- Identidade, risco e relações preservados: sim.
- Dose, promessa, diagnóstico, código ou publicação: não incluídos.

Implementação realizada: não
