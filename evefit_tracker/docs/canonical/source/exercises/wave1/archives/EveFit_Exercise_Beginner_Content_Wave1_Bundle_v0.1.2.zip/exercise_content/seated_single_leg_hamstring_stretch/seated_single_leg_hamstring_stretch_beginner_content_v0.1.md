# Alongamento unilateral dos isquiotibiais sentado

Conteúdo para principiantes em português europeu.

## Descrição curta

Inclinação controlada a partir da anca sobre uma perna estendida, em posição sentada.

## O que é

Senta-te numa superfície estável, estende uma perna e inclina o tronco a partir da anca sobre essa perna, apenas até uma posição controlável. A outra perna fica dobrada e organizada para dar conforto e apoio à posição sentada.

## O que vais fazer

Vais organizar uma posição sentada assimétrica, manter o joelho da perna-alvo estendido sem o forçar e levar o tronco para a frente através da anca. O movimento termina antes de dor, sintomas elétricos ou perda de controlo.

## Porque existe este movimento

Este exercício permite praticar uma posição de alongamento tolerada para a parte posterior da coxa, sem carga portátil, assistência externa ou movimento balístico.

## Antes de começares

1. Escolhe uma superfície estável, antiderrapante e sem trânsito ou obstáculos próximos.
2. Não é necessário equipamento portátil; um tapete de exercício é opcional para conforto.
3. Confirma que consegues sentar-te, estender uma perna e voltar à posição vertical com controlo.
4. Não inicies se já estiver presente dor aguda ou crescente, dormência, formigueiro, sensação elétrica, fraqueza súbita, instabilidade ou mal-estar.
5. Se estás a regressar após lesão ou cirurgia, ou se uma condição relevante altera a tua mobilidade ou sensibilidade, obtém primeiro orientação profissional adequada.

## Preparar o equipamento

1. Não há equipamento obrigatório. Se usares um tapete, coloca-o totalmente assente numa superfície firme e verifica que não desliza nem cria dobras sob a bacia ou a perna.

## Preparar o espaço

1. Reserva um espaço pequeno e livre, no interior ou no exterior, sobre piso firme e antiderrapante. Evita superfícies escorregadias, instáveis, inclinadas ou expostas a trânsito ativo.

## Verificação do corpo

1. Senta-te e verifica se a bacia fica apoiada sem sensação de queda ou desequilíbrio.
2. Estende a perna-alvo apenas até conseguires manter o joelho sem pressão agressiva atrás da articulação.
3. Faz uma inclinação mínima a partir da anca e confirma que consegues parar e regressar de imediato.
4. Prossegue apenas se a sensação for de tensão muscular tolerável e localizada sobretudo na parte posterior da coxa.

## Posição inicial

Senta-te com a bacia estável. Estende uma perna à frente e mantém o pé e o joelho orientados para cima. Dobra a outra perna e pousa-a de forma confortável, sem empurrar a perna estendida. Cresce pelo tronco, alinha a cabeça com a coluna e deixa as mãos pousadas sem puxar o pé.

## Confirmar a posição inicial

1. Bacia apoiada e estável.
2. Uma perna estendida sem bloqueio agressivo do joelho.
3. Outra perna dobrada e confortável.
4. Pé e joelho da perna estendida alinhados.
5. Tronco alto, cabeça alinhada e ombros sem tensão desnecessária.
6. Mãos pousadas sem criar força externa sobre o pé ou a perna.

## Passos de execução

1. Organiza a bacia sobre a superfície e confirma que consegues manter-te sentado sem deslizar.
2. Estende uma perna à frente, com o joelho sem bloqueio agressivo e o pé alinhado e descontraído.
3. Dobra a outra perna e deixa-a apoiada numa posição confortável que não empurre nem rode a perna estendida.
4. Alonga o tronco para cima e mantém a cabeça alinhada com a coluna.
5. Expira suavemente e inicia uma pequena inclinação para a frente a partir da anca, levando a bacia e o tronco como uma unidade.
6. Continua apenas até surgir tensão muscular tolerável na parte posterior da coxa, sem procurar alcançar o pé.
7. Mantém a posição controlada, a respiração livre e o pé relaxado; reduz de imediato a amplitude se a sensação mudar para dor ou sintomas elétricos.
8. Para sair, conduz o tronco de volta com a anca, regressa à vertical sem impulso e só depois reorganiza as pernas.

## Fases do movimento

### Organização

Bacia estável, uma perna estendida, outra dobrada, tronco alto e alinhamento confirmado.

### Entrada

Inclinação lenta a partir da anca, sem arredondar deliberadamente a lombar nem puxar o pé.

### Posição controlada

Tensão muscular tolerável, respiração contínua, joelho e pé alinhados e capacidade de recuar preservada.

### Saída

Regresso do tronco à vertical através da anca, sem ressalto nem impulso.

## Respiração

Expira suavemente ao iniciar a inclinação e continua a respirar de forma natural, calma e contínua enquanto permaneces na posição. Não prendas a respiração e não uses contagens respiratórias para forçar mais amplitude.

## Sensações esperadas

1. Tensão muscular gradual e tolerável na parte posterior da coxa da perna estendida.
2. Possível tensão leve na parte superior da barriga da perna, sobretudo se o tornozelo estiver menos descontraído.
3. Sensação de trabalho postural ligeiro no tronco para manter a inclinação controlada.
4. Capacidade de respirar, falar e regressar à vertical sem esforço brusco.

## Sensações inesperadas ou de alerta

1. Dor aguda, crescente ou localizada de forma intensa atrás do joelho.
2. Formigueiro, dormência, ardor, sensação elétrica ou dor que percorre a perna.
3. Fraqueza súbita, perda de controlo ou incapacidade de regressar à posição inicial.
4. Dor lombar crescente, tontura, náusea ou outro mal-estar.
5. Sensação de escorregamento ou instabilidade da superfície.

## Indicações técnicas principais

1. Apoia a bacia de forma estável.
2. Mantém o joelho estendido sem o bloquear agressivamente.
3. Inclina-te a partir da anca, não apenas da lombar.
4. Mantém o pé e o joelho alinhados e o tornozelo descontraído.
5. Respira de forma livre e contínua.
6. Procura tensão muscular tolerável, nunca dor ou sensação elétrica.

## Erros comuns e correções

### Erro 1: Arredondar a lombar para ganhar alcance.

- Como reconhecer: O peito fecha, a cabeça cai e a bacia quase não avança, apesar de as mãos chegarem mais longe.
- Como corrigir: Volta à vertical, alonga o tronco e reinicia com uma inclinação menor a partir da anca.

### Erro 2: Bloquear o joelho com força.

- Como reconhecer: Surge pressão marcada atrás do joelho ou a pessoa empurra a parte posterior da articulação contra a superfície.
- Como corrigir: Mantém a perna longa, mas retira o bloqueio agressivo e reduz a inclinação.

### Erro 3: Puxar o pé ou os dedos para aproximar o tronco.

- Como reconhecer: As mãos agarram o pé, os ombros ficam tensos e a sensação pode deslocar-se para a barriga da perna ou tornar-se elétrica.
- Como corrigir: Pousa as mãos sem tração, relaxa o tornozelo e deixa a amplitude vir apenas da inclinação controlada.

### Erro 4: Rodar a bacia ou o joelho da perna estendida.

- Como reconhecer: O joelho e os dedos do pé deixam de apontar na mesma direção, ou um lado da bacia avança mais do que o outro.
- Como corrigir: Reduz a amplitude e realinha o joelho, o pé e o tronco sobre a perna-alvo.

### Erro 5: Fazer ressalto para tentar chegar mais longe.

- Como reconhecer: O tronco oscila repetidamente e a tensão aparece de forma brusca.
- Como corrigir: Imobiliza o tronco numa posição confortável ou regressa à vertical; usa apenas movimento lento e controlado.

### Erro 6: Prender a respiração.

- Como reconhecer: A garganta fecha, os ombros sobem ou torna-se difícil falar com naturalidade.
- Como corrigir: Recua ligeiramente e retoma uma respiração calma e contínua antes de manter a posição.

### Erro 7: Tratar formigueiro ou sensação elétrica como alongamento normal.

- Como reconhecer: A sensação queima, pica, adormece ou percorre a perna em vez de permanecer como tensão muscular difusa na coxa.
- Como corrigir: Interrompe a posição e regressa com controlo; não tentes ultrapassar essa sensação.

## Formas de simplificar ou ensaiar

1. Usa uma inclinação muito pequena e mantém as mãos perto da coxa, sem procurar o pé.
2. Mantém o joelho estendido, mas sem o pressionar para uma extensão rígida.
3. Escolhe a colocação da perna dobrada que permita à bacia ficar estável e confortável.
4. Se o tornozelo aumentar a tensão na barriga da perna ou provocar sintomas incomuns, deixa o pé mais descontraído.
5. Se não consegues distinguir a inclinação da anca do arredondamento lombar, pratica apenas a organização sentada e o início do movimento com orientação qualificada.

## Supervisão

A supervisão não é necessária na execução geral deste exercício de baixo risco quando a pessoa compreende as instruções, controla a entrada e a saída e não apresenta sinais de alerta. Procura orientação qualificada se não conseguires organizar a posição, se for a primeira exposição e houver dificuldade em compreender o movimento, se existir historial relevante que altere a elegibilidade, ou se estiveres a regressar após lesão ou cirurgia. Não é necessário parceiro nem observador de segurança.

## Como terminar

Reduz a inclinação e conduz o tronco à vertical a partir da anca. Confirma que estás estável, dobra com suavidade a perna estendida e reorganiza as pernas sem torção ou impulso.

## Nota de segurança

Mantém sempre uma amplitude que permita respirar e regressar com controlo. Reduz ou interrompe perante dor lombar crescente, dor aguda, pressão marcada atrás do joelho, sensação elétrica, formigueiro, dormência, fraqueza súbita, instabilidade ou mal-estar.

## Quando parar ou reduzir

1. Dor aguda ou crescente — Reduz imediatamente a inclinação; se não desaparecer, sai da posição com controlo.
2. Formigueiro, dormência, ardor ou sensação elétrica — Interrompe a posição; estes sinais não são o objetivo do exercício.
3. Pressão marcada atrás do joelho — Retira o bloqueio agressivo do joelho, reduz a amplitude e sai se a pressão persistir.
4. Fraqueza súbita, perda de controlo, instabilidade ou mal-estar — Termina o exercício e adota uma posição sentada estável.

## Segurança do equipamento

Sem equipamento obrigatório e sem assistência externa. Um tapete é apenas opcional; não uses correias, pesos ou outra pessoa para aumentar a inclinação. Se houver tapete, confirma que está plano e não desliza.

## Segurança do espaço

Usa uma superfície firme, estável e antiderrapante, com espaço livre para sentar, estender a perna e regressar à vertical. Não executes em piso escorregadio ou instável, em apoio inseguro, junto de trânsito ativo ou quando o frio altera claramente o conforto e o controlo.

## Limitações

1. As fontes externas não validam palavra por palavra este conteúdo nem representam todas as populações que podem necessitar de adaptação.
2. A literatura consultada apoia sobretudo a família mecânica e os limites de segurança; não demonstra um resultado individual para esta variante.
3. Tensão muscular e sintomas neurais não podem ser distinguidos de forma diagnóstica por texto; a orientação pública limita-se a interromper perante sinais de alerta.
4. Não foram incorporadas alegações de prevenção, recuperação, tratamento, superioridade, dose ou utilização universal.
5. A aprovação de conteúdo não aprova imagem, vídeo, código ou publicação.

## Teste de compreensão

### 1. Em que tipo de superfície deves fazer o exercício?

Resposta esperada: Numa superfície firme, estável e antiderrapante, sem obstáculos nem trânsito ativo.

### 2. É obrigatório usar equipamento?

Resposta esperada: Não. Um tapete de exercício é opcional e serve apenas para conforto.

### 3. Como ficam as pernas na posição inicial?

Resposta esperada: Uma perna fica estendida e alinhada; a outra fica dobrada e apoiada de forma confortável.

### 4. De onde deve nascer a inclinação para a frente?

Resposta esperada: Da anca, com a bacia e o tronco a avançarem de forma controlada.

### 5. Deves bloquear o joelho da perna estendida com força?

Resposta esperada: Não. O joelho mantém-se estendido, mas sem bloqueio agressivo nem pressão marcada atrás da articulação.

### 6. O que deves fazer com o pé da perna estendida?

Resposta esperada: Mantê-lo alinhado e descontraído, sem o puxar agressivamente.

### 7. Como deves respirar?

Resposta esperada: Expirar suavemente ao iniciar a inclinação e continuar a respirar de forma natural e contínua, sem prender a respiração.

### 8. Qual é a sensação esperada?

Resposta esperada: Tensão muscular gradual e tolerável, sobretudo na parte posterior da coxa.

### 9. Que sensações exigem que interrompas?

Resposta esperada: Dor aguda ou crescente, formigueiro, dormência, ardor, sensação elétrica, fraqueza súbita, instabilidade ou mal-estar.

### 10. É necessário alcançar ou agarrar o pé?

Resposta esperada: Não. O alcance das mãos não define o exercício e não se deve criar tração externa.

### 11. Como sais da posição?

Resposta esperada: Reduzes a inclinação e conduzes o tronco à vertical a partir da anca, sem impulso, antes de reorganizar as pernas.

### 12. Quando pode ser útil orientação qualificada?

Resposta esperada: Quando não consegues organizar ou compreender a posição, quando existe historial ou sintoma relevante, ou no regresso após lesão ou cirurgia.

## Fontes e limites da evidência

### Fonte 1: EveFit — Especificação Canónica de Classificação de Exercícios v0.1

- Autor ou entidade: D1-CAN-01 — fonte canónica interna — EveFit — Especificação Canónica de Classificação de Exercícios v0.1 — Preservação da identidade, separação entre exercício e prescrição e requisitos do registo.
- Tipo: fonte canónica interna
- Localizador: D1-CAN-01 — fonte canónica interna — EveFit — Especificação Canónica de Classificação de Exercícios v0.1 — Preservação da identidade, separação entre exercício e prescrição e requisitos do registo.
- Usada para: D1-CAN-01 — fonte canónica interna — EveFit — Especificação Canónica de Classificação de Exercícios v0.1 — Preservação da identidade, separação entre exercício e prescrição e requisitos do registo.
- Limite: D1-CAN-01 — fonte canónica interna — EveFit — Especificação Canónica de Classificação de Exercícios v0.1 — Preservação da identidade, separação entre exercício e prescrição e requisitos do registo.

### Fonte 2: EveFit — Registo corretivo v0.4.1

- Autor ou entidade: D1-CAN-03 — fonte canónica interna — EveFit — Registo corretivo v0.4.1 — Preservação do identificador canónico, do risco, do equipamento e das relações aprovadas.
- Tipo: fonte canónica interna
- Localizador: D1-CAN-03 — fonte canónica interna — EveFit — Registo corretivo v0.4.1 — Preservação do identificador canónico, do risco, do equipamento e das relações aprovadas.
- Usada para: D1-CAN-03 — fonte canónica interna — EveFit — Registo corretivo v0.4.1 — Preservação do identificador canónico, do risco, do equipamento e das relações aprovadas.
- Limite: D1-CAN-03 — fonte canónica interna — EveFit — Registo corretivo v0.4.1 — Preservação do identificador canónico, do risco, do equipamento e das relações aprovadas.

### Fonte 3: Konrad et al. — Chronic effects of stretching on range of motion

- Autor ou entidade: D1-EXT-03 — revisão sistemática e meta-análise — Konrad et al. — Chronic effects of stretching on range of motion — https://pubmed.ncbi.nlm.nih.gov/37301370/ — Contexto de evidência de família; não usado para dose, resultado individual ou superioridade desta variante.
- Tipo: revisão sistemática e meta-análise
- Localizador: https://pubmed.ncbi.nlm.nih.gov/37301370/
- Usada para: D1-EXT-03 — revisão sistemática e meta-análise — Konrad et al. — Chronic effects of stretching on range of motion — https://pubmed.ncbi.nlm.nih.gov/37301370/ — Contexto de evidência de família; não usado para dose, resultado individual ou superioridade desta variante.
- Limite: D1-EXT-03 — revisão sistemática e meta-análise — Konrad et al. — Chronic effects of stretching on range of motion — https://pubmed.ncbi.nlm.nih.gov/37301370/ — Contexto de evidência de família; não usado para dose, resultado individual ou superioridade desta variante.

### Fonte 4: AAOS OrthoInfo — Flexibility Exercises for Young Athletes

- Autor ou entidade: D2-S19 — guia profissional — AAOS OrthoInfo — Flexibility Exercises for Young Athletes — https://www.orthoinfo.org/en/staying-healthy/flexibility-exercises-for-young-athletes/ — Suporte profissional para movimento controlado, ausência de ressalto e organização sentada; as indicações etárias e de dose não foram adotadas.
- Tipo: guia profissional
- Localizador: https://www.orthoinfo.org/en/staying-healthy/flexibility-exercises-for-young-athletes/
- Usada para: D2-S19 — guia profissional — AAOS OrthoInfo — Flexibility Exercises for Young Athletes — https://www.orthoinfo.org/en/staying-healthy/flexibility-exercises-for-young-athletes/ — Suporte profissional para movimento controlado, ausência de ressalto e organização sentada; as indicações etárias e de dose não foram adotadas.
- Limite: D2-S19 — guia profissional — AAOS OrthoInfo — Flexibility Exercises for Young Athletes — https://www.orthoinfo.org/en/staying-healthy/flexibility-exercises-for-young-athletes/ — Suporte profissional para movimento controlado, ausência de ressalto e organização sentada; as indicações etárias e de dose não foram adotadas.

### Fonte 5: AAOS OrthoInfo — Warm Up, Cool Down and Be Flexible

- Autor ou entidade: D2-S20 — guia profissional revisto por pares — AAOS OrthoInfo — Warm Up, Cool Down and Be Flexible — https://www.orthoinfo.org/en/staying-healthy/warm-up-cool-down-and-be-flexible/ — Fonte diretamente compatível com a variante unilateral: uma perna estendida, outra dobrada, inclinação a partir da anca, tornozelo e dedos descontraídos, movimento lento e respiração sem tensão.
- Tipo: guia profissional revisto por pares
- Localizador: https://www.orthoinfo.org/en/staying-healthy/warm-up-cool-down-and-be-flexible/
- Usada para: D2-S20 — guia profissional revisto por pares — AAOS OrthoInfo — Warm Up, Cool Down and Be Flexible — https://www.orthoinfo.org/en/staying-healthy/warm-up-cool-down-and-be-flexible/ — Fonte diretamente compatível com a variante unilateral: uma perna estendida, outra dobrada, inclinação a partir da anca, tornozelo e dedos descontraídos, movimento lento e respiração sem tensão.
- Limite: D2-S20 — guia profissional revisto por pares — AAOS OrthoInfo — Warm Up, Cool Down and Be Flexible — https://www.orthoinfo.org/en/staying-healthy/warm-up-cool-down-and-be-flexible/ — Fonte diretamente compatível com a variante unilateral: uma perna estendida, outra dobrada, inclinação a partir da anca, tornozelo e dedos descontraídos, movimento lento e respiração sem tensão.

### Fonte 6: American Council on Exercise — Seated Toe Touches

- Autor ou entidade: EX31-EXT-01 — biblioteca profissional de exercício — American Council on Exercise — Seated Toe Touches — https://www.acefitness.org/resources/everyone/exercise-library/213/seated-toe-touches/ — Suporte independente para alinhamento inicial, expiração suave, inclinação a partir da anca, controlo da coluna, tensão sem dor e ausência de ressalto; a fonte é bilateral e foi usada apenas para mecânica partilhada.
- Tipo: biblioteca profissional de exercício
- Localizador: https://www.acefitness.org/resources/everyone/exercise-library/213/seated-toe-touches/
- Usada para: EX31-EXT-01 — biblioteca profissional de exercício — American Council on Exercise — Seated Toe Touches — https://www.acefitness.org/resources/everyone/exercise-library/213/seated-toe-touches/ — Suporte independente para alinhamento inicial, expiração suave, inclinação a partir da anca, controlo da coluna, tensão sem dor e ausência de ressalto; a fonte é bilateral e foi usada apenas para mecânica partilhada.
- Limite: EX31-EXT-01 — biblioteca profissional de exercício — American Council on Exercise — Seated Toe Touches — https://www.acefitness.org/resources/everyone/exercise-library/213/seated-toe-touches/ — Suporte independente para alinhamento inicial, expiração suave, inclinação a partir da anca, controlo da coluna, tensão sem dor e ausência de ressalto; a fonte é bilateral e foi usada apenas para mecânica partilhada.

### Fonte 7: Sullivan, Dejulia e Worrell — Effect of pelvic position and stretching method on hamstring muscle flexibility

- Autor ou entidade: EX31-PRI-01 — estudo primário — Sullivan, Dejulia e Worrell — Effect of pelvic position and stretching method on hamstring muscle flexibility — https://europepmc.org/article/MED/1470022 — Suporte biomecânico para dar prioridade à organização pélvica e à inclinação pela anca; o estudo não avaliou este guião exato nem autoriza promessas.
- Tipo: estudo primário
- Localizador: https://europepmc.org/article/MED/1470022
- Usada para: EX31-PRI-01 — estudo primário — Sullivan, Dejulia e Worrell — Effect of pelvic position and stretching method on hamstring muscle flexibility — https://europepmc.org/article/MED/1470022 — Suporte biomecânico para dar prioridade à organização pélvica e à inclinação pela anca; o estudo não avaliou este guião exato nem autoriza promessas.
- Limite: EX31-PRI-01 — estudo primário — Sullivan, Dejulia e Worrell — Effect of pelvic position and stretching method on hamstring muscle flexibility — https://europepmc.org/article/MED/1470022 — Suporte biomecânico para dar prioridade à organização pélvica e à inclinação pela anca; o estudo não avaliou este guião exato nem autoriza promessas.

### Fonte 8: López-de-Celis et al. — Short-Term Effects of Three Types of Hamstring Stretching on Length, Neurodynamic Response, and Perceived Sense of Effort

- Autor ou entidade: EX31-PRI-02 — ensaio cruzado aleatorizado — López-de-Celis et al. — Short-Term Effects of Three Types of Hamstring Stretching on Length, Neurodynamic Response, and Perceived Sense of Effort — https://pubmed.ncbi.nlm.nih.gov/36295102/ — Mostra que técnicas de alongamento dos isquiotibiais podem produzir respostas neurais, sobretudo com carga neural adicional; sustenta linguagem conservadora sobre tornozelo relaxado e interrupção perante sintomas neurais, sem diagnóstico.
- Tipo: ensaio cruzado aleatorizado
- Localizador: https://pubmed.ncbi.nlm.nih.gov/36295102/
- Usada para: EX31-PRI-02 — ensaio cruzado aleatorizado — López-de-Celis et al. — Short-Term Effects of Three Types of Hamstring Stretching on Length, Neurodynamic Response, and Perceived Sense of Effort — https://pubmed.ncbi.nlm.nih.gov/36295102/ — Mostra que técnicas de alongamento dos isquiotibiais podem produzir respostas neurais, sobretudo com carga neural adicional; sustenta linguagem conservadora sobre tornozelo relaxado e interrupção perante sintomas neurais, sem diagnóstico.
- Limite: EX31-PRI-02 — ensaio cruzado aleatorizado — López-de-Celis et al. — Short-Term Effects of Three Types of Hamstring Stretching on Length, Neurodynamic Response, and Perceived Sense of Effort — https://pubmed.ncbi.nlm.nih.gov/36295102/ — Mostra que técnicas de alongamento dos isquiotibiais podem produzir respostas neurais, sobretudo com carga neural adicional; sustenta linguagem conservadora sobre tornozelo relaxado e interrupção perante sintomas neurais, sem diagnóstico.
