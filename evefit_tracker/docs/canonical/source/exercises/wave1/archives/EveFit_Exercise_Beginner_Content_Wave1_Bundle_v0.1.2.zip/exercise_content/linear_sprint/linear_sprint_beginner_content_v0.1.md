# Sprint linear

Conteúdo para principiantes em português europeu.

## Descrição curta

Corrida linear com mecânica de sprint e apoios alternados.

## O que é

O sprint linear é uma corrida para a frente, em linha reta, com apoios alternados e fases de voo. O corpo aplica força ao solo para acelerar e continuar a deslocar-se, mantendo braços e pernas coordenados. A distância, a velocidade concreta e a duração não fazem parte desta definição.

## O que vais fazer

Partir de uma posição em pé, estável e assimétrica; projetar o corpo para a frente; alternar apoios rápidos com coordenação do lado oposto dos braços; elevar gradualmente o tronco à medida que a corrida se organiza; e terminar numa zona livre, reduzindo a velocidade de forma progressiva e em linha reta.

## Porque existe este movimento

Esta ação existe para executar e organizar a mecânica cíclica da locomoção de sprint. Pode integrar contextos de velocidade locomotora e aceleração inicial, mas a descrição técnica não promete resultados nem define como deve ser usada numa sessão.

## Antes de começares

1. Não inicies sozinho na primeira exposição. Um treinador de atletismo ou profissional qualificado deve observar a partida, o corredor e a travagem.
2. Confirma que compreendes o sinal para não começar e o sinal para interromper a tarefa.
3. Confirma que consegues correr para a frente e reduzir a velocidade com controlo numa tarefa antecedente escolhida pelo supervisor.
4. Verifica se não existe dor aguda, mal-estar, perda de coordenação ou outra sensação que torne inseguro começar.
5. Percorre visualmente toda a trajetória, incluindo a zona de travagem, antes de assumir a posição inicial.

## Preparar o equipamento

1. Não há equipamento obrigatório. Podem usar-se marcadores de distância opcionais para tornar visíveis o corredor e a zona de travagem; devem ficar estáveis, bem visíveis e fora da linha de passada.

## Preparar o espaço

1. Escolhe uma pista de atletismo, pavilhão desportivo ou campo com corredor linear desimpedido.
2. Usa apenas uma superfície firme, regular e antiderrapante.
3. Reserva, depois da zona de corrida, espaço livre suficiente para uma desaceleração progressiva.
4. Exclui trânsito ativo, cruzamentos públicos não controlados, obstáculos, piso escorregadio ou instável, iluminação insuficiente e qualquer pessoa a atravessar a trajetória.
5. Mantém visíveis o início, o percurso e o fim da zona de travagem.

## Verificação do corpo

1. Consegues manter-te de pé com uma base assimétrica sem perder o equilíbrio.
2. Consegues alternar braços e pernas enquanto corres para a frente.
3. Consegues reduzir a velocidade progressivamente sem paragem brusca nem mudança repentina de direção.
4. Compreendes e consegues cumprir imediatamente uma indicação do supervisor para não começar ou parar.
5. Não tens dor aguda, mal-estar ou perda súbita de coordenação antes de iniciares.

## Posição inicial

Fica em pé, voltado para o corredor, com um pé ligeiramente à frente do outro e o peso distribuído de forma estável. Mantém cabeça, tronco e bacia organizados, braços preparados para alternar com as pernas e olhar dirigido para a trajetória livre. Esta posição em pé não é uma saída de blocos.

## Confirmar a posição inicial

1. Corpo orientado para a frente e dentro do corredor.
2. Base assimétrica estável, sem cruzar os pés.
3. Tronco e bacia alinhados, sem dobrar apenas pela cintura.
4. Braço oposto à perna da frente preparado para avançar.
5. Corredor e zona de travagem totalmente livres.
6. Supervisor em posição de observar e dar o sinal.

## Passos de execução

1. Aguarda o sinal do supervisor e confirma uma última vez que ninguém entrou no corredor ou na zona de travagem.
2. Inclina o corpo para a frente como uma unidade, a partir dos tornozelos, sem fechar o tronco pela cintura, e inicia a deslocação com ação coordenada de braços e pernas.
3. Empurra o solo para trás e para baixo nos primeiros apoios, mantendo cabeça e tronco na mesma linha geral e os passos inicialmente organizados sob o corpo.
4. Alterna os apoios e a fase de voo; deixa o braço oposto à perna avançar e evita que as mãos atravessem marcadamente a linha média do tronco.
5. À medida que aceleras, eleva gradualmente o corpo até uma posição de sprint mais alta, sem te endireitares de repente nem inclinares para trás.
6. Mantém a passada a acontecer à frente e debaixo do corpo, sem alcançar deliberadamente o solo com o pé muito à frente da bacia.
7. Antes do limite do corredor, deixa de procurar acelerar e começa a reduzir a velocidade em linha reta, usando passos progressivamente mais controlados.
8. Continua dentro da zona de travagem, com flexão coordenada de tornozelos, joelhos e ancas para absorver a travagem, até recuperares uma marcha estável; só depois sai do corredor.

## Fases do movimento

### Preparação

Base assimétrica estável, corpo orientado para a frente, trajetória verificada e atenção ao sinal do supervisor.

### Aceleração

Inclinação global para a frente, aplicação de força ao solo e elevação gradual do tronco à medida que os apoios se sucedem.

### Locomoção cíclica

Apoios alternados, fases de voo, coordenação do lado oposto de braços e pernas e postura organizada.

### Desaceleração

Redução progressiva da velocidade em linha reta, com apoios controlados e flexão coordenada dos membros inferiores para gerir a travagem.

### Saída segura

Transição para marcha estável e abandono do corredor apenas depois de o corpo estar sob controlo.

## Respiração

Respira de forma natural e contínua durante a partida, a corrida e a desaceleração. Não prendas voluntariamente a respiração e não imponhas uma contagem de passos por inspiração ou expiração. A literatura sobre acoplamento entre passada e respiração mostra variabilidade entre pessoas e velocidades; não sustenta uma cadência respiratória universal para este conteúdo de iniciação.

## Sensações esperadas

1. Aumento rápido do esforço global e da ventilação.
2. Contactos breves e firmes com o solo, alternados com pequenas fases de voo.
3. Ação coordenada de braços e pernas.
4. Maior solicitação das ancas, coxas, gémeos e tornozelos.
5. Sensação de o corpo se elevar gradualmente durante a aceleração e de absorver carga ao desacelerar.

## Sensações inesperadas ou de alerta

1. Dor aguda ou súbita em qualquer região.
2. Mal-estar, tontura, visão alterada, falta de ar desproporcionada ou sensação de desmaio.
3. Perda súbita de coordenação, tropeção repetida ou instabilidade.
4. Sensação de não conseguir manter a trajetória linear.
5. Incapacidade de reduzir a velocidade dentro da zona livre com controlo.

## Indicações técnicas principais

1. Corredor e zona de travagem livres antes de partir.
2. Inclina o corpo a partir dos tornozelos; não dobres apenas a cintura.
3. Empurra o solo para trás e para baixo sem alongar artificialmente a passada.
4. Braço e perna opostos trabalham em conjunto.
5. Sobe gradualmente para uma postura mais alta.
6. Reduz a velocidade cedo, em linha reta e sem paragem brusca.

## Erros comuns e correções

### Erro 1: Começar sem confirmar uma zona de travagem livre.

- Como reconhecer: O fim do corredor está próximo de uma parede, obstáculo, pessoa ou cruzamento, ou não é possível ver onde termina a desaceleração.
- Como corrigir: Não iniciar. O supervisor deve redefinir e verificar um corredor linear com zona de travagem desimpedida.

### Erro 2: Dobrar o tronco pela cintura na partida.

- Como reconhecer: A bacia fica para trás enquanto o peito cai para a frente, quebrando a linha geral entre cabeça, tronco e perna de apoio.
- Como corrigir: Reorganizar a posição inicial e inclinar o corpo como uma unidade a partir dos tornozelos, sob observação do supervisor.

### Erro 3: Procurar uma passada demasiado longa.

- Como reconhecer: O pé procura o chão muito à frente da bacia, o contacto parece de travagem e o ritmo perde continuidade.
- Como corrigir: Deixar o passo acontecer mais perto do corpo e pensar em aplicar força ao solo, sem tentar alcançar distância com o pé.

### Erro 4: Cruzar excessivamente os braços à frente do tronco.

- Como reconhecer: As mãos passam repetidamente para o lado oposto da linha média e os ombros rodam de forma marcada.
- Como corrigir: Dirigir os braços sobretudo para a frente e para trás, com ombros estáveis e mãos descontraídas.

### Erro 5: Endireitar o corpo de forma abrupta durante a aceleração.

- Como reconhecer: O tronco passa de inclinado para vertical num único momento e os passos perdem continuidade.
- Como corrigir: Permitir que cabeça e tronco se elevem gradualmente à medida que a velocidade aumenta.

### Erro 6: Parar bruscamente ou mudar de direção no fim.

- Como reconhecer: A pessoa trava num único apoio, salta, roda ou sai lateralmente ainda com velocidade.
- Como corrigir: Começar a reduzir a velocidade antes, continuar em linha reta e usar toda a zona livre até chegar a uma marcha estável.

## Formas de simplificar ou ensaiar

1. Usar uma partida em pé e estável, sem blocos nem equipamento especializado.
2. Rever primeiro, com o supervisor, a trajetória e a forma de terminar; essa revisão não é o sprint.
3. Ensaiar separadamente a posição inicial, a alternância dos braços e uma desaceleração controlada numa tarefa antecedente escolhida pelo profissional.
4. Parar a preparação se o controlo da corrida ou da travagem ainda não for observável; a simplificação não transforma o sprint de risco alto numa tarefa autónoma.

## Supervisão

A supervisão é recomendada para este exercício de risco operacional alto e é necessária na primeira exposição técnica de um principiante. O supervisor deve ser um treinador de atletismo ou profissional qualificado capaz de verificar prontidão, superfície, espaço, trajetória, técnica de aceleração e controlo da travagem; deve também manter terceiros fora do corredor e poder cancelar a partida. Uma explicação escrita ou um vídeo não substituem esta observação presencial.

## Como terminar

Deixa de procurar aumentar a velocidade antes de chegar ao limite do corredor. Mantém a trajetória em linha reta e reduz a velocidade ao longo de vários apoios controlados, sem fixar um número. Permite flexão coordenada de tornozelos, joelhos e ancas para gerir a travagem, sem colapsar o tronco. Passa para marcha estável dentro da zona livre. Sai do corredor apenas quando tens controlo e confirma ao supervisor qualquer sinal de alerta.

## Nota de segurança

O sprint linear tem risco operacional alto por combinar forças de reação do solo elevadas, carga rápida dos tecidos, fase aérea, contactos repetidos e possibilidade de perda de controlo à velocidade. Interrompe perante dor aguda, mal-estar, perda súbita de coordenação ou incapacidade de controlar a trajetória ou a travagem. Não comeces se o espaço, a superfície, a visibilidade ou a supervisão forem inadequados.

## Quando parar ou reduzir

1. Dor aguda.
2. Mal-estar.
3. Perda súbita de coordenação.
4. Incapacidade de controlar a travagem ou a receção de cada apoio.
5. Para perante este sinal de alerta: Dor aguda ou súbita em qualquer região.
6. Para perante este sinal de alerta: Mal-estar, tontura, visão alterada, falta de ar desproporcionada ou sensação de desmaio.
7. Para perante este sinal de alerta: Perda súbita de coordenação, tropeção repetida ou instabilidade.
8. Para perante este sinal de alerta: Sensação de não conseguir manter a trajetória linear.
9. Para perante este sinal de alerta: Incapacidade de reduzir a velocidade dentro da zona livre com controlo.

## Segurança do equipamento

Sem equipamento obrigatório. Se forem usados marcadores opcionais, coloca-os de modo estável e fora da linha de passada; não uses obstáculos altos, elásticos, trenós, blocos ou outro equipamento especializado como parte desta explicação de iniciação.

## Segurança do espaço

Usa apenas uma superfície firme, regular e antiderrapante, com iluminação suficiente, corredor linear desimpedido e zona de travagem livre. Não executar junto de trânsito ativo, cruzamentos públicos não controlados, paredes próximas, piso molhado, solto ou irregular, nem com pessoas a poderem entrar na trajetória.

## Limitações

1. Este conteúdo explica a tarefa; não avalia prontidão individual nem autoriza execução autónoma no primeiro dia.
2. Não define distância, duração, velocidade, intensidade, volume, recuperação ou progressão.
3. Não diagnostica, trata nem substitui avaliação clínica ou profissional quando necessária.
4. A investigação consultada inclui sobretudo adultos fisicamente ativos, corredores experientes ou atletas; a transferência para principiantes é prudente e limitada.
5. Não existe aqui uma dimensão universal para a zona de travagem: deve ser validada no local pelo supervisor.
6. Não é imposta uma cadência respiratória porque a evidência não sustenta uma regra universal de iniciação.
7. Implementação realizada: não

## Teste de compreensão

### 1. Podes fazer o teu primeiro sprint sozinho depois de leres esta explicação?

Resposta esperada: Não. A primeira exposição exige supervisão presencial por um treinador de atletismo ou profissional qualificado.

### 2. O que deves confirmar antes de assumir a posição inicial?

Resposta esperada: Que o corredor e toda a zona de travagem estão livres, visíveis e em superfície adequada.

### 3. De onde deve partir a inclinação inicial do corpo?

Resposta esperada: Dos tornozelos, mantendo o corpo organizado como uma unidade, e não dobrando apenas a cintura.

### 4. Deves tentar chegar mais longe colocando o pé muito à frente da bacia?

Resposta esperada: Não. Isso pode criar uma passada demasiado longa e maior travagem no contacto.

### 5. Como trabalham braços e pernas?

Resposta esperada: Alternam de forma do lado oposto: o braço oposto acompanha a perna que avança.

### 6. O tronco deve ficar alto de repente depois dos primeiros apoios?

Resposta esperada: Não. Deve elevar-se gradualmente à medida que a aceleração se organiza.

### 7. Qual é a orientação respiratória principal?

Resposta esperada: Respirar naturalmente e de forma contínua, sem retenção voluntária nem contagem imposta.

### 8. Quando começa a travagem segura?

Resposta esperada: Antes do limite do corredor, deixando de acelerar e reduzindo progressivamente a velocidade.

### 9. É adequado parar num único apoio ou virar de repente no fim?

Resposta esperada: Não. A desaceleração deve continuar em linha reta até chegar a uma marcha estável.

### 10. Que articulações ajudam a gerir a travagem?

Resposta esperada: Tornozelos, joelhos e ancas, através de flexão coordenada.

### 11. Que sinais obrigam a interromper ou não reiniciar sem revisão?

Resposta esperada: Dor aguda, mal-estar, perda súbita de coordenação ou incapacidade de controlar a travagem ou cada apoio.

### 12. Os marcadores opcionais tornam, por si sós, o espaço seguro?

Resposta esperada: Não. O supervisor tem de verificar a superfície, a trajetória, a visibilidade, os atravessamentos e toda a zona de travagem.

## Fontes e limites da evidência

### Fonte 1: World Athletics. The Sprints.

- Autor ou entidade: B1-S01 — World Athletics. The Sprints. — revisão técnica de federação internacional — https://worldathletics.org/download/downloadnsa?filename=f411d6b2-f0be-456f-b969-28abad2159ce.pdf&urlslug=the-sprints — Enquadramento técnico das fases de aceleração e corrida de velocidade e dos exercícios técnicos específicos. — Recurso técnico, não ensaio de segurança em principiantes.
- Tipo: revisão técnica de federação internacional
- Localizador: https://worldathletics.org/download/downloadnsa?filename=f411d6b2-f0be-456f-b969-28abad2159ce.pdf&urlslug=the-sprints
- Usada para: B1-S01 — World Athletics. The Sprints. — revisão técnica de federação internacional — https://worldathletics.org/download/downloadnsa?filename=f411d6b2-f0be-456f-b969-28abad2159ce.pdf&urlslug=the-sprints — Enquadramento técnico das fases de aceleração e corrida de velocidade e dos exercícios técnicos específicos. — Recurso técnico, não ensaio de segurança em principiantes.
- Limite: Recurso técnico, não ensaio de segurança em principiantes.

### Fonte 2: Bezodis, N. E., Willwacher, S., e Salo, A. I. T. The Biomechanics of the Track and Field Sprint Start: A Narrative Review.

- Autor ou entidade: B1-S12 — Bezodis, N. E., Willwacher, S., e Salo, A. I. T. The Biomechanics of the Track and Field Sprint Start: A Narrative Review. — revisão científica — https://pubmed.ncbi.nlm.nih.gov/31209732/ — Sustenta a distinção entre a saída delimitada e a locomoção cíclica de sprint. — Foca a saída de sprint, não a execução pública integral por principiantes.
- Tipo: revisão científica
- Localizador: https://pubmed.ncbi.nlm.nih.gov/31209732/
- Usada para: B1-S12 — Bezodis, N. E., Willwacher, S., e Salo, A. I. T. The Biomechanics of the Track and Field Sprint Start: A Narrative Review. — revisão científica — https://pubmed.ncbi.nlm.nih.gov/31209732/ — Sustenta a distinção entre a saída delimitada e a locomoção cíclica de sprint. — Foca a saída de sprint, não a execução pública integral por principiantes.
- Limite: Foca a saída de sprint, não a execução pública integral por principiantes.

### Fonte 3: Haugen, T. et al. The Training and Development of Elite Sprint Performance: an Integration of Scientific and Best Practice Literature.

- Autor ou entidade: SP-B2-S16 — Haugen, T. et al. The Training and Development of Elite Sprint Performance: an Integration of Scientific and Best Practice Literature. — revisão científica e de prática profissional — https://doi.org/10.1186/s40798-019-0221-0 — Contextualiza aceleração, velocidade máxima, técnica e exigências do sprint. — Centra-se sobretudo no desenvolvimento de desempenho de atletas treinados.
- Tipo: revisão científica e de prática profissional
- Localizador: https://doi.org/10.1186/s40798-019-0221-0
- Usada para: SP-B2-S16 — Haugen, T. et al. The Training and Development of Elite Sprint Performance: an Integration of Scientific and Best Practice Literature. — revisão científica e de prática profissional — https://doi.org/10.1186/s40798-019-0221-0 — Contextualiza aceleração, velocidade máxima, técnica e exigências do sprint. — Centra-se sobretudo no desenvolvimento de desempenho de atletas treinados.
- Limite: Centra-se sobretudo no desenvolvimento de desempenho de atletas treinados.

### Fonte 4: Athletics Ireland. AAi Coach Sprints Manual.

- Autor ou entidade: EX19-S01 — Athletics Ireland. AAi Coach Sprints Manual. — manual oficial de treinador de federação nacional — https://www.athleticsireland.ie/wp-content/uploads/2024/10/AAI-Coach_Sprints_Manual.pdf — Apoia os pontos de postura, elevação gradual na aceleração, coordenação dos braços, posição do pé e erros técnicos comuns. — Material de formação de treinadores; alguns exemplos do manual contêm doses que não foram transferidas para este conteúdo.
- Tipo: manual oficial de treinador de federação nacional
- Localizador: https://www.athleticsireland.ie/wp-content/uploads/2024/10/AAI-Coach_Sprints_Manual.pdf
- Usada para: EX19-S01 — Athletics Ireland. AAi Coach Sprints Manual. — manual oficial de treinador de federação nacional — https://www.athleticsireland.ie/wp-content/uploads/2024/10/AAI-Coach_Sprints_Manual.pdf — Apoia os pontos de postura, elevação gradual na aceleração, coordenação dos braços, posição do pé e erros técnicos comuns. — Material de formação de treinadores; alguns exemplos do manual contêm doses que não foram transferidas para este conteúdo.
- Limite: Material de formação de treinadores; alguns exemplos do manual contêm doses que não foram transferidas para este conteúdo.

### Fonte 5: National Strength and Conditioning Association. Acceleration and Deceleration Mechanics; e Effective Deceleration Technique for Court and Field Sports.

- Autor ou entidade: EX19-S02 — National Strength and Conditioning Association. Acceleration and Deceleration Mechanics; e Effective Deceleration Technique for Court and Field Sports. — orientação profissional — https://www.nsca.com/education/articles/kinetic-select/acceleration-and-deceleration-mechanics/ — Apoia a inclinação global na aceleração, a ação dos braços e a travagem por flexão coordenada do tornozelo, joelho e anca. — A orientação de desaceleração inclui contextos de mudança de direção; aqui foi usada apenas para a travagem linear.
- Tipo: orientação profissional
- Localizador: https://www.nsca.com/education/articles/kinetic-select/acceleration-and-deceleration-mechanics/
- Usada para: EX19-S02 — National Strength and Conditioning Association. Acceleration and Deceleration Mechanics; e Effective Deceleration Technique for Court and Field Sports. — orientação profissional — https://www.nsca.com/education/articles/kinetic-select/acceleration-and-deceleration-mechanics/ — Apoia a inclinação global na aceleração, a ação dos braços e a travagem por flexão coordenada do tornozelo, joelho e anca. — A orientação de desaceleração inclui contextos de mudança de direção; aqui foi usada apenas para a travagem linear.
- Limite: A orientação de desaceleração inclui contextos de mudança de direção; aqui foi usada apenas para a travagem linear.

### Fonte 6: Weyand, P. G., Sternlight, D. B., Bellizzi, M. J., e Wright, S. Faster top running speeds are achieved with greater ground forces not more rapid leg movements. Journal of Applied Physiology. 2000;89(5):1991-1999.

- Autor ou entidade: EX19-S03 — Weyand, P. G., Sternlight, D. B., Bellizzi, M. J., e Wright, S. Faster top running speeds are achieved with greater ground forces not more rapid leg movements. Journal of Applied Physiology. 2000;89(5):1991-1999. — estudo biomecânico primário — https://doi.org/10.1152/jappl.2000.89.5.1991 — Sustenta a importância das forças de apoio ao solo na velocidade máxima e evita reduzir o sprint a mexer as pernas mais depressa. — Amostra adulta em passadeira e condições laboratoriais; não define técnica segura individual.
- Tipo: estudo biomecânico primário
- Localizador: https://doi.org/10.1152/jappl.2000.89.5.1991
- Usada para: EX19-S03 — Weyand, P. G., Sternlight, D. B., Bellizzi, M. J., e Wright, S. Faster top running speeds are achieved with greater ground forces not more rapid leg movements. Journal of Applied Physiology. 2000;89(5):1991-1999. — estudo biomecânico primário — https://doi.org/10.1152/jappl.2000.89.5.1991 — Sustenta a importância das forças de apoio ao solo na velocidade máxima e evita reduzir o sprint a mexer as pernas mais depressa. — Amostra adulta em passadeira e condições laboratoriais; não define técnica segura individual.
- Limite: Amostra adulta em passadeira e condições laboratoriais; não define técnica segura individual.

### Fonte 7: Morin, J.-B., Edouard, P., e Samozino, P. Technical Ability of Force Application as a Determinant Factor of Sprint Performance. Medicine & Science in Sports & Exercise. 2011;43(9):1680-1688.

- Autor ou entidade: EX19-S04 — Morin, J.-B., Edouard, P., e Samozino, P. Technical Ability of Force Application as a Determinant Factor of Sprint Performance. Medicine & Science in Sports & Exercise. 2011;43(9):1680-1688. — estudo biomecânico primário — https://pubmed.ncbi.nlm.nih.gov/21364480/ — Sustenta que, durante a aceleração, a orientação da força aplicada ao solo é relevante e não apenas a sua quantidade total. — Amostra pequena de homens fisicamente ativos e foco no desempenho, não em principiantes.
- Tipo: estudo biomecânico primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/21364480/
- Usada para: EX19-S04 — Morin, J.-B., Edouard, P., e Samozino, P. Technical Ability of Force Application as a Determinant Factor of Sprint Performance. Medicine & Science in Sports & Exercise. 2011;43(9):1680-1688. — estudo biomecânico primário — https://pubmed.ncbi.nlm.nih.gov/21364480/ — Sustenta que, durante a aceleração, a orientação da força aplicada ao solo é relevante e não apenas a sua quantidade total. — Amostra pequena de homens fisicamente ativos e foco no desempenho, não em principiantes.
- Limite: Amostra pequena de homens fisicamente ativos e foco no desempenho, não em principiantes.

### Fonte 8: Schache, A. G., Dorn, T. W., Blanch, P. D., Brown, N. A. T., e Pandy, M. G. Mechanics of the human hamstring muscles during sprinting. Medicine & Science in Sports & Exercise. 2012;44(4):647-658.

- Autor ou entidade: EX19-S05 — Schache, A. G., Dorn, T. W., Blanch, P. D., Brown, N. A. T., e Pandy, M. G. Mechanics of the human hamstring muscles during sprinting. Medicine & Science in Sports & Exercise. 2012;44(4):647-658. — estudo biomecânico primário — https://pubmed.ncbi.nlm.nih.gov/21912301/ — Documenta carga musculotendinosa elevada dos isquiotibiais, sobretudo no balanço terminal, reforçando a classificação de carga rápida dos tecidos. — Sete participantes e modelação musculoesquelética; não permite prever lesão individual.
- Tipo: estudo biomecânico primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/21912301/
- Usada para: EX19-S05 — Schache, A. G., Dorn, T. W., Blanch, P. D., Brown, N. A. T., e Pandy, M. G. Mechanics of the human hamstring muscles during sprinting. Medicine & Science in Sports & Exercise. 2012;44(4):647-658. — estudo biomecânico primário — https://pubmed.ncbi.nlm.nih.gov/21912301/ — Documenta carga musculotendinosa elevada dos isquiotibiais, sobretudo no balanço terminal, reforçando a classificação de carga rápida dos tecidos. — Sete participantes e modelação musculoesquelética; não permite prever lesão individual.
- Limite: Sete participantes e modelação musculoesquelética; não permite prever lesão individual.

### Fonte 9: Dorn, T. W., Schache, A. G., e Pandy, M. G. Muscular strategy shift in human running: dependence of running speed on hip and ankle muscle performance. Journal of Experimental Biology. 2012;215:1944-1956.

- Autor ou entidade: EX19-S06 — Dorn, T. W., Schache, A. G., e Pandy, M. G. Muscular strategy shift in human running: dependence of running speed on hip and ankle muscle performance. Journal of Experimental Biology. 2012;215:1944-1956. — estudo biomecânico primário — https://doi.org/10.1242/jeb.064527 — Demonstra a coordenação muscular distinta entre apoio e balanço em velocidades elevadas e documenta, no método, a separação de uma zona de desaceleração segura. — Nove corredores experientes e modelação; a dimensão laboratorial da zona de travagem não é transferível como regra universal.
- Tipo: estudo biomecânico primário
- Localizador: https://doi.org/10.1242/jeb.064527
- Usada para: EX19-S06 — Dorn, T. W., Schache, A. G., e Pandy, M. G. Muscular strategy shift in human running: dependence of running speed on hip and ankle muscle performance. Journal of Experimental Biology. 2012;215:1944-1956. — estudo biomecânico primário — https://doi.org/10.1242/jeb.064527 — Demonstra a coordenação muscular distinta entre apoio e balanço em velocidades elevadas e documenta, no método, a separação de uma zona de desaceleração segura. — Nove corredores experientes e modelação; a dimensão laboratorial da zona de travagem não é transferível como regra universal.
- Limite: Nove corredores experientes e modelação; a dimensão laboratorial da zona de travagem não é transferível como regra universal.
