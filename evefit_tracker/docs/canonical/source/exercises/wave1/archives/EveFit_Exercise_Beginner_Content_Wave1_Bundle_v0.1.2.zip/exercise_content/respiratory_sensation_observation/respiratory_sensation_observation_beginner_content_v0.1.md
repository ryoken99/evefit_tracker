# Observação das sensações respiratórias

Conteúdo para principiantes em português europeu.

## Descrição curta

Observa as sensações da respiração tal como estão, sem tentar mudar o ciclo nem tirar conclusões clínicas.

## O que é

É uma tarefa simples de atenção interna. Escolhes uma posição estável e reparas onde sentes a respiração, como reconheces a entrada e a saída do ar, que ritmo percebes e quanto esforço parece existir. A tarefa é descrever o que está presente, não corrigir a respiração nem avaliar a tua saúde.

## O que vais fazer

Vais pousar a atenção num local onde a respiração seja percetível, acompanhar as sensações ao longo do ciclo espontâneo e reconhecer localização, fase, ritmo percebido e esforço percebido. Se a atenção se afastar, podes regressar ao mesmo ponto de forma simples. Podes terminar em qualquer momento.

## Porque existe este movimento

A tarefa existe para praticar o reconhecimento descritivo dos sinais internos do ciclo respiratório. Não serve para decidir se uma sensação é normal, explicar a sua causa ou determinar se deves fazer outra atividade.

## Antes de começares

1. Escolhe uma posição em que estejas estável e possas sair da tarefa sem ajuda. Começa apenas se a respiração estiver estável no estado atual e se compreenderes que não é necessário mudar a profundidade, o ritmo ou o percurso do ar. Se o foco na respiração costuma desencadear sofrimento intenso, ou se existem sinais novos ou sem explicação, procura primeiro orientação de um profissional de saúde qualificado.

## Preparar o equipamento

1. Não é necessário equipamento. Podes usar uma cadeira estável ou um apoio para a cabeça ou para os joelhos se isso ajudar a manter uma posição confortável. Coloca qualquer apoio antes de começares e confirma que não limita o movimento espontâneo do tronco.

## Preparar o espaço

1. Fica numa zona segura, ventilada e suficientemente calma para notares a respiração. Usa uma superfície firme e estável, sem obstáculos imediatos. Não realizes a tarefa num veículo em movimento, debaixo de água, junto de uma altura desprotegida ou sobre um apoio instável.

## Verificação do corpo

1. Confirma que estás orientado, que consegues iniciar e parar voluntariamente, que a posição é estável e que a respiração está estável no momento. Se já tens dor no peito, falta de ar invulgar, tontura, sensação de desmaio, confusão, formigueiro marcado ou pânico crescente, não inicies.

## Posição inicial

Senta-te numa cadeira estável, fica de pé com apoio seguro ou deita-te numa superfície firme, conforme a posição estável que escolheste. Deixa o corpo apoiado sem rigidez desnecessária. Mantém os olhos abertos ou fecha-os apenas se isso for confortável e seguro.

## Confirmar a posição inicial

1. A posição está estável e permite terminar a tarefa facilmente.
2. O corpo está apoiado sem comprimir o peito nem o abdómen.
3. Os ombros e a mandíbula não estão deliberadamente presos.
4. Os olhos estão abertos se fechá-los reduzir a sensação de segurança.
5. A respiração está a acontecer espontaneamente, sem ser forçada.

## Passos de execução

1. Reconhece primeiro os pontos de apoio do corpo e confirma que te sentes estável no local escolhido.
2. Leva a atenção para um local onde a respiração seja fácil de notar, como as narinas, o peito ou o abdómen, sem procurar o local «certo».
3. Nota como reconheces a entrada do ar, a transição e a saída do ar, deixando o ciclo acontecer por si.
4. Descreve mentalmente qual é a localização mais nítida e que movimento ou contacto acompanha a respiração.
5. Repara no ritmo tal como o percebes e no esforço aparente, sem tentar acelerar, abrandar, aprofundar ou suavizar.
6. Se a atenção se afastar, reconhece isso sem crítica e regressa ao mesmo sinal respiratório que escolheste.
7. Se surgir desconforto crescente, retira a atenção da respiração, orienta-te para o ambiente e termina. Caso contrário, termina quando decidires e volta a notar os apoios e o espaço à tua volta.

## Fases do movimento

### Escolher uma posição estável, reconhecer os apoios e confirmar que é possível parar voluntariamente.

Escolher uma posição estável, reconhecer os apoios e confirmar que é possível parar voluntariamente.

### Encontrar um ponto respiratório percetível nas narinas, no peito ou no abdómen.

Encontrar um ponto respiratório percetível nas narinas, no peito ou no abdómen.

### Observar entrada, transição e saída do ar sem impor um padrão.

Observar entrada, transição e saída do ar sem impor um padrão.

### Reconhecer localização, movimento, ritmo percebido e esforço percebido sem os interpretar clinicamente.

Reconhecer localização, movimento, ritmo percebido e esforço percebido sem os interpretar clinicamente.

### Notar uma distração e voltar com suavidade ao sinal respiratório escolhido.

Notar uma distração e voltar com suavidade ao sinal respiratório escolhido.

### Retirar a atenção da respiração, reconhecer os apoios e o ambiente e sair da posição com segurança.

Retirar a atenção da respiração, reconhecer os apoios e o ambiente e sair da posição com segurança.

## Respiração

Deixa a respiração acontecer naturalmente e de forma contínua. Não imponhas profundidade, ritmo, via nasal ou oral, nem pausas. A respiração é o objeto da observação, não algo que tenhas de ajustar.

## Sensações esperadas

1. Passagem do ar nas narinas ou na boca, se for aí que a sensação aparece espontaneamente.
2. Movimento discreto do peito, das costelas ou do abdómen.
3. Diferença percebida entre a entrada, a transição e a saída do ar.
4. Variações espontâneas no ritmo ou na nitidez das sensações.
5. Esforço respiratório percebido como menor, maior ou difícil de descrever, sem necessidade de o classificar como bom ou mau.
6. Momentos em que nenhuma sensação é particularmente nítida.

## Sensações inesperadas ou de alerta

1. Dor no peito.
2. Falta de ar invulgar ou que aumenta.
3. Tontura, sensação de desmaio ou desmaio.
4. Confusão ou sensação de perda de controlo.
5. Formigueiro que surge ou aumenta durante a tarefa.
6. Pânico, medo ou vigilância interna que aumentam claramente com o foco na respiração.

## Indicações técnicas principais

1. Observa o ciclo; não o corrijas.
2. Escolhe um ponto respiratório nítido e mantém a tarefa delimitada.
3. Descreve localização, fase, ritmo percebido e esforço percebido sem procurar uma resposta certa.
4. Deixa o corpo respirar por si, sem impor profundidade nem velocidade.
5. Se o foco interno aumentar muito o desconforto, orienta-te para o exterior e termina.

## Erros comuns e correções

### Erro 1: Tornar a respiração propositadamente mais funda, lenta ou regular.

- Como reconhecer: Sentes que estás a fabricar cada ciclo ou a tentar fazer a respiração corresponder a uma ideia de «boa respiração».
- Como corrigir: Liberta a tentativa de controlo e observa o ciclo que aparece espontaneamente. Se não conseguires deixar de o forçar, termina.

### Erro 2: Transformar a tarefa numa medição numérica.

- Como reconhecer: A atenção fica presa a obter um valor ou desempenho, em vez de notar as sensações presentes.
- Como corrigir: Volta a palavras descritivas simples, como localização, entrada, saída, movimento e esforço percebido.

### Erro 3: Tratar uma sensação como prova sobre o estado de saúde.

- Como reconhecer: Passas de «sinto pressão» ou «noto esforço» para uma conclusão clínica sobre a causa.
- Como corrigir: Fica apenas na descrição. Se o sinal for novo, invulgar, preocupante ou crescente, termina e procura orientação adequada.

### Erro 4: Alargar o foco a uma exploração do corpo inteiro.

- Como reconhecer: A tarefa passa a seguir pés, pernas, braços ou outras zonas sem relação direta com o ciclo respiratório.
- Como corrigir: Regressa a um sinal respiratório concreto nas narinas, no peito ou no abdómen.

### Erro 5: Continuar apesar de sinais de alarme ou sofrimento crescente.

- Como reconhecer: Surge dor no peito, falta de ar invulgar, tontura, sensação de desmaio, confusão, formigueiro marcado ou pânico crescente e tentas insistir.
- Como corrigir: Termina, orienta a atenção para o ambiente e procura ajuda adequada à gravidade e ao contexto.

## Formas de simplificar ou ensaiar

1. Usa uma cadeira estável se sentar for a posição mais segura e simples.
2. Mantém os olhos abertos e fixa suavemente um ponto neutro se fechar os olhos aumentar a insegurança.
3. Escolhe apenas um local respiratório fácil de notar, sem procurar várias zonas.
4. Se o sinal interno for pouco nítido, aceita «não noto claramente» como uma observação válida.
5. Se o foco interno for desconfortável, termina e usa os pontos de contacto com a cadeira ou o chão para te orientares para o ambiente.

## Supervisão

Não é necessária supervisão por defeito para uma pessoa que cumpre os pré-requisitos e consegue parar ou ajustar a tarefa de forma autónoma. Procura acompanhamento de um profissional de saúde qualificado quando o foco interoceptivo desencadeia sofrimento, existe história de desmaio, há doença cardiovascular ou respiratória conhecida com restrições, surgem sinais novos ou sem explicação, ou não consegues interromper a tarefa sozinho.

## Como terminar

Deixa de seguir o ciclo respiratório e volta a reparar nos pontos de apoio, nos sons e no espaço à tua volta. Se tinhas os olhos fechados, abre-os quando for seguro. Ajusta a posição devagar antes de retomares outra atividade. Se terminaste por um sinal de alarme, não reinicies nesse momento e procura ajuda adequada.

## Nota de segurança

Esta observação tem risco operacional baixo, mas a atenção interna pode aumentar ansiedade ou vigilância em algumas pessoas. A tarefa não decide elegibilidade nem explica sintomas. Termina perante dor no peito, falta de ar invulgar ou crescente, confusão, tontura, sensação de desmaio, desmaio, formigueiro marcado ou pânico crescente. Sinais graves, súbitos ou persistentes requerem ajuda urgente adequada ao local.

## Quando parar ou reduzir

1. Confusão ou sensação de perda de controlo.
2. Falta de ar invulgar ou crescente.
3. Dor no peito.
4. Pânico ou vigilância interna em aumento.
5. Formigueiro ou sinais de respiração excessivamente funda ou rápida.
6. Tontura, sensação de desmaio ou desmaio.

## Segurança do equipamento

Não é necessário equipamento. Se usares cadeira ou apoio, confirma que é estável, está bem colocado e não comprime o peito nem o abdómen. Não uses equipamento para impor o ritmo respiratório ou para transformar a tarefa num teste.

## Segurança do espaço

Usa uma zona ventilada, com superfície firme, apoio estável e espaço livre de obstáculos imediatos. Evita veículos em movimento, água, alturas desprotegidas e superfícies instáveis. Mantém iluminação suficiente para te orientares quando terminares.

## Limitações

1. A investigação disponível estuda tarefas de atenção, medição ou programas de mindfulness que não são idênticos a este exercício técnico.
2. Não existe uma sensação respiratória que todas as pessoas tenham de notar.
3. A ausência ou presença de uma sensação não permite concluir o estado de saúde.
4. O foco interno pode aumentar ansiedade ou vigilância em algumas pessoas.
5. O conteúdo não decide elegibilidade individual e não substitui orientação profissional quando existem restrições ou sinais preocupantes.

## Teste de compreensão

### 1. Qual é o objetivo imediato desta tarefa?

Resposta esperada: Reconhecer e descrever sensações presentes no ciclo respiratório.

### 2. Deves tornar a respiração mais funda ou mais lenta?

Resposta esperada: Não. A respiração deve acontecer espontaneamente, sem ajuste imposto.

### 3. Que locais podes escolher para observar a respiração?

Resposta esperada: Um local percetível, como as narinas, o peito ou o abdómen.

### 4. É obrigatório fechar os olhos?

Resposta esperada: Não. Podem ficar abertos, sobretudo se isso aumentar a segurança.

### 5. O que fazes quando a atenção se afasta?

Resposta esperada: Reconheço a distração sem crítica e volto ao sinal respiratório escolhido.

### 6. Não sentir uma zona com clareza significa que estás a executar mal?

Resposta esperada: Não. «Não noto claramente» é uma observação válida.

### 7. Podes usar uma sensação para concluir a sua causa?

Resposta esperada: Não. A tarefa fica na descrição e não tira conclusões clínicas.

### 8. Que aspetos do ciclo podes descrever?

Resposta esperada: Localização, fase, movimento, ritmo percebido e esforço percebido.

### 9. O que deves fazer se o foco interno aumentar claramente o pânico?

Resposta esperada: Retiro a atenção da respiração, oriento-me para o ambiente e termino.

### 10. Indica dois sinais que exigem terminar.

Resposta esperada: Por exemplo, dor no peito e falta de ar invulgar ou crescente.

### 11. Em que ambientes não deves realizar a tarefa?

Resposta esperada: Num veículo em movimento, debaixo de água, junto de uma altura desprotegida ou sobre apoio instável.

### 12. Quando pode ser indicado procurar acompanhamento qualificado?

Resposta esperada: Quando o foco interno desencadeia sofrimento, há história de desmaio, existem restrições cardiovasculares ou respiratórias, surgem sinais novos ou sem explicação, ou não consigo parar sozinho.

## Fontes e limites da evidência

### Fonte 1: EveFit — Especificação Canónica de Classificação de Exercícios v0.1

- Autor ou entidade: CAN-01 — fonte canónica interna resumida no pacote EX-46 — EveFit — Especificação Canónica de Classificação de Exercícios v0.1 — Fronteiras de identidade, risco, elegibilidade e ausência de parâmetros individualizados. — Considerada apenas através do conteúdo incluído no pacote EX-46.
- Tipo: fonte canónica interna resumida no pacote EX-46
- Localizador: CAN-01 — fonte canónica interna resumida no pacote EX-46 — EveFit — Especificação Canónica de Classificação de Exercícios v0.1 — Fronteiras de identidade, risco, elegibilidade e ausência de parâmetros individualizados. — Considerada apenas através do conteúdo incluído no pacote EX-46.
- Usada para: CAN-01 — fonte canónica interna resumida no pacote EX-46 — EveFit — Especificação Canónica de Classificação de Exercícios v0.1 — Fronteiras de identidade, risco, elegibilidade e ausência de parâmetros individualizados. — Considerada apenas através do conteúdo incluído no pacote EX-46.
- Limite: Considerada apenas através do conteúdo incluído no pacote EX-46.

### Fonte 2: EveFit — Registo de Intenções de Produção v0.4.1

- Autor ou entidade: CAN-03 — fonte canónica interna resumida no pacote EX-46 — EveFit — Registo de Intenções de Produção v0.4.1 — Preservação do ambiente, do equipamento, do risco e da relação aprovada. — Considerada apenas através do conteúdo incluído no pacote EX-46.
- Tipo: fonte canónica interna resumida no pacote EX-46
- Localizador: CAN-03 — fonte canónica interna resumida no pacote EX-46 — EveFit — Registo de Intenções de Produção v0.4.1 — Preservação do ambiente, do equipamento, do risco e da relação aprovada. — Considerada apenas através do conteúdo incluído no pacote EX-46.
- Usada para: CAN-03 — fonte canónica interna resumida no pacote EX-46 — EveFit — Registo de Intenções de Produção v0.4.1 — Preservação do ambiente, do equipamento, do risco e da relação aprovada. — Considerada apenas através do conteúdo incluído no pacote EX-46.
- Limite: Considerada apenas através do conteúdo incluído no pacote EX-46.

### Fonte 3: Interoceptive Awareness of the Breath Preserves Attention and Language Networks amidst Widespread Cortical Deactivation: A Within-Participant Neuroimaging Study

- Autor ou entidade: G2-S34 — estudo primário — Interoceptive Awareness of the Breath Preserves Attention and Language Networks amidst Widespread Cortical Deactivation: A Within-Participant Neuroimaging Study — https://pubmed.ncbi.nlm.nih.gov/37316296/ — Sustenta a distinção entre observar o próprio ciclo respiratório e seguir um estímulo externo; informa a identidade interoceptiva. — Amostra pequena de adultos saudáveis em contexto de neuroimagem; não estabelece regras de execução para todos nem resultados individuais.
- Tipo: estudo primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/37316296/
- Usada para: G2-S34 — estudo primário — Interoceptive Awareness of the Breath Preserves Attention and Language Networks amidst Widespread Cortical Deactivation: A Within-Participant Neuroimaging Study — https://pubmed.ncbi.nlm.nih.gov/37316296/ — Sustenta a distinção entre observar o próprio ciclo respiratório e seguir um estímulo externo; informa a identidade interoceptiva. — Amostra pequena de adultos saudáveis em contexto de neuroimagem; não estabelece regras de execução para todos nem resultados individuais.
- Limite: Amostra pequena de adultos saudáveis em contexto de neuroimagem; não estabelece regras de execução para todos nem resultados individuais.

### Fonte 4: Respiratory interoceptive accuracy in experienced meditators

- Autor ou entidade: G2-S35 — estudo primário — Respiratory interoceptive accuracy in experienced meditators — https://pubmed.ncbi.nlm.nih.gov/23692525/ — Mostra que a perceção respiratória pode ser estudada como capacidade distinta; reforça que uma tarefa observacional não deve ser convertida num teste informal. — Estudo de medição com meditadores experientes; não valida benefícios nem uma técnica pública para principiantes.
- Tipo: estudo primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/23692525/
- Usada para: G2-S35 — estudo primário — Respiratory interoceptive accuracy in experienced meditators — https://pubmed.ncbi.nlm.nih.gov/23692525/ — Mostra que a perceção respiratória pode ser estudada como capacidade distinta; reforça que uma tarefa observacional não deve ser convertida num teste informal. — Estudo de medição com meditadores experientes; não valida benefícios nem uma técnica pública para principiantes.
- Limite: Estudo de medição com meditadores experientes; não valida benefícios nem uma técnica pública para principiantes.

### Fonte 5: Mindfulness of breathing: instructions

- Autor ou entidade: NHS-TSD-01 — orientação clínica profissional oficial — Mindfulness of breathing: instructions — https://www.torbayandsouthdevon.nhs.uk/uploads/mindfulness-of-breath-instructions.pdf — Apoia posição confortável e estável, olhos opcionais, observação sem alterar a respiração e foco possível nas narinas ou no abdómen. — Material de mindfulness mais amplo; foram usados apenas os elementos compatíveis com este exercício técnico delimitado.
- Tipo: orientação clínica profissional oficial
- Localizador: https://www.torbayandsouthdevon.nhs.uk/uploads/mindfulness-of-breath-instructions.pdf
- Usada para: NHS-TSD-01 — orientação clínica profissional oficial — Mindfulness of breathing: instructions — https://www.torbayandsouthdevon.nhs.uk/uploads/mindfulness-of-breath-instructions.pdf — Apoia posição confortável e estável, olhos opcionais, observação sem alterar a respiração e foco possível nas narinas ou no abdómen. — Material de mindfulness mais amplo; foram usados apenas os elementos compatíveis com este exercício técnico delimitado.
- Limite: Material de mindfulness mais amplo; foram usados apenas os elementos compatíveis com este exercício técnico delimitado.

### Fonte 6: Mindfulness-based stress reduction — exercises

- Autor ou entidade: NHS-GSTT-01 — orientação clínica profissional oficial — Mindfulness-based stress reduction — exercises — https://www.guysandstthomas.nhs.uk/health-information/mindfulness-based-stress-reduction-mbsr/mbsr-exercises — Apoia observar o corpo a respirar sem o controlar, aceitar ausência de sensação nítida, regressar após distração e manter escolha sobre o foco. — A página inclui práticas mais amplas; o conteúdo EveFit mantém o foco apenas no ciclo respiratório.
- Tipo: orientação clínica profissional oficial
- Localizador: https://www.guysandstthomas.nhs.uk/health-information/mindfulness-based-stress-reduction-mbsr/mbsr-exercises
- Usada para: NHS-GSTT-01 — orientação clínica profissional oficial — Mindfulness-based stress reduction — exercises — https://www.guysandstthomas.nhs.uk/health-information/mindfulness-based-stress-reduction-mbsr/mbsr-exercises — Apoia observar o corpo a respirar sem o controlar, aceitar ausência de sensação nítida, regressar após distração e manter escolha sobre o foco. — A página inclui práticas mais amplas; o conteúdo EveFit mantém o foco apenas no ciclo respiratório.
- Limite: A página inclui práticas mais amplas; o conteúdo EveFit mantém o foco apenas no ciclo respiratório.

### Fonte 7: Mindfulness

- Autor ou entidade: NHS-MIND-01 — orientação de saúde oficial — Mindfulness — https://www.nhs.uk/mental-health/self-help/tips-and-support/mindfulness/ — Apoia atenção às sensações respiratórias e reconhece que algumas pessoas podem sentir agravamento do desconforto. — Informação geral, não específica desta identidade.
- Tipo: orientação de saúde oficial
- Localizador: https://www.nhs.uk/mental-health/self-help/tips-and-support/mindfulness/
- Usada para: NHS-MIND-01 — orientação de saúde oficial — Mindfulness — https://www.nhs.uk/mental-health/self-help/tips-and-support/mindfulness/ — Apoia atenção às sensações respiratórias e reconhece que algumas pessoas podem sentir agravamento do desconforto. — Informação geral, não específica desta identidade.
- Limite: Informação geral, não específica desta identidade.

### Fonte 8: Meditation and Mindfulness: Effectiveness and Safety

- Autor ou entidade: NCCIH-SAFE-01 — síntese oficial de segurança — Meditation and Mindfulness: Effectiveness and Safety — https://www.nccih.nih.gov/health/meditation-and-mindfulness-effectiveness-and-safety — Sustenta linguagem prudente: existem poucos dados de segurança e foram relatadas experiências negativas, incluindo ansiedade. — Abrange práticas heterogéneas e não quantifica o risco específico deste exercício técnico.
- Tipo: síntese oficial de segurança
- Localizador: https://www.nccih.nih.gov/health/meditation-and-mindfulness-effectiveness-and-safety
- Usada para: NCCIH-SAFE-01 — síntese oficial de segurança — Meditation and Mindfulness: Effectiveness and Safety — https://www.nccih.nih.gov/health/meditation-and-mindfulness-effectiveness-and-safety — Sustenta linguagem prudente: existem poucos dados de segurança e foram relatadas experiências negativas, incluindo ansiedade. — Abrange práticas heterogéneas e não quantifica o risco específico deste exercício técnico.
- Limite: Abrange práticas heterogéneas e não quantifica o risco específico deste exercício técnico.

### Fonte 9: Shortness of breath

- Autor ou entidade: NHS-BREATH-01 — orientação clínica oficial de segurança — Shortness of breath — https://www.nhs.uk/symptoms/shortness-of-breath/ — Informa a interrupção e procura de ajuda perante dificuldade respiratória grave, aperto ou peso no peito e confusão súbita. — Fonte de triagem geral; não permite atribuir causas a uma sensação durante o exercício técnico.
- Tipo: orientação clínica oficial de segurança
- Localizador: https://www.nhs.uk/symptoms/shortness-of-breath/
- Usada para: NHS-BREATH-01 — orientação clínica oficial de segurança — Shortness of breath — https://www.nhs.uk/symptoms/shortness-of-breath/ — Informa a interrupção e procura de ajuda perante dificuldade respiratória grave, aperto ou peso no peito e confusão súbita. — Fonte de triagem geral; não permite atribuir causas a uma sensação durante o exercício técnico.
- Limite: Fonte de triagem geral; não permite atribuir causas a uma sensação durante o exercício técnico.

### Fonte 10: Chest pain

- Autor ou entidade: NHS-CHEST-01 — orientação clínica oficial de segurança — Chest pain — https://www.nhs.uk/symptoms/chest-pain/ — Informa a interrupção perante dor no peito e a necessidade de ajuda adequada quando o sinal é súbito, persistente ou acompanhado por outros sinais graves. — Fonte de triagem geral; não deve ser usada para interpretar a causa da dor.
- Tipo: orientação clínica oficial de segurança
- Localizador: https://www.nhs.uk/symptoms/chest-pain/
- Usada para: NHS-CHEST-01 — orientação clínica oficial de segurança — Chest pain — https://www.nhs.uk/symptoms/chest-pain/ — Informa a interrupção perante dor no peito e a necessidade de ajuda adequada quando o sinal é súbito, persistente ou acompanhado por outros sinais graves. — Fonte de triagem geral; não deve ser usada para interpretar a causa da dor.
- Limite: Fonte de triagem geral; não deve ser usada para interpretar a causa da dor.
