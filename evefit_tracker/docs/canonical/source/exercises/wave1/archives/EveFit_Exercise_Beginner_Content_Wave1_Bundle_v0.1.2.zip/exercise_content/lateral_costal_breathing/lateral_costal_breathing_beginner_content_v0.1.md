# Respiração com expansão costal lateral

Conteúdo para principiantes em português europeu.

## Descrição curta

Dirigir uma inspiração confortável para uma expansão suave dos lados das costelas e deixar que as costelas regressem durante a expiração.

## O que é

É um exercício técnico de respiração no qual procuras sentir as costelas a afastarem-se suavemente para os lados ao inspirar. Não é uma inspiração máxima, não inclui retenção do ar e não serve para diagnosticar ou corrigir assimetrias.

## O que vais fazer

Numa posição estável, vais observar a respiração, inspirar sem esforço excessivo enquanto diriges a expansão para os lados da caixa torácica e expirar de forma confortável.

## Porque existe este movimento

Este exercício existe para praticares o controlo voluntário da direção da expansão costal durante a inspiração e para reconheceres esse movimento interno ou através de contacto leve das tuas próprias mãos.

## Antes de começares

1. Escolhe uma posição em que te sintas estável e consigas parar de imediato.
2. Confirma que a tua respiração está confortável no estado atual antes de a tentares dirigir.
3. Liberta roupa ou acessórios que comprimam o tórax, se isso limitar o conforto.
4. Se acabaste de fazer um esforço intenso, espera até recuperares uma respiração estável.
5. Não inicies se estiveres num veículo em movimento, numa superfície instável, submerso ou junto a uma altura desprotegida.

## Preparar o equipamento

1. Nenhum.
2. Uma cadeira estável pode ser usada como apoio.
3. Se quiseres, pousa as tuas próprias mãos suavemente nos lados das costelas apenas para sentir o movimento; não apertes nem empurres.

## Preparar o espaço

1. Usa uma zona segura, com ar de qualidade aceitável e uma base firme e estável.
2. Mantém a pequena área à tua volta livre de obstáculos.
3. Se usares uma cadeira, confirma que não desliza nem oscila.
4. Pode ser feito no interior ou no exterior, desde que a posição permaneça protegida e estável.

## Verificação do corpo

1. Consegues iniciar e interromper a tarefa voluntariamente.
2. Compreendes que não tens de aumentar ao máximo a profundidade da inspiração.
3. Não tens dor torácica ou costal, tontura, sensação de desmaio, confusão ou falta de ar atípica no momento.
4. Pescoço, mãos e ombros conseguem permanecer confortáveis e sem tensão desnecessária.

## Posição inicial

Escolhe uma posição estável. Para um primeiro contacto, podes sentar-te numa cadeira firme, com os pés apoiados e o tronco confortavelmente erguido. Em alternativa, usa outra posição estável e apoiada que não altere a identidade do exercício.

## Confirmar a posição inicial

1. Base de apoio firme e sem balanço.
2. Tronco numa posição confortável, sem arquear deliberadamente a zona lombar.
3. Ombros afastados das orelhas e braços relaxados.
4. Pescoço e maxilar sem tensão desnecessária.
5. Mãos livres ou apenas pousadas de forma leve nos lados das costelas.
6. Respiração espontânea confortável antes de começares.

## Passos de execução

1. Adota a posição estável escolhida e deixa a respiração acontecer naturalmente.
2. Repara nos lados da caixa torácica. Se usares as mãos, mantém-nas apenas em contacto leve com as costelas.
3. Inicia uma inspiração confortável, sem tentar encher os pulmões ao máximo.
4. Enquanto o ar entra, imagina que os lados das costelas se afastam suavemente para a esquerda e para a direita; pode também existir algum movimento posterior.
5. Mantém os ombros e o pescoço tranquilos e evita compensar com uma elevação do peito ou com um arqueamento da zona lombar.
6. Sem reter o ar, deixa a expiração começar de forma confortável e permite que as costelas regressem naturalmente.
7. Antes de outra inspiração dirigida, confirma que continuas confortável e com controlo para reduzir ou parar.

## Fases do movimento

### Preparação

Posição estável, respiração espontânea e relaxamento dos ombros, pescoço e mãos.

### Inspiração dirigida

Entrada confortável de ar acompanhada por expansão lateral suave das costelas, sem inspiração máxima.

### Transição

Passagem contínua para a expiração, sem pausa voluntária nem retenção.

### Expiração

Saída confortável do ar e retorno natural das costelas.

### Reavaliação

Verificação de conforto, controlo e ausência de sinais de interrupção.

## Respiração

A respiração é a própria tarefa: inspira de forma confortável enquanto permites expansão lateral das costelas e expira sem forçar. Mantém o ciclo contínuo, sem contagens, sem cadência imposta e sem retenções. Não procures uma inspiração máxima.

## Sensações esperadas

1. Movimento suave das costelas para os lados durante a inspiração.
2. Regresso natural das costelas durante a expiração.
3. Movimento respiratório confortável, sem necessidade de esforço elevado.
4. Ombros e pescoço relativamente tranquilos.
5. Alguma expansão posterior pode acompanhar a expansão lateral.

## Sensações inesperadas ou de alerta

1. Dor no peito ou nas costelas.
2. Falta de ar atípica, nova ou crescente.
3. Tontura, sensação de desmaio ou desmaio.
4. Formigueiro, dormência ou outros sinais associados a respiração excessiva.
5. Confusão, perda de controlo ou incapacidade de regressar a uma respiração confortável.

## Indicações técnicas principais

1. Deixa as costelas abrirem suavemente para os lados.
2. Inspira apenas até onde continua confortável.
3. Mantém ombros, pescoço e maxilar relaxados.
4. Usa as mãos como sensores, nunca como pressão.
5. Deixa a expiração acontecer sem forçar.
6. Passa da inspiração para a expiração sem prender o ar.

## Erros comuns e correções

### Erro 1: Tentar fazer uma inspiração máxima.

- Como reconhecer: Surge esforço excessivo, necessidade de puxar mais ar ou desconforto no fim da inspiração.
- Como corrigir: Reduz a profundidade e mantém apenas uma expansão lateral confortável.

### Erro 2: Elevar excessivamente os ombros e tensionar o pescoço.

- Como reconhecer: Os ombros aproximam-se das orelhas ou os músculos do pescoço ficam muito ativos.
- Como corrigir: Solta os ombros e torna a inspiração mais pequena e suave.

### Erro 3: Arquear a zona lombar para simular expansão.

- Como reconhecer: O tronco muda de posição, mas os lados das costelas quase não se movem.
- Como corrigir: Mantém a posição estável e procura um movimento costal discreto, sem empurrar o tronco.

### Erro 4: Pressionar as costelas com as mãos.

- Como reconhecer: As mãos apertam, empurram ou oferecem resistência ao movimento das costelas.
- Como corrigir: Alivia totalmente a pressão ou retira as mãos.

### Erro 5: Tentar corrigir uma assimetria por conta própria.

- Como reconhecer: Forças um lado, bloqueias o outro ou assumes que a diferença indica um problema.
- Como corrigir: Mantém a intenção bilateral e confortável; uma assimetria persistente ou preocupante requer avaliação profissional.

### Erro 6: Prender o ar entre a inspiração e a expiração.

- Como reconhecer: Existe uma pausa voluntária ou tensão antes de deixares o ar sair.
- Como corrigir: Liga as duas fases de forma contínua e sem retenção.

## Formas de simplificar ou ensaiar

1. Usa uma cadeira estável para reduzir a exigência postural.
2. Começa apenas por observar a expansão espontânea, sem tentar aumentá-la.
3. Usa uma única mão de cada lado como feedback leve, se isso tornar o movimento mais claro.
4. Reduz a profundidade da inspiração se os ombros começarem a subir ou se surgir esforço.
5. Retira as mãos se o contacto te levar a apertar ou a empurrar as costelas.

## Supervisão

Não requer parceiro, observador de segurança ou supervisão num contexto geral de baixo risco quando a pessoa compreende a tarefa e consegue parar ou ajustar autonomamente. Procura orientação de um profissional de saúde qualificado antes de usar esta técnica num contexto pós-operatório, perante uma assimetria clínica conhecida ou preocupante, no regresso à função, com doença cardiovascular ou respiratória, ou com história de desmaio. Supervisão torna-se apropriada se não conseguires interromper ou ajustar a tarefa de forma independente ou se surgirem sintomas novos e inexplicados.

## Como terminar

Deixa de dirigir a expansão, se tiveres usado as mãos como contacto opcional, retira-as se as estiveres a usar e regressa a uma respiração espontânea confortável na mesma posição estável. Levanta-te apenas quando te sentires estável e sem sinais de alerta.

## Nota de segurança

O risco operacional de base é baixo, mas respirar demasiado fundo ou depressa pode causar desconforto e sinais de hiperventilação. Interrompe perante dor torácica ou costal, falta de ar atípica ou crescente, tontura, sensação de desmaio, desmaio, formigueiro, confusão ou perda de controlo. Sintomas novos, intensos ou inexplicados justificam avaliação profissional.

## Quando parar ou reduzir

1. Esforço crescente ou elevação dos ombros — Reduz a profundidade; se não normalizar, termina.
2. Tontura, formigueiro ou sensação de respiração excessiva — Termina a tarefa e regressa à respiração espontânea numa posição estável.
3. Dor torácica ou costal — Interrompe de imediato e procura avaliação adequada se for nova, intensa ou persistente.
4. Falta de ar atípica ou crescente — Interrompe e procura ajuda adequada se não resolver prontamente ou se for intensa.
5. Confusão, pré-síncope ou síncope — Interrompe; não retomes sem avaliação apropriada.

## Segurança do equipamento

Não é necessário equipamento. Se usares uma cadeira, confirma que é firme e estável. As mãos são apenas feedback tátil leve e não devem aplicar compressão, resistência ou pressão terapêutica.

## Segurança do espaço

Usa uma superfície firme, uma posição protegida e ar de qualidade aceitável. Evita suportes instáveis, veículos em movimento, ambiente submerso e alturas desprotegidas. Mantém a área próxima livre de obstáculos para poderes parar com segurança.

## Limitações

1. A literatura usa frequentemente expansão torácica dentro de protocolos clínicos; este conteúdo não transforma o exercício técnico em tratamento ou técnica de limpeza das vias aéreas.
2. Não há base suficiente para prometer aumento da capacidade pulmonar, correção postural, correção de assimetria ou qualquer resultado individual.
3. Não foram incluídos inspiração máxima, pausas, retenções, pressão manual, dose ou cadência, mesmo quando presentes em fontes clínicas, porque não pertencem ao âmbito aprovado.
4. A expansão aproximadamente simétrica é uma referência técnica, não um teste diagnóstico.
5. Implementação realizada: não.
6. Limite documentado: A amplitude lateral considerada confortável varia entre pessoas e não deve ser convertida numa meta fixa.
7. Limite documentado: A melhor posição para cada pessoa depende do conforto e do contexto; a identidade canónica permite posições estáveis diferentes.
8. Limite documentado: A evidência primária não isola de forma robusta o efeito deste exercício técnico em principiantes saudáveis.

## Teste de compreensão

### 1. Qual é o movimento principal procurado durante a inspiração?

Resposta esperada: Uma expansão suave dos lados das costelas.

### 2. É necessário inspirar até ao máximo?

Resposta esperada: Não. A inspiração deve permanecer confortável e sem esforço excessivo.

### 3. Deves prender o ar antes de expirar?

Resposta esperada: Não. A passagem para a expiração deve ser contínua, sem retenção.

### 4. Para que servem as mãos nesta versão do exercício?

Resposta esperada: Apenas para feedback tátil leve e opcional.

### 5. Deves apertar ou empurrar as costelas com as mãos?

Resposta esperada: Não. Não se aplica pressão nem resistência.

### 6. O que devem fazer os ombros durante a inspiração?

Resposta esperada: Permanecer relaxados, sem elevação excessiva.

### 7. O que fazes se começares a arquear a zona lombar?

Resposta esperada: Reduzes a inspiração e recuperas uma posição estável.

### 8. A observação de um lado diferente do outro permite diagnosticar uma assimetria clínica?

Resposta esperada: Não. Uma observação isolada não é um diagnóstico.

### 9. Que sinais podem indicar respiração excessiva?

Resposta esperada: Por exemplo, tontura, formigueiro, sensação de desmaio, confusão ou falta de ar crescente.

### 10. O que fazes se surgir dor torácica ou costal?

Resposta esperada: Interrompes de imediato e procuras avaliação adequada se for nova, intensa ou persistente.

### 11. É obrigatório usar uma cadeira?

Resposta esperada: Não. É opcional; o essencial é uma posição segura e estável.

### 12. Quando pode ser indicada orientação profissional?

Resposta esperada: Em contexto pós-operatório, com doença cardiovascular ou respiratória, história de desmaio, assimetria preocupante, sintomas novos ou incapacidade de ajustar e parar autonomamente.

## Fontes e limites da evidência

### Fonte 1: Bott J, et al. Guidelines for the physiotherapy management of the adult, medical, spontaneously breathing patient. Thorax. 2009;64 Suppl 1:i1-i51.

- Autor ou entidade: G2-S15 — Bott J, et al. Guidelines for the physiotherapy management of the adult, medical, spontaneously breathing patient. Thorax. 2009;64 Suppl 1:i1-i51. — Guideline profissional da British Thoracic Society e da Association of Chartered Physiotherapists in Respiratory Care. — https://www.brit-thoracic.org.uk/document-library/guidelines/physiotherapy/btsacprc-guidelines-for-physiotherapy-management-of-the-adult-medical-spontaneously-breathing-patient/ — Distinção entre controlo respiratório, expansão torácica e técnicas manuais; apoio para postura confortável, esforço baixo e relaxamento de ombros e mãos. — Documento clínico dirigido a pessoas com doença respiratória; não valida resultados gerais deste exercício técnico.
- Tipo: Guideline profissional da British Thoracic Society e da Association of Chartered Physiotherapists in Respiratory Care.
- Localizador: https://www.brit-thoracic.org.uk/document-library/guidelines/physiotherapy/btsacprc-guidelines-for-physiotherapy-management-of-the-adult-medical-spontaneously-breathing-patient/
- Usada para: Distinção entre controlo respiratório, expansão torácica e técnicas manuais; apoio para postura confortável, esforço baixo e relaxamento de ombros e mãos.
- Limite: G2-S15 — Bott J, et al. Guidelines for the physiotherapy management of the adult, medical, spontaneously breathing patient. Thorax. 2009;64 Suppl 1:i1-i51. — Guideline profissional da British Thoracic Society e da Association of Chartered Physiotherapists in Respiratory Care. — https://www.brit-thoracic.org.uk/document-library/guidelines/physiotherapy/btsacprc-guidelines-for-physiotherapy-management-of-the-adult-medical-spontaneously-breathing-patient/ — Distinção entre controlo respiratório, expansão torácica e técnicas manuais; apoio para postura confortável, esforço baixo e relaxamento de ombros e mãos. — Documento clínico dirigido a pessoas com doença respiratória; não valida resultados gerais deste exercício técnico.

### Fonte 2: Cambridge University Hospitals NHS Foundation Trust. Airway clearance: active cycle of breathing technique (ACBT). Versão 8, aprovada em 5 de setembro de 2025.

- Autor ou entidade: WEB-CUH-ACBT-2025 — Cambridge University Hospitals NHS Foundation Trust. Airway clearance: active cycle of breathing technique (ACBT). Versão 8, aprovada em 5 de setembro de 2025. — Informação clínica oficial para doentes. — https://www.cuh.nhs.uk/patient-information/airway-clearance-active-cycle-of-breathing-technique-acbt/ — Posição confortável, braços e ombros relaxados, cadeira ou decúbito lateral como opções clínicas e expiração confortável. — A página descreve um protocolo de limpeza das vias aéreas e inclui dose e retenção; esses elementos não foram transferidos para este conteúdo.
- Tipo: Informação clínica oficial para doentes.
- Localizador: https://www.cuh.nhs.uk/patient-information/airway-clearance-active-cycle-of-breathing-technique-acbt/
- Usada para: Posição confortável, braços e ombros relaxados, cadeira ou decúbito lateral como opções clínicas e expiração confortável.
- Limite: WEB-CUH-ACBT-2025 — Cambridge University Hospitals NHS Foundation Trust. Airway clearance: active cycle of breathing technique (ACBT). Versão 8, aprovada em 5 de setembro de 2025. — Informação clínica oficial para doentes. — https://www.cuh.nhs.uk/patient-information/airway-clearance-active-cycle-of-breathing-technique-acbt/ — Posição confortável, braços e ombros relaxados, cadeira ou decúbito lateral como opções clínicas e expiração confortável. — A página descreve um protocolo de limpeza das vias aéreas e inclui dose e retenção; esses elementos não foram transferidos para este conteúdo.

### Fonte 3: Blaney F, Sawyer T. Sonographic measurement of diaphragmatic motion after upper abdominal surgery: a comparison of three breathing manoeuvres. Physiotherapy Theory and Practice. 1997;13(3):207-215. doi:10.3109/09593989709036464.

- Autor ou entidade: PRIMARY-BLANEY-SAWYER-1997 — Blaney F, Sawyer T. Sonographic measurement of diaphragmatic motion after upper abdominal surgery: a comparison of three breathing manoeuvres. Physiotherapy Theory and Practice. 1997;13(3):207-215. doi:10.3109/09593989709036464. — Estudo primário comparativo. — https://doi.org/10.3109/09593989709036464 — Confirma que a expansão torácica, também descrita como respiração costal lateral, é uma manobra respiratória treinável e distinta da respiração abdominal. — Amostra pequena e pós-operatória; não sustenta generalização de benefícios nem uma instrução universal.
- Tipo: Estudo primário comparativo.
- Localizador: https://doi.org/10.3109/09593989709036464
- Usada para: Confirma que a expansão torácica, também descrita como respiração costal lateral, é uma manobra respiratória treinável e distinta da respiração abdominal.
- Limite: PRIMARY-BLANEY-SAWYER-1997 — Blaney F, Sawyer T. Sonographic measurement of diaphragmatic motion after upper abdominal surgery: a comparison of three breathing manoeuvres. Physiotherapy Theory and Practice. 1997;13(3):207-215. doi:10.3109/09593989709036464. — Estudo primário comparativo. — https://doi.org/10.3109/09593989709036464 — Confirma que a expansão torácica, também descrita como respiração costal lateral, é uma manobra respiratória treinável e distinta da respiração abdominal. — Amostra pequena e pós-operatória; não sustenta generalização de benefícios nem uma instrução universal.

### Fonte 4: Korkie E. Effect of lateral costal breathing dissociation exercises on the position of the scapula in level two up to senior national level swimmers. Tese de doutoramento, University of Pretoria, 2015.

- Autor ou entidade: PRIMARY-KORKIE-2015 — Korkie E. Effect of lateral costal breathing dissociation exercises on the position of the scapula in level two up to senior national level swimmers. Tese de doutoramento, University of Pretoria, 2015. — Investigação primária longitudinal. — https://repository.up.ac.za/items/5b6145e9-d9ae-4730-95fb-2eb1a8b4d1c7 — Documenta a facilitação voluntária da respiração costal lateral e a medição de expansão torácica. — Intervenção combinada com treino escapular e alongamento numa população de nadadores; o efeito isolado da respiração não pode ser inferido.
- Tipo: Investigação primária longitudinal.
- Localizador: https://repository.up.ac.za/items/5b6145e9-d9ae-4730-95fb-2eb1a8b4d1c7
- Usada para: Documenta a facilitação voluntária da respiração costal lateral e a medição de expansão torácica.
- Limite: PRIMARY-KORKIE-2015 — Korkie E. Effect of lateral costal breathing dissociation exercises on the position of the scapula in level two up to senior national level swimmers. Tese de doutoramento, University of Pretoria, 2015. — Investigação primária longitudinal. — https://repository.up.ac.za/items/5b6145e9-d9ae-4730-95fb-2eb1a8b4d1c7 — Documenta a facilitação voluntária da respiração costal lateral e a medição de expansão torácica. — Intervenção combinada com treino escapular e alongamento numa população de nadadores; o efeito isolado da respiração não pode ser inferido.

### Fonte 5: MedlinePlus Medical Encyclopedia. Hyperventilation. National Library of Medicine; revisão de 23 de julho de 2024.

- Autor ou entidade: WEB-MEDLINEPLUS-HYPERVENTILATION-2024 — MedlinePlus Medical Encyclopedia. Hyperventilation. National Library of Medicine; revisão de 23 de julho de 2024. — Recurso clínico oficial do governo dos Estados Unidos. — https://medlineplus.gov/ency/article/003071.htm — Apoio para o risco de respiração excessivamente rápida ou profunda e para sinais como tontura, falta de ar, dor torácica, formigueiro e dificuldade de concentração. — Fonte geral sobre hiperventilação, não específica desta técnica.
- Tipo: Recurso clínico oficial do governo dos Estados Unidos.
- Localizador: https://medlineplus.gov/ency/article/003071.htm
- Usada para: Apoio para o risco de respiração excessivamente rápida ou profunda e para sinais como tontura, falta de ar, dor torácica, formigueiro e dificuldade de concentração.
- Limite: WEB-MEDLINEPLUS-HYPERVENTILATION-2024 — MedlinePlus Medical Encyclopedia. Hyperventilation. National Library of Medicine; revisão de 23 de julho de 2024. — Recurso clínico oficial do governo dos Estados Unidos. — https://medlineplus.gov/ency/article/003071.htm — Apoio para o risco de respiração excessivamente rápida ou profunda e para sinais como tontura, falta de ar, dor torácica, formigueiro e dificuldade de concentração. — Fonte geral sobre hiperventilação, não específica desta técnica.

### Fonte 6: Especificação canónica de classificação e registo de intenções EveFit, conforme incorporados no pacote de entrada EX-47.

- Autor ou entidade: CAN-01-CAN-03 — Especificação canónica de classificação e registo de intenções EveFit, conforme incorporados no pacote de entrada EX-47. — Fontes canónicas internas herdadas. — não aplicável — Preservação de identidade, risco, equipamento, ambiente, elegibilidade e relações aprovadas. — Foram usados apenas os excertos e campos presentes no pacote de entrada; não houve leitura de outros pacotes.
- Tipo: Fontes canónicas internas herdadas.
- Localizador: não aplicável
- Usada para: Preservação de identidade, risco, equipamento, ambiente, elegibilidade e relações aprovadas.
- Limite: CAN-01-CAN-03 — Especificação canónica de classificação e registo de intenções EveFit, conforme incorporados no pacote de entrada EX-47. — Fontes canónicas internas herdadas. — não aplicável — Preservação de identidade, risco, equipamento, ambiente, elegibilidade e relações aprovadas. — Foram usados apenas os excertos e campos presentes no pacote de entrada; não houve leitura de outros pacotes.
