# Relatório de investigação — Respiração ritmada

## Resultado

Foi produzida cobertura documental defensável para a execução principiante de `paced_breathing`, com apoio em duas investigações primárias independentes, duas fontes clínicas/profissionais oficiais e duas fontes científicas já associadas ao registo canónico.

**Implementação realizada: não.**

## Âmbito preservado

- **Identidade:** alinhar voluntariamente inspiração e expiração com um ritmo regular autoescolhido ou fornecido por sinal externo, sem retenção obrigatória.
- **Propósito técnico:** praticar consistência temporal entre as fases respiratórias.
- **Risco operacional de base:** baixo.
- **Equipamento:** nenhum obrigatório; guia visual, sonoro ou háptico opcional e alternativo.
- **Ambiente:** posição segura e estável, superfície firme, ar de boa qualidade e sinal percetível; exclusão de veículo em movimento, água e altura desprotegida.
- **Relações:** preservadas sem criação, remoção, reclassificação ou alteração.

Não foram introduzidas dose, contagem, frequência, razão temporal, retenção, prescrição individual, promessa de resultado, diagnóstico, tratamento, aprovação multimédia, código ou publicação.

## Questões de investigação

1. Como pode um estímulo externo orientar as fases respiratórias sem impor uma razão temporal?
2. Que preparação postural, material e ambiental é defensável?
3. Como evitar e reconhecer sobre-respiração ou hiperventilação?
4. Que erros são plausíveis numa pessoa principiante?
5. Quando é adequada execução independente e quando procurar supervisão?
6. Como separar esta identidade de box breathing, avaliação de frequência de ressonância, biofeedback e tratamento?

## Síntese da evidência

### Estímulo externo

Gonzalez e colaboradores compararam sinais auditivos e visuais numa tarefa respiratória controlada. Ambas as modalidades permitiram orientar o ritmo, mas a dificuldade percebida diferiu: o sinal auditivo foi considerado mais difícil por muitos participantes. A transferência segura para o conteúdo é oferecer modalidades alternativas e escolher a mais fácil de perceber; a cadência experimental não é transferível.

Russell e colaboradores descrevem uma interface em que uma forma visual muda para representar as fases e um som assinala uma transição. Isto sustenta operacionalmente sinais claros de mudança. O estudo inclui elementos que pertencem a outra técnica e a uma prescrição experimental; por isso, retenções, razão temporal, dose e objetivos fisiológicos foram explicitamente excluídos.

### Preparação e execução confortável

O folheto de fisioterapia dos Cambridge University Hospitals recomenda apoio confortável, relaxamento da parte superior do peito e dos ombros, entrada suave do ar, saída sem esforço e ritmo confortável. Estes elementos são coerentes com o risco baixo e ajudam a evitar que acompanhar o sinal se transforme em esforço ventilatório. As contagens e a finalidade terapêutica do folheto não foram importadas.

### Hiperventilação e interrupção

Johns Hopkins Medicine define hiperventilação como respiração rápida ou profunda em excesso e explica que a eliminação excessiva de dióxido de carbono pode causar sintomas. Esta base sustenta não aumentar a profundidade apenas para preencher uma fase e interromper perante tontura, cabeça leve, formigueiro, falta de ar, confusão ou sensação de desmaio.

Shaffer e Meehan também descrevem sobre-respiração durante respiração ritmada e recomendam menor amplitude quando surgem sinais. O artigo pertence ao contexto de avaliação de frequência de ressonância; foi usado apenas para segurança e para afirmar a fronteira conceptual. Nenhuma métrica, frequência ou avaliação foi transferida.

### Fronteira com frequência de ressonância e tratamento

Shaffer e Meehan mostram que avaliar frequência de ressonância requer comparar respostas fisiológicas a diferentes frequências e interpretar métricas cardiorrespiratórias. A tarefa aqui documentada não faz qualquer medição ou interpretação; usa apenas um estímulo externo para organizar as fases.

Zaccaro e colaboradores mostram grande heterogeneidade nos protocolos de respiração lenta. A revisão oferece suporte de família, mas não justifica uma frequência, razão inspiração/expiração ou efeito universal. Por isso, o conteúdo limita-se a controlo temporal confortável.

### Supervisão

A ausência de supervisão por defeito vem do registo canónico de risco baixo e do requisito de a pessoa conseguir iniciar, ajustar e parar a tarefa. Os gatilhos canónicos foram preservados: contexto clinicamente restrito, incapacidade para parar ou ajustar de forma independente e sintomas novos ou sem explicação. O folheto dos Cambridge University Hospitals reforça procurar fisioterapeuta ou médico quando a prática é dolorosa.

## Decisões editoriais

| Tema | Decisão | Justificação |
|---|---|---|
| Modalidade do sinal | Visual, sonora ou háptica, em alternativa | Preserva o registo e permite acessibilidade sem tornar uma modalidade universal |
| Ritmo | Regular, ajustável e confortável | Mantém identidade sem introduzir dose |
| Profundidade | Amplitude confortável | Reduz risco de sobre-respiração |
| Mudança de fase | Direta, sem pausa imposta | Preserva ausência de retenção obrigatória |
| Via respiratória | Não imposta | As fontes e o registo não sustentam uma via universal |
| Saída | Abandonar o sinal e regressar à respiração espontânea | Garante controlo voluntário e estratégia simples de interrupção |
| Supervisão | Não exigida por defeito; acionada por gatilhos canónicos | Preserva risco baixo sem presumir elegibilidade universal |
| Resultados | Nenhuma promessa | Evidência heterogénea e âmbito estritamente técnico |

## Erros cobertos

- forçar uma frequência universal;
- respirar demasiado fundo para preencher a fase;
- acrescentar retenções;
- transformar o sinal em objetivo de desempenho;
- elevar os ombros e tensionar a parte superior do peito;
- escolher um sinal sensorialmente difícil de perceber.

Cada erro foi acompanhado por forma de reconhecimento e correção não prescritiva.

## Fontes consultadas

### Investigação primária

1. Gonzalez JE, Jewell SR, Stelly SP, Cooke WH. *Controlled breathing and autonomic rhythms: Influence of auditory versus visual cues*. [DOI](https://doi.org/10.1016/j.autneu.2021.102896)  
   **Contributo:** viabilidade de sinais auditivos e visuais e diferença na facilidade percebida.  
   **Limite:** a cadência do estudo não foi transferida.

2. Russell MEB, Scott AB, Boggero IA, Carlson CR. *Inclusion of a Rest Period in Diaphragmatic Breathing Increases High Frequency Heart Rate Variability*. [PubMed Central](https://pmc.ncbi.nlm.nih.gov/articles/PMC5319881/)  
   **Contributo:** implementação observável de sinal visual e sonoro para marcar fases.  
   **Limite:** retenções, razão temporal, dose e objetivo fisiológico foram excluídos.

### Fontes clínicas e profissionais oficiais

3. Cambridge University Hospitals NHS Foundation Trust. *Breathing exercises in the treatment of hyperventilation*. [CUH](https://www.cuh.nhs.uk/patient-information/breathing-exercises-in-the-treatment-of-hyperventilation/)  
   **Contributo:** posição confortável, ombros relaxados, expiração suave, ritmo confortável e procura de orientação perante dor.  
   **Limite:** tratamento e contagens não foram importados.

4. Johns Hopkins Medicine. *Hyperventilation*. [Johns Hopkins Medicine](https://www.hopkinsmedicine.org/health/conditions-and-diseases/hyperventilation)  
   **Contributo:** mecanismo e sinais associados a respiração rápida ou profunda em excesso.  
   **Limite:** usada para segurança, não para diagnóstico.

### Fontes científicas existentes no registo

5. Shaffer F, Meehan ZM. *A Practical Guide to Resonance Frequency Assessment for Heart Rate Variability Biofeedback*. [Frontiers in Neuroscience](https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.570400/full)  
   **Contributo:** sobre-respiração e distinção entre exercício ritmado e avaliação de ressonância.  
   **Limite:** sem importação de frequências, métricas ou procedimentos clínicos.

6. Zaccaro A, et al. *How Breath-Control Can Change Your Life: A Systematic Review on Psycho-Physiological Correlates of Slow Breathing*. [PubMed Central](https://pmc.ncbi.nlm.nih.gov/articles/PMC6137615/)  
   **Contributo:** suporte de família e heterogeneidade dos protocolos.  
   **Limite:** não sustenta frequência, razão temporal ou efeito universal.

## Avaliação da confiança

**Confiança global: moderada.**

A evidência é suficiente para documentar a mecânica de seguir um sinal externo, a escolha de modalidade, a preparação confortável, os principais erros e a interrupção perante sobre-respiração. A identidade, o risco, o equipamento, o ambiente, a elegibilidade e as relações têm suporte canónico aprovado. A literatura não permite estabelecer uma única forma temporal nem prometer efeitos individuais.

## Limitações finais

- Conteúdo para aprendizagem técnica, não para avaliação clínica.
- Sem elegibilidade automática para qualquer pessoa ou contexto.
- Sem dose, progressão programada ou parametrização do sinal.
- Sem retenções, box breathing ou razão temporal fixa.
- Sem avaliação de frequência de ressonância, HRV ou dióxido de carbono.
- Sem afirmação de tratamento, prevenção de doença ou efeito autonómico universal.
- Sem alteração de identidade, risco, equipamento, ambiente ou relações.
- Sem aprovação de imagem ou vídeo.
- Implementação realizada: não.
