# Propulsão manual de cadeira de rodas no solo

Conteúdo para principiantes em português europeu.

## Descrição curta

Deslocamento real numa cadeira de rodas manual através de impulsos repetidos nos aros, com recuperação das mãos, orientação e travagem controlada.

## O que é

Neste exercício, permaneces sentado numa cadeira de rodas manual já ajustada e funcional e fazes a cadeira deslocar-se no solo. As mãos contactam os aros para impulsionar, largam ou aliviam o contacto durante a recuperação e voltam à posição de impulso. A pressão pode ser igual nos dois lados para seguir em frente ou diferente para mudar de direção; para recuar, puxas os aros de forma controlada enquanto observas o espaço atrás.

## O que vais fazer

Vais verificar a cadeira e o percurso, assumir uma posição sentada estável, destravar a cadeira, impulsionar os dois aros, recuperar as mãos, orientar o trajeto e terminar com uma desaceleração progressiva.

## Porque existe este movimento

A ação técnica existe para propulsionar e orientar uma cadeira de rodas manual num percurso terrestre. Pode integrar treino de locomoção cíclica e de propulsão cíclica, mas esta explicação não define dose, intensidade nem resultado individual.

## Antes de começares

1. Confirma que esta é a tua cadeira de rodas manual ajustada ou uma cadeira cuja adequação já foi verificada por um profissional competente.
2. Verifica visualmente rodas, pneus, rodízios dianteiros, aros, travões de estacionamento, assento, almofada e apoios dos pés.
3. Com a cadeira parada e os travões de estacionamento aplicados, confirma que te sentas de forma estável e que os pés e a roupa ficam afastados das rodas e dos rodízios.
4. Observa todo o percurso, incluindo largura, inclinação, obstáculos, pessoas, tráfego, iluminação e espaço necessário para virar e parar.
5. Se a cadeira, o percurso ou a técnica forem novos para ti, assegura supervisão adequada antes de iniciar.

## Preparar o equipamento

1. Cadeira de rodas manual ajustada, funcional e adequada ao utilizador e ao percurso.
2. A cadeira deve rolar sem ruídos, folgas ou desvios inesperados; os pneus e rodízios devem estar em condição funcional; os aros devem estar secos, limpos e firmes; os travões de estacionamento devem imobilizar a cadeira quando aplicados; o assento, a almofada e os apoios prescritos devem estar corretamente colocados.
3. Não alteres a posição do eixo, a altura ou o ângulo do assento, o encosto, os apoios nem outros componentes para executar este conteúdo. Se não alcanças os aros com controlo, se a postura não é estável ou se o ajuste parece inadequado, interrompe e pede avaliação a um profissional de cadeiras de rodas.

## Preparar o espaço

1. Escolhe um percurso acessível, desimpedido, previsível e com superfície firme e controlável.
2. Reserva espaço livre à frente, atrás e nos lados para orientar, virar e parar sem colisão.
3. Evita declives, desníveis, lancis, pisos soltos ou escorregadios, tráfego e visibilidade reduzida quando ainda não dominas o controlo básico.
4. Mantém uma saída livre e um local seguro onde possas parar se perderes confiança ou controlo.

## Verificação do corpo

1. Consegues manter a posição sentada e o apoio necessário sem escorregar ou perder estabilidade.
2. Consegues contactar ambos os aros sem esticar excessivamente os ombros, inclinar-te de forma insegura ou prender os dedos.
3. Não tens dor nova, tonturas, confusão, desconforto no peito nem falta de ar atípica antes de começares.
4. Sentes que consegues observar o percurso, orientar a cadeira e aplicar pressão suficiente nos aros para abrandar.

## Posição inicial

Senta-te com a bacia apoiada no assento, o tronco estável de acordo com o ajuste da cadeira e os pés apoiados nos suportes prescritos. Mantém a cabeça levantada e olha para o percurso. Com a cadeira ainda imobilizada pelos travões de estacionamento, deixa os ombros relaxados e aproxima as mãos dos aros sem colocar os dedos entre o aro, a roda, os raios ou os travões.

## Confirmar a posição inicial

1. Bacia e tronco apoiados de forma estável.
2. Pés, roupa e objetos pessoais afastados das rodas e dos rodízios.
3. Cabeça levantada e percurso observado.
4. Mãos prontas nos aros, com os polegares orientados para a frente e sem envolver a parte inferior do aro.
5. Travões de estacionamento aplicados durante a verificação e prontos a ser libertados antes do movimento.
6. Espaço livre suficiente para iniciar, corrigir a direção e parar.

## Passos de execução

1. Depois de terminares todas as verificações, liberta completamente os dois travões de estacionamento. Confirma que nenhuma mão, peça de roupa ou objeto está junto de uma zona de aperto. — Liberta a cadeira para rolar
2. Coloca as mãos nos aros ligeiramente atrás do ponto mais alto das rodas, numa posição confortável que permita empurrar para a frente. Mantém os polegares orientados para a frente e os punhos sem posições extremas. — Prepara o primeiro impulso
3. Empurra os dois aros para a frente de forma longa, suave e tão simétrica quanto o teu controlo permitir. Evita puxões bruscos e mantém os ombros afastados das orelhas. — Impulsiona para a frente
4. No fim do impulso, alivia ou larga o contacto e leva as mãos de volta com os ombros relaxados. Uma recuperação natural abaixo dos aros pode criar um ciclo suave em piso plano, mas não forces este trajeto se não for confortável ou não tiver sido adequado à tua técnica. — Recupera as mãos
5. Olha para onde queres ir. Para seguir em frente, aplica impulsos semelhantes nos dois lados. Para uma curva ampla, impulsiona um pouco mais o aro do lado exterior da curva ou abranda suavemente o aro do lado interior, mantendo as mãos prontas para controlar a cadeira. — Mantém ou corrige a direção
6. Se precisares de recuar, verifica primeiro ambos os lados e o espaço atrás. Puxa os dois aros para trás com movimentos curtos e controlados, volta a observar frequentemente o percurso e evita uma travagem súbita. — Recua apenas com o percurso visível
7. Antecipa o ponto de paragem. Contacta os dois aros à frente do corpo e aumenta a pressão de forma gradual e semelhante nos dois lados até a cadeira ficar imóvel. Não uses os travões de estacionamento para abrandar uma cadeira em movimento. — Abranda e para
8. Quando a cadeira estiver completamente parada numa zona segura, aplica os dois travões de estacionamento e confirma que a cadeira permanece imóvel antes de retirares as mãos dos aros. — Estabiliza no final

## Fases do movimento

### Preparação

Cadeira imobilizada, corpo apoiado, percurso observado e mãos prontas sem contacto com zonas de aperto.

### Impulso

As mãos aplicam força nos aros para deslocar a cadeira; em linha reta, a ação é tão simétrica e suave quanto possível.

### Recuperação

As mãos aliviam ou largam os aros e regressam à posição de contacto sem arrastar, prender ou fazer movimentos abruptos.

### Orientação

A diferença controlada entre os lados altera a direção, enquanto a visão permanece no percurso e no espaço de travagem.

### Travagem e finalização

A pressão progressiva nos aros reduz a velocidade; só depois da imobilização são aplicados os travões de estacionamento.

## Respiração

Respira de forma natural e contínua durante o impulso, a recuperação, a viragem e a travagem. Evita prender a respiração quando aplicas força. Não é necessária uma contagem respiratória; se surgir falta de ar atípica, desconforto no peito, tontura ou confusão, pára em segurança.

## Sensações esperadas

1. Trabalho dos braços, ombros e antebraços ao impulsionar e controlar os aros.
2. Ativação do tronco para manter a postura sentada estável.
3. Contacto e pressão controlados das mãos nos aros.
4. Aumento gradual da ventilação compatível com o esforço, sem sintomas atípicos.
5. Necessidade de pequenas correções de direção devido à superfície ou a diferenças entre os lados.

## Sensações inesperadas ou de alerta

1. Dor nova, aguda ou crescente no ombro, cotovelo, punho, mão, tronco ou noutra região.
2. Dormência nova, perda de sensibilidade, beliscão, queimadura por fricção ou lesão da pele nas mãos.
3. Tonturas, confusão, desconforto no peito ou falta de ar atípica.
4. Instabilidade do tronco, escorregamento no assento ou sensação de queda iminente.
5. Perda de controlo da direção ou da travagem, vibração, ruído, folga ou desvio inesperado da cadeira.

## Indicações técnicas principais

1. Olha para o percurso, não para as mãos.
2. Impulsos longos e suaves; ombros relaxados.
3. Polegares para a frente e dedos longe das partes móveis.
4. Recupera sem arrastar as mãos nos aros.
5. Vira com diferenças pequenas entre os lados.
6. Abranda cedo e de forma progressiva.

## Erros comuns e correções

### Erro 1: Iniciar com a cadeira mal verificada, mal ajustada ou com um componente solto.

- Como reconhecer: A postura parece instável, o alcance aos aros é forçado, a cadeira desvia-se, faz ruído, vibra ou não fica imóvel com os travões de estacionamento aplicados.
- Como corrigir: Não inicies nem tentes corrigir o ajuste por conta própria. Usa apenas uma cadeira já adequada e funcional e pede avaliação profissional quando o ajuste ou o funcionamento levantarem dúvidas.

### Erro 2: Começar com um dos travões de estacionamento ainda aplicado ou apenas parcialmente libertado.

- Como reconhecer: A cadeira oferece resistência desigual, roda para um lado ou exige força inesperada logo no início.
- Como corrigir: Pára, aplica ambos os travões, verifica a posição dos dois mecanismos e só reinicia quando ambos estiverem totalmente libertados e a cadeira funcionar normalmente.

### Erro 3: Usar impulsos curtos, bruscos e com os ombros elevados.

- Como reconhecer: O contacto com o aro é ruidoso, a cadeira acelera aos solavancos e os ombros aproximam-se das orelhas.
- Como corrigir: Reduz a força súbita, relaxa os ombros e procura um contacto mais longo e suave dentro da tua amplitude confortável.

### Erro 4: Arrastar as mãos durante toda a recuperação ou aproximar os dedos de raios, pneus, travões e zonas de aperto.

- Como reconhecer: Ouve-se fricção contínua, a cadeira abranda entre impulsos ou os dedos ficam muito próximos de componentes móveis.
- Como corrigir: Alivia ou larga o contacto durante a recuperação, orienta os polegares para a frente e mantém todos os dedos do lado seguro do aro.

### Erro 5: Olhar para os aros e reagir tarde ao percurso.

- Como reconhecer: A cadeira aproxima-se demasiado de paredes, pessoas, bordos ou obstáculos e as correções tornam-se repentinas.
- Como corrigir: Mantém a cabeça levantada, observa mais à frente e inicia a correção ou a travagem enquanto ainda existe espaço livre.

### Erro 6: Travar de repente ou acionar os travões de estacionamento com a cadeira em movimento.

- Como reconhecer: O corpo é projetado para a frente, a cadeira guina ou a paragem é brusca e instável.
- Como corrigir: Antecipa a paragem e aplica pressão progressiva e semelhante nos dois aros. Usa os travões de estacionamento apenas depois de a cadeira estar completamente imóvel.

### Erro 7: Forçar uma trajetória de recuperação ou uma postura que não é confortável.

- Como reconhecer: Surge tensão, dor, perda de controlo ou necessidade de elevar e rodar excessivamente os ombros.
- Como corrigir: Regressa a uma ação segura e confortável e pede observação a um profissional de reabilitação ou mobilidade; a técnica deve respeitar a função, o conforto e o ajuste individual.

## Formas de simplificar ou ensaiar

1. Usar uma superfície interior firme, nivelada e sem obstáculos.
2. Escolher um percurso reto com grande espaço de travagem.
3. Separar a aprendizagem em arrancar, rolar, orientar e parar, mantendo sempre o controlo.
4. Usar curvas amplas em vez de mudanças apertadas de direção.
5. Evitar recuar, declives, desníveis, superfícies soltas e zonas com tráfego até existir competência específica para esses contextos.
6. Pedir demonstração e feedback individual de um profissional habituado a ensinar mobilidade em cadeira de rodas.

## Supervisão

A supervisão é recomendada, sobretudo na aprendizagem inicial, com cadeira ou ambiente desconhecidos, instabilidade marcada, dificuldade de visão do percurso, controlo inconsistente dos aros ou incerteza sobre a travagem. A pessoa que supervisiona deve conhecer a cadeira e a técnica, manter-se suficientemente próxima para intervir sem agarrar inesperadamente a cadeira e não deve substituir a avaliação profissional do ajuste. O registo canónico não exige parceiro nem assistente de segurança em todas as execuções.

## Como terminar

Escolhe uma zona firme e desimpedida, olha em frente e abranda progressivamente com pressão nos dois aros. Quando a cadeira estiver totalmente imóvel, aplica ambos os travões de estacionamento. Reposiciona as mãos em segurança, confirma que os pés e a roupa continuam afastados das rodas e verifica se surgiu dor nova, alteração da pele, tontura, confusão, desconforto no peito, falta de ar atípica ou anomalia na cadeira.

## Nota de segurança

O risco operacional é moderado. Colisão ou capotamento, lesão das mãos e sobrecarga dos membros superiores tornam-se mais prováveis com fadiga, visibilidade reduzida, inclinação, tráfego, superfície difícil ou falha dos travões, rodas, pneus, assento ou outros componentes. Este conteúdo cobre controlo básico no solo; não autoriza lancis, degraus, wheelies, declives exigentes, tráfego ou superfícies que excedam o controlo do utilizador.

## Quando parar ou reduzir

1. Desconforto no peito ou falta de ar atípica.
2. Tonturas ou confusão.
3. Perda de controlo ou dor nova.
4. Instabilidade marcada, escorregamento no assento ou sensação de queda.
5. Lesão da mão, contacto repetido com partes móveis ou aquecimento/fricção que já não consegues controlar.
6. Falha, ruído, folga, vibração ou desvio inesperado da cadeira.

## Segurança do equipamento

Usa apenas uma cadeira de rodas manual ajustada e funcional; não substituas por equipamento improvisado. Testa os travões de estacionamento com a cadeira parada e usa-os apenas para manter a cadeira imóvel. Confirma que rodas, pneus, rodízios, eixos, aros, assento, almofada e apoios estão montados e em condição normal. Mantém dedos, polegares, roupa e objetos afastados de raios, pneus, rodízios, travões e outras zonas de aperto. Se a cadeira puxar para um lado, exigir alcance forçado ou mostrar falha, não alteres o equipamento: interrompe e pede assistência técnica ou avaliação profissional.

## Segurança do espaço

Utiliza uma rota acessível e livre de obstáculos, com espaço para virar e parar. Observa inclinação, aderência, desníveis, água, gravilha, buracos, bordos e mudanças de superfície antes de avançar. Evita tráfego, multidões, pouca luz e qualquer descida ou superfície que possa causar fuga da cadeira. Mantém velocidade controlável e margem de travagem compatível com a superfície e a visibilidade. Se o ambiente se tornar imprevisível ou exceder o teu controlo, pára numa zona segura e pede ajuda.

## Limitações

1. O conteúdo é educativo e não avalia a adequação da cadeira, a função individual, a visão, a sensibilidade, a estabilidade do tronco nem o ambiente real.
2. Não cobre técnicas para rampas, inclinações laterais, lancis, degraus, obstáculos, wheelies, quedas, tráfego ou desportos em cadeira.
3. Não prescreve dose, intensidade, velocidade, cadência, distância, duração, carga, intervalos, descanso nem progressão.
4. Não substitui avaliação, ajuste, demonstração ou treino individual por um profissional competente.
5. A orientação respiratória é conservadora; não foi identificada uma regra respiratória específica e universal para propulsão básica no solo.
6. A evidência biomecânica sobre padrões de recuperação não demonstra uma técnica única adequada a todas as pessoas e contextos.
7. O padrão de recuperação mais confortável e controlável depende da função, da cadeira e da tarefa.
8. A proximidade e o tipo de supervisão dependem da estabilidade, do controlo da travagem, da cadeira e do ambiente.

## Teste de compreensão

### 1. Que equipamento é obrigatório para este exercício?

Resposta esperada: Uma cadeira de rodas manual ajustada, funcional e adequada ao utilizador e ao percurso.

### 2. Quando devem estar aplicados os travões de estacionamento durante a preparação?

Resposta esperada: Enquanto a cadeira está parada e são feitas as verificações iniciais.

### 3. O que deves fazer aos travões de estacionamento antes de iniciares o movimento?

Resposta esperada: Libertar completamente os dois travões.

### 4. Onde deves manter o olhar enquanto propulsionas?

Resposta esperada: No percurso e no espaço à frente, não nas mãos.

### 5. Como devem ser os impulsos básicos para a frente?

Resposta esperada: Longos, suaves e tão simétricos quanto o controlo individual permitir.

### 6. Onde devem ficar os dedos e polegares relativamente às partes móveis?

Resposta esperada: Afastados de raios, pneus, rodízios, travões e zonas de aperto, com os polegares orientados para a frente.

### 7. Como podes fazer uma curva ampla enquanto avanças?

Resposta esperada: Impulsionando um pouco mais o lado exterior ou abrandando suavemente o lado interior da curva.

### 8. O que deves verificar antes de recuares?

Resposta esperada: Ambos os lados e todo o espaço atrás da cadeira.

### 9. Como se trava a cadeira enquanto ela ainda está em movimento?

Resposta esperada: Com pressão progressiva e semelhante nos dois aros, nunca com os travões de estacionamento.

### 10. Como deves respirar durante o movimento?

Resposta esperada: De forma natural e contínua, sem prender a respiração nem seguir contagens impostas.

### 11. Indica três sinais que obrigam a parar em segurança.

Resposta esperada: Por exemplo, desconforto no peito ou falta de ar atípica, tonturas ou confusão, e perda de controlo ou dor nova.

### 12. O que deves fazer se o alcance aos aros ou o ajuste da cadeira parecer inadequado?

Resposta esperada: Interromper e pedir avaliação a um profissional, sem alterar o equipamento por conta própria.

## Fontes e limites da evidência

### Fonte 1: SCIRE — Wheelchair Propulsion Training

- Autor ou entidade: A1-S22 — SCIRE — Wheelchair Propulsion Training — https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/wheelchair-propulsion-training/ — síntese profissional existente — Fonte existente usada como contexto para distinguir propulsão no solo de treino em rolos e para enquadrar a necessidade de técnica e equipamento adequados. — A página legada não ficou acessível durante a verificação; não foi usada como único suporte de nenhuma instrução.
- Tipo: síntese profissional existente
- Localizador: https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/wheelchair-propulsion-training/
- Usada para: A1-S22 — SCIRE — Wheelchair Propulsion Training — https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/wheelchair-propulsion-training/ — síntese profissional existente — Fonte existente usada como contexto para distinguir propulsão no solo de treino em rolos e para enquadrar a necessidade de técnica e equipamento adequados. — A página legada não ficou acessível durante a verificação; não foi usada como único suporte de nenhuma instrução.
- Limite: A1-S22 — SCIRE — Wheelchair Propulsion Training — https://scireproject.com/evidence/physical-activity-cardiovascular-health-and-fitness/cardiovascular-health-and-endurance/wheelchair-propulsion-training/ — síntese profissional existente — Fonte existente usada como contexto para distinguir propulsão no solo de treino em rolos e para enquadrar a necessidade de técnica e equipamento adequados. — A página legada não ficou acessível durante a verificação; não foi usada como único suporte de nenhuma instrução.

### Fonte 2: CSEP — Physical Activity Guidelines for Adults with Spinal Cord Injury

- Autor ou entidade: A1-S23 — CSEP — Physical Activity Guidelines for Adults with Spinal Cord Injury — https://csepguidelines.ca/guidelines/physical-activity-guidelines-for-adults-with-spinal-cord-injury/ — guideline profissional existente — Fonte existente usada apenas para enquadramento geral de atividade física adaptada. — Não fornece instrução detalhada de propulsão nem estabelece elegibilidade individual.
- Tipo: guideline profissional existente
- Localizador: https://csepguidelines.ca/guidelines/physical-activity-guidelines-for-adults-with-spinal-cord-injury/
- Usada para: A1-S23 — CSEP — Physical Activity Guidelines for Adults with Spinal Cord Injury — https://csepguidelines.ca/guidelines/physical-activity-guidelines-for-adults-with-spinal-cord-injury/ — guideline profissional existente — Fonte existente usada apenas para enquadramento geral de atividade física adaptada. — Não fornece instrução detalhada de propulsão nem estabelece elegibilidade individual.
- Limite: A1-S23 — CSEP — Physical Activity Guidelines for Adults with Spinal Cord Injury — https://csepguidelines.ca/guidelines/physical-activity-guidelines-for-adults-with-spinal-cord-injury/ — guideline profissional existente — Fonte existente usada apenas para enquadramento geral de atividade física adaptada. — Não fornece instrução detalhada de propulsão nem estabelece elegibilidade individual.

### Fonte 3: Arm crank ergometer is reliable and valid for measuring aerobic capacity during submaximal exercise

- Autor ou entidade: A2-S23 — Arm crank ergometer is reliable and valid for measuring aerobic capacity during submaximal exercise — https://pubmed.ncbi.nlm.nih.gov/20885199/ — artigo indexado existente — Consultado para auditoria do registo de evidência existente. — O URL corresponde a um estudo de ergómetro de braços e não a uma fonte direta sobre técnica de propulsão manual; não foi usado para sustentar instruções de execução.
- Tipo: artigo indexado existente
- Localizador: https://pubmed.ncbi.nlm.nih.gov/20885199/
- Usada para: A2-S23 — Arm crank ergometer is reliable and valid for measuring aerobic capacity during submaximal exercise — https://pubmed.ncbi.nlm.nih.gov/20885199/ — artigo indexado existente — Consultado para auditoria do registo de evidência existente. — O URL corresponde a um estudo de ergómetro de braços e não a uma fonte direta sobre técnica de propulsão manual; não foi usado para sustentar instruções de execução.
- Limite: A2-S23 — Arm crank ergometer is reliable and valid for measuring aerobic capacity during submaximal exercise — https://pubmed.ncbi.nlm.nih.gov/20885199/ — artigo indexado existente — Consultado para auditoria do registo de evidência existente. — O URL corresponde a um estudo de ergómetro de braços e não a uma fonte direta sobre técnica de propulsão manual; não foi usado para sustentar instruções de execução.

### Fonte 4: Wheelchair Provision Guidelines

- Autor ou entidade: EX07-S01 — Wheelchair Provision Guidelines — https://www.who.int/publications/i/item/9789240074521 — guideline oficial — Sustenta avaliação individual, ajuste, formação e acompanhamento por pessoal formado. — É uma guideline de prestação de serviços, não um manual passo a passo de propulsão.
- Tipo: guideline oficial
- Localizador: https://www.who.int/publications/i/item/9789240074521
- Usada para: EX07-S01 — Wheelchair Provision Guidelines — https://www.who.int/publications/i/item/9789240074521 — guideline oficial — Sustenta avaliação individual, ajuste, formação e acompanhamento por pessoal formado. — É uma guideline de prestação de serviços, não um manual passo a passo de propulsão.
- Limite: EX07-S01 — Wheelchair Provision Guidelines — https://www.who.int/publications/i/item/9789240074521 — guideline oficial — Sustenta avaliação individual, ajuste, formação e acompanhamento por pessoal formado. — É uma guideline de prestação de serviços, não um manual passo a passo de propulsão.

### Fonte 5: Wheelchair Service Training Package — Basic Level

- Autor ou entidade: EX07-S02 — Wheelchair Service Training Package — Basic Level — https://www.who.int/publications/i/item/9789241503471 — material oficial de formação — Sustenta a verificação, o ajuste, a formação do utilizador e a aprendizagem segura de competências básicas. — Destina-se a pessoal de serviços de cadeiras de rodas e requer adaptação ao utilizador.
- Tipo: material oficial de formação
- Localizador: https://www.who.int/publications/i/item/9789241503471
- Usada para: EX07-S02 — Wheelchair Service Training Package — Basic Level — https://www.who.int/publications/i/item/9789241503471 — material oficial de formação — Sustenta a verificação, o ajuste, a formação do utilizador e a aprendizagem segura de competências básicas. — Destina-se a pessoal de serviços de cadeiras de rodas e requer adaptação ao utilizador.
- Limite: EX07-S02 — Wheelchair Service Training Package — Basic Level — https://www.who.int/publications/i/item/9789241503471 — material oficial de formação — Sustenta a verificação, o ajuste, a formação do utilizador e a aprendizagem segura de competências básicas. — Destina-se a pessoal de serviços de cadeiras de rodas e requer adaptação ao utilizador.

### Fonte 6: Preservation of Upper Limb Function Following Spinal Cord Injury: A Clinical Practice Guideline for Health-Care Professionals

- Autor ou entidade: EX07-S03 — Preservation of Upper Limb Function Following Spinal Cord Injury: A Clinical Practice Guideline for Health-Care Professionals — https://pva.org/wp-content/uploads/2021/09/cpg_upperlimb.pdf — guideline clínica profissional — Sustenta impulsos longos e suaves, recuperação natural, postura estável e relevância do ajuste para a mecânica da propulsão. — Focada sobretudo em pessoas com lesão medular; não permite generalizar resultados ou uma técnica única a todos os utilizadores.
- Tipo: guideline clínica profissional
- Localizador: https://pva.org/wp-content/uploads/2021/09/cpg_upperlimb.pdf
- Usada para: EX07-S03 — Preservation of Upper Limb Function Following Spinal Cord Injury: A Clinical Practice Guideline for Health-Care Professionals — https://pva.org/wp-content/uploads/2021/09/cpg_upperlimb.pdf — guideline clínica profissional — Sustenta impulsos longos e suaves, recuperação natural, postura estável e relevância do ajuste para a mecânica da propulsão. — Focada sobretudo em pessoas com lesão medular; não permite generalizar resultados ou uma técnica única a todos os utilizadores.
- Limite: EX07-S03 — Preservation of Upper Limb Function Following Spinal Cord Injury: A Clinical Practice Guideline for Health-Care Professionals — https://pva.org/wp-content/uploads/2021/09/cpg_upperlimb.pdf — guideline clínica profissional — Sustenta impulsos longos e suaves, recuperação natural, postura estável e relevância do ajuste para a mecânica da propulsão. — Focada sobretudo em pessoas com lesão medular; não permite generalizar resultados ou uma técnica única a todos os utilizadores.

### Fonte 7: Wheelchair Skills Program Manual, Version 5.3.1

- Autor ou entidade: EX07-S04 — Wheelchair Skills Program Manual, Version 5.3.1 — https://wheelchairskillsprogram.ca/wp-content/uploads/WSP-Manual-version-5.3.1-final-.docx — manual profissional de competências — Sustenta propulsão para a frente, recuperação, observação do percurso, controlo da direção, recuo e travagem gradual. — A instrução completa pressupõe ensino e avaliação individual por alguém competente.
- Tipo: manual profissional de competências
- Localizador: https://wheelchairskillsprogram.ca/wp-content/uploads/WSP-Manual-version-5.3.1-final-.docx
- Usada para: EX07-S04 — Wheelchair Skills Program Manual, Version 5.3.1 — https://wheelchairskillsprogram.ca/wp-content/uploads/WSP-Manual-version-5.3.1-final-.docx — manual profissional de competências — Sustenta propulsão para a frente, recuperação, observação do percurso, controlo da direção, recuo e travagem gradual. — A instrução completa pressupõe ensino e avaliação individual por alguém competente.
- Limite: EX07-S04 — Wheelchair Skills Program Manual, Version 5.3.1 — https://wheelchairskillsprogram.ca/wp-content/uploads/WSP-Manual-version-5.3.1-final-.docx — manual profissional de competências — Sustenta propulsão para a frente, recuperação, observação do percurso, controlo da direção, recuo e travagem gradual. — A instrução completa pressupõe ensino e avaliação individual por alguém competente.

### Fonte 8: Manual Wheelchair Skills Guide — Wheeler and Clinician

- Autor ou entidade: EX07-S05 — Manual Wheelchair Skills Guide — Wheeler and Clinician — https://hsc.mb.ca/wp-content/uploads/manual-wheelchair-skills-guide.pdf — guia clínico profissional — Sustenta posição das mãos, impulso simétrico, cabeça levantada, recuperação, viragem, paragem e supervisão clínica. — É um guia de apoio a clínicos com formação de base e não substitui demonstração nem avaliação profissional.
- Tipo: guia clínico profissional
- Localizador: https://hsc.mb.ca/wp-content/uploads/manual-wheelchair-skills-guide.pdf
- Usada para: EX07-S05 — Manual Wheelchair Skills Guide — Wheeler and Clinician — https://hsc.mb.ca/wp-content/uploads/manual-wheelchair-skills-guide.pdf — guia clínico profissional — Sustenta posição das mãos, impulso simétrico, cabeça levantada, recuperação, viragem, paragem e supervisão clínica. — É um guia de apoio a clínicos com formação de base e não substitui demonstração nem avaliação profissional.
- Limite: EX07-S05 — Manual Wheelchair Skills Guide — Wheeler and Clinician — https://hsc.mb.ca/wp-content/uploads/manual-wheelchair-skills-guide.pdf — guia clínico profissional — Sustenta posição das mãos, impulso simétrico, cabeça levantada, recuperação, viragem, paragem e supervisão clínica. — É um guia de apoio a clínicos com formação de base e não substitui demonstração nem avaliação profissional.

### Fonte 9: Propulsion patterns and pushrim biomechanics in manual wheelchair propulsion

- Autor ou entidade: EX07-S06 — Propulsion patterns and pushrim biomechanics in manual wheelchair propulsion — https://pubmed.ncbi.nlm.nih.gov/11994814/ — estudo biomecânico primário — Sustenta a associação entre recuperação semicircular, menor cadência e maior proporção de tempo de impulso. — Estudo laboratorial numa população específica; apoia uma opção técnica, não uma regra universal.
- Tipo: estudo biomecânico primário
- Localizador: https://pubmed.ncbi.nlm.nih.gov/11994814/
- Usada para: EX07-S06 — Propulsion patterns and pushrim biomechanics in manual wheelchair propulsion — https://pubmed.ncbi.nlm.nih.gov/11994814/ — estudo biomecânico primário — Sustenta a associação entre recuperação semicircular, menor cadência e maior proporção de tempo de impulso. — Estudo laboratorial numa população específica; apoia uma opção técnica, não uma regra universal.
- Limite: EX07-S06 — Propulsion patterns and pushrim biomechanics in manual wheelchair propulsion — https://pubmed.ncbi.nlm.nih.gov/11994814/ — estudo biomecânico primário — Sustenta a associação entre recuperação semicircular, menor cadência e maior proporção de tempo de impulso. — Estudo laboratorial numa população específica; apoia uma opção técnica, não uma regra universal.

### Fonte 10: SCIRE — Stroke Pattern in Wheelchair Propulsion

- Autor ou entidade: EX07-S07 — SCIRE — Stroke Pattern in Wheelchair Propulsion — https://scireproject.com/evidence/wheeled-mobility-and-seating-equipment/manual-wheelchairs/wheelchair-propulsion/stroke-pattern-in-wheelchair-propulsion/ — síntese profissional atual — Sustenta a variabilidade dos padrões de recuperação e a necessidade de considerar preferência, conforto, tarefa, ambiente e ajuste. — A evidência sobre superioridade de um padrão é limitada e maioritariamente específica de pessoas com lesão medular.
- Tipo: síntese profissional atual
- Localizador: https://scireproject.com/evidence/wheeled-mobility-and-seating-equipment/manual-wheelchairs/wheelchair-propulsion/stroke-pattern-in-wheelchair-propulsion/
- Usada para: EX07-S07 — SCIRE — Stroke Pattern in Wheelchair Propulsion — https://scireproject.com/evidence/wheeled-mobility-and-seating-equipment/manual-wheelchairs/wheelchair-propulsion/stroke-pattern-in-wheelchair-propulsion/ — síntese profissional atual — Sustenta a variabilidade dos padrões de recuperação e a necessidade de considerar preferência, conforto, tarefa, ambiente e ajuste. — A evidência sobre superioridade de um padrão é limitada e maioritariamente específica de pessoas com lesão medular.
- Limite: EX07-S07 — SCIRE — Stroke Pattern in Wheelchair Propulsion — https://scireproject.com/evidence/wheeled-mobility-and-seating-equipment/manual-wheelchairs/wheelchair-propulsion/stroke-pattern-in-wheelchair-propulsion/ — síntese profissional atual — Sustenta a variabilidade dos padrões de recuperação e a necessidade de considerar preferência, conforto, tarefa, ambiente e ajuste. — A evidência sobre superioridade de um padrão é limitada e maioritariamente específica de pessoas com lesão medular.
