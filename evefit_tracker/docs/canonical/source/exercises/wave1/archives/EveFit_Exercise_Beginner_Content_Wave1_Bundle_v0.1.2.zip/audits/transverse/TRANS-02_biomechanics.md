# TRANS-02 — Auditoria transversal de biomecânica

**Data:** 2026-07-24  
**Especialidade:** anatomia funcional, mecânica do movimento, apoios, fases, receção/travagem, compensações e respiração  
**Resultado global:** `passed_with_revisions`  
**Blockers:** 0  
**Implementação realizada:** não

## Âmbito

Foram revistos os 49 exercícios em
`EveFit_Exercise_Beginner_Content_Wave1_v0.1/exercise_content`, comparando, para cada
exercício, o JSON `*_beginner_content_v0.1.json` com o Markdown público
`*_beginner_content_v0.1.md`: 49 JSON + 49 Markdown, 98 artefactos no total.

Foram também lidas as sete auditorias de capacidade:

- `AUD-A_cardio_conditioning.md`;
- `AUD-B_speed_power.md`;
- `AUD-C_mobility.md`;
- `AUD-D_flexibility.md`;
- `AUD-E_motor_control_coordination.md`;
- `AUD-F_technique_skill.md`;
- `AUD-G_breathing_regulation.md`.

Não foram consultados outputs de outros especialistas transversais. A revisão não
reabriu nem propõe alterar identidades, famílias, risco, relações ou elegibilidade.

## Método

1. Inventário fechado dos 49 pares JSON/Markdown e seleção dos campos com significado
   mecânico.
2. Leitura, por exercício, de posição inicial, checklist, passos, fases, pistas,
   erros/correções, finalização e, quando aplicável, receção ou travagem.
3. Verificação da direção do movimento, sequência articular, transferência de peso,
   manutenção ou libertação dos apoios, ordem das fases e regresso a uma base estável.
4. Verificação específica de tarefas balísticas: impulsão, fase aérea, contacto,
   absorção, desaceleração e estabilização.
5. Verificação de compensações previsíveis: colapso medial, extensão lombar substitutiva,
   rotação pélvica, inclinação do tronco, sobrealcance, bloqueio articular e impulso.
6. Revisão da respiração para retenções, sincronizações de fase não sustentadas e
   conflito entre orientação geral e instrução específica.
7. Comparação semântica JSON/Markdown nas instruções nucleares e cruzamento final com
   os findings das auditorias de capacidade. Um finding de capacidade só foi integrado
   quando a evidência biomecânica foi confirmada diretamente nos conteúdos.

Critério de estado:

- `passed`: sem revisão biomecânica obrigatória;
- `passed_with_revisions`: execução reconhecível e utilizável, mas com correção local
  obrigatória;
- `failed`: contradição nuclear ou blocker que impeça aprovação.

## Findings

### Grupo A — anatomia, apoios e direção da força

### TRANS-02-BIO-001 — localização do fulcro torácico não é operacional para principiante

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `seated_supported_thoracic_extension`
- **Campo:** `equipment_setup_pt_pt`, `starting_position_pt_pt`,
  `execution_steps_pt_pt[1]`, `principal_cues_pt_pt`, teste de compreensão; secções
  Markdown correspondentes
- **Evidência:** JSON linhas 25, 59, 124, 213 e 326 e Markdown linhas 38, 54 e 149
  localizam repetidamente o fulcro apenas na “região média ou superior das costas,
  abaixo do pescoço e acima da região lombar”. A descrição abrange uma área ampla e
  não fornece um teste visual ou tátil que permita a um principiante distinguir um
  apoio torácico de um contacto demasiado cervical ou lombar antes de se inclinar.
  A correção “reposiciona mais acima” também não fecha o critério. A auditoria
  `AUD-C-MOB-003` confirma a mesma lacuna de precisão.
- **Revisão exigida:** acrescentar uma referência leiga, observável e tecnicamente
  validada para a região torácica e uma verificação antes do arco. Se a pessoa não
  conseguir confirmar a localização, a colocação deve ser demonstrada/revista antes
  de iniciar. Replicar o mesmo critério em setup, posição, passos, erro/correção e
  teste, sem prescrever um nível vertebral universal.

### TRANS-02-BIO-002 — receção do salto horizontal omite a ação do tornozelo

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `standing_broad_jump`
- **Campo:** `execution_steps_pt_pt[4:6]`, `movement_phases_pt_pt`,
  `landing_or_braking_control_pt_pt`, `principal_cues_pt_pt`; Markdown “Execução” e
  “Controlo da receção e travagem”
- **Evidência:** o JSON, linhas 47 e 164, e o Markdown, linhas 62 e 170, fazem o
  contacto progredir para o pé inteiro, mas descrevem a absorção apenas por flexão da
  anca e dos joelhos. O tornozelo participa explicitamente na extensão da impulsão,
  mas desaparece da absorção e do critério final de receção. Nos conteúdos irmãos
  `countermovement_jump`, `bilateral_pogo_jump` e `two_foot_rope_skipping`, a ação
  controlada do tornozelo faz parte da receção.
- **Revisão exigida:** integrar a cedência controlada do tornozelo na preparação para
  o contacto, na absorção e no critério de travagem, mantendo a progressão para o pé
  inteiro. Não impor um padrão universal de contacto inicial do pé.

### TRANS-02-BIO-003 — rotação do pé traseiro no direto de boxe é mecanicamente ambígua

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `boxing_jab_cross_to_focus_mitts`
- **Campo:** `execution_steps_pt_pt[4]`, `movement_phases_pt_pt`,
  `principal_cues_pt_pt`; Markdown “Execução”
- **Evidência:** o JSON, linha 72, e o Markdown, linha 47, mandam “rodar o pé, a anca
  e o ombro traseiros em conjunto”. A posição inicial exige uma base estável, mas
  nenhuma instrução esclarece que a rotação do pé deve ocorrer como pivô controlado,
  em vez de torção de um pé integralmente fixo ao piso. Também não existe critério
  observável para o joelho acompanhar a direção do pé durante a rotação.
- **Revisão exigida:** operacionalizar o pivô do apoio traseiro com linguagem simples,
  permitindo que o calcanhar acompanhe a rotação sobre a parte anterior do pé e que o
  joelho permaneça orientado com o pé. Evitar ângulos, amplitude universal ou mudança
  da identidade jab–direto.

### TRANS-02-BIO-004 — superfície e organização do pé recetor não são executáveis no primeiro toque

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `football_directional_first_touch`
- **Campo:** `execution_steps_pt_pt[4:6]`, `principal_cues_pt_pt`,
  `common_errors_pt_pt`; Markdown “Execução” e “Erros comuns”
- **Evidência:** o JSON, linhas 73 e 148, e o Markdown, linhas 69 e 120, repetem
  “superfície ampla e controlável do pé”, mas não dão um exemplo introdutório nem um
  critério para reconhecer um tornozelo organizado no contacto. Assim, o principiante
  recebe a direção funcional — amortecer e redirecionar — sem uma configuração
  executável da superfície que transmite a força à bola. `AUD-F F-001` confirma esta
  lacuna técnica.
- **Revisão exigida:** acrescentar um exemplo introdutório não universal, como o
  interior do pé numa direção simples, e um critério observável de tornozelo estável
  durante o contacto. Outras superfícies devem depender da direção demonstrada,
  preservando passe rasteiro, primeiro toque único e ausência de oposição.

### TRANS-02-BIO-005 — interface correia–pé permanece indefinida

- **Severidade:** baixa
- **Blocker:** não
- **Exercício:** `supine_hamstring_strap_stretch`
- **Campo:** `formal_variant_explanation.additional_setup_pt_pt`,
  `equipment_setup_pt_pt`, `starting_position_checklist_pt_pt`,
  `movement_phases_pt_pt`, `common_errors_pt_pt`; Markdown correspondente
- **Evidência:** o JSON, linhas 15, 40, 63, 81 e 148, e o Markdown, linhas 26, 49, 78,
  96 e 155, repetem “zona estável do pé” sem a tornar observável. O conteúdo impede
  deslizamento para os dedos e compressão dolorosa, mas não permite confirmar antes da
  elevação onde a tração deve ficar distribuída. `AUD-D F-03` regista a mesma lacuna.
- **Revisão exigida:** validar e documentar uma descrição visual da zona permitida e
  da distribuição da pressão. Se não existir base para uma localização universal,
  exigir demonstração/revisão da colocação na primeira utilização, sem inventar um
  ponto anatómico único.

### Grupo B — respiração

### TRANS-02-BIO-006 — sincronização respiratória proposta apesar de falta de suporte específico

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `seated_supported_thoracic_extension`
- **Campo:** `breathing_guidance_pt_pt`; Markdown “Respiração”
- **Evidência:** o JSON, linha 96, e o Markdown, linha 69, afirmam primeiro que “não
  existe uma fase respiratória obrigatória sustentada especificamente para esta
  variante”, mas sugerem logo depois expirar na inclinação e inspirar no regresso.
  A ressalva “se for confortável” reduz rigidez, mas não resolve a contradição entre
  ausência de suporte específico e associação direcional. `AUD-C-MOB-001` confirma
  que o relatório de investigação não encontrou suporte suficiente para essa
  sincronização.
- **Revisão exigida:** manter apenas respiração natural, regular e contínua, sem
  retenção nem associação a uma direção, salvo suporte técnico específico posteriormente
  documentado e sincronizado em todos os artefactos.

### Grupo C — conflito JSON/Markdown com efeito mecânico

### TRANS-02-BIO-007 — verificação de prontidão testa direções diferentes

- **Severidade:** baixa
- **Blocker:** não
- **Exercício:** `tandem_stance`
- **Campo:** `body_readiness_check_pt_pt`
- **Evidência:** o JSON, linha 37, pergunta se a pessoa consegue mover um pé “para a
  frente” e regressar a base larga; o Markdown, linha 47, pergunta se consegue movê-lo
  “para o lado”. A primeira formulação testa a entrada em tandem; a segunda testa
  sobretudo a saída lateral. São verificações mecanicamente diferentes.
- **Revisão exigida:** usar nos dois formatos uma verificação única que cubra
  explicitamente a entrada para a frente e a saída controlada para uma base confortável,
  sem fundir as duas direções numa instrução ambígua.

### TRANS-02-BIO-008 — Markdown manda retirar mãos que são opcionais

- **Severidade:** baixa
- **Blocker:** não
- **Exercício:** `lateral_costal_breathing`
- **Campo:** `ending_the_exercise_pt_pt`; Markdown “Como terminar”
- **Evidência:** o contacto manual é opcional. O JSON, linha 163, termina corretamente
  com “retira as mãos **se as estiveres a usar**”; o Markdown, linha 121, elimina a
  condição e ordena “retira as mãos”. O Markdown deixa, portanto, de representar uma
  das duas configurações de apoio previstas.
- **Revisão exigida:** repor no Markdown a condição literal do JSON, sem tornar o
  contacto manual obrigatório.

## Padrões transversais

### Padrões conformes

- A ordem global das fases é mecanicamente coerente nos 49 exercícios: preparação,
  produção ou orientação do movimento, controlo do contacto/regresso e saída estável.
- As tarefas cíclicas distinguem adequadamente apoio, transferência, recuperação e
  finalização; as tarefas de equilíbrio regressam a base bipodal antes de mudança de
  direção ou abandono da zona.
- Receção e travagem estão, em geral, bem desenvolvidas nos saltos e sprints:
  desaceleração progressiva, vários apoios quando aplicável, flexão coordenada,
  alinhamento frontal e estabilização antes de nova ação.
- As compensações recorrentes são identificadas com critérios observáveis: joelhos
  para dentro, extensão lombar substitutiva, rotação pélvica, sobrealcance, inclinação
  do tronco, rigidez articular e uso de impulso.
- A respiração é predominantemente natural e contínua, sem retenção ou contagem
  obrigatória. Foi encontrada uma única sincronização diretamente contraditória com a
  ausência declarada de suporte específico.

### Padrões a rever

- Termos anatómicos amplos como “região torácica”, “superfície ampla do pé” e “zona
  estável do pé” não devem substituir um critério observável quando definem o fulcro ou
  a interface de transmissão de força.
- Uma articulação incluída na produção de força não deve desaparecer da descrição da
  absorção quando continua mecanicamente relevante; a exceção local encontrada é o
  tornozelo na receção do salto horizontal.
- Instruções de rotação sobre piso firme devem distinguir pivô controlado de torção
  sobre um pé fixo.
- A paridade JSON/Markdown é forte no núcleo mecânico: apenas dois conflitos locais
  com efeito em direção ou apoio foram confirmados.

## Estado por exercício afetado

| Exercício | Estado TRANS-02 | Findings | Síntese |
|---|---|---|---|
| `seated_supported_thoracic_extension` | `passed_with_revisions` | BIO-001, BIO-006 | Fulcro não operacional para principiante e sincronização respiratória sem suporte específico. |
| `standing_broad_jump` | `passed_with_revisions` | BIO-002 | A receção omite a ação absorvente do tornozelo. |
| `boxing_jab_cross_to_focus_mitts` | `passed_with_revisions` | BIO-003 | O pivô traseiro não distingue rotação controlada de torção do pé fixo. |
| `football_directional_first_touch` | `passed_with_revisions` | BIO-004 | Superfície e estabilidade do pé recetor não são suficientemente executáveis. |
| `supine_hamstring_strap_stretch` | `passed_with_revisions` | BIO-005 | A interface da correia com o pé não tem critério visual suficiente. |
| `tandem_stance` | `passed_with_revisions` | BIO-007 | JSON e Markdown testam direções distintas na prontidão. |
| `lateral_costal_breathing` | `passed_with_revisions` | BIO-008 | O Markdown perde a condição de uso opcional das mãos. |

Os outros 42 exercícios ficam `passed` nesta auditoria transversal: não foi
identificada neles revisão biomecânica obrigatória dentro do âmbito definido.

## Contagens

| Métrica | Contagem |
|---|---:|
| Exercícios auditados | 49 |
| JSON auditados | 49 |
| Markdown auditados | 49 |
| Auditorias de capacidade consultadas | 7 |
| Exercícios `passed` | 42 |
| Exercícios `passed_with_revisions` | 7 |
| Exercícios `failed` | 0 |
| Findings | 8 |
| Severidade média | 5 |
| Severidade baixa | 3 |
| Severidade alta | 0 |
| Blockers | 0 |
| Exercícios com conflito JSON/Markdown de efeito mecânico | 2 |
| Identidades ou riscos alterados/propostos para alteração | 0 |

## Independência e zero implementação

TRANS-02 não foi autor dos conteúdos. A revisão foi feita de forma independente sobre
os 98 artefactos de conteúdo e as sete auditorias de capacidade, sem consulta de
qualquer output de outro especialista transversal.

Foi realizada **zero implementação**. Nenhum JSON, Markdown de exercício, relatório de
investigação, registo canónico, relação, identidade, risco, equipamento, código,
configuração, multimédia ou conteúdo de produto foi alterado. O único ficheiro criado
por TRANS-02 foi este relatório.
