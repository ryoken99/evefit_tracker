# Ciclo de tiro com arco para alvo

Conteúdo para principiantes em português europeu.

## Descrição curta

Sequência completa de tiro com arco para um alvo protegido por barreira de retenção, executada numa linha de tiro controlada.

## O que é

Neste exercício, uma flecha real é colocada num arco aprovado e projetada contra um alvo próprio para tiro com arco. A execução encadeia postura, colocação da flecha, organização das mãos e do corpo, puxada, ancoragem, mira, largada e seguimento. Só é executada num campo controlado, com a linha de tiro autorizada, alvo e barreira de retenção verificados e supervisão obrigatória.

## O que vais fazer

Sob o comando do responsável pelo campo, vais posicionar-te na linha de tiro, colocar a flecha, organizar o arco e a mão da corda, puxar mantendo a flecha orientada ao alvo, chegar a uma ancoragem estável, mirar, largar sem gesto brusco e manter o seguimento até a flecha chegar ao alvo. Depois baixas o arco, aguardas atrás da linha e só recuperas flechas quando houver autorização.

## Porque existe este movimento

A ação existe para aprender e repetir com precisão a ordem técnica do ciclo completo de tiro dirigido a um alvo seguro. A distância, a pontuação e a quantidade de flechas não fazem parte da identidade deste exercício.

## Antes de começares

1. Confirma que estás num campo de tiro com arco controlado e que há um instrutor ou responsável de campo a supervisionar.
2. O responsável deve confirmar que a linha de tiro, a pista até ao alvo e a zona à frente e atrás do alvo estão livres e com acessos fechados.
3. O arco, as flechas, o alvo, a barreira de retenção, a proteção do antebraço e a proteção dos dedos têm de estar ajustados e inspecionados.
4. Mantém as flechas na aljava e não coloques nenhuma na corda antes do comando de tiro.
5. Aprende previamente os comandos locais de iniciar, parar e recuperar flechas; um comando de paragem tem prioridade sobre toda a sequência.

## Preparar o equipamento

1. Arco de tiro com arco aprovado — Deve ser selecionado, montado, ajustado e inspecionado pelo instrutor para a pessoa que o vai usar. Flechas aprovadas — Devem ser compatíveis com o arco e estar sem fissuras, lascas, deformações, pontas soltas ou encaixes danificados. Anteparo próprio para alvo de tiro com arco — Deve receber e reter as flechas e estar firmemente preso ao suporte para não tombar nem expor partes que danifiquem as flechas. Barreira de retenção verificada — Deve estar atrás do alvo, ter capacidade e cobertura adequadas ao campo e ser verificada pelo responsável antes do tiro.
2. Proteção do antebraço — Deve ficar colocada no antebraço do braço do arco, sem interferir com a corda. Proteção dos dedos — Deve estar corretamente colocada na mão que puxa a corda e ser adequada ao equipamento aprovado.
3. Não improvisar, reparar ou alterar o equipamento durante esta orientação. Qualquer ajuste ou dúvida pertence ao instrutor ou técnico responsável.

## Preparar o espaço

1. Campo de tiro com arco controlado, interior ou exterior, classificado como instalação especializada.
2. Linha de tiro estável e claramente identificada. Pista de tiro protegida e sem obstáculos entre a linha e o alvo. Anteparo de alvo próprio e barreira de retenção verificada. Acessos laterais, frontais e posteriores controlados durante o tiro. Zona de espera separada da linha de tiro e sistema de comandos audível ou visível.
3. Espaço público não fechado ou com possibilidade de atravessamento. Campo sem responsável, sem barreira de retenção verificada ou com alvo instável. Pessoa, animal ou veículo na pista de tiro ou na zona de segurança. Visibilidade, vento ou condições meteorológicas que impeçam o controlo seguro definido pelo responsável do campo.

## Verificação do corpo

1. Consegues permanecer de pé em apoio bipodal estável na linha sem desequilíbrio.
2. Consegues segurar o arco baixo e orientado para a zona segura sem perder o controlo.
3. Não há dor aguda, tontura, dormência, falta de ar fora do habitual nem fadiga que altere a direção do arco.
4. Compreendes e consegues cumprir imediatamente os comandos do responsável do campo.
5. Se algum ponto falhar, não colocas a flecha e informas o instrutor.

## Posição inicial

Em pé na linha de tiro estável, de lado para o alvo conforme a orientação do instrutor, com os dois pés apoiados, tronco alto e cabeça orientada ao alvo. O arco está baixo e apontado para a zona segura; a flecha permanece na aljava até ao comando que autoriza o tiro.

## Confirmar a posição inicial

1. Estou na posição indicada da linha de tiro e atrás de qualquer limite que o responsável tenha definido.
2. A pista, o alvo e a zona posterior foram declarados seguros pelo responsável.
3. Os pés estão estáveis e o corpo não está inclinado para a frente nem para trás.
4. A proteção do antebraço e a proteção dos dedos estão corretamente colocadas.
5. O arco permanece baixo e orientado ao alvo; a flecha só sai da aljava após autorização.

## Passos de execução

1. Avança para a posição atribuída apenas quando o responsável autorizar. Confirma o alvo correspondente e mantém o arco baixo, sem flecha na corda, enquanto organizas os pés. — Entrar na linha sob comando
2. Coloca os dois pés em apoio estável, com a orientação indicada pelo instrutor. Mantém o tronco alto, a cabeça virada para o alvo e a distribuição do peso sem balanço evidente. — Organizar a postura
3. Depois do comando de tiro, retira uma flecha aprovada da aljava, assenta-a no apoio e encaixa o entalhe no ponto de encaixe da corda conforme demonstrado pelo instrutor. — Colocar a flecha
4. Assenta a mão do arco na pega sem apertar em excesso e coloca os dedos protegidos na corda na posição ensinada para o equipamento aprovado. — Colocar as mãos
5. Alinha cabeça, tronco e cintura escapular de acordo com a demonstração do instrutor. Eleva o arco de forma controlada até a flecha apontar diretamente para o alvo correspondente. — Organizar o corpo e elevar o arco
6. Empurra de forma estável através do braço do arco e puxa a corda para trás com o cotovelo da corda a deslocar-se no plano do tiro. Mantém o ombro do arco controlado, sem o encolher. — Puxar
7. Leva a mão da corda ao ponto de referência no rosto que o instrutor definiu. Mantém a cabeça quieta e verifica que a sensação de contacto e o alinhamento são estáveis. — Ancorar e confirmar o alinhamento
8. Mantém o arco dirigido ao centro visual escolhido no alvo, sem perseguir movimentos pequenos. Respira de modo natural e discreto e deixa sair o ar sem contagens nem retenção deliberada. — Mirar e manter a respiração natural
9. Mantém a ação organizada do corpo e permite que os dedos da corda relaxem, sem abrir a mão de forma brusca. A mão da corda desloca-se naturalmente para trás no plano do tiro. — Largar
10. Conserva a cabeça, o olhar, o braço do arco e a direção para o alvo enquanto a flecha sai. Deixa a reação do arco acontecer sem o agarrar subitamente. — Manter o seguimento
11. Depois de a flecha chegar ao alvo, baixa o arco, confirma que não há flecha colocada e recua para a zona de espera indicada. — Baixar, sair e aguardar

## Fases do movimento

### Preparação

Preparação — Comando de campo, entrada na linha, postura, colocação da flecha e organização das mãos. — Flecha corretamente colocada, arco baixo e corpo estável.

### Construção do tiro

Construção do tiro — Organização do corpo, elevação do arco, puxada e chegada à ancoragem. — Referência de ancoragem reconhecível, cabeça estável e flecha orientada ao alvo.

### Mira e largada

Mira e largada — Mira, continuidade da ação e relaxamento dos dedos da corda. — A corda sai dos dedos sem gesto brusco e a flecha inicia o voo para o alvo.

### Seguimento e fecho

Seguimento e fecho — Manutenção da direção após a largada, descida do arco, saída da linha e espera pelo comando. — Arco baixo, linha desocupada e pessoa atrás da zona de espera.

## Respiração

Mantém uma respiração natural, discreta e coerente com o movimento. Evita inspirar ou expirar de forma forçada, usar contagens ou prender deliberadamente a respiração. Uma expiração suave pode acompanhar a puxada, a mira e a largada sem mudar subitamente no momento de soltar a corda. Se a respiração ficar presa, surgir tensão excessiva ou perderes estabilidade, baixa o arco de forma controlada em direção ao alvo e pede orientação ao instrutor.

## Sensações esperadas

1. Apoio estável nos dois pés e tronco organizado sem balanço evidente.
2. Tensão progressiva e controlada na região superior das costas e nos estabilizadores dos ombros durante a puxada.
3. Contacto de ancoragem reconhecível no ponto ensinado, sem necessidade de empurrar a cabeça.
4. Pressão estável da mão do arco e movimento natural da mão da corda para trás após a largada.
5. Reação breve do arco e da corda após a flecha sair, mantendo o corpo orientado ao alvo.

## Sensações inesperadas ou de alerta

1. Dor aguda, sensação de estalido corporal, dormência, perda súbita de força, tontura ou falta de ar fora do habitual.
2. Impacto forte ou repetido da corda no braço, mesmo com a proteção colocada.
3. Vibração, ruído ou deslocamento do arco que não estavam presentes na inspeção.
4. Flecha a fletir de forma visível, com fissura, lasca, deformação ou componentes soltos.
5. Incapacidade de manter a ponta da flecha e o arco dirigidos ao alvo.
6. Qualquer sinal destes exige paragem, arco baixo e comunicação imediata ao instrutor.

## Indicações técnicas principais

1. Só coloca a flecha após o comando de tiro.
2. Mantém o arco e a flecha orientados apenas para o teu alvo.
3. Pés estáveis, cabeça quieta e ombro do arco controlado.
4. Puxa até à mesma referência de ancoragem ensinada.
5. Respira naturalmente, sem contagens nem retenção deliberada.
6. Relaxa os dedos e mantém o seguimento antes de baixar o arco.
7. Nunca atravesses a linha sem o comando de recuperação.

## Erros comuns e correções

### Erro 1: Colocar uma flecha antes de a linha estar autorizada.

- Como reconhecer: A flecha sai da aljava ou é encaixada enquanto o responsável ainda não deu o comando de tiro.
- Como corrigir: Mantém todas as flechas na aljava, baixa o arco e espera pelo comando claro do responsável.

### Erro 2: Rodar ou elevar o arco para fora do alvo com a flecha colocada.

- Como reconhecer: A ponta da flecha cruza uma zona lateral, superior ou uma posição ocupada por pessoas.
- Como corrigir: Não largues. Mantém a direção para o alvo, baixa o arco de forma controlada e retira a flecha sob indicação do instrutor.

### Erro 3: Puxar sobretudo com o braço e elevar o ombro do arco.

- Como reconhecer: O ombro aproxima-se da orelha, o cotovelo da corda deixa o plano do tiro ou o tronco compensa.
- Como corrigir: Baixa o arco e pede ao instrutor que reorganize o ombro, o alinhamento e a ação das costas antes de nova tentativa.

### Erro 4: Mover a cabeça para procurar a corda ou variar a ancoragem.

- Como reconhecer: O rosto avança ou inclina-se e a mão da corda toca num local diferente do ponto de referência ensinado.
- Como corrigir: Mantém a cabeça orientada ao alvo e leva a mão da corda ao ponto de referência validado pelo instrutor.

### Erro 5: Agarrar o arco ou abrir a mão da corda de forma brusca na largada.

- Como reconhecer: O arco roda antes de a flecha sair, a mão da corda afasta-se lateralmente ou o corpo antecipa o disparo.
- Como corrigir: Mantém a ação, relaxa os dedos da corda e deixa as mãos seguirem as direções naturais ensinadas.

### Erro 6: Prender deliberadamente a respiração ou forçar a expiração.

- Como reconhecer: A face e o pescoço ficam tensos, a mira prolonga-se ou há uma mudança respiratória brusca antes da largada.
- Como corrigir: Baixa o arco com controlo e retoma uma respiração natural antes de reiniciar sob comando.

### Erro 7: Cruzar a linha para recuperar material sem autorização.

- Como reconhecer: A pessoa avança para uma flecha caída ou para o alvo enquanto o campo não foi aberto.
- Como corrigir: Permanece atrás da linha, sinaliza o responsável e espera pelo comando de recuperação.

## Formas de simplificar ou ensaiar

1. O instrutor pode dizer em voz alta os nomes das fases para ajudar a manter a ordem do ciclo completo.
2. O foco inicial pode ser cumprir a sequência e a direção segura, sem usar pontuação como critério.
3. Usa apenas o arco e as flechas que o instrutor ajustou e aprovou para ti; não alteres acessórios nem referências.
4. Se uma fase perder estabilidade, termina a tentativa com uma descida controlada; abortar antes da largada faz parte do controlo seguro.
5. Estas simplificações não eliminam a flecha real, o alvo, a barreira de retenção, o campo controlado nem a supervisão obrigatória.

## Supervisão

A supervisão é obrigatória em qualquer utilização com flecha real. Um instrutor competente ou responsável de campo deve inspecionar e ajustar o equipamento, verificar alvo e barreira de retenção, controlar acessos, emitir os comandos de tiro e recuperação, observar a direção do arco e intervir imediatamente perante qualquer falha. A presença de experiência prévia não transforma este conteúdo numa autorização para praticar sem supervisão.

## Como terminar

Após a largada, mantém o seguimento e só depois baixa o arco. Confirma que não ficou uma flecha colocada e recua para a zona de espera indicada. Mantém o arco em segurança e aguarda o comando de recuperação. Quando o responsável abrir o campo, caminha até ao alvo sem correr e segue a organização local para retirar as flechas. Não permaneças imediatamente atrás de outra pessoa que esteja a retirar uma flecha e não procures flechas perdidas sem autorização. No final, entrega o arco e qualquer flecha danificada ao instrutor para nova inspeção.

## Nota de segurança

Risco operacional alto. Só executar em campo de tiro com arco controlado, com equipamento obrigatório inspecionado, alvo e barreira de retenção verificados, acessos fechados, comandos de segurança ativos e supervisão obrigatória. Nunca apontar o arco a uma pessoa, nunca largar a corda sem uma flecha aprovada e nunca avançar para o alvo antes do comando.

## Quando parar ou reduzir

1. Entrada de qualquer pessoa, animal ou veículo na pista de tiro ou na zona protegida.
2. Comando de paragem ou sinal de emergência emitido pelo responsável.
3. Falha ou suspeita de dano no arco, corda, apoio, flecha, alvo ou barreira de retenção.
4. Perda de controlo da direção do arco ou incapacidade de baixar o arco em segurança.
5. Dor aguda, dormência, tontura, falta de ar fora do habitual ou fadiga que altere a técnica.
6. Perda de visibilidade ou condições meteorológicas que o responsável considere incompatíveis com a segurança.
7. Perante qualquer destes sinais, não largues: mantém a direção para o alvo, baixa o arco com controlo se conseguires fazê-lo e segue imediatamente as instruções do responsável.

## Segurança do equipamento

O instrutor verifica o arco aprovado antes da utilização, incluindo estrutura, membros, corda, ponto de encaixe, apoio da flecha e acessórios instalados. Cada flecha aprovada é observada antes de ser colocada; uma flecha fissurada, lascada, deformada ou com ponta, entalhe ou penas soltos não é usada. O anteparo de alvo deve estar firmemente preso ao suporte, e a barreira de retenção deve estar posicionada e verificada antes de abrir a linha. A proteção do antebraço e a proteção dos dedos são obrigatórias e devem estar corretamente ajustadas. Nunca largar a corda sem flecha, nunca usar equipamento improvisado e nunca tentar reparar uma falha na linha de tiro.

## Segurança do espaço

A linha de tiro e o alvo correspondente devem estar claramente identificados. Não pode existir acesso ativo do público, atravessamento ou pessoa à frente da linha durante o tiro. A pista deve estar livre em toda a direção da flecha, e a zona atrás do alvo deve ser protegida pela barreira de retenção verificada. Os arqueiros só elevam o arco, disparam e recuperam flechas nos períodos indicados pelos comandos locais. Se a visibilidade, o vento, a iluminação ou outro fator impedir o controlo seguro, o responsável mantém o campo fechado.

## Limitações

1. Este conteúdo é uma explicação documental para principiantes e não substitui demonstração, ajuste do equipamento, comandos e correção presencial por um instrutor competente.
2. A posição exata dos dedos, a referência facial e alguns pormenores da largada dependem do arco aprovado e do método ensinado; não são universalizados aqui.
3. Não são definidos distância, pontuação, volume, carga, ritmo, progressão individual nem critérios clínicos.
4. O manual da World Archery descreve padrões respiratórios que podem incluir uma breve pausa; por regra deste conteúdo e para evitar impor retenções, a orientação pública fica limitada a respiração natural e consistente.
5. A segurança depende da verificação real do campo, do alvo, da barreira de retenção, dos acessos e do equipamento em cada utilização.
6. Implementação realizada: não

## Teste de compreensão

### 1. Quando podes retirar uma flecha da aljava para a colocar no arco?

Resposta esperada: Só depois do comando de tiro dado pelo responsável do campo.

### 2. Para onde devem apontar o arco e a flecha durante a elevação e a puxada?

Resposta esperada: Diretamente para o alvo correspondente e nunca para uma pessoa ou zona lateral.

### 3. O que fazes se alguém entrar na pista enquanto estás a puxar?

Resposta esperada: Não largo; mantenho a direção para o alvo, baixo o arco com controlo e sigo o comando do responsável.

### 4. Podes avançar para apanhar uma flecha que caiu à frente da linha?

Resposta esperada: Não. Permaneço atrás da linha e aviso o responsável; só avanço com o comando de recuperação.

### 5. Qual é a diferença entre o anteparo do alvo e a barreira de retenção?

Resposta esperada: O anteparo recebe as flechas dirigidas ao alvo; a barreira atrás ajuda a reter uma flecha que falhe o anteparo.

### 6. Porque é proibido largar a corda sem uma flecha aprovada?

Resposta esperada: Porque pode danificar o arco e criar uma falha perigosa.

### 7. Que partes do corpo devem permanecer estáveis durante a ancoragem e a mira?

Resposta esperada: Os pés, o tronco e a cabeça mantêm-se estáveis, com o ombro do arco controlado.

### 8. Como chega a mão da corda à ancoragem?

Resposta esperada: A mão vai ao ponto de referência ensinado; a cabeça não avança para procurar a corda.

### 9. Como deve ser a respiração neste conteúdo para principiantes?

Resposta esperada: Natural e discreta, sem contagens, esforço ou retenção deliberada.

### 10. O que significa manter o seguimento?

Resposta esperada: Conservar cabeça, olhar, braço do arco e direção organizados enquanto a flecha sai, antes de baixar o arco.

### 11. O que fazes se uma flecha tiver fissura, lasca ou componente solto?

Resposta esperada: Não a coloco nem a disparo; entrego-a ao instrutor para inspeção.

### 12. A experiência prévia elimina a necessidade de campo controlado e supervisão?

Resposta esperada: Não. Toda a utilização com flecha real mantém o campo controlado e a supervisão obrigatória.

## Fontes e limites da evidência

### Fonte 1: World Archery Coaching Manual Level 1

- Autor ou entidade: World Archery
- Tipo: manual oficial de federação internacional
- Localizador: https://extranet.worldarchery.sport/documents/index.php/Coaches/Accreditation/Coaching_Levels/MANUAL_COACHING_LEVEL_1.pdf
- Usada para: F1S21 — World Archery Coaching Manual Level 1 — World Archery — manual oficial de federação internacional — https://extranet.worldarchery.sport/documents/index.php/Coaches/Accreditation/Coaching_Levels/MANUAL_COACHING_LEVEL_1.pdf — 2026-07-24 — Sequência técnica, postura, colocação da flecha, puxada, ancoragem, mira, largada, seguimento, respiração e problemas técnicos frequentes.
- Limite: F1S21 — World Archery Coaching Manual Level 1 — World Archery — manual oficial de federação internacional — https://extranet.worldarchery.sport/documents/index.php/Coaches/Accreditation/Coaching_Levels/MANUAL_COACHING_LEVEL_1.pdf — 2026-07-24 — Sequência técnica, postura, colocação da flecha, puxada, ancoragem, mira, largada, seguimento, respiração e problemas técnicos frequentes.

### Fonte 2: The World Archery Beginners' Awards Program

- Autor ou entidade: World Archery
- Tipo: programa técnico oficial para principiantes
- Localizador: https://extranet.worldarchery.sport/documents/index.php/Federation/Award_Schemes/Beginners_Awards_Programme_ENGLISH.pdf
- Usada para: F1S22 — The World Archery Beginners' Awards Program — World Archery — programa técnico oficial para principiantes — https://extranet.worldarchery.sport/documents/index.php/Federation/Award_Schemes/Beginners_Awards_Programme_ENGLISH.pdf — 2026-07-24 — Ordem das etapas do tiro, importância da segurança, cuidado do equipamento, largada e seguimento.
- Limite: F1S22 — The World Archery Beginners' Awards Program — World Archery — programa técnico oficial para principiantes — https://extranet.worldarchery.sport/documents/index.php/Federation/Award_Schemes/Beginners_Awards_Programme_ENGLISH.pdf — 2026-07-24 — Ordem das etapas do tiro, importância da segurança, cuidado do equipamento, largada e seguimento.

### Fonte 3: World Archery Coaching Manual Level 1

- Autor ou entidade: World Archery
- Tipo: manual técnico oficial
- Localizador: https://extranet.worldarchery.sport/documents/index.php/Coaches/Accreditation/Coaching_Levels/MANUAL_COACHING_LEVEL_1.pdf
- Usada para: F2-S15 — World Archery Coaching Manual Level 1 — World Archery — manual técnico oficial — https://extranet.worldarchery.sport/documents/index.php/Coaches/Accreditation/Coaching_Levels/MANUAL_COACHING_LEVEL_1.pdf — 2026-07-24 — Confirmação independente dentro do registo de evidência canónico para a sequência completa.
- Limite: F2-S15 — World Archery Coaching Manual Level 1 — World Archery — manual técnico oficial — https://extranet.worldarchery.sport/documents/index.php/Coaches/Accreditation/Coaching_Levels/MANUAL_COACHING_LEVEL_1.pdf — 2026-07-24 — Confirmação independente dentro do registo de evidência canónico para a sequência completa.

### Fonte 4: World Archery Rulebook, Book 2: Events

- Autor ou entidade: World Archery
- Tipo: regulamento oficial
- Localizador: https://extranet.worldarchery.sport/documents/index.php/Rules/Rule_Book_versions/2026-01-27/EN-Book_2_-_2026-01-27_Version.pdf
- Usada para: WA-BOOK2-2026 — World Archery Rulebook, Book 2: Events — World Archery — regulamento oficial — https://extranet.worldarchery.sport/documents/index.php/Rules/Rule_Book_versions/2026-01-27/EN-Book_2_-_2026-01-27_Version.pdf — 2026-07-24 — Barreiras ao público, fecho do campo, zona de segurança, barreira de retenção e fixação segura dos anteparos de alvo.
- Limite: WA-BOOK2-2026 — World Archery Rulebook, Book 2: Events — World Archery — regulamento oficial — https://extranet.worldarchery.sport/documents/index.php/Rules/Rule_Book_versions/2026-01-27/EN-Book_2_-_2026-01-27_Version.pdf — 2026-07-24 — Barreiras ao público, fecho do campo, zona de segurança, barreira de retenção e fixação segura dos anteparos de alvo.

### Fonte 5: World Archery Rulebook, Book 3: Target Archery

- Autor ou entidade: World Archery
- Tipo: regulamento oficial
- Localizador: https://extranet.worldarchery.sport/documents/index.php/Rules/Rule_Book_versions/2022-09-01/EN-Book3.pdf
- Usada para: WA-BOOK3-2022 — World Archery Rulebook, Book 3: Target Archery — World Archery — regulamento oficial — https://extranet.worldarchery.sport/documents/index.php/Rules/Rule_Book_versions/2022-09-01/EN-Book3.pdf — 2026-07-24 — Puxar o arco apenas na linha de tiro, orientar a flecha ao anteparo e confirmar a zona livre à frente e atrás do alvo.
- Limite: WA-BOOK3-2022 — World Archery Rulebook, Book 3: Target Archery — World Archery — regulamento oficial — https://extranet.worldarchery.sport/documents/index.php/Rules/Rule_Book_versions/2022-09-01/EN-Book3.pdf — 2026-07-24 — Puxar o arco apenas na linha de tiro, orientar a flecha ao anteparo e confirmar a zona livre à frente e atrás do alvo.

### Fonte 6: Archery Facilities: Guidance & Specifications

- Autor ou entidade: Archery GB
- Tipo: orientação oficial de federação nacional
- Localizador: https://archerygb.org/files/FacilityrequirementsandspecificationsFinalLOWRES-16543.pdf
- Usada para: AGB-FACILITIES — Archery Facilities: Guidance & Specifications — Archery GB — orientação oficial de federação nacional — https://archerygb.org/files/FacilityrequirementsandspecificationsFinalLOWRES-16543.pdf — 2026-07-24 — Controlo da linha, ausência de acesso à frente durante o tiro, direção única para o alvo, sinais para disparar e recuperar e manuseamento seguro do arco.
- Limite: AGB-FACILITIES — Archery Facilities: Guidance & Specifications — Archery GB — orientação oficial de federação nacional — https://archerygb.org/files/FacilityrequirementsandspecificationsFinalLOWRES-16543.pdf — 2026-07-24 — Controlo da linha, ausência de acesso à frente durante o tiro, direção única para o alvo, sinais para disparar e recuperar e manuseamento seguro do arco.

### Fonte 7: Archery Safety

- Autor ou entidade: USA Archery
- Tipo: orientação oficial de federação nacional
- Localizador: https://www.usarchery.org/participate/archery-safety
- Usada para: USA-ARCHERY-SAFETY — Archery Safety — USA Archery — orientação oficial de federação nacional — https://www.usarchery.org/participate/archery-safety — 2026-07-24 — Necessidade de instrutores formados para montar e operar o campo e ensinar tiro responsável.
- Limite: USA-ARCHERY-SAFETY — Archery Safety — USA Archery — orientação oficial de federação nacional — https://www.usarchery.org/participate/archery-safety — 2026-07-24 — Necessidade de instrutores formados para montar e operar o campo e ensinar tiro responsável.

### Fonte 8: USA Archery Club Handbook

- Autor ou entidade: USA Archery
- Tipo: manual oficial de clube
- Localizador: https://www.usarchery.org/resources/usa-archery-club-handbook-030220184842.pdf
- Usada para: USA-ARCHERY-CLUB-HANDBOOK — USA Archery Club Handbook — USA Archery — manual oficial de clube — https://www.usarchery.org/resources/usa-archery-club-handbook-030220184842.pdf — 2026-07-24 — Flechas na aljava até ao comando, largada apenas com flecha colocada e dirigida ao alvo e regras de circulação no campo.
- Limite: USA-ARCHERY-CLUB-HANDBOOK — USA Archery Club Handbook — USA Archery — manual oficial de clube — https://www.usarchery.org/resources/usa-archery-club-handbook-030220184842.pdf — 2026-07-24 — Flechas na aljava até ao comando, largada apenas com flecha colocada e dirigida ao alvo e regras de circulação no campo.
