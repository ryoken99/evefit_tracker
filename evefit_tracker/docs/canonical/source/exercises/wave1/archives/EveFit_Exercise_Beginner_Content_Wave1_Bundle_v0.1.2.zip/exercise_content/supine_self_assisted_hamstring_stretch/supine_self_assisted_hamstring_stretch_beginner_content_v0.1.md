# Alongamento dos isquiotibiais em decúbito dorsal com as mãos

Conteúdo para principiantes em português europeu.

## Descrição curta

Alongamento em decúbito dorsal no qual elevas uma coxa, sustentas a parte posterior da coxa com as próprias mãos e aproximas o joelho da extensão de forma controlada.

## O que é

Deitas-te de costas, manténs o tronco, a bacia e a outra perna apoiados, elevas uma coxa com a ajuda das mãos e estendes gradualmente esse joelho apenas até uma amplitude que continues a controlar. É um exercício autoassistido, não é um teste clínico.

## O que vais fazer

Vais apoiar a coxa com as duas mãos, manter a bacia estável e deixar o joelho abrir gradualmente. As mãos sustentam o peso da perna e permitem-te reduzir imediatamente a força ou sair da posição.

## Porque existe este movimento

Este movimento existe para praticares um alongamento assistido dos isquiotibiais com a força limitada pelas tuas próprias mãos. Pode integrar os percursos já aprovados de alongamento assistido, mas não garante uma alteração de amplitude nem um resultado individual.

## Antes de começares

1. Escolhe uma superfície estável, antiderrapante e sem trânsito ativo ou objetos que dificultem deitar, mover a perna e voltar a levantar.
2. Não é necessário equipamento portátil. Um tapete de exercício é opcional e serve apenas para conforto e contacto com o chão.
3. Confirma que consegues deitar-te, elevar uma coxa, alcançá-la com as duas mãos e voltar a baixar a perna sem depender de outra pessoa.
4. Não inicies se já tens dor aguda ou crescente, dormência, formigueiro, sensação elétrica, fraqueza súbita, instabilidade ou mal-estar.
5. Se estás a regressar após lesão ou cirurgia, ou se uma condição relevante altera a tua tolerância ou a capacidade de sair da posição, procura orientação individual antes de usar este conteúdo.

## Preparar o equipamento

1. Não há equipamento obrigatório. Se escolheres um tapete de exercício, coloca-o completamente assente numa superfície firme e antiderrapante, sem dobras ou zonas que deslizem. Não acrescentes uma faixa, toalha, peso, parceiro ou outro meio de tração: isso não faz parte desta identidade.

## Preparar o espaço

1. Reserva um espaço pequeno mas livre junto ao corpo e acima das pernas. A superfície deve ser estável e antiderrapante, e deve permitir apoio seguro das costas, da bacia e do pé ou da perna do lado oposto. Evita superfícies escorregadias, instáveis ou expostas a trânsito ativo.

## Verificação do corpo

1. Consegues manter a cabeça, os ombros, as costas e a bacia apoiados sem desconforto crescente?
2. Consegues apoiar a parte posterior da coxa com ambas as mãos sem puxar pela articulação do joelho?
3. Consegues estender e voltar a fletir o joelho de forma lenta, sem ressalto e sem perder o controlo da perna?
4. Consegues respirar de forma natural enquanto sustentas a coxa?
5. Consegues reconhecer a diferença entre uma tração suave na parte posterior da coxa e dor, pressão localizada, formigueiro ou sensação elétrica?

## Posição inicial

Deita-te de costas. Apoia a cabeça, os ombros, as costas e a bacia. Mantém a perna do lado oposto apoiada, com o pé ou a perna em contacto seguro com a superfície. Eleva a coxa que vai alongar, deixa o joelho fletido e coloca as duas mãos na parte posterior da coxa, acima da dobra do joelho.

## Confirmar a posição inicial

1. Estou deitado de costas numa superfície estável e antiderrapante.
2. A cabeça, os ombros, as costas e a bacia estão apoiados.
3. O pé ou a perna do lado contrário mantém contacto seguro com a superfície.
4. As duas mãos estão atrás da coxa, e não sobre a articulação nem na dobra do joelho.
5. O joelho da perna elevada começa fletido.
6. Consigo aliviar a tração e baixar a perna sem ajuda.

## Passos de execução

1. A partir da posição deitada, eleva uma coxa com o joelho fletido e recebe o peso da coxa nas duas mãos.
2. Apoia as mãos na parte posterior da coxa, suficientemente acima do joelho para não comprimir nem puxar a articulação.
3. Mantém a cabeça, os ombros, as costas, a bacia e a perna do lado oposto apoiados; não uses a bacia para ganhar amplitude.
4. Sem balanço, começa a estender lentamente o joelho da perna elevada, mantendo a coxa sustentada pelas mãos.
5. Pára de aumentar a amplitude quando sentires uma tração suave e distribuída na parte posterior da coxa, antes de dor ou perda de apoio.
6. Conserva apenas a amplitude que permita respirar naturalmente, manter a bacia apoiada e aliviar a força de imediato.
7. Para reduzir a sensação, flete um pouco mais o joelho ou aproxima menos a coxa do tronco, sem mudar o apoio das mãos.
8. Para sair, flete o joelho, aproxima a perna de uma posição fácil de controlar e baixa-a devagar até recuperar o apoio.

## Fases do movimento

### Preparação

Organiza a superfície e os apoios, eleva a coxa com o joelho fletido e coloca as mãos atrás da coxa.

### Entrada

Sustenta a coxa e estende gradualmente o joelho, sem balanço nem pressão direta sobre a articulação.

### Controlo da posição

Mantém apenas uma tração suave, com bacia apoiada, respiração livre e possibilidade de reduzir a força imediatamente.

### Saída

Volta a fletir o joelho antes de baixar a perna de forma controlada.

## Respiração

Respira de forma natural e contínua durante a entrada, a posição e a saída. Não prendas a respiração e não uses contagens, retenções ou expirações forçadas para tentar aumentar a amplitude.

## Sensações esperadas

1. Tração suave, gradual e relativamente distribuída na parte posterior da coxa elevada.
2. Esforço ligeiro das mãos e dos braços para sustentar a coxa, sem tensão crescente no pescoço ou nos ombros.
3. Sensação que diminui prontamente quando voltas a fletir um pouco o joelho ou aproximas menos a coxa do tronco.
4. Respiração livre e sensação de que continuas a controlar a entrada e a saída.

## Sensações inesperadas ou de alerta

1. Dor aguda, dor crescente ou sensação de rasgão.
2. Dormência, formigueiro, parestesia ou sensação elétrica na perna.
3. Fraqueza súbita ou perda de controlo da perna.
4. Pressão localizada ou desconfortável na dobra ou na parte posterior do joelho.
5. Dor lombar crescente, levantamento involuntário da bacia ou incapacidade de manter os apoios.
6. Tontura, náusea, falta de ar fora do habitual ou mal-estar.

## Indicações técnicas principais

1. Mãos atrás da coxa, acima do joelho.
2. Bacia e costas apoiadas.
3. Estende o joelho devagar e sem balanço.
4. Procura uma tração suave na parte posterior da coxa, não dor.
5. Respira livremente; não prendas o ar.
6. Para sair, flete primeiro o joelho e só depois baixa a perna.

## Erros comuns e correções

### Erro 1: Puxar diretamente pela articulação ou pela dobra do joelho.

- Como reconhecer: Sentes as mãos ou os dedos a pressionar uma zona pequena atrás do joelho, ou a sensação principal é pressão local em vez de tração na coxa.
- Como corrigir: Desloca ambas as mãos para a parte posterior da coxa, acima do joelho, e reduz a força antes de recomeçar.

### Erro 2: Levantar ou rodar a bacia para ganhar amplitude.

- Como reconhecer: Um lado da bacia perde contacto, as costas mudam de apoio ou a perna do lado oposto deixa de estar estável.
- Como corrigir: Flete um pouco o joelho da perna elevada ou afasta ligeiramente a coxa do tronco até recuperares um apoio estável.

### Erro 3: Forçar o joelho até uma posição rígida.

- Como reconhecer: A passagem para a amplitude final é brusca, aparece pressão posterior no joelho ou deixas de conseguir aliviar a força de imediato.
- Como corrigir: Volta a fletir o joelho e aproxima-te da extensão apenas enquanto a sensação continuar suave e controlável.

### Erro 4: Usar balanço ou pequenos ressaltos.

- Como reconhecer: O pé e a perna oscilam e a sensação aparece em picos, em vez de aumentar gradualmente.
- Como corrigir: Pára o movimento, estabiliza a coxa com as mãos e recomeça com uma extensão lenta e contínua.

### Erro 5: Prender a respiração e enrijecer o pescoço ou os ombros.

- Como reconhecer: O ar deixa de fluir, os ombros sobem ou a cabeça faz força contra a superfície.
- Como corrigir: Reduz a amplitude até conseguires respirar naturalmente e apoiar a cabeça e os ombros sem esforço crescente.

### Erro 6: Tratar formigueiro ou sensação elétrica como alongamento normal.

- Como reconhecer: A sensação percorre a perna, parece um choque, inclui dormência ou não se limita a uma tração suave na parte posterior da coxa.
- Como corrigir: Flete o joelho e baixa a perna de forma controlada; interrompe o exercício se a sensação não desaparecer prontamente ou voltar a surgir.

## Formas de simplificar ou ensaiar

1. Mantém o joelho mais fletido; não é necessário aproximá-lo da extensão completa.
2. Mantém a coxa menos próxima do tronco para reduzir a tração e facilitar o apoio da bacia.
3. Conserva a perna do lado oposto fletida com o pé apoiado, se essa organização tornar a base mais estável.
4. Coloca as mãos um pouco mais acima na parte posterior da coxa, desde que continues a sustentar a mesma coxa com ambas as mãos.
5. Interrompe a tentativa se não conseguires alcançar e sustentar a coxa sem ajuda; não substituas as mãos por equipamento ou assistência humana dentro desta identidade.

## Supervisão

A supervisão e um parceiro não são requisitos base para esta execução autoassistida de baixo risco. Pede observação de um profissional qualificado se não consegues organizar os apoios, distinguir uma tração muscular suave de sintomas de aviso ou sair da posição com controlo. Historial recente de lesão ou cirurgia, condição crónica relevante, retorno funcional, hipermobilidade, deficiência, gravidez ou pós-parto podem justificar adaptação ou revisão individual. Uma pessoa a puxar a tua perna introduz força externa e deixa de corresponder a esta execução autoassistida.

## Como terminar

Reduz primeiro a amplitude ao fletir o joelho. Mantendo a coxa segura, baixa a perna lentamente até o pé ou a perna recuperar contacto estável com a superfície. Só depois larga o apoio das mãos e muda de lado ou levanta-te sem movimentos bruscos.

## Nota de segurança

Mantém a ação lenta, reversível e sem ressalto. As mãos apoiam a coxa, não a articulação do joelho. Interrompe perante dor aguda ou crescente, sintomas elétricos ou sensitivos, fraqueza súbita, pressão desconfortável atrás do joelho, perda de apoio da bacia, perda de controlo ou mal-estar.

## Quando parar ou reduzir

1. A tração deixa de ser suave ou fica localizada atrás do joelho. — Reduz a amplitude ao fletir o joelho e reposiciona as mãos mais acima na coxa.
2. A bacia ou as costas começam a levantar-se. — Afasta ligeiramente a coxa do tronco ou mantém o joelho mais fletido até recuperares apoio.
3. Surge dor aguda ou crescente, dormência, formigueiro, parestesia ou sensação elétrica. — Flete o joelho, baixa a perna com controlo e interrompe.
4. Surge fraqueza súbita, perda de controlo, instabilidade ou mal-estar. — Termina a posição de forma controlada e não reinicies com base apenas neste conteúdo.

## Segurança do equipamento

Não existe equipamento obrigatório nem está aprovada qualquer resistência externa. Um tapete é apenas opcional: usa-o somente se ficar plano, firme e sem deslizar. Faixas, toalhas, pesos ou assistência de outra pessoa alteram a forma de aplicar força e não devem ser introduzidos nesta instrução.

## Segurança do espaço

Usa uma superfície estável, antiderrapante e sem obstáculos junto ao corpo. Garante espaço para elevar e baixar a perna sem bater em móveis, pessoas ou objetos. Não executes sobre apoio instável, superfície escorregadia ou numa zona com trânsito ativo.

## Limitações

1. Conteúdo educativo para principiantes, sem dose, prescrição, diagnóstico, tratamento, autorização clínica ou promessa de resultado. Não valida a execução com faixa, toalha, peso ou assistência humana e não substitui avaliação individual quando o historial ou os sintomas alteram a elegibilidade. Implementação realizada: não

## Teste de compreensão

### 1. Em que posição fica o corpo durante este exercício?

Resposta esperada: Deitado de costas, com o tronco e a bacia apoiados.

### 2. Onde deves colocar as mãos?

Resposta esperada: Na parte posterior da coxa elevada, acima da dobra do joelho.

### 3. Deves puxar diretamente pela articulação do joelho?

Resposta esperada: Não; a articulação e a dobra do joelho não são pontos de tração.

### 4. Qual é a principal ação da perna elevada?

Resposta esperada: A coxa mantém-se sustentada pelas mãos enquanto o joelho se aproxima da extensão de forma controlada.

### 5. Que partes do corpo devem continuar apoiadas?

Resposta esperada: Cabeça, ombros, costas, bacia e o pé ou a perna do lado oposto.

### 6. Qual é a sensação esperada?

Resposta esperada: Uma tração suave, gradual e distribuída na parte posterior da coxa.

### 7. O formigueiro ou a sensação elétrica contam como alongamento normal?

Resposta esperada: Não; são sinais para fletir o joelho, sair com controlo e interromper.

### 8. Como deves respirar?

Resposta esperada: De forma natural e contínua, sem prender o ar nem usar contagens.

### 9. O que fazes se a bacia começar a levantar-se?

Resposta esperada: Reduzo a amplitude, fletindo mais o joelho ou afastando um pouco a coxa do tronco.

### 10. Qual é a primeira ação para sair da posição?

Resposta esperada: Voltar a fletir o joelho.

### 11. É necessário equipamento ou um parceiro?

Resposta esperada: Não; não há equipamento obrigatório nem parceiro, e o tapete é apenas opcional.

### 12. Quando pode ser útil pedir orientação individual?

Resposta esperada: Quando não consigo organizar ou controlar a posição, distinguir sensações, sair com segurança, ou quando historial, sintomas ou condições relevantes alteram a elegibilidade.

## Fontes e limites da evidência

### Fonte 1: American Academy of Orthopaedic Surgeons. Knee Conditioning Program — Supine Hamstring Stretch.

- Autor ou entidade: D1-EXT-08 — guia profissional oficial — American Academy of Orthopaedic Surgeons. Knee Conditioning Program — Supine Hamstring Stretch. — https://www.orthoinfo.org/recovery/knee-conditioning-program/ — 2026-07-24 — Execução deitada, joelhos inicialmente fletidos, mãos atrás da coxa abaixo do joelho, extensão da perna, sensação posterior e aviso para não puxar pela articulação. — O documento está inserido num programa de condicionamento do joelho e inclui prescrição própria, que não foi importada.
- Tipo: guia profissional oficial
- Localizador: https://www.orthoinfo.org/recovery/knee-conditioning-program/
- Usada para: Execução deitada, joelhos inicialmente fletidos, mãos atrás da coxa abaixo do joelho, extensão da perna, sensação posterior e aviso para não puxar pela articulação.
- Limite: D1-EXT-08 — guia profissional oficial — American Academy of Orthopaedic Surgeons. Knee Conditioning Program — Supine Hamstring Stretch. — https://www.orthoinfo.org/recovery/knee-conditioning-program/ — 2026-07-24 — Execução deitada, joelhos inicialmente fletidos, mãos atrás da coxa abaixo do joelho, extensão da perna, sensação posterior e aviso para não puxar pela articulação. — O documento está inserido num programa de condicionamento do joelho e inclui prescrição própria, que não foi importada.

### Fonte 2: Mayo Clinic Staff. A guide to basic stretches.

- Autor ou entidade: MAYO-2024-STRETCH — guia clínico profissional — Mayo Clinic Staff. A guide to basic stretches. — https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20546848 — 2026-07-24 — Princípios de segurança: ação suave e lenta, sem ressalto, respiração durante o alongamento, tração ligeira como sensação esperada e dor como limite. — A variante de isquiotibiais mostrada usa uma parede e não define o apoio manual desta identidade.
- Tipo: guia clínico profissional
- Localizador: https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20546848
- Usada para: Princípios de segurança: ação suave e lenta, sem ressalto, respiração durante o alongamento, tração ligeira como sensação esperada e dor como limite.
- Limite: MAYO-2024-STRETCH — guia clínico profissional — Mayo Clinic Staff. A guide to basic stretches. — https://www.mayoclinic.org/healthy-lifestyle/fitness/in-depth/stretching/art-20546848 — 2026-07-24 — Princípios de segurança: ação suave e lenta, sem ressalto, respiração durante o alongamento, tração ligeira como sensação esperada e dor como limite. — A variante de isquiotibiais mostrada usa uma parede e não define o apoio manual desta identidade.

### Fonte 3: Cleveland Clinic. Stretching: 9 Exercises and 8 Benefits — Static hamstring stretch, lying down.

- Autor ou entidade: CCF-2025-LYING-HAMSTRING — conteúdo profissional revisto por especialista — Cleveland Clinic. Stretching: 9 Exercises and 8 Benefits — Static hamstring stretch, lying down. — https://health.clevelandclinic.org/stretching — 2026-07-24 — Confirmação independente da posição deitada e do apoio das mãos atrás da coxa. — A descrição pública é breve e contém dose, que não foi importada.
- Tipo: conteúdo profissional revisto por especialista
- Localizador: https://health.clevelandclinic.org/stretching
- Usada para: Confirmação independente da posição deitada e do apoio das mãos atrás da coxa.
- Limite: CCF-2025-LYING-HAMSTRING — conteúdo profissional revisto por especialista — Cleveland Clinic. Stretching: 9 Exercises and 8 Benefits — Static hamstring stretch, lying down. — https://health.clevelandclinic.org/stretching — 2026-07-24 — Confirmação independente da posição deitada e do apoio das mãos atrás da coxa. — A descrição pública é breve e contém dose, que não foi importada.

### Fonte 4: Decoster LC, Scanlon RL, Horn KD, Cleland J. Standing and Supine Hamstring Stretching Are Equally Effective. Journal of Athletic Training. 2004;39(4):330-334.

- Autor ou entidade: PMID-15592605 — literatura primária — ensaio aleatorizado — Decoster LC, Scanlon RL, Horn KD, Cleland J. Standing and Supine Hamstring Stretching Are Equally Effective. Journal of Athletic Training. 2004;39(4):330-334. — https://pubmed.ncbi.nlm.nih.gov/15592605/ — 2026-07-24 — Suporte de família para alongamento dos isquiotibiais em decúbito dorsal e extensão do joelho como medida de amplitude. — A variante supina estudada apoiava a perna numa parede, não nas mãos; a amostra era pequena e saudável, pelo que não sustenta técnica exata, segurança universal ou resultado individual.
- Tipo: literatura primária — ensaio aleatorizado
- Localizador: https://pubmed.ncbi.nlm.nih.gov/15592605/
- Usada para: Suporte de família para alongamento dos isquiotibiais em decúbito dorsal e extensão do joelho como medida de amplitude.
- Limite: PMID-15592605 — literatura primária — ensaio aleatorizado — Decoster LC, Scanlon RL, Horn KD, Cleland J. Standing and Supine Hamstring Stretching Are Equally Effective. Journal of Athletic Training. 2004;39(4):330-334. — https://pubmed.ncbi.nlm.nih.gov/15592605/ — 2026-07-24 — Suporte de família para alongamento dos isquiotibiais em decúbito dorsal e extensão do joelho como medida de amplitude. — A variante supina estudada apoiava a perna numa parede, não nas mãos; a amostra era pequena e saudável, pelo que não sustenta técnica exata, segurança universal ou resultado individual.

### Fonte 5: Reid DA, McNair PJ. Passive force, angle, and stiffness changes after stretching of hamstring muscles. Medicine & Science in Sports & Exercise. 2004;36(11):1944-1948.

- Autor ou entidade: PMID-15514511 — literatura primária — ensaio controlado aleatorizado — Reid DA, McNair PJ. Passive force, angle, and stiffness changes after stretching of hamstring muscles. Medicine & Science in Sports & Exercise. 2004;36(11):1944-1948. — https://pubmed.ncbi.nlm.nih.gov/15514511/ — 2026-07-24 — Contexto sobre amplitude de extensão do joelho, força passiva e tolerância à sensação no alongamento dos isquiotibiais. — Não estudou esta instrução autoassistida específica e não autoriza converter desconforto, dor ou sintomas neurais em metas.
- Tipo: literatura primária — ensaio controlado aleatorizado
- Localizador: https://pubmed.ncbi.nlm.nih.gov/15514511/
- Usada para: Contexto sobre amplitude de extensão do joelho, força passiva e tolerância à sensação no alongamento dos isquiotibiais.
- Limite: PMID-15514511 — literatura primária — ensaio controlado aleatorizado — Reid DA, McNair PJ. Passive force, angle, and stiffness changes after stretching of hamstring muscles. Medicine & Science in Sports & Exercise. 2004;36(11):1944-1948. — https://pubmed.ncbi.nlm.nih.gov/15514511/ — 2026-07-24 — Contexto sobre amplitude de extensão do joelho, força passiva e tolerância à sensação no alongamento dos isquiotibiais. — Não estudou esta instrução autoassistida específica e não autoriza converter desconforto, dor ou sintomas neurais em metas.

### Fonte 6: Borrelli J Jr, Kantor J, Ungacta F, Ricci W. Intraneural sciatic nerve pressures relative to the position of the hip and knee: a human cadaveric study. Journal of Orthopaedic Trauma. 2000.

- Autor ou entidade: PMID-10898197 — literatura primária — estudo biomecânico em cadáver — Borrelli J Jr, Kantor J, Ungacta F, Ricci W. Intraneural sciatic nerve pressures relative to the position of the hip and knee: a human cadaveric study. Journal of Orthopaedic Trauma. 2000. — https://pubmed.ncbi.nlm.nih.gov/10898197/ — 2026-07-24 — Contexto biomecânico conservador para reconhecer que as posições combinadas da anca e do joelho também podem alterar carga neural. — Estudo cadavérico; não permite diagnosticar sintomas, definir elegibilidade nem estabelecer um limiar seguro individual.
- Tipo: literatura primária — estudo biomecânico em cadáver
- Localizador: https://pubmed.ncbi.nlm.nih.gov/10898197/
- Usada para: Contexto biomecânico conservador para reconhecer que as posições combinadas da anca e do joelho também podem alterar carga neural.
- Limite: PMID-10898197 — literatura primária — estudo biomecânico em cadáver — Borrelli J Jr, Kantor J, Ungacta F, Ricci W. Intraneural sciatic nerve pressures relative to the position of the hip and knee: a human cadaveric study. Journal of Orthopaedic Trauma. 2000. — https://pubmed.ncbi.nlm.nih.gov/10898197/ — 2026-07-24 — Contexto biomecânico conservador para reconhecer que as posições combinadas da anca e do joelho também podem alterar carga neural. — Estudo cadavérico; não permite diagnosticar sintomas, definir elegibilidade nem estabelecer um limiar seguro individual.
