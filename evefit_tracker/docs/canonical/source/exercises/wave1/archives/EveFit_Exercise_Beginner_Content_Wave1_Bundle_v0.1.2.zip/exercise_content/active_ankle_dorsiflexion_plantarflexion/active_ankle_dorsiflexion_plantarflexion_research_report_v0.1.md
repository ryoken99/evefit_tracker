# Relatório de investigação — Flexão dorsal e plantar ativa do tornozelo

**Agente:** EX-25  
**Exercício:** `active_ankle_dorsiflexion_plantarflexion`  
**Data de consulta:** 2026-07-24  
**Âmbito:** conteúdo documental para principiante; sem implementação, prescrição, diagnóstico, tratamento ou publicação

## Decisão

O conteúdo pode ser aprovado com limites. A identidade canónica, o risco baixo, a cadeira obrigatória, a superfície, a ausência de parceiro/spotter e as quatro relações aprovadas foram preservados. Não foi criada variante nem alterado qualquer percurso.

O núcleo defensável é: posição sentada estável, pé alvo livre e sem carga, alternância ativa entre flexão dorsal e flexão plantar, controlo pelo tornozelo e ausência de deslocamento relevante do joelho e da perna.

## Perguntas de investigação

- Como explicar a execução a uma pessoa principiante?
- Que cadeira e posição sentada são defensáveis?
- Que orientação respiratória é sustentada?
- Como limitar a amplitude sem prescrever?
- Que erros são observáveis?
- Quais são os sinais de interrupção e os gatilhos de supervisão?

## Fontes e contributos

| Fonte | Tipo | Contributo usado | Limite aplicado |
|---|---|---|---|
| [NHS — Sitting exercises](https://www.nhs.uk/live-well/exercise/sitting-exercises/) | Institucional oficial | Cadeira sólida, estável e sem rodas; posição sentada; pé livre; apontar os dedos para longe e aproximá-los | Não foram importadas dose, frequência nem a posição específica do joelho |
| [AAOS — Foot and Ankle Conditioning Program](https://www.orthoinfo.org/recovery/foot-and-ankle-conditioning-program/) | Guia profissional oficial revisto por pares | Movimento pelo pé e tornozelo; dorsiflexão e flexão plantar; precaução perante dor; consulta profissional em caso de dúvida | Programa de condicionamento/reabilitação; não foram importados banda, alfabeto, dose ou alegações |
| [AAOS — Total Hip Replacement Exercise Guide: Ankle Pumps](https://www.orthoinfo.org/recovery/total-hip-replacement-exercise-guide/) | Guia profissional oficial | Execução sentada possível e movimento ativo para cima e para baixo dobrando no tornozelo | Contexto pós-operatório específico; dose, indicação e efeitos excluídos |
| [Toya et al., 2016](https://doi.org/10.1589/jpts.28.685) | Literatura experimental primária | Operacionalização de ankle pumping como alternância simples entre dorsiflexão e flexão plantar | Dez homens, posições em decúbito e objetivo hemodinâmico; ritmo, intervalos, amplitude máxima e resultados não generalizados |
| [Martin et al., 2021](https://www.jospt.org/doi/10.2519/jospt.2021.0302) | Guideline clínica profissional | Enquadramento conservador da mobilidade do tornozelo e separação entre conteúdo geral e decisão clínica em lesão | Específica para entorse lateral e dirigida a profissionais |

As fontes são independentes entre NHS, AAOS, guideline JOSPT e investigação primária. A literatura primária foi usada apenas para confirmar a estrutura mecânica recíproca; não foi usada para prometer eficácia.

## Síntese por domínio

### Execução e posição

O NHS e a AAOS convergem numa execução sentada em que o pé se move para cima e para baixo pelo tornozelo. A cadeira sólida e sem rodas é diretamente sustentada pelo NHS e coincide com o registo canónico. Para preservar a identidade, o texto mantém a coxa apoiada e o joelho organizado, sem impor extensão completa do joelho.

### Amplitude

A amplitude é descrita como voluntária, controlada e tolerada. Não é indicada amplitude máxima, porque isso seria individual e porque o registo canónico identifica «forçar fim de amplitude» como risco principal. Dor aguda ou bloqueio determinam interrupção, não continuação.

### Respiração

Não foi encontrada uma fase respiratória específica e generalizável para esta execução sentada sem carga. Foi aplicada a regra conservadora do contrato: respiração natural e contínua, sem retenção, sem contagens e sem coordenação fixa com a direção do pé.

### Erros observáveis

Foram documentados seis erros: deslocar coxa/joelho, introduzir movimento lateral ou circular, usar impulso, forçar o fim da amplitude, usar cadeira/superfície incompatível e prender a respiração. As correções mantêm a identidade e não acrescentam equipamento, carga ou variante.

### Segurança e supervisão

O risco operacional permanece baixo. Os sinais de interrupção foram preservados: dor aguda, bloqueio articular, perda súbita de controlo, tontura ou mal-estar. A supervisão basal permanece `none`, sem parceiro nem spotter.

Foram preservados os gatilhos de supervisão: incapacidade de manter o suporte previsto, medo de queda, sintomas durante a amplitude e dificuldade em distinguir movimento alvo de compensação. Cirurgia recente, retorno à função, sintomas persistentes ou instabilidade conhecida continuam a justificar revisão profissional contextual.

## Elementos deliberadamente não importados

- números de repetições ou séries;
- duração, frequência, ritmo ou intervalos;
- resistência elástica ou outra carga;
- amplitude máxima experimental;
- progressão programada;
- alegações de prevenção, circulação, redução de trombos, recuperação ou tratamento;
- autorização universal para executar;
- diagnóstico de sintomas;
- instruções específicas de protocolos pós-operatórios.

## Verificação do contrato

- Português europeu e UTF-8 NFC: sim.
- Chaves JSON na ordem exigida: sim.
- Passos de execução: 7.
- Cues principais: 6.
- Erros comuns com reconhecimento e correção: 6.
- Perguntas de compreensão: 12.
- Pelo menos duas fontes independentes: sim.
- Fonte clínica/profissional oficial: sim.
- Literatura primária: sim.
- Dose ou prescrição: não incluída.
- Promessa, diagnóstico ou tratamento: não incluídos.
- Alteração de identidade, risco, equipamento ou relações: nenhuma.
- Aprovação de media: nenhuma.
- Código ou publicação: nenhum.

## Limitações e confiança

A confiança é alta para a ação motora, a cadeira e a distinção entre direções; moderada para a respiração, porque a recomendação é conservadora e não específica; e moderada-alta para segurança e supervisão, por concordância entre o registo canónico e fontes profissionais.

As fontes clínicas têm contextos diferentes do conteúdo geral e o estudo primário não avaliou esta configuração sentada nem aprendizagem de principiantes. Por isso, o estado é `beginner_content_approved_with_limits`.

Implementação realizada: não
