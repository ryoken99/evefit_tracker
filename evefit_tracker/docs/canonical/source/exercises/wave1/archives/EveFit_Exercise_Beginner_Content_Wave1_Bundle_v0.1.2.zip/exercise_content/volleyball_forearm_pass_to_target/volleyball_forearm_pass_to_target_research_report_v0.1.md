# Relatório de investigação — `volleyball_forearm_pass_to_target`

**Agente:** EX-43  
**Data de consulta:** 2026-07-24  
**Idioma do conteúdo resultante:** português europeu  
**Implementação realizada: não**

## Resultado

O conteúdo para principiantes foi concluído com confiança moderada-alta. A técnica nuclear é sustentada por documentação oficial FIVB e USA Volleyball: posição atlética, deslocação até à linha da bola, plataforma plana com antebraços unidos e cotovelos estendidos, contacto à frente do corpo e orientação da plataforma para o alvo. As regras FIVB sustentam o uso de uma superfície regular e não escorregadia, espaço livre de obstáculos, bola adequada e contacto em ressalto, sem agarrar ou lançar.

Não foi encontrada uma instrução respiratória específica para o passe de antebraços nas fontes técnicas da modalidade. Foi mantida apenas a orientação geral de respiração natural e contínua, sem retenção nem contagens.

## Âmbito e bloqueios preservados

- Identidade: `canonical_exercise`.
- Definição: receber uma bola de voleibol alimentada por parceiro nos antebraços unidos e redirecioná-la para uma zona-alvo previamente definida.
- Família: `volleyball_forearm_pass`.
- Variante e exercício-base: `none`.
- Risco operacional: `low`, sem redução nem aumento.
- Equipamento obrigatório: `volleyball`.
- Equipamento opcional: `floor_target_marker`.
- Parceiro obrigatório: sim.
- Alvo obrigatório: sim.
- Spotter obrigatório: não.
- Supervisão: recomendada.
- Superfície: firme, plana e não escorregadia.
- Espaço: trajetória da bola, laterais e zona superior livres.
- Locais proibidos: teto baixo e espaço partilhado sem controlo.
- Sem aprovação de média.
- Sem dose, prescrição, diagnóstico, tratamento, promessa, código ou publicação.

## Relações preservadas

| Relação | Estado | Papel | Limite |
|---|---|---|---|
| `main_training → technique_skill → isolated_technical_practice → develop_isolated_technical_component` | compatível | candidato principal | Não inclui rally ou sequência coletiva |
| `main_training → technique_skill → target_oriented_precision → improve_target_consistency` | compatível | alternativa principal | Tamanho do alvo, alimentação e volume permanecem prescrição |

Não foi criada, removida ou alterada qualquer relação.

## Evidência técnica extraída

### Posição e deslocação

- O plano pedagógico da USA Volleyball indica pés aproximadamente à largura dos ombros, joelhos fletidos e deslocação dos pés até à bola.
- O glossário técnico da USA Volleyball usa os cues “joelhos fletidos”, “ombros à frente” e “plataforma plana e estável”.
- O Drill-book FIVB recomenda base ampla, joelhos fletidos, movimento para colocar a bola, quando possível, na linha central do corpo e contacto numa posição equilibrada.

Decisão editorial: posição bipodal estável, joelhos fletidos, ombros ligeiramente à frente e ajustes curtos antes de formar a plataforma.

### Plataforma e contacto

- A USA Volleyball descreve braços unidos ao nível dos cotovelos, punhos e mãos, polegares lado a lado, cotovelos estendidos e contacto entre punhos e cotovelos.
- O plano pedagógico da USA Volleyball indica plataforma afastada do corpo e orientada ao alvo.
- O manual FIVB refere contacto nos antebraços com plataforma de passe por baixo.
- O Drill-book FIVB recomenda braços estendidos, bola à frente do corpo e espaço entre bola e tronco.

Decisão editorial: antebraços aproximados, polegares lado a lado, cotovelos estendidos, plataforma plana afastada do tronco e contacto à frente.

### Direção para o alvo

- A FIVB descreve o controlo do passe para um alvo e a orientação do movimento na direção pretendida.
- A USA Volleyball indica explicitamente que a plataforma deve ficar angulada para o alvo.
- O Drill-book FIVB descreve um parceiro ou treinador a lançar a bola ao passador e um alvo de passe à frente.

Decisão editorial: definir o alvo antes do início, torná-lo conhecido pelos dois parceiros e orientar a saída sobretudo pelo ângulo da plataforma, com contribuição controlada das pernas.

### Natureza do contacto

- As regras FIVB determinam que a bola não deve ser agarrada nem lançada; deve ressaltar.
- O plano da USA Volleyball para defesa aconselha colocar a plataforma sob a bola sem balançar os braços.

Decisão editorial: contacto breve e simultâneo, sem agarrar, transportar ou executar balanço amplo dos braços.

## Preparação da bola, alvo e alimentação

A bola de voleibol permanece o único equipamento obrigatório. O marcador de chão permanece opcional, mas a zona-alvo é sempre definida. A fonte USA Volleyball sustenta o lançamento controlado como forma de iniciar tarefas de receção; a FIVB também descreve alimentação por treinador ou atleta.

A alimentação foi descrita como controlada, previsível e dirigida à frente do corpo. Isto é uma condição operacional segura para o principiante, não uma dose nem uma progressão programada. Não foram fixados distância, velocidade, volume ou dimensão do alvo.

## Segurança e supervisão

As Regras Oficiais FIVB 2025–2028 exigem uma superfície plana, horizontal e uniforme que não apresente perigo, proíbem superfícies ásperas ou escorregadias e definem espaço de jogo livre de obstáculos. Também atribuem ao árbitro a inspeção das condições, bolas e equipamento. Estes princípios foram traduzidos para o contexto documental, sem importar medidas de competição para a tarefa.

Foram preservados os fatores de risco canónicos:

- contacto da bola com face ou dedos;
- colisão pela bola;
- espaço cheio;
- fadiga;
- maior velocidade da alimentação;
- pouca iluminação;
- piso molhado;
- vento;
- bola danificada.

Foram preservados os sinais de interrupção:

- contactos repetidos na face;
- dor aguda;
- entrada de uma pessoa na zona.

A supervisão continua recomendada, sobretudo na primeira exposição ou com alimentação mais exigente. Não foi introduzida a exigência de spotter. O papel do supervisor é controlar alimentação, espaço, comunicação e pontos técnicos.

## Respiração

As fontes FIVB e USA Volleyball consultadas não apresentam um padrão respiratório específico para a manchete dirigida a alvo. A American Heart Association recomenda respirar regularmente durante atividade física e evitar prender a respiração. Essa orientação geral foi usada de forma limitada: respirar natural e continuamente, podendo deixar sair o ar suavemente no contacto, sem contagens nem retenções.

Não foi inferido qualquer benefício, efeito clínico ou padrão obrigatório.

## Erros documentados

1. Agarrar ou transportar a bola em vez de a deixar ressaltar.
2. Separar os antebraços no contacto.
3. Balancear excessivamente os braços.
4. Contactar demasiado perto do corpo.
5. Perseguir a bola para fora da zona segura.

Cada erro foi acompanhado por um sinal observável e uma correção técnica não prescritiva.

## Fontes oficiais e primárias consultadas

| Código | Fonte | Uso principal | Limite |
|---|---|---|---|
| `F2-S09` | [FIVB — Coaches Manual Level II](https://www.fivb.com/wp-content/uploads/2024/03/Coaches_Manual_Level_II_EN.pdf) | Plataforma de antebraços, controlo e alvo | Inclui material avançado; foram usados apenas princípios diretamente aplicáveis |
| `EX43-S01` | [FIVB — Beach Volleyball Drill-book](https://www.fivb.com/wp-content/uploads/2024/03/FIVB_Beachvolley_Drill-Book_EN.pdf) | Base, deslocação, contacto à frente e alimentação por parceiro | Algumas tarefas são de praia e contêm dose; não se importou dose nem especificidade da areia |
| `EX43-S02` | [FIVB — Official Volleyball Rules 2025–2028](https://www.fivb.com/wp-content/uploads/2025/01/FIVB-Volleyball_Rules2025_2028-EN-v05.pdf) | Superfície, espaço, bola e natureza do contacto | Regras de competição; as medidas competitivas não foram prescritas |
| `F1S06` | [USA Volleyball — Junior High Lesson Plans](https://usavolleyball.org/wp-content/uploads/2020/12/Junior-High-Lesson-Plans.pdf) | Posição, deslocação, plataforma, alvo e lançamento controlado | Plano pedagógico; a dose dos exemplos foi excluída |
| `EX43-S03` | [USA Volleyball — Teaching Goals, Objectives, Glossary and Cue Words](https://usavolleyball.org/wp-content/uploads/2020/12/Junior-High-Glossary-Cue-Words.pdf) | Definição do passe, superfície de contacto e cues | Recurso introdutório, não análise biomecânica individual |
| `F1S05` | [USA Volleyball — Lesson Plans](https://usavolleyball.org/resources-for-coaches/lesson-plans/) | Proveniência institucional dos planos | Índice, não substitui os documentos técnicos |
| `EX43-S04` | [American Heart Association — Getting Active to Control High Blood Pressure](https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/getting-active-to-control-high-blood-pressure) | Respiração regular e ausência de retenção | Orientação geral, não específica do voleibol |

## Confiança

| Área | Confiança | Justificação |
|---|---|---|
| Identidade | alta | Preservada diretamente do registo canónico |
| Técnica | alta | Convergência entre FIVB e USA Volleyball |
| Bola, alvo e alimentação | moderada-alta | Fontes oficiais sustentam bola, alvo e lançamento controlado; detalhes permanecem qualitativos |
| Ambiente | alta | Regras FIVB explícitas sobre superfície e espaço livre |
| Respiração | moderada | Sem instrução específica da modalidade; apenas orientação geral |
| Segurança | moderada-alta | Registo canónico mais regras e manuais oficiais |

## Limitações e campos por resolver

- Não há prescrição individual nem avaliação de elegibilidade.
- Não foram estabelecidas dose, distância, velocidade, intensidade, tamanho do alvo ou progressão.
- A evidência técnica é de manuais e federações, não prova transferência, segurança universal ou resultado individual.
- Os média permanecem `not_yet_approved`.
- Não existem campos documentais por resolver neste pacote.
- Implementação realizada: não.
