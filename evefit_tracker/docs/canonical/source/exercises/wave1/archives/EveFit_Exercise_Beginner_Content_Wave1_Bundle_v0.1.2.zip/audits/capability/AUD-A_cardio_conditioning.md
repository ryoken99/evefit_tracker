# Auditoria independente AUD-A — Cardio e Condicionamento

## Âmbito

Foram revistos todos e apenas os 11 exercícios cujo JSON contém `capability_primary == cardio_conditioning`:

`continuous_stair_ascent`, `full_body_elliptical`, `manual_wheelchair_propulsion_overground`, `marching_in_place`, `overground_running`, `overground_walking`, `static_rowing_ergometer`, `stationary_arm_crank_ergometry`, `treadmill_walking`, `two_foot_rope_skipping` e `upright_stationary_cycling`.

Para cada exercício foram comparados o JSON de conteúdo, o Markdown público e o respetivo relatório de investigação. A identidade, o risco, o equipamento, o ambiente e a supervisão foram também confirmados contra o registo canónico do próprio exercício em `_beginner_content_workspace/agent_inputs`. Não foram consultados relatórios de outros auditores.

## Método

A revisão verificou:

- clareza e capacidade de execução por um principiante;
- especificidade da preparação, posição inicial, passos, fases e finalização;
- orientação respiratória;
- erros observáveis e correções acionáveis;
- segurança pessoal, do equipamento e do ambiente;
- indicação e limites da supervisão;
- coerência entre JSON, Markdown, relatório de investigação e registo canónico;
- ausência de dose, prescrição, progressão programada, promessas de resultado, diagnóstico ou tratamento;
- coerência entre exercícios da mesma família e ausência de duplicação superficial.

Critério de estado:

- `passed`: sem revisão obrigatória identificada;
- `passed_with_revisions`: conteúdo utilizável, mas com uma ou mais correções locais obrigatórias;
- `failed`: existe blocker ou falha nuclear de identidade/segurança que impede aprovação.

## Estado por exercício

| Exercício | Estado | Síntese |
|---|---|---|
| `continuous_stair_ascent` | `passed` | Identidade de subida em degraus fixos, risco moderado, corrimão opcional, saída no patamar e exclusão da descida estão claros e coerentes. |
| `full_body_elliptical` | `passed_with_revisions` | Execução, quatro contactos, entrada/saída e equipamento estão sólidos; falta paridade do gabarito do teste no Markdown. |
| `manual_wheelchair_propulsion_overground` | `passed` | Cadeira ajustada, proteção das mãos, direção, recuo, travagem pelos aros e limites do percurso estão operacionalizados com prudência. |
| `marching_in_place` | `passed_with_revisions` | A execução é clara, mas a instrução obrigatória sobre calçado contradiz o material canónico sem requisitos pessoais. |
| `overground_running` | `passed` | Fase aérea, distinção de sprint/caminhada, passada não rígida, saída para marcha e riscos ambientais estão bem delimitados. |
| `overground_walking` | `passed` | Mantém deslocamento real, ausência de fase aérea intencional, equipamento não obrigatório e mudança de direção segura, sem prescrição. |
| `static_rowing_ergometer` | `passed` | Sequências pernas–tronco–braços e braços–tronco–pernas, ajuste dos pés, retorno da pega e supervisão são específicos e coerentes. |
| `stationary_arm_crank_ergometry` | `passed_with_revisions` | A mecânica e o ajuste são claros; a opção de cadeira de rodas não está reconciliada com o equipamento canónico nem operacionaliza a estabilização. |
| `treadmill_walking` | `passed_with_revisions` | Variante, plataformas laterais, chave, comandos e paragem estão coerentes; falta paridade do gabarito do teste no Markdown. |
| `two_foot_rope_skipping` | `passed_with_revisions` | Identidade bilateral, corda, espaço, receção e impacto estão bem delimitados; falta paridade do gabarito do teste no Markdown. |
| `upright_stationary_cycling` | `passed_with_revisions` | Ajuste, contactos e paragem estão sólidos; a montagem é demasiado genérica para principiante e falta o gabarito do teste no Markdown. |

## Findings

### AUD-A-CARDIO-001

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `marching_in_place`
- **Campo:** `before_you_start_pt_pt`; secção Markdown “Antes de começar”; coerência com equipamento
- **Evidência:** o JSON e o Markdown dizem “Usa roupa que não prenda os passos e calçado estável que não escorregue”. O registo canónico define `required_equipment: []`, `optional_equipment: []` e `personal_gear_requirements: []`. O próprio relatório afirma que não foi introduzido equipamento obrigatório.
- **Revisão exigida:** substituir a ordem por uma condição de segurança que não crie requisito pessoal, por exemplo: “Se usares roupa ou calçado, confirma que não prendem os passos nem escorregam.” Manter explícito que a superfície fixa usada como apoio é uma adaptação, não equipamento da identidade.

### AUD-A-CARDIO-002

- **Severidade:** alta
- **Blocker:** não
- **Exercício:** `stationary_arm_crank_ergometry`
- **Campo:** `before_you_start_pt_pt`, `starting_position_pt_pt`, `execution_steps_pt_pt`, `equipment_safety_pt_pt`
- **Evidência:** o conteúdo autoriza a posição “sentado numa cadeira de rodas devidamente estabilizada quando o aparelho o permite” e depois limita a verificação a confirmar que a cadeira está “estável”. O registo canónico permite posição sentada ou de pé, mas define apenas `stationary_arm_crank_ergometer` como equipamento obrigatório e não lista equipamento opcional. Nem JSON nem Markdown explicam ao principiante o que constitui estabilização suficiente da cadeira. O relatório reconhece a configuração em cadeira de rodas, mas também não fecha esta lacuna operacional.
- **Revisão exigida:** remover a menção específica à cadeira de rodas e manter uma formulação genérica de assento estável, salvo autorização canónica explícita. Se a configuração em cadeira de rodas for formalmente mantida, reconciliá-la primeiro com o campo de material e acrescentar uma verificação inequívoca e dependente do manual/profissional: travões de estacionamento aplicados e testados, cadeira imóvel, posicionamento compatível com o ergómetro e saída segura. Não transformar esta correção numa instrução genérica de ajuste de cadeira.

### AUD-A-CARDIO-003

- **Severidade:** média
- **Blocker:** não
- **Exercício:** `upright_stationary_cycling`
- **Campo:** `execution_steps_pt_pt`, `starting_position_pt_pt`, `ending_the_exercise_pt_pt`
- **Evidência:** o passo de entrada é apenas “Monta com cuidado, senta-te ao centro do selim e fixa cada pé...”. Para um principiante absoluto, isto não identifica apoio fixo, sequência de transferência nem como evitar contacto com pedais/manivelas. A saída é mais específica e exige pontos fixos de apoio, criando uma assimetria de detalhe. O relatório declara montagem e desmontagem cobertas, mas não resolve a montagem ao nível operacional.
- **Revisão exigida:** acrescentar uma sequência de montagem dependente do modelo: bicicleta totalmente parada, apoio apenas em ponto fixo indicado pelo fabricante, entrada controlada, estabilização no selim e só depois colocação segura dos pés. Evitar inventar um lado universal de entrada ou um método incompatível com modelos diferentes.

### AUD-A-CARDIO-004

- **Severidade:** baixa
- **Blocker:** não
- **Exercícios:** `full_body_elliptical`, `treadmill_walking`, `two_foot_rope_skipping`, `upright_stationary_cycling`
- **Campo:** `beginner_comprehension_test`; secção Markdown de teste/verificação de compreensão
- **Evidência:** cada JSON contém 12 perguntas com `expected_answer_pt_pt`, mas os quatro Markdown apresentam apenas as perguntas. Nos restantes exercícios do âmbito, as respostas são publicadas em linha ou numa secção de respostas esperadas. Os relatórios contabilizam as 12 perguntas, sem explicar a omissão do gabarito público.
- **Revisão exigida:** acrescentar ao Markdown as respostas esperadas já existentes no JSON, sem criar conteúdo novo, e normalizar a apresentação com os restantes exercícios.

## Padrões transversais

### Pontos fortes confirmados

- Os 11 IDs, nomes, tipos, famílias e relações base/variante coincidem com os registos canónicos.
- Os níveis de risco declarados ou descritos são coerentes: baixo para caminhada terrestre, marcha no lugar, elíptica, manivela de braços e bicicleta vertical; moderado para corrida, cadeira de rodas, remo, passadeira, corda e escadas.
- O equipamento nuclear é corretamente distinguido: nenhum equipamento obrigatório nas locomoções livres; máquina específica nas modalidades estacionárias; cadeira manual ajustada na propulsão; corda no salto.
- Todos os exercícios têm preparação, posição, pelo menos cinco passos, respiração, pelo menos quatro pistas, pelo menos quatro erros completos, finalização e sinais de interrupção.
- A respiração é apresentada de forma natural e contínua, sem retenções ou contagens impostas.
- Não foram encontradas doses fixas, resistência prescrita, cadência-alvo, duração, distância, progressão programada, promessas de resultado, diagnóstico ou tratamento.
- As fronteiras familiares são suficientemente específicas: caminhada versus corrida; solo versus passadeira; marcha estacionária versus deslocamento; ergómetro fixo versus deslocamento real; elíptica de corpo inteiro versus pernas isoladas; salto bilateral versus alternado; escadas reais versus máquinas.
- Não foi identificada duplicação superficial entre exercícios: a estrutura editorial é semelhante, mas as instruções nucleares, riscos, equipamento, entrada/saída e erros são específicos de cada identidade.

### Padrões que exigem revisão

- As referências a equipamento ou apoio individual devem manter a mesma disciplina já aplicada em `overground_walking` e `overground_running`: linguagem condicional, sem transformar equipamento pessoal não canónico em requisito.
- Operações de montagem ou estabilização de equipamento devem ser descritas até ao ponto em que um principiante saiba o que verificar, remetendo apenas os mecanismos específicos para o manual.
- O teste de compreensão precisa de uma convenção única entre JSON e Markdown; a atual omissão seletiva das respostas é uma divergência editorial evitável.

## Contagens

| Métrica | Contagem |
|---|---:|
| Exercícios auditados | 11 |
| `passed` | 5 |
| `passed_with_revisions` | 6 |
| `failed` | 0 |
| Findings | 4 |
| Findings de severidade alta | 1 |
| Findings de severidade média | 2 |
| Findings de severidade baixa | 1 |
| Blockers | 0 |

Não existe qualquer `failed` disfarçado: não foi encontrada falha nuclear de identidade, risco ou execução que torne um exercício não utilizável após revisão local. O finding de severidade alta é não bloqueante porque a correção pode ser feita removendo ou formalizando uma opção de configuração sem reescrever a identidade nuclear do exercício.

## Declaração de independência e zero implementação

Esta auditoria foi realizada por AUD-A como revisão independente. AUD-A não foi autor de nenhum dos exercícios e não consultou relatórios de outros auditores.

Foi realizada **zero implementação**: nenhum JSON, Markdown de exercício, relatório de investigação, registo canónico, relação, regra, código, configuração, multimédia ou conteúdo de produto foi alterado. O único ficheiro criado foi este relatório de auditoria.
